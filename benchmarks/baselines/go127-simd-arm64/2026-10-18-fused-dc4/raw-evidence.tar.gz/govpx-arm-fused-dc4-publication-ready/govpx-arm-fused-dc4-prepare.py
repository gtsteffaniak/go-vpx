from pathlib import Path
import shutil,subprocess
r=Path('/private/tmp/govpx-arm-fused-dc4');r.mkdir();(r/'drivers').mkdir();(r/'evidence').mkdir();src=Path('/private/tmp/govpx-arm-fused-dc-fresh/candidate')
for v in ['parent','candidate']:shutil.copytree(src,r/v)
p=r/'candidate/internal/pixel/intra4x4_dc_fill_arm64.go';p.write_text('''//go:build goexperiment.simd && arm64 && !purego

package pixel

import (
 "simd/archsimd"
 "unsafe"
)

// Intra4x4DCFill follows libvpx v1.16.0 vpx_dsp/intrapred.c DC rounding.
// The exact four-byte references are completely consumed before output stores.
func Intra4x4DCFill(dst []byte, ds int, above, left []byte) bool {
 if !Enabled || uint(ds)>>30 != 0 || 3*ds+4 > len(dst) || len(above)<4 || len(left)<4 { return false }
 a := *(*uint32)(unsafe.Pointer(unsafe.SliceData(above)))
 l := *(*uint32)(unsafe.Pointer(unsafe.SliceData(left)))
 v := archsimd.Uint32x4{}.SetElem(0,a).SetElem(1,l).ReshapeToUint8s().ExtendLo8ToUint16()
 value := byte((int(v.ReduceSum())+4)>>3)
 word := archsimd.BroadcastUint8x16(value).ReshapeToUint32s().GetElem(0)
 p := unsafe.Pointer(unsafe.SliceData(dst))
 *(*uint32)(p)=word
 *(*uint32)(unsafe.Add(p,ds))=word
 *(*uint32)(unsafe.Add(p,2*ds))=word
 *(*uint32)(unsafe.Add(p,3*ds))=word
 return true
}
''')
(r/'candidate/internal/pixel/intra4x4_dc_fill_other.go').write_text('''//go:build !goexperiment.simd || !arm64 || purego

package pixel

func Intra4x4DCFill(dst []byte, ds int, above, left []byte) bool { return false }
''')
p=r/'candidate/internal/vp8/dsp/intra4x4_other.go';s=p.read_text();old='\tif pixel.Enabled {\n\t\tintraDCGo(dst, dstStride, above, left, 4, true, true)';new='\tif pixel.Enabled {\n\t\tif pixel.Intra4x4DCFill(dst, dstStride, above, left) { return }\n\t\tintraDCGo(dst, dstStride, above, left, 4, true, true)';assert s.count(old)==1;p.write_text(s.replace(old,new))
s=(src/'internal/vp8/dsp/fused_dc_probe_test.go').read_text().replace('fusedDC','fusedDC4').replace('TestFusedDC','TestFusedDC4').replace('[]int{8, 16}','[]int{4}').replace('[]bool{false, true}', '[]bool{true}').replace('for mode := range 4 {','for _, mode := range []int{3} {')
a=s.index('func fusedDC4Prior(');b=s.index('func fusedDC4Scalar(',a)
s=s[:a]+'''func fusedDC4Prior(dst []byte, ds int, above, left []byte, n int, up, lf bool) {
 _ = above[3]
 _ = left[3]
 _ = dst[3*ds+3]
 if pixel.Enabled { intraDCGo(dst,ds,above,left,4,true,true) } else { intra4x4DCPredictScalar(dst,ds,above,left) }
}
func fusedDC4Call(dst []byte, ds int, above, left []byte, n int, up, lf bool) {
 Intra4x4DCPredict(dst,ds,above,left)
}
'''+s[b:]
# Keep both reference clipping modes (unrelated to available-reference booleans).
s=s.replace('for _, clip := range []bool{true} {','for _, clip := range []bool{false, true} {')
for v in ['parent','candidate']:(r/v/'internal/vp8/dsp/fused_dc4_probe_test.go').write_text(s)
p=r/'candidate/internal/pixel/intra4x4_dc_fill_probe_test.go';p.write_text('''package pixel

import (
 "bytes"
 "runtime"
 "testing"
)

func dc4PixelOracle(dst []byte,ds int,above,left []byte) {
 sum:=0;for i:=0;i<4;i++ { sum+=int(above[i])+int(left[i]) };value:=byte((sum+4)>>3)
 for y:=0;y<4;y++ { for x:=0;x<4;x++ { dst[y*ds+x]=value } }
}
func TestIntra4x4DCFillAllSums(t *testing.T) {
 selected:=Enabled&&runtime.GOARCH=="arm64"
 for total:=0;total<=2040;total++ {
  above,left:=make([]byte,4),make([]byte,4);rem:=total
  for i:=0;i<8;i++ { v:=min(255,rem);rem-=v;if i<4 {above[i]=byte(v)}else{left[i-4]=byte(v)} }
  for align:=0;align<16;align++ {
   const ds=7;const span=3*ds+4
   got:=bytes.Repeat([]byte{91},align+span+17);want:=bytes.Clone(got)
   if selected { dc4PixelOracle(want[align:align+span:align+span],ds,above,left) }
   ok:=Intra4x4DCFill(got[align:align+span:align+span],ds,above,left)
   if ok!=selected||!bytes.Equal(got,want) {t.Fatalf("sum%d align%d selected%v/%v",total,align,ok,selected)}
  }
 }
}
func TestIntra4x4DCFillAliases(t *testing.T) {
 selected:=Enabled&&runtime.GOARCH=="arm64"
 for _,ds:=range []int{0,1,3,4,7,37,1312} {
  for align:=0;align<16;align++ {
   for alias:=0;alias<5;alias++ {
    span:=3*ds+4;off:=31+align;got:=make([]byte,off+span+71)
    for i:=range got {got[i]=byte(i*37+i/7+11)};want:=bytes.Clone(got)
    ao,lo:=off+span+11,off+span+17
    if alias==1 {ao=off};if alias==2 {lo=off};if alias==3 {ao=off;lo=off};if alias==4 {lo=ao+1}
    if selected {dc4PixelOracle(want[off:off+span:off+span],ds,want[ao:ao+4:ao+4],want[lo:lo+4:lo+4])}
    ok:=Intra4x4DCFill(got[off:off+span:off+span],ds,got[ao:ao+4:ao+4],got[lo:lo+4:lo+4])
    if ok!=selected||!bytes.Equal(got,want) {t.Fatalf("ds%d align%d alias%d",ds,align,alias)}
   }
  }
 }
}
func TestIntra4x4DCFillDeclines(t *testing.T) {
 maxInt:=int(^uint(0)>>1)
 for _,ds:=range []int{-1,0,1,3,4,7,37,1312,(1<<30)-1,1<<30,maxInt,-maxInt-1} {
  span:=4;if ds>=0&&ds<=1312 {span=3*ds+4}
  for _,win:=range [][2]int{{0,0},{0,span},{span-1,span-1},{span-1,span},{span,span}} {
   for _,alen:=range []int{0,1,3,4} {for _,llen:=range []int{0,1,3,4} {
    got:=bytes.Repeat([]byte{139},span+17);want:=bytes.Clone(got);above,left:=[]byte{1,3,5,7},[]byte{9,11,13,15}
    eligible:=Enabled&&runtime.GOARCH=="arm64"&&uint(ds)>>30==0&&3*ds+4<=win[0]&&alen>=4&&llen>=4
    if eligible {dc4PixelOracle(want[:win[0]:win[1]],ds,above,left)}
    ok:=Intra4x4DCFill(got[:win[0]:win[1]],ds,above[:alen:alen],left[:llen:llen])
    if ok!=eligible||!bytes.Equal(got,want) {t.Fatalf("ds%d win%v refs%d/%d",ds,win,alen,llen)}
   }}
  }
 }
}
''')
files=[p for v in ['parent','candidate']for p in(r/v).rglob('*_probe_test.go')if 'dc4'in p.name]+[r/'candidate/internal/pixel/intra4x4_dc_fill_arm64.go',r/'candidate/internal/pixel/intra4x4_dc_fill_other.go',r/'candidate/internal/vp8/dsp/intra4x4_other.go']
subprocess.run(['/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/gofmt','-w']+[str(p)for p in files],check=True)

from pathlib import Path
import subprocess,os,json,hashlib
r=Path('/private/tmp/govpx-arm-fused-dc4');srcs={'parent':r/'parent','candidate':r/'candidate','old691':Path('/private/tmp/govpx-arm-fused-dc-fresh/old691')};e=os.environ.copy();e.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-dc4-fresh',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go');records=[]
for v,src in srcs.items():
 for name,args in [('dsp-build',['test','-pgo=off','-c','./internal/vp8/dsp','-o',str(r/(v+'-fresh-dsp.test'))]),('whole-build',['build','-pgo=off','-o',str(r/(v+'-whole-bench')),'./cmd/govpx-bench'])]:
  cmd=['/Users/thesyncim/GolandProjects/govpx/scripts/go.sh','-C',str(src)]+args
  with(r/'evidence'/f'{v}-fresh-{name}.log').open('w')as f:run=subprocess.run(cmd,cwd='/Users/thesyncim/GolandProjects/govpx',env=e,stdout=f,stderr=subprocess.STDOUT)
  records.append({'variant':v,'name':name,'command':cmd,'exit':run.returncode});(r/'evidence/fresh-build.json').write_text(json.dumps(records,indent=2)+'\n');assert run.returncode==0;print(v,name,'PASS',flush=True)
 e1=e.copy();e1['GOMAXPROCS']='1';cmd=[str(r/(v+'-fresh-dsp.test')),'-test.run=^$','-test.bench=^BenchmarkIntraDCFill(Exact|Supplement)$','-test.benchtime=1x','-test.cpu=1','-test.count=1','-test.benchmem']
 with(r/'evidence'/f'{v}-fresh27-one-shot.log').open('w')as f:run=subprocess.run(cmd,env=e1,stdout=f,stderr=subprocess.STDOUT)
 assert run.returncode==0;records.append({'variant':v,'name':'27-public-one-shot','command':cmd,'exit':run.returncode});(r/'evidence/fresh-build.json').write_text(json.dumps(records,indent=2)+'\n');print(v,'all27one-shotPASS',flush=True)
(r/'evidence/fresh-binary-hashes.json').write_text(json.dumps({v:{name:{'path':str(r/(v+suffix)),'size':(r/(v+suffix)).stat().st_size,'sha256':hashlib.sha256((r/(v+suffix)).read_bytes()).hexdigest()}for name,suffix in [('DSP','-fresh-dsp.test'),('CLI','-whole-bench')]}for v in srcs},indent=2)+'\n');print('FRESH BUILDS/ORACLES COMPLETE',flush=True)

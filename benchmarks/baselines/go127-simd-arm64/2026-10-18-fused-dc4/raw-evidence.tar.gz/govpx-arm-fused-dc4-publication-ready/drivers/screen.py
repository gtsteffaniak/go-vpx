from pathlib import Path
import subprocess,os,time,json,hashlib
r=Path('/private/tmp/govpx-arm-fused-dc4');out=r/'screen';out.mkdir();bins={'parent':r/'parent-dsp.test','candidate':r/'candidate-dsp.test','old691':Path('/private/tmp/govpx-arm-fused-dc-fresh/old691-dsp.test')};(r/'evidence/screen-binaries.json').write_text(json.dumps({v:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for v,p in bins.items()},indent=2)+'\n');e=os.environ.copy();e.update(GOMAXPROCS='1');records=[]
for rnd,order in enumerate([['parent','candidate','old691'],['candidate','old691','parent'],['old691','parent','candidate']],1):
 for v in order:
  cmd=[str(bins[v]),'-test.run=^$','-test.bench=^BenchmarkIntraDCFill(Exact|Supplement)$','-test.benchtime=75ms','-test.cpu=1','-test.count=1','-test.benchmem'];start=time.time()
  with(out/f'r{rnd}-{v}.log').open('w')as f:run=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT)
  records.append({'round':rnd,'variant':v,'command':cmd,'start':start,'end':time.time(),'exit':run.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert run.returncode==0
 print('round',rnd,'complete',flush=True)
print('N4 SCREEN END',flush=True)

from pathlib import Path
import subprocess,os,json,time
r=Path('/private/tmp/govpx-arm-fused-dc4');out=r/'profiles600';out.mkdir();e=os.environ.copy();e.update(GOMAXPROCS='1');records=[]
for v in ['parent','candidate','old691']:
 cmd=[str(r/(v+'-whole-bench')),'-codec=vp8','-width=1280','-height=720','-frames=600','-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8','-threads=1','-encode-only','-auto-libvpx=false','-format=json','-cpuprofile='+str(out/(v+'.pgo'))];start=time.time()
 with(out/(v+'.json')).open('w')as f,(out/(v+'.stderr')).open('w')as err:run=subprocess.run(cmd,env=e,stdout=f,stderr=err)
 records.append({'variant':v,'command':cmd,'start':start,'end':time.time(),'exit':run.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert run.returncode==0;print(v,'600profilePASS',flush=True)
ref=json.loads((out/'parent.json').read_text());excluded={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'};keys=sorted(set(ref)-excluded);assert len(keys)==22
for v in ['parent','candidate','old691']:
 j=json.loads((out/(v+'.json')).read_text());assert all(j[k]==ref[k]for k in keys),v;assert j['allocs_per_frame']==0,v
(out/'parity.json').write_text(json.dumps({'all22_semantics_match':True,'all_allocations_zero':True,'semantic_field_names':keys,'scope':'Untimed diagnostic profiles only; no comparison with whole timing samples.'},indent=2)+'\n')
print('PROFILE600 END: all3 JSONs22semantic+zeroalloc equality',flush=True)

from pathlib import Path
import os,subprocess,json,time
r=Path('/private/tmp/govpx-arm-fused-dc4');out=r/'fresh-dsp';out.mkdir();e=os.environ.copy();e.update(GOMAXPROCS='1');records=[]
orders=[['parent','candidate','old691'],['candidate','old691','parent'],['old691','parent','candidate'],['old691','candidate','parent'],['candidate','parent','old691'],['parent','old691','candidate']]
for rnd,order in enumerate(orders,1):
 for v in order:
  cmd=[str(r/(v+'-fresh-dsp.test')),'-test.run=^$','-test.bench=^BenchmarkIntraDCFill(Exact|Supplement)$','-test.benchtime=100ms','-test.cpu=1','-test.count=1','-test.benchmem'];start=time.time()
  with(out/f'r{rnd}-{v}.log').open('w')as f:run=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT)
  records.append({'round':rnd,'variant':v,'command':cmd,'start':start,'end':time.time(),'exit':run.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert run.returncode==0
 print('round',rnd,'complete',flush=True)
print('FRESH27 END',flush=True)

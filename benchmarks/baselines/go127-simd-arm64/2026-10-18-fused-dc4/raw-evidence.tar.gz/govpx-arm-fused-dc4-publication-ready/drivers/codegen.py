from pathlib import Path
import subprocess,re,json,hashlib,os
r=Path('/private/tmp/govpx-arm-fused-dc4');norm={};summaries={};syms=['internal/vp8/dsp.Intra4x4DCPredict','internal/vp8/dsp.intra4x4DCPredict','internal/vp8/dsp.intraDCPredict8x8','internal/vp8/dsp.intraDCPredict16x16','internal/vp8/dsp.intraDCGo','internal/vp8/dsp.BenchmarkIntraDCFillExact.func1','internal/vp8/dsp.BenchmarkIntraDCFillSupplement.func1','internal/pixel.IntraDCFill','internal/pixel.Intra4x4DCFill']
for arch in ['arm64','amd64']:
 for v in ['parent','candidate']:
  prefix='_'if arch=='arm64'else'';binary=r/(v+('-amd64'if arch=='amd64'else'')+'-dsp.test');cmd=['xcrun','llvm-objdump','--disassemble','--demangle','--disassemble-symbols='+','.join(prefix+'github.com/thesyncim/govpx/'+s for s in syms),str(binary)];run=subprocess.run(cmd,capture_output=True,text=True);assert run.returncode==0;(r/'evidence'/f'{arch}-{v}-llvm.txt').write_text(run.stdout+run.stderr);blocks=re.split(r'^[0-9a-f]+ <'+prefix+r'github.com/thesyncim/govpx/([^>]+)>:\n',run.stdout,flags=re.M);norm[arch,v]={};summaries[arch+':'+v]={}
  for i in range(1,len(blocks),2):
   s,body=blocks[i:i+2];pat=r'^\s*[0-9a-f]+:\s+(?:[0-9a-f]{2}\s+)+(.+)$'if arch=='amd64'else r'^[0-9a-f]+:\s+[0-9a-f]+\s+([^\n]+)';ins=re.findall(pat,body,re.M);ins=[re.sub(r'0x[0-9a-fA-F]+','ADDR',x)for x in ins];norm[arch,v][s]=ins;summaries[arch+':'+v][s]={'instructions':len(ins),'calls':[x for x in ins if re.match('bl\s',x)],'reduce':[x for x in ins if 'addv'in x],'vector_stack_stores':[x for x in ins if re.match(r'(str|stur)\s+q',x)and'[sp'in x]}
proof={}
for arch in ['arm64','amd64']:
 wanted=syms[:1]+syms[4:7]if arch=='amd64'else syms[2:5]+[syms[7]]
 for s in wanted:
  a,b=norm[arch,'parent'][s],norm[arch,'candidate'][s];assert a==b,(arch,s,len(a),len(b),[(i,x,y)for i,(x,y)in enumerate(zip(a,b))if x!=y][:5]);proof[arch+':'+s]={'identical':True,'instructions':len(a),'normalized_sha256':hashlib.sha256('\n'.join(a).encode()).hexdigest()}
for f in ['internal/pixel/intra_dc_fill_arm64.go','internal/pixel/intra_dc_fill_other.go','internal/vp8/dsp/intra_dispatch_other.go']:
 a,b=(r/'parent'/f).read_bytes(),(r/'candidate'/f).read_bytes();assert a==b;proof['D8source:'+f]={'identical':True,'sha256':hashlib.sha256(a).hexdigest()}
(r/'evidence/codegen-proof.json').write_text(json.dumps(proof,indent=2)+'\n');(r/'evidence/codegen-summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
e=os.environ.copy();e['GOMAXPROCS']='1';records=[]
for v in ['parent','candidate']:
 cmd=[str(r/(v+'-dsp.test')),'-test.run=^$','-test.bench=^BenchmarkIntraDCFill(Exact|Supplement)$','-test.benchtime=1x','-test.cpu=1','-test.count=1','-test.benchmem']
 with(r/'evidence'/f'{v}-27-public-oneshot.log').open('w')as f:run=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT)
 assert run.returncode==0;records.append({'variant':v,'command':cmd,'exit':run.returncode})
(r/'evidence/oneshot-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(summaries['arm64:candidate'],indent=2));print('AMD n4+allfixtures unchanged; ARM D8+generic unchanged; all27 one-shot oraclesPASS')

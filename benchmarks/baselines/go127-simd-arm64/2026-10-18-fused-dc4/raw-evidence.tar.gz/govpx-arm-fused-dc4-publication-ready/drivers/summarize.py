from pathlib import Path
import re,json,statistics
r=Path('/private/tmp/govpx-arm-fused-dc4');groups={};pairs={};samples=[];variants=['parent','candidate','old691']
for p in sorted((r/'screen').glob('r*-*.log')):
 rnd=int(p.stem.split('-')[0][1:]);v=p.stem.split('-',1)[1];s=p.read_text();assert re.search(r'^PASS$',s,re.M),p
 rows=re.findall(r'^(Benchmark\S+)\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',s,re.M);assert len(rows)==27,(p,len(rows))
 for case,it,ns,byte,alloc in rows:
  assert byte==alloc=='0'and float(ns)>0;assert(v,case,rnd)not in pairs;pairs[v,case,rnd]=float(ns);groups.setdefault((v,case),[]).append(float(ns));samples.append({'round':rnd,'variant':v,'case':case,'ns':float(ns),'iterations':int(it),'B/op':0,'allocs/op':0,'log':p.name})
assert len(samples)==243
out=[]
for case in sorted({s['case']for s in samples}):
 med={v:statistics.median(groups[v,case])for v in variants};pr=[pairs['parent',case,i]/pairs['candidate',case,i]for i in range(1,4)];orr=[pairs['old691',case,i]/pairs['candidate',case,i]for i in range(1,4)];x={'case':case,'medians_ns':med,'parent_over_candidate':med['parent']/med['candidate'],'old_over_candidate':med['old691']/med['candidate'],'all3paired_parent_ratios':pr,'all3paired_old_ratios':orr};out.append(x)
 print(case.split('/',1)[1],f"D8={med['parent']:.4f} new={med['candidate']:.4f} old={med['old691']:.4f};D8/new={x['parent_over_candidate']:.4f}[{min(pr):.4f}..{max(pr):.4f}];old/new={x['old_over_candidate']:.4f}[{min(orr):.4f}..{max(orr):.4f}]")
(r/'screen/summary.json').write_text(json.dumps({'hardware':'Apple M4 Max','SDK':'officialGo1.27.2SIMD','PGO':'off','GOMAXPROCS':1,'benchtime':'75ms','rounds':3,'orders':[['parent','candidate','old691'],['candidate','old691','parent'],['old691','parent','candidate']],'cases':out,'samples':samples,'all_zero_alloc':True,'scope':'Provisional n4 screen against strongest D8 winner; not fresh acceptance.'},indent=2)+'\n')

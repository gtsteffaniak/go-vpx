from pathlib import Path
import shutil,hashlib,json,tarfile
r=Path('/private/tmp/govpx-arm-fused-dc4-ready');r.mkdir();src=Path('/private/tmp/govpx-arm-fused-dc4');failed=Path('/private/tmp/govpx-arm-fused-dc4-inline');d8=Path('/private/tmp/govpx-arm-fused-dc-ready');old=Path('/private/tmp/govpx-arm-fused-dc-fresh/old691')
for d in ['drivers','evidence','screen','fresh-dsp','fresh-whole','profiles600']:shutil.copytree(src/d,r/d)
for p in src.glob('*-dsp.test'):
 q=r/'binaries'/p.name;q.parent.mkdir(exist_ok=True);shutil.copy2(p,q)
for p in src.glob('*-whole-bench'):shutil.copy2(p,r/'binaries'/p.name)
shutil.copytree(failed/'evidence',r/'failed-inline/evidence');p=failed/'candidate-dsp.test';q=r/'failed-inline/binaries'/p.name;q.parent.mkdir();shutil.copy2(p,q)
f='internal/pixel/intra4x4_dc_fill_arm64.go';q=r/'failed-inline/source'/f;q.parent.mkdir(parents=True);shutil.copy2(failed/'candidate'/f,q)
for p in [Path('/private/tmp/govpx-arm-fused-dc4-prepare.py'),Path('/private/tmp/govpx-arm-fused-dc4-inline-prepare.py')]:shutil.copy2(p,r/p.name)
proof={}
for v,base,previous in [('parent',src/'parent',d8/'source/candidate'),('candidate',src/'candidate',src/'parent'),('old691',old,d8/'source/old691')]:
 entries=[];deltas=[]
 for p in base.rglob('*'):
  if not p.is_file():continue
  if (p.suffix in ['.go','.s']and not p.name.endswith('_test.go'))or p.name in ['go.mod','go.sum']:
   f=str(p.relative_to(base));q=r/'source'/v/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);h=hashlib.sha256(p.read_bytes()).hexdigest();b=previous/f
   item={'path':f,'sha256':h}
   if not b.exists()or b.read_bytes()!=p.read_bytes():deltas.append(item)
   entries.append(item)
 proof[v]={'baseline_path':str(previous),'files':entries,'production_changes':deltas}
assert proof['parent']['production_changes']==[]
assert proof['old691']['production_changes']==[]
assert len(proof['candidate']['production_changes'])==3
(r/'source-locks.json').write_text(json.dumps(proof,indent=2)+'\n')
shutil.copy2(d8/'git-source-proof.json',r/'prior-git-source-proof.json')
(r/'PRIOR-D8-PACKAGE.json').write_text(json.dumps({'immutable_path':str(d8),'manifest_sha256':hashlib.sha256((d8/'MANIFEST.json').read_bytes()).hexdigest(),'baseline_role':'strongestfrozenD8winner, candidateproductionexact','previous_publication_archive':'/private/tmp/govpx-arm-fused-dc-publication-ready.tar.gz'},indent=2)+'\n')
overlay=['internal/pixel/intra4x4_dc_fill_arm64.go','internal/pixel/intra4x4_dc_fill_other.go','internal/vp8/dsp/intra4x4_other.go','internal/pixel/intra4x4_dc_fill_probe_test.go','internal/vp8/dsp/fused_dc4_probe_test.go']
for f in overlay:
 q=r/'overlay'/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src/'candidate'/f,q)
for v in ['parent','candidate','old691']:
 base=old if v=='old691'else src/v
 for f in ['internal/vp8/dsp/fill_exact_native_test.go','internal/vp8/dsp/fused_dc_supplement_test.go']:
  q=r/'source'/v/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/f,q)
 for f in ['internal/vp8/dsp/fused_dc4_probe_test.go','internal/pixel/intra4x4_dc_fill_probe_test.go']:
  if(base/f).exists():q=r/'source'/v/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/f,q)
s=json.loads((src/'fresh-dsp/summary.json').read_text());report='''# ARM4x4 DC fused sum/fill retention evidence

Strongest baseline is the exact frozen D8 winner in `/private/tmp/govpx-arm-fused-dc-ready` (source derived from PR44 `46b89f5ab4c6c469755323a61c77fe3a766b4081`, plus measured D8 overlay). This n4 candidate adds exactly3 production files: ARM helper, other-architecture false stub, and hook in existing4x4-only dispatch. It leaves all D8 production bytes unchanged. Baseline source exactness is proved against the immutable earlier package, with its Git source proof retained. Old actualNEON reference is `691cd0512c4829d9ee40d483205dd223f9eb028d`.

`overlay/` provides5 integration files:3 production and2 independent state/oracle tests. All27 public benchmark fixture bytes remain identical across current/baseline/old; they are retained under source/ for all3. The frozen prior D8 package, initial243sample n4 screen, failed inline attempt, and fresh acceptance samples remain separate.

Algorithm: guard Enabled, unsigned stride<2^30, complete4-row destination length and both4-byte reference lengths before any unsafe reads/stores. Exact uint32 reference loads occupy two packet lanes, widen8bytes to unsigned16, single reduction max2040, round(sum+4)>>3, broadcast and4 exact uint32 row stores. All references are consumed before first write, preserving destination/ref aliases and overlapping rows. Any decline returns to exact previous flow. Public above/left/destination index checks remain unchanged and in original order, preserving panic/partial-state behavior and capacity. Other-architecture stub folds away.

Correctness:2041 attainable sums×16align directpixel; full backing/alias/canaries/minimal windows/short+sparecap/clippedcap/extreme strides, independently short above/left and disabledstate; actual public frozen original prechecks+generic path as panic/partial-state oracle; race/checkptr2, purego,nosimd. Sixteen initial build/validation commands pass. New fresh all3 binaries rebuilt with officialGo1.27.2SIMD and PGOoff; all27 one-shot full-output/input/canary oracles pass. Optimized ARM helper37entries, no calls/vector spills, oneADDV. AMD n4/generic and both public closures normalized identical. ARM D8 helper/wrappers/generic and both public closures normalized identical too. All source and full LLVM proofs retained.

One authorized inline-wrapper attempt failed: exported guardwrappercost93>budget80, uncheckedworker96>80. It was stopped after compile, no timing run. Its source, build command, full compiler output, and binary are retained; initial37-entry measured source was never altered. No other n4 production variant.

Native fresh acceptance: M4Max, officialGo1.27.2, SIMD, PGOoff, GOMAXPROCS1,27 actual public B.Loop cases100ms ×6balancedpermutations×3variants=486samples, all0B/0alloc with output/input/canary oracles. Separate provisional3round75ms screen has243samples; never pooled.

Fresh n4 medians2.4694–2.5065×strongD8baseline; every18n4pairedratio>1.5 (2.3890–2.6886). OldNEON remains27.3–28.2%faster in these public n4 cases. All24 D8 controls retained, including8up-onlypackedmedian0.9568×baseline, with paired0.9181–1.0390. Equal source/codegen does not prove the cause of control timing variation.

|Public case|D8baseline ns|n4winner ns|oldNEON ns|baseline/new|old/new|
|---|---:|---:|---:|---:|---:|
'''
for x in s['cases']:
 m=x['medians_ns'];report+=f"|{x['case'].split('/',1)[1]}|{m['parent']:.4f}|{m['candidate']:.4f}|{m['old691']:.4f}|{x['parent_over_candidate']:.4f}×|{x['old_over_candidate']:.4f}×|\n"
report+='''
All6 paired ratios and every slower control are in fresh-dsp/summary.json, alongside all18rawlogs, orders, command timestamps and binary hashes.

Whole300-input VP8 realtime720p cpu8/30fps/2500kbps/1thread, sixbalanced3way runs: D8parent7.3279565ms, winner7.2998625ms, old6.7012025ms. Winner−0.383381%vsD8,4/6faster (paired+2.35241,−0.67308,−2.02767,+0.32316,−0.75795,−1.14069%). Winner+8.93362%slowerold,0/6faster (paired+5.55240,+9.05257,+9.86946,+9.67727,+8.64257,+7.75046%). All22 semantic fields and zeroalloc match across18JSONs. This is a retained2.5×component win; whole improvement is small/noisy and oldassembly gap remains open.

Separate600-input profiles for all3 use the exact same CLI binaries/options, outside timed pairs. Rawpgo, flat/cumulative top50, allcommands/JSON/stderr are retained. All22semantic and zeroalloc equality pass across3profileJSONs. These profiles are diagnostic only, not timing denominators. Binary blobs are private evidence; lean publication copy omits only executable blobs and retains their exact hashes/sizes/privatepaths. Full private package stays immutable.
'''
(r/'REPORT.md').write_text(report)
items=[{'path':str(p.relative_to(r)),'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(r.rglob('*'))if p.is_file()];(r/'MANIFEST.json').write_text(json.dumps(items,indent=2)+'\n');print(json.dumps({'ready':str(r),'files':len(items),'bytes':sum(x['size']for x in items),'manifest_sha256':hashlib.sha256((r/'MANIFEST.json').read_bytes()).hexdigest()},indent=2))

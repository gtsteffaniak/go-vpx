from pathlib import Path
import os,subprocess,json
r=Path('/private/tmp/govpx-arm-fused-dc4');root=Path('/Users/thesyncim/GolandProjects/govpx');e=os.environ.copy();e.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-dc4-profile-top',GOTOOLCHAIN='local',GOMAXPROCS='2');records=[]
for v in ['parent','candidate','old691']:
 for mode,flag in [('flat','-flat'),('cum','-cum')]:
  cmd=['/Users/thesyncim/.codex/bin/project-env','/usr/local/go/bin/go','tool','pprof','-top',flag,'-nodecount=50',str(r/(v+'-whole-bench')),str(r/'profiles600'/(v+'.pgo'))]
  with(r/'profiles600'/(v+'-top-'+mode+'.txt')).open('w')as f:run=subprocess.run(cmd,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
  records.append({'variant':v,'mode':mode,'command':cmd,'exit':run.returncode});assert run.returncode==0
(r/'profiles600/top-commands.json').write_text(json.dumps(records,indent=2)+'\n');print('ALL profile tops captured')

package common

// Ported from libvpx v1.16.0 vp8/common/quant_common.c and dequant setup
// logic in vp8/decoder/decodeframe.c.

var dcQLookup = [QIndexRange]int16{
	4, 5, 6, 7, 8, 9, 10, 10, 11, 12, 13, 14, 15, 16, 17,
	17, 18, 19, 20, 20, 21, 21, 22, 22, 23, 23, 24, 25, 25, 26,
	27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 37, 38, 39, 40,
	41, 42, 43, 44, 45, 46, 46, 47, 48, 49, 50, 51, 52, 53, 54,
	55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69,
	70, 71, 72, 73, 74, 75, 76, 76, 77, 78, 79, 80, 81, 82, 83,
	84, 85, 86, 87, 88, 89, 91, 93, 95, 96, 98, 100, 101, 102, 104,
	106, 108, 110, 112, 114, 116, 118, 122, 124, 126, 128, 130, 132, 134, 136,
	138, 140, 143, 145, 148, 151, 154, 157,
}

var acQLookup = [QIndexRange]int16{
	4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18,
	19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33,
	34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48,
	49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 60, 62, 64, 66, 68,
	70, 72, 74, 76, 78, 80, 82, 84, 86, 88, 90, 92, 94, 96, 98,
	100, 102, 104, 106, 108, 110, 112, 114, 116, 119, 122, 125, 128, 131, 134,
	137, 140, 143, 146, 149, 152, 155, 158, 161, 164, 167, 170, 173, 177, 181,
	185, 189, 193, 197, 201, 205, 209, 213, 217, 221, 225, 229, 234, 239, 245,
	249, 254, 259, 264, 269, 274, 279, 284,
}

const maxPublicQuantizer = 63

var publicQuantizerToQIndex = [maxPublicQuantizer + 1]int{
	0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 12, 13, 15, 17, 18, 19,
	20, 21, 23, 24, 25, 26, 27, 28, 29, 30, 31, 33, 35, 37, 39, 41,
	43, 45, 47, 49, 51, 53, 55, 57, 59, 61, 64, 67, 70, 73, 76, 79,
	82, 85, 88, 91, 94, 97, 100, 103, 106, 109, 112, 115, 118, 121, 124, 127,
}

type QuantDeltas struct {
	Y1DC int
	Y2DC int
	Y2AC int
	UVDC int
	UVAC int
}

type FrameDequantTables struct {
	Y1 [QIndexRange][2]int16
	Y2 [QIndexRange][2]int16
	UV [QIndexRange][2]int16
}

type MacroblockDequant struct {
	Y1   [16]int16
	Y1DC [16]int16
	Y2   [16]int16
	UV   [16]int16
}

func ClampQIndex(qIndex int) int {
	return min(max(qIndex, MinQ), MaxQ)
}

func PublicQuantizerToQIndex(q int) int {
	return publicQuantizerToQIndex[min(max(q, 0), maxPublicQuantizer)]
}

func QIndexToPublicQuantizer(qIndex int) int {
	for q, translated := range publicQuantizerToQIndex {
		if translated >= qIndex {
			return q
		}
	}
	return maxPublicQuantizer
}

func DCQuant(qIndex int, delta int) int {
	return int(dcQLookup[ClampQIndex(qIndex+delta)])
}

func DC2Quant(qIndex int, delta int) int {
	return int(dcQLookup[ClampQIndex(qIndex+delta)]) * 2
}

func DCUVQuant(qIndex int, delta int) int {
	return min(int(dcQLookup[ClampQIndex(qIndex+delta)]), 132)
}

func ACYQuant(qIndex int) int {
	return int(acQLookup[ClampQIndex(qIndex)])
}

func AC2Quant(qIndex int, delta int) int {
	v := (int(acQLookup[ClampQIndex(qIndex+delta)]) * 101581) >> 16
	if v < 8 {
		return 8
	}
	return v
}

func ACUVQuant(qIndex int, delta int) int {
	return int(acQLookup[ClampQIndex(qIndex+delta)])
}

func BuildFrameDequantTables(d QuantDeltas, out *FrameDequantTables) {
	for q := range QIndexRange {
		out.Y1[q][0] = int16(DCQuant(q, d.Y1DC))
		out.Y1[q][1] = int16(ACYQuant(q))
		out.Y2[q][0] = int16(DC2Quant(q, d.Y2DC))
		out.Y2[q][1] = int16(AC2Quant(q, d.Y2AC))
		out.UV[q][0] = int16(DCUVQuant(q, d.UVDC))
		out.UV[q][1] = int16(ACUVQuant(q, d.UVAC))
	}
}

func InitMacroblockDequant(t *FrameDequantTables, qIndex int, out *MacroblockDequant) {
	q := ClampQIndex(qIndex)

	out.Y1DC[0] = 1
	out.Y1[0] = t.Y1[q][0]
	out.Y2[0] = t.Y2[q][0]
	out.UV[0] = t.UV[q][0]

	y1AC := t.Y1[q][1]
	y2AC := t.Y2[q][1]
	uvAC := t.UV[q][1]
	for i := 1; i < 16; i++ {
		out.Y1DC[i] = y1AC
		out.Y1[i] = y1AC
		out.Y2[i] = y2AC
		out.UV[i] = uvAC
	}
}

//go:build goexperiment.simd && amd64 && !purego

package pixel

import "simd/archsimd"

func lfAbsByte(a, b archsimd.Uint8x16) archsimd.Uint8x16 { return a.Max(b).Sub(a.Min(b)) }

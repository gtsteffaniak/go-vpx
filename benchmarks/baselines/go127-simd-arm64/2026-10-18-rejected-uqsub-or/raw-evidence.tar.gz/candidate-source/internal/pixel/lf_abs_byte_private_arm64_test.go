//go:build goexperiment.simd && arm64 && !purego
package pixel
import("testing"; "simd/archsimd")
func TestLFAbsByteAllUnsignedPairs(t *testing.T){
 if !Enabled {t.Fatal("ARM SIMD backend not enabled")}
 for a:=0;a<256;a++{for b:=0;b<256;b+=16{
  var aa,bb,got [16]byte
  for i:=range 16 {aa[i]=byte(a);bb[i]=byte(b+i)}
  lfAbsByte(archsimd.LoadUint8x16Array(&aa),archsimd.LoadUint8x16Array(&bb)).StoreArray(&got)
  for i:=range 16 {want:=a-(b+i);if want<0{want=-want};if got[i]!=byte(want){t.Fatalf("%d,%d got%d want%d",a,b+i,got[i],want)}}
 }}
}

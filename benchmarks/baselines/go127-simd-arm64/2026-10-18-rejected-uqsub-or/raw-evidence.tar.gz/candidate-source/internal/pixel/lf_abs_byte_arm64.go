//go:build goexperiment.simd && arm64 && !purego

package pixel

import "simd/archsimd"

func lfAbsByte(a, b archsimd.Uint8x16) archsimd.Uint8x16 { return a.SubSaturated(b).Or(b.SubSaturated(a)) }

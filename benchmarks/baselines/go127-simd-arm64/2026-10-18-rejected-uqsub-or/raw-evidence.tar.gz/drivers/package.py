from pathlib import Path
import json,hashlib,re,shutil
r=Path('/private/tmp/govpx-arm-lf-uqsub-or');ready=Path('/private/tmp/govpx-arm-lf-uqsub-or-ready');sdk=Path('/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64')
shutil.copyfile(__file__,ready/'drivers/package.py')
env={'cpu':re.search(r'^cpu: (.+)$',(r/'screen/r1-parent.txt').read_text(),re.M).group(1),'cpu_provenance':'Go benchmark runtime header, all six raw logs retained','compiler':(sdk/'VERSION').read_text().strip(),'GOEXPERIMENT':'simd','GOFLAGS':'-p=2','GOMAXPROCS':1,'GOVPX_REQUIRE_SIMD':1,'PGO':'off','CODEX_AGENT_ID':'govpx-ci-lf-uqsub-or','GOCACHE':'/private/tmp/codex-projects/99feb44aac13f74a/go-build','binary_sha256':{v:hashlib.sha256((r/(v+'-decoder.test')).read_bytes()).hexdigest()for v in ['parent','candidate']},'source_sha256':{str(p.relative_to(ready)):hashlib.sha256(p.read_bytes()).hexdigest()for v in ['parent-source','candidate-source']for p in (ready/v).rglob('*.go')}}
(ready/'evidence/environment.json').write_text(json.dumps(env,indent=2)+'\n')
s=json.loads((r/'screen-summary.json').read_text())
report='''# ARM unsigned saturated-absolute difference: rejected after screen

Parent `768f2fc2aba7bbd82981494473cbadc026a95570` (PR43).
Stop/archive: no useful public component gain; no root, README or PR changes.
No fresh-six/whole-codec experiment was warranted.

The sole candidate changes ARM lfAbsByte from unsigned Max−Min to
`a.SubSaturated(b).Or(b.SubSaturated(a))`. An architecture helper split keeps
AMD's original expression. Loads/stores, thresholds, CPU dispatch, aliases,
geometry and fallback contracts remain unchanged. Scoped prior report/patch
review found the rejected clamped signed-saturating-abs experiment, not this
exact unsigned UQSUB/OR expression. This is not a repeat of signed/clamped math.

Pinned SDK lowers unsigned SubSaturatedUint8x16 directly to UQSUB and OR to ORR.
Actual optimized LLVM confirms2UQSUB+OR replacing Max+Min+Sub. Both use3ops;
totals416/364/698 instructions in generic/horizontal/vertical bodies remain
unchanged. Calls unchanged; vector stack stores1/0/19 unchanged. No lower
instruction-count, latency or execution-port speedup is claimed.

Both variants passed all65,536 unsigned byte pairs, live ARM backend detection,
five-package short suites(pixel,VP8 DSP/encoder/decoder,VP9 DSP), and four-package
loop-filter race/checkptr2(pixel,VP8 DSP/decoder,VP9 DSP). Existing fused-filter
oracle covers7,200 geometry/alignment/trial/threshold combinations; aliases,
minimal windows, bounds and sentinel-preserving writes are covered as well.
Complete commands and logs are in evidence; no thresholds/assertions changed.

Native Apple M4 Max; official Go1.27.2; GOEXPERIMENT=simd; PGO off; GOMAXPROCS=1.
Three75ms alternating AB/BA/AB rounds of the actual public picker fixture, with
source window restored each iteration and complete output matched against four
separate public edge operations. All60 samples are0B/op/0allocs. All30 paired
ratios/slower controls retained, including first-parent-flat60.58ns outlier.

| Public case | Parent ns | Candidate ns | Parent/candidate | Candidate time change |
|---|---:|---:|---:|---:|
'''
for x in s['results']:report+=f"| {x['case'].split('Native/')[1]} | {x['parent_ns']:.2f} | {x['candidate_ns']:.2f} | {x['speedup']:.5f}× | {x['candidate_time_change_percent']:+.3f}% |\n"
report+='''
Median ratios0.9822–1.0067×: candidate times range0.67%faster to1.81%slower.
Mixed-texture controls regress at both pitches. These near-noise/mixed changes
do not establish useful improvement. No x64 or whole-codec claim. Host released;
no further Go/build/test/timing jobs were started after the screen.

Factual correction to the earlier conversational dual-copy feasibility note:
pinned internal/abi/abi_arm64.go has IntArgRegs=16, FloatArgRegs=16; twelve scalar
argument words do not exceed ARM Go's integer argument-register count. The
incorrect argument is withdrawn. No private dual-copy report file existed and
no production decision adopted it. That caller's actual rejection stands on
intervening UV copies/spatial mutation and different Y-copy sources.

Exact source/helper/test/public fixture, full LLVM, correctness/build logs,
raw6logs/commands, all samples/ratios and environment/source/binary hashes are
preserved. Binaries/full snapshots excluded. Drivers retain original private
experiment paths. SHA256SUMS covers all delivered members except itself.
'''
(ready/'REPORT.md').write_text(report)
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ready))+'\n'for p in sorted(ready.rglob('*'))if p.is_file()and p.name!='SHA256SUMS');(ready/'SHA256SUMS').write_text(manifest)
for line in manifest.splitlines():
 sha,p=line.split('  ',1);assert hashlib.sha256((ready/p).read_bytes()).hexdigest()==sha
assert len(s['samples'])==60 and len(s['results'])==10 and all(x['B/op']==x['allocs/op']==0 for x in s['samples'])
assert len(json.loads((ready/'evidence/validation.json').read_text()))==10
print('FILES',len(manifest.splitlines()),'BYTES',sum(p.stat().st_size for p in ready.rglob('*')if p.is_file()),'MANIFEST_SHA256',hashlib.sha256(manifest.encode()).hexdigest())

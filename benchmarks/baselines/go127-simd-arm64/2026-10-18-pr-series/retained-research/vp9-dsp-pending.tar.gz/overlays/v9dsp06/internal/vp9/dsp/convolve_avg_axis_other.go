package dsp

import (
	"github.com/thesyncim/govpx/internal/pixel"
	"github.com/thesyncim/govpx/internal/vp9/tables"
	"unsafe"
)

func vpxConvolve8AvgHoriz(src []byte, srcStride int, dst []byte, dstStride int,
	filter *[tables.SubpelShifts][tables.SubpelTaps]int16,
	x0Q4, xStepQ4, y0Q4, yStepQ4, w, h, srcOffset int,
	scratch *Convolve8Scratch,
) {
	_ = y0Q4
	_ = yStepQ4
	base := srcOffset - 3 + (x0Q4 >> 4)
	if xStepQ4 == 16 && convolveAvgSIMDWindow(src, srcStride, dst, dstStride, w, h, base, 1) {
		temp, b := convolve8AvgTempForScratch(scratch)
		pixel.Filter(src[base:], srcStride, temp, 64, w, h, 1, filter[x0Q4&15][:])
		pixel.Average(temp, 64, dst, dstStride, w, h)
		convolve8AvgTempPut(b)
		return
	}
	convolveAvgHoriz(src, srcStride, dst, dstStride, filter, x0Q4, xStepQ4,
		w, h, srcOffset)
}

func vpxConvolve8AvgVert(src []byte, srcStride int, dst []byte, dstStride int,
	filter *[tables.SubpelShifts][tables.SubpelTaps]int16,
	x0Q4, xStepQ4, y0Q4, yStepQ4, w, h, srcOffset int,
	scratch *Convolve8Scratch,
) {
	_ = x0Q4
	_ = xStepQ4
	base := srcOffset + (y0Q4>>4)*srcStride - 3*srcStride
	if yStepQ4 == 16 && srcStride <= len(src)/7 && convolveAvgSIMDWindow(src, srcStride, dst, dstStride, w, h, base, srcStride) {
		temp, b := convolve8AvgTempForScratch(scratch)
		pixel.Filter(src[base:], srcStride, temp, 64, w, h, srcStride, filter[y0Q4&15][:])
		pixel.Average(temp, 64, dst, dstStride, w, h)
		convolve8AvgTempPut(b)
		return
	}
	convolveAvgVert(src, srcStride, dst, dstStride, filter, y0Q4, yStepQ4,
		w, h, srcOffset)
}

func convolveAvgSIMDWindow(src []byte, ss int, dst []byte, ds, w, h, off, step int) bool {
	if !pixel.Enabled || w < 4 || w > 64 || w%4 != 0 || h <= 0 || h > 64 || ss < w || ds < w || off < 0 || off > len(src) {
		return false
	}
	extra := 7 * step
	if extra < 0 || extra > len(src)-off || w > len(src)-off-extra || (h-1) > (len(src)-off-extra-w)/ss || w > len(dst) || (h-1) > (len(dst)-w)/ds {
		return false
	}
	sn, dn := (h-1)*ss+w+extra, (h-1)*ds+w
	sp, dp := uintptr(unsafe.Pointer(unsafe.SliceData(src[off:]))), uintptr(unsafe.Pointer(unsafe.SliceData(dst)))
	return (sp <= dp && dp-sp >= uintptr(sn)) || (dp < sp && sp-dp >= uintptr(dn))
}

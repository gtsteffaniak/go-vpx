package dsp

import (
	"github.com/thesyncim/govpx/internal/vp9/tables"
	"unsafe"
)

// Shared convolution entry points select Go SIMD for supported filter
// shapes and retain scalar handling of scaled coordinates.

// VpxConvolve8Horiz applies the horizontal 8-tap subpel filter.
// Mirrors vpx_convolve8_horiz_c.
func VpxConvolve8Horiz(src []byte, srcStride int, dst []byte, dstStride int,
	filter *[tables.SubpelShifts][tables.SubpelTaps]int16,
	x0Q4, xStepQ4, y0Q4, yStepQ4, w, h, srcOffset int,
) {
	_ = y0Q4
	_ = yStepQ4
	convolveHoriz(src, srcStride, dst, dstStride, filter, x0Q4, xStepQ4, w, h, srcOffset)
}

// VpxConvolve8Vert mirrors vpx_convolve8_vert_c.
func VpxConvolve8Vert(src []byte, srcStride int, dst []byte, dstStride int,
	filter *[tables.SubpelShifts][tables.SubpelTaps]int16,
	x0Q4, xStepQ4, y0Q4, yStepQ4, w, h, srcOffset int,
) {
	_ = x0Q4
	_ = xStepQ4
	convolveVert(src, srcStride, dst, dstStride, filter, y0Q4, yStepQ4, w, h, srcOffset)
}

// VpxConvolve8 mirrors vpx_convolve8_c — full 2-pass subpel filter
// (horizontal then vertical) with a scratch buffer matching libvpx's
// 64×135 stride-64 intermediate layout.
func VpxConvolve8(src []byte, srcStride int, dst []byte, dstStride int,
	filter *[tables.SubpelShifts][tables.SubpelTaps]int16,
	x0Q4, xStepQ4, y0Q4, yStepQ4, w, h, srcOffset int,
) {
	VpxConvolve8WithScratch(src, srcStride, dst, dstStride, filter,
		x0Q4, xStepQ4, y0Q4, yStepQ4, w, h, srcOffset, nil)
}

// VpxConvolve8WithScratch is VpxConvolve8 with optional caller-owned scratch.
func VpxConvolve8WithScratch(src []byte, srcStride int, dst []byte, dstStride int,
	filter *[tables.SubpelShifts][tables.SubpelTaps]int16,
	x0Q4, xStepQ4, y0Q4, yStepQ4, w, h, srcOffset int,
	scratch *Convolve8Scratch,
) {
	if xStepQ4 == 16 && yStepQ4 == 16 && x0Q4 >= 0 && x0Q4 < 16 && y0Q4 >= 0 && y0Q4 < 16 && convolveIdentityWindow(src, srcStride, dst, dstStride, w, h, srcOffset) {
		if convolveIdentityFilter(&filter[x0Q4]) {
			convolveVert(src, srcStride, dst, dstStride, filter, y0Q4, 16, w, h, srcOffset)
			return
		}
		if convolveIdentityFilter(&filter[y0Q4]) {
			convolveHoriz(src, srcStride, dst, dstStride, filter, x0Q4, 16, w, h, srcOffset)
			return
		}
	}
	temp, tempBuf := convolve8TempForScratch(scratch)
	intermediateHeight := (((h-1)*yStepQ4 + y0Q4) >> tables.SubpelBits) + tables.SubpelTaps
	horizSrcOffset := srcOffset - srcStride*(tables.SubpelTaps/2-1)
	convolveHoriz(src, srcStride, temp, 64, filter, x0Q4, xStepQ4, w, intermediateHeight, horizSrcOffset)
	vertSrcOffset := 64 * (tables.SubpelTaps/2 - 1)
	convolveVert(temp, 64, dst, dstStride, filter, y0Q4, yStepQ4, w, h, vertSrcOffset)
	if tempBuf != nil {
		convolve8TempPut(tempBuf)
	}
}

// VpxConvolve8Avg mirrors vpx_convolve8_avg_c.
func VpxConvolve8Avg(src []byte, srcStride int, dst []byte, dstStride int,
	filter *[tables.SubpelShifts][tables.SubpelTaps]int16,
	x0Q4, xStepQ4, y0Q4, yStepQ4, w, h, srcOffset int,
) {
	VpxConvolve8AvgWithScratch(src, srcStride, dst, dstStride, filter,
		x0Q4, xStepQ4, y0Q4, yStepQ4, w, h, srcOffset, nil)
}

// VpxConvolve8AvgWithScratch is VpxConvolve8Avg with optional caller-owned scratch.
func VpxConvolve8AvgWithScratch(src []byte, srcStride int, dst []byte, dstStride int,
	filter *[tables.SubpelShifts][tables.SubpelTaps]int16,
	x0Q4, xStepQ4, y0Q4, yStepQ4, w, h, srcOffset int,
	scratch *Convolve8Scratch,
) {
	temp, tempBuf := convolve8AvgTempForScratch(scratch)
	VpxConvolve8WithScratch(src, srcStride, temp, 64, filter,
		x0Q4, xStepQ4, y0Q4, yStepQ4, w, h, srcOffset, scratch)
	VpxConvolveAvg(temp, 64, dst, dstStride, w, h, 0)
	if tempBuf != nil {
		convolve8AvgTempPut(tempBuf)
	}
}

func convolveIdentityFilter(t *[8]int16) bool {
	return t[0] == 0 && t[1] == 0 && t[2] == 0 && t[3] == 128 && t[4] == 0 && t[5] == 0 && t[6] == 0 && t[7] == 0
}
func convolveIdentityWindow(src []byte, ss int, dst []byte, ds, w, h, off int) bool {
	if w < 4 || w > 64 || w%4 != 0 || h <= 0 || h > 64 || ss < w+7 || ds < w || ss > len(src)/3 || off < 3*ss+3 || off > len(src) || w > len(dst) || h-1 > (len(dst)-w)/ds {
		return false
	}
	start := off - 3*ss - 3
	if w+7 > len(src)-start || h+6 > (len(src)-start-w-7)/ss {
		return false
	}
	sn, dn := (h+6)*ss+w+7, (h-1)*ds+w
	sp, dp := uintptr(unsafe.Pointer(unsafe.SliceData(src[start:]))), uintptr(unsafe.Pointer(unsafe.SliceData(dst)))
	return (sp <= dp && dp-sp >= uintptr(sn)) || (dp < sp && sp-dp >= uintptr(dn))
}

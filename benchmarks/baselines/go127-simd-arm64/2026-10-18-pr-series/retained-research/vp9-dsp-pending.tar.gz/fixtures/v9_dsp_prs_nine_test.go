package dsp

import (
	"bytes"
	"fmt"
	"github.com/thesyncim/govpx/internal/pixel"
	"reflect"
	"testing"
)

var v9DSPSink uint64

func v9DSPBytes(n int) []byte {
	p := make([]byte, n)
	var v uint32 = 4711
	for i := range p {
		v = v*1664525 + 1013904223
		p[i] = byte(v >> 24)
	}
	return p
}
func TestV9DSPAvg(t *testing.T) {
	for _, s := range []int{8, 13, 32} {
		for off := 0; off < 5; off++ {
			p := v9DSPBytes(off + 7*s + 8)
			var want int
			for y := range 8 {
				for x := range 8 {
					want += int(p[off+y*s+x])
				}
			}
			if got := VpxAvg8x8(p, off, s); got != (want+32)>>6 {
				t.Fatalf("%d", got)
			}
		}
	}
}
func TestV9DSPCopy(t *testing.T) {
	for _, w := range []int{4, 8, 16, 32, 64} {
		for _, pad := range []int{0, 3} {
			for _, alias := range []int{-9, -1, 0, 1, 9, 10000} {
				s := w + pad
				n := s*w + 64
				a := v9DSPBytes(2*n + 100)
				b := bytes.Clone(a)
				so, do := 32, 32+alias
				if alias == 10000 {
					do = n + 32
				}
				if do < 0 {
					continue
				}
				for y := range w {
					copy(b[do+y*s:do+y*s+w], b[so+y*s:so+y*s+w])
				}
				VpxConvolveCopy(a, s, a[do:], s, w, w, so)
				if !bytes.Equal(a, b) {
					t.Fatalf("copy w%d pad%d alias%d", w, pad, alias)
				}
			}
		}
	}
}
func TestV9DSPDC(t *testing.T) {
	for _, n := range []int{4, 8, 16, 32} {
		for _, v := range []int16{-32768, -64, -1, 0, 1, 2, 31, 64, 32767} {
			p := v9DSPBytes(n * (n + 7))
			want := bytes.Clone(p)
			q := []int16{v}
			z := int16(dctConstRoundShift(int64(v) * cospi16_64))
			z = int16(dctConstRoundShift(int64(z) * cospi16_64))
			shift := uint(6)
			if n == 4 {
				shift = 4
			} else if n == 8 {
				shift = 5
			}
			pixel.AddConstant(want, n+7, want, n+7, n, n, int(roundPowerOfTwo(int32(z), shift)))
			switch n {
			case 4:
				Idct4x4_1Add(q, p, n+7)
			case 8:
				Idct8x8_1Add(q, p, n+7)
			case 16:
				Idct16x16_1Add(q, p, n+7)
			case 32:
				Idct32x32_1Add(q, p, n+7)
			}
			if !bytes.Equal(p, want) {
				t.Fatalf("dc%d v%d", n, v)
			}
		}
	}
}
func TestV9DSPResize(t *testing.T) {
	for _, dims := range [][4]int{{3, 2, 1, 1}, {12, 9, 7, 5}, {64, 48, 41, 29}, {96, 64, 64, 43}, {64, 48, 64, 48}, {192, 108, 64, 36}} {
		sw, sh, dw, dh := dims[0], dims[1], dims[2], dims[3]
		src := v9DSPBytes((sw + 7) * sh)
		a := v9DSPBytes((dw + 5) * dh)
		b := bytes.Clone(a)
		sa, sb := make([]int32, dw*sh), make([]int32, dw*sh)
		PolyphaseFilterPlane(a, dw+5, dw, dh, src, sw+7, sw, sh, sa)
		v9DSPResizeReference(b, dw+5, dw, dh, src, sw+7, sw, sh, sb)
		if !bytes.Equal(a, b) || !reflect.DeepEqual(sa, sb) {
			t.Fatalf("resize%v", dims)
		}
	}
}

func v9DSPFilters() [16][8]int16 {
	var f [16][8]int16
	for phase := range 16 {
		f[phase][3] = int16(128 - 8*phase)
		f[phase][4] = int16(8 * phase)
	}
	f[5] = [8]int16{-1, 3, -7, 108, 36, -14, 4, -1}
	return f
}
func TestV9DSPAxis(t *testing.T) {
	f := v9DSPFilters()
	for _, w := range []int{4, 8, 16, 32, 64} {
		for _, axis := range []int{0, 1} {
			for _, phase := range []int{0, 1, 5, 8, 15} {
				for _, alias := range []bool{false, true} {
					s := w + 17
					n := s * (w + 10)
					src := v9DSPBytes(n)
					a := v9DSPBytes(n)
					b := bytes.Clone(a)
					bs := bytes.Clone(src)
					off := 3*s + 4
					if alias {
						src = a
						bs = b
					}
					if axis == 0 {
						convolveAvgHoriz(bs, s, b, s, &f, phase, 16, w, w, off)
						VpxConvolve8AvgHoriz(src, s, a, s, &f, phase, 16, 0, 16, w, w, off)
					} else {
						convolveAvgVert(bs, s, b, s, &f, phase, 16, w, w, off)
						VpxConvolve8AvgVert(src, s, a, s, &f, 0, 16, phase, 16, w, w, off)
					}
					if !bytes.Equal(a, b) {
						t.Fatalf("axis w%d a%d p%d alias%v", w, axis, phase, alias)
					}
				}
			}
		}
	}
}
func v9DSPConvolveReference(src []byte, ss int, dst []byte, ds int, f *[16][8]int16, x, y, w, h, off int) {
	var tmp [64 * 135]byte
	convolveHoriz(src, ss, tmp[:], 64, f, x, 16, w, h+7, off-3*ss)
	convolveVert(tmp[:], 64, dst, ds, f, y, 16, w, h, 3*64)
}
func TestV9DSPIdentity(t *testing.T) {
	f := v9DSPFilters()
	for _, w := range []int{4, 8, 16, 32, 64} {
		for _, phase := range [][2]int{{0, 0}, {0, 5}, {5, 0}, {5, 8}} {
			for _, alias := range []bool{false, true} {
				s := w + 17
				n := s * (w + 10)
				src := v9DSPBytes(n)
				a := v9DSPBytes(n)
				b := bytes.Clone(a)
				bs := bytes.Clone(src)
				off := 3*s + 4
				if alias {
					src = a
					bs = b
				}
				v9DSPConvolveReference(bs, s, b, s, &f, phase[0], phase[1], w, w, off)
				VpxConvolve8(src, s, a, s, &f, phase[0], 16, phase[1], 16, w, w, off)
				if !bytes.Equal(a, b) {
					t.Fatalf("identity%d %v alias%v", w, phase, alias)
				}
			}
		}
	}
}
func TestV9DSPWHT(t *testing.T) {
	for v := -32768; v <= 32767; v++ {
		q := []int16{int16(v)}
		a := v9DSPBytes(4 * 11)
		b := bytes.Clone(a)
		Iwht4x4_1Add(q, a, 11)
		iwht4x4_1AddScalar(q, b, 11)
		if !bytes.Equal(a, b) {
			t.Fatalf("wht%d", v)
		}
	}
}
func BenchmarkV9DSPAvg(b *testing.B) {
	for _, s := range []int{8, 13, 32} {
		b.Run(fmt.Sprintf("stride%d", s), func(b *testing.B) {
			p := v9DSPBytes(8 * s)
			b.ReportAllocs()
			var v uint64
			for b.Loop() {
				v += uint64(VpxAvg8x8(p, 0, s))
			}
			v9DSPSink = v
		})
	}
}
func BenchmarkV9DSPCopy(b *testing.B) {
	for _, w := range []int{8, 16, 32, 64} {
		b.Run(fmt.Sprintf("w%d", w), func(b *testing.B) {
			p, d := v9DSPBytes(w*w), make([]byte, w*w)
			b.ReportAllocs()
			for b.Loop() {
				VpxConvolveCopy(p, w, d, w, w, w, 0)
				v9DSPSink += uint64(d[0])
			}
		})
	}
}
func BenchmarkV9DSPDC(b *testing.B) {
	for _, n := range []int{4, 8, 16, 32} {
		for _, dc := range []int16{0, 100} {
			b.Run(fmt.Sprintf("n%d_dc%d", n, dc), func(b *testing.B) {
				p := v9DSPBytes(n * (n + 7))
				q := []int16{dc}
				b.ReportAllocs()
				for b.Loop() {
					switch n {
					case 4:
						Idct4x4_1Add(q, p, n+7)
					case 8:
						Idct8x8_1Add(q, p, n+7)
					case 16:
						Idct16x16_1Add(q, p, n+7)
					case 32:
						Idct32x32_1Add(q, p, n+7)
					}
					v9DSPSink += uint64(p[0])
				}
			})
		}
	}
}
func BenchmarkV9DSPResize(b *testing.B) {
	for _, dims := range [][4]int{{96, 64, 64, 43}, {192, 108, 128, 72}, {320, 180, 160, 90}} {
		b.Run(fmt.Sprint(dims), func(b *testing.B) {
			sw, sh, dw, dh := dims[0], dims[1], dims[2], dims[3]
			s, d := v9DSPBytes(sw*sh), make([]byte, dw*dh)
			tmp := make([]int32, dw*sh)
			b.ReportAllocs()
			for b.Loop() {
				PolyphaseFilterPlane(d, dw, dw, dh, s, sw, sw, sh, tmp)
				v9DSPSink += uint64(d[0])
			}
		})
	}
}
func BenchmarkV9DSPAxis(b *testing.B) {
	f := v9DSPFilters()
	var scratch Convolve8Scratch
	for _, w := range []int{8, 16, 32, 64} {
		for _, axis := range []int{0, 1} {
			b.Run(fmt.Sprintf("w%d_axis%d", w, axis), func(b *testing.B) {
				s := w + 17
				p, d := v9DSPBytes(s*(w+10)), make([]byte, s*w)
				off := 3*s + 4
				b.ReportAllocs()
				for b.Loop() {
					if axis == 0 {
						VpxConvolve8AvgHorizWithScratch(p, s, d, s, &f, 5, 16, 0, 16, w, w, off, &scratch)
					} else {
						VpxConvolve8AvgVertWithScratch(p, s, d, s, &f, 0, 16, 5, 16, w, w, off, &scratch)
					}
					v9DSPSink += uint64(d[0])
				}
			})
		}
	}
}
func BenchmarkV9DSPIdentity(b *testing.B) {
	f := v9DSPFilters()
	var scratch Convolve8Scratch
	for _, w := range []int{8, 16, 32, 64} {
		for _, phase := range [][2]int{{0, 0}, {0, 5}, {5, 0}, {5, 8}} {
			b.Run(fmt.Sprintf("w%d_p%d_%d", w, phase[0], phase[1]), func(b *testing.B) {
				s := w + 17
				p, d := v9DSPBytes(s*(w+10)), make([]byte, s*w)
				off := 3*s + 4
				b.ReportAllocs()
				for b.Loop() {
					VpxConvolve8WithScratch(p, s, d, s, &f, phase[0], 16, phase[1], 16, w, w, off, &scratch)
					v9DSPSink += uint64(d[0])
				}
			})
		}
	}
}
func BenchmarkV9DSPWHT(b *testing.B) {
	for _, dc := range []int16{0, 1, -1, 1200, -32768, 32767} {
		b.Run(fmt.Sprintf("dc%d", dc), func(b *testing.B) {
			p := v9DSPBytes(4 * 11)
			q := []int16{dc}
			b.ReportAllocs()
			for b.Loop() {
				Iwht4x4_1Add(q, p, 11)
				v9DSPSink += uint64(p[0])
			}
		})
	}
}
func v9DSPResizeReference(dst []byte, dstStride int,
	dstWidth, dstHeight int,
	src []byte, srcStride int,
	srcWidth, srcHeight int,
	scratch []int32,
) {
	if dstWidth <= 0 || dstHeight <= 0 || srcWidth <= 0 || srcHeight <= 0 ||
		len(scratch) < dstWidth*srcHeight {
		return
	}

	// Horizontal pass: resample every source row from srcWidth to
	// dstWidth. The output is a signed int32 (we keep the 128-scaled
	// taps unrounded so the second pass can sum at full precision).
	for y := range srcHeight {
		srcRow := src[y*srcStride:]
		dstRow := scratch[y*dstWidth:]
		for x := range dstWidth {
			firstSrc, phase := polyphaseTap(x, dstWidth, srcWidth)
			taps := &polyphaseFilters[phase]
			var acc int32
			for t := range polyphaseTaps {
				idx := firstSrc + t
				if idx < 0 {
					idx = 0
				} else if idx >= srcWidth {
					idx = srcWidth - 1
				}
				acc += int32(taps[t]) * int32(srcRow[idx])
			}
			dstRow[x] = acc
		}
	}

	// Vertical pass: resample every column of the intermediate plane
	// from srcHeight to dstHeight, applying the polyphase filter and
	// the combined two-pass rounding shift. The intermediate samples
	// are 128-scaled; the combined shift is 2 * shift = 14 bits.
	const combinedShift = 2 * polyphaseShift
	const round = 1 << (combinedShift - 1)
	for y := range dstHeight {
		firstSrc, phase := polyphaseTap(y, dstHeight, srcHeight)
		taps := &polyphaseFilters[phase]
		dstRow := dst[y*dstStride:]
		for x := range dstWidth {
			var acc int64
			for t := range polyphaseTaps {
				idx := firstSrc + t
				if idx < 0 {
					idx = 0
				} else if idx >= srcHeight {
					idx = srcHeight - 1
				}
				acc += int64(taps[t]) * int64(scratch[idx*dstWidth+x])
			}
			out := (acc + int64(round)) >> combinedShift
			if out < 0 {
				out = 0
			} else if out > 255 {
				out = 255
			}
			dstRow[x] = byte(out)
		}
	}
}
func v9DSPRefd207Predictor(dst []uint8, stride, bs int, above, left []uint8) {
	_ = above
	// first column
	for r := 0; r < bs-1; r++ {
		dst[r*stride] = avg2(int(left[r]), int(left[r+1]))
	}
	dst[(bs-1)*stride] = left[bs-1]

	// second column
	for r := 0; r < bs-2; r++ {
		dst[r*stride+1] = avg3(int(left[r]), int(left[r+1]), int(left[r+2]))
	}
	dst[(bs-2)*stride+1] = avg3(int(left[bs-2]), int(left[bs-1]), int(left[bs-1]))
	dst[(bs-1)*stride+1] = left[bs-1]

	// rest of last row
	for c := 0; c < bs-2; c++ {
		dst[(bs-1)*stride+2+c] = left[bs-1]
	}

	// rest fills in via copy-up-2 from the bottom-right corner.
	for r := bs - 2; r >= 0; r-- {
		for c := 0; c < bs-2; c++ {
			dst[r*stride+2+c] = dst[(r+1)*stride+c]
		}
	}
}
func v9DSPRefd117Predictor(dst []uint8, stride, bs int, aboveFull, left []uint8) {
	cornerByte := aboveFull[0]
	above := aboveFull[1:]
	// first row
	for c := range bs {
		var a0 uint8
		if c == 0 {
			a0 = cornerByte
		} else {
			a0 = above[c-1]
		}
		dst[c] = avg2(int(a0), int(above[c]))
	}
	// second row
	dst[stride+0] = avg3(int(left[0]), int(cornerByte), int(above[0]))
	for c := 1; c < bs; c++ {
		var a0 uint8
		if c == 1 {
			a0 = cornerByte
		} else {
			a0 = above[c-2]
		}
		dst[stride+c] = avg3(int(a0), int(above[c-1]), int(above[c]))
	}
	// rest of first col — libvpx walks dst from the row-2 base; we
	// keep dst at the buffer root and account for the offset by adding
	// 2 to the row index inside this loop.
	dst[2*stride] = avg3(int(cornerByte), int(left[0]), int(left[1]))
	for r := 3; r < bs; r++ {
		dst[r*stride] = avg3(int(left[r-3]), int(left[r-2]), int(left[r-1]))
	}
	// the rest of the block
	for r := 2; r < bs; r++ {
		for c := 1; c < bs; c++ {
			dst[r*stride+c] = dst[(r-2)*stride+c-1]
		}
	}
}
func v9DSPRefd153Predictor(dst []uint8, stride, bs int, aboveFull, left []uint8) {
	cornerByte := aboveFull[0]
	above := aboveFull[1:]
	// first column
	dst[0] = avg2(int(cornerByte), int(left[0]))
	for r := 1; r < bs; r++ {
		dst[r*stride] = avg2(int(left[r-1]), int(left[r]))
	}
	// second column
	dst[1] = avg3(int(left[0]), int(cornerByte), int(above[0]))
	dst[stride+1] = avg3(int(cornerByte), int(left[0]), int(left[1]))
	for r := 2; r < bs; r++ {
		dst[r*stride+1] = avg3(int(left[r-2]), int(left[r-1]), int(left[r]))
	}
	// third column onward, row 0
	for c := 0; c < bs-2; c++ {
		var a0 uint8
		if c == 0 {
			a0 = cornerByte
		} else {
			a0 = above[c-1]
		}
		dst[2+c] = avg3(int(a0), int(above[c]), int(above[c+1]))
	}
	// rest of the block: shift-from-prior-row-by-2 columns
	for r := 1; r < bs; r++ {
		for c := 0; c < bs-2; c++ {
			dst[r*stride+2+c] = dst[(r-1)*stride+c]
		}
	}
}

func TestV9DSPDirection(t *testing.T) {
	for _, n := range []int{8, 16, 32} {
		for _, stride := range []int{n - 1, n, n + 7} {
			for _, alias := range []int{-1, 0, 1} {
				for mode := range 3 {
					a := v9DSPBytes((n+7)*n + 400)
					b := bytes.Clone(a)
					aa, la := v9DSPBytes(2*n+1), v9DSPBytes(n)
					ab, lb := bytes.Clone(aa), bytes.Clone(la)
					if alias >= 0 {
						aa = a[alias:]
						la = a[alias+1:]
						ab = b[alias:]
						lb = b[alias+1:]
					}
					switch mode {
					case 0:
						d207Predictor(a, stride, n, aa, la)
						v9DSPRefd207Predictor(b, stride, n, ab, lb)
					case 1:
						d117Predictor(a, stride, n, aa, la)
						v9DSPRefd117Predictor(b, stride, n, ab, lb)
					case 2:
						d153Predictor(a, stride, n, aa, la)
						v9DSPRefd153Predictor(b, stride, n, ab, lb)
					}
					if !bytes.Equal(a, b) {
						t.Fatalf("direction n%d s%d a%d m%d", n, stride, alias, mode)
					}
				}
			}
		}
	}
}
func BenchmarkV9DSPDirection(b *testing.B) {
 funcs:=[3][3]func([]byte,int,[]byte,[]byte){{VpxD207Predictor8x8,VpxD117Predictor8x8,VpxD153Predictor8x8},{VpxD207Predictor16x16,VpxD117Predictor16x16,VpxD153Predictor16x16},{VpxD207Predictor32x32,VpxD117Predictor32x32,VpxD153Predictor32x32}}
 for idx,n:=range []int{8,16,32}{for mode:=range 3{b.Run(fmt.Sprintf("n%d_mode%d",n,mode),func(b *testing.B){a:=make([]byte,(n+7)*n);above,left:=v9DSPBytes(2*n+1),v9DSPBytes(n);f:=funcs[idx][mode];b.ReportAllocs();for b.Loop(){f(a,n+7,above,left);v9DSPSink+=uint64(a[0])}})}}
}

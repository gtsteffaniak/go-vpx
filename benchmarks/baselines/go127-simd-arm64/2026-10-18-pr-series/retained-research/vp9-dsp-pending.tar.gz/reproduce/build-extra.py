from pathlib import Path
import subprocess,os,json,hashlib
p=Path('/private/tmp/govpx-vp9dsp-prs')
for tree in [p/'base',p/'v9dsp09']:
 q=tree/'internal/vp9/dsp/v9_dsp_prs_test.go';s=q.read_text();a=s.index('func BenchmarkV9DSPDirection(')
 s=s[:a]+'''func BenchmarkV9DSPDirection(b *testing.B) {
 funcs:=[3][3]func([]byte,int,[]byte,[]byte){{VpxD207Predictor8x8,VpxD117Predictor8x8,VpxD153Predictor8x8},{VpxD207Predictor16x16,VpxD117Predictor16x16,VpxD153Predictor16x16},{VpxD207Predictor32x32,VpxD117Predictor32x32,VpxD153Predictor32x32}}
 for idx,n:=range []int{8,16,32}{for mode:=range 3{b.Run(fmt.Sprintf("n%d_mode%d",n,mode),func(b *testing.B){a:=make([]byte,(n+7)*n);above,left:=v9DSPBytes(2*n+1),v9DSPBytes(n);f:=funcs[idx][mode];b.ReportAllocs();for b.Loop(){f(a,n+7,above,left);v9DSPSink+=uint64(a[0])}})}}
}
''';q.write_text(s)
env=os.environ.copy();env.update(CODEX_AGENT_ID='vp9dsp-prs',CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',GOTOOLCHAIN='local',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',GOEXPERIMENT='simd',GOMAXPROCS='2',GOFLAGS='-p=2',CGO_ENABLED='1')
for name,binary in [('base','base-nine.test'),('v9dsp09','v9dsp09.test')]:
 with (p/f'{name}-nine-build.log').open('w') as f:r=subprocess.run(['scripts/go.sh','-C',str(p/name),'test','-c','-pgo=off','-o',str(p/binary),'./internal/vp9/dsp'],env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,'build',r.returncode,flush=True)
 if r.returncode:continue
 with (p/f'{name}-nine-correctness.log').open('w') as f:r=subprocess.run([str(p/binary),'-test.run=^TestV9DSPDirection$','-test.count=1'],env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,'proof',r.returncode,flush=True)
manifest=json.loads((p/'manifest.json').read_text());path='internal/vp9/dsp/intrapred_dir.go';tree=p/'v9dsp09';manifest.append(dict(id='v9dsp09',title='Propagate directional predictor rows with bounded copies',base='870699ce83f3eb6de44f507ef29f6d6a429e916d',tree=str(tree),base_binary=str(p/'base-nine.test'),binary=str(p/'v9dsp09.test'),paths=[path],fixture='internal/vp9/dsp/v9_dsp_prs_test.go',test='^TestV9DSPDirection$',bench='^BenchmarkV9DSPDirection$',correctness=str(p/'v9dsp09-nine-correctness.log'),source_sha256={path:hashlib.sha256((tree/path).read_bytes()).hexdigest()}));(p/'manifest-nine.json').write_text(json.dumps(manifest,indent=2)+'\n')

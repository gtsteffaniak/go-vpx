from pathlib import Path
import shutil
p=Path('/private/tmp/govpx-vp9dsp-prs');shutil.copytree(p/'base',p/'v9dsp09',dirs_exist_ok=True)
q=p/'v9dsp09/internal/vp9/dsp/intrapred_dir.go';s=q.read_text()
for fn in ['d207Predictor','d117Predictor','d153Predictor']:
 a=s.index('func '+fn+'(');b=s.index('\n}',a)+2;seg=s[a:b];seg=seg.replace('{\n','{\n fastRows := intraBridgeWindow(dst,stride,bs)\n',1)
 if fn=='d207Predictor':seg=seg.replace('''		for c := 0; c < bs-2; c++ {
			dst[r*stride+2+c] = dst[(r+1)*stride+c]
		}''','''        if fastRows { copy(dst[r*stride+2:r*stride+bs],dst[(r+1)*stride:(r+1)*stride+bs-2]) } else {
            for c:=0;c<bs-2;c++ {dst[r*stride+2+c]=dst[(r+1)*stride+c]}
        }''')
 if fn=='d117Predictor':seg=seg.replace('''		for c := 1; c < bs; c++ {
			dst[r*stride+c] = dst[(r-2)*stride+c-1]
		}''','''        if fastRows { copy(dst[r*stride+1:r*stride+bs],dst[(r-2)*stride:(r-2)*stride+bs-1]) } else {
            for c:=1;c<bs;c++ {dst[r*stride+c]=dst[(r-2)*stride+c-1]}
        }''')
 if fn=='d153Predictor':seg=seg.replace('''		for c := 0; c < bs-2; c++ {
			dst[r*stride+2+c] = dst[(r-1)*stride+c]
		}''','''        if fastRows { copy(dst[r*stride+2:r*stride+bs],dst[(r-1)*stride:(r-1)*stride+bs-2]) } else {
            for c:=0;c<bs-2;c++ {dst[r*stride+2+c]=dst[(r-1)*stride+c]}
        }''')
 s=s[:a]+seg+s[b:]
q.write_text(s)
# Freeze the original directional operations.
s=(p/'base/internal/vp9/dsp/intrapred_dir.go').read_text();frozen=''
for fn in ['d207Predictor','d117Predictor','d153Predictor']:
 a=s.index('func '+fn+'(');b=s.index('\n}',a)+2;frozen+=s[a:b].replace('func '+fn+'(','func v9DSPRef'+fn+'(')+'\n'
extra=r'''
func TestV9DSPDirection(t *testing.T) {for _,n:=range []int{8,16,32}{for _,stride:=range []int{n-1,n,n+7}{for _,alias:=range []int{-1,0,1}{for mode:=range 3 {a:=v9DSPBytes((n+7)*n+400);b:=bytes.Clone(a);aa,la:=v9DSPBytes(2*n+1),v9DSPBytes(n);ab,lb:=bytes.Clone(aa),bytes.Clone(la);if alias>=0 {aa=a[alias:];la=a[alias+1:];ab=b[alias:];lb=b[alias+1:]};switch mode{case 0:d207Predictor(a,stride,n,aa,la);v9DSPRefd207Predictor(b,stride,n,ab,lb);case 1:d117Predictor(a,stride,n,aa,la);v9DSPRefd117Predictor(b,stride,n,ab,lb);case 2:d153Predictor(a,stride,n,aa,la);v9DSPRefd153Predictor(b,stride,n,ab,lb)};if !bytes.Equal(a,b){t.Fatalf("direction n%d s%d a%d m%d",n,stride,alias,mode)}}}}}}
func BenchmarkV9DSPDirection(b *testing.B){for _,n:=range []int{8,16,32}{for mode:=range 3{b.Run(fmt.Sprintf("n%d_mode%d",n,mode),func(b *testing.B){a:=make([]byte,(n+7)*n);above,left:=v9DSPBytes(2*n+1),v9DSPBytes(n);b.ReportAllocs();for b.Loop(){switch mode{case 0:d207Predictor(a,n+7,n,above,left);case 1:d117Predictor(a,n+7,n,above,left);case 2:d153Predictor(a,n+7,n,above,left)};v9DSPSink+=uint64(a[0])}})}}}
'''
for tree in [p/'base',p/'v9dsp09']:
 q=tree/'internal/vp9/dsp/v9_dsp_prs_test.go';q.write_text(q.read_text()+frozen+extra)

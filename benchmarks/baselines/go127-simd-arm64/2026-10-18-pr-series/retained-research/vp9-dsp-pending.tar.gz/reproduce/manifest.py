from pathlib import Path
import json,hashlib
p=Path('/private/tmp/govpx-vp9dsp-prs'); fixture='internal/vp9/dsp/v9_dsp_prs_test.go'
names=['Use SIMD sum for single VP9 block averages','Collapse disjoint contiguous convolve copies','Skip exact zero DC residual reconstruction','Plan vertical resize row bounds once','Hoist repeated horizontal resize phase division','Filter and average convolution axes in SIMD packets','Remove identity axis from two-pass convolution','Evaluate lossless DC inverse WHT without staging']
tests=['Avg','Copy','DC','Resize','Resize','Axis','Identity','WHT'];rows=[]
for i in range(1,9):
 tree=p/f'v9dsp{i:02}'; paths=[]
 for q in sorted((tree/'internal/vp9/dsp').glob('*.go')):
  path=str(q.relative_to(tree))
  if path!=fixture and q.read_bytes()!=(p/'base'/path).read_bytes():paths.append(path)
 rows.append(dict(id=f'v9dsp{i:02}',title=names[i-1],base='870699ce83f3eb6de44f507ef29f6d6a429e916d',tree=str(tree),base_binary=str(p/'base.test'),binary=str(p/f'v9dsp{i:02}.test'),paths=paths,fixture=fixture,test=f'^TestV9DSP{tests[i-1]}$',bench=f'^BenchmarkV9DSP{tests[i-1]}$',correctness=str(p/f'v9dsp{i:02}-correctness.log'),source_sha256={x:hashlib.sha256((tree/x).read_bytes()).hexdigest() for x in paths}))
(p/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([(x['id'],x['paths']) for x in rows]))

from pathlib import Path
import subprocess,os,json,hashlib
p=Path('/private/tmp/govpx-vp9dsp-prs'); env=os.environ.copy();env.update(CODEX_AGENT_ID='vp9dsp-prs',CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',GOTOOLCHAIN='local',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',GOEXPERIMENT='simd',GOMAXPROCS='2',GOFLAGS='-p=2',CGO_ENABLED='1')
for name in ['base']+[f'v9dsp{i:02}' for i in range(1,9)]:
 log=p/f'{name}-build.log'
 with log.open('w') as f:r=subprocess.run(['scripts/go.sh','-C',str(p/name),'test','-c','-pgo=off','-o',str(p/f'{name}.test'),'./internal/vp9/dsp'],env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,'build',r.returncode,flush=True)
 if r.returncode:print(log.read_text()[-3000:],flush=True);continue
 with (p/f'{name}-correctness.log').open('w') as f:r=subprocess.run([str(p/f'{name}.test'),'-test.run=^TestV9DSP','-test.count=1'],env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,'proof',r.returncode,flush=True)
 if r.returncode:print((p/f'{name}-correctness.log').read_text()[-3000:],flush=True)

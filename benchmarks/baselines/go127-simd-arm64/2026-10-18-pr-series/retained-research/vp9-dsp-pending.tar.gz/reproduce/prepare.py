from pathlib import Path
import shutil,json
p=Path('/private/tmp/govpx-vp9dsp-prs'); base=p/'base'
for i in range(1,9): shutil.copytree(base,p/f'v9dsp{i:02}',dirs_exist_ok=True)
def edit(i,name,f):
 q=p/f'v9dsp{i:02}'/'internal/vp9/dsp'/name;q.write_text(f(q.read_text()))
edit(1,'avg_block.go',lambda s:s.replace('package dsp','package dsp\n\nimport "github.com/thesyncim/govpx/internal/pixel"',1).replace('sum := 0\n\tfor r := range 8 {','if pixel.Enabled && off >= 0 && stride >= 8 && len(src)-off >= 8 && stride <= (len(src)-off-8)/7 {\n\t\treturn (pixel.Sum(src[off:], stride, 8, 8) + 32) >> 6\n\t}\n\tsum := 0\n\tfor r := range 8 {',1))
edit(2,'convolve.go',lambda s:s.replace('"runtime"','"runtime"\n "unsafe"').replace('for y := range h {\n\t\tcopy(dst[y*dstStride', '''if w > 0 && h > 0 && srcStride == w && dstStride == w && srcOffset >= 0 && w <= len(dst)/h && srcOffset <= len(src) && w <= (len(src)-srcOffset)/h {
        count := w*h
        sp, dp := uintptr(unsafe.Pointer(unsafe.SliceData(src[srcOffset:]))), uintptr(unsafe.Pointer(unsafe.SliceData(dst)))
        if (sp <= dp && dp-sp >= uintptr(count)) || (dp < sp && sp-dp >= uintptr(count)) {
            copy(dst[:count], src[srcOffset:srcOffset+count]); return
        }
    }
    for y := range h {
        copy(dst[y*dstStride''',1))
edit(3,'idct_dispatch_other.go',lambda s:s.replace('pixel.AddConstant(dest, stride, dest, stride, 4, 4, int(roundPowerOfTwo(int32(v), 4)))','if v == 0 && intraBridgeWindow(dest, stride, 4) { return }\n\t\tpixel.AddConstant(dest, stride, dest, stride, 4, 4, int(roundPowerOfTwo(int32(v), 4)))').replace('pixel.AddConstant(dest, stride, dest, stride, 8, 8, int(roundPowerOfTwo(int32(v), 5)))','if roundPowerOfTwo(int32(v), 5) == 0 && intraBridgeWindow(dest, stride, 8) { return }\n\t\tpixel.AddConstant(dest, stride, dest, stride, 8, 8, int(roundPowerOfTwo(int32(v), 5)))').replace('pixel.AddConstant(dest, stride, dest, stride, 16, 16, int(roundPowerOfTwo(int32(v), 6)))','if roundPowerOfTwo(int32(v), 6) == 0 && intraBridgeWindow(dest, stride, 16) { return }\n\t\tpixel.AddConstant(dest, stride, dest, stride, 16, 16, int(roundPowerOfTwo(int32(v), 6)))').replace('pixel.AddConstant(dest, stride, dest, stride, 32, 32, int(roundPowerOfTwo(int32(v), 6)))','if roundPowerOfTwo(int32(v), 6) == 0 && intraBridgeWindow(dest, stride, 32) { return }\n\t\tpixel.AddConstant(dest, stride, dest, stride, 32, 32, int(roundPowerOfTwo(int32(v), 6)))'))
# Plan vertical source indices once per output row.
def vresize(s):
 marker='\t\tfor x := range dstWidth {\n\t\t\tvar acc int64'
 s=s.replace(marker,'''        var rows [polyphaseTaps]int
        for t := range polyphaseTaps {
            idx := firstSrc+t
            if idx < 0 { idx=0 } else if idx >= srcHeight { idx=srcHeight-1 }
            rows[t] = idx*dstWidth
        }
        for x := range dstWidth {
            var acc int64''')
 a=s.index('\t\t\t\tidx := firstSrc + t',s.index('const combinedShift'));b=s.index('\n\t\t\t}',a)
 s=s[:a]+'\t\t\t\tacc += int64(taps[t]) * int64(scratch[rows[t]+x])'+s[b:]
 return s
edit(4,'resize.go',vresize)
def hresize(s):
 a=s.index('\tfor y := range srcHeight {');b=s.index('\n\t// Vertical pass:',a)
 s=s[:a]+'''    for x := range dstWidth {
        firstSrc, phase := polyphaseTap(x, dstWidth, srcWidth)
        taps := &polyphaseFilters[phase]
        var indices [polyphaseTaps]int
        for t := range polyphaseTaps {
            idx := firstSrc+t
            if idx < 0 { idx=0 } else if idx >= srcWidth { idx=srcWidth-1 }
            indices[t]=idx
        }
        for y := range srcHeight {
            srcRow := src[y*srcStride:]
            var acc int32
            for t := range polyphaseTaps { acc += int32(taps[t])*int32(srcRow[indices[t]]) }
            scratch[y*dstWidth+x]=acc
        }
    }
''' + s[b:]
 return s
edit(5,'resize.go',hresize)
# SIMD filter to caller scratch, then SIMD blend; restrict disjoint and full bounds.
helper='''
func convolveAvgSIMDWindow(src []byte, ss int, dst []byte, ds, w,h, off, step int) bool {
 if !pixel.Enabled || w < 4 || w > 64 || w%4 != 0 || h <= 0 || h > 64 || ss < w || ds < w || off < 0 || off > len(src) { return false }
 extra := 7*step
 if extra < 0 || extra > len(src)-off || w > len(src)-off-extra || (h-1) > (len(src)-off-extra-w)/ss || w > len(dst) || (h-1) > (len(dst)-w)/ds {return false}
 sn,dn := (h-1)*ss+w+extra,(h-1)*ds+w
 sp,dp:=uintptr(unsafe.Pointer(unsafe.SliceData(src[off:]))),uintptr(unsafe.Pointer(unsafe.SliceData(dst)))
 return (sp <= dp && dp-sp >= uintptr(sn)) || (dp < sp && sp-dp >= uintptr(dn))
}
'''
def avgaxis(s):
 s=s.replace('import "github.com/thesyncim/govpx/internal/vp9/tables"','import ("github.com/thesyncim/govpx/internal/vp9/tables"; "github.com/thesyncim/govpx/internal/pixel"; "unsafe")')
 s=s.replace('\t_ = scratch\n\tconvolveAvgHoriz', '''    base := srcOffset - 3 + (x0Q4 >> 4)
    if xStepQ4 == 16 && convolveAvgSIMDWindow(src,srcStride,dst,dstStride,w,h,base,1) {
        temp, b := convolve8AvgTempForScratch(scratch)
        pixel.Filter(src[base:],srcStride,temp,64,w,h,1,filter[x0Q4&15][:])
        pixel.Average(temp,64,dst,dstStride,w,h)
        convolve8AvgTempPut(b); return
    }
    convolveAvgHoriz''')
 s=s.replace('\t_ = scratch\n\tconvolveAvgVert', '''    base := srcOffset + (y0Q4 >> 4)*srcStride - 3*srcStride
    if yStepQ4 == 16 && srcStride <= len(src)/7 && convolveAvgSIMDWindow(src,srcStride,dst,dstStride,w,h,base,srcStride) {
        temp, b := convolve8AvgTempForScratch(scratch)
        pixel.Filter(src[base:],srcStride,temp,64,w,h,srcStride,filter[y0Q4&15][:])
        pixel.Average(temp,64,dst,dstStride,w,h)
        convolve8AvgTempPut(b); return
    }
    convolveAvgVert''')
 return s+helper
edit(6,'convolve_avg_axis_other.go',avgaxis)
def identity(s):
 s=s.replace('import "github.com/thesyncim/govpx/internal/vp9/tables"','import ("github.com/thesyncim/govpx/internal/vp9/tables"; "unsafe")')
 s=s.replace('\ttemp, tempBuf := convolve8TempForScratch(scratch)', '''    if xStepQ4 == 16 && yStepQ4 == 16 && x0Q4 >= 0 && x0Q4 < 16 && y0Q4 >= 0 && y0Q4 < 16 && convolveIdentityWindow(src,srcStride,dst,dstStride,w,h,srcOffset) {
        if convolveIdentityFilter(&filter[x0Q4]) {
            convolveVert(src,srcStride,dst,dstStride,filter,y0Q4,16,w,h,srcOffset); return
        }
        if convolveIdentityFilter(&filter[y0Q4]) {
            convolveHoriz(src,srcStride,dst,dstStride,filter,x0Q4,16,w,h,srcOffset); return
        }
    }
    temp, tempBuf := convolve8TempForScratch(scratch)''',1)
 s+='''
func convolveIdentityFilter(t *[8]int16) bool {
 return t[0]==0 && t[1]==0 && t[2]==0 && t[3]==128 && t[4]==0 && t[5]==0 && t[6]==0 && t[7]==0
}
func convolveIdentityWindow(src []byte,ss int,dst []byte,ds,w,h,off int) bool {
 if w < 4 || w > 64 || w%4 != 0 || h <= 0 || h > 64 || ss < w+7 || ds < w || ss > len(src)/3 || off < 3*ss+3 || off > len(src) || w > len(dst) || h-1 > (len(dst)-w)/ds {return false}
 start:=off-3*ss-3
 if w+7 > len(src)-start || h+6 > (len(src)-start-w-7)/ss {return false}
 sn,dn := (h+6)*ss+w+7,(h-1)*ds+w
 sp,dp:=uintptr(unsafe.Pointer(unsafe.SliceData(src[start:]))),uintptr(unsafe.Pointer(unsafe.SliceData(dst)))
 return (sp <= dp && dp-sp >= uintptr(sn)) || (dp < sp && sp-dp >= uintptr(dn))
}
'''
 return s
edit(7,'convolve_other.go',identity)
def wht(s):
 a=s.index('\tvar onlyDC [16]int16');b=s.index('\ta, c, d, b :=',a)
 s=s[:a]+'''    if dc {
        // The lossless DC lifting produces two values per axis, not a DCT constant.
        v := int32(input[0]) >> 2
        lo := v >> 1
        hi := v-lo
        r0 := archsimd.Int32x4{}.SetElem(0,hi-(hi>>1)).SetElem(1,lo-(lo>>1)).SetElem(2,lo-(lo>>1)).SetElem(3,lo-(lo>>1))
        rn := archsimd.Int32x4{}.SetElem(0,hi>>1).SetElem(1,lo>>1).SetElem(2,lo>>1).SetElem(3,lo>>1)
        pixel.StorePixels4(dst,r0.Add(pixel.LoadPixels4(dst)))
        pixel.StorePixels4(dst[stride:],rn.Add(pixel.LoadPixels4(dst[stride:])))
        pixel.StorePixels4(dst[2*stride:],rn.Add(pixel.LoadPixels4(dst[2*stride:])))
        pixel.StorePixels4(dst[3*stride:],rn.Add(pixel.LoadPixels4(dst[3*stride:])))
        return true
    }
''' + s[b:]
 return s
edit(8,'transform_simd.go',wht)

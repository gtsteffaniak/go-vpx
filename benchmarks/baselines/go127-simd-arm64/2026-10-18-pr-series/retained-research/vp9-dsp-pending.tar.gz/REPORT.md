# Retained VP9 DSP candidates

Status: retained pending integration. Eight native winners are preserved as source overlays, with the rejected average experiment retained as loss evidence. These are not additional published PRs. All production overlays are independent against frozen commit `870699ce83f3eb6de44f507ef29f6d6a429e916d`. Do not overwrite newer production files with an entire overlay when integrating; apply the function-level changes, particularly resize candidates 04 and 05, which touch the same file.

## Preliminary native component screen

Apple M4 Max, Darwin ARM64, Go 1.27.2, `GOEXPERIMENT=simd`, PGO off. Two short 40 ms comparisons per case with one benchmark CPU. Every measured operation reports zero allocations. These are public-operation kernels, not whole-codec results; no x64 performance or correctness claim is made.

| Candidate | Operation | Native speedup | Decision |
|---|---|---|---|
| 01 | SIMD single block average | 0.54–0.59× | Rejected |
| 02 | Disjoint contiguous convolve copy | 2.70–4.97× | Retained pending integration |
| 03 | Exact zero DC reconstruction | 3–81× zero controls | Retained pending integration |
| 04 | Vertical resize clamp planning | 1.277–1.35× | Retained pending integration |
| 05 | Horizontal resize phase division hoist | 1.67–1.76× | Retained pending integration |
| 06 | SIMD filter and average convolution axes | 4.45–11.38× | Retained pending integration |
| 07 | Identity convolution axis removal | 1.80–2.84× | Retained pending integration |
| 08 | Direct lossless DC inverse WHT | 1.49–1.66× | Retained pending integration |
| 09 | Directional row propagation | 1.23–4.14× | Retained pending integration |

All cases, including losses and controls, are in summary.json and raw timing text. Candidate 07 mixed-axis controls range about 0.949–1.01×; candidate 09 has an 8-pixel D207 case below the 15% target. Candidate 03 only changes exact zero residual cases; nonzero controls remain measured separately. Performance acceptance is per affected workload, not a claim that every case improves.

## Focused proof and alias review

All focused native tests passed. Proofs include frozen resize/directional algorithms, progressive overlapping row-copy controls, aliasing edge inputs, complete int16 DC-WHT sweep, DC clipping extremes, and scalar/frozen convolution comparisons. No full suite, full CI, C comparison, profile, or root ML stream was run for these unpublished candidates.

Copy candidate 02 requires disjoint, complete contiguous windows and falls back to original row order on overlap. Candidate 03 validates the complete destination before skipping any zero write, preserving invalid-window fallback. Axis convolution 06 requires disjoint source/destination spans, complete 4-aligned rows, and bounds valid for all eight filter taps; overlapping inputs retain the scalar progressive route. Candidate 07 similarly requires the full original read window and disjoint destination, and verifies all eight coefficients of an identity row. Candidate 09 only uses row copies after proving complete nonoverlapping rows, retaining original scalar propagation otherwise.

Resize candidate 05 changes scratch write order while keeping the complete horizontal pass before any destination output. Its proof covers valid public source/destination/scratch windows, including unusual scaling ratios. Partial scratch mutation on a panic caused by an invalid source window is not proven equivalent. Deliberate unsafe byte/int32 scratch aliasing is outside the tested contract. Candidate 06 assumes the caller-owned internal scratch does not alias source/destination, as normal production callers require; unusual manually aliased scratch layouts are not covered.

## Reuse

manifest.json binds every production source, focused fixture, baseline source and native binary hash. overlays/ contains exact measured production sources; frozen-base/ contains affected frozen sources. fixtures/ has the shared first-eight fixture and the separately bound ninth fixture. raw/ preserves every short run and correctness/build log. reproduce/ preserves construction scripts. Reconstruct a base checkout from the pinned commit, copy the matching fixture and apply one candidate overlay, then use the project root scripts/go.sh with an agent-specific CODEX_AGENT_ID. Native binaries are deliberately omitted from this compact archive; their SHA256 identities are preserved for evidence.

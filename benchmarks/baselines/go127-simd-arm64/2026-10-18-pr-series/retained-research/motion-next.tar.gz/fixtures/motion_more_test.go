package govpx

import (
	"fmt"
	vp8common "github.com/thesyncim/govpx/internal/vp8/common"
	vp8dec "github.com/thesyncim/govpx/internal/vp8/decoder"
	vp8enc "github.com/thesyncim/govpx/internal/vp8/encoder"
	vp8tables "github.com/thesyncim/govpx/internal/vp8/tables"
	"testing"
)

func motionParentDiamondNstepInterFrameSplitBlockFullPixelMotionVectorWithErrorPerBitAndCostTables(search *splitFullPelSearchCtx, center vp8enc.MotionVector, centerWalkCost int, centerReturnCost int, bestRefMV vp8enc.MotionVector, refRowFull int, refColFull int, qIndex int, errorPerBit int, mvProbs *[2][vp8tables.MVPCount]uint8, mvCosts *vp8enc.MotionVectorCostTables, bounds vp8enc.InterFrameFullPixelBounds, searchParam int) splitFullPixelSearchResult {
	sites := vp8enc.InterFrameNstepSearchSites[:]
	if searchParam < 0 {
		searchParam = 0
	} else if searchParam >= interFrameMaxMVSearchSteps {
		searchParam = interFrameMaxMVSearchSteps - 1
	}
	best := center
	bestWalkCost := centerWalkCost
	start := center
	startIndex := searchParam * 8
	totalSteps := (len(sites) / 8) - searchParam
	i := 1
	bestSite := 0
	lastSite := 0
	num00 := 0
	for range totalSteps {
		for range 8 {
			site := sites[startIndex+i]
			row := (int(best.Row) >> 3) + int(site.Row)
			col := (int(best.Col) >> 3) + int(site.Col)
			if bounds.ContainsFullPelStrict(row, col) {
				cost := search.fullPelCostFull(row, col, refRowFull, refColFull, qIndex)
				if cost < bestWalkCost {
					bestWalkCost = cost
					bestSite = i
				}
			}
			i++
		}
		if bestSite != lastSite {
			site := sites[startIndex+bestSite]
			best = vp8enc.MotionVector{
				Row: int16(int(best.Row) + int(site.Row)*interFrameMVFullPixelStep),
				Col: int16(int(best.Col) + int(site.Col)*interFrameMVFullPixelStep),
			}
			lastSite = bestSite
		} else if best == start {
			num00++
		}
	}
	returnCost := centerReturnCost
	if best != center {
		var ok bool
		returnCost, ok = interMotionSplitBlockFullPixelReturnCostWithErrorPerBitAndCostTables(search.src, search.ref, search.mbRow, search.mbCol, search.block, search.width, search.height, best, bestRefMV, errorPerBit, mvProbs, mvCosts)
		if !ok {
			returnCost = maxInt()
		}
	}
	return splitFullPixelSearchResult{mv: best, walkCost: bestWalkCost, returnCost: returnCost, num00: uint8(num00)}
}
func motionParentFullSearchInterFrameSplitBlockFullPixelMotionVectorWithErrorPerBitAndCostTables(search *splitFullPelSearchCtx, center vp8enc.MotionVector, bestRefMV vp8enc.MotionVector, refRowFull int, refColFull int, qIndex int, errorPerBit int, mvProbs *[2][vp8tables.MVPCount]uint8, mvCosts *vp8enc.MotionVectorCostTables, bounds vp8enc.InterFrameFullPixelBounds, distance int) splitFullPixelSearchResult {
	refRow := int(center.Row) >> 3
	refCol := int(center.Col) >> 3
	rowMin := refRow - distance
	rowMax := refRow + distance
	colMin := refCol - distance
	colMax := refCol + distance
	if rowMin < bounds.RowMin {
		rowMin = bounds.RowMin
	}
	if rowMax > bounds.RowMax {
		rowMax = bounds.RowMax
	}
	if colMin < bounds.ColMin {
		colMin = bounds.ColMin
	}
	if colMax > bounds.ColMax {
		colMax = bounds.ColMax
	}
	best := center
	bestWalkCost := search.fullPelCostFull(int(best.Row)>>3, int(best.Col)>>3, refRowFull, refColFull, qIndex)
	for row := rowMin; row < rowMax; row++ {
		for col := colMin; col < colMax; col++ {
			mv := vp8enc.MotionVector{Row: int16(row * interFrameMVFullPixelStep), Col: int16(col * interFrameMVFullPixelStep)}
			cost := search.fullPelCostFull(row, col, refRowFull, refColFull, qIndex)
			if cost < bestWalkCost {
				best = mv
				bestWalkCost = cost
			}
		}
	}
	returnCost, ok := interMotionSplitBlockFullPixelReturnCostWithErrorPerBitAndCostTables(search.src, search.ref, search.mbRow, search.mbCol, search.block, search.width, search.height, best, bestRefMV, errorPerBit, mvProbs, mvCosts)
	if !ok {
		returnCost = maxInt()
	}
	return splitFullPixelSearchResult{mv: best, walkCost: bestWalkCost, returnCost: returnCost}
}

func TestMotionPR09(t *testing.T) {
	for _, sz := range [][2]int{{64, 64}, {65, 49}} {
		src, ref := motionPixelSetup(t, sz[0], sz[1])
		var costs vp8enc.MotionVectorCostTables
		costs.Build(&vp8tables.DefaultMVContext)
		for _, shape := range [][2]int{{16, 8}, {8, 16}, {8, 8}, {4, 4}} {
			for _, q := range []int{0, 44, 127} {
				y, x := (src.Height-1)/16, (src.Width-1)/16
				c1 := newSplitFullPelSearchCtx(src, ref, y, x, 0, shape[0], shape[1])
				c2 := c1
				bounds := vp8enc.InterFrameFullPixelSearchBounds(vp8enc.MotionVector{}, y, x, (src.Height+15)/16, (src.Width+15)/16)
				center := vp8enc.MotionVector{}
				a := fullSearchInterFrameSplitBlockFullPixelMotionVectorWithErrorPerBitAndCostTables(&c1, center, center, 0, 0, q, 34, &vp8tables.DefaultMVContext, &costs, bounds, 4)
				b := motionParentFullSearchInterFrameSplitBlockFullPixelMotionVectorWithErrorPerBitAndCostTables(&c2, center, center, 0, 0, q, 34, &vp8tables.DefaultMVContext, &costs, bounds, 4)
				if a != b {
					t.Fatal("full", sz, shape, q, a, b)
				}
				wc := c1.fullPelCostFull(0, 0, 0, 0, q)
				rc, ok := interMotionSplitBlockFullPixelReturnCostWithErrorPerBitAndCostTables(src, ref, y, x, 0, shape[0], shape[1], center, center, 34, &vp8tables.DefaultMVContext, &costs)
				if !ok {
					t.Fatal("returncost")
				}
				for param := 0; param < 8; param++ {
					a := diamondNstepInterFrameSplitBlockFullPixelMotionVectorWithErrorPerBitAndCostTables(&c1, center, wc, rc, center, 0, 0, q, 34, &vp8tables.DefaultMVContext, &costs, bounds, param)
					b := motionParentDiamondNstepInterFrameSplitBlockFullPixelMotionVectorWithErrorPerBitAndCostTables(&c2, center, wc, rc, center, 0, 0, q, 34, &vp8tables.DefaultMVContext, &costs, bounds, param)
					if a != b {
						t.Fatal("diamond", sz, shape, q, param, a, b)
					}
				}
			}
		}
	}
}
func BenchmarkMotionPR09(b *testing.B) {
	for _, shape := range [][2]int{{8, 8}, {4, 4}} {
		for _, which := range []string{"full", "nstep"} {
			b.Run(fmt.Sprintf("%s_%dx%d", which, shape[0], shape[1]), func(b *testing.B) {
				src, ref := motionPixelSetup(b, 128, 96)
				for y := 0; y < src.Height; y++ {
					for x := 0; x < src.Width; x++ {
						src.Y[y*src.YStride+x] = ref.Y[y*ref.YStride+min(x+1, ref.CodedWidth-1)]
					}
				}
				ctx := newSplitFullPelSearchCtx(src, ref, 2, 2, 0, shape[0], shape[1])
				var costs vp8enc.MotionVectorCostTables
				costs.Build(&vp8tables.DefaultMVContext)
				bounds := vp8enc.InterFrameFullPixelSearchBounds(vp8enc.MotionVector{}, 2, 2, 6, 8)
				center := vp8enc.MotionVector{}
				wc := ctx.fullPelCostFull(0, 0, 0, 0, 44)
				rc, _ := interMotionSplitBlockFullPixelReturnCostWithErrorPerBitAndCostTables(src, ref, 2, 2, 0, shape[0], shape[1], center, center, 34, &vp8tables.DefaultMVContext, &costs)
				b.ReportAllocs()
				for b.Loop() {
					var r splitFullPixelSearchResult
					if which == "full" {
						r = fullSearchInterFrameSplitBlockFullPixelMotionVectorWithErrorPerBitAndCostTables(&ctx, center, center, 0, 0, 44, 34, &vp8tables.DefaultMVContext, &costs, bounds, 6)
					} else {
						r = diamondNstepInterFrameSplitBlockFullPixelMotionVectorWithErrorPerBitAndCostTables(&ctx, center, wc, rc, center, 0, 0, 44, 34, &vp8tables.DefaultMVContext, &costs, bounds, 4)
					}
					motionPRMV = r.mv
					motionPRInt = r.returnCost + r.walkCost
				}
			})
		}
	}
}

func (ctx *loopFilterPickContext) motionParentPickFastNoStats(seedLevel uint8, minLevel int) (uint8, error) {
	e := ctx.encoder
	traceEnabled := oracleTraceBuild && e.oracleTraceEnabled()
	maxLevel := e.libvpxMaxLoopFilterLevelForFrame()
	ssErr := [vp8common.MaxLoopFilter + 1]int{}
	ssSet := [vp8common.MaxLoopFilter + 1]bool{}
	level := vp8enc.ClampLoopFilterPickLevel(int(seedLevel), minLevel, maxLevel)
	bestLevel := level
	bestErr := ctx.cachedPartialLumaSSE(level, &ssErr, &ssSet)
	if traceEnabled {
		e.emitOracleLFTrial("seed", level, bestErr)
	}

	filtLevel := level - vp8enc.LoopFilterSearchStep(level)
	for filtLevel >= minLevel {
		filtErr := ctx.cachedPartialLumaSSE(filtLevel, &ssErr, &ssSet)
		if traceEnabled {
			e.emitOracleLFTrial("down", filtLevel, filtErr)
		}
		if filtErr < bestErr {
			bestErr = filtErr
			bestLevel = filtLevel
		} else {
			break
		}
		filtLevel -= vp8enc.LoopFilterSearchStep(filtLevel)
	}

	filtLevel = level + vp8enc.LoopFilterSearchStep(filtLevel)
	if bestLevel == level {
		bestErr -= bestErr >> 10
		for filtLevel < maxLevel {
			filtErr := ctx.cachedPartialLumaSSE(filtLevel, &ssErr, &ssSet)
			if traceEnabled {
				e.emitOracleLFTrial("up", filtLevel, filtErr)
			}
			if filtErr < bestErr {
				bestErr = filtErr - (filtErr >> 10)
				bestLevel = filtLevel
			} else {
				break
			}
			filtLevel += vp8enc.LoopFilterSearchStep(filtLevel)
		}
	}
	return uint8(vp8enc.ClampLoopFilterPickLevel(bestLevel, minLevel, maxLevel)), nil
}

func (ctx *loopFilterPickContext) motionParentPickFullNoStats(seedLevel uint8, minLevel int) (uint8, error) {
	e := ctx.encoder
	traceEnabled := oracleTraceBuild && e.oracleTraceEnabled()
	if ctx.fullFrameConfig.SegmentationEnabled {
		e.loopFilterSegmentLF = ctx.fullFrameConfig.SegmentLF
	}
	maxLevel := e.libvpxMaxLoopFilterLevelForFrame()
	filtMid := vp8enc.ClampLoopFilterPickLevel(int(seedLevel), minLevel, maxLevel)
	filterStep := 4
	if filtMid >= 16 {
		filterStep = filtMid / 4
	}
	ssErr := [vp8common.MaxLoopFilter + 1]int{}
	ssSet := [vp8common.MaxLoopFilter + 1]bool{}
	residentLevel := -1
	bestLumaLevel := -1

	bestErr := ctx.cachedFullLumaSSE(filtMid, &ssErr, &ssSet, &residentLevel)
	if traceEnabled {
		e.emitOracleLFTrial("full", filtMid, bestErr)
	}
	filtBest := filtMid
	filtDirection := 0
	for filterStep > 0 {
		// Mirror libvpx vp8/encoder/picklpf.c vp8cx_pick_filter_level
		// (Bias = (best_err >> (15 - (filt_mid / 8))) * filter_step), then
		// scale that bias by section_intra_rating / 20 when the intra
		// rating is below 20. One-pass and realtime paths can therefore
		// use zero bias because libvpx's calloc'd two-pass state leaves
		// section_intra_rating at zero.
		bias := vp8enc.LoopFilterFullPickerBias(bestErr, filtMid, filterStep, e.twoPass.sectionIntraRating)
		filtHigh := min(filtMid+filterStep, maxLevel)
		filtLow := max(filtMid-filterStep, minLevel)

		// Parallel filt_low / filt_high trials at Threads >= 2 when this
		// iteration would otherwise run both serially (filtDirection == 0,
		// both bracket levels distinct from filtMid, neither cached). The
		// filt_low trial runs on the row-worker pool against the alt
		// scratch (loopFilterPickAlt + loopInfoAlt); the filt_high trial
		// runs inline on the calling goroutine against the resident
		// scratch (loopFilterPick + loopInfo). After both finish the
		// score-update conditionals are applied in the same serial order
		// as the non-parallel branch, so bestErr / filtBest converge
		// byte-identically to the serial run. residentLevel is set to
		// filtHigh to match the post-iteration state of the serial code.
		// loopFilterPick (resident scratch) holds the filtHigh-filtered
		// luma; loopFilterPickAlt holds the filtLow-filtered luma. If
		// filtLow becomes the new filtBest we patch loopFilterBest with
		// the alt-scratch luma so the chroma post-pass reuse decision in
		// applyReconstructionLoopFilter sees the correct preserved image
		// (mirroring the serial preserveBestBeforeTrial-before-filtHigh
		// copy that would have run had the trials been serial).
		// ssSet is [MaxLoopFilter+1=64]bool (pow2); LF trial levels are
		// clamped to [0, MaxLoopFilter]. AND-mask with 63 elides the
		// per-iter bounds check on both lookups.
		if filtDirection == 0 && filtLow != filtMid && filtHigh != filtMid &&
			!ssSet[filtLow&63] && !ssSet[filtHigh&63] && e.canParallelLFTrials() {
			ctx.preserveBestLoopFilterLumaBeforeTrial(filtLow, filtBest, &ssSet, residentLevel, &bestLumaLevel)
			filtErrLow, filtErrHigh := ctx.dispatchLFTrialPair(filtLow, filtHigh)
			// ssErr/ssSet are [MaxLoopFilter+1=64]; mask with 63 to elide
			// the bounds check on the indexed writes (matches the read
			// path above).
			ssErr[filtLow&63] = filtErrLow
			ssSet[filtLow&63] = true
			ssErr[filtHigh&63] = filtErrHigh
			ssSet[filtHigh&63] = true
			if filtHigh != 0 {
				residentLevel = filtHigh
			}
			if traceEnabled {
				e.emitOracleLFTrial("full", filtLow, filtErrLow)
				e.emitOracleLFTrial("full", filtHigh, filtErrHigh)
			}
			if filtErrLow-bias < bestErr {
				if filtErrLow < bestErr {
					bestErr = filtErrLow
				}
				filtBest = filtLow
				// Replicate the serial "preserveBestBeforeTrial(filtHigh,
				// filtBest=filtLow)" copy that would have run between
				// the two trials: residentLevel == filtBest == filtLow,
				// so loopFilterPick (which would hold the filtLow-filtered
				// luma in serial) gets copied to loopFilterBest. In
				// parallel that filtLow-filtered luma is in
				// loopFilterPickAlt instead, so we copy from there.
				if filtBest > 0 && bestLumaLevel != filtBest {
					vp8common.CopyImageLuma(&e.loopFilterBest.Img, &e.loopFilterPickAlt.Img)
					bestLumaLevel = filtBest
				}
			}
			if filtErrHigh < bestErr-bias {
				bestErr = filtErrHigh
				filtBest = filtHigh
			}
		} else {
			if filtDirection <= 0 && filtLow != filtMid {
				ctx.preserveBestLoopFilterLumaBeforeTrial(filtLow, filtBest, &ssSet, residentLevel, &bestLumaLevel)
				freshTrial := !ssSet[filtLow]
				filtErr := ctx.cachedFullLumaSSE(filtLow, &ssErr, &ssSet, &residentLevel)
				if traceEnabled && freshTrial {
					e.emitOracleLFTrial("full", filtLow, filtErr)
				}
				if filtErr-bias < bestErr {
					if filtErr < bestErr {
						bestErr = filtErr
					}
					filtBest = filtLow
				}
			}
			if filtDirection >= 0 && filtHigh != filtMid {
				ctx.preserveBestLoopFilterLumaBeforeTrial(filtHigh, filtBest, &ssSet, residentLevel, &bestLumaLevel)
				freshTrial := !ssSet[filtHigh]
				filtErr := ctx.cachedFullLumaSSE(filtHigh, &ssErr, &ssSet, &residentLevel)
				if traceEnabled && freshTrial {
					e.emitOracleLFTrial("full", filtHigh, filtErr)
				}
				if filtErr < bestErr-bias {
					bestErr = filtErr
					filtBest = filtHigh
				}
			}
		}
		if filtBest == filtMid {
			filterStep /= 2
			filtDirection = 0
		} else {
			if filtBest < filtMid {
				filtDirection = -1
			} else {
				filtDirection = 1
			}
			filtMid = filtBest
		}
	}
	if filtBest > 0 {
		switch {
		case residentLevel == filtBest:
			e.loopFilterPickReady = true
			e.loopFilterPickLevel = uint8(filtBest)
			e.loopFilterPickBest = false
		case bestLumaLevel == filtBest:
			e.loopFilterPickReady = true
			e.loopFilterPickLevel = uint8(filtBest)
			e.loopFilterPickBest = true
		}
	}
	return uint8(filtBest), nil
}

func motion10Context(tb testing.TB, varied bool) loopFilterPickContext {
	const w, h = 128, 96
	src := testImage(w, h)
	e := newSizedTestEncoder(tb, w, h)
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			v := byte(128)
			if varied {
				v = byte(40 + (y*17+x*13)%180)
			}
			src.Y[y*src.YStride+x] = v
			e.analysis.Img.Y[y*e.analysis.Img.YStride+x] = v
		}
	}
	e.analysis.ExtendBorders()
	const rows, cols = h / 16, w / 16
	if len(e.reconstructModes) < rows*cols {
		e.reconstructModes = make([]vp8dec.MacroblockMode, rows*cols)
	}
	for i := range e.reconstructModes {
		e.reconstructModes[i] = vp8dec.MacroblockMode{Mode: vp8common.NearestMV, RefFrame: vp8common.LastFrame}
	}
	return e.newLoopFilterPickContext(sourceImageFromPublic(src), vp8common.InterFrame, 0, rows, cols, rows*cols, vp8enc.SegmentationConfig{})
}
func TestMotionPR10(t *testing.T) {
	for _, varied := range []bool{false, true} {
		for _, level := range []uint8{0, 1, 8, 16, 32, 63} {
			for _, full := range []bool{false, true} {
				a, b := motion10Context(t, varied), motion10Context(t, varied)
				var got, want uint8
				var ge, we error
				if full {
					got, ge = a.pickFullNoStats(level, 0)
					want, we = b.motionParentPickFullNoStats(level, 0)
				} else {
					got, ge = a.pickFastNoStats(level, 0)
					want, we = b.motionParentPickFastNoStats(level, 0)
				}
				if got != want || ge != we {
					t.Fatal(varied, level, full, got, want, ge, we)
				}
				if a.encoder.loopFilterPickReady != b.encoder.loopFilterPickReady || a.encoder.loopFilterPickLevel != b.encoder.loopFilterPickLevel {
					t.Fatal("resident flag", varied, level, full)
				}
				if a.encoder.loopFilterPickReady {
					p, q := &a.encoder.loopFilterPick.Img, &b.encoder.loopFilterPick.Img
					if a.encoder.loopFilterPickBest {
						p = &a.encoder.loopFilterBest.Img
					}
					if b.encoder.loopFilterPickBest {
						q = &b.encoder.loopFilterBest.Img
					}
					for y := 0; y < 96; y++ {
						for x := 0; x < 128; x++ {
							if p.Y[y*p.YStride+x] != q.Y[y*q.YStride+x] {
								t.Fatal("resident pixels", varied, level, full, y, x)
							}
						}
					}
				}
			}
		}
	}
}
func BenchmarkMotionPR10(b *testing.B) {
	for _, full := range []bool{false, true} {
		b.Run(fmt.Sprint("full", full), func(b *testing.B) {
			ctx := motion10Context(b, false)
			b.ReportAllocs()
			for b.Loop() {
				var l uint8
				var e error
				if full {
					l, e = ctx.pickFullNoStats(32, 0)
				} else {
					l, e = ctx.pickFastNoStats(32, 0)
				}
				motionPRInt = int(l)
				if e != nil {
					b.Fatal(e)
				}
			}
		})
	}
}

func (ctx *splitMotionSubsetContext) motionParentSelectMotion() (vp8enc.MotionVector, vp8common.BPredictionMode, int, int, int, int, int) {
	// MBSplitOffset is [4][16]uint8: ctx.mode.Partition ∈ [0,4) and
	// ctx.subset ∈ [0,16) by upstream validation. Pow2 AND-masks
	// elide both bounds checks on this hot per-subset load.
	block := int(vp8tables.MBSplitOffset[ctx.mode.Partition&3][ctx.subset&15])
	leftMV := vp8enc.SplitLeftMV(ctx.mode, ctx.left, block)
	aboveMV := vp8enc.SplitAboveMV(ctx.mode, ctx.above, block)
	mbRows := (ctx.src.Height + 15) >> 4
	mbCols := (ctx.src.Width + 15) >> 4
	bestMV := vp8enc.MotionVector{}
	bestMode := vp8common.Zero4x4
	bestRD := maxInt()
	bestRate := 0
	bestYRate := 0
	bestDistortion := 0
	// lastTTEOB tracks the per-block-tteob from the LAST inner-loop iteration
	// that actually called vp8_encode_inter_mb_segment (i.e. wasn't UMV-
	// trapped and wasn't gated out before the call). libvpx returns this
	// side-effect via `xd->eobs[i]` because rd_check_segment never restores
	// the eobs after the winning mode is re-selected by `labels2mode`
	// (rdopt.c:1152-1158): only the entropy contexts (t_above_b/t_left_b)
	// are restored, the per-block eob registers retain the last call's
	// values, and bsi->eobs[i] = xd->eobs[i] at rdopt.c:1180 then captures
	// that stale snapshot for the segment_rd-wins path. calculate_final_rd_
	// costs reads tteob back through those stale eobs (rdopt.c:1689-1697),
	// so the SPLITMV skip-backout gate depends on the LAST-tested mode's
	// tteob, not the RD-winning mode's. Track it independently here.
	lastTTEOB := 0
	var bestAbove [4]uint8
	var bestLeft [4]uint8
	bestHasContexts := false

	tryCandidate := func(candidateMode vp8common.BPredictionMode, mv vp8enc.MotionVector) {
		// rd_check_segment applies the same UMV trap to inherited
		// LEFT/ABOVE/ZERO labels as it does to searched NEW labels.
		if !vp8enc.InterFrameUMVFullPixelInRange(mv, ctx.mbRow, ctx.mbCol, mbRows, mbCols) {
			return
		}
		rate := vp8enc.SplitSubMotionLabelRate(candidateMode, ctx.subMVRefProbs)
		rd, labelRate, labelYRate, distortion, tteob, nextAbove, nextLeft, hasContexts := ctx.candidateRD(block, mv, rate)
		lastTTEOB = tteob
		if rd < bestRD {
			bestRD = rd
			bestRate = labelRate
			bestYRate = labelYRate
			bestDistortion = distortion
			bestMV = mv
			bestMode = candidateMode
			bestAbove = nextAbove
			bestLeft = nextLeft
			bestHasContexts = hasContexts
		}
	}

	tryCandidate(vp8common.Left4x4, leftMV)
	if aboveMV != leftMV {
		tryCandidate(vp8common.Above4x4, aboveMV)
	}
	tryCandidate(vp8common.Zero4x4, vp8enc.MotionVector{})

	// libvpx: `if (best_label_rd < label_mv_thresh) break;` — the running
	// best label score is already below the per-label MV threshold, skip
	// the NEW4X4 motion search (the most expensive trial). When the gate
	// is disabled (labelMVThresh == 0) we keep the legacy behavior of
	// always running the NEW4X4 search. We compare in RDCOST space so
	// the threshold matches the libvpx rd_threshes scale.
	//
	// libvpx breaks out of the inner mode loop here BEFORE calling
	// vp8_encode_inter_mb_segment for NEW4X4 (rdopt.c:1027 is inside the
	// `if (this_mode == NEW4X4)` block and precedes the segment-encode
	// call at 1135), so the lastTTEOB carry from ZERO4X4 (or the prior
	// non-trapped mode) is what bsi->eobs sees. lastTTEOB stays untouched
	// in this branch — _not_ assigned bestTTEOB — exactly matching that
	// side-effect.
	if ctx.labelMVThresh > 0 && bestRD < ctx.labelMVThresh {
		if ctx.labelRD != nil && bestHasContexts {
			ctx.labelRD.yAbove = bestAbove
			ctx.labelRD.yLeft = bestLeft
		}
		return bestMV, bestMode, bestRD, bestRate, bestYRate, bestDistortion, lastTTEOB
	}

	errorPerBit := ctx.errorPerBit
	if errorPerBit <= 0 {
		errorPerBit = vp8enc.ErrorPerBit(ctx.qIndex)
	}
	// libvpx vp8_rd_pick_best_mbsegmentation (vp8/encoder/rdopt.c:1199-
	// 1303) runs each rd_check_segment call inside one of two branches:
	//
	//   * Best mode (cpi->compressor_speed == 0, rdopt.c:1220-1226):
	//     all four segmentations (BLOCK_16X8/8X16/8X8/4X4) execute back-
	//     to-back with x->mv_col_min/x->mv_col_max untouched at their
	//     wide MB-scope UMV window. The [best_ref_mv ± MAX_FULL_PEL_VAL]
	//     intersection block (rdopt.c:1233-1248) lives in the `else`
	//     speed-mode branch and is never reached here.
	//
	//   * Speed mode (compressor_speed != 0, rdopt.c:1227-1302): the
	//     first BLOCK_8X8 call runs against the wide UMV window, then
	//     mv_col_min/max are tightened to the intersection with
	//     [best_ref_mv ± MAX_FULL_PEL_VAL] before BLOCK_8X16/16X8/4X4
	//     and restored afterwards (rdopt.c:1297-1301).
	//
	// govpx mirrors both shapes: in best mode every partition uses the
	// wide UMV window; in speed mode only partition 2 (BLOCK_8X8) does,
	// and the secondary partitions intersect with bestRefMV±MAX_FULL_PEL_
	// VAL. Earlier code intersected the window in best mode too,
	// truncating the SPLITMV per-label diamond search at MB(0,0) frame 1
	// for partitions 0/1/3 on the 1280x720 SSIM-best cohort and biasing
	// the picker away from SPLITMV.
	var bounds vp8enc.InterFrameFullPixelBounds
	if ctx.compressorSpeed == 0 || (ctx.mode != nil && ctx.mode.Partition == 2) {
		bounds = vp8enc.InterFrameUMVOnlyFullPixelSearchBounds(ctx.mbRow, ctx.mbCol, mbRows, mbCols)
	} else {
		bounds = vp8enc.InterFrameFullPixelSearchBounds(ctx.bestRefMV, ctx.mbRow, ctx.mbCol, mbRows, mbCols)
	}
	newMV, _ := selectInterFrameSplitBlockFullPixelMotionVectorWithBounds(ctx.src, ctx.ref, ctx.mbRow, ctx.mbCol, block, ctx.width, ctx.height, ctx.searchCenter, ctx.bestRefMV, ctx.qIndex, errorPerBit, ctx.stepParam, ctx.fullSearchFallback, ctx.mvProbs, ctx.mvCosts, bounds)
	if refinedMV, _, ok := refineInterFrameSplitBlockSubpixelMotionVectorWithErrorPerBitAndCostTables(ctx.src, ctx.ref, ctx.mbRow, ctx.mbCol, block, ctx.width, ctx.height, newMV, ctx.bestRefMV, ctx.qIndex, errorPerBit, ctx.search, ctx.mvProbs, ctx.mvCosts); ok {
		newMV = refinedMV
	}
	newRate := vp8enc.SplitSubMotionLabelRate(vp8common.New4x4, ctx.subMVRefProbs)
	delta := vp8enc.MotionVector{Row: int16(int(newMV.Row) - int(ctx.bestRefMV.Row)), Col: int16(int(newMV.Col) - int(ctx.bestRefMV.Col))}
	if ctx.mvCosts != nil {
		newRate += vp8enc.SplitMotionVectorCost(delta, nil, ctx.mvCosts)
	} else {
		newRate += vp8enc.SplitMotionVectorCost(delta, ctx.mvProbs, nil)
	}
	newRD, labelRate, labelYRate, distortion, tteob, nextAbove, nextLeft, hasContexts := ctx.candidateRD(block, newMV, newRate)
	lastTTEOB = tteob
	if newRD < bestRD {
		bestRD = newRD
		bestRate = labelRate
		bestYRate = labelYRate
		bestDistortion = distortion
		bestMV = newMV
		bestMode = vp8common.New4x4
		bestAbove = nextAbove
		bestLeft = nextLeft
		bestHasContexts = hasContexts
	}
	if ctx.labelRD != nil && bestHasContexts {
		ctx.labelRD.yAbove = bestAbove
		ctx.labelRD.yLeft = bestLeft
	}

	return bestMV, bestMode, bestRD, bestRate, bestYRate, bestDistortion, lastTTEOB
}

func motion11Context(tb testing.TB, partition int, fast bool) splitMotionSubsetContext {
	src, ref, _, quant, q := splitMVDecisionRDFixture(tb)
	ev := new(splitMotionLabelRDEvaluator)
	ev.init(0, 0, nil, nil, fast, false)
	mode := &vp8enc.InterFrameMacroblockMode{Mode: vp8common.SplitMV, Partition: uint8(partition)}
	w, h := splitMotionPartitionBlockSize(partition)
	return splitMotionSubsetContext{src: src, ref: ref, mode: mode, subset: 0, width: w, height: h, qIndex: q, labelMVThresh: maxInt(), labelRD: ev, quant: &quant, coefProbs: &vp8tables.DefaultCoefProbs, mvProbs: &vp8tables.DefaultMVContext, search: defaultInterAnalysisSearchConfig(), stepParam: 7}
}
func TestMotionPR11(t *testing.T) {
	for partition := 0; partition < 4; partition++ {
		for _, fast := range []bool{false, true} {
			for _, fallback := range []bool{false, true} {
				for _, gate := range []int{0, maxInt()} {
					ctx := motion11Context(t, partition, fast)
					ctx.labelMVThresh = gate
					if fallback {
						ctx.labelRD = nil
					}
					a, b := ctx, ctx
					var ea, eb splitMotionLabelRDEvaluator
					if ctx.labelRD != nil {
						ea, eb = *ctx.labelRD, *ctx.labelRD
						a.labelRD = &ea
						b.labelRD = &eb
					}
					mv, mode, rd, rate, yr, dist, te := a.selectMotion()
					wm, wb, wr, wt, wy, wd, we := b.motionParentSelectMotion()
					if mv != wm || mode != wb || rd != wr || rate != wt || yr != wy || dist != wd || te != we || ea != eb {
						t.Fatal(partition, fast, fallback, gate, mv, mode, rd, rate, yr, dist, te, wm, wb, wr, wt, wy, wd, we, ea, eb)
					}
				}
			}
		}
	}
}
func BenchmarkMotionPR11(b *testing.B) {
	for _, part := range []int{0, 2, 3} {
		b.Run(fmt.Sprint("partition", part), func(b *testing.B) {
			ctx := motion11Context(b, part, true)
			initial := *ctx.labelRD
			b.ReportAllocs()
			for b.Loop() {
				*ctx.labelRD = initial
				mv, _, rd, rate, yr, dist, te := ctx.selectMotion()
				motionPRMV = mv
				motionPRInt = rd + rate + yr + dist + te
			}
		})
	}
}

func (ev *splitMotionLabelRDEvaluator) motionParentRateDistortion(src vp8enc.SourceImage, ref *vp8common.Image, mbRow int, mbCol int, qIndex int, quant *vp8enc.MacroblockQuant, coefProbs *vp8tables.CoefficientProbs, mode *vp8enc.InterFrameMacroblockMode, subset int, mv vp8enc.MotionVector, labelRate int) (int, int, int, int, [4]uint8, [4]uint8, bool) {
	if ev == nil || ref == nil || quant == nil || coefProbs == nil || mode == nil || mode.Partition >= vp8tables.NumMBSplits {
		return 0, 0, 0, 0, [4]uint8{}, [4]uint8{}, false
	}
	nextAbove := ev.yAbove
	nextLeft := ev.yLeft
	rate := labelRate
	yRate := 0
	distortion := 0
	tteob := 0
	for block := range 16 {
		// MBSplits is [4][16]uint8 indexed by validated Partition ∈ [0,4)
		// and block ∈ [0,16). Pow2 masks elide both bounds checks.
		if int(vp8tables.MBSplits[mode.Partition&3][block&15]) != subset {
			continue
		}
		var pred [16]byte
		if !predictSplitMotionBlock4x4(ref, mbRow, mbCol, block, mv, &pred) {
			return 0, 0, 0, 0, [4]uint8{}, [4]uint8{}, false
		}
		var input [16]int16
		fillSplitMotionResidual4x4(src, mbRow, mbCol, block, &pred, &input)
		var dct [16]int16
		var qcoeff [16]int16
		var dqcoeff [16]int16
		vp8enc.ForwardDCT4x4(input[:], 4, &dct)
		a := block & 3
		l := (block & 0x0c) >> 2
		ctx := int(nextAbove[a] + nextLeft[l])
		eob := vp8enc.QuantizeEncodedBlockWithRDZbinAndActivity(coefProbs, qIndex, 3, ctx, 0, ev.zbinOverQuant, vp8enc.SplitInterModeZbinBoost, ev.actZbinAdj, ev.zbinOverQuant, ev.rdMult, ev.rdDiv, false, ev.fastQuant, ev.optimize, &dct, &quant.Y1, &qcoeff, &dqcoeff)
		blockRate := coefficientBlockTokenRate(coefProbs, ev.coefTokenCosts, 3, ctx, 0, &qcoeff, eob)
		rate += blockRate
		yRate += blockRate
		if eob > 0 {
			tteob++
		}
		distortion += vp8enc.TransformBlockError(&dct, &dqcoeff)
		hasCoeffs := uint8(0)
		if eob > 0 {
			hasCoeffs = 1
		}
		nextAbove[a] = hasCoeffs
		nextLeft[l] = hasCoeffs
	}
	return rate, yRate, distortion >> 2, tteob, nextAbove, nextLeft, true
}

func motionParentFillInterFrameSplitSubsetWithMode(mode *vp8enc.InterFrameMacroblockMode, subset int, mv vp8enc.MotionVector, firstMode vp8common.BPredictionMode) {
	if mode == nil || mode.Partition >= vp8tables.NumMBSplits {
		return
	}
	for block := range 16 {
		// MBSplits is [4][16]uint8 indexed by validated Partition ∈ [0,4)
		// and block ∈ [0,16). Pow2 masks elide both bounds checks.
		if int(vp8tables.MBSplits[mode.Partition&3][block&15]) != subset {
			continue
		}
		bMode := firstMode
		// block-1 ∈ [0,15) and block-4 ∈ [-4,12); the guards above
		// (block&3 != 0, block>>2 != 0) ensure block-1 ≥ 0 and
		// block-4 ≥ 0 respectively. AND-mask with 15 elides bounds
		// checks on the [16]uint8 inner array.
		if block&3 != 0 && int(vp8tables.MBSplits[mode.Partition&3][(block-1)&15]) == subset {
			bMode = vp8common.Left4x4
		} else if block>>2 != 0 && int(vp8tables.MBSplits[mode.Partition&3][(block-4)&15]) == subset {
			bMode = vp8common.Above4x4
		}
		mode.BlockMV[block&15] = mv
		mode.BModes[block&15] = bMode
	}
}

var motion12Mode vp8enc.InterFrameMacroblockMode

func TestMotionPR12(t *testing.T) {
	for partition := 0; partition < 4; partition++ {
		for subset := -1; subset <= 17; subset++ {
			a := vp8enc.InterFrameMacroblockMode{Partition: uint8(partition)}
			for i := range a.BlockMV {
				a.BlockMV[i] = vp8enc.MotionVector{Row: int16(i * 19), Col: int16(i * 31)}
				a.BModes[i] = vp8common.Above4x4
			}
			b := a
			fillInterFrameSplitSubsetWithMode(&a, subset, vp8enc.MotionVector{Row: -32, Col: 24}, vp8common.New4x4)
			motionParentFillInterFrameSplitSubsetWithMode(&b, subset, vp8enc.MotionVector{Row: -32, Col: 24}, vp8common.New4x4)
			if a != b {
				t.Fatal("fill", partition, subset, a, b)
			}
			src, ref, _, quant, q := splitMVDecisionRDFixture(t)
			mode := vp8enc.InterFrameMacroblockMode{Partition: uint8(partition)}
			var ev splitMotionLabelRDEvaluator
			ev.init(0, 0, nil, nil, false, false)
			r, y, d, te, ab, le, ok := ev.rateDistortion(src, ref, 0, 0, q, &quant, &vp8tables.DefaultCoefProbs, &mode, subset, vp8enc.MotionVector{}, 37)
			wr, wy, wd, we, wa, wl, wok := ev.motionParentRateDistortion(src, ref, 0, 0, q, &quant, &vp8tables.DefaultCoefProbs, &mode, subset, vp8enc.MotionVector{}, 37)
			if r != wr || y != wy || d != wd || te != we || ab != wa || le != wl || ok != wok {
				t.Fatal("score", partition, subset, r, y, d, te, ab, le, ok, wr, wy, wd, we, wa, wl, wok)
			}
		}
	}
}
func BenchmarkMotionPR12(b *testing.B) {
	for _, p := range []int{0, 1, 2, 3} {
		b.Run(fmt.Sprint("fill", p), func(b *testing.B) {
			mode := vp8enc.InterFrameMacroblockMode{Partition: uint8(p)}
			b.ReportAllocs()
			for b.Loop() {
				fillInterFrameSplitSubsetWithMode(&mode, 0, vp8enc.MotionVector{Row: -32, Col: 24}, vp8common.New4x4)
				motion12Mode = mode
			}
		})
	}
	b.Run("score4x4", func(b *testing.B) {
		src, ref, _, quant, q := splitMVDecisionRDFixture(b)
		mode := vp8enc.InterFrameMacroblockMode{Partition: 3}
		var ev splitMotionLabelRDEvaluator
		ev.init(0, 0, nil, nil, true, false)
		b.ReportAllocs()
		for b.Loop() {
			r, y, d, te, _, _, ok := ev.rateDistortion(src, ref, 0, 0, q, &quant, &vp8tables.DefaultCoefProbs, &mode, 0, vp8enc.MotionVector{}, 37)
			if !ok {
				b.Fatal("invalid")
			}
			motionPRInt = r + y + d + te
		}
	})
}

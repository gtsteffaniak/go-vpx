from pathlib import Path
import subprocess,json,os,re
R=Path('/Users/thesyncim/GolandProjects/govpx');D=Path('/private/tmp/govpx-pr-publication');E=os.environ|{'CODEX_AGENT_ID':'fifty-final','CODEX_PROJECT_CACHE_ROOT':'/private/tmp/codex-projects','GOTOOLCHAIN':'local','GO':'/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go','GOEXPERIMENT':'simd','GOMAXPROCS':'2','GOFLAGS':'-p=2','CGO_ENABLED':'1'}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='715645fd212cfc65295f4f6fb1002dcc60856758'
selectors=json.loads((D/'final-focused-selectors.json').read_text());records=[]
for k,(pkg,selector) in enumerate(selectors.items()):
 cmd=[str(R/'scripts/go.sh'),'test','-pgo=off',pkg,'-run',selector,'-count=1','-v'];log=D/f'final-focused-{k}.log'
 with log.open('w') as f:p=subprocess.run(cmd,cwd=R,env=E,stdout=f,stderr=subprocess.STDOUT)
 s=log.read_text();expect=selector[2:-2].split('|');passed=re.findall(r'^--- PASS: (\w+) ',s,re.M)
 assert p.returncode==0 and set(expect)<=set(passed),(pkg,p.returncode,set(expect)-set(passed),s[-3000:])
 records.append({'package':pkg,'command':cmd,'tests':len(expect),'PASS':True,'log':str(log)});print(pkg,len(expect),'focused checks PASS',flush=True)
(D/'final-focused-receipt.json').write_text(json.dumps({'head':'715645fd212cfc65295f4f6fb1002dcc60856758','scope':'Only the 56 exact tests from the 50 published fixtures and root packet streams; no full suite.','checks':records},indent=2)+'\n')
cmd=[str(R/'scripts/go.sh'),'build','-pgo=off','-o',str(D/'fifty-main-whole'),'./cmd/govpx-bench']
with (D/'fifty-main-whole-build.log').open('w') as f:p=subprocess.run(cmd,cwd=R,env=E,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0;print('short codec binary ready',flush=True)

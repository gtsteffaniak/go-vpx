from pathlib import Path
import subprocess,os,json,hashlib,statistics
D=Path('/private/tmp/govpx-pr-publication');O=D/'whole-short';O.mkdir(exist_ok=True);refs={'fixed-c4':Path('/private/tmp/govpx-iterations50/base-whole'),'parent98':Path('/private/tmp/govpx-iterations100/final-whole'),'merged':D/'fifty-main-whole'};env=os.environ|{'GOMAXPROCS':'1'}
workloads={'vp8-720':['-codec=vp8','-width=1280','-height=720','-frames=60','-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8'],'vp9-320':['-codec=vp9','-width=320','-height=180','-frames=120','-fps=30','-bitrate=500','-mode=realtime','-cpu-used=8'],'vp9-720':['-codec=vp9','-width=1280','-height=720','-frames=60','-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8']}
assert hashlib.sha256(refs['fixed-c4'].read_bytes()).hexdigest()=='23d0f2aff65664610bb3c54795851a7b5b02078818dcab45beaa9f37978e9320'
assert hashlib.sha256(refs['parent98'].read_bytes()).hexdigest()=='34253d4ef62929205c818ddc7293376b9277391dee5524e55a8564d932017b1a'
(O/'binding.json').write_text(json.dumps({'scope':'Preliminary native M4 Max; three-way balanced short screen, two samples/reference/workload, no C/quality/profile/full matrix. PGOoff/CGO1/GOMAXPROCS1/Go1.27.2SIMD.','merged':'715645fd212cfc65295f4f6fb1002dcc60856758','parent98':'98aa69f178b8f3213c25dc1b1475f57b30f9621e; same production7cc tree','fixed':'c4a8bd9f66805fc9b7b4f99e26752cc68505e572','binaries':{k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in refs.items()}},indent=2)+'\n')
rows=[]
for rnd,order in enumerate([['fixed-c4','parent98','merged'],['merged','parent98','fixed-c4']],1):
 for scope,args in workloads.items():
  for name in order:
   cmd=[str(refs[name])]+args+['-threads=1','-encode-only','-auto-libvpx=false','-format=json'];log=O/f'r{rnd}-{scope}-{name}.json'
   with log.open('w') as f,log.with_suffix('.stderr').open('w') as err:p=subprocess.run(cmd,cwd=D,env=env,stdout=f,stderr=err)
   assert p.returncode==0,(scope,name);value=json.loads(log.read_text());rows.append({'round':rnd,'scope':scope,'reference':name,'command':cmd,'value':value});print(rnd,scope,name,value['ns_per_frame'],flush=True)
perf={'ns_per_frame','encode_fps','macroblocks_per_second','allocs_per_frame','latency_ns'};summaries={}
for scope in workloads:
 summaries[scope]={}
 for ref in ['fixed-c4','parent98']:
  ratios=[];alloc=[]
  for rnd in [1,2]:
   a=next(x['value'] for x in rows if x['round']==rnd and x['scope']==scope and x['reference']==ref);b=next(x['value'] for x in rows if x['round']==rnd and x['scope']==scope and x['reference']=='merged');sa={k:v for k,v in a.items() if k not in perf};sb={k:v for k,v in b.items() if k not in perf};assert sa==sb,(scope,rnd,ref,{k:(sa.get(k),sb.get(k)) for k in sa.keys()|sb.keys() if sa.get(k)!=sb.get(k)});ratios.append(a['ns_per_frame']/b['ns_per_frame']);alloc.append([a['allocs_per_frame'],b['allocs_per_frame']])
  summaries[scope][ref]={'paired_speedups':ratios,'median_speedup':statistics.median(ratios),'semantic_equal':True,'semantic_fields':len(sa),'allocations_pairs':alloc,'preliminary':True}
(O/'summary.json').write_text(json.dumps({'summary':summaries,'rows':rows},indent=2)+'\n');print(json.dumps(summaries,sort_keys=True),flush=True)

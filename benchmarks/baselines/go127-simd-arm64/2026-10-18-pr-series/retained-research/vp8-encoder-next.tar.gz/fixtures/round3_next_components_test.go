package encoder

import (
	"bytes"
	"fmt"
	"github.com/thesyncim/govpx/internal/vp8/common"
	"github.com/thesyncim/govpx/internal/vp8/tables"
	vp8tables "github.com/thesyncim/govpx/internal/vp8/tables"
	"reflect"
	"testing"
	"unsafe"
)

func r4Frozen_countBlockCoefficientTokensAndRecords(counts *coefficientTokenCounts, records *InterCoefficientTokenRecords, blockType int, ctx int, skipDC int, qcoeff *[16]int16, eob int) error {
	// Records-nil callers (e.g. probability-only update passes) re-enter
	// the cheaper count-only path; the per-coefficient nil check that
	// previously sat inside appendTokenUnchecked is hoisted once here.
	if records == nil {
		return countBlockCoefficientTokens(counts, blockType, ctx, skipDC, qcoeff, eob)
	}
	// Uint range checks collapse the (x < 0 || x >= max) dual-bound
	// pairs into one branch each. Hot per-block validation.
	if counts == nil || qcoeff == nil ||
		uint(blockType) >= uint(tables.BlockTypes) ||
		uint(ctx) >= uint(tables.PrevCoefContexts) ||
		uint(skipDC) > 1 {
		return ErrInvalidPacketConfig
	}
	if eob <= skipDC {
		(*counts)[blockType][skipDC][ctx][tables.DCTEOBToken]++
		records.appendTokenUnchecked(blockType, skipDC, ctx, tables.DCTEOBToken, 0, 0, false)
		return nil
	}
	if eob > 16 {
		return ErrInvalidPacketConfig
	}

	band := skipDC
	tokenCtx := ctx
	skipEOBNode := false
	for pos := skipDC; pos < eob; pos++ {
		// DefaultZigZag1D returns a permutation of 0..15. Mask the uint8
		// lookup result so the compiler can elide the bounds check on
		// qcoeff[rc] (qcoeff is *[16]int16).
		rc := tables.DefaultZigZag1D[pos] & 0xF
		coeff := int(qcoeff[rc])
		// Branchless |coeff| split into magnitude and sign nibble: signMask
		// is -1 when coeff is negative, 0 otherwise.
		signMask := coeff >> intSignShift
		mag := (coeff ^ signMask) - signMask
		sign := uint8(signMask & 1)
		// Uint range check folds the (mag < 0) guard the int comparison
		// could not eliminate (signed-overflow possibility) and yields a
		// proven [0, DCTMaxValue] for the LUT load below.
		if uint(mag) > uint(tables.DCTMaxValue) {
			return ErrInvalidPacketConfig
		}
		token := int(coeffAbsTokenLUT[mag])
		// blockType and band were validated to [0,3] and the LUT yields
		// 0..7 for band. AND-mask both so BlockTypes(=4) and
		// CoefBands(=8) bounds checks elide (both are powers of two).
		(*counts)[blockType&3][band&7][tokenCtx][token]++
		// records guaranteed non-nil by the entry branch above, so the
		// per-coefficient nil check inside appendTokenUnchecked has been
		// dropped (it is the hot-path unchecked variant by contract).
		records.appendTokenUnchecked(blockType, band, tokenCtx, token, mag, sign, skipEOBNode)
		if pos+1 < 16 {
			band = int(tables.CoefBandsTable[pos+1])
			tokenCtx = int(tables.PrevTokenClass[token])
			skipEOBNode = tokenCtx == 0
		}
	}
	if eob < 16 {
		(*counts)[blockType&3][band&7][tokenCtx][tables.DCTEOBToken]++
		records.appendTokenUnchecked(blockType, band, tokenCtx, tables.DCTEOBToken, 0, 0, false)
	}
	return nil
}

func r4Frozen_countCoefficientMacroblockTokensAndRecords(is4x4 bool, above *TokenContextPlanes, left *TokenContextPlanes, coeffs *MacroblockCoefficients, counts *coefficientTokenCounts, records *InterCoefficientTokenRecords) error {
	if records == nil {
		return countCoefficientMacroblockTokens(is4x4, above, left, coeffs, counts)
	}
	if above == nil || left == nil || coeffs == nil || counts == nil {
		return ErrInvalidPacketConfig
	}
	blockType := 0
	skipDC := 0
	if !is4x4 {
		eob := coeffs.BlockEOB(24, 0)
		ctx := int(above.Y2 + left.Y2)
		if ctx >= tables.PrevCoefContexts {
			return ErrInvalidPacketConfig
		}
		if eob <= 0 {
			// Macroblock entry and context checks already prove these arguments.
			(*counts)[1][0][ctx][tables.DCTEOBToken]++
			records.appendTokenUnchecked(1, 0, ctx, tables.DCTEOBToken, 0, 0, false)
		} else if err := r4Frozen_countBlockCoefficientTokensAndRecords(counts, records, 1, ctx, 0, &coeffs.QCoeff[24], eob); err != nil {
			return err
		}
		hasCoeffs := uint8(0)
		if eob > 0 {
			hasCoeffs = 1
		}
		above.Y2 = hasCoeffs
		left.Y2 = hasCoeffs

		blockType = 0
		skipDC = 1
	} else {
		blockType = 3
	}

	if !zeroY1TokenRecords(above, left, coeffs, counts, records, blockType, skipDC) {
		for block := range 16 {
			eob := coeffs.BlockEOB(block, skipDC)
			a := block & 3
			l := (block & 0x0c) >> 2
			ctx := int(above.Y1[a] + left.Y1[l])
			if ctx >= tables.PrevCoefContexts {
				return ErrInvalidPacketConfig
			}
			if eob <= skipDC {
				// Macroblock entry and context checks already prove these arguments.
				(*counts)[blockType][skipDC][ctx][tables.DCTEOBToken]++
				records.appendTokenUnchecked(blockType, skipDC, ctx, tables.DCTEOBToken, 0, 0, false)
			} else if err := r4Frozen_countBlockCoefficientTokensAndRecords(counts, records, blockType, ctx, skipDC, &coeffs.QCoeff[block], eob); err != nil {
				return err
			}
			hasCoeffs := uint8(0)
			if eob > skipDC {
				hasCoeffs = 1
			}
			above.Y1[a] = hasCoeffs
			left.Y1[l] = hasCoeffs
		}

	}

	for block := 16; block < 24; block++ {
		eob := coeffs.BlockEOB(block, 0)
		a, l := common.UVTokenContextIndex(block)
		ctx := int(getTokenUVContext(above, a) + getTokenUVContext(left, l))
		if ctx >= tables.PrevCoefContexts {
			return ErrInvalidPacketConfig
		}
		if eob <= 0 {
			// Macroblock entry and context checks already prove these arguments.
			(*counts)[2][0][ctx][tables.DCTEOBToken]++
			records.appendTokenUnchecked(2, 0, ctx, tables.DCTEOBToken, 0, 0, false)
		} else if err := r4Frozen_countBlockCoefficientTokensAndRecords(counts, records, 2, ctx, 0, &coeffs.QCoeff[block], eob); err != nil {
			return err
		}
		hasCoeffs := uint8(0)
		if eob > 0 {
			hasCoeffs = 1
		}
		setTokenUVContext(above, a, hasCoeffs)
		setTokenUVContext(left, l, hasCoeffs)
	}
	return nil
}

func r4Frozen_BlockCoeffEOB(qcoeff *[16]int16, skipDC int) int {
	for pos := 15; pos >= skipDC; pos-- {
		rc := int(tables.DefaultZigZag1D[pos])
		if qcoeff[rc] != 0 {
			return pos + 1
		}
	}
	return skipDC
}

func r4Frozen_QuantizeBlockWithZbinAndActivity(coeff *[16]int16, quant *BlockQuant, zbinOverQuant int, zbinModeBoost int, actZbinAdj int, qcoeff *[16]int16, dqcoeff *[16]int16) int {
	if coeff == nil || quant == nil || qcoeff == nil || dqcoeff == nil {
		return 0
	}
	eob := -1
	zeroRun := 0
	for pos := range 16 {
		// DefaultZigZag1D is [16]uint8 with values 0..15; coeff/qcoeff/
		// dqcoeff/quant.Zbin/ZbinBoost are all [16]-sized. Mask rc and
		// zeroRun with 15 (pow2-1) so the compiler can elide the per-iter
		// bounds checks on the indexed loads/stores. zeroRun is clamped
		// to ≤ 15 by min(zeroRun+1, 15) below so the mask is a no-op.
		rc := int(vp8tables.DefaultZigZag1D[pos]) & 15
		z := int(coeff[rc])
		if z == 0 {
			qcoeff[rc] = 0
			dqcoeff[rc] = 0
			zeroRun = min(zeroRun+1, 15)
			continue
		}

		// Branchless |z| via sign mask: sign is -1 when z<0, 0 otherwise.
		sign := z >> intSignShift
		x := (z ^ sign) - sign
		zbin := int(quant.Zbin[rc])
		zbin += int(quant.ZbinBoost[zeroRun&15])
		zbin += (int(quant.Dequant[1]) * (zbinOverQuant + zbinModeBoost + actZbinAdj)) >> 7
		if x < zbin {
			qcoeff[rc] = 0
			dqcoeff[rc] = 0
			zeroRun = min(zeroRun+1, 15)
			continue
		}

		x += int(quant.Round[rc])
		y := ((((x * int(quant.Quant[rc])) >> 16) + x) * int(quant.QuantShift[rc])) >> 16
		y = (y ^ sign) - sign
		q := int16(y)
		qcoeff[rc] = q
		dqcoeff[rc] = q * quant.Dequant[rc]
		if y != 0 {
			eob = pos
			zeroRun = 0
		} else {
			zeroRun = min(zeroRun+1, 15)
		}
	}
	return eob + 1
}

func r4Frozen_MacroblockMeanLumaSSE(src SourceImage, mbRow int, mbCol int) int {
	baseY := mbRow * 16
	baseX := mbCol * 16
	sum := 0
	sse := 0
	for row := range 16 {
		srcY := clampSourceCoord(baseY+row, src.Height)
		for col := range 16 {
			srcX := clampSourceCoord(baseX+col, src.Width)
			v := int(src.Y[srcY*src.YStride+srcX])
			sum += v
			sse += v * v
		}
	}
	variance := sse - int((int64(sum)*int64(sum)+128)>>8)
	if variance < 0 {
		return 0
	}
	return variance
}

func r4Frozen_GatherClampedLumaBlock(src SourceImage, baseY int, baseX int, width int, height int, dst []byte, dstStride int) {
	if min(width, height) <= 0 || src.Width <= 0 || src.Height <= 0 {
		return
	}
	srcY := src.Y
	srcStride := src.YStride
	fullX := baseX >= 0 && baseX+width <= src.Width
	var srcXs [16]int
	precomputedX := !fullX && width <= len(srcXs)
	if precomputedX {
		for col := range width {
			srcXs[col] = clampEncodeCoord(baseX+col, src.Width)
		}
	}
	for row := range height {
		y := clampEncodeCoord(baseY+row, src.Height)
		dstRow := row * dstStride
		srcRow := y * srcStride
		if fullX {
			copy(dst[dstRow:dstRow+width], srcY[srcRow+baseX:srcRow+baseX+width])
			continue
		}
		if precomputedX {
			for col := range width {
				dst[dstRow+col] = srcY[srcRow+srcXs[col]]
			}
		} else {
			for col := range width {
				srcX := clampEncodeCoord(baseX+col, src.Width)
				dst[dstRow+col] = srcY[srcRow+srcX]
			}
		}
	}
}

func r4Frozen_padPlaneVisibleToCoded(plane []byte, stride int, width int, height int, codedWidth int, codedHeight int) {
	if width <= 0 || height <= 0 {
		return
	}
	for y := range height {
		row := plane[y*stride:]
		last := row[width-1]
		for x := width; x < codedWidth; x++ {
			row[x] = last
		}
	}
	lastRow := plane[(height-1)*stride:]
	for y := height; y < codedHeight; y++ {
		copy(plane[y*stride:y*stride+codedWidth], lastRow[:codedWidth])
	}
}
func r4Capture(fn func()) (pan string) {
	defer func() {
		if p := recover(); p != nil {
			pan = fmt.Sprint(p)
		}
	}()
	fn()
	return
}
func r4Coeff(pattern string) MacroblockCoefficients {
	var c MacroblockCoefficients
	for block := range 25 {
		for j := range 16 {
			switch pattern {
			case "zero":
			case "lumaOnly":
				if block < 16 && j == 1 {
					c.QCoeff[block][j] = int16(block%3 + 1)
				}
			case "denseSmall":
				c.QCoeff[block][j] = int16((block+j)%3 - 1)
			case "denseMixed":
				c.QCoeff[block][j] = int16((block*17+j*13)%2049 - 1024)
			}
		}
	}
	setAllMacroblockEOBs(&c, false)
	return c
}
func TestR4Count(t *testing.T) {
	n := 0
	for _, pattern := range []string{"zero", "lumaOnly", "denseSmall", "denseMixed"} {
		for _, is4 := range []bool{false, true} {
			for _, capacity := range []int{0, 1, 7, 8, 15, 64, 1024} {
				for _, ctx := range []byte{0, 1, 255} {
					a, b := r4Coeff(pattern), r4Coeff(pattern)
					if is4 {
						setAllMacroblockEOBs(&a, true)
						b = a
					}
					var ac, bc coefficientTokenCounts
					aa, al := TokenContextPlanes{Y2: ctx}, TokenContextPlanes{}
					ba, bl := aa, al
					ar := InterCoefficientTokenRecords{Records: make([]CoefficientTokenRecord, 0, capacity)}
					br := InterCoefficientTokenRecords{Records: make([]CoefficientTokenRecord, 0, capacity)}
					var ae, be error
					ap := r4Capture(func() { ae = AccumulateInterMacroblockTokenCountsAndRecords(&ac, &ar, is4, &aa, &al, &a) })
					bp := r4Capture(func() { be = r4Frozen_countCoefficientMacroblockTokensAndRecords(is4, &ba, &bl, &b, &bc, &br) })
					if ap != bp || ae != be || ac != bc || aa != ba || al != bl || a != b || !reflect.DeepEqual(ar.Records, br.Records) {
						t.Fatalf("%s is4%v cap%d ctx%d panic%q/%q err%v/%v", pattern, is4, capacity, ctx, ap, bp, ae, be)
					}
					n++
				}
			}
		}
	}
	t.Logf("%d full macro state/error/partial-panic cases", n)
}
func TestR4EOB(t *testing.T) {
	for _, skip := range []int{-1, 0, 1, 2, 15, 16, 17} {
		for pos := -1; pos < 16; pos++ {
			var c [16]int16
			if pos >= 0 {
				c[pos] = 1
			}
			for _, v := range []int16{1, -1, 32767, -32768} {
				if pos >= 0 {
					c[pos] = v
				}
				a, b := 0, 0
				ap := r4Capture(func() { a = BlockCoeffEOB(&c, skip) })
				bp := r4Capture(func() { b = r4Frozen_BlockCoeffEOB(&c, skip) })
				if a != b || ap != bp {
					t.Fatalf("skip%d pos%d got%d/%q want%d/%q", skip, pos, a, ap, b, bp)
				}
			}
		}
	}
}
func r4Quant() BlockQuant {
	var d [16]int16
	for i := range d {
		d[i] = 32
	}
	var q BlockQuant
	InitRegularBlockQuant(64, &d, &q)
	return q
}
func TestR4Quant(t *testing.T) {
	n := 0
	for _, qo := range []int{0, 16, 32, 96, 192} {
		for _, do := range []int{0, 1, 96, 224} {
			for _, seed := range []int{0, 1, 255, 32767} {
				var a, b [512]int16
				qa := (*BlockQuant)(unsafe.Pointer(&a[0]))
				*qa = r4Quant()
				for i := 0; i < 16; i++ {
					a[160+i] = int16((i*97+seed)%65536 - 32768)
				}
				b = a
				qb := (*BlockQuant)(unsafe.Pointer(&b[0]))
				oa := (*[16]int16)(unsafe.Pointer(&a[qo]))
				ob := (*[16]int16)(unsafe.Pointer(&b[qo]))
				da := (*[16]int16)(unsafe.Pointer(&a[do]))
				db := (*[16]int16)(unsafe.Pointer(&b[do]))
				ca, cb := (*[16]int16)(unsafe.Pointer(&a[160])), (*[16]int16)(unsafe.Pointer(&b[160]))
				x := QuantizeBlockWithZbinAndActivity(ca, qa, 31, -7, 13, oa, da)
				y := r4Frozen_QuantizeBlockWithZbinAndActivity(cb, qb, 31, -7, 13, ob, db)
				if x != y || a != b {
					t.Fatalf("q%d d%d seed%d", qo, do, seed)
				}
				n++
			}
		}
	}
	t.Logf("%d quantizer/output alias states", n)
}
func TestR4Mean(t *testing.T) {
	for _, dim := range []int{1, 15, 16, 17, 32, 65} {
		for _, pad := range []int{0, 13} {
			stride := dim + pad
			src := SourceImage{Width: dim, Height: dim, YStride: stride, Y: make([]byte, stride*dim)}
			for i := range src.Y {
				src.Y[i] = byte(i*73 + 19)
			}
			for row := -1; row < 5; row++ {
				for col := -1; col < 5; col++ {
					a := MacroblockMeanLumaSSE(src, row, col)
					b := r4Frozen_MacroblockMeanLumaSSE(src, row, col)
					if a != b {
						t.Fatalf("dim%d stride%d mb%d/%d", dim, stride, row, col)
					}
				}
			}
		}
	}
}
func TestR4Gather(t *testing.T) {
	n := 0
	for _, dy := range []int{-32, -16, -1, 0, 31, 32, 40, int(^uint(0) >> 1)} {
		for _, dx := range []int{-3, 0, 16, 30, int(^uint(0) >> 1)} {
			for _, off := range []int{0, 1, 900, 2048} {
				for _, short := range []int{0, 1} {
					var a, b [4096]byte
					for i := range a {
						a[i] = byte(i*73 + 29)
						b[i] = a[i]
					}
					sa := SourceImage{Width: 32, Height: 32, YStride: 32, Y: a[:1024:1024]}
					sb := sa
					sb.Y = b[:1024:1024]
					size := 15*32 + 16 - short
					da, db := a[off:off+size:off+size], b[off:off+size:off+size]
					ap := r4Capture(func() { GatherClampedLumaBlock(sa, dy, dx, 16, 16, da, 32) })
					bp := r4Capture(func() { r4Frozen_GatherClampedLumaBlock(sb, dy, dx, 16, 16, db, 32) })
					if ap != bp || a != b {
						t.Fatalf("dy%d dx%d off%d short%d %q/%q", dy, dx, off, short, ap, bp)
					}
					n++
				}
			}
		}
	}
	t.Logf("%d full backing gather/partial panic states", n)
}
func TestR4Padding(t *testing.T) {
	n := 0
	for _, width := range []int{1, 7, 15, 16, 17, 31} {
		for _, extra := range []int{0, 1, 7, 8, 15, 16, 31} {
			cw := width + extra
			for _, stride := range []int{0, width - 1, cw, cw + 7} {
				for _, sz := range []int{0, 7, 63, 511, 1024} {
					a, b := make([]byte, sz), make([]byte, sz)
					for i := range a {
						a[i] = byte(i*73 + 11)
						b[i] = a[i]
					}
					ap := r4Capture(func() { padPlaneVisibleToCoded(a, stride, width, 7, cw, 8) })
					bp := r4Capture(func() { r4Frozen_padPlaneVisibleToCoded(b, stride, width, 7, cw, 8) })
					if ap != bp || !bytes.Equal(a, b) {
						t.Fatalf("w%d cw%d stride%d len%d %q/%q", width, cw, stride, sz, ap, bp)
					}
					n++
				}
			}
		}
	}
	t.Logf("%d padding full state/panic scenarios", n)
}
func BenchmarkR4Components(b *testing.B) {
	for _, pattern := range []string{"zero", "lumaOnly", "denseSmall", "denseMixed"} {
		b.Run("Count/"+pattern, func(b *testing.B) {
			c := r4Coeff(pattern)
			var ac, wc coefficientTokenCounts
			var a, l, wa, wl TokenContextPlanes
			ar := InterCoefficientTokenRecords{Records: make([]CoefficientTokenRecord, 0, 1024)}
			wr := InterCoefficientTokenRecords{Records: make([]CoefficientTokenRecord, 0, 1024)}
			if r4Frozen_countCoefficientMacroblockTokensAndRecords(false, &wa, &wl, &c, &wc, &wr) != nil {
				b.Fatal("oracle")
			}
			b.ReportAllocs()
			for b.Loop() {
				a, l = TokenContextPlanes{}, TokenContextPlanes{}
				ar.Records = ar.Records[:0]
				if AccumulateInterMacroblockTokenCountsAndRecords(&ac, &ar, false, &a, &l, &c) != nil {
					b.Fatal("count")
				}
			}
			if a != wa || l != wl || !reflect.DeepEqual(ar.Records, wr.Records) {
				b.Fatal("state")
			}
			for i := range ac {
				for j := range ac[i] {
					for k := range ac[i][j] {
						for m := range ac[i][j][k] {
							if ac[i][j][k][m] != wc[i][j][k][m]*b.N {
								b.Fatal("counts")
							}
						}
					}
				}
			}
			r3Sink += uint64(len(ar.Records))
		})
	}
	for _, pos := range []int{-1, 0, 15} {
		b.Run(fmt.Sprintf("EOB/pos%d", pos), func(b *testing.B) {
			var c [16]int16
			if pos >= 0 {
				c[pos] = 7
			}
			out := 0
			b.ReportAllocs()
			for b.Loop() {
				out = BlockCoeffEOB(&c, 0)
			}
			if out != r4Frozen_BlockCoeffEOB(&c, 0) {
				b.Fatal("eob")
			}
			r3Sink += uint64(out)
		})
	}
	for _, pattern := range []string{"zero", "sparse", "dense"} {
		b.Run("Quant/"+pattern, func(b *testing.B) {
			q := r4Quant()
			var c, out, dq, want, wdq [16]int16
			for i := range c {
				if pattern == "dense" {
					c[i] = int16(i*37 - 127)
				} else if pattern == "sparse" && i%5 == 0 {
					c[i] = int16(i*37 + 7)
				}
			}
			eob := 0
			wantEOB := r4Frozen_QuantizeBlockWithZbinAndActivity(&c, &q, 31, 7, 13, &want, &wdq)
			b.ReportAllocs()
			for b.Loop() {
				eob = QuantizeBlockWithZbinAndActivity(&c, &q, 31, 7, 13, &out, &dq)
			}
			if eob != wantEOB || out != want || dq != wdq {
				b.Fatal("quant")
			}
			r3Sink += uint64(eob)
		})
	}
	for _, dim := range []int{16, 17, 32} {
		b.Run(fmt.Sprintf("Mean/dim%d", dim), func(b *testing.B) {
			s := SourceImage{Width: dim, Height: dim, YStride: dim, Y: make([]byte, dim*dim)}
			for i := range s.Y {
				s.Y[i] = byte(i*17 + 29)
			}
			v := 0
			b.ReportAllocs()
			for b.Loop() {
				v = MacroblockMeanLumaSSE(s, 0, 0)
			}
			if v != r4Frozen_MacroblockMeanLumaSSE(s, 0, 0) {
				b.Fatal("mean")
			}
			r3Sink += uint64(v)
		})
	}
	for _, y := range []int{-16, 0, 31} {
		b.Run(fmt.Sprintf("Gather/y%d", y), func(b *testing.B) {
			s := SourceImage{Width: 32, Height: 32, YStride: 32, Y: make([]byte, 1024)}
			for i := range s.Y {
				s.Y[i] = byte(i*17 + 29)
			}
			var out, want [256]byte
			r4Frozen_GatherClampedLumaBlock(s, y, 0, 16, 16, want[:], 16)
			b.ReportAllocs()
			for b.Loop() {
				GatherClampedLumaBlock(s, y, 0, 16, 16, out[:], 16)
			}
			if out != want {
				b.Fatal("gather")
			}
			r3Sink += uint64(out[17])
		})
	}
	for _, width := range []int{17, 25, 32} {
		b.Run(fmt.Sprintf("Padding/w%d", width), func(b *testing.B) {
			var a, bb [1024]byte
			for i := range a {
				a[i] = byte(i*17 + 29)
				bb[i] = a[i]
			}
			r4Frozen_padPlaneVisibleToCoded(bb[:], 32, width, 16, 32, 16)
			b.ReportAllocs()
			for b.Loop() {
				padPlaneVisibleToCoded(a[:], 32, width, 16, 32, 16)
			}
			if a != bb {
				b.Fatal("padding")
			}
			r3Sink += uint64(a[31])
		})
	}
}

# ARM VP8 encoder component hypotheses

Pinned baseline: `870699ce83f3eb6de44f507ef29f6d6a429e916d`. Eight independent variants. All affected correctness checks PASS. No throughput timing or qualifying-gain claim. ROOT source/Git untouched.

| ID | Candidate | Correctness | Suggested live benchmark |
|---|---|---|---|
|111|normalized-token-bits|build 0, test 0|`^BenchmarkR3Components/Writer`|
|112|branch-subtree-sums|build 0, test 0|`^BenchmarkR3Components/Branches`|
|113|cost-table-prefix-dag|build 0, test 0|`^BenchmarkR3Components/CostFill`|
|114|terminal-token-contexts|build 0, test 0|`^BenchmarkR3Components/Contexts`|
|115|skippable-eob-words|build 0, test 0|`^BenchmarkR3Components/Skippable`|
|116|direct-token-path-cost|build 0, test 0|`^BenchmarkR3Components/DirectCost`|
|117|zero-zbin-rd-lookup|build 0, test 0|`^BenchmarkR3Components/RD`|
|118|contiguous-reference-equality|build 0, test 0|`^BenchmarkR3Components/Plane`|

Use `parent.test` and each `<id>.test` with the same benchmark regex, `GOMAXPROCS=1`, `-test.run=^$ -test.benchtime=40ms -test.benchmem`. Parent owns ABBA ordering and timing. Tests use exact frozen original functions, full coder state/backing, coefficient-tree outputs, context alias backing and boundary inputs. The shared B.Loop fixture checks frozen outputs after the loop and exports a live sink.

Raw compile/test logs, commands/environment and executable digests are in `build-receipts.json`; source overlay maps, patches and benchmark selectors are in `manifest.json`. Executables remain private, not intended for repository publication.

The initial preparation failed on the host Python tarfile API (`filter` unsupported); `prepare.py` was corrected to extract the trusted pinned Git archive. No production compile or correctness failures occurred.

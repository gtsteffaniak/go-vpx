package govpx

import (
	"fmt"
	vp8common "github.com/thesyncim/govpx/internal/vp8/common"
	"github.com/thesyncim/govpx/internal/vp8/dsp"
	vp8enc "github.com/thesyncim/govpx/internal/vp8/encoder"
	vp8tables "github.com/thesyncim/govpx/internal/vp8/tables"
	"math/rand"
	"testing"
)

func (e *VP8Encoder) motionParentImprovedInterFrameSearchStart(
	src vp8enc.SourceImage, refFrame vp8common.MVReferenceFrame,
	mbRow int, mbCol int, mbRows int, mbCols int,
	above *vp8enc.InterFrameMacroblockMode, left *vp8enc.InterFrameMacroblockMode, aboveLeft *vp8enc.InterFrameMacroblockMode,
	search interAnalysisSearchConfig,
	sadCache *improvedInterFrameNearSADCache,
) interFrameSearchStart {
	if !search.improvedMVPrediction || refFrame == vp8common.IntraFrame {
		return interFrameSearchStart{}
	}
	signBias := e.interFrameSignBias()
	mbCount := mbRows * mbCols
	lastRefsAvailable := e.lastFrameInterModesValid && len(e.lastFrameInterModeRefs) >= mbCount
	includeLastSlots := (lastRefsAvailable || e.lastCodedFrameType != vp8common.KeyFrame) && mbRows > 0 && mbCols > 0
	var localSADs improvedInterFrameNearSADCache
	cache := sadCache
	if cache == nil {
		cache = &localSADs
	}
	if !cache.set {
		cache.sad[0] = currentNeighborNearSAD(src, &e.analysis.Img, mbRow, mbCol, mbRow-1, mbCol, above)
		cache.sad[1] = currentNeighborNearSAD(src, &e.analysis.Img, mbRow, mbCol, mbRow, mbCol-1, left)
		cache.sad[2] = currentNeighborNearSAD(src, &e.analysis.Img, mbRow, mbCol, mbRow-1, mbCol-1, aboveLeft)
		if includeLastSlots {
			cache.sad[3] = lastNeighborNearSAD(src, &e.lastRef.Img, mbRow, mbCol, mbRows, mbCols, mbRow, mbCol)
			cache.sad[4] = lastNeighborNearSAD(src, &e.lastRef.Img, mbRow, mbCol, mbRows, mbCols, mbRow-1, mbCol)
			cache.sad[5] = lastNeighborNearSAD(src, &e.lastRef.Img, mbRow, mbCol, mbRows, mbCols, mbRow, mbCol-1)
			cache.sad[6] = lastNeighborNearSAD(src, &e.lastRef.Img, mbRow, mbCol, mbRows, mbCols, mbRow, mbCol+1)
			cache.sad[7] = lastNeighborNearSAD(src, &e.lastRef.Img, mbRow, mbCol, mbRows, mbCols, mbRow+1, mbCol)
		}
		cache.set = true
	}
	var slots [8]improvedInterFrameMVSlot
	slotCount := 3
	slots[0].fillCurrent(cache.sad[0], mbRow-1, mbCol, above, signBias)
	slots[1].fillCurrent(cache.sad[1], mbRow, mbCol-1, left, signBias)
	slots[2].fillCurrent(cache.sad[2], mbRow-1, mbCol-1, aboveLeft, signBias)
	if includeLastSlots {
		slotCount = 8
		if lastRefsAvailable {
			slots[3].fillLastRef(cache.sad[3], e.lastFrameInterModeRefs, mbRows, mbCols, mbRow, mbCol)
			slots[4].fillLastRef(cache.sad[4], e.lastFrameInterModeRefs, mbRows, mbCols, mbRow-1, mbCol)
			slots[5].fillLastRef(cache.sad[5], e.lastFrameInterModeRefs, mbRows, mbCols, mbRow, mbCol-1)
			slots[6].fillLastRef(cache.sad[6], e.lastFrameInterModeRefs, mbRows, mbCols, mbRow, mbCol+1)
			slots[7].fillLastRef(cache.sad[7], e.lastFrameInterModeRefs, mbRows, mbCols, mbRow+1, mbCol)
		} else {
			slots[3] = improvedInterFrameMVSlot{sad: cache.sad[3]}
			slots[4] = improvedInterFrameMVSlot{sad: cache.sad[4]}
			slots[5] = improvedInterFrameMVSlot{sad: cache.sad[5]}
			slots[6] = improvedInterFrameMVSlot{sad: cache.sad[6]}
			slots[7] = improvedInterFrameMVSlot{sad: cache.sad[7]}
		}
	}
	biasImprovedInterFrameMVSlots(&slots, slotCount, refFrame, signBias, mbRow, mbCol, mbRows, mbCols)
	order := improvedInterFrameMVSlotOrder(slots, slotCount)
	// Both slots and order are length 8 (pow2). rank is bounded by
	// slotCount ≤ 8 and each order[rank] cell is [0,8) by construction
	// (the insertion sort writes only [0, slotCount) indices). Mask
	// with 7 to elide bounds checks on both indexed loads.
	for rank := 0; rank < slotCount; rank++ {
		slot := slots[order[rank&7]&7]
		if slot.refFrame == refFrame {
			sr := 2
			if rank < 3 {
				sr = 3
			}
			return newInterFrameSearchStart(slot.mv, sr, order[rank&7])
		}
	}
	mv := improvedInterFrameMVMedian(slots, slotCount)
	return newInterFrameSearchStart(mv, 0, -1)
}

func motionParentBiasImprovedInterFrameMVSlots(slots *[8]improvedInterFrameMVSlot, count int, refFrame vp8common.MVReferenceFrame, signBias [vp8common.MaxRefFrames]bool, mbRow int, mbCol int, mbRows int, mbCols int) {
	if slots == nil || refFrame <= vp8common.IntraFrame || refFrame >= vp8common.MaxRefFrames {
		return
	}
	targetBias := signBias[refFrame]
	limit := min(count, len(slots))
	for i := range limit {
		slot := &slots[i]
		if slot.refFrame == vp8common.IntraFrame {
			continue
		}
		if slot.signBias != targetBias {
			slot.mv.Row = -slot.mv.Row
			slot.mv.Col = -slot.mv.Col
		}
		slot.mv = clampInterFrameModeMotionVector(slot.mv, mbRow, mbCol, mbRows, mbCols)
	}
}

func motionParentImprovedInterFrameMVMedian(slots [8]improvedInterFrameMVSlot, count int) vp8enc.MotionVector {
	if count <= 0 {
		return vp8enc.MotionVector{}
	}
	var rows [8]int
	var cols [8]int
	// limit ∈ [0, 8] by construction (min with array length); using
	// limit instead of count for both the sort range and the median
	// index avoids a per-call IsSliceInBounds on rows[:count]/
	// cols[:count] (count is unbounded from the compiler's view) and
	// also closes a latent panic when count > 8.
	limit := min(count, len(slots))
	for i := range limit {
		rows[i] = int(slots[i].mv.Row)
		cols[i] = int(slots[i].mv.Col)
	}
	insertionSortInts(rows[:limit])
	insertionSortInts(cols[:limit])
	return vp8enc.MotionVector{Row: int16(rows[limit/2]), Col: int16(cols[limit/2])}
}

func motionParentMacroblockLumaSSE(src vp8enc.SourceImage, ref *vp8common.Image, mbRow int, mbCol int, mv vp8enc.MotionVector) int {
	baseY := mbRow * 16
	baseX := mbCol * 16
	mvY := int(mv.Row >> 3)
	mvX := int(mv.Col >> 3)
	refBaseY := baseY + mvY
	refBaseX := baseX + mvX
	xOffset := int(mv.Col) & 7
	yOffset := int(mv.Row) & 7
	// Uint range collapses (base >= 0) and (base+16 <= dim) into one
	// compare per dimension (works when dim >= 16; smaller dims fall
	// through to the per-pixel clamped path).
	if xOffset|yOffset != 0 {
		if uint(baseY) <= uint(src.Height-16) && uint(baseX) <= uint(src.Width-16) {
			if sse, ok := macroblockSubpixelSSE(src, ref, baseY, baseX, refBaseY, refBaseX, xOffset, yOffset); ok {
				return sse
			}
		} else {
			var srcScratch [16 * 16]byte
			vp8enc.GatherClampedLumaBlock(src, baseY, baseX, 16, 16, srcScratch[:], 16)
			if sse, ok := macroblockSubpixelSSEBlock(ref, refBaseY, refBaseX, xOffset, yOffset, srcScratch[:], 16); ok {
				return sse
			}
		}
	}
	if uint(baseY) <= uint(src.Height-16) && uint(baseX) <= uint(src.Width-16) {
		if refPtr, ok := refFullPelYPtr(ref, refBaseY, refBaseX, 16, 16); ok {
			return dsp.SSE16x16PtrFast(&src.Y[baseY*src.YStride+baseX], src.YStride, refPtr, ref.YStride)
		}
	}

	sse := 0
	for row := range 16 {
		srcY := vp8enc.ClampEncodeCoord(baseY+row, src.Height)
		refY := vp8enc.ClampEncodeCoord(refBaseY+row, ref.CodedHeight)
		for col := range 16 {
			srcX := vp8enc.ClampEncodeCoord(baseX+col, src.Width)
			refX := vp8enc.ClampEncodeCoord(refBaseX+col, ref.CodedWidth)
			diff := int(src.Y[srcY*src.YStride+srcX]) - int(ref.Y[refY*ref.YStride+refX])
			sse += diff * diff
		}
	}
	return sse
}

func motionParentMacroblockLumaMotionVarianceSSE(src vp8enc.SourceImage, ref *vp8common.Image, mbRow int, mbCol int, mv vp8enc.MotionVector) (int, int) {
	baseY := mbRow * 16
	baseX := mbCol * 16
	mvY := int(mv.Row >> 3)
	mvX := int(mv.Col >> 3)
	refBaseY := baseY + mvY
	refBaseX := baseX + mvX
	xOffset := int(mv.Col) & 7
	yOffset := int(mv.Row) & 7
	if xOffset|yOffset != 0 {
		if uint(baseY) <= uint(src.Height-16) && uint(baseX) <= uint(src.Width-16) {
			if variance, sse, ok := macroblockSubpixelVariance(src, ref, baseY, baseX, refBaseY, refBaseX, xOffset, yOffset); ok {
				return variance, sse
			}
		} else {
			var srcScratch [16 * 16]byte
			vp8enc.GatherClampedLumaBlock(src, baseY, baseX, 16, 16, srcScratch[:], 16)
			if variance, sse, ok := macroblockSubpixelVarianceBlock(ref, refBaseY, refBaseX, xOffset, yOffset, srcScratch[:], 16); ok {
				return variance, sse
			}
		}
	}
	// Uint range collapses (baseY/X >= 0) and (baseY/X+16 <= dim) into
	// one compare each, matching the pattern in macroblockLumaSSE.
	if uint(baseY) <= uint(src.Height-16) && uint(baseX) <= uint(src.Width-16) {
		if refPtr, ok := refFullPelYPtr(ref, refBaseY, refBaseX, 16, 16); ok {
			sum, sse := dsp.VarianceBlock16x16PtrFast(&src.Y[baseY*src.YStride+baseX], src.YStride, refPtr, ref.YStride)
			return sse - ((sum * sum) >> 8), sse
		}
	}

	sum := 0
	sse := 0
	for row := range 16 {
		srcY := vp8enc.ClampEncodeCoord(baseY+row, src.Height)
		refY := vp8enc.ClampEncodeCoord(refBaseY+row, ref.CodedHeight)
		for col := range 16 {
			srcX := vp8enc.ClampEncodeCoord(baseX+col, src.Width)
			refX := vp8enc.ClampEncodeCoord(refBaseX+col, ref.CodedWidth)
			diff := int(src.Y[srcY*src.YStride+srcX]) - int(ref.Y[refY*ref.YStride+refX])
			sum += diff
			sse += diff * diff
		}
	}
	return sse - ((sum * sum) >> 8), sse
}

// macroblockSADLimited dispatches the limit-aware 16x16 SAD between the
// full-pel bordered-reference SIMD kernel, the sub-pel six-tap predict path,
// and the scalar fallback for invalid buffers / non-UMV callers.
func motionParentSplitBlockSAD(src vp8enc.SourceImage, ref *vp8common.Image, mbRow int, mbCol int, block int, width int, height int, mv vp8enc.MotionVector) int {
	baseY := mbRow*16 + (block>>2)*4
	baseX := mbCol*16 + (block&3)*4
	mvY := int(mv.Row >> 3)
	mvX := int(mv.Col >> 3)
	refBaseY := baseY + mvY
	refBaseX := baseX + mvX
	xOffset := int(mv.Col) & 7
	yOffset := int(mv.Row) & 7
	if xOffset|yOffset != 0 {
		if uint(baseY) <= uint(src.Height-height) && uint(baseX) <= uint(src.Width-width) {
			if sad, ok := splitBlockSubpixelSAD(src, ref, baseY, baseX, refBaseY, refBaseX, width, height, xOffset, yOffset); ok {
				return sad
			}
		} else {
			var srcScratch [16 * 16]byte
			vp8enc.GatherClampedLumaBlock(src, baseY, baseX, width, height, srcScratch[:], 16)
			if sad, ok := splitBlockSubpixelSADBlock(ref, refBaseY, refBaseX, width, height, xOffset, yOffset, srcScratch[:], 16); ok {
				return sad
			}
		}
	}
	if uint(baseY) <= uint(src.Height-height) && uint(baseX) <= uint(src.Width-width) {
		srcBlock := src.Y[baseY*src.YStride+baseX:]
		refBlock, ok := refFullPelYSlice(ref, refBaseY, refBaseX, width, height)
		if ok {
			switch {
			case width == 16 && height == 8:
				return dsp.SAD16x8(srcBlock, src.YStride, refBlock, ref.YStride)
			case width == 8 && height == 16:
				return dsp.SAD8x16(srcBlock, src.YStride, refBlock, ref.YStride)
			case width == 8 && height == 8:
				return dsp.SAD8x8(srcBlock, src.YStride, refBlock, ref.YStride)
			case width == 4 && height == 4:
				return dsp.SAD4x4(srcBlock, src.YStride, refBlock, ref.YStride)
			}
		}
	}

	// libvpx allocates every reference (cm->yv12_fb[]) and lookahead source
	// buffer with 16-aligned width/height via vp8_yv12_alloc_frame_buffer
	// (vp8/common/alloccommon.c:56-65 rounds (width|height) up to a
	// multiple of 16 before calling vp8_yv12_alloc_frame_buffer, and
	// vp8/encoder/lookahead.c:68-70 does the same), so for an odd-axis
	// frame y_crop_height == y_height == coded height (e.g. 368 for a
	// visible 360 input). The post-loop-filter publication path
	// (vp8/encoder/onyx_if.c:3212 vp8_yv12_extend_frame_borders applied to
	// cm->frame_to_show) therefore extends from coded-height-1 (not from
	// visible-height-1), and the coded-but-invisible MB-padded rows/cols
	// retain the LF-modified reconstruction. The SPLITMV picker's NEW4X4
	// SAD walk on padded-edge MBs must read from that region the same way
	// libvpx does — i.e. clamp reference coords to CodedHeight/CodedWidth,
	// not to the visible extent. The source side, by contrast, comes from
	// vp8_copy_and_extend_frame (vp8/common/extend.c:14-72, called from
	// lookahead.c:139) which is a visible-edge extend, so source coords
	// remain clamped to visible Width/Height.
	refClampHeight := ref.CodedHeight
	refClampWidth := ref.CodedWidth
	sad := 0
	for row := range height {
		srcY := vp8enc.ClampEncodeCoord(baseY+row, src.Height)
		refY := vp8enc.ClampEncodeCoord(refBaseY+row, refClampHeight)
		for col := range width {
			srcX := vp8enc.ClampEncodeCoord(baseX+col, src.Width)
			refX := vp8enc.ClampEncodeCoord(refBaseX+col, refClampWidth)
			diff := int(src.Y[srcY*src.YStride+srcX]) - int(ref.Y[refY*ref.YStride+refX])
			mask := diff >> mvKernelSignShift
			sad += (diff ^ mask) - mask
		}
	}
	return sad
}

func motionParentGatherCodedClampedRefBlock(ref *vp8common.Image, baseY int, baseX int, width int, height int, dst []byte, dstStride int) {
	for row := range height {
		refY := vp8enc.ClampEncodeCoord(baseY+row, ref.CodedHeight)
		dstRow := row * dstStride
		srcRow := refY * ref.YStride
		for col := range width {
			refX := vp8enc.ClampEncodeCoord(baseX+col, ref.CodedWidth)
			dst[dstRow+col] = ref.Y[srcRow+refX]
		}
	}
}

func motionParentFillSplitMotionResidual4x4(src vp8enc.SourceImage, mbRow int, mbCol int, block int, pred *[16]byte, out *[16]int16) {
	baseY := mbRow*16 + (block>>2)*4
	baseX := mbCol*16 + (block&3)*4
	for row := range 4 {
		srcY := vp8enc.ClampEncodeCoord(baseY+row, src.Height)
		for col := range 4 {
			srcX := vp8enc.ClampEncodeCoord(baseX+col, src.Width)
			out[row*4+col] = int16(int(src.Y[srcY*src.YStride+srcX]) - int(pred[row*4+col]))
		}
	}
}

func motionParentIterativeInterFrameSplitBlockSubpixelMotionVector(src vp8enc.SourceImage, ref *vp8common.Image, mbRow int, mbCol int, block int, width int, height int, best vp8enc.MotionVector, bestRefMV vp8enc.MotionVector, qIndex int, errorPerBit int, mvProbs *[2][vp8tables.MVPCount]uint8, mvCosts *vp8enc.MotionVectorCostTables) (vp8enc.MotionVector, int, bool) {
	if int(best.Row)&7 != 0 || int(best.Col)&7 != 0 {
		return vp8enc.MotionVector{}, 0, false
	}
	br := (int(best.Row) >> 3) * 4
	bc := (int(best.Col) >> 3) * 4
	tr := br
	tc := bc
	bestMV := vp8enc.MotionVector{Row: int16(br * 2), Col: int16(bc * 2)}
	bestDist, ok := splitBlockSubpixelVarianceForQuarterMV(src, ref, mbRow, mbCol, block, width, height, br, bc)
	if !ok {
		return vp8enc.MotionVector{}, 0, false
	}
	bestCost := bestDist + interMotionSearchErrorVectorCostWithErrorPerBitAndCostTables(bestMV, bestRefMV, errorPerBit, mvProbs, mvCosts)
	mbRows := (src.Height + 15) >> 4
	mbCols := (src.Width + 15) >> 4
	bounds := vp8enc.InterFrameSubpelSearchBoundsFor(bestRefMV, mbRow, mbCol, mbRows, mbCols)
	_ = qIndex
	var cache subpelEvalCache
	cand := func(r, c int) int {
		return cachedBoundedSplitBlockSubpixelMotionSearchCandidateCost(&cache, bounds, src, ref, mbRow, mbCol, block, width, height, r, c, bestRefMV, errorPerBit, mvProbs, mvCosts)
	}

	for range 3 {
		leftCost := cand(tr, tc-2)
		rightCost := cand(tr, tc+2)
		upCost := cand(tr-2, tc)
		downCost := cand(tr+2, tc)
		bestCost, br, bc = updateSubpixelSearchBest(bestCost, br, bc, leftCost, tr, tc-2)
		bestCost, br, bc = updateSubpixelSearchBest(bestCost, br, bc, rightCost, tr, tc+2)
		bestCost, br, bc = updateSubpixelSearchBest(bestCost, br, bc, upCost, tr-2, tc)
		bestCost, br, bc = updateSubpixelSearchBest(bestCost, br, bc, downCost, tr+2, tc)

		diagRow := tr - 2
		if upCost >= downCost {
			diagRow = tr + 2
		}
		diagCol := tc - 2
		if leftCost >= rightCost {
			diagCol = tc + 2
		}
		diagCost := cand(diagRow, diagCol)
		bestCost, br, bc = updateSubpixelSearchBest(bestCost, br, bc, diagCost, diagRow, diagCol)

		if tr == br && tc == bc {
			break
		}
		tr = br
		tc = bc
	}

	for range 3 {
		leftCost := cand(tr, tc-1)
		rightCost := cand(tr, tc+1)
		upCost := cand(tr-1, tc)
		downCost := cand(tr+1, tc)
		bestCost, br, bc = updateSubpixelSearchBest(bestCost, br, bc, leftCost, tr, tc-1)
		bestCost, br, bc = updateSubpixelSearchBest(bestCost, br, bc, rightCost, tr, tc+1)
		bestCost, br, bc = updateSubpixelSearchBest(bestCost, br, bc, upCost, tr-1, tc)
		bestCost, br, bc = updateSubpixelSearchBest(bestCost, br, bc, downCost, tr+1, tc)

		diagRow := tr - 1
		if upCost >= downCost {
			diagRow = tr + 1
		}
		diagCol := tc - 1
		if leftCost >= rightCost {
			diagCol = tc + 1
		}
		diagCost := cand(diagRow, diagCol)
		bestCost, br, bc = updateSubpixelSearchBest(bestCost, br, bc, diagCost, diagRow, diagCol)

		if tr == br && tc == bc {
			break
		}
		tr = br
		tc = bc
	}

	finalMV := vp8enc.MotionVector{Row: int16(br * 2), Col: int16(bc * 2)}
	if !vp8enc.InterFrameSubpixelMotionVectorInRange(finalMV, bestRefMV) {
		return vp8enc.MotionVector{}, 0, false
	}
	return finalMV, bestCost, true
}

var motionPRInt int
var motionPRMV vp8enc.MotionVector
var motionPRStart interFrameSearchStart
var motionPRSlots [8]improvedInterFrameMVSlot
var motionPRBytes [289]byte
var motionPRResidual [16]int16

func motionPredictorSetup(tb testing.TB) (*VP8Encoder, vp8enc.SourceImage, [3]vp8enc.InterFrameMacroblockMode) {
	e := newSizedTestEncoder(tb, 128, 128)
	e.lastFrameInterModesValid = true
	e.lastFrameInterModeRefs = make([]vp8enc.InterFrameMVRef, 64)
	for i := range e.lastFrameInterModeRefs {
		e.lastFrameInterModeRefs[i] = vp8enc.InterFrameMVRef{MV: vp8enc.MotionVector{Row: int16(i*71 - 2000), Col: int16(i*43 - 1000)}, RefFrame: vp8common.MVReferenceFrame(1 + i%3), SignBias: i&1 != 0}
	}
	src := sourceImageFromPublic(testImage(128, 128))
	var modes [3]vp8enc.InterFrameMacroblockMode
	for i := range modes {
		modes[i] = vp8enc.InterFrameMacroblockMode{RefFrame: vp8common.MVReferenceFrame(i + 1), MV: vp8enc.MotionVector{Row: int16(3000 + i*41), Col: int16(-4000 - i*59)}}
	}
	return e, src, modes
}
func TestMotionPR01(t *testing.T) {
	e, src, m := motionPredictorSetup(t)
	r := rand.New(rand.NewSource(511))
	for i := 0; i < 500; i++ {
		cache := improvedInterFrameNearSADCache{set: true}
		for j := range cache.sad {
			cache.sad[j] = r.Intn(7)
		}
		for j := range m {
			m[j].RefFrame = vp8common.MVReferenceFrame(r.Intn(4))
			m[j].MV = vp8enc.MotionVector{Row: int16(r.Uint32()), Col: int16(r.Uint32())}
		}
		for j := range e.lastFrameInterModeRefs {
			e.lastFrameInterModeRefs[j].RefFrame = vp8common.MVReferenceFrame(r.Intn(4))
		}
		e.lastFrameInterModesValid = i&1 != 0
		e.lastCodedFrameType = vp8common.FrameType(i % 2)
		search := defaultInterAnalysisSearchConfig()
		search.improvedMVPrediction = true
		row, col := i%8, (i/8)%8
		ref := vp8common.MVReferenceFrame(1 + i%3)
		got := e.improvedInterFrameSearchStart(src, ref, row, col, 8, 8, &m[0], &m[1], &m[2], search, &cache)
		want := e.motionParentImprovedInterFrameSearchStart(src, ref, row, col, 8, 8, &m[0], &m[1], &m[2], search, &cache)
		if got != want {
			t.Fatalf("case %d got %+v want %+v", i, got, want)
		}
	}
}
func TestMotionPR02(t *testing.T) {
	r := rand.New(rand.NewSource(522))
	for i := 0; i < 1000; i++ {
		var a [8]improvedInterFrameMVSlot
		for j := range a {
			a[j] = improvedInterFrameMVSlot{mv: vp8enc.MotionVector{Row: int16(r.Uint32()), Col: int16(r.Uint32())}, signBias: j%2 != 0, refFrame: vp8common.MVReferenceFrame(r.Intn(4))}
		}
		b := a
		bias := [vp8common.MaxRefFrames]bool{false, false, true, true}
		n, rows, cols := i%10, (i%10)-1, (i%7)-1
		biasImprovedInterFrameMVSlots(&a, n, vp8common.LastFrame, bias, i%8, i%8, rows, cols)
		motionParentBiasImprovedInterFrameMVSlots(&b, n, vp8common.LastFrame, bias, i%8, i%8, rows, cols)
		if a != b {
			t.Fatalf("case %d differs", i)
		}
	}
}
func motionPixelSetup(tb testing.TB, w, h int) (vp8enc.SourceImage, *vp8common.Image) {
	src := testImage(w, h)
	for i := range src.Y {
		src.Y[i] = byte(i*17 + i/11)
	}
	ref := testVP8Frame(tb, w, h, 10, 90, 170)
	for i := range ref.Img.Y {
		ref.Img.Y[i] = byte(i*23 + i/7)
	}
	ref.ExtendBorders()
	return sourceImageFromPublic(src), &ref.Img
}
func TestMotionPR03(t *testing.T) {
	for _, sz := range [][2]int{{65, 49}, {17, 17}, {33, 48}, {64, 64}} {
		s, r := motionPixelSetup(t, sz[0], sz[1])
		for y := 0; y < (s.Height+15)/16; y++ {
			for x := 0; x < (s.Width+15)/16; x++ {
				for _, mv := range []vp8enc.MotionVector{{}, {Row: 8, Col: -8}, {Row: -32, Col: 16}, {Row: 2, Col: 4}} {
					got := macroblockLumaSSE(s, r, y, x, mv)
					want := motionParentMacroblockLumaSSE(s, r, y, x, mv)
					a, b := macroblockLumaMotionVarianceSSE(s, r, y, x, mv)
					c, d := motionParentMacroblockLumaMotionVarianceSSE(s, r, y, x, mv)
					if got != want || a != c || b != d {
						t.Fatalf("size %v yx %d %d mv %v got %d %d %d want %d %d %d", sz, y, x, mv, got, a, b, want, c, d)
					}
				}
			}
		}
	}
}
func TestMotionPR04(t *testing.T) {
	for _, sz := range [][2]int{{65, 49}, {17, 17}, {33, 48}, {64, 64}} {
		s, r := motionPixelSetup(t, sz[0], sz[1])
		for _, shape := range [][2]int{{16, 8}, {8, 16}, {8, 8}, {4, 4}} {
			for _, block := range []int{0, 5, 15} {
				for _, mv := range []vp8enc.MotionVector{{}, {Row: 8, Col: -8}, {Row: -32, Col: 16}, {Row: 2, Col: 4}} {
					y, x := (s.Height-1)/16, (s.Width-1)/16
					got := splitBlockSAD(s, r, y, x, block, shape[0], shape[1], mv)
					want := motionParentSplitBlockSAD(s, r, y, x, block, shape[0], shape[1], mv)
					if got != want {
						t.Fatalf("size %v shape %v block %d mv %v got %d want %d", sz, shape, block, mv, got, want)
					}
				}
			}
		}
	}
}
func TestMotionPR05(t *testing.T) {
	_, r := motionPixelSetup(t, 65, 49)
	for _, xy := range [][2]int{{0, -6}, {3, 63}, {-1, -1}, {70, 60}, {0, 0}} {
		for _, shape := range [][2]int{{17, 9}, {9, 17}, {9, 9}, {5, 5}} {
			var a, b [289]byte
			gatherCodedClampedRefBlock(r, xy[1], xy[0], shape[0], shape[1], a[:], 17)
			motionParentGatherCodedClampedRefBlock(r, xy[1], xy[0], shape[0], shape[1], b[:], 17)
			if a != b {
				t.Fatalf("xy %v shape %v differs", xy, shape)
			}
		}
	}
	// The original forward copy semantics remain live for aliased destinations.
	for _, off := range []int{0, 1, 5, 20} {
		_, a := motionPixelSetup(t, 64, 64)
		_, b := motionPixelSetup(t, 64, 64)
		gatherCodedClampedRefBlock(a, 0, 0, 9, 9, a.Y[off:], 17)
		motionParentGatherCodedClampedRefBlock(b, 0, 0, 9, 9, b.Y[off:], 17)
		for i := range a.Y {
			if a.Y[i] != b.Y[i] {
				t.Fatal("alias", off, i)
			}
		}
	}
}
func TestMotionPR06(t *testing.T) {
	for _, sz := range [][2]int{{65, 49}, {17, 17}, {64, 64}} {
		s, _ := motionPixelSetup(t, sz[0], sz[1])
		var p [16]byte
		for i := range p {
			p[i] = byte(i * 13)
		}
		for y := 0; y < (s.Height+15)/16; y++ {
			for x := 0; x < (s.Width+15)/16; x++ {
				for block := 0; block < 16; block++ {
					var a, b [16]int16
					fillSplitMotionResidual4x4(s, y, x, block, &p, &a)
					motionParentFillSplitMotionResidual4x4(s, y, x, block, &p, &b)
					if a != b {
						t.Fatal(sz, y, x, block)
					}
				}
			}
		}
	}
}
func TestMotionPR08(t *testing.T) {
	r := rand.New(rand.NewSource(588))
	for i := 0; i < 1000; i++ {
		var a [8]improvedInterFrameMVSlot
		for j := range a {
			a[j].mv = vp8enc.MotionVector{Row: int16(r.Uint32()), Col: int16(r.Uint32())}
		}
		for n := 0; n <= 9; n++ {
			if got, want := improvedInterFrameMVMedian(a, n), motionParentImprovedInterFrameMVMedian(a, n); got != want {
				t.Fatal(n, got, want)
			}
		}
	}
}
func BenchmarkMotionPRs(b *testing.B) {
	b.Run("motion01/predictor", func(b *testing.B) {
		e, s, m := motionPredictorSetup(b)
		cache := improvedInterFrameNearSADCache{set: true, sad: [8]int{31, 28, 29, 47, 32, 43, 19, 20}}
		search := defaultInterAnalysisSearchConfig()
		search.improvedMVPrediction = true
		b.ReportAllocs()
		for b.Loop() {
			motionPRStart = e.improvedInterFrameSearchStart(s, vp8common.LastFrame, 4, 4, 8, 8, &m[0], &m[1], &m[2], search, &cache)
		}
	})
	b.Run("motion02/bias", func(b *testing.B) {
		var slots [8]improvedInterFrameMVSlot
		for i := range slots {
			slots[i] = improvedInterFrameMVSlot{refFrame: vp8common.MVReferenceFrame(1 + i%3), mv: vp8enc.MotionVector{Row: int16(30 + i*71), Col: int16(-50 - i*79)}, signBias: i&1 != 0}
		}
		bias := [vp8common.MaxRefFrames]bool{false, false, true, true}
		b.ReportAllocs()
		for b.Loop() {
			a := slots
			biasImprovedInterFrameMVSlots(&a, 8, vp8common.LastFrame, bias, 4, 4, 8, 8)
			motionPRSlots = a
		}
	})
	for _, which := range []string{"SSE", "variance"} {
		b.Run("motion03/partial_"+which, func(b *testing.B) {
			s, r := motionPixelSetup(b, 65, 49)
			b.ReportAllocs()
			for b.Loop() {
				if which == "SSE" {
					motionPRInt = macroblockLumaSSE(s, r, 3, 4, vp8enc.MotionVector{})
				} else {
					a, v := macroblockLumaMotionVarianceSSE(s, r, 3, 4, vp8enc.MotionVector{})
					motionPRInt = a + v
				}
			}
		})
	}
	for _, shape := range [][2]int{{16, 8}, {8, 16}, {8, 8}, {4, 4}} {
		b.Run(fmt.Sprintf("motion04/partial_%dx%d", shape[0], shape[1]), func(b *testing.B) {
			s, r := motionPixelSetup(b, 65, 49)
			b.ReportAllocs()
			for b.Loop() {
				motionPRInt = splitBlockSAD(s, r, 3, 4, 0, shape[0], shape[1], vp8enc.MotionVector{})
			}
		})
	}
	for _, y := range []int{-5, 63} {
		b.Run(fmt.Sprintf("motion05/gather_y%d", y), func(b *testing.B) {
			_, r := motionPixelSetup(b, 65, 49)
			b.ReportAllocs()
			for b.Loop() {
				gatherCodedClampedRefBlock(r, y, 32, 17, 9, motionPRBytes[:], 17)
			}
		})
	}
	b.Run("motion06/residual", func(b *testing.B) {
		s, _ := motionPixelSetup(b, 64, 64)
		var p [16]byte
		for i := range p {
			p[i] = byte(i * 13)
		}
		b.ReportAllocs()
		for b.Loop() {
			fillSplitMotionResidual4x4(s, 1, 1, 5, &p, &motionPRResidual)
		}
	})
	b.Run("motion08/median3", func(b *testing.B) {
		var a [8]improvedInterFrameMVSlot
		for i := range a {
			a[i].mv = vp8enc.MotionVector{Row: int16(i*47 - 70), Col: int16(20 - i*72)}
		}
		b.ReportAllocs()
		for b.Loop() {
			motionPRMV = improvedInterFrameMVMedian(a, 3)
		}
	})
}

func TestMotionPR07(t *testing.T) {
	for _, sz := range [][2]int{{65, 49}, {17, 17}, {64, 64}} {
		s, r := motionPixelSetup(t, sz[0], sz[1])
		var costs vp8enc.MotionVectorCostTables
		costs.Build(&vp8tables.DefaultMVContext)
		for _, shape := range [][2]int{{16, 8}, {8, 16}, {8, 8}, {4, 4}} {
			for _, block := range []int{0, 5, 15} {
				for _, center := range []vp8enc.MotionVector{{}, {Row: 8, Col: -8}, {Row: -32, Col: 16}} {
					y, x := (s.Height-1)/16, (s.Width-1)/16
					a, b, c := iterativeInterFrameSplitBlockSubpixelMotionVector(s, r, y, x, block, shape[0], shape[1], center, vp8enc.MotionVector{}, 44, 34, &vp8tables.DefaultMVContext, &costs)
					d, e, f := motionParentIterativeInterFrameSplitBlockSubpixelMotionVector(s, r, y, x, block, shape[0], shape[1], center, vp8enc.MotionVector{}, 44, 34, &vp8tables.DefaultMVContext, &costs)
					if a != d || b != e || c != f {
						t.Fatal(sz, shape, block, center, a, b, c, d, e, f)
					}
				}
			}
		}
	}
}
func BenchmarkMotionPR07(b *testing.B) {
	for _, shape := range [][2]int{{8, 8}, {4, 4}} {
		b.Run(fmt.Sprintf("partial_%dx%d", shape[0], shape[1]), func(b *testing.B) {
			s, r := motionPixelSetup(b, 65, 49)
			var costs vp8enc.MotionVectorCostTables
			costs.Build(&vp8tables.DefaultMVContext)
			b.ReportAllocs()
			for b.Loop() {
				mv, c, ok := iterativeInterFrameSplitBlockSubpixelMotionVector(s, r, 3, 4, 0, shape[0], shape[1], vp8enc.MotionVector{}, vp8enc.MotionVector{}, 44, 34, &vp8tables.DefaultMVContext, &costs)
				motionPRInt = c
				if !ok {
					b.Fatal("invalid")
				}
				motionPRMV = mv
			}
		})
	}
}

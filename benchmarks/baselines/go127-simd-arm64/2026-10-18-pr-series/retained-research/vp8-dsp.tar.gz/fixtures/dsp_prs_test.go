package dsp

import (
	"fmt"
	"github.com/thesyncim/govpx/internal/vp8/common"
	"slices"
	"testing"
)

var dspPRSink int

func dspPRData(n int) []byte {
	b := make([]byte, n)
	x := uint32(73241)
	for i := range b {
		x ^= x << 13
		x ^= x >> 17
		x ^= x << 5
		b[i] = byte(x)
	}
	return b
}
func dspPRBilinear(w int, s []byte, ss, x, y int, d []byte, ds int) {
	if w == 4 {
		BilinearPredict4x4(s, ss, x, y, d, ds)
	} else {
		BilinearPredict8x4(s, ss, x, y, d, ds)
	}
}
func dspPRBilinearRef(w int, s []byte, ss, x, y int, d []byte, ds int) {
	var tmp [5 * 8]int
	for r := 0; r < 5; r++ {
		for c := 0; c < w; c++ {
			tmp[r*w+c] = (int(s[r*ss+c])*(128-x*16) + int(s[r*ss+c+1])*x*16 + 64) >> 7
		}
	}
	for r := 0; r < 4; r++ {
		for c := 0; c < w; c++ {
			d[r*ds+c] = byte((tmp[r*w+c]*(128-y*16) + tmp[(r+1)*w+c]*y*16 + 64) >> 7)
		}
	}
}
func TestDSPPRBilinear(t *testing.T) {
	for _, w := range []int{4, 8} {
		for _, pad := range []int{0, 11} {
			ss, ds := w+1+pad, w+pad
			for x := 0; x < 8; x++ {
				for y := 0; y < 8; y++ {
					s := dspPRData(5 * ss)
					a, b := dspPRData(4*ds), dspPRData(4*ds)
					dspPRBilinear(w, s, ss, x, y, a, ds)
					dspPRBilinearRef(w, s, ss, x, y, b, ds)
					if !slices.Equal(a, b) {
						t.Fatalf("w%d %d,%d", w, x, y)
					}
				}
			}
		}
		for _, off := range []int{0, 1, 9} {
			a, b := dspPRData(256), dspPRData(256)
			dspPRBilinear(w, a, 24, 3, 5, a[off:], 16)
			dspPRBilinearRef(w, b, 24, 3, 5, b[off:], 16)
			if !slices.Equal(a, b) {
				t.Fatalf("alias%d", off)
			}
		}
	}
}
func BenchmarkDSPPRBilinear(b *testing.B) {
	for _, w := range []int{4, 8} {
		for _, xy := range [][2]int{{0, 0}, {4, 0}, {0, 4}, {3, 5}} {
			b.Run(fmt.Sprintf("w%d/%d_%d", w, xy[0], xy[1]), func(b *testing.B) {
				s, d := dspPRData(5*24), make([]byte, 4*16)
				b.ReportAllocs()
				for b.Loop() {
					dspPRBilinear(w, s, 24, xy[0], xy[1], d, 16)
				}
				dspPRSink = int(d[7])
			})
		}
	}
}
func dspPRResidualRef(d []byte, ds int, r *[16]int16) {
	for y := 0; y < 4; y++ {
		row := (*[4]byte)(d[y*ds : y*ds+4])
		for x := 0; x < 4; x++ {
			row[x] = ClipPixel(int(row[x]) + int(r[y*4+x]))
		}
	}
}
func TestDSPPRResidual(t *testing.T) {
	for k := 0; k < 1000; k++ {
		var r [16]int16
		for i := range r {
			r[i] = int16(k*1517 + i*3791)
		}
		for _, ds := range []int{4, 7, 24} {
			a, c := dspPRData(4*ds), dspPRData(4*ds)
			AddResidual4x4(a, ds, &r)
			dspPRResidualRef(c, ds, &r)
			if !slices.Equal(a, c) {
				t.Fatalf("k%d ds%d", k, ds)
			}
		}
	}
}
func BenchmarkDSPPRResidual(b *testing.B) {
	for _, ds := range []int{4, 24} {
		for _, dense := range []bool{false, true} {
			b.Run(fmt.Sprintf("stride%d/dense%v", ds, dense), func(b *testing.B) {
				d := dspPRData(4 * ds)
				var r [16]int16
				for i := range r {
					r[i] = int16(i - 7)
					if dense {
						r[i] = int16(i * 4000)
					}
				}
				b.ReportAllocs()
				for b.Loop() {
					AddResidual4x4(d, ds, &r)
				}
				dspPRSink = int(d[0])
			})
		}
	}
}
func TestDSPPRZeroDC(t *testing.T) {
	for _, c := range []int16{-32768, -10, -5, -4, -1, 0, 1, 3, 4, 10, 32767} {
		for _, ds := range []int{4, 24} {
			for _, same := range []bool{false, true} {
				s := dspPRData(4 * ds)
				a, z := slices.Clone(s), slices.Clone(s)
				p := s
				if same {
					p = a
				}
				DCOnlyIDCT4x4Add(c, p, ds, a, ds)
				p = s
				if same {
					p = z
				}
				dcOnlyIDCT4x4AddScalar(c, p, ds, z, ds)
				if !slices.Equal(a, z) {
					t.Fatalf("c%d ds%d", c, ds)
				}
			}
		}
	}
}
func BenchmarkDSPPRZeroDC(b *testing.B) {
	for _, c := range []int16{0, 8} {
		for _, same := range []bool{true, false} {
			b.Run(fmt.Sprintf("dc%d/inplace%v", c, same), func(b *testing.B) {
				s, d := dspPRData(4*24), dspPRData(4*24)
				if same {
					s = d
				}
				b.ReportAllocs()
				for b.Loop() {
					DCOnlyIDCT4x4Add(c, s, 24, d, 24)
				}
				dspPRSink = int(d[0])
			})
		}
	}
}
func TestDSPPRDequant(t *testing.T) {
	for k := 0; k < 1000; k++ {
		var q, d, a, z [16]int16
		for i := range q {
			q[i] = int16(k*1517 + i*3791)
			d[i] = int16(k*913 + i*1777)
			z[i] = q[i] * d[i]
		}
		DequantizeBlock(&q, &d, &a)
		if a != z {
			t.Fatalf("k%d", k)
		}
		DequantizeBlock(&q, &d, &q)
		if q != z {
			t.Fatalf("inplace k%d", k)
		}
	}
	for _, off := range []int{1, 7, 15} {
		var a, z [48]int16
		for i := range a {
			a[i] = int16(i * 7851)
			z[i] = a[i]
		}
		DequantizeBlock((*[16]int16)(a[:]), (*[16]int16)(a[32:]), (*[16]int16)(a[off:]))
		for i := 0; i < 16; i++ {
			z[off+i] = z[i] * z[32+i]
		}
		if a != z {
			t.Fatalf("alias%d", off)
		}
	}
}
func BenchmarkDSPPRDequant(b *testing.B) {
	for _, same := range []bool{false, true} {
		b.Run(fmt.Sprintf("inplace%v", same), func(b *testing.B) {
			var q, d, o [16]int16
			for i := range q {
				q[i] = int16(i * 1517)
				d[i] = int16(i * 1777)
			}
			out := &o
			if same {
				out = &q
			}
			b.ReportAllocs()
			for b.Loop() {
				DequantizeBlock(&q, &d, out)
			}
			dspPRSink = int(out[0])
		})
	}
}
func TestDSPPRWalsh(t *testing.T) {
	for k := 0; k < 3000; k++ {
		var c [16]int16
		for i := range c {
			c[i] = int16(k*1517 + i*3791)
		}
		a, z := make([]int16, 256), make([]int16, 256)
		InverseWalsh4x4(&c, a)
		inverseWalsh4x4Scalar(&c, z)
		if !slices.Equal(a, z) {
			t.Fatalf("k%d", k)
		}
	}
}
func BenchmarkDSPPRWalsh(b *testing.B) {
	var c [16]int16
	for i := range c {
		c[i] = int16(i * 141)
	}
	o := make([]int16, 256)
	b.ReportAllocs()
	for b.Loop() {
		InverseWalsh4x4(&c, o)
	}
	dspPRSink = int(o[16])
}
func TestDSPPRSparseDequant(t *testing.T) {
	for _, dc := range []int16{-32768, -32765, -1000, -4, 0, 3, 1000, 32767} {
		for _, dq := range []int16{-32768, -17, 0, 1, 17, 32767} {
			for _, dense := range []bool{false, true} {
				var a, z, q [16]int16
				a[0] = dc
				for i := range q {
					q[i] = dq
					if dense {
						a[i] = int16(i * 1517)
					}
				}
				z = a
				x, y := dspPRData(4*24), dspPRData(4*24)
				DequantIDCT4x4Add(&a, &q, x, 24)
				for i := range z {
					z[i] *= q[i]
				}
				IDCT4x4Add(&z, y, 24, y, 24)
				clear(z[:])
				if a != z || !slices.Equal(x, y) {
					t.Fatalf("dc%d dq%d dense%v", dc, dq, dense)
				}
			}
		}
	}
}
func BenchmarkDSPPRSparseDequant(b *testing.B) {
	for _, kind := range []string{"zero", "dc", "dense"} {
		b.Run(kind, func(b *testing.B) {
			var in, q, seed [16]int16
			for i := range q {
				q[i] = 117
				if kind == "dense" {
					seed[i] = int16(i*71 - 300)
				}
			}
			if kind == "dc" {
				seed[0] = 17
			}
			d := dspPRData(4 * 24)
			b.ReportAllocs()
			for b.Loop() {
				in = seed
				DequantIDCT4x4Add(&in, &q, d, 24)
			}
			dspPRSink = int(d[0])
		})
	}
}
func dspPRSplitRef(src []byte, ss, x, y int, ref []byte, rs, w, h int) (int, int) {
	tmp := make([]byte, (h+1)*w)
	f := make([]byte, h*w)
	for r := 0; r < h+1; r++ {
		for c := 0; c < w; c++ {
			tmp[r*w+c] = byte((int(src[r*ss+c])*(128-x*16) + int(src[r*ss+c+1])*x*16 + 64) >> 7)
		}
	}
	for r := 0; r < h; r++ {
		for c := 0; c < w; c++ {
			f[r*w+c] = byte((int(tmp[r*w+c])*(128-y*16) + int(tmp[(r+1)*w+c])*y*16 + 64) >> 7)
		}
	}
	sum, sse := varianceBlockGeneric(f, w, ref, rs, w, h)
	return sse - sum*sum/(w*h), sse
}
func dspPRSplit(s []byte, ss, x, y int, r []byte, rs, w, h int) (int, int) {
	if w == 4 && h == 4 {
		return SubpelVariance4x4(s, ss, x, y, r, rs)
	}
	if w == 4 {
		return SubpelVariance4x8(s, ss, x, y, r, rs)
	}
	if h == 4 {
		return SubpelVariance8x4(s, ss, x, y, r, rs)
	}
	if h == 8 {
		return SubpelVariance8x8(s, ss, x, y, r, rs)
	}
	return SubpelVariance8x16(s, ss, x, y, r, rs)
}
func TestDSPPRSplit(t *testing.T) {
	for _, wh := range [][2]int{{4, 4}, {4, 8}, {8, 4}, {8, 8}, {8, 16}} {
		w, h := wh[0], wh[1]
		s, r := dspPRData((h+1)*24), dspPRData(h*32)
		for x := 0; x < 8; x++ {
			for y := 0; y < 8; y++ {
				a, b := dspPRSplit(s, 24, x, y, r, 32, w, h)
				c, d := dspPRSplitRef(s, 24, x, y, r, 32, w, h)
				if a != c || b != d {
					t.Fatalf("%dx%d %d,%d", w, h, x, y)
				}
			}
		}
	}
}
func BenchmarkDSPPRSplit(b *testing.B) {
	for _, wh := range [][2]int{{4, 4}, {4, 8}, {8, 4}, {8, 8}, {8, 16}} {
		for _, xy := range [][2]int{{4, 0}, {0, 4}, {3, 5}} {
			b.Run(fmt.Sprintf("%dx%d/%d_%d", wh[0], wh[1], xy[0], xy[1]), func(b *testing.B) {
				s, r := dspPRData(17*24), dspPRData(16*32)
				a, z := 0, 0
				b.ReportAllocs()
				for b.Loop() {
					a, z = dspPRSplit(s, 24, xy[0], xy[1], r, 32, wh[0], wh[1])
				}
				dspPRSink = a + z
			})
		}
	}
}
func dspPRCopy(w int, s []byte, ss int, d []byte, ds int) {
	if w == 4 {
		Copy4x4(s, ss, d, ds)
	} else {
		Copy8x4(s, ss, d, ds)
	}
}
func TestDSPPRCopy(t *testing.T) {
	for _, w := range []int{4, 8} {
		for _, ss := range []int{0, 3, 8, 24} {
			for _, ds := range []int{0, 2, 8, 24} {
				for _, offset := range []int{-1, 0, 1, 7, 15} {
					a, z := dspPRData(256), dspPRData(256)
					s, q := dspPRData(256), dspPRData(256)
					d, e := a, z
					if offset >= 0 {
						s, q = a, z
						d, e = a[offset:], z[offset:]
					}
					dspPRCopy(w, s, ss, d, ds)
					for y := 0; y < 4; y++ {
						copy(e[y*ds:y*ds+w], q[y*ss:y*ss+w])
					}
					if !slices.Equal(a, z) {
						t.Fatalf("w%d ss%d ds%d off%d", w, ss, ds, offset)
					}
				}
			}
		}
	}
}
func BenchmarkDSPPRCopy(b *testing.B) {
	for _, w := range []int{4, 8} {
		for _, ds := range []int{8, 24} {
			b.Run(fmt.Sprintf("w%d/stride%d", w, ds), func(b *testing.B) {
				s, d := dspPRData(128), dspPRData(128)
				b.ReportAllocs()
				for b.Loop() {
					dspPRCopy(w, s, 24, d, ds)
				}
				dspPRSink = int(d[0])
			})
		}
	}
}

func dspPRDirectionalRef(mode int, d []byte, ds int, a, l []byte, t byte) {
	switch mode {
	case 2:
		intra4x4VEPredictScalar(d, ds, a, t)
	case 3:
		intra4x4HEPredictScalar(d, ds, l, t)
	case 4:
		intra4x4LDPredictScalar(d, ds, a)
	case 5:
		intra4x4RDPredictScalar(d, ds, a, l, t)
	case 6:
		intra4x4VRPredictScalar(d, ds, a, l, t)
	case 7:
		intra4x4VLPredictScalar(d, ds, a)
	case 8:
		intra4x4HDPredictScalar(d, ds, a, l, t)
	case 9:
		intra4x4HUPredictScalar(d, ds, l)
	}
}
func TestDSPPRDirectional(t *testing.T) {
	for k := 0; k < 100; k++ {
		a, l := dspPRData(8), dspPRData(4)
		for i := range a {
			a[i] += byte(k * 11)
		}
		for i := range l {
			l[i] += byte(k * 31)
		}
		for mode := 2; mode < 10; mode++ {
			x, z := dspPRData(4*24), dspPRData(4*24)
			Intra4x4Predict(x, 24, common.BPredictionMode(mode), a, l, byte(k))
			dspPRDirectionalRef(mode, z, 24, a, l, byte(k))
			if !slices.Equal(x, z) {
				t.Fatalf("mode%d k%d", mode, k)
			}
		}
	}
}
func BenchmarkDSPPRDirectional(b *testing.B) {
	for mode := 2; mode < 10; mode++ {
		b.Run(fmt.Sprintf("mode%d", mode), func(b *testing.B) {
			a, l, d := dspPRData(8), dspPRData(4), dspPRData(4*24)
			b.ReportAllocs()
			for b.Loop() {
				Intra4x4Predict(d, 24, common.BPredictionMode(mode), a, l, 127)
			}
			dspPRSink = int(d[0])
		})
	}
}

func TestDSPPRError(t *testing.T) {
	for k := 0; k < 3000; k++ {
		var a, z [16]int16
		for i := range a {
			a[i] = int16(k*1517 + i*3791)
			z[i] = int16(k*1777 + i*3011)
		}
		x, y := TransformBlockError(&a, &z), transformBlockErrorScalar(&a, &z)
		if x != y {
			t.Fatalf("k%d %d!=%d", k, x, y)
		}
	}
	var a, z [16]int16
	for i := range a {
		a[i] = -32768
		z[i] = 32767
	}
	if TransformBlockError(&a, &z) != transformBlockErrorScalar(&a, &z) {
		t.Fatal("extreme")
	}
}
func BenchmarkDSPPRError(b *testing.B) {
	var a, z [16]int16
	for i := range a {
		a[i] = int16(i * 1517)
		z[i] = int16(i * 1777)
	}
	v := 0
	b.ReportAllocs()
	for b.Loop() {
		v = TransformBlockError(&a, &z)
	}
	dspPRSink = v
}
func TestDSPPRSAD4(t *testing.T) {
	for _, ss := range []int{0, 4, 24} {
		for _, rs := range []int{0, 4, 31} {
			s, r := dspPRData(4*24), dspPRData(4*31)
			for k := 0; k < 100; k++ {
				for i := range s {
					s[i] += byte(k * 11)
				}
				for i := range r {
					r[i] += byte(k * 31)
				}
				x, y := SAD4x4(s, ss, r, rs), sadBlockScalar(s, ss, r, rs, 4, 4)
				if x != y {
					t.Fatalf("k%d", k)
				}
			}
		}
	}
}
func BenchmarkDSPPRSAD4(b *testing.B) {
	for _, stride := range []int{4, 24} {
		b.Run(fmt.Sprintf("stride%d", stride), func(b *testing.B) {
			s, r := dspPRData(4*stride), dspPRData(4*stride)
			v := 0
			b.ReportAllocs()
			for b.Loop() {
				v = SAD4x4(s, stride, r, stride)
			}
			dspPRSink = v
		})
	}
}
func TestDSPPRSSE4(t *testing.T) {
	for _, h := range []int{4, 8} {
		for _, ss := range []int{0, 4, 24} {
			for _, rs := range []int{0, 4, 31} {
				s, r := dspPRData(h*24), dspPRData(h*31)
				for k := 0; k < 100; k++ {
					for i := range s {
						s[i] += byte(k * 11)
					}
					for i := range r {
						r[i] += byte(k * 31)
					}
					x := SSE4x4(s, ss, r, rs)
					if h == 8 {
						x = SSE4x8(s, ss, r, rs)
					}
					_, y := varianceBlockGeneric(s, ss, r, rs, 4, h)
					if x != y {
						t.Fatalf("h%d k%d", h, k)
					}
				}
			}
		}
	}
}
func BenchmarkDSPPRSSE4(b *testing.B) {
	for _, h := range []int{4, 8} {
		for _, stride := range []int{4, 24} {
			b.Run(fmt.Sprintf("h%d/stride%d", h, stride), func(b *testing.B) {
				s, r := dspPRData(h*stride), dspPRData(h*stride)
				v := 0
				b.ReportAllocs()
				for b.Loop() {
					if h == 4 {
						v = SSE4x4(s, stride, r, stride)
					} else {
						v = SSE4x8(s, stride, r, stride)
					}
				}
				dspPRSink = v
			})
		}
	}
}

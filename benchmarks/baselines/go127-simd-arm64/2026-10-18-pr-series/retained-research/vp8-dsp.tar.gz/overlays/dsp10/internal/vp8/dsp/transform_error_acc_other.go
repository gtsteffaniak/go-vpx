//go:build !goexperiment.simd || (!arm64 && !amd64) || purego

package dsp

func transformError16Go(a, b *[16]int16) uint64 { return uint64(transformBlockErrorScalar(a, b)) }

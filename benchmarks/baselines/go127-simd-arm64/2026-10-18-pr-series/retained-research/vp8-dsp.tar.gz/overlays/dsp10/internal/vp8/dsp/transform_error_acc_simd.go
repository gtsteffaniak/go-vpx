//go:build goexperiment.simd && (arm64 || amd64) && !purego

package dsp

import (
	"github.com/thesyncim/govpx/internal/pixel"
	"simd/archsimd"
)

func transformError16Go(a, b *[16]int16) uint64 {
	var sum archsimd.Uint64x2
	for i := 0; i < 16; i += 4 {
		d := pixel.Load4(a[i:]).Sub(pixel.Load4(b[i:]))
		// |difference|<=65535: each square fits uint32, even above MaxInt32.
		q := d.Mul(d).ToBits()
		hi := q.ReshapeToUint64s().InterleaveHi(q.ReshapeToUint64s()).ReshapeToUint32s()
		sum = sum.Add(q.ExtendLo2ToUint64()).Add(hi.ExtendLo2ToUint64())
	}
	return sum.GetElem(0) + sum.GetElem(1)
}

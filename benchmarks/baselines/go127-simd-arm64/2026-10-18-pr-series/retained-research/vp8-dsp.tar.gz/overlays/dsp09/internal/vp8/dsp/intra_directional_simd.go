//go:build goexperiment.simd && (arm64 || amd64) && !purego

package dsp

// The direct canonical formulas share seven rounded averages and write their
// repeated output values once. A generic selector kernel instead constructs
// a border and executes four whole-block permutes for these tiny predictors.
func intraDirectionalGo(_ int, _ []byte, _ int, _, _ []byte, _ byte) bool { return false }

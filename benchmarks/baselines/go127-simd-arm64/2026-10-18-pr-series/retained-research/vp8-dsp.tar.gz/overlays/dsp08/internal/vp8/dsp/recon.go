package dsp

import (
	"encoding/binary"
	"github.com/thesyncim/govpx/internal/pixel"
)

// Ported from libvpx v1.16.0 vp8/common/reconinter.c copy helpers.

func Copy4x4(src []byte, srcStride int, dst []byte, dstStride int) {
	if copyShortFourRows(src, srcStride, dst, dstStride, 4) {
		return
	}

	copyBlock(src, srcStride, dst, dstStride, 4, 4)
}

func Copy8x4(src []byte, srcStride int, dst []byte, dstStride int) {
	if copyShortFourRows(src, srcStride, dst, dstStride, 8) {
		return
	}

	copyBlock(src, srcStride, dst, dstStride, 8, 4)
}

func Copy8x8(src []byte, srcStride int, dst []byte, dstStride int) {
	if pixel.Copy8Rows(src, srcStride, dst, dstStride) {
		return
	}
	copyBlock(src, srcStride, dst, dstStride, 8, 8)
}

func Copy16x16(src []byte, srcStride int, dst []byte, dstStride int) {
	if pixel.Copy16Rows(src, srcStride, dst, dstStride) {
		return
	}
	copyBlock(src, srcStride, dst, dstStride, 16, 16)
}

func AddResidual4x4(dst []byte, dstStride int, residual *[16]int16) {
	for y := range 4 {
		// Pinning the row to a [4]byte view drops the per-cell bounds
		// check from each of the four writes.
		row := (*[4]byte)(dst[y*dstStride : y*dstStride+4])
		coeff := y * 4
		row[0] = ClipPixelAdd(row[0], int(residual[coeff+0]))
		row[1] = ClipPixelAdd(row[1], int(residual[coeff+1]))
		row[2] = ClipPixelAdd(row[2], int(residual[coeff+2]))
		row[3] = ClipPixelAdd(row[3], int(residual[coeff+3]))
	}
}

func copyBlock(src []byte, srcStride int, dst []byte, dstStride int, width int, height int) {
	for y := range height {
		copy(dst[y*dstStride:y*dstStride+width], src[y*srcStride:y*srcStride+width])
	}
}

// Each row is a complete native word load followed by its store. This keeps
// memmove semantics within overlapping rows and preserves row-to-row order.
func copyShortFourRows(src []byte, ss int, dst []byte, ds, w int) bool {
	if ss < 0 || ds < 0 || len(src) < w || len(dst) < w || ss > (len(src)-w)/3 || ds > (len(dst)-w)/3 {
		return false
	}
	if w == 4 {
		for y := 0; y < 4; y++ {
			binary.LittleEndian.PutUint32(dst[y*ds:], binary.LittleEndian.Uint32(src[y*ss:]))
		}
	} else {
		for y := 0; y < 4; y++ {
			binary.LittleEndian.PutUint64(dst[y*ds:], binary.LittleEndian.Uint64(src[y*ss:]))
		}
	}
	return true
}

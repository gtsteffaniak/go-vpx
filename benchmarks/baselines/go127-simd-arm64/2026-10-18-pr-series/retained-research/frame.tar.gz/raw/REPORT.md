# VP8 frame bookkeeping candidates

Preliminary native Apple M4 Max / Darwin ARM64, Go 1.27.2, GOEXPERIMENT=simd, PGO off, CGO enabled, GOMAXPROCS=1. Two 40 ms AB/BA pairs. Affected correctness and root stream checks are separate from kernel timings. No codec throughput claim.

| Candidate | Workload | Median speedup | Paired speedups |
|---|---|---:|---|
| frame01 | BenchmarkFramePR01/720p-flat | 1.052x | 1.037x, 1.067x |
| frame01 | BenchmarkFramePR01/720p-mixed | 0.934x | 0.890x, 0.977x |
| frame01 | BenchmarkFramePR01/720p-moving | 1.132x | 1.137x, 1.128x |
| frame01 | BenchmarkFramePR01/small-mixed | 0.836x | 0.920x, 0.752x |
| frame02 | BenchmarkFramePR02/empty | 6.417x | 6.969x, 5.865x |
| frame02 | BenchmarkFramePR02/skin | 11.157x | 10.871x, 11.443x |
| frame02 | BenchmarkFramePR02/mixed | 7.013x | 7.132x, 6.894x |
| frame03 | BenchmarkFramePR03/dark-reject | 2.948x | 3.019x, 2.878x |
| frame03 | BenchmarkFramePR03/skin-accept | 1.321x | 1.337x, 1.306x |
| frame03 | BenchmarkFramePR03/mixed | 1.261x | 1.267x, 1.255x |
| frame04 | BenchmarkFramePR04/skin | 3.982x | 3.967x, 3.998x |
| frame04 | BenchmarkFramePR04/mixed | 1.645x | 1.650x, 1.641x |
| frame04 | BenchmarkFramePR04/gray | 1.022x | 1.017x, 1.027x |
| frame05 | BenchmarkFramePR05/flat-last | 1.336x | 1.329x, 1.342x |
| frame05 | BenchmarkFramePR05/gradient-last | 0.990x | 1.021x, 0.959x |
| frame05 | BenchmarkFramePR05/mixed | 1.021x | 1.019x, 1.024x |
| frame06 | BenchmarkFramePR06/static-720p | 22.816x | 22.654x, 22.978x |
| frame06 | BenchmarkFramePR06/moving-720p | 0.906x | 0.859x, 0.953x |

frame01 is rejected: it did not reach the user's +15% kernel threshold. Only frame02–frame06 are selected for independent PRs.

## Contracts and limitations

- frame02 preserves row-major, in-place smoothing. Every value is classified as zero/nonzero, including nonbinary masks. A nonzero center needs any nonzero neighbor; a zero center needs all eight. Original row order and mutation dependencies remain intact.
- frame03 reads only source planes. It retains coordinate clamping and the exact two-of-four decision. It skips chroma reads when the luma gate proves the block cannot qualify, and stops when remaining votes cannot meet the threshold. Encoder source planes are validated before the picker; malformed-plane panic order is outside this internal helper contract.
- frame04 adds a 64 KiB immutable byte table and one-time package initialization. Exhaustive checks cover all 65,536 byte chroma pairs at the luma/motion decision boundaries. Nonbyte chroma uses the original integer classifier, preserving its arithmetic behavior. Gaussian configuration variables have no runtime mutation sites. Startup cost was not benchmarked and this is a steady-state kernel result.
- frame05 reads source and LAST only, with no changes to dot-artifact bookkeeping. It skips source gradient arithmetic when the LAST threshold cannot match. Production callers supply complete 8x8/16x16 windows from validated source/reference planes; malformed-window panic order is outside this internal helper contract.
- frame06 writes the skin map and reads consecutive-zero counters. These are separately owned encoder buffers allocated in vp8_encoder_alloc.go. The optimized case requires every counter >60, which makes every macroblock ineligible before reading any pixel; clearing the map produces exactly the original all-zero result. The moving-frame control loses approximately 9.4% in the short screen and is retained explicitly rather than hidden.

All raw AB/BA rows are the frame0N-r1/r2-base/candidate.txt files. The uniform timing source fixture is retained in base/vp8_frame_prs_test.go. Publication fixtures are minimized per PR and use unique helper names.

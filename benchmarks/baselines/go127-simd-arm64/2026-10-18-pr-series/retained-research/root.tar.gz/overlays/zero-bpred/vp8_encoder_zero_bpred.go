package govpx
import vp8enc "github.com/thesyncim/govpx/internal/vp8/encoder"
func bPredZeroResidualIdentity(state *uint8, fast bool,q *vp8enc.BlockQuant,zbin,activity int) bool {
 if *state==0 {var zero,qc,dq [16]int16;vp8enc.QuantizeDecisionBlockWithActivity(fast,&zero,q,zbin,activity,&qc,&dq);*state=1;if dq==([16]int16{}){*state=2}}
 return *state==2
}

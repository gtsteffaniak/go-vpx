package govpx
import(vp8enc "github.com/thesyncim/govpx/internal/vp8/encoder";"github.com/thesyncim/govpx/internal/pixel")
func prepareBPredSource(src vp8enc.SourceImage, row,col,block int)(out [16]byte){
 x:=col*16+(block&3)*4;y:=row*16+(block>>2)*4
 if x>=0&&y>=0&&x<=src.Width-4&&y<=src.Height-4 {for r:=range 4{copy(out[r*4:r*4+4],src.Y[(y+r)*src.YStride+x:])};return}
 for r:=range 4{sy:=clampEncodeCoord(y+r,src.Height);for c:=range 4{sx:=clampEncodeCoord(x+c,src.Width);out[r*4+c]=src.Y[sy*src.YStride+sx]}}
 return
}
func fillPreparedBPredResidual(src,pred *[16]byte,out *[16]int16){pixel.Subtract(src[:],4,pred[:],4,out[:],4,4,4)}

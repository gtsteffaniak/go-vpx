import re
exec(open('/private/tmp/govpx-iterations50/build.py').read().split('selected=')[0])
for name in ('base','combined'):
 p=D/name
 with (D/(name+'-whole-build.log')).open('w') as f:
  cmds=[[str(R/'scripts/go.sh'),'-C',str(p),'build','-pgo=off','-o',str(D/(name+'-whole')),'./cmd/govpx-bench'],[str(R/'scripts/go.sh'),'-C',str(p),'test','-pgo=off','.','-run','^TestMLCacheStreamNative$','-count=1','-v']]
  for cmd in cmds:
   result=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
   if result.returncode:raise RuntimeError((name,result.returncode))
 print(name,'whole-build and72packet streamPASS',flush=True)
a=re.findall(r'stream_sha256=(\w+)',(D/'base-whole-build.log').read_text());b=re.findall(r'stream_sha256=(\w+)',(D/'combined-whole-build.log').read_text());assert len(a)==3 and a==b,(a,b);print('all3streamsha256match/72packets',flush=True)

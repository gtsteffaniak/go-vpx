from pathlib import Path
import shutil
D=Path('/private/tmp/govpx-iterations50');p=D/'25-pre-multiply-zero';shutil.copytree(D/'base',p,dirs_exist_ok=True);f='internal/pixel/quantize_vp8_batch_arm64.go';s=(p/f).read_text();s=s.replace('\tz := archsimd.Int16x8{}','\tz := archsimd.Int16x8{}\n zeroThreshold := vp8BatchZeroThreshold(d0,q0) && vp8BatchZeroThreshold(d1,q1)',1)
needle='\t\tt0, t1 := vp8QuantPacket(c0, r0, q0), vp8QuantPacket(c1, r1, q1)';s=s.replace(needle,'''        a0, a1 := c0.Abs().ToBits().Add(r0.ToBits()),c1.Abs().ToBits().Add(r1.ToBits())
        if zeroThreshold && a0.Less(d0.ToBits()).And(a1.Less(d1.ToBits())).ToInt16x8().ReduceMax() == -1 {
            z.StoreArray((*[8]int16)(unsafe.Add(qp,off)));z.StoreArray((*[8]int16)(unsafe.Add(qp,off+16)))
            z.StoreArray((*[8]int16)(unsafe.Add(dp,off)));z.StoreArray((*[8]int16)(unsafe.Add(dp,off+16)))
            eobs[i]=0;continue
        }
        m0,m1 := vp8MulHighU16(a0,q0.ToBits()).BitsToInt16(),vp8MulHighU16(a1,q1.ToBits()).BitsToInt16()
        t0 := z.Sub(m0).IfElse(c0.Less(z),m0)
        t1 := z.Sub(m1).IfElse(c1.Less(z),m1)''')
s+='''
// If d*q<=65536 and abs(c)+round<d, the unsigned high product is exactly zero.
// Check the public mutable tables once per batch; unusual tables retain full math.
func vp8BatchZeroThreshold(d,q archsimd.Int16x8) bool {
 if d.ReduceMin()<=0 {return false}
 lo,hi := d.MulWidenLo(q),d.HiToLo().MulWidenLo(q.HiToLo())
 return lo.Max(hi).ReduceMax() <= 65536
}
''';(p/f).write_text(s)

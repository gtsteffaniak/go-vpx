from pathlib import Path
import shutil
D=Path('/private/tmp/govpx-iterations50');base=D/'base';E='internal/vp8/encoder/';B=E+'dct_batch_gosimd_arm64.go'
def variant(n,name):
 p=D/f'{n:02d}-{name}';shutil.copytree(base,p,dirs_exist_ok=True);return p
def put(p,f,s):(p/f).write_text(s)
p=variant(19,'arrays-ordinary-range');s=(D/'02-batch-array-windows'/B).read_text().replace('if peak-1 >= 255 {','if peak == 0 || peak > 255 {');put(p,B,s)
p=variant(20,'uniform-endpoint-prefilter');s=(D/'03-uniform-dc'/B).read_text();a=s.index('// Constant blocks');b=s.index('// Deinterleave',a);code=s[a:b];code=code.replace('dc0, dc1 := r0.GetElem(0), r2.GetElem(0)','dc0, dc1 := r0.GetElem(0), r2.GetElem(0)\n if dc0 == r1.GetElem(7) && dc1 == r3.GetElem(7) {')+'\n}\n';s=s[:a]+code+s[b:];put(p,B,s)
p=variant(21,'quant-zero-packets');f='internal/pixel/quantize_vp8_batch_arm64.go';s=(p/f).read_text();s=s.replace('\tz := archsimd.Int16x8{}','\tz := archsimd.Int16x8{}\n zeroMapsToZero := vp8QuantPacket(z,r0,q0).Or(vp8QuantPacket(z,r1,q1)).ToBits().ReduceMax() == 0',1);needle='\t\tt0, t1 := vp8QuantPacket(c0, r0, q0), vp8QuantPacket(c1, r1, q1)';s=s.replace(needle,'''        if zeroMapsToZero && c0.Or(c1).ToBits().ReduceMax() == 0 {
            z.StoreArray((*[8]int16)(unsafe.Add(qp,off))); z.StoreArray((*[8]int16)(unsafe.Add(qp,off+16)))
            z.StoreArray((*[8]int16)(unsafe.Add(dp,off))); z.StoreArray((*[8]int16)(unsafe.Add(dp,off+16)))
            eobs[i]=0;continue
        }
'''+needle);put(p,f,s)
p=variant(22,'quant-bitwise-sign');f='internal/pixel/quantize_vp8_simd.go';s=(p/f).read_text().replace('return archsimd.Int16x8{}.Sub(magnitude).IfElse(c.Less(archsimd.Int16x8{}), magnitude)','sign := c.Less(archsimd.Int16x8{}).ToInt16x8()\n return magnitude.Xor(sign).Sub(sign)');put(p,f,s)
p=variant(23,'shared-quant-two');f=E+'quant_batch_other.go';put(p,f,(p/f).read_text().replace('count >= 8','count >= 2'))
p=variant(24,'shared-quant-one');f=E+'quant_batch_other.go';put(p,f,(p/f).read_text().replace('count >= 8','count >= 1'))
fixture='''
func BenchmarkIterationQuant(b *testing.B){for _,pat:=range []string{"zero","sparse","dense"}{for _,count:=range []int{1,2,8,16}{b.Run(pat+"/"+string(rune('A'+count)),func(b *testing.B){var deq [16]int16;for i:=range deq{deq[i]=int16(i+10)};var quant BlockQuant;InitFastBlockQuant(&deq,&quant);c:=make([]int16,count*16);q:=make([]int16,len(c));dq:=make([]int16,len(c));e:=make([]uint8,count);for i:=range c{if pat=="dense"{c[i]=int16((i*17)%8191-4095)}else if pat=="sparse"&&i%16==0{c[i]=17}};b.ReportAllocs();for b.Loop(){FastQuantizeBlockBatch(c,&quant,q,dq,e,count)}})}}}
'''
for p in [base]+[x for x in D.glob('[0-9][0-9]-*') if x.is_dir()]:
 f=p/E/'iteration_fdct_test.go';s=f.read_text();
 if 'BenchmarkIterationQuant' not in s:f.write_text(s+fixture)
print('prepared19–24')

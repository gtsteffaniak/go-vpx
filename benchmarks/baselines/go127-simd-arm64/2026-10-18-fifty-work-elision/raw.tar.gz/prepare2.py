from pathlib import Path
import shutil,re
D=Path('/private/tmp/govpx-iterations50');base=D/'base';E='internal/vp8/encoder/';B=E+'dct_batch_gosimd_arm64.go';S=E+'transform_simd.go'
def variant(n,name):
 p=D/f'{n:02d}-{name}';shutil.copytree(base,p,dirs_exist_ok=True);return p
def put(p,f,s):(p/f).write_text(s)
p=variant(9,'uniform-before-range');s=(p/B).read_text();u=(D/'03-uniform-dc'/B).read_text();a=u.index('// Constant blocks');b=u.index('// Deinterleave',a);gate=u[a:b].replace('if diff.ToBits().ReduceMax() == 0 {','if uint32(int32(dc0)+255) <= 510 && uint32(int32(dc1)+255) <= 510 && diff.ToBits().ReduceMax() == 0 {');s=s.replace('\t\tmagnitude :=', '\t\t'+gate+'magnitude :=',1);put(p,B,s)
p=variant(10,'signed-range-reduction');s=(p/B).read_text();a=s.index('\t\tmagnitude :=');b=s.index('\t\t// Deinterleave',a);s=s[:a]+'''        lo := r0.Min(r1).Min(r2.Min(r3)).ReduceMin()
        hi := r0.Max(r1).Max(r2.Max(r3)).ReduceMax()
        if lo == 0 && hi == 0 {
            v := archsimd.Int16x8{}.SetElem(1, 1); z := archsimd.Int16x8{}
            v.Store(out); z.Store(out[8:]); v.Store(out[16:]); z.Store(out[24:]); continue
        }
        if lo < -255 || hi > 255 {
            forwardDCT4x4Scalar(in, 4, (*[16]int16)(out)); forwardDCT4x4Scalar(in[16:], 4, (*[16]int16)(out[16:])); continue
        }
'''+s[b:];put(p,B,s)
p=variant(11,'half-zero-packet');s=(p/B).read_text();s=s.replace('// Deinterleave the four input columns across eight rows (two blocks).','''zero0 := r0.Or(r1).ToBits().ReduceMax() == 0
        zero1 := r2.Or(r3).ToBits().ReduceMax() == 0
        if zero0 || zero1 {
            var stage, result [16]int16
            if zero0 { r2.Store(stage[:]); r3.Store(stage[8:]) } else { r0.Store(stage[:]); r1.Store(stage[8:]) }
            forwardDCT4x4SIMD(stage[:], 4, &result)
            z := archsimd.Int16x8{}; v := z.SetElem(1, 1)
            if zero0 { v.Store(out); z.Store(out[8:]); copy(out[16:32], result[:]) } else { copy(out[:16],result[:]); v.Store(out[16:]);z.Store(out[24:]) }
            continue
        }
        // Deinterleave the four input columns across eight rows (two blocks).''');put(p,B,s)
p=variant(12,'single-zero-packet');s=(p/S).read_text();needle='a, b, c, d := pixel.Transpose4(pixel.Load4(input), pixel.Load4(input[stride:]), pixel.Load4(input[2*stride:]), pixel.Load4(input[3*stride:]))';s=s.replace(needle,'''a, b, c, d := pixel.Load4(input), pixel.Load4(input[stride:]), pixel.Load4(input[2*stride:]), pixel.Load4(input[3*stride:])
    if a.Or(b).Or(c).Or(d).ToBits().ReduceMax() == 0 {
        *output = [16]int16{}
        if !walsh { output[1] = 1 }
        return true
    }
    a,b,c,d = pixel.Transpose4(a,b,c,d)''');put(p,S,s)
p=variant(13,'single-subtract-condition');s=(p/S).read_text().replace('\tone := archsimd.BroadcastInt32x4(1)\n','').replace('x.Add(y).Add(x.NotEqual(zero).ToInt32x4().And(one))','x.Add(y).Sub(x.NotEqual(zero).ToInt32x4())').replace('.Add(w.NotEqual(zero).ToInt32x4().And(one))','.Sub(w.NotEqual(zero).ToInt32x4())');put(p,S,s)
p=variant(14,'walsh-negative-mask');s=(p/S).read_text();
for v in ('v0','v1','v2','v3'):s=s.replace(f'{v}.Sub(vp8Sign({v}))',f'{v}.Sub({v}.Less(zero).ToInt32x4())')
put(p,S,s)
helper='''
// Fast SIMD gathers change load/store grouping; preserve scalar behavior for aliased outputs.
func residualOutputDisjoint(src, pred []byte, out []int16) bool {
    op := uintptr(unsafe.Pointer(unsafe.SliceData(out)))
    overlap := func(b []byte) bool {
        bp := uintptr(unsafe.Pointer(unsafe.SliceData(b)))
        return len(b) != 0 && len(out) != 0 && ((bp <= op && op-bp < uintptr(len(b))) || (op < bp && bp-op < uintptr(len(out))*2))
    }
    return !overlap(src) && !overlap(pred)
}
'''
p=variant(15,'pred-buffer-gather');f=E+'residual_gather.go';s=(p/f).read_text();needle='func GatherMacroblockYResiduals4x4FromPredBuffer(src []byte, srcStride int, width int, height int, pred []byte, predStride int, mbBaseX int, mbBaseY int, out []int16) {';s=s.replace(needle,needle+'''
    if width >= 16 && height >= 16 && uint(mbBaseX) <= uint(width-16) && uint(mbBaseY) <= uint(height-16) && srcStride >= width && predStride >= 16 && len(out) >= 256 && len(src) >= mbBaseX+16 && len(pred) >= 16 && mbBaseY+15 <= (len(src)-mbBaseX-16)/srcStride && predStride <= (len(pred)-16)/15 && residualOutputDisjoint(src,pred,out[:256]) {
        sp := (*byte)(unsafe.Add(unsafe.Pointer(unsafe.SliceData(src)),mbBaseY*srcStride+mbBaseX))
        dsp.ResidualGather16x16PtrFast(sp,srcStride,unsafe.SliceData(pred),predStride,unsafe.SliceData(out))
        return
    }
''');put(p,f,s+helper)
p=variant(16,'predicted-four-simd');f=E+'residual_gather.go';s=(p/f).read_text().replace('"unsafe"','"unsafe"\n "github.com/thesyncim/govpx/internal/pixel"');a=s.index('func FillPredictedResidual4x4(');b=s.index('// FillPredictedResidual4x4Slice',a);header=s[a:s.index('{',a)+1];s=s[:a]+header+'\n FillPredictedResidual4x4Slice(src,srcStride,width,height,pred,predStride,x,y,out[:])\n}\n\n'+s[b:];needle='func FillPredictedResidual4x4Slice(src []byte, srcStride int, width int, height int, pred []byte, predStride int, x int, y int, out []int16) {';s=s.replace(needle,needle+'''
 if width >= 4 && height >= 4 && uint(x)<=uint(width-4) && uint(y)<=uint(height-4) && srcStride>=width && predStride>=x+4 && len(out)>=16 && len(src)>=x+4 && len(pred)>=x+4 && y+3<=(len(src)-x-4)/srcStride && y+3<=(len(pred)-x-4)/predStride && residualOutputDisjoint(src,pred,out[:16]) {
    pixel.Subtract(src[y*srcStride+x:],srcStride,pred[y*predStride+x:],predStride,out,4,4,4);return
 }
''');put(p,f,s+helper)
p=variant(17,'bpred-sse-bridge');f=E+'bpred_block.go';s=(p/f).read_text().replace('package encoder','package encoder\n\nimport "github.com/thesyncim/govpx/internal/vp8/dsp"',1);needle='\tsse := 0';s=s.replace(needle,'''    if src.Width>=4 && src.Height>=4 && uint(baseX)<=uint(src.Width-4) && uint(baseY)<=uint(src.Height-4) && src.YStride>=src.Width && predStride>=4 && len(src.Y)>=baseX+4 && len(pred)>=4 && baseY+3<=(len(src.Y)-baseX-4)/src.YStride && predStride <= (len(pred)-4)/3 {
        return dsp.SSE4x4(src.Y[baseY*src.YStride+baseX:],src.YStride,pred,predStride)
    }
'''+needle,1);put(p,f,s)
p=variant(18,'bpred-residual-bridge');f=E+'bpred_block.go';s=(p/f).read_text().replace('package encoder','package encoder\n\nimport("unsafe";"github.com/thesyncim/govpx/internal/pixel")',1);a=s.index('func FillBPredResidual4x4');b=s.index('\tfor row := range 4 {',a);s=s[:b]+'''    if src.Width>=4 && src.Height>=4 && uint(baseX)<=uint(src.Width-4) && uint(baseY)<=uint(src.Height-4) && src.YStride>=src.Width && len(src.Y)>=baseX+4 && len(pred)>=16 && baseY+3<=(len(src.Y)-baseX-4)/src.YStride && residualOutputDisjoint(src.Y,pred,out[:]) {
        pixel.Subtract(src.Y[baseY*src.YStride+baseX:],src.YStride,pred,4,out[:],4,4,4);return
    }
'''+s[b:];put(p,f,s+helper)
# Extend identical bench fixture for single transform, local prediction buffer and B_PRED.
fixture='''
func BenchmarkIterationSingle(b *testing.B){for _,walsh:=range []bool{false,true}{for _,pat:=range []string{"zero","dc","dense"}{name:="dct";if walsh{name="walsh"};b.Run(name+"/"+pat,func(b *testing.B){var in,out [16]int16;for i:=range in{if pat=="dc"{in[i]=17}else if pat=="dense"{in[i]=int16((i*37+11)%511-255)}};b.ReportAllocs();for b.Loop(){if walsh{ForwardWalsh4x4(in[:],4,&out)}else{ForwardDCT4x4(in[:],4,&out)}}})}}}
func BenchmarkIterationGather(b *testing.B){for _,edge:=range []bool{false,true}{name:="interior";width:=48;height:=48;x:=16;y:=16;if edge{name="edge";x=40;y=40};b.Run(name,func(b *testing.B){src:=make([]byte,48*48);pred:=make([]byte,16*16);for i:=range src{src[i]=byte(i*17)};for i:=range pred{pred[i]=byte(i*31)};var out [256]int16;b.ReportAllocs();for b.Loop(){GatherMacroblockYResiduals4x4FromPredBuffer(src,48,width,height,pred,16,x,y,out[:])}})}}
func BenchmarkIterationBPred(b *testing.B){src:=SourceImage{Y:make([]byte,48*48),YStride:48,Width:48,Height:48};for i:=range src.Y{src.Y[i]=byte(i*17)};pred:=make([]byte,16*16);for i:=range pred{pred[i]=byte(i*31)};b.Run("sse",func(b *testing.B){b.ReportAllocs();for b.Loop(){iterationSink=BPredBlockSSE(src,1,1,5,pred,4)}});b.Run("residual",func(b *testing.B){var out [16]int16;b.ReportAllocs();for b.Loop(){FillBPredResidual4x4(src,1,1,5,pred,&out)}});b.Run("predicted",func(b *testing.B){var out [16]int16;b.ReportAllocs();for b.Loop(){FillPredictedResidual4x4(src.Y,48,48,48,src.Y,48,20,20,&out)}})}
var iterationSink int
func TestIterationResidualBridges(t *testing.T){for _,w:=range []int{1,15,16,17,48}{for _,h:=range []int{1,15,16,19,48}{stride:=w+5;src:=make([]byte,stride*h);pred:=make([]byte,256);for i:=range src{src[i]=byte(i*17)};for i:=range pred{pred[i]=byte(i*31)};for _,x:=range []int{0,w-1}{for _,y:=range []int{0,h-1}{var got,want [256]int16;GatherMacroblockYResiduals4x4FromPredBuffer(src,stride,w,h,pred,16,x,y,got[:]);for block:=range 16{bx:=(block&3)*4;by:=(block>>2)*4;for r:=range 4{for c:=range 4{sx:=min(x+bx+c,w-1);sy:=min(y+by+r,h-1);want[block*16+r*4+c]=int16(src[sy*stride+sx])-int16(pred[(by+r)*16+bx+c])}}};if got!=want{t.Fatalf("gather %dx%d@%d,%d",w,h,x,y)}}};image:=SourceImage{Y:src,YStride:stride,Width:w,Height:h};for block:=range 16{var got,want [16]int16;FillBPredResidual4x4(image,0,0,block,pred,&got);sse:=0;for r:=range 4{for c:=range 4{x:=min((block&3)*4+c,w-1);y:=min((block>>2)*4+r,h-1);v:=int(src[y*stride+x])-int(pred[r*4+c]);want[r*4+c]=int16(v);sse+=v*v}};if got!=want||BPredBlockSSE(image,0,0,block,pred,4)!=sse{t.Fatalf("bpred %dx%d block%d",w,h,block)}}}}}
'''
for p in [base]+[x for x in D.glob('[0-9][0-9]-*') if x.is_dir()]:
 f=p/E/'iteration_fdct_test.go';s=f.read_text();
 if 'BenchmarkIterationSingle' not in s:f.write_text(s+fixture)
print('prepared 9–18')

from pathlib import Path
import subprocess,os,json,time
D=Path('/private/tmp/govpx-iterations50');R=Path('/Users/thesyncim/GolandProjects/govpx')
env=os.environ|{'CODEX_AGENT_ID':'root-iterations50','CODEX_PROJECT_CACHE_ROOT':'/private/tmp/codex-projects','GOTOOLCHAIN':'local','GO':'/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go','GOEXPERIMENT':'simd','GOMAXPROCS':'2','GOFLAGS':'-p=2','CGO_ENABLED':'1'}
selected=['base']+__import__('sys').argv[1:]
if len(selected)==1:selected+= [p.name for p in sorted(D.glob('[0-9][0-9]-*')) if p.is_dir()]
for name in selected:
 p=D/name;log=D/(name+'-build.log')
 with log.open('w') as f:
  cmd=[str(R/'scripts/go.sh'),'-C',str(p),'test','-c','-pgo=off','-o',str(D/(name+'.test')),'./internal/vp8/encoder']
  result=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
  if result.returncode==0:
   result=subprocess.run([str(D/(name+'.test')),'-test.run=^Test(IterationFDCTPackets|FDCTZero|ForwardDCT4x4|ForwardDCTBatchIndependentScalar|WalshFullSignedNative|ForwardWalsh|IterationResidual(Bridges|AliasOrder)|FillResidual4x4SliceMatchesLibvpxEdgeExtension|VP8PickerSubtractFDCTParity|UVResidualGatherMatchesLibvpxBlockLayout|Quant|FastQuantizeBlock(SIMD|FullSigned|Sentinel|Zeroes|Allocates|Batch))','-test.count=1'],cwd=p,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,'PASS' if result.returncode==0 else 'FAIL',flush=True)
 if result.returncode:print(log.read_text()[-2500:],flush=True)

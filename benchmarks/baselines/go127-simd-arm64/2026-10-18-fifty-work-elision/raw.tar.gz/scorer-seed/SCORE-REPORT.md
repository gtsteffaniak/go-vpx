The fused BlockYrd scoring change is a keeper on native Apple M4 Max (Go1.27.2 archsimd, CGO1, PGOoff, GOMAXPROCS1). The baseline is the already-accepted Hadamard-only candidate, not the older canonical transform. This is a short three-pair40ms component screen and three-pair whole screen, not a stable C-throughput claim.

The private six-file delta is score.patch, with exact sources in score-source.json. The candidate is ../candidate-score. The root PR54 BlockYrd baseline matches the frozen Hadamard source. Generic quantizer APIs remain unchanged. The consumer-specialized path removes q/dq materialization, sign restoration, scan/EOB loads and reduction, and later SATD/error rereads. Zero residuals reuse the nonzero flag already returned by subtraction and skip all transform/scoring work.

Correctness: the existing300 scalar consumer cases pass, plus192 new full-consumer boundary/SSE cases. Signed-int16 ramps cover all coefficient values across12 dequant pairs and64/256 coefficient counts; uniform extremes check accumulation. These are15,600 independent scalar aggregate comparisons (1,611,264 coefficient comparisons), not an exhaustive Cartesian product of coefficient positions and quantizers. All72 public packets retain the frozen SHA256 digests. ARM native and AMD cross-build pass; AMD execution/performance remains pending. Logs: score-targeted.log and score-stream.log. No broad suite was repeated.

The fast domain is the exact BlockYrd-derived quantizer tables and3<=dequant<=2048. With a=abs(coeff), clipped=min(a+round,32767), qabs=floor(clipped*floor(65536/d)/65536), qabs*d<=32767. Also -round<=a-qabs*d<1+1.5*d<=3073. Thus dequantization cannot wrap, sign restoration is unnecessary for abs(q) and squared error, each signed32 accumulator stays below2^31, and the full256-coefficient squared-error sum stays below2^32. Wider/unusual quantizers andTx4 retain the existing path. Scratch extent checks run before dispatch; the optimized path consumes only complete, disjoint residual/temporary slices. Only aggregate BlockYrdResult is observable at its production callers.

Actual ARM LLVM in score-llvm.txt confirms blockYrdQuantScore is a leaf with no stack frame, no calls, no q/dq stores, and no scan loads. Its loop loads one eight-coefficient packet and retains rate/error accumulators in registers.

All12 component medians and all36 paired comparisons improve; allocations remain0. Ten medians exceed1.5x. Pattern0 is zero residual, pattern1 is DC residual, pattern2 is dense. Exact raw, binaries/source SHA256 bindings, commands, and all paired data are in score-screen/.

|Transform/block|Zero|DC|Dense|
|---|---:|---:|---:|
|8/32|5.9239x|1.7119x|2.2040x|
|8/64|6.4054x|1.6723x|2.1850x|
|16/32|4.6520x|1.4063x|1.8190x|
|16/64|4.9960x|1.3540x|1.7759x|

Whole-codec CPU8/one-thread results, identical22 reported semantic fields and separate allocation values:

- 320: median time change +1.1712%; 2/3 slower. All pairs: -3.8151%, +1.1712%, +2.1396%.
- 1280: median time change -6.7051%; 0/3 slower. All pairs: -7.1805%, -6.7051%, -3.5823%.

320x180 uses120inputs/500kbps;720p uses60inputs/2500kbps. The320p loss remains explicit. At CPU8, small-block simple scoring bypasses the transform path, so this component is not equally prominent in both workloads; the screen does not establish the cause of the320p movement.

Work-count diagnostics against pinnedlibvpx are separately preserved in work-counts/. Both encoders emitted117/120 frames at320p and48/60 at720p. Inter-mode picks were40,074 Go vs40,084 C, and95,847 Go vs99,586 C. Go reused every write-pass decision with no replay misses. Outputs differ19/405 bytes; these are same-input work-volume observations, not exact stream parity or throughput results. Instrumented timings are excluded.

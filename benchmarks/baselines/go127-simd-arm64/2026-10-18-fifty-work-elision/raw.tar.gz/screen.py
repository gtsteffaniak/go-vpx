from pathlib import Path
import subprocess,os,re,json,statistics,sys,time
D=Path('/private/tmp/govpx-iterations50');env=os.environ|{'GOMAXPROCS':'1'};out=D/'screen';out.mkdir(exist_ok=True)
names=sys.argv[1:] or [p.name for p in sorted(D.glob('[0-9][0-9]-*')) if p.is_dir()]
results={}
def read(p):
 d={}
 for line in p.read_text().splitlines():
  m=re.match(r'(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',line)
  if m:d[m[1]]={'ns':float(m[2]),'bytes':int(m[3]),'allocs':int(m[4])}
 return d
for name in names:
 i=int(name[:2]);pat='^BenchmarkIterationFDCT$'
 if i in (1,8):pat='^Benchmark(IterationFDCT|ForwardDCT4x4SIMD|ForwardWalsh4x4SIMD)$'
 if 12 <= i <= 14:pat='^BenchmarkIterationSingle$'
 if i==15:pat='^BenchmarkIterationGather$'
 if 16<=i<=18:pat='^BenchmarkIterationBPred$'
 if 21<=i<=25:pat='^BenchmarkIterationQuant$'
 entries=[]
 for rnd in (1,2):
  for ref in (['base',name] if rnd==1 else [name,'base']):
   p=out/f'{name}-r{rnd}-{ref}.txt'
   with p.open('w') as f, p.with_suffix('.stderr').open('w') as e:
    c=subprocess.run([str(D/(ref+'.test')),'-test.run=^$','-test.bench='+pat,'-test.benchtime=40ms','-test.count=1','-test.benchmem'],env=env,cwd=D/ref,stdout=f,stderr=e)
   if c.returncode:raise RuntimeError((name,ref,c.returncode))
   entries.append({'round':rnd,'ref':ref,'file':str(p),'values':read(p)})
 pairs={}
 for rnd in (1,2):
  a=next(e for e in entries if e['round']==rnd and e['ref']=='base')['values'];b=next(e for e in entries if e['round']==rnd and e['ref']==name)['values']
  for k in a.keys()&b.keys():pairs.setdefault(k,[]).append(a[k]['ns']/b[k]['ns'])
 results[name]={'pairs':pairs,'medians':{k:statistics.median(v) for k,v in pairs.items()},'entries':entries}
 print(name, json.dumps(results[name]['medians'],sort_keys=True),flush=True)
 existing=json.loads((out/'summary.json').read_text()) if (out/'summary.json').exists() else {}
 existing.update(results);(out/'summary.json').write_text(json.dumps(existing,indent=2)+'\n')

from pathlib import Path
import subprocess,os,json,statistics,sys
D=Path('/private/tmp/govpx-iterations50');O=D/'whole-screen';O.mkdir(exist_ok=True);env=os.environ|{'GOMAXPROCS':'1'}
workloads={'vp8-720': ['-codec=vp8','-width=1280','-height=720','-frames=60','-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8'], 'vp9-320':['-codec=vp9','-width=320','-height=180','-frames=120','-fps=30','-bitrate=500','-mode=realtime','-cpu-used=8'], 'vp9-720':['-codec=vp9','-width=1280','-height=720','-frames=60','-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8']}
rows=[];candidate=sys.argv[1] if len(sys.argv)>1 else 'final'
for rnd in (1,2):
 for name,args in workloads.items():
  for ref in (('base',candidate) if rnd==1 else (candidate,'base')):
   cmd=[str(D/(ref+'-whole'))]+args+['-threads=1','-encode-only','-auto-libvpx=false','-format=json'];p=O/f'r{rnd}-{name}-{ref}.json'
   with p.open('w') as f,p.with_suffix('.stderr').open('w') as e:r=subprocess.run(cmd,cwd=D,env=env,stdout=f,stderr=e)
   if r.returncode:raise RuntimeError((name,ref,r.returncode))
   rows.append({'round':rnd,'workload':name,'ref':ref,'cmd':cmd,'value':json.loads(p.read_text())});print(rnd,name,ref,rows[-1]['value']['ns_per_frame'],flush=True)
perf={'ns_per_frame','encode_fps','macroblocks_per_second','allocs_per_frame','latency_ns'}
summary={}
for name in workloads:
 pairs=[];alloc=[]
 for rnd in (1,2):
  a=next(x['value'] for x in rows if x['round']==rnd and x['workload']==name and x['ref']=='base');b=next(x['value'] for x in rows if x['round']==rnd and x['workload']==name and x['ref']==candidate)
  sa={k:v for k,v in a.items() if k not in perf};sb={k:v for k,v in b.items() if k not in perf};assert sa==sb,(name,rnd,{k:(sa.get(k),sb.get(k)) for k in sa.keys()|sb.keys() if sa.get(k)!=sb.get(k)})
  pairs.append(a['ns_per_frame']/b['ns_per_frame']);alloc.append([a['allocs_per_frame'],b['allocs_per_frame']])
 summary[name]={'speedup_pairs':pairs,'median_speedup':statistics.median(pairs),'allocs_per_frame_pairs':alloc,'semantic_fields':len(sa),'semantic_equal':True}
(O/'summary.json').write_text(json.dumps({'summary':summary,'rows':rows},indent=2)+'\n');print(json.dumps(summary,sort_keys=True),flush=True)

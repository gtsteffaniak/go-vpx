from pathlib import Path
import shutil,json,re
D=Path('/private/tmp/govpx-iterations50');E='internal/vp8/encoder/';B=E+'dct_batch_gosimd_arm64.go';S=E+'transform_simd.go'
p=D/'25-quantized-zero';shutil.copytree(D/'base',p,dirs_exist_ok=True)
f='internal/pixel/quantize_vp8_batch_arm64.go';s=(p/f).read_text();needle='\t\tt0, t1 := vp8QuantPacket(c0, r0, q0), vp8QuantPacket(c1, r1, q1)';s=s.replace(needle,'''        m0 := vp8MulHighU16(c0.Abs().ToBits().Add(r0.ToBits()),q0.ToBits()).BitsToInt16()
        m1 := vp8MulHighU16(c1.Abs().ToBits().Add(r1.ToBits()),q1.ToBits()).BitsToInt16()
        if m0.Or(m1).ToBits().ReduceMax() == 0 {
            z.StoreArray((*[8]int16)(unsafe.Add(qp,off)));z.StoreArray((*[8]int16)(unsafe.Add(qp,off+16)))
            z.StoreArray((*[8]int16)(unsafe.Add(dp,off)));z.StoreArray((*[8]int16)(unsafe.Add(dp,off+16)))
            eobs[i]=0;continue
        }
        t0 := z.Sub(m0).IfElse(c0.Less(z),m0)
        t1 := z.Sub(m1).IfElse(c1.Less(z),m1)''');(p/f).write_text(s)
for p in [D/'base',p]:
 f=p/E/'iteration_fdct_test.go';s=f.read_text().replace('[]string{"zero","sparse","dense"}', '[]string{"zero","below","sparse","dense"}').replace('if pat=="dense"{c[i]=','if pat=="below"{c[i]=1}else if pat=="dense"{c[i]=');f.write_text(s)
# Combine measured keepers from1–24 with the already-published scorer seed.
p=D/'combined';shutil.copytree(D/'base',p,dirs_exist_ok=True)
seed=Path('/Users/thesyncim/GolandProjects/govpx')
for f in json.load(open('/private/tmp/govpx-astra-extra-work55/proof/score-source.json')):shutil.copy2(seed/f,p/f)
s=(D/'19-arrays-ordinary-range'/B).read_text();u=(D/'20-uniform-endpoint-prefilter'/B).read_text();a=u.index('// Constant blocks');b=u.index('// Deinterleave',a);gate=u[a:b];s=s.replace('// Deinterleave the four input columns across eight rows (two blocks).',gate+'// Deinterleave the four input columns across eight rows (two blocks).')
for o in [0,8,16,24]:s=s.replace('.Store(out'+('' if o==0 else f'[{o}:]')+')',f'.StoreArray((*[8]int16)(unsafe.Add(unsafe.Pointer(op), (i*16+{o})*2)))')
(p/B).write_text(s)
s=(D/'08-split-dct-walsh'/S).read_text();s=s.replace('if true && ','if ')
def closing(s,start):
 depth=1;i=start+1
 while depth:
  if s[i]=='{':depth+=1
  if s[i]=='}':depth-=1
  i+=1
 return i
while 'if false && ' in s:
 a=s.index('if false && ');b=s.index('{',a);z=closing(s,b);s=s[:a]+s[z:]
for token in ('if false {','if true {'):
 while token in s:
  a=s.index(token);b=a+len(token)-1;z=closing(s,b);j=z
  while j<len(s) and s[j].isspace():j+=1
  end=z;other=''
  if s.startswith('else {',j):
   k=j+len('else ');end=closing(s,k);other=s[k+1:end-1]
  chosen=s[b+1:z-1] if token=='if true {' else other;s=s[:a]+"{"+chosen+"}"+s[end:]
s=s.replace('\tone := archsimd.BroadcastInt32x4(1)\n','').replace('x.Add(y).Add(x.NotEqual(zero).ToInt32x4().And(one))','x.Add(y).Sub(x.NotEqual(zero).ToInt32x4())').replace('.Add(w.NotEqual(zero).ToInt32x4().And(one))','.Sub(w.NotEqual(zero).ToInt32x4())')
needle='a, b, c, d := pixel.Transpose4(pixel.Load4(input), pixel.Load4(input[stride:]), pixel.Load4(input[2*stride:]), pixel.Load4(input[3*stride:]))'
for literal in ('[16]int16{1:1}','[16]int16{}'):
 s=s.replace(needle,'''a,b,c,d := pixel.Load4(input),pixel.Load4(input[stride:]),pixel.Load4(input[2*stride:]),pixel.Load4(input[3*stride:])
 if a.Or(b).Or(c).Or(d).ToBits().ReduceMax()==0 { *output = '''+literal+''';return true }
 a,b,c,d = pixel.Transpose4(a,b,c,d)''',1)
(p/S).write_text(s)
f=E+'residual_gather.go';s=(D/'15-pred-buffer-gather'/f).read_text().replace('"unsafe"','"unsafe"\n "github.com/thesyncim/govpx/internal/pixel"');v=(D/'16-predicted-four-simd'/f).read_text();a=s.index('func FillPredictedResidual4x4(');b=s.index('// Fast SIMD gathers',a);c=v.index('func FillPredictedResidual4x4(');d=v.index('// Fast SIMD gathers',c);s=s[:a]+v[c:d]+s[b:];(p/f).write_text(s)
f=E+'bpred_block.go';s=(D/'18-bpred-residual-bridge'/f).read_text();s=s[:s.index('// Fast SIMD gathers')];s=s.replace('"unsafe";','"github.com/thesyncim/govpx/internal/vp8/dsp";');v=(D/'17-bpred-sse-bridge'/f).read_text();a=s.index('func BPredBlockSSE');b=s.index('// FillBPredResidual4x4',a);c=v.index('func BPredBlockSSE');d=v.index('// FillBPredResidual4x4',c);s=s[:a]+v[c:d]+s[b:];(p/f).write_text(s)
f=E+'quant_batch_other.go';shutil.copy2(D/'23-shared-quant-two'/f,p/f)
f=p/E/'iteration_fdct_test.go';s=f.read_text().replace('"fmt";','"fmt";"bytes";"unsafe";')+(D/'alias_fixture.txt').read_text();f.write_text(s)
print('Prepared25 and combined1–24+seed')

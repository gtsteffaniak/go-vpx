# Archive layout

Anchor: c4a8bd9f66805fc9b7b4f99e26752cc68505e572. Apply `baseline/aggregate-score-seed.patch` for the scoring cohort; this seed predates the numbered50 experiments. Every numbered `variants/ID.patch` is cumulative against that anchor plus seed, not against the immediately preceding ID. Intra source is unchanged by the seed.

Raw bindings, commands, source/binary hashes and output were copied unchanged from the original proof folders. Absolute local paths inside those records intentionally remain unchanged. The corresponding archive folders are:

- `/private/tmp/govpx-astra-intra-edges56/proof` → `raw/edges26-28`.
- `/private/tmp/govpx-astra-intra-simd57/proof` → `raw/predictors29-36`.
- `/private/tmp/govpx-astra-score58/proof` → `raw/scoring37-50`.

`raw/scoring37-50/screen` is the original noisy37–40 window; decision claims use `confirm37`. Both windows and every slower control are preserved. Predictors33–36 compare with the retained29/30/32 baseline reconstructed by `variants/baseline33.patch`. Scoring41–48 compare with37;49–50 use modelbase, equivalent to37 in production source. Read each original configuration/binding for exact comparison order.

`fixtures/` and `keepers/` include the exact shared numeric/backing/panic oracles and benchmark fixtures. Drivers retain existing commands and source preparation. No executables or full checkout trees are included. This folder was assembled from existing evidence without rerunning tests, timing, audits or hashes. The final combined correctness log is copied once; combined codec measurements belong to the root integration evidence.

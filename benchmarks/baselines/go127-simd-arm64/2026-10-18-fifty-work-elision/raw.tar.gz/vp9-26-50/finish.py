from pathlib import Path
import csv, difflib, hashlib, json

P=Path('/private/tmp/govpx-astra-iterations26-50')
B=Path('/private/tmp/govpx-astra-score58/base')
C=P/'keepers'
E=Path('/private/tmp/govpx-astra-intra-edges56/proof/screen')
D=Path('/private/tmp/govpx-astra-intra-simd57/proof')
S=Path('/private/tmp/govpx-astra-score58/proof')
entries=[
 (26,'Gather only mode-required edges and copy contiguous above rows','KEEP','all modes; missing-edge controls lose up to 6.4%',E,'26'),
 (27,'Dispatch directly from valid prepared interior edges','KEEP','DC/V/H/TM; D45 and missing-edge controls mixed',E,'27'),
 (28,'Skip unused DC missing-edge sentinel fills','KEEP','six missing-edge cases; common-path controls lose up to 8.8%; final common path ordered first',E,'28'),
 (29,'Connect VP9 true-motion wrappers to existing pixel SIMD','KEEP','all TM widths; TM32 further improved by 33',D/'screen','v29'),
 (30,'Connect horizontal predictors to existing pixel SIMD','SUPERSEDED','H16 kept then improved by 35; H4/H8 bridge rejected',D/'screen','v30'),
 (31,'Use existing row-repeat SIMD for vertical prediction','REJECT','all affected V entries slower',D/'screen','v31'),
 (32,'Use existing fused SIMD edge sum and DC fill','KEEP SCOPED','DC4 both edges and DC8/16 families; unsupported-width guards excluded',D/'screen','v32'),
 (33,'Saturating-byte TM32 computes complete rows directly','KEEP SCOPED','TM32; generic dispatch guard removed from smaller wrappers',D/'screen33','v33'),
 (34,'Use direct fixed-width vertical row stores','KEEP SCOPED','V16 only (1.052x, both pairs faster); V4/V8 lose; V32 mixed',D/'screen33','v34'),
 (35,'Use fixed horizontal word/vector broadcasts','KEEP SCOPED','H8/H16/H32; H4 rejected',D/'screen33','v35'),
 (36,'Vectorize uncovered DC4 and DC32 sums/fills','KEEP SCOPED','partial-DC4 and all DC32; existing DC4 both-edge and DC8/16 paths retained',D/'screen33','v36'),
 (37,'Eliminate reciprocal-quantizer threshold mask that cannot affect output','KEEP','bounded private scorer; stable 80ms confirmation replaces noisy first screen',S/'confirm37','v37'),
 (38,'Peel first DC packet to avoid AC parameter moves','REJECT','incremental vs37 approximately -0.8% to +1.6%; stronger 39 retained',S/'confirm37','v38'),
 (39,'Accumulate bounded rates in uint16 before final widening','KEEP','d>=16 proves 32*2047<=65535; uniform and fused8 paths specialize further',S/'confirm37','v39'),
 (40,'Skip arithmetic for all-zero transform coefficient packets','SUPERSEDED','DC case >=1.5x retained by stronger pre-transform uniform43; dense64 control0.932x',S/'confirm37','v40'),
 (41,'Consume Hadamard8 registers directly in aggregate quantizer','KEEP','nonuniform Tx8; 7-12% gains vs37, unchanged zero control mixed',S/'screen41','v41'),
 (42,'Fuse Hadamard16 combine and aggregate quantizer','REJECT','intended Tx16 cases 0.981-0.997x',S/'screen41','v42'),
 (43,'Compute uniform-residual transform and quantizer as one DC coefficient','KEEP','DC cases1.79-2.43x; dense controls0.959-1.003x vs37',S/'screen41','v43'),
 (44,'Use two independent wide accumulation chains','REJECT','0-4% mixed; stronger narrow39 retained',S/'screen41','v44'),
 (45,'Use four independent wide accumulators and 32-coefficient tiles','REJECT','nonzero cases0.993-1.020x mixed',S/'screen45','v45'),
 (46,'Use byte-offset loop induction instead of scaled indices','REJECT','nonzero cases0.985-1.014x mixed',S/'screen45','v46'),
 (47,'Move zero-residual return ahead of quantizer setup','REJECT','three zero cases1.016-1.036x; fourth mixed loss and nonzero losses',S/'screen45','v47'),
 (48,'Reuse broadcast quantizer tables across transform units','REJECT','Tx8 gains1-3%; Tx16 mixed/loss; stronger41/39 retained',S/'screen45','v48'),
 (49,'Use exact qstep-zero Laplace-model closed form','KEEP','qstep0 <=12 shift; q0 cases1.78-1.81x, nonzero controls0.981-1.010x',S/'screen49','v49'),
 (50,'Use exact saturated-endpoint Laplace-model closed form','KEEP','saturated cases1.74-1.80x; all measured controls faster',S/'screen49','v50'),
]
with (P/'final.tsv').open('w') as f:
 w=csv.writer(f, delimiter='\t',lineterminator='\n')
 w.writerow(['id','hypothesis','decision','scope_and_losses','all_case_median_range','slower_pairs','raw_path'])
 for i,h,d,scope,path,key in entries:
  vals=json.loads((path/'summary.json').read_text())[key]
  lo=min(x['median'] for x in vals.values());hi=max(x['median'] for x in vals.values())
  losses=sum(x['slower_pairs'] for x in vals.values());pairs=sum(len(x['paired_speedup']) for x in vals.values())
  w.writerow([i,h,d,scope,f'{lo:.6f}-{hi:.6f}x',f'{losses}/{pairs}',str(path)])

files=(P/'keeper-files.txt').read_text().splitlines()
patch=[];binding={}
for file in files:
 before=(B/file).read_text() if (B/file).exists() else ''
 # This oracle was installed into the private baseline for identical
 # benchmark execution; it is absent from the c4+seed production parent.
 if file == 'internal/vp9/dsp/intra_bridge57_test.go':
  before=''
 after=(C/file).read_text()
 if before!=after:
  patch.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='a/'+file if before else '/dev/null', tofile='b/'+file))
 binding[file]={'changed':before!=after,'parent_sha256':hashlib.sha256(before.encode()).hexdigest() if before else None,'candidate_sha256':hashlib.sha256(after.encode()).hexdigest()}
(P/'keepers.patch').write_text(''.join(patch))
(P/'binding.json').write_text(json.dumps({'anchor':'c4a8bd9f66805fc9b7b4f99e26752cc68505e572','parent':'anchor plus frozen aggregate scorer seed','host':'Apple M4 Max/Darwin arm64','Go':'1.27.2','timing':'CGO1/PGOoff/GOMAXPROCS1; two balanced 40ms pairs; scorer37-40 confirmation two80ms pairs','scope':'component measurements, not codec or libvpx speed claims','files':binding},indent=2)+'\n')
report='''# VP9 iterations 26–50

All 25 distinct hypotheses were implemented and checked against independent or frozen numeric/state oracles, then screened on native Apple M4 Max with Go 1.27.2, SIMD, CGO1, PGOoff and GOMAXPROCS1. Each screen uses two balanced 40 ms pairs; the initially noisy scorer37–40 screen is retained and replaced for decisions by a fresh two-pair80ms confirmation. These are short component screens, not precise whole-codec or C throughput claims.

`final.tsv` contains exactly25 final decision rows, the complete measured-case speedup range and every slower-pair count. It links each immutable source/binary binding, command log and raw output folder. The original append-only experiment history remains in `experiments.tsv`.

The patch is incremental to c4 plus the frozen scorer seed already handed off in PR55. It includes scoped intra gathering/dispatch, SIMD predictors, aggregate scoring and exact model shortcuts. The combined assembly moves checks into only winning fixed-size wrappers, so rejected small-width controls retain their original scalar bodies. The zero-coefficient-packet DC win in40 is superseded by the faster uniform-input43 path before the transform. Other rejected accumulation/table variants are not included.

Main causal wins: existing VP9 TM wrappers used scalar per-pixel loops despite available SIMD; required edge flags were ignored and above-right rows gathered unnecessarily; prepared interior edges were copied onto themselves; DC predictors repeated scalar summation/fill despite existing kernels. Scoring still computed a redundant reciprocal threshold and widened every packet; Hadamard8 stored and reloaded coefficients consumed only as aggregates. Uniform residuals unnecessarily transformed and visited all coefficients. The model evaluated division/interpolation even at two exact endpoints.

Correctness scope retained: 1440 live-intra backing comparisons,2240 fixed-predictor backing/alias/panic comparisons, existing signed-domain quantizer and full BlockYrd consumers, boundary SSE cases, and73728 frozen-model state comparisons including unusual shifts and wrapping uint64 arithmetic. All screens reported zero allocation. Final integration uses only targeted selectors, without a new broad suite/race/C/profile run.

Control losses remain material in some individual variants: missing-edge/common intra branches, unsupported predictor widths, DC generic wrapper inlining, the40 dense64 case0.932x, uniform43 dense controls down to0.959x, and qstep-zero49 nonzero controls down to0.981x. The final scoped assembly is a new composition; original variant numbers are not represented as measurements of that composition. Root owns one combined codec A/B against c4 after integrating both agents'25 iterations.
'''
(P/'REPORT.md').write_text(report)
print(f'{len(entries)} final rows; {sum(x["changed"] for x in binding.values())} changed files plus unchanged fixtures; patch {len("".join(patch))} bytes')

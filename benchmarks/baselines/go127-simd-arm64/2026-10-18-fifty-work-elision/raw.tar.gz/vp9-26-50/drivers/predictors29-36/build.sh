#!/bin/sh
set -eu
export CODEX_AGENT_ID=astra-intra57 CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go GOEXPERIMENT=simd GOMAXPROCS=2 GOFLAGS=-p=2 CGO_ENABLED=1
r=/Users/thesyncim/GolandProjects/govpx
p=/private/tmp/govpx-astra-intra-simd57
cd "$r"
for v in base v29 v30 v31 v32; do
 if "$r/scripts/go.sh" -C "$p/$v" test -pgo=off -run 'TestIntraBridge57|TestVP9Intra|TestVP9Tm' ./internal/vp9/dsp > "$p/proof/$v-tests.log" 2>&1; then
  "$r/scripts/go.sh" -C "$p/$v" test -pgo=off -c -o "$p/$v.test" ./internal/vp9/dsp > "$p/proof/$v-build.log" 2>&1
  echo "$v built"
 else
  echo "$v FAILED"
 fi
done

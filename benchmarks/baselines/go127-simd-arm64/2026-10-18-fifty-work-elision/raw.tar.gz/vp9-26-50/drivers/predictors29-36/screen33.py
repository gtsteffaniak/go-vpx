from pathlib import Path
import os,subprocess,json,hashlib,re,statistics
p=Path('/private/tmp/govpx-astra-intra-simd57');o=p/'proof/screen33';o.mkdir(exist_ok=False)
vs=['base33','v33','v35','v34','v36'];sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();filters={'base33':'.','v33':'^tm','v35':'^h','v34':'^v','v36':'^dc'};counts={'base33':32,'v33':8,'v35':4,'v34':4,'v36':16}
bind={'base33':'c4a8bd9f66805fc9b7b4f99e26752cc68505e572','host':'Apple M4 Max/Darwin arm64','go':'1.27.2','PGO':'off','CGO_ENABLED':1,'GOEXPERIMENT':'simd','GOMAXPROCS':1,'preliminary':True,'variants':{v:{'production':{f.name:sha(f)for f in (p/v/'internal/vp9/dsp').glob('intra*.go')if not f.name.endswith('_test.go')},'fixture':sha(p/v/'internal/vp9/dsp/intra_bridge57_test.go'),'binary':sha(p/(v+'.test'))}for v in vs}}
(o/'binding.json').write_text(json.dumps(bind,indent=2)+'\n');env=os.environ.copy();env['GOMAXPROCS']='1';rows={};commands=[];pat=re.compile(r'^(BenchmarkIntraBridge57\S+)\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op$',re.M)
for rnd,order in enumerate([vs,vs[::-1]],1):
 for v in order:
  cmd=[str(p/(v+'.test')),'-test.run=^$','-test.bench=^BenchmarkIntraBridge57$/'+filters[v],'-test.benchtime=40ms','-test.count=1','-test.cpu=1','-test.benchmem'];r=subprocess.run(cmd,capture_output=True,text=True,env=env);f=o/f'r{rnd}-{v}.txt';f.write_text(r.stdout);f.with_suffix('.stderr').write_text(r.stderr);commands.append({'cmd':cmd,'rc':r.returncode});assert r.returncode==0
  matches=pat.findall(r.stdout);assert len(matches)==counts[v],(v,len(matches))
  for name,ns,b,a in matches:rows.setdefault(name,{}).setdefault(v,[]).append(float(ns));assert b=='0'and a=='0'
 print('round',rnd,'done',flush=True)
s={}
for v in vs[1:]:
 s[v]={}
 for name,vals in rows.items():
  if v not in vals:continue
  speed=[a/b for a,b in zip(vals['base33'],vals[v])];s[v][name]={'baseline_ns':vals['base33'],'candidate_ns':vals[v],'paired_speedup':speed,'median':statistics.median(speed),'slower_pairs':sum(x<1 for x in speed)}
(o/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');(o/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
for eid,z in s.items():print(eid,[(k.split('/')[1],round(x['median'],3),x['slower_pairs'])for k,x in z.items()],flush=True)
print('END all timing processes stopped',flush=True)

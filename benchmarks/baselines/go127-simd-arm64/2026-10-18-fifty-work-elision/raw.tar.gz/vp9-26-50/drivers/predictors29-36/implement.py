from pathlib import Path
import re
p=Path('/private/tmp/govpx-astra-intra-simd57'); f='internal/vp9/dsp/intrapred.go';base=(p/'base'/f).read_text()
helpers='''package dsp

import (
 "unsafe"
 "github.com/thesyncim/govpx/internal/pixel"
)

// The SIMD bridge only accepts complete rows. Invalid windows retain the
// original predictor's partial-write/panic behavior.
func intraBridgeWindow(dst []byte, stride, bs int) bool {
 return pixel.Enabled && stride >= bs && len(dst) >= bs && stride <= (len(dst)-bs)/(bs-1)
}
func intraBridgeDisjoint(dst []byte, stride, bs int, edge []byte, count int) bool {
 if !intraBridgeWindow(dst,stride,bs) || len(edge)<count { return false }
 d,e:=uintptr(unsafe.Pointer(unsafe.SliceData(dst))),uintptr(unsafe.Pointer(unsafe.SliceData(edge)))
 span:=uintptr((bs-1)*stride+bs)
 return !((d<=e && e-d<span)||(e<d && d-e<uintptr(count)))
}
'''
for v in ['v29','v30','v31','v32']:
 s=base.replace('package dsp\n','package dsp\n\nimport "github.com/thesyncim/govpx/internal/pixel"\n',1)
 if v=='v29':
  needle='func tmPredictor(dst []uint8, stride, bs int, above, left []uint8) {\n'
  s=s.replace(needle,needle+''' // Both implementations follow libvpx v1.16.0 vpx_dsp/intrapred.c.
 // The pixel package already owns SIMD kernels for this exact arithmetic.
 if intraBridgeDisjoint(dst,stride,bs,above,bs+1) && intraBridgeDisjoint(dst,stride,bs,left,bs) {
  pixel.TMPredict(dst,stride,above[1:],left,above[0],bs)
  return
 }
''')
 elif v=='v30':
  for n in [4,8,16]:
   needle=f'func hPredictor{n}(dst []uint8, stride int, left []uint8) {{\n'
   s=s.replace(needle,needle+f' if intraBridgeWindow(dst,stride,{n}) && len(left)>={n} {{ pixel.Horizontal(dst,stride,left,{n}); return }}\n')
 elif v=='v31':
  needle='func vPredictor(dst []uint8, stride, bs int, above, left []uint8) {\n'
  s=s.replace(needle,needle+' if bs<=16 && intraBridgeDisjoint(dst,stride,bs,above,bs) { pixel.RepeatRow(dst,stride,above,bs); return }\n')
 else:
  for name,up,lf in [('dcPredictor','true','true'),('dcLeftPredictor','false','true'),('dcTopPredictor','true','false'),('dc128Predictor','false','false')]:
   needle=f'func {name}(dst []uint8, stride, bs int, above, left []uint8) {{\n'
   extra=f' if pixel.IntraDCFill(dst,stride,above,left,bs,{up},{lf}) {{ return }}\n'
   if name=='dcPredictor':extra+=' if bs==4 && pixel.Intra4x4DCFill(dst,stride,above,left) { return }\n'
   s=s.replace(needle,needle+extra)
 (p/v/f).write_text(s)
 if v!='v32':(p/v/'internal/vp9/dsp/intra_bridge.go').write_text(helpers)
# Frozen independent pre-change scalar implementation for full backing + panic comparisons.
names=re.findall(r'^func (\w+)\(',base,re.M)
frozen=base[base.index('func dcPredictor'):]
for name in sorted(names,key=len,reverse=True):frozen=re.sub(r'\b'+name+r'\b',name+'Frozen57',frozen)
fixture='''package dsp
import("testing";"fmt";"bytes")
'''+frozen+'''
type intra57case struct { name string; n int; fn,ref func([]byte,int,[]byte,[]byte) }
func intra57cases()[]intra57case { return []intra57case{
'''
for prefix,label in [('VpxTmPredictor','tm'),('VpxHPredictor','h'),('VpxVPredictor','v'),('VpxDcPredictor','dc'),('VpxDcLeftPredictor','dcl'),('VpxDcTopPredictor','dct'),('VpxDc128Predictor','dc0')]:
 for n in [4,8,16,32]:
  name=f'{prefix}{n}x{n}';fixture+=f'{{"{label}{n}",{n},{name},{name}Frozen57}},\n'
fixture+='''} }
func intra57panic(fn func())(pan bool) { defer func(){pan=recover()!=nil}();fn();return }
func TestIntraBridge57(t *testing.T) {
 for _,tc:=range intra57cases(){
  for _,stride:=range []int{tc.n,tc.n+7}{
   for pattern:=0;pattern<5;pattern++ {
    for alias:=0;alias<4;alias++ {
     got:=make([]byte,4096);want:=make([]byte,4096)
     for i:=range got{ got[i]=byte(i*17+i/11+pattern*43);want[i]=got[i] }
     off,ao,lo:=99,3000,3200
     if alias==1{ao=off+1};if alias==2{lo=off+stride};if alias==3{ao=off-1;lo=off+2*stride}
     if pattern==1 {got[ao]=255;want[ao]=255};if pattern==2{got[ao]=0;want[ao]=0}
     for _,short:=range []bool{false,true}{
      g:=append([]byte(nil),got...);w:=append([]byte(nil),want...)
      size:=(tc.n-1)*stride+tc.n;if short{size--}
      gp:=intra57panic(func(){tc.fn(g[off:off+size:off+size],stride,g[ao:ao+tc.n+1:ao+tc.n+1],g[lo:lo+tc.n:lo+tc.n])})
      wp:=intra57panic(func(){tc.ref(w[off:off+size:off+size],stride,w[ao:ao+tc.n+1:ao+tc.n+1],w[lo:lo+tc.n:lo+tc.n])})
      if gp!=wp||!bytes.Equal(g,w){t.Fatalf("%s stride%d pattern%d alias%d short%t panic%t/%t backing differs",tc.name,stride,pattern,alias,short,gp,wp)}
     }
    }
   }
  }
 }
}
func BenchmarkIntraBridge57(b *testing.B){
 for _,tc:=range intra57cases(){
  patterns:=1;if tc.name[:2]=="tm"{patterns=2}
  for pattern:=0;pattern<patterns;pattern++{ b.Run(fmt.Sprintf("%s-p%d",tc.name,pattern),func(b *testing.B){
   above,left:=intraBenchEdges();if pattern==1{above,left=intraClipEdges()}
   dst:=make([]byte,(tc.n+7)*tc.n);b.ReportAllocs()
   for b.Loop(){tc.fn(dst,tc.n+7,above,left)}
  })}
 }
}
'''
for v in ['base','v29','v30','v31','v32']:(p/v/'internal/vp9/dsp/intra_bridge57_test.go').write_text(fixture)
log=Path('/private/tmp/govpx-astra-iterations26-50/experiments.tsv')
with log.open('a')as f:
 for i,h in [(29,'Wire scalar VP9 TM to existing exact pixel SIMD'),(30,'Wire H predictors to per-row SIMD broadcasts'),(31,'Cache V predictor row with SIMD repeat'),(32,'Wire DC sum and fill to existing fused SIMD')]:f.write(f'{i}\t{h}\timplemented\tVP9 intra DSP\t{p}/v{i}\n')

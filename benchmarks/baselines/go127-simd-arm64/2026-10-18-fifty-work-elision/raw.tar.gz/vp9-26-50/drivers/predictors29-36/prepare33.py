from pathlib import Path
import shutil,re
p=Path('/private/tmp/govpx-astra-intra-simd57');b=p/'base33';shutil.copytree(p/'v29',b)
f='internal/vp9/dsp/intrapred.go';s=(b/f).read_text()
needle='func hPredictor16(dst []uint8, stride int, left []uint8) {\n'
s=s.replace(needle,needle+' if intraBridgeWindow(dst,stride,16) && len(left)>=16 { pixel.Horizontal(dst,stride,left,16); return }\n')
for name,up,lf in [('dcPredictor','true','true'),('dcLeftPredictor','false','true'),('dcTopPredictor','true','false'),('dc128Predictor','false','false')]:
 needle=f'func {name}(dst []uint8, stride, bs int, above, left []uint8) {{\n'
 extra=f' if (bs==8 || bs==16) && pixel.IntraDCFill(dst,stride,above,left,bs,{up},{lf}) {{ return }}\n'
 if name=='dcPredictor':extra+=' if bs==4 && pixel.Intra4x4DCFill(dst,stride,above,left) { return }\n'
 s=s.replace(needle,needle+extra)
(b/f).write_text(s)
for v in ['v33','v34','v35','v36']:shutil.copytree(b,p/v)
shared='''//go:build goexperiment.simd && (arm64 || amd64) && !purego

package dsp
import("unsafe";"simd/archsimd";"github.com/thesyncim/govpx/internal/pixel")

// Fixed-row kernels implement libvpx v1.16.0 vpx_dsp/intrapred.c arithmetic.
// Entry guards prove every complete row and preserve the scalar alias/panic path.
func intraTM32Fixed(dst []byte,stride int,above,left []byte,top byte) bool {
 if !pixel.Enabled {return false}
 dp,ap,lp:=unsafe.Pointer(unsafe.SliceData(dst)),unsafe.Pointer(unsafe.SliceData(above)),unsafe.Pointer(unsafe.SliceData(left))
 a:=archsimd.LoadUint8x16Array((*[16]byte)(ap));b:=archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(ap,16)))
 for y:=0;y<32;y++{
  delta:=int(*(*byte)(unsafe.Add(lp,y)))-int(top)
  pos,neg:=archsimd.BroadcastUint8x16(byte(max(delta,0))),archsimd.BroadcastUint8x16(byte(max(-delta,0)))
  row:=unsafe.Add(dp,y*stride)
  a.AddSaturated(pos).SubSaturated(neg).StoreArray((*[16]byte)(row))
  b.AddSaturated(pos).SubSaturated(neg).StoreArray((*[16]byte)(unsafe.Add(row,16)))
 }
 return true
}
func intraVFixed(dst []byte,stride,n int,above []byte) bool {
 if !intraBridgeDisjoint(dst,stride,n,above,n){return false}
 dp,ap:=unsafe.Pointer(unsafe.SliceData(dst)),unsafe.Pointer(unsafe.SliceData(above))
 switch n {
 case 4:
  v:=*(*uint32)(ap);for y:=0;y<4;y++{*(*uint32)(unsafe.Add(dp,y*stride))=v}
 case 8:
  v:=*(*uint64)(ap);for y:=0;y<8;y++{*(*uint64)(unsafe.Add(dp,y*stride))=v}
 case 16:
  v:=archsimd.LoadUint8x16Array((*[16]byte)(ap));for y:=0;y<16;y++{v.StoreArray((*[16]byte)(unsafe.Add(dp,y*stride)))}
 case 32:
  a:=archsimd.LoadUint8x16Array((*[16]byte)(ap));b:=archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(ap,16)))
  for y:=0;y<32;y++{row:=unsafe.Add(dp,y*stride);a.StoreArray((*[16]byte)(row));b.StoreArray((*[16]byte)(unsafe.Add(row,16)))}
 default:return false
 }
 return true
}
func intraHFixed(dst []byte,stride,n int,left []byte)bool{
 if !intraBridgeWindow(dst,stride,n)||len(left)<n{return false}
 dp,lp:=unsafe.Pointer(unsafe.SliceData(dst)),unsafe.Pointer(unsafe.SliceData(left))
 switch n{
 case 4:
  for y:=0;y<4;y++{v:=uint32(*(*byte)(unsafe.Add(lp,y)))*0x01010101;*(*uint32)(unsafe.Add(dp,y*stride))=v}
 case 8:
  for y:=0;y<8;y++{v:=uint64(*(*byte)(unsafe.Add(lp,y)))*0x0101010101010101;*(*uint64)(unsafe.Add(dp,y*stride))=v}
 case 16:
  for y:=0;y<16;y++{v:=archsimd.BroadcastUint8x16(*(*byte)(unsafe.Add(lp,y)));v.StoreArray((*[16]byte)(unsafe.Add(dp,y*stride)))}
 case 32:
  for y:=0;y<32;y++{v:=archsimd.BroadcastUint8x16(*(*byte)(unsafe.Add(lp,y)));row:=unsafe.Add(dp,y*stride);v.StoreArray((*[16]byte)(row));v.StoreArray((*[16]byte)(unsafe.Add(row,16)))}
 default:return false
 }
 return true
}
func intraEdgeSum(p unsafe.Pointer,n int)int{
 switch n{
 case 4:return intraSumBytes(archsimd.Uint32x4{}.SetElem(0,*(*uint32)(p)).ReshapeToUint8s())
 case 8:return intraSumBytes(archsimd.Uint64x2{}.SetElem(0,*(*uint64)(p)).ReshapeToUint8s())
 case 16:return intraSumBytes(archsimd.LoadUint8x16Array((*[16]byte)(p)))
 default:return intraSumBytes(archsimd.LoadUint8x16Array((*[16]byte)(p)))+intraSumBytes(archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(p,16))))
 }
}
func intraDCFixed(dst []byte,stride,n int,above,left []byte,up,lf bool)bool{
 if !intraBridgeWindow(dst,stride,n)||(up&&len(above)<n)||(lf&&len(left)<n){return false}
 sum,count:=0,0
 if up{sum+=intraEdgeSum(unsafe.Pointer(unsafe.SliceData(above)),n);count+=n}
 if lf{sum+=intraEdgeSum(unsafe.Pointer(unsafe.SliceData(left)),n);count+=n}
 value:=byte(128);if count>0{value=byte((sum+count/2)/count)}
 dp:=unsafe.Pointer(unsafe.SliceData(dst));v:=archsimd.BroadcastUint8x16(value)
 switch n{
 case 4:
  word:=v.ReshapeToUint32s().GetElem(0);for y:=0;y<4;y++{*(*uint32)(unsafe.Add(dp,y*stride))=word}
 case 8:
  word:=v.ReshapeToUint64s().GetElem(0);for y:=0;y<8;y++{*(*uint64)(unsafe.Add(dp,y*stride))=word}
 case 16:
  for y:=0;y<16;y++{v.StoreArray((*[16]byte)(unsafe.Add(dp,y*stride)))}
 case 32:
  for y:=0;y<32;y++{row:=unsafe.Add(dp,y*stride);v.StoreArray((*[16]byte)(row));v.StoreArray((*[16]byte)(unsafe.Add(row,16)))}
 default:return false
 }
 return true
}
'''
arm='''//go:build goexperiment.simd && arm64 && !purego
package dsp
import "simd/archsimd"
func intraSumBytes(v archsimd.Uint8x16)int{return int(v.ExtendLo8ToUint16().Add(v.HiToLo().ExtendLo8ToUint16()).ReduceSum())}
'''
amd='''//go:build goexperiment.simd && amd64 && !purego
package dsp
import "simd/archsimd"
func intraSumBytes(v archsimd.Uint8x16)int{s:=v.SumOf8AbsDiff(archsimd.Uint8x16{});return int(s.GetElem(0)+s.GetElem(1))}
'''
no='''//go:build !goexperiment.simd || (!arm64 && !amd64) || purego
package dsp
func intraTM32Fixed(_ []byte,_ int,_,_ []byte,_ byte)bool{return false}
func intraVFixed(_ []byte,_,_ int,_ []byte)bool{return false}
func intraHFixed(_ []byte,_,_ int,_ []byte)bool{return false}
func intraDCFixed(_ []byte,_,_ int,_,_ []byte,_,_ bool)bool{return false}
'''
for v in ['v33','v34','v35','v36']:
 s=(b/f).read_text()
 if v=='v33':s=s.replace('pixel.TMPredict(dst, stride, above[1:], left, above[0], bs)','if bs==32 && intraTM32Fixed(dst,stride,above[1:],left,above[0]){return}\n\t\tpixel.TMPredict(dst, stride, above[1:], left, above[0], bs)')
 if v=='v34':s=s.replace('func vPredictor(dst []uint8, stride, bs int, above, left []uint8) {','func vPredictor(dst []uint8, stride, bs int, above, left []uint8) {\n if intraVFixed(dst,stride,bs,above){return}')
 if v=='v35':
  s=s.replace(' if intraBridgeWindow(dst,stride,16) && len(left)>=16 { pixel.Horizontal(dst,stride,left,16); return }\n','')
  for n in [4,8,16,32]:s=s.replace(f'func hPredictor{n}(dst []uint8, stride int, left []uint8) {{',f'func hPredictor{n}(dst []uint8, stride int, left []uint8) {{\n if intraHFixed(dst,stride,{n},left){{return}}')
 if v=='v36':
  for name,up,lf in [('dcPredictor','true','true'),('dcLeftPredictor','false','true'),('dcTopPredictor','true','false'),('dc128Predictor','false','false')]:
   needle=f'func {name}(dst []uint8, stride, bs int, above, left []uint8) {{\n'
   # Restrict this experiment to widths not covered by the retained native bridge.
   s=s.replace(needle,needle+f' if (bs==4 || bs==32 || !pixel.IntraDCFillNative) && intraDCFixed(dst,stride,bs,above,left,{up},{lf}){{return}}\n')
 (p/v/f).write_text(s)
 for name,txt in [('intrapred_fixed_simd.go',shared),('intrapred_fixed_arm64.go',arm),('intrapred_fixed_amd64.go',amd),('intrapred_fixed_nosimd.go',no)]: (p/v/'internal/vp9/dsp'/name).write_text(txt)
with Path('/private/tmp/govpx-astra-iterations26-50/experiments.tsv').open('a')as z:
 for i,h in [(33,'Byte-saturating 32x32 TM replaces generic four-pixel operations'),(34,'Direct fixed V rows remove per-row StorePart and copy calls'),(35,'Direct fixed H broadcasts remove per-byte stores and StorePart'),(36,'Vector DC sum/fill for uncovered 4 and32 sizes')]:z.write(f'{i}\t{h}\timplemented\tVP9 intra DSP versus retained bridge baseline\t{p}/v{i}\n')

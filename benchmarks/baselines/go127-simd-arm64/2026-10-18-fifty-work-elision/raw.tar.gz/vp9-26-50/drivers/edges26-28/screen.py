from pathlib import Path
import os,subprocess,json,hashlib,re,statistics
p=Path('/private/tmp/govpx-astra-intra-edges56');o=p/'proof/screen';o.mkdir(exist_ok=False)
vs=['parent','candidate','v27','v28'];sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
bind={'base':'c4a8bd9f66805fc9b7b4f99e26752cc68505e572','host':'Apple M4 Max/Darwin arm64','go':'1.27.2','PGO':'off','CGO_ENABLED':1,'GOEXPERIMENT':'simd','GOMAXPROCS':1,'preliminary':True,'variants':{v:{'production':sha(p/v/'vp9_encoder_prediction.go'),'fixture':sha(p/v/'vp9_intra_edges56_test.go'),'binary':sha(p/(v+'.test'))}for v in vs}}
(o/'binding.json').write_text(json.dumps(bind,indent=2)+'\n'); env=os.environ.copy();env['GOMAXPROCS']='1';rows={};commands=[]
pat=re.compile(r'^(BenchmarkVP9Scratch\S+)\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op$',re.M)
for rnd,order in enumerate([vs,vs[::-1]],1):
 for v in order:
  cmd=[str(p/(v+'.test')),'-test.run=^$','-test.bench=^BenchmarkVP9Scratch(Live|Missing)Edges56$','-test.benchtime=40ms','-test.count=1','-test.cpu=1','-test.benchmem'];r=subprocess.run(cmd,capture_output=True,text=True,env=env);f=o/f'r{rnd}-{v}.txt';f.write_text(r.stdout);f.with_suffix('.stderr').write_text(r.stderr);commands.append({'cmd':cmd,'rc':r.returncode});assert r.returncode==0
  matches=pat.findall(r.stdout);assert len(matches)==26,(v,len(matches))
  for name,ns,b,a in matches:rows.setdefault(name,{}).setdefault(v,[]).append(float(ns));assert b=='0'and a=='0'
 print('round',rnd,'done',flush=True)
summary={}
for old,new,eid in [('parent','candidate',26),('candidate','v27',27),('v27','v28',28)]:
 ss={}
 for name,vals in rows.items():
  speed=[a/b for a,b in zip(vals[old],vals[new])];ss[name]={'baseline_ns':vals[old],'candidate_ns':vals[new],'paired_speedup':speed,'median':statistics.median(speed),'slower_pairs':sum(x<1 for x in speed)}
 summary[str(eid)]=ss
(o/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');(o/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for eid,s in summary.items(): print(eid,'median-range',min(x['median']for x in s.values()),max(x['median']for x in s.values()),'slower-pairs',sum(x['slower_pairs']for x in s.values()),flush=True)
print('END all timing processes stopped',flush=True)

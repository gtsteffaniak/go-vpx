#!/bin/sh
set -eu
export CODEX_AGENT_ID=astra-intra56 CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go GOEXPERIMENT=simd GOMAXPROCS=2 GOFLAGS=-p=2 CGO_ENABLED=1
r=/Users/thesyncim/GolandProjects/govpx
p=/private/tmp/govpx-astra-intra-edges56
cd "$r"
for v in parent candidate v27 v28; do
 "$r/scripts/go.sh" -C "$p/$v" test -pgo=off -run 'TestVP9ScratchLiveEdgeReads56|TestVP9NonrdIntraScratch' . > "$p/proof/$v-tests.log" 2>&1
 "$r/scripts/go.sh" -C "$p/$v" test -pgo=off -c -o "$p/$v.test" . > "$p/proof/$v-build.log" 2>&1
 echo "$v built"
done

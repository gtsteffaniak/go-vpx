from pathlib import Path
import shutil,json
p=Path('/private/tmp/govpx-astra-intra-edges56')
for v in ['v27','v28']:
 shutil.copytree(p/'candidate',p/v)
s=(p/'candidate/vp9_encoder_prediction.go').read_text()
needle='\tdst = dstData[localY*dstStride+localX:]\n\tvp9dec.BuildIntraPredictorsWithScratch('
pos=s.index(needle,s.index('func (e *VP9Encoder) predictVP9KeyframeTxScratchLive('))
fast='''\tdst = dstData[localY*dstStride+localX:]
	// These gathered edges already have libvpx's interior values. Avoid
	// copying them onto themselves through the general border builder.
	if upAvailable && leftAvailable && bounds.MbToRightEdge >= 0 &&
		bounds.MbToBottomEdge >= 0 && need&vp9dec.NeedAboveRight == 0 {
		e.intraScratch.Above[0] = aboveLeft
		if mode == common.DcPred {
			vp9dec.IntraDcPredTable[1][1][txSize](dst, dstStride, e.intraScratch.Above[:1+2*bs], left)
		} else {
			vp9dec.IntraPredTable[mode][txSize](dst, dstStride, e.intraScratch.Above[:1+2*bs], left)
		}
		return dst, dstStride, x0, y0, true
	}
	vp9dec.BuildIntraPredictorsWithScratch('''
s27=s[:pos]+s[pos:].replace(needle,fast,1)
(p/'v27/vp9_encoder_prediction.go').write_text(s27)
# Independent additional path on v27: missing-edge DC kernels never read the missing side.
fast2='''	// libvpx's four DC kernels only read available edges. Missing-edge
	// sentinel fills cannot affect DC output, so dispatch before those fills.
	if mode == common.DcPred && (!upAvailable || !leftAvailable) &&
		bounds.MbToRightEdge >= 0 && bounds.MbToBottomEdge >= 0 {
		li, ai := 0, 0
		if leftAvailable { li = 1 }
		if upAvailable { ai = 1 }
		vp9dec.IntraDcPredTable[li][ai][txSize](dst, dstStride, e.intraScratch.Above[:1+2*bs], left)
		return dst, dstStride, x0, y0, true
	}
'''
pos2=s27.index('\t// These gathered edges already have',s27.index('func (e *VP9Encoder) predictVP9KeyframeTxScratchLive('))
(p/'v28/vp9_encoder_prediction.go').write_text(s27[:pos2]+fast2+s27[pos2:])
fixture=(p/'candidate/vp9_intra_edges56_test.go').read_text()+'''
func BenchmarkVP9ScratchMissingEdges56(b *testing.B) {
 for _, tx := range []common.TxSize{common.Tx8x8, common.Tx16x16} {
  for _, origin := range [][2]int{{0,0},{0,8},{8,0}} {
   b.Run(fmt.Sprintf("tx%d/origin%d-%d",4<<uint(tx),origin[0],origin[1]),func(b *testing.B) {
    e:=new(VP9Encoder); hdr:=vp9dec.UncompressedHeader{Width:128,Height:128}; pd:=vp9dec.MacroblockdPlane{}
    ref:=make([]byte,160*160); var dst [4096]byte
    for i:=range ref { ref[i]=byte(i*23+i/17) }; for i:=range dst { dst[i]=byte(i*7+i/31) }
    tile:=vp9dec.TileBounds{MiRowEnd:16,MiColEnd:16}
    b.ReportAllocs()
    for b.Loop() { _,_,_,_,ok:=e.predictVP9KeyframeTxScratchLive(&hdr,&pd,common.DcPred,tx,tile,16,16,origin[0],origin[1],common.Block64x64,0,0,dst[:],64,origin[1]*8,origin[0]*8,ref,160); if !ok { b.Fatal("invalid") } }
   })
  }
 }
}
'''
for v in ['parent','candidate','v27','v28']:(p/v/'vp9_intra_edges56_test.go').write_text(fixture)
log=Path('/private/tmp/govpx-astra-iterations26-50');log.mkdir(exist_ok=True)
(log/'experiments.tsv').write_text('id\thypothesis\tdecision\tscope\traw_paths\n26\tMode-directed edge gathering and contiguous above-row copy\tcorrectness-pass;timing-pending\tVP9 scratch-live intra\t'+str(p)+'/proof/targeted.log\n27\tDirect dispatch from prepared interior edges\timplemented\tVP9 scratch-live intra\t'+str(p)+'/v27\n28\tSkip unused missing-edge DC fills\timplemented\tVP9 scratch-live intra\t'+str(p)+'/v28\n')

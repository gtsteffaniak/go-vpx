from pathlib import Path
import shutil,re
p=Path('/private/tmp/govpx-astra-score58');p.mkdir();(p/'proof').mkdir();b=p/'base'
shutil.copytree('/private/tmp/govpx-astra-intra-simd57/base',b)
seed=Path('/private/tmp/govpx-astra-extra-work55/candidate-score')
for name in ['block_yrd.go','block_yrd_score_simd.go','block_yrd_score_arm64.go','block_yrd_score_amd64.go','block_yrd_score_nosimd.go','block_yrd_score_test.go']:
 shutil.copyfile(seed/'internal/vp9/encoder'/name,b/'internal/vp9/encoder'/name)
for v in ['v37','v38','v39','v40']:shutil.copytree(b,p/v)
f='internal/vp9/encoder/block_yrd_score_simd.go';s=(b/f).read_text()
s37=s.replace('blockYrdMulHigh16(a, vq).Masked(a.GreaterEqual(vd))','blockYrdMulHigh16(a, vq)')
(p/'v37'/f).write_text(s37)
loopstart=s37.index('\tfor i := 0; i < n; i += 8 {',s37.index('func blockYrdQuantScore('));loopend=s37.index('\n\treturn int(blockYrdSum32(rate))',loopstart)
body=s37[loopstart:loopend];inner=body[body.index('\n')+1:body.rfind('\n\t}')]
first=inner.replace('unsafe.Add(cp, i*2)','cp').replace('\t\tvr, vq, vd = acR, acQ, acD\n','')
# A separate scope retains the first packet DC values, then the loop is AC-only.
body38='\t{\n'+first+'\n\t}\n\tfor i := 8; i < n; i += 8 {\n'+inner.replace('vr, vq, vd = acR, acQ, acD','').replace('mag.Add(vr)','mag.Add(acR)').replace('blockYrdMulHigh16(a, vq)','blockYrdMulHigh16(a, acQ)').replace('t.Mul(vd)','t.Mul(acD)')+'\n\t}'
(p/'v38'/f).write_text(s37[:loopstart]+body38+s37[loopend:])
# Bounded unsigned 16-bit lane accumulators: n<=256 and d>=16 imply
# qabs<=2047, hence each lane sums at most 32*2047=65504.
funcstart=s37.index('func blockYrdQuantScore(');openbrace=s37.index('{',funcstart)+1
innerfunc=s37[openbrace:s37.rfind('}')]
narrow=innerfunc.replace('rate, err := archsimd.Uint32x4{}, archsimd.Uint32x4{}','rate, err := archsimd.Uint16x8{}, archsimd.Uint32x4{}').replace('rate.Add(blockYrdSumPairs16(t))','rate.Add(t.ToBits())').replace('int(blockYrdSum32(rate))','int(blockYrdSumUnsigned16(rate))')
s39=s37[:openbrace]+'\n\tif d[0]>=16 && d[1]>=16 {\n'+narrow+'\n\t}\n'+s37[openbrace:]
(p/'v39'/f).write_text(s39)
arm=p/'v39/internal/vp9/encoder/block_yrd_score_arm64.go';arm.write_text(arm.read_text()+'\nfunc blockYrdSumUnsigned16(v archsimd.Uint16x8)uint32{return v.ExtendLo4ToUint32().Add(v.HiToLo().ExtendLo4ToUint32()).ReduceSum()}\n')
amd=p/'v39/internal/vp9/encoder/block_yrd_score_amd64.go';amd.write_text(amd.read_text()+'\nfunc blockYrdSumUnsigned16(v archsimd.Uint16x8)uint32{hi:=v.ReshapeToUint32s().PermuteScalars(2,3,0,1).ReshapeToUint16s();return blockYrdSum32(v.ExtendLo4ToUint32().Add(hi.ExtendLo4ToUint32()))}\n')
s40=s37.replace('\t\tmag := c.Abs().ToBits()','\t\tmag := c.Abs().ToBits()\n\t\tbits:=mag.ReshapeToUint64s()\n\t\tif bits.GetElem(0)|bits.GetElem(1)==0 {vr,vq,vd=acR,acQ,acD;continue}')
(p/'v40'/f).write_text(s40)
with Path('/private/tmp/govpx-astra-iterations26-50/experiments.tsv').open('a')as z:
 for i,h in [(37,'Remove redundant threshold mask guaranteed by reciprocal quantizer'),(38,'Peel DC packet to eliminate AC loop parameter moves'),(39,'Bounded uint16 rate accumulation removes widening per packet'),(40,'Skip all-zero coefficient packet arithmetic')]:z.write(f'{i}\t{h}\timplemented\tVP9 fused scoring seed on c4\t{p}/v{i}\n')

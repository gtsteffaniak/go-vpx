from pathlib import Path
import shutil,subprocess
p=Path('/private/tmp/govpx-astra-intra-simd57');p.mkdir();(p/'proof').mkdir()
b=p/'base';b.mkdir()
arc=subprocess.Popen(['git','-C','/Users/thesyncim/GolandProjects/govpx','archive','c4a8bd9f66805fc9b7b4f99e26752cc68505e572'],stdout=subprocess.PIPE)
r=subprocess.run(['tar','-x','-C',str(b)],stdin=arc.stdout);assert r.returncode==0;assert arc.wait()==0
for v in ['v29','v30','v31','v32']:shutil.copytree(b,p/v)

from pathlib import Path
import shutil,re
p=Path('/private/tmp/govpx-astra-score58');base=p/'v37';f='internal/vp9/encoder/block_yrd_score_simd.go';s=(base/f).read_text()
for v in ['v41','v42','v43','v44']:shutil.copytree(base,p/v)
# Exact existing eight-row Hadamard body, ending before its output stores.
h=(base/'internal/vp9/encoder/hadamard_block_yrd_simd.go').read_text();a=h.index('func hadamardBlockYrd8(');a=h.index('{',a)+1;b=h.index('\n\tv0.StoreArray',a);hbody=h[a:b]
setup='''
 ar:=archsimd.BroadcastUint16x8(uint16(r[1]));aq:=archsimd.BroadcastInt16x8(q[1]);ad:=archsimd.BroadcastInt16x8(d[1])
 rr,qq,dd:=ar.SetElem(0,uint16(r[0])),aq.SetElem(0,q[0]),ad.SetElem(0,d[0])
 max16:=archsimd.BroadcastUint16x8(32767)
 rate,err:=archsimd.Uint32x4{},archsimd.Uint32x4{}
'''
def quant(v,first=False,rate='rate',err='err'):
 rr,qq,dd=('rr','qq','dd')if first else('ar','aq','ad')
 return f'''{{
 mag:={v}.Abs().ToBits();a:=mag.Add({rr}).Min(max16).BitsToInt16();t:=blockYrdMulHigh16(a,{qq})
 {rate}={rate}.Add(blockYrdSumPairs16(t));diff:=mag.Sub(t.Mul({dd}).ToBits()).BitsToInt16();{err}={err}.Add(blockYrdSquarePairs16(diff))
 }}\n'''
commonhead='''//go:build goexperiment.simd && (arm64 || amd64) && !purego
package encoder
import("simd/archsimd";"unsafe")
// The BlockYrd scoring caller proves complete residual rows, disjoint scratch,
// and the bounded quantizer contract documented by blockYrdQuantScore.
'''
new41=commonhead+'''func blockYrdHadamard8Score(input []int16,stride int,r,q,d [2]int16)(int,uint32){
 src:=unsafe.Pointer(unsafe.SliceData(input))
'''+hbody+setup+''.join(quant('v'+str(i),i==0)for i in range(8))+'''return int(blockYrdSum32(rate)),blockYrdSum32(err)
}
'''
(p/'v41/internal/vp9/encoder/block_yrd_fused41_simd.go').write_text(new41)
old='''\t\t\thadamardBlockYrd(src[y*bw+x:], bw, coeff, n)
\t\t\trtx, etx := blockYrdQuantScore(coeff, n*n, r, q, d)'''
rep='''            var rtx int;var etx uint32
            if n==8 {rtx,etx=blockYrdHadamard8Score(src[y*bw+x:],bw,r,q,d)} else {hadamardBlockYrd(src[y*bw+x:],bw,coeff,n);rtx,etx=blockYrdQuantScore(coeff,n*n,r,q,d)}'''
assert old in s;(p/'v41'/f).write_text(s.replace(old,rep))
new42=commonhead+'''func blockYrdHadamard16Score(input []int16,stride int,coeff []int16,r,q,d [2]int16)(int,uint32){
 sp,cp:=unsafe.Pointer(unsafe.SliceData(input)),unsafe.Pointer(unsafe.SliceData(coeff))
 hadamardBlockYrd8(sp,stride,cp)
 hadamardBlockYrd8(unsafe.Add(sp,16),stride,unsafe.Add(cp,128))
 hadamardBlockYrd8(unsafe.Add(sp,16*stride),stride,unsafe.Add(cp,256))
 hadamardBlockYrd8(unsafe.Add(sp,16*stride+16),stride,unsafe.Add(cp,384))
'''+setup+'''
 for i:=0;i<128;i+=16{
 h0:=archsimd.LoadInt16x8Array((*[8]int16)(unsafe.Add(cp,i)))
 h1:=archsimd.LoadInt16x8Array((*[8]int16)(unsafe.Add(cp,i+128)))
 h2:=archsimd.LoadInt16x8Array((*[8]int16)(unsafe.Add(cp,i+256)))
 h3:=archsimd.LoadInt16x8Array((*[8]int16)(unsafe.Add(cp,i+384)))
 u,v,w,z:=h0.Add(h1).ShiftAllRight(1),h0.Sub(h1).ShiftAllRight(1),h2.Add(h3).ShiftAllRight(1),h2.Sub(h3).ShiftAllRight(1)
 o0,o1,o2,o3:=u.Add(w),v.Add(z),u.Sub(w),v.Sub(z)
'''+''.join(quant('o'+str(i),i==0)for i in range(4))+'''rr,qq,dd=ar,aq,ad
 }
 return int(blockYrdSum32(rate)),blockYrdSum32(err)
}
'''
(p/'v42/internal/vp9/encoder/block_yrd_fused42_simd.go').write_text(new42)
rep='''            var rtx int;var etx uint32
            if n==16 {rtx,etx=blockYrdHadamard16Score(src[y*bw+x:],bw,coeff,r,q,d)} else {hadamardBlockYrd(src[y*bw+x:],bw,coeff,n);rtx,etx=blockYrdQuantScore(coeff,n*n,r,q,d)}'''
(p/'v42'/f).write_text(s.replace(old,rep))
new43=commonhead+'''func blockYrdUniformScore(input []int16,stride,n int,r,q,d [2]int16)(int,uint32,bool){
 sp:=unsafe.Pointer(unsafe.SliceData(input));v:=*(*int16)(sp);same:=archsimd.BroadcastInt16x8(v)
 for y:=0;y<n;y++{for x:=0;x<n;x+=8{
 c:=archsimd.LoadInt16x8Array((*[8]int16)(unsafe.Add(sp,2*(y*stride+x))));bits:=c.ToBits().Xor(same.ToBits()).ReshapeToUint64s()
 if bits.GetElem(0)|bits.GetElem(1)!=0{return 0,0,false}
 }}
 dc:=int(v)*64;if n==16{dc*=2};if dc<0{dc=-dc}
 a:=min(dc+int(r[0]),32767);rate:=a*int(q[0])>>16;diff:=dc-rate*int(d[0])
 return rate,uint32(diff*diff),true
}
'''
(p/'v43/internal/vp9/encoder/block_yrd_uniform43_simd.go').write_text(new43)
rep='''            rtx,etx,uniform:=blockYrdUniformScore(src[y*bw+x:],bw,n,r,q,d)
            if !uniform {hadamardBlockYrd(src[y*bw+x:],bw,coeff,n);rtx,etx=blockYrdQuantScore(coeff,n*n,r,q,d)}'''
(p/'v43'/f).write_text(s.replace(old,rep))
# Two independent accumulation chains halve loop-carried sum dependencies.
l=s.index('\tfor i := 0; i < n; i += 8 {',s.index('func blockYrdQuantScore('));e=s.index('\n\treturn int(blockYrdSum32(rate))',l)
body='''\trate1,err1:=archsimd.Uint32x4{},archsimd.Uint32x4{}
 for i:=0;i<n;i+=16{
  {c:=archsimd.LoadInt16x8Array((*[8]int16)(unsafe.Add(cp,i*2)));mag:=c.Abs().ToBits();a:=mag.Add(vr).Min(max16).BitsToInt16();t:=blockYrdMulHigh16(a,vq);rate=rate.Add(blockYrdSumPairs16(t));diff:=mag.Sub(t.Mul(vd).ToBits()).BitsToInt16();err=err.Add(blockYrdSquarePairs16(diff))}
  {c:=archsimd.LoadInt16x8Array((*[8]int16)(unsafe.Add(cp,i*2+16)));mag:=c.Abs().ToBits();a:=mag.Add(acR).Min(max16).BitsToInt16();t:=blockYrdMulHigh16(a,acQ);rate1=rate1.Add(blockYrdSumPairs16(t));diff:=mag.Sub(t.Mul(acD).ToBits()).BitsToInt16();err1=err1.Add(blockYrdSquarePairs16(diff))}
  vr,vq,vd=acR,acQ,acD
 }
 rate,err=rate.Add(rate1),err.Add(err1)'''
(p/'v44'/f).write_text(s[:l]+body+s[e:])
with Path('/private/tmp/govpx-astra-iterations26-50/experiments.tsv').open('a')as z:
 for i,h in [(41,'Fuse 8x8 Hadamard register outputs directly into quantizer statistics'),(42,'Fuse 16x16 Hadamard combine with quantizer statistics'),(43,'Detect uniform residual Tx blocks and compute only DC statistics'),(44,'Two independent quantizer rate/error accumulation chains')]:z.write(f'{i}\t{h}\timplemented\tVP9 fused scorer versus v37\t{p}/v{i}\n')

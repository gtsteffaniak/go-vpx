from pathlib import Path
import shutil,re
p=Path('/private/tmp/govpx-astra-score58');base=p/'v37';f='internal/vp9/encoder/block_yrd_score_simd.go';s=(base/f).read_text()
for v in ['v45','v46','v47','v48','v49','v50']:shutil.copytree(base,p/v)
l=s.index('\tfor i := 0; i < n; i += 8 {',s.index('func blockYrdQuantScore('));e=s.index('\n\treturn int(blockYrdSum32(rate))',l)
body='\trate1,err1:=archsimd.Uint32x4{},archsimd.Uint32x4{}\n\trate2,err2:=archsimd.Uint32x4{},archsimd.Uint32x4{}\n\trate3,err3:=archsimd.Uint32x4{},archsimd.Uint32x4{}\n\tfor i:=0;i<n;i+=32{\n'
for j in range(4):
 rr,qq,dd=('vr','vq','vd')if j==0 else('acR','acQ','acD');ra,er=('rate','err')if j==0 else('rate'+str(j),'err'+str(j))
 body+=f'{{c:=archsimd.LoadInt16x8Array((*[8]int16)(unsafe.Add(cp,i*2+{j*16})));mag:=c.Abs().ToBits();a:=mag.Add({rr}).Min(max16).BitsToInt16();t:=blockYrdMulHigh16(a,{qq});{ra}={ra}.Add(blockYrdSumPairs16(t));diff:=mag.Sub(t.Mul({dd}).ToBits()).BitsToInt16();{er}={er}.Add(blockYrdSquarePairs16(diff))}}\n'
body+='vr,vq,vd=acR,acQ,acD\n}\nrate=rate.Add(rate1).Add(rate2.Add(rate3));err=err.Add(err1).Add(err2.Add(err3))'
(p/'v45'/f).write_text(s[:l]+body+s[e:])
(p/'v46'/f).write_text(s[:l]+s[l:].replace('for i := 0; i < n; i += 8 {','for off := 0; off < n*2; off += 16 {',1).replace('unsafe.Add(cp, i*2)','unsafe.Add(cp, off)',1))
# Move only dead quantizer setup below a guarded zero-residual early return.
bf='internal/vp9/encoder/block_yrd.go';bs=(base/bf).read_text()
recipe='''\troundFP[0] = int16((48 * int(dequant[0])) >> 7)
\troundFP[1] = int16((42 * int(dequant[1])) >> 7)
\tquantFP[0] = int16((1 << 16) / int(dequant[0]))
\tquantFP[1] = int16((1 << 16) / int(dequant[1]))
'''
assert recipe in bs
bs47=bs.replace(recipe,'',1)
needle='\t// BlockYrd consumes only zero/nonzero, sum(abs(q)), and squared error.'
pos=bs47.index(needle)
new='''\t// The subtraction flag proves all coefficients will be zero. The
\t// scoring helper validates its quantizer range before using that fact;
\t// no reciprocal, round table, or scan is consumed on this path.
\tif !nonzero && maxTxUnits<=blockYrdMaxTxUnits && bw%txDim==0 && bh%txDim==0 {
\t\tif score,ok:=blockYrdScore(srcDiff,bw,bh,txSize,[2]int16{},[2]int16{},dequant,sseIn,residueScratch[srcDiffLen:srcDiffLen+nCoeffs],false);ok{return score}
\t}
'''+recipe
(p/'v47'/bf).write_text(bs47[:pos]+new+bs47[pos:])
# Construct invariant SIMD tables once per BlockYrd, instead of per Tx unit.
start=s.index('func blockYrdQuantScore(');brace=s.index('{',start)+1;setupend=s.index('\n\trate, err :=',brace)
setup='''
 cp:=unsafe.Pointer(unsafe.SliceData(coeff))
 acR,acQ,acD:=tab.acR,tab.acQ,tab.acD
 vr,vq,vd:=tab.vr,tab.vq,tab.vd
 max16:=tab.max16'''
newfunc='''type blockYrdScoreTables struct {acR,vr,max16 archsimd.Uint16x8;acQ,acD,vq,vd archsimd.Int16x8}
func blockYrdMakeTables(r,q,d [2]int16)blockYrdScoreTables{
 ar:=archsimd.BroadcastUint16x8(uint16(r[1]));aq:=archsimd.BroadcastInt16x8(q[1]);ad:=archsimd.BroadcastInt16x8(d[1])
 return blockYrdScoreTables{ar,ar.SetElem(0,uint16(r[0])),archsimd.BroadcastUint16x8(32767),aq,ad,aq.SetElem(0,q[0]),ad.SetElem(0,d[0])}
}
func blockYrdQuantScore(coeff []int16,n int,r,q,d [2]int16)(int,uint32){tab:=blockYrdMakeTables(r,q,d);return blockYrdQuantScoreTable(coeff,n,&tab)}
func blockYrdQuantScoreTable(coeff []int16,n int,tab *blockYrdScoreTables)(int,uint32){'''+setup+s[setupend:]
s48=s[:start]+newfunc
s48=s48.replace('\tvar rate int\n','\ttables:=blockYrdMakeTables(r,q,d)\n\tvar rate int\n',1).replace('blockYrdQuantScore(coeff, n*n, r, q, d)','blockYrdQuantScoreTable(coeff,n*n,&tables)',1)
(p/'v48'/f).write_text(s48)
# Laplace-model closed forms from the pinned rate/dist table endpoints.
needle='''\tif varN == 0 {
\t\treturn 0, 0
\t}
'''
pos=bs.index('func ModelRDFromVarLapndz(');before,tail=bs[:pos],bs[pos:]
(p/'v49'/bf).write_text(before+tail.replace(needle,needle+'''\t// model_rd_norm(0) is exactly (65536,0). Restrict the direct
\t// shift to codec block sizes; unusual shift counts keep original wrap.
\tif qstep==0 && nLog2<=12{return 32768<<nLog2,0}
''',1))
needle='''\tif xsqQ1064 > maxXsqQ10 {
\t\txsqQ10 = maxXsqQ10
\t} else {
\t\txsqQ10 = int(xsqQ1064)
\t}'''
replacement='''\tif xsqQ1064 >= maxXsqQ10 {
\t\t// libvpx v1.16.0 vp9_rd.c tables: model_rd_norm(245727)
\t\t// interpolates buckets102/103 to exactly rate0,dist1023.
\t\treturn 0,(int64(varN)*1023+512)>>10
\t} else {
\t\txsqQ10 = int(xsqQ1064)
\t}'''
assert needle in bs;(p/'v50'/bf).write_text(bs.replace(needle,replacement,1))
# Frozen source model is the independently unchanged equation for branch tests.
a=bs.index('func ModelRDFromVarLapndz(');depth=0;b=None
for i in range(bs.index('{',a),len(bs)):
 if bs[i]=='{':depth+=1
 elif bs[i]=='}':
  depth-=1
  if depth==0:b=i+1;break
frozen=bs[a:b].replace('func ModelRDFromVarLapndz(','func modelRDFrozen58(',1)
fixture='''package encoder
import("testing";"fmt")
'''+frozen+'''
func TestModelRDIterations58(t *testing.T){
 x:=uint32(1873)
 for i:=0;i<8192;i++{
  x=x*1664525+1013904223;v:=x;if i%7==0{v=0};if i%11==0{v=uint32(i&255)}
  x=x*1664525+1013904223;q:=x;if i%3==0{q=0};if i%5==0{q=uint32(i%1024)}
  for _,n:=range []uint{0,4,8,10,12,32,48,63,64}{gr,gd:=ModelRDFromVarLapndz(v,n,q);wr,wd:=modelRDFrozen58(v,n,q);if gr!=wr||gd!=wd{t.Fatalf("v%d n%d q%d got%d/%d want%d/%d",v,n,q,gr,gd,wr,wd)}}
 }
}
var modelRate58 int
var modelDist58 int64
func BenchmarkModelRDIteration58(b *testing.B){
 for _,tc:=range []struct{v uint32;n uint;q uint32}{{0,8,128},{4096,8,0},{1<<24,12,0},{1<<24,8,4},{65535,8,32},{1,8,32},{65535,12,1024},{4096,8,61},{4096,8,62}}{
  b.Run(fmt.Sprintf("v%d-n%d-q%d",tc.v,tc.n,tc.q),func(b *testing.B){b.ReportAllocs();for b.Loop(){modelRate58,modelDist58=ModelRDFromVarLapndz(tc.v,tc.n,tc.q)}})
 }
}
'''
# The scorer fixture remains byte-identical. Only model baseline and model
# candidates require the additional model fixture, and are compared separately.
for v in ['modelbase','v49','v50']:
 if v=='modelbase':shutil.copytree(base,p/v)
 (p/v/'internal/vp9/encoder/model_iterations58_test.go').write_text(fixture)
with Path('/private/tmp/govpx-astra-iterations26-50/experiments.tsv').open('a')as z:
 for i,h in [(45,'Four independent quantizer accumulators and 32-coefficient tiling'),(46,'Byte-offset quantizer induction removes index scaling'),(47,'Zero residual bypasses reciprocal and round-table construction'),(48,'Hoist SIMD quantizer tables across all Tx units'),(49,'Laplace model qstep0 closed form removes divide/table interpolation'),(50,'Laplace saturated endpoint closed form removes interpolation')]:z.write(f'{i}\t{h}\timplemented\tVP9 scorer/model\t{p}/v{i}\n')

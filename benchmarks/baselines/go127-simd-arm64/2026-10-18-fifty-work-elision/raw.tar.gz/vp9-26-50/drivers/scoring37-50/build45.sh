#!/bin/sh
set -eu
export CODEX_AGENT_ID=astra-score58 CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go GOEXPERIMENT=simd GOMAXPROCS=2 GOFLAGS=-p=2 CGO_ENABLED=1
r=/Users/thesyncim/GolandProjects/govpx
p=/private/tmp/govpx-astra-score58
cd "$r"
for v in v45 v46 v47 v48 modelbase v49 v50; do
 if "$r/scripts/go.sh" -C "$p/$v" test -pgo=off -run 'TestBlockYrd(QuantScore|ScoreQuantizer)|TestHadamardBlockYrdConsumer|TestVP9BlockYrd|TestModelRDIterations58|TestVP9Model' ./internal/vp9/encoder > "$p/proof/$v-tests.log" 2>&1; then
  "$r/scripts/go.sh" -C "$p/$v" test -pgo=off -c -o "$p/$v.test" ./internal/vp9/encoder > "$p/proof/$v-build.log" 2>&1
  echo "$v built"
 else
  echo "$v FAILED"
 fi
done

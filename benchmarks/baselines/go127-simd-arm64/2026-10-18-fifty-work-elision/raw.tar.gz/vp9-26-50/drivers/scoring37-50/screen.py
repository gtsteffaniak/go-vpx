from pathlib import Path
import os,subprocess,json,hashlib,re,statistics
p=Path('/private/tmp/govpx-astra-score58');o=p/'proof/screen';o.mkdir(exist_ok=False)
vs=['base','v37','v38','v39','v40'];sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
bind={'base':'c4a8bd9f66805fc9b7b4f99e26752cc68505e572+frozen-fused-score-seed','host':'Apple M4 Max/Darwin arm64','go':'1.27.2','PGO':'off','CGO_ENABLED':1,'GOEXPERIMENT':'simd','GOMAXPROCS':1,'preliminary':True,'variants':{v:{'production':{f.name:sha(f)for f in (p/v/'internal/vp9/encoder').glob('block_yrd*go')if not f.name.endswith('_test.go')},'fixture':sha(p/v/'internal/vp9/encoder/hadamard_score_native_test.go'),'binary':sha(p/(v+'.test'))}for v in vs}}
(o/'binding.json').write_text(json.dumps(bind,indent=2)+'\n');env=os.environ.copy();env['GOMAXPROCS']='1';rows={};commands=[];pat=re.compile(r'^(BenchmarkHadamardScoreConsumerNative\S+)\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op$',re.M)
for rnd,order in enumerate([vs,vs[::-1]],1):
 for v in order:
  cmd=[str(p/(v+'.test')),'-test.run=^$','-test.bench=^BenchmarkHadamardScoreConsumerNative$','-test.benchtime=40ms','-test.count=1','-test.cpu=1','-test.benchmem'];r=subprocess.run(cmd,capture_output=True,text=True,env=env);f=o/f'r{rnd}-{v}.txt';f.write_text(r.stdout);f.with_suffix('.stderr').write_text(r.stderr);commands.append({'cmd':cmd,'rc':r.returncode});assert r.returncode==0
  matches=pat.findall(r.stdout);assert len(matches)==12,(v,len(matches))
  for name,ns,b,a in matches:rows.setdefault(name,{}).setdefault(v,[]).append(float(ns));assert b=='0'and a=='0'
 print('round',rnd,'done',flush=True)
s={}
for v in vs[1:]:
 s[v]={}
 for name,vals in rows.items():
  speed=[a/b for a,b in zip(vals['base'],vals[v])];increment=[a/b for a,b in zip(vals['v37'],vals[v])]
  s[v][name]={'baseline_ns':vals['base'],'candidate_ns':vals[v],'paired_speedup':speed,'median':statistics.median(speed),'slower_pairs':sum(x<1 for x in speed),'v37_speedups':increment,'v37_median':statistics.median(increment)}
(o/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');(o/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
for eid,z in s.items():print(eid,[(k.split('Native/')[1],round(x['median'],3),round(x['v37_median'],3),x['slower_pairs'])for k,x in z.items()],flush=True)
print('END all timing processes stopped',flush=True)

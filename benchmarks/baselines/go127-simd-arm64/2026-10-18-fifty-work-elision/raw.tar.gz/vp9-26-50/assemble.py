from pathlib import Path
import shutil

P = Path('/private/tmp/govpx-astra-iterations26-50')
B = Path('/private/tmp/govpx-astra-score58/base')
C = P / 'keepers'
if not C.exists():
    shutil.copytree(B, C)

files = []
def put(path, source):
    dest = C / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(source)
    if path not in files:
        files.append(path)
def copy(path, origin, source_path=None):
    put(path, (Path(origin)/(source_path or path)).read_text())

# Mode-specific edge acquisition and direct dispatch. Check the common
# available-edge path first, retaining the missing-edge DC specialization.
path = 'vp9_encoder_prediction.go'
s = Path('/private/tmp/govpx-astra-intra-edges56/v28', path).read_text()
a = s.index("\t// libvpx's four DC kernels only read available edges.")
b = s.index('\t// These gathered edges already have libvpx', a)
c = s.index('\tvp9dec.BuildIntraPredictorsWithScratch(', b)
s = s[:a] + s[b:c] + s[a:b] + s[c:]
put(path, s)
copy('vp9_intra_edges56_test.go', '/private/tmp/govpx-astra-intra-edges56/v28')

# Fixed wrappers isolate profitable shapes: rejected generic fast-path checks
# do not enlarge the unchanged small scalar predictors.
path = 'internal/vp9/dsp/intrapred.go'
s = (B/path).read_text().replace('package dsp\n', 'package dsp\n\nimport "github.com/thesyncim/govpx/internal/pixel"\n', 1)
needle = 'func tmPredictor(dst []uint8, stride, bs int, above, left []uint8) {\n'
s = s.replace(needle, needle + '''\tif intraBridgeDisjoint(dst, stride, bs, above, bs+1) &&
\t\tintraBridgeDisjoint(dst, stride, bs, left, bs) {
\t\tpixel.TMPredict(dst, stride, above[1:], left, above[0], bs)
\t\treturn
\t}
''', 1)
needle = 'func VpxTmPredictor32x32(dst []uint8, stride int, above, left []uint8) {\n'
s = s.replace(needle, needle + '''\tif intraBridgeDisjoint(dst, stride, 32, above, 33) &&
\t\tintraBridgeDisjoint(dst, stride, 32, left, 32) &&
\t\tintraTM32Fixed(dst, stride, above[1:], left, above[0]) {
\t\treturn
\t}
''', 1)
for n in [8, 16, 32]:
    needle = f'func VpxHPredictor{n}x{n}(dst []uint8, stride int, above, left []uint8) {{\n\t_ = above[0]\n'
    s = s.replace(needle, needle + f'\tif intraHFixed(dst, stride, {n}, left) {{\n\t\treturn\n\t}}\n', 1)
needle = 'func VpxVPredictor16x16(dst []uint8, stride int, above, left []uint8) {\n'
s = s.replace(needle, needle + '\tif intraVFixed(dst, stride, 16, above[1:]) {\n\t\treturn\n\t}\n', 1)
for kind, up, lf in [('Dc','true','true'), ('DcLeft','false','true'), ('DcTop','true','false'), ('Dc128','false','false')]:
    for n in [4, 8, 16, 32]:
        if n == 4 and kind == 'Dc':
            call = 'pixel.Intra4x4DCFill(dst, stride, above[1:], left)'
        elif n in [8,16]:
            call = f'pixel.IntraDCFill(dst, stride, above[1:], left, {n}, {up}, {lf})'
        else:
            call = f'intraDCFixed(dst, stride, {n}, above[1:], left, {up}, {lf})'
        needle = f'func Vpx{kind}Predictor{n}x{n}(dst []uint8, stride int, above, left []uint8) {{\n'
        assert needle in s
        s = s.replace(needle, needle + f'\tif {call} {{\n\t\treturn\n\t}}\n', 1)
put(path, s)
for f in ['intra_bridge.go', 'intrapred_fixed_simd.go', 'intrapred_fixed_arm64.go', 'intrapred_fixed_amd64.go', 'intrapred_fixed_nosimd.go', 'intra_bridge57_test.go']:
    copy('internal/vp9/dsp/'+f, '/private/tmp/govpx-astra-intra-simd57/v36')

# Keep the bounded narrow accumulator and direct 8x8 register consumer.
# Uniform Tx input is handled before either transform, replacing the weaker
# zero-coefficient packet shortcut on that representative workload.
path = 'internal/vp9/encoder/block_yrd_score_simd.go'
s = Path('/private/tmp/govpx-astra-score58/v39', path).read_text()
old = '''\t\t\thadamardBlockYrd(src[y*bw+x:], bw, coeff, n)
\t\t\trtx, etx := blockYrdQuantScore(coeff, n*n, r, q, d)
'''
new = '''\t\t\tinput := src[y*bw+x:]
\t\t\trtx, etx, uniform := blockYrdUniformScore(input, bw, n, r, q, d)
\t\t\tif !uniform {
\t\t\t\tif n == 8 {
\t\t\t\t\trtx, etx = blockYrdHadamard8Score(input, bw, r, q, d)
\t\t\t\t} else {
\t\t\t\t\thadamardBlockYrd(input, bw, coeff, n)
\t\t\t\t\trtx, etx = blockYrdQuantScore(coeff, n*n, r, q, d)
\t\t\t\t}
\t\t\t}
'''
assert old in s
s = s.replace(old, new, 1)
s = s.replace('if d[0] >= 16 && d[1] >= 16 {\n\n', '''// For d>=16, each qabs<=2047. At most 32 packets contribute to
\t// a lane, so 32*2047=65504 fits uint16 without per-packet widening.
\tif d[0] >= 16 && d[1] >= 16 {
''', 1)
s = s.replace('blockYrdSum32(err)\n\n\t}', 'blockYrdSum32(err)\n\t}', 1)
s = s.replace('// Thus q>=0 and qabs*d<=32767:', '''// The usual threshold mask is redundant here: a<d implies
// floor(a*floor(65536/d)/65536)==0. Thus q>=0 and qabs*d<=32767:''', 1)
put(path, s)
for f in ['block_yrd_score_arm64.go','block_yrd_score_amd64.go']:
    copy('internal/vp9/encoder/'+f, '/private/tmp/govpx-astra-score58/v39')
copy('internal/vp9/encoder/block_yrd_hadamard_score_simd.go', '/private/tmp/govpx-astra-score58/v41', 'internal/vp9/encoder/block_yrd_fused41_simd.go')
copy('internal/vp9/encoder/block_yrd_uniform_simd.go', '/private/tmp/govpx-astra-score58/v43', 'internal/vp9/encoder/block_yrd_uniform43_simd.go')

path = 'internal/vp9/encoder/block_yrd.go'
s = Path('/private/tmp/govpx-astra-score58/v50', path).read_text()
needle = '''func ModelRDFromVarLapndz(varN uint32, nLog2 uint, qstep uint32) (rate int, dist int64) {
\tif varN == 0 {
\t\treturn 0, 0
\t}
'''
assert needle in s
s = s.replace(needle, needle + '''\t// At xsq=0 the libvpx table is exactly rQ10=65536, dQ10=0.
\t// Keep the general arithmetic for unusual shifts outside block sizes.
\tif qstep == 0 && nLog2 <= 12 {
\t\treturn 32768 << nLog2, 0
\t}
''', 1)
put(path, s)
copy('internal/vp9/encoder/model_iterations58_test.go', '/private/tmp/govpx-astra-score58/v50')
copy('internal/vp9/encoder/hadamard_score_native_test.go', '/private/tmp/govpx-astra-score58/v43')

(P/'keeper-files.txt').write_text('\n'.join(files)+'\n')
print(f'Assembled {len(files)} files in {C}')

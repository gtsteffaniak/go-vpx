from pathlib import Path
import shutil,subprocess,json,re
root=Path('/Users/thesyncim/GolandProjects/govpx'); dest=Path('/private/tmp/govpx-iterations50'); base=dest/'base'
if not base.exists():
 for f in subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0'):
  if not f or f.startswith(('benchmarks/baselines/','internal/coracle/build/')):continue
  p=base/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/f,p)
 (dest/'baseline.json').write_text(json.dumps({'commit':'c4a8bd9f66805fc9b7b4f99e26752cc68505e572','cpu':'Apple M4 Max','os':'darwin/arm64','go':'go1.27.2','GOEXPERIMENT':'simd','pgo':'off','full_validation_threshold':'same-host/workload codec throughput >=1.5x; component wins do not unlock'},indent=2)+'\n')
enc='internal/vp8/encoder/'
batch=enc+'dct_batch_gosimd_arm64.go'; shifts=enc+'transform_shifts_arm64.go'; single=enc+'transform_simd.go'
def variant(n,name):
 p=dest/f'{n:02d}-{name}';shutil.copytree(base,p,dirs_exist_ok=True);return p
def put(p,f,s): (p/f).write_text(s)
def fixed(p):
 s=(p/shifts).read_text();s=re.sub(r'var vp8Shift\w+ = archsimd.BroadcastInt32x4\(-?\d+\)\n\n','',s)
 for name,d in [('Left2',2),('Left3',3),('Right3',3),('Right4',4),('Right12',12),('Right16',16),('Sign',31)]:
  s=s.replace(f'v.Shift(vp8Shift{name})',f'v.ShiftAll{"Left" if name.startswith("Left") else "Right"}({d})')
 put(p,shifts,s)
 s=(p/batch).read_text();s=re.sub(r'var vp8Batch(?:Left3|Right4) = archsimd.BroadcastInt16x8\(-?\d+\)\n\n','',s);s=s.replace('.Shift(vp8BatchLeft3)','.ShiftAllLeft(3)').replace('.Shift(vp8BatchRight4)','.ShiftAllRight(4)');put(p,batch,s)
p=variant(1,'fixed-shifts');fixed(p)
p=variant(2,'batch-array-windows');s=(p/batch).read_text();s=s.replace('"simd/archsimd"','"simd/archsimd"\n "unsafe"');s=s.replace('i := 0','if count > len(input)/16 || count > len(output)/16 { return 0 }\n ip, op := unsafe.SliceData(input), unsafe.SliceData(output)\n i := 0',1)
for o in [0,8,16,24]:
 s=s.replace('archsimd.LoadInt16x8(in'+('' if o==0 else f'[{o}:]')+')',f'archsimd.LoadInt16x8Array((*[8]int16)(unsafe.Add(unsafe.Pointer(ip), (i*16+{o})*2)))')
 s=s.replace('.Store(out'+('' if o==0 else f'[{o}:]')+')',f'.StoreArray((*[8]int16)(unsafe.Add(unsafe.Pointer(op), (i*16+{o})*2)))')
put(p,batch,s)
p=variant(3,'uniform-dc');s=(p/batch).read_text();needle='// Deinterleave the four input columns across eight rows (two blocks).';insert='''// Constant blocks have one DC term and the exact raster-1 rounding term.
        dc0, dc1 := r0.GetElem(0), r2.GetElem(0)
        same0, same1 := archsimd.BroadcastInt16x8(dc0), archsimd.BroadcastInt16x8(dc1)
        diff := r0.Xor(same0).Or(r1.Xor(same0)).Or(r2.Xor(same1)).Or(r3.Xor(same1))
        if diff.ToBits().ReduceMax() == 0 {
            v0 := archsimd.Int16x8{}.SetElem(0, dc0*8).SetElem(1, 1)
            v1 := archsimd.Int16x8{}.SetElem(0, dc1*8).SetElem(1, 1)
            z := archsimd.Int16x8{}
            v0.Store(out); z.Store(out[8:]); v1.Store(out[16:]); z.Store(out[24:]); continue
        }
        ''';s=s.replace(needle,insert+needle);put(p,batch,s)
p=variant(4,'subtract-condition-mask');s=(p/batch).read_text().replace('o1.Add(w.NotEqual(archsimd.Int16x8{}).ToInt16x8().And(archsimd.BroadcastInt16x8(1)))','o1.Sub(w.NotEqual(archsimd.Int16x8{}).ToInt16x8())');put(p,batch,s)
p=variant(5,'ordinary-range-branch');s=(p/batch).read_text().replace('if peak-1 >= 255 {','if peak == 0 || peak > 255 {');put(p,batch,s)
p=variant(6,'or-zero-before-abs');s=(p/batch).read_text();start=s.index('\t\tmagnitude :=');end=s.index('\t\t// Deinterleave',start);s=s[:start]+'''        if r0.Or(r1).Or(r2).Or(r3).ToBits().ReduceMax() == 0 {
            v := archsimd.Int16x8{}.SetElem(1, 1); z := archsimd.Int16x8{}
            v.Store(out); z.Store(out[8:]); v.Store(out[16:]); z.Store(out[24:]); continue
        }
        magnitude := r0.Abs().ToBits().Max(r1.Abs().ToBits()).Max(r2.Abs().ToBits()).Max(r3.Abs().ToBits())
        if magnitude.ReduceMax() > 255 {
            forwardDCT4x4Scalar(in, 4, (*[16]int16)(out))
            forwardDCT4x4Scalar(in[16:], 4, (*[16]int16)(out[16:])); continue
        }
'''+s[end:];put(p,batch,s)
p=variant(7,'balanced-range-reduction');s=(p/batch).read_text().replace('r0.Abs().ToBits().Max(r1.Abs().ToBits()).Max(r2.Abs().ToBits()).Max(r3.Abs().ToBits())','r0.Abs().ToBits().Max(r1.Abs().ToBits()).Max(r2.Abs().ToBits().Max(r3.Abs().ToBits()))');put(p,batch,s)
p=variant(8,'split-dct-walsh');s=(p/single).read_text();head=s[:s.index('func forward4Go')];body=s[s.index('func forward4Go'):];wrapper='''func forward4Go(input []int16, stride int, output *[16]int16, walsh bool) bool {
 if walsh { return forwardWalshOnlyGo(input,stride,output) }
 return forwardDCTOnlyGo(input,stride,output)
}
'''
body1=body.replace('func forward4Go(input []int16, stride int, output *[16]int16, walsh bool)','func forwardDCTOnlyGo(input []int16, stride int, output *[16]int16)').replace('!walsh','true').replace('if walsh','if false')
body2=body.replace('func forward4Go(input []int16, stride int, output *[16]int16, walsh bool)','func forwardWalshOnlyGo(input []int16, stride int, output *[16]int16)').replace('!walsh','false').replace('if walsh','if true')
put(p,single,head+wrapper+body1+body2)
# Shared constant/mixed/tiny fixtures and a scalar oracle on all original packet overlaps.
fixture='''package encoder
import("testing";"github.com/thesyncim/govpx/internal/pixel")
func BenchmarkIterationFDCT(b *testing.B) {
 for _, pattern := range []string{"zero","dc","alternating","sparse","dense"} { b.Run(pattern,func(b *testing.B){
 var in,out [256]int16
 for i:=range in {switch pattern {case "dc": in[i]=int16((i/16)%31-15);case "alternating":if (i/16)%2!=0 {in[i]=int16((i*37+11)%511-255)};case "sparse":if i%32==0 {in[i]=17};case "dense":in[i]=int16((i*37+11)%511-255)}}
 b.ReportAllocs();for b.Loop(){ForwardDCT4x4Batch(in[:],out[:],16)}
 }) }
}
func TestIterationFDCTPackets(t *testing.T){
 if !pixel.Enabled {t.Skip("SIMD packet order")}
 for _,count:=range []int{1,2,3,8,16,25}{for delta:=-17;delta<=17;delta++{for pattern:=0;pattern<5;pattern++{
 const off=64; got:=make([]int16,off+25*16+80);for i:=range got {got[i]=0x1357};for i:=0;i<count*16;i++{switch pattern{case 0:got[off+i]=0;case 1:got[off+i]=int16((i/16)%31-15);case 2:if (i/16)%2!=0 {got[off+i]=int16((i*37+11)%511-255)}else{got[off+i]=0};case 3:got[off+i]=int16((i*37+11)%511-255);case 4:got[off+i]=int16(i*17557)}}
 want:=append([]int16(nil),got...);in,out:=want[off:off+count*16],want[off+delta:off+delta+count*16];i:=0
 for ;i+2<=count;i+=2 {var stage,result [32]int16;copy(stage[:],in[i*16:i*16+32]);peak:=0;for _,v:=range stage{x:=int(v);if x<0{x=-x};if x>peak{peak=x}};if peak>255 {forwardDCT4x4Scalar(in[i*16:],4,(*[16]int16)(out[i*16:]));forwardDCT4x4Scalar(in[i*16+16:],4,(*[16]int16)(out[i*16+16:]))} else {forwardDCT4x4Scalar(stage[:16],4,(*[16]int16)(result[:16]));forwardDCT4x4Scalar(stage[16:],4,(*[16]int16)(result[16:]));copy(out[i*16:i*16+32],result[:])}}
 for ;i<count;i++{forwardDCT4x4Scalar(in[i*16:],4,(*[16]int16)(out[i*16:]))};ForwardDCT4x4Batch(got[off:off+count*16],got[off+delta:off+delta+count*16],count)
 for lane,x:=range got{if x!=want[lane]{t.Fatalf("count%d delta%d pattern%d lane%d got%d want%d",count,delta,pattern,lane,x,want[lane])}}
 }}}
}
'''
for p in [base]+sorted(dest.glob('[0-9][0-9]-*')):put(p,enc+'iteration_fdct_test.go',fixture)
print('prepared',len(list(dest.glob('[0-9][0-9]-*'))),'variants')

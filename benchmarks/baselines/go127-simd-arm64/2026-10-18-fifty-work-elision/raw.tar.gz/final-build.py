exec(open('/private/tmp/govpx-iterations50/build.py').read().split('selected=')[0])
import re
p=D/'final';selector='^Test(VP8WorkElision|BlockYrd|VP9BlockYrd|Hadamard|IntraBridge57|ModelRDIterations58|MLCacheStreamNative|VP9ScratchLiveEdgeReads56|ForwardDCT4x4SIMDMatchesScalar|ForwardDCTBatchIndependentScalar|WalshFullSignedNative|ForwardWalsh)'
cmds=[('final-native-tests.log',[str(R/'scripts/go.sh'),'-C',str(p),'test','-pgo=off','./internal/vp8/encoder','./internal/vp9/encoder','./internal/vp9/dsp','.', '-run',selector,'-count=1','-v'],env),('final-whole-build.log',[str(R/'scripts/go.sh'),'-C',str(p),'build','-pgo=off','-o',str(D/'final-whole'),'./cmd/govpx-bench'],env),('final-amd64-build.log',[str(R/'scripts/go.sh'),'-C',str(p),'test','-c','-pgo=off','-o',str(D/'final-vp9-linux-amd64.test'),'./internal/vp9/dsp'],env|{'CGO_ENABLED':'0','GOOS':'linux','GOARCH':'amd64'})]
for log,cmd,e in cmds:
 with (D/log).open('w') as f:r=subprocess.run(cmd,cwd=R,env=e,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:print((D/log).read_text()[-4000:],flush=True);raise RuntimeError((log,r.returncode))
 print(log,'PASS',flush=True)
a=re.findall(r'stream_sha256=(\w+)',(D/'base-whole-build.log').read_text());b=re.findall(r'stream_sha256=(\w+)',(D/'final-native-tests.log').read_text());assert len(a)==3 and a==b,(a,b)
(D/'final-stream-comparison.json').write_text(json.dumps({'packets':72,'base':a,'final':b,'match':True},indent=2)+'\n');print('final all72packet hashes match c4',flush=True)

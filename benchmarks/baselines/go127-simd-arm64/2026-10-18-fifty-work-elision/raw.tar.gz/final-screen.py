from pathlib import Path
import subprocess,os,re,json,statistics,time
D=Path('/private/tmp/govpx-iterations50');O=D/'final-screen';O.mkdir(exist_ok=True);env=os.environ|{'GOMAXPROCS':'1'}
pat='^Benchmark(IterationFDCT|IterationSingle|IterationGather|IterationBPred)$'
rows=[]
for rnd in (1,2):
 for ref in (('base','combined') if rnd==1 else ('combined','base')):
  p=O/f'r{rnd}-{ref}.txt';cmd=[str(D/(ref+'.test')),'-test.run=^$','-test.bench='+pat,'-test.benchtime=80ms','-test.count=1','-test.benchmem']
  with p.open('w') as f,p.with_suffix('.stderr').open('w') as e:
   r=subprocess.run(cmd,cwd=D/ref,env=env,stdout=f,stderr=e)
  if r.returncode:raise RuntimeError((ref,r.returncode))
  vals={}
  for line in p.read_text().splitlines():
   m=re.match(r'(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',line)
   if m: vals[m[1]]={'ns':float(m[2]),'bytes':int(m[3]),'allocs':int(m[4])}
  rows.append({'round':rnd,'ref':ref,'values':vals,'cmd':cmd,'raw':str(p)})
pairs={}
for rnd in (1,2):
 a=next(x for x in rows if x['round']==rnd and x['ref']=='base')['values'];b=next(x for x in rows if x['round']==rnd and x['ref']=='combined')['values']
 for k in a.keys()&b.keys():pairs.setdefault(k,[]).append(a[k]['ns']/b[k]['ns'])
s={'pairs':pairs,'medians':{k:statistics.median(v) for k,v in pairs.items()},'rows':rows};(O/'summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s['medians'],sort_keys=True),flush=True)

# Preserved TM research history

All timed screens compare directly with the frozen left-packet parent and old691, 27 public cases × three balanced three-way 75 ms rounds. They are not pooled with the final fresh-six window.

| Variant | Samples | Scope/outcome |
|---|---:|---|
| Packed-store | 243 | TM8 pitch8 1.073–1.115× parent; mixed controls; below1.5. |
| Bias-swap | 243 | One TBL instead of two, but near-flat/mixed public results. |
| Void-dispatch | 243 | Reduced fallback argument spills; public wrappers lost inlining; modest/mixed gains. |
| Direct-glue | 243 | Restored one native call; all target pairs faster, below1.5. |
| Unroll prototype | 243 | All target medians beat old reference; three TM8 pairs slower. Clean refactor preserves exact native code. |
| Float64 bit-store | 0 | Exact raw NaN bits/aliases pass; same244-instruction body, no timing justified. |

Each history directory in raw.tar.gz includes its changed-source overlay, evidence, reproduction scripts and all available raw screen files. Compiled binaries are omitted and recorded in OMITTED-BINARIES.json.

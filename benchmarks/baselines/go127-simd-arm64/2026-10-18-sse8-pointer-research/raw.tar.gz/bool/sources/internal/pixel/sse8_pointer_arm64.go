//go:build goexperiment.simd && arm64 && !purego

package pixel

import (
	"simd/archsimd"
	"unsafe"
)

// SSE8Ptr computes an already validated 8x8 window, following libvpx v1.16.0
// vpx_dsp/variance.c. Each exact eight-byte row is read once; inputs may alias.
func SSE8Ptr(src *byte, ss int, ref *byte, rs int) (uint32, bool) {
	if !Enabled || src == nil || ref == nil || (uint(ss)|uint(rs))>>30 != 0 {
		return 0, false
	}
	sp, rp := unsafe.Pointer(src), unsafe.Pointer(ref)
	var lo, hi archsimd.Int32x4
	{
		a := (archsimd.Uint64x2{}).SetElem(0, *(*uint64)(unsafe.Add(sp, 0*ss))).SetElem(1, *(*uint64)(unsafe.Add(sp, 1*ss))).ReshapeToUint8s()
		b := (archsimd.Uint64x2{}).SetElem(0, *(*uint64)(unsafe.Add(rp, 0*rs))).SetElem(1, *(*uint64)(unsafe.Add(rp, 1*rs))).ReshapeToUint8s()
		d := a.Max(b).Sub(a.Min(b))
		lo = lo.Add(square8(widen8(d)))
		hi = hi.Add(square8(widen8(highBytes(d))))
	}
	{
		a := (archsimd.Uint64x2{}).SetElem(0, *(*uint64)(unsafe.Add(sp, 2*ss))).SetElem(1, *(*uint64)(unsafe.Add(sp, 3*ss))).ReshapeToUint8s()
		b := (archsimd.Uint64x2{}).SetElem(0, *(*uint64)(unsafe.Add(rp, 2*rs))).SetElem(1, *(*uint64)(unsafe.Add(rp, 3*rs))).ReshapeToUint8s()
		d := a.Max(b).Sub(a.Min(b))
		lo = lo.Add(square8(widen8(d)))
		hi = hi.Add(square8(widen8(highBytes(d))))
	}
	{
		a := (archsimd.Uint64x2{}).SetElem(0, *(*uint64)(unsafe.Add(sp, 4*ss))).SetElem(1, *(*uint64)(unsafe.Add(sp, 5*ss))).ReshapeToUint8s()
		b := (archsimd.Uint64x2{}).SetElem(0, *(*uint64)(unsafe.Add(rp, 4*rs))).SetElem(1, *(*uint64)(unsafe.Add(rp, 5*rs))).ReshapeToUint8s()
		d := a.Max(b).Sub(a.Min(b))
		lo = lo.Add(square8(widen8(d)))
		hi = hi.Add(square8(widen8(highBytes(d))))
	}
	{
		a := (archsimd.Uint64x2{}).SetElem(0, *(*uint64)(unsafe.Add(sp, 6*ss))).SetElem(1, *(*uint64)(unsafe.Add(sp, 7*ss))).ReshapeToUint8s()
		b := (archsimd.Uint64x2{}).SetElem(0, *(*uint64)(unsafe.Add(rp, 6*rs))).SetElem(1, *(*uint64)(unsafe.Add(rp, 7*rs))).ReshapeToUint8s()
		d := a.Max(b).Sub(a.Min(b))
		lo = lo.Add(square8(widen8(d)))
		hi = hi.Add(square8(widen8(highBytes(d))))
	}
	return uint32(sum32(lo.Add(hi))), true
}

//go:build goexperiment.simd && arm64 && !purego

package pixel

import (
	"bytes"
	"testing"
)

func TestSSE8PointerExactRows(t *testing.T) {
	for _, strides := range [][2]int{{0, 0}, {1, 7}, {7, 1}, {8, 8}, {17, 31}, {1312, 1320}} {
		ss, rs := strides[0], strides[1]
		sn, rn := 7*ss+8, 7*rs+8
		for sa := 0; sa < 16; sa++ {
			for ra := 0; ra < 16; ra++ {
				for mode := 0; mode < 3; mode++ {
					src, ref := make([]byte, sa+sn), make([]byte, ra+rn)
					for i := range src {
						src[i] = byte(i*37 + 11)
					}
					for i := range ref {
						ref[i] = byte(i*71 + 19)
					}
					if mode == 1 {
						clear(src)
						for i := range ref {
							ref[i] = 255
						}
					} else if mode == 2 {
						clear(src)
						clear(ref)
					}
					savedS, savedR := bytes.Clone(src), bytes.Clone(ref)
					var want uint32
					for y := 0; y < 8; y++ {
						for x := 0; x < 8; x++ {
							d := int(src[sa+y*ss+x]) - int(ref[ra+y*rs+x])
							want += uint32(d * d)
						}
					}
					got, ok := SSE8Ptr(&src[sa], ss, &ref[ra], rs)
					if !ok || got != want || !bytes.Equal(src, savedS) || !bytes.Equal(ref, savedR) {
						t.Fatalf("strides%v align%d/%d mode%d got%d/%v want%d", strides, sa, ra, mode, got, ok, want)
					}
				}
			}
		}
		for _, offsets := range [][2]int{{0, 0}, {0, 1}, {1, 0}, {3, 7}, {7, 3}, {0, 17}, {17, 0}} {
			so, ro := offsets[0], offsets[1]
			back := make([]byte, max(so+sn, ro+rn))
			for i := range back {
				back[i] = byte(i*37 + 23)
			}
			saved := bytes.Clone(back)
			var want uint32
			for y := 0; y < 8; y++ {
				for x := 0; x < 8; x++ {
					d := int(back[so+y*ss+x]) - int(back[ro+y*rs+x])
					want += uint32(d * d)
				}
			}
			got, ok := SSE8Ptr(&back[so], ss, &back[ro], rs)
			if !ok || got != want || !bytes.Equal(back, saved) {
				t.Fatalf("alias%v strides%v got%d/%v want%d", offsets, strides, got, ok, want)
			}
		}
	}
}

func TestSSE8PointerDeclines(t *testing.T) {
	a, b := byte(3), byte(17)
	for _, strides := range [][2]int{{-1, 8}, {8, -1}, {1 << 30, 8}, {8, 1 << 30}, {int(^uint(0) >> 1), 8}, {8, int(^uint(0) >> 1)}} {
		if _, ok := SSE8Ptr(&a, strides[0], &b, strides[1]); ok {
			t.Fatalf("handled invalid%v", strides)
		}
	}
	for _, ptrs := range [][2]*byte{{nil, &b}, {&a, nil}, {nil, nil}} {
		if _, ok := SSE8Ptr(ptrs[0], 8, ptrs[1], 8); ok {
			t.Fatal("handled nil")
		}
	}
	if a != 3 || b != 17 {
		t.Fatal("inputs changed")
	}
}

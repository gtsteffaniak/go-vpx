//go:build !goexperiment.simd || !arm64 || purego

package pixel

func SSE8Ptr(src *byte, ss int, ref *byte, rs int) (uint32, bool) { return 0, false }

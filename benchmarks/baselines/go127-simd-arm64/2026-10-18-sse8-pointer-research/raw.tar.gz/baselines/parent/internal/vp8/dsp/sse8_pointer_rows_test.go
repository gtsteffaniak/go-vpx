package dsp

import (
	"bytes"
	"testing"
)

func TestSSE8PointerPublicRows(t *testing.T) {
	for _, p := range [][2]int{{0, 0}, {1, 7}, {7, 1}, {8, 8}, {17, 31}, {1312, 1320}} {
		for _, off := range [][2]int{{0, 0}, {0, 1}, {1, 0}, {3, 7}, {7, 3}, {0, 17}, {17, 0}} {
			ss, rs := p[0], p[1]
			so, ro := off[0], off[1]
			back := make([]byte, max(so+7*ss+8, ro+7*rs+8))
			for i := range back {
				back[i] = byte(i*37 + 23)
			}
			saved := bytes.Clone(back)
			want := 0
			for y := 0; y < 8; y++ {
				for x := 0; x < 8; x++ {
					d := int(back[so+y*ss+x]) - int(back[ro+y*rs+x])
					want += d * d
				}
			}
			if got := SSE8x8PtrFast(&back[so], ss, &back[ro], rs); got != want || !bytes.Equal(back, saved) {
				t.Fatalf("strides%v offsets%v got%d want%d", p, off, got, want)
			}
		}
	}
}

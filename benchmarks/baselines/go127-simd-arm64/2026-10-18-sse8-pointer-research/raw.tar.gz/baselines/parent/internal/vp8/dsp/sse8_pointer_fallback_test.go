package dsp

import (
 "fmt"
 "os"
 "os/exec"
 "strconv"
 "strings"
 "testing"
)

func TestSSE8PointerPublicFallbackPanics(t *testing.T) {
 var a,b [64]byte
 cases:=[]struct{s *byte;ss int;r *byte;rs int}{
  {nil,8,&b[0],8},{&a[0],8,nil,8},{nil,8,nil,8},
  {&a[0],-2,&b[0],8},{&a[0],8,&b[0],-2},
  {&a[0],int(^uint(0)>>1),&b[0],8},{&a[0],8,&b[0],int(^uint(0)>>1)},
  {nil,1<<30,&b[0],8},{&a[0],8,nil,1<<30},
 }
 const key="GOVPX_SSE8_POINTER_PANIC_PROBE"
 if raw:=os.Getenv(key);raw!="" {
  i,err:=strconv.Atoi(raw);if err!=nil||i<0||i>=len(cases){t.Fatal("invalid probe")}
  c:=cases[i];_ = SSE8x8PtrFast(c.s,c.ss,c.r,c.rs);return
 }
 exe,err:=os.Executable();if err!=nil {t.Fatal(err)}
 for i:=range cases {t.Run(fmt.Sprint(i),func(t *testing.T){
  cmd:=exec.Command(exe,"-test.run=^TestSSE8PointerPublicFallbackPanics$")
  cmd.Env=append(os.Environ(),key+"="+fmt.Sprint(i))
  output,err:=cmd.CombinedOutput()
  if err==nil||!strings.Contains(string(output),"unsafe.Slice") {t.Fatalf("expected original window failure: %v\n%s",err,output)}
 })}
}

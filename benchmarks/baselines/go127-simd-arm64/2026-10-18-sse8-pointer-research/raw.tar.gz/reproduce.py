#!/usr/bin/python3
"""Explicit native reproduction of rejected screens; never changes the checkout."""
import argparse
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

parser=argparse.ArgumentParser()
parser.add_argument('--repo',type=Path,required=True)
parser.add_argument('--work',type=Path,required=True,help='New private directory')
parser.add_argument('--go',default='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go')
args=parser.parse_args()
package=Path(__file__).resolve().parent
metadata=json.loads((package/'environment.json').read_text())
args.work.mkdir(parents=True,exist_ok=False)
env=dict(os.environ,GO=args.go,GOTOOLCHAIN='local',GOEXPERIMENT='simd',
         CODEX_AGENT_ID='ci-sse8-rejected-reproduction',GOMAXPROCS='2',GOFLAGS='-p=2',
         CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects')
commands=[]

def run(cmd,log,runenv=None):
    commands.append(cmd)
    with log.open('w') as output:
        output.write(repr(cmd)+'\n');output.flush()
        subprocess.run(cmd,cwd=args.repo,env=runenv or env,stdout=output,stderr=subprocess.STDOUT,check=True)

for name in ('bool-parent','parent','bool','direct','u8square','oldbuild'):
    snapshot=args.work/name;snapshot.mkdir()
    revision=metadata['oldbuild_head'] if name=='oldbuild' else metadata['parent_head']
    archive=subprocess.check_output(['git','archive',revision],cwd=args.repo)
    with tarfile.open(fileobj=io.BytesIO(archive)) as files:files.extractall(snapshot)
    if name in ('bool','direct','u8square'):
        overlay=package/name/'sources'
        for source in overlay.rglob('*'):
            if source.is_file():
                target=snapshot/source.relative_to(overlay);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
    if name=='parent':
        for filename in ('sse8_pointer_rows_test.go','sse8_pointer_fallback_test.go'):
            shutil.copyfile(package/'baselines/parent/internal/vp8/dsp'/filename,snapshot/'internal/vp8/dsp'/filename)
    if name=='oldbuild':
        shutil.copyfile(package/'baselines/oldbuild/internal/vp8/dsp/sse8_rows_native_test.go',snapshot/'internal/vp8/dsp/sse8_rows_native_test.go')
wrapper=str(args.repo/'scripts/go.sh')
for name in ('bool','direct','u8square'):
    for extra,label in (([],'ordinary'),(['-race','-gcflags=all=-d=checkptr=2'],'race-checkptr')):
        run([wrapper,'-C',str(args.work/name),'test','-pgo=off']+extra+
            ['./internal/pixel','./internal/vp8/dsp','-run','TestSSE8|TestSquaredError|TestVariance','-count=1'],
            args.work/(name+'-'+label+'.log'))
    if name!='u8square':
        for extra,label,buildenv in ((['-tags=purego'],'purego',env),([], 'nosimd',dict(env,GOEXPERIMENT='nosimd'))):
            run([wrapper,'-C',str(args.work/name),'test','-pgo=off']+extra+
                ['./internal/pixel','./internal/vp8/dsp','-run','TestSSE8|TestSquaredError|TestVariance','-count=1'],
                args.work/(name+'-'+label+'.log'),buildenv)
run([wrapper,'-C',str(args.work/'parent'),'test','-pgo=off','-gcflags=all=-d=checkptr=2',
     './internal/vp8/dsp','-run','TestSSE8PointerPublic','-count=1'],args.work/'parent-fallback-checkptr.log')
for name in ('bool-parent','parent','bool','direct','u8square','oldbuild'):
    run([wrapper,'-C',str(args.work/name),'test','-pgo=off','-c','-o',str(args.work/(name+'.test')),
         './internal/vp8/dsp'],args.work/(name+'-build.log'))
timing_env=dict(env,GOMAXPROCS='1')
for name in ('bool-parent','parent','bool','direct','u8square','oldbuild'):
    run([str(args.work/(name+'.test')),'-test.run=^$','-test.bench=^BenchmarkSSE8RowsNative$',
         '-test.benchtime=1x','-test.cpu=1','-test.benchmem'],args.work/(name+'-fixture1x.log'),timing_env)
for stage,names in (('bool',('bool-parent','bool','oldbuild')),('direct',('parent','direct','oldbuild'))):
    for name in names:
        run([str(args.work/(name+'.test')),'-test.run=^$',
             '-test.bench=^BenchmarkSSE8RowsNative/pointer8x8/','-test.benchtime=100ms','-test.cpu=1','-test.benchmem'],
            args.work/(stage+'-screen-'+name+'.log'),timing_env)
orders=[('parent','direct','oldbuild','u8square'),('direct','u8square','parent','oldbuild'),
        ('u8square','oldbuild','direct','parent'),('oldbuild','parent','u8square','direct')]
for index,order in enumerate(orders,1):
    for name in order:
        run([str(args.work/(name+'.test')),'-test.run=^$',
             '-test.bench=^BenchmarkSSE8RowsNative/pointer8x8/','-test.benchtime=100ms','-test.cpu=1','-test.benchmem'],
            args.work/('interaction-round%d-%s.log'%(index,name)),timing_env)
(args.work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')

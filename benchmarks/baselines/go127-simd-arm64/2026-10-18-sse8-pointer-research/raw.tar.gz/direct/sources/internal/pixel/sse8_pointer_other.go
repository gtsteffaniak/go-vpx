//go:build !goexperiment.simd || !arm64 || purego

package pixel

import "unsafe"

// SSE8Ptr retains libvpx v1.16.0 vpx_dsp/variance.c through the original path.
func SSE8Ptr(src *byte, ss int, ref *byte, rs int) uint32 {
	return SSE8(unsafe.Slice(src, 7*ss+8), ss, unsafe.Slice(ref, 7*rs+8), rs, 8)
}

#!/bin/sh
set -eu
export CODEX_AGENT_ID=root-h-unroll50 CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go GOEXPERIMENT=simd GOMAXPROCS=2 GOFLAGS=-p=2 CGO_ENABLED=1
r=/Users/thesyncim/GolandProjects/govpx
p=/private/tmp/govpx-next-lf-h-unroll50
for v in parent candidate; do
 "$r/scripts/go.sh" -C "$p/$v" test -pgo=off -overlay="$p/$v-overlay.json" -c -o "$p/$v-dsp.test" ./internal/vp8/dsp > "$p/$v-dsp-build.log" 2>&1
 "$r/scripts/go.sh" -C "$p/$v" test -pgo=off -c -o "$p/$v-decoder.test" ./internal/vp8/decoder > "$p/$v-decoder-build.log" 2>&1
 "$r/scripts/go.sh" -C "$p/$v" build -pgo=off -o "$p/$v-whole-bench" ./cmd/govpx-bench > "$p/$v-cli-build.log" 2>&1
 env GOMAXPROCS=1 GOVPX_REQUIRE_SIMD=1 "$p/$v-dsp.test" -test.run '^$' -test.bench '^BenchmarkLFMacroAxisNative$' -test.benchtime=1x -test.count=1 -test.cpu=1 -test.benchmem > "$p/$v-dsp-preflight.txt" 2>&1
 env GOMAXPROCS=1 GOVPX_REQUIRE_SIMD=1 "$p/$v-decoder.test" -test.run '^$' -test.bench '^BenchmarkVP8PickerFilterNative$' -test.benchtime=1x -test.count=1 -test.cpu=1 -test.benchmem > "$p/$v-decoder-preflight.txt" 2>&1
done
"$r/scripts/go.sh" -C "$p/candidate" test -pgo=off ./internal/pixel ./internal/vp8/dsp ./internal/vp8/decoder > "$p/candidate-full-three.log" 2>&1
"$r/scripts/go.sh" -C "$p/candidate" test -pgo=off -race -gcflags=all=-d=checkptr=2 ./internal/pixel ./internal/vp8/dsp ./internal/vp8/decoder -run '^Test(Macro|LoopFilter|InternalLoopFilter|ApplyLoopFilter)' -count=1 > "$p/candidate-race-checkptr.log" 2>&1

from pathlib import Path
import shutil,subprocess,json,hashlib,platform
r=Path('/private/tmp/govpx-arm-fused-dc-ready');r.mkdir();fresh=Path('/private/tmp/govpx-arm-fused-dc-fresh');initial=Path('/private/tmp/govpx-arm-fused-dc');repair=Path('/private/tmp/govpx-arm-fused-dc-noref');failed=Path('/private/tmp/govpx-arm-fused-dc-inline');root=Path('/Users/thesyncim/GolandProjects/govpx')
for name,src,dirs in [('initial',initial,['drivers','evidence','screen']),('repair',repair,['drivers','evidence','screen']),('failed-inline',failed,['evidence']),('fresh',fresh,['drivers','evidence','fresh-dsp','fresh-whole','profiles600'])]:
 for d in dirs:
  if(src/d).exists():shutil.copytree(src/d,r/name/d)
 for f in ['REPORT.md']:
  if(src/f).exists():shutil.copy2(src/f,r/name/f)
 for p in src.glob('*-dsp.test'):
  q=r/name/'binaries'/p.name;q.parent.mkdir(exist_ok=True);shutil.copy2(p,q)
 for p in src.glob('*-whole-bench'):
  q=r/name/'binaries'/p.name;q.parent.mkdir(exist_ok=True);shutil.copy2(p,q)
for p in [Path('/private/tmp/govpx-arm-fused-dc-noref-prepare.py'),Path('/private/tmp/govpx-arm-fused-dc-fresh-prepare.py'),Path('/private/tmp/govpx-arm-fused-dc-inline-prepare.py')]:shutil.copy2(p,r/p.name)
for v in ['parent','candidate','old691']:
 for p in (fresh/v).rglob('*'):
  if p.is_file()and((p.suffix in ['.go','.s']and not p.name.endswith('_test.go'))or p.name in ['go.mod','go.sum']):
   q=r/'source'/v/p.relative_to(fresh/v);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 for f in ['internal/vp8/dsp/fill_exact_native_test.go','internal/vp8/dsp/fused_dc_supplement_test.go','internal/vp8/dsp/fused_dc_probe_test.go','internal/pixel/intra_dc_fill_probe_test.go']:
  p=fresh/v/f
  if p.exists():q=r/'source'/v/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for name,src in [('initial',initial/'candidate'),('failed-inline',failed/'candidate')]:
 for f in ['internal/pixel/intra_dc_fill_arm64.go','internal/pixel/intra_dc_fill_other.go','internal/vp8/dsp/intra_dispatch_other.go']:
  p=src/f;q=r/'trial-source'/name/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
proof={}
for v,sha in [('parent','46b89f5ab4c6c469755323a61c77fe3a766b4081'),('old691','691cd0512c4829d9ee40d483205dd223f9eb028d')]:
 paths=[p for p in(r/'source'/v).rglob('*')if p.is_file()and p.suffix in ['.go','.s']and not p.name.endswith('_test.go')];entries=[]
 for p in paths:
  rel=str(p.relative_to(r/'source'/v));gitbytes=subprocess.check_output(['git','show',sha+':'+rel],cwd=root);assert gitbytes==p.read_bytes(),(v,rel);entries.append(rel)
 proof[v]={'git_commit':sha,'tree':subprocess.check_output(['git','rev-parse',sha+'^{tree}'],cwd=root,text=True).strip(),'all_production_go_and_assembly_files_exact':True,'checked_paths':entries}
(r/'git-source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
(r/'environment.json').write_text(json.dumps({'platform':platform.platform(),'cpu':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),'hardware_cpu_count':subprocess.check_output(['sysctl','-n','hw.ncpu'],text=True).strip(),'SDK':'official Go1.27.2 darwin-arm64','SDK_path':'/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go','GOEXPERIMENT':'simd','PGO':'off','timing_GOMAXPROCS':1,'build_GOMAXPROCS':2,'GOFLAGS':'-p=2','project_wrapper':str(root/'scripts/go.sh'),'project_cache':'/private/tmp/codex-projects/99feb44aac13f74a/go-build'},indent=2)+'\n')
s=json.loads((fresh/'fresh-dsp/summary.json').read_text());w=json.loads((fresh/'fresh-whole/summary.json').read_text());report='''# ARM fused8/16 DC prediction retention package

Exact strongest baseline PR44 `46b89f5ab4c6c469755323a61c77fe3a766b4081`; old reference `691cd0512c4829d9ee40d483205dd223f9eb028d`, actual NEON assembly. M4 Max, official Go1.27.2 SIMD, PGO off, native GOMAXPROCS=1. No root repository/PR changes. This package contains complete production Go/assembly source for all three fresh variants, source/Git proofs, relevant independent tests, all benchmark/CLI binaries, commands, raw measurements, full LLVM, failed inline trial, and profiles.

Production overlay: exact ARM fused sum/fill helper and other-architecture false stub; ARM constant selects an exact no-reference FillBlock route in existing n8/n16 wrappers. Both available sources are fully read before stores, preserving aliases. Complete positive bounded destination/ref guards precede SIMD writes; failure returns to the original flow, preserving panic diagnostics and partial writes. The no-ref route invokes the exact original FillBlock on every geometry. n4 production caller exists and is unchanged; its public performance controls are explicitly measured here. AMD normalized n4/generic/public-fixture codegen and ARM n4/generic codegen are identical to44. The initial helper112-entry body is unchanged in the final repair.

Correctness: exhaustive24488 available-sum public calls; full backing/alias/unaligned/minimal/short+sparecap/clippedcap/extreme strides and exact original panic/partial-state comparisons; race/checkptr2; purego; SIMD-disabled fallback; all3 fresh27-case one-shot scalar/full-input/output/canary oracles. All486 fresh native component samples0B/0alloc. The identical15-case supplement adds12 one-neighbor cases plus3 actual n4 controls; its full-state alias tests also pass on all3 references with race/checkptr2.

Initial candidate3round3way screen108samples and no-ref repair3round3way screen108samples are preserved separately and never pooled. Initial16none regression motivated the repaired no-ref route. Failed inline-wrapper cost110 exceeded budget80, added a call; no timing run. Repair's additional branch makes initial both-neighbor path a few percent slower but removes none regressions. No production variant beyond this final repair was tested.

Fresh acceptance:27 public B.Loop cases ×6 balanced permutations ×3 variants,100ms,486 samples. Both8 median1.770–1.811×44, both16 median1.590–1.620×44; every both-neighbor paired ratio>1.5. Both also beat old NEON. None and one-neighbor medians improve44; some8one-neighbor paired samples trail oldNEON. n4 controls remain approximatelyflat vs44 and ~3.2×slowerold; unchanged codegen and this gap are disclosed, not attributed as a win.

| Public case |44 ns|candidate ns|oldNEON ns|44/candidate|old/candidate|
|---|---:|---:|---:|---:|---:|
'''
for x in s['cases']:
 m=x['medians_ns'];report+=f"|{x['case'].split('/',1)[1]}|{m['parent']:.4f}|{m['candidate']:.4f}|{m['old691']:.4f}|{x['parent_over_candidate']:.4f}×|{x['old_over_candidate']:.4f}×|\n"
report+='''
All6 paired ratios, including every slower control, are preserved in `fresh/fresh-dsp/summary.json`; all18 raw logs and full commands accompany it.

Whole encoder: fresh six balanced300-input VP8 realtime720p cpu8/30fps/2500kbps/1thread runs for all3. Medians44 7.330647ms, candidate7.3022785ms, old6.901636ms. Candidate−0.386985%vs44 (5/6 faster; paired changes+0.17919,−0.24515,−1.45844,−0.40656,−0.59636,−2.09108%). Candidate remains+5.80504%slowerold (all6 slower; paired+2.78545,+3.45116,+9.02898,+2.91534,+8.21586,+8.61933%). All22 semantic fields and zero allocations match across18 JSONs. This is a retained component win; whole-encoder improvement is small/noisy and the assembly gap remains open.

Separate600-input profiles: all3 same binaries/options with raw pgo,22semantic/zeroalloc equality, flat/cumulative top50 text and commands. They are outside timed pairs and are diagnostic only. Candidate LF fusedV7.11%flat/12.32%cum; fusedH6.87%flat/9.24%cum; pickLFlevel29.15%cum; tokenwrite5.45%flat; memmove4.03%flat. Old's LFvertical12.44%, DCpair8.85%, LFhorizontal4.07%, SSE16dot3.83%flat. Profile percentages are sampling estimates and not comparative timing denominators.

The original frozen FillBlock archives remain unchanged. The new fused helper uses those exact proven stores; no blanket ARM or x64 encoder completion claim is made. All binaries are retained only as private evidence, not intended for repository inclusion.
'''
(r/'REPORT.md').write_text(report)
items=[]
for p in sorted(r.rglob('*')):
 if p.is_file():items.append({'path':str(p.relative_to(r)),'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(r/'MANIFEST.json').write_text(json.dumps(items,indent=2)+'\n')
print(json.dumps({'ready':str(r),'files':len(items),'bytes':sum(x['size']for x in items),'manifest_sha256':hashlib.sha256((r/'MANIFEST.json').read_bytes()).hexdigest()},indent=2))

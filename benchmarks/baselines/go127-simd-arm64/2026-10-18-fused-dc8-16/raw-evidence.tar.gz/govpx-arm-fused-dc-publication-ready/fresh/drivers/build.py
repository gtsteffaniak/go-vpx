from pathlib import Path
import os,subprocess,json,hashlib
r=Path('/private/tmp/govpx-arm-fused-dc-fresh');root=Path('/Users/thesyncim/GolandProjects/govpx');e=os.environ.copy();e.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-fused-dc-fresh',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go');records=[]
for v in ['parent','candidate','old691']:
 for name,args in [('state',['test','-pgo=off','./internal/vp8/dsp','-run','^Test(IntraDCFillExactState|FusedDCSupplementState)$','-count=1','-v']),('state-race-checkptr2',['test','-pgo=off','-race','-gcflags=all=-d=checkptr=2','./internal/vp8/dsp','-run','^Test(IntraDCFillExactState|FusedDCSupplementState)$','-count=1','-v']),('dsp-build',['test','-pgo=off','-c','./internal/vp8/dsp','-o',str(r/(v+'-dsp.test'))]),('whole-build',['build','-pgo=off','-o',str(r/(v+'-whole-bench')),'./cmd/govpx-bench'])]:
  cmd=[str(root/'scripts/go.sh'),'-C',str(r/v)]+args
  with(r/'evidence'/f'{v}-{name}.log').open('w')as f:run=subprocess.run(cmd,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
  records.append({'variant':v,'name':name,'command':cmd,'exit':run.returncode});(r/'evidence/build-validation.json').write_text(json.dumps(records,indent=2)+'\n');assert run.returncode==0,(v,name);print(v,name,'PASS',flush=True)
 e1=e.copy();e1['GOMAXPROCS']='1';cmd=[str(r/(v+'-dsp.test')),'-test.run=^$','-test.bench=^BenchmarkIntraDCFill(Exact|Supplement)$','-test.benchtime=1x','-test.cpu=1','-test.count=1','-test.benchmem']
 with(r/'evidence'/f'{v}-27-public-oneshot.log').open('w')as f:run=subprocess.run(cmd,env=e1,stdout=f,stderr=subprocess.STDOUT)
 assert run.returncode==0,v;records.append({'variant':v,'name':'27-public-oneshot','command':cmd,'exit':run.returncode});(r/'evidence/build-validation.json').write_text(json.dumps(records,indent=2)+'\n');print(v,'all27-public-one-shot PASS',flush=True)
(r/'evidence/binary-hashes.json').write_text(json.dumps({v:{name:hashlib.sha256((r/(v+suffix)).read_bytes()).hexdigest()for name,suffix in [('DSP','-dsp.test'),('CLI','-whole-bench')]}for v in ['parent','candidate','old691']},indent=2)+'\n');print('ALL BUILDS/ORACLES COMPLETE',flush=True)

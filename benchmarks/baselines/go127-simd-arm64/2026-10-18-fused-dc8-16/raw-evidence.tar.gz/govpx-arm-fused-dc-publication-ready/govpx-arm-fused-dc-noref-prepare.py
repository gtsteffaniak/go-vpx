from pathlib import Path
import shutil,subprocess,json,hashlib
r=Path('/private/tmp/govpx-arm-fused-dc-noref'); initial=Path('/private/tmp/govpx-arm-fused-dc');r.mkdir();(r/'evidence').mkdir();(r/'drivers').mkdir();shutil.copytree(initial/'candidate',r/'candidate')
paths=['internal/pixel/intra_dc_fill_arm64.go','internal/pixel/intra_dc_fill_other.go','internal/vp8/dsp/intra_dispatch_other.go']
for suffix,value in [('arm64','true'),('other','false')]:
 p=r/'candidate/internal/pixel'/f'intra_dc_fill_{suffix}.go';s=p.read_text();idx=s.index('func IntraDCFill(');s=s[:idx]+f'const IntraDCFillNative = {value}\n\n'+s[idx:];p.write_text(s)
p=r/'candidate/internal/vp8/dsp/intra_dispatch_other.go';s=p.read_text()
for n in [8,16]:
 old=f'\t\tif pixel.IntraDCFill(dst, dstStride, above, left, {n}, upAvailable, leftAvailable) {{'
 new=f'\t\tif pixel.IntraDCFillNative && !upAvailable && !leftAvailable {{\n\t\t\tpixel.FillBlock(dst, dstStride, {n}, {n}, 128)\n\t\t\treturn\n\t\t}}\n'+old
 assert s.count(old)==1;s=s.replace(old,new)
p.write_text(s)
subprocess.run(['/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/gofmt','-w']+[str(r/'candidate'/x)for x in paths],check=True)
records=[]
for x in paths:
 a=initial/'candidate'/x;b=r/'candidate'/x;records.append({'path':x,'initial_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'repaired_sha256':hashlib.sha256(b.read_bytes()).hexdigest()})
(r/'evidence/scope.json').write_text(json.dumps(records,indent=2)+'\n')
s=(initial/'drivers/validate.py').read_text().replace("r=Path('/private/tmp/govpx-arm-fused-dc')","r=Path('/private/tmp/govpx-arm-fused-dc-noref')").replace("govpx-ci-fused-dc'","govpx-ci-fused-dc-noref'").replace("for v in ['parent','candidate']:","for v in ['candidate']:")
(r/'drivers/validate.py').write_text(s)

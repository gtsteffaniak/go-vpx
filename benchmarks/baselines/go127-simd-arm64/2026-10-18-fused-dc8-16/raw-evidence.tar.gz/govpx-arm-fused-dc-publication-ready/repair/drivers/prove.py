from pathlib import Path
import subprocess,re,json,os,hashlib
r=Path('/private/tmp/govpx-arm-fused-dc-noref');initial=Path('/private/tmp/govpx-arm-fused-dc');root=Path('/Users/thesyncim/GolandProjects/govpx');e=os.environ.copy();e.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-fused-dc-noref-proof',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',GOOS='linux',GOARCH='amd64');cmd=[str(root/'scripts/go.sh'),'-C',str(r/'candidate'),'test','-pgo=off','-c','./internal/vp8/dsp','-o',str(r/'candidate-amd64-dsp.test')]
with (r/'evidence/amd64-build.log').open('w')as f:run=subprocess.run(cmd,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
assert run.returncode==0;(r/'evidence/amd64-build.json').write_text(json.dumps({'command':cmd,'exit':run.returncode,'env':{k:e[k]for k in ['GOOS','GOARCH','GO','GOMAXPROCS','GOFLAGS','GOEXPERIMENT','CODEX_AGENT_ID','GOTOOLCHAIN','CODEX_PROJECT_CACHE_ROOT']}},indent=2)+'\n')
syms=['internal/vp8/dsp.Intra4x4DCPredict','internal/vp8/dsp.intraDCGo','internal/vp8/dsp.BenchmarkIntraDCFillExact.func1','internal/vp8/dsp.intraDCPredict8x8','internal/vp8/dsp.intraDCPredict16x16','internal/pixel.IntraDCFill'];norm={};summaries={}
for arch in ['arm64','amd64']:
 for v,base in [('parent',initial),('initial',initial),('candidate',r)]:
  name='candidate'if v=='initial'else v;binary=base/(name+('-amd64'if arch=='amd64'else'')+'-dsp.test');prefix='_'if arch=='arm64'else'';cmd=['xcrun','llvm-objdump','--disassemble','--demangle','--disassemble-symbols='+','.join(prefix+'github.com/thesyncim/govpx/'+s for s in syms),str(binary)];run=subprocess.run(cmd,capture_output=True,text=True);assert run.returncode==0;(r/'evidence'/f'{arch}-{v}-llvm.txt').write_text(run.stdout+run.stderr);blocks=re.split(r'^[0-9a-f]+ <'+prefix+r'github.com/thesyncim/govpx/([^>]+)>:\n',run.stdout,flags=re.M);norm[arch,v]={};summaries[arch+':'+v]={}
  for i in range(1,len(blocks),2):
   s,body=blocks[i:i+2];pat=r'^\s*[0-9a-f]+:\s+(?:[0-9a-f]{2}\s+)+(.+)$'if arch=='amd64'else r'^[0-9a-f]+:\s+[0-9a-f]+\s+([^\n]+)';ins=re.findall(pat,body,re.M);ins=[re.sub(r'0x[0-9a-fA-F]+','ADDR',x)for x in ins];norm[arch,v][s]=ins;summaries[arch+':'+v][s]={'instructions':len(ins),'calls':[x for x in ins if re.match('bl\s',x)],'vector_stack_stores':[x for x in ins if re.match(r'(str|stur)\s+q',x)and'[sp'in x]}
proof={}
for arch in ['arm64','amd64']:
 for s in syms[:2]+([syms[2]]if arch=='amd64'else[]):
  a,b=norm[arch,'parent'][s],norm[arch,'candidate'][s];assert a==b,(arch,s,[(x,y)for x,y in zip(a,b)if x!=y][:5]);proof[arch+':'+s]={'identical':True,'instructions':len(a),'normalized_sha256':hashlib.sha256('\n'.join(a).encode()).hexdigest()}
s=syms[-1];a,b=norm['arm64','initial'][s],norm['arm64','candidate'][s];assert a==b,(s,len(a),len(b),[(x,y)for x,y in zip(a,b)if x!=y][:5]);proof['initial_helper_body']={'identical':True,'instructions':len(a),'normalized_sha256':hashlib.sha256('\n'.join(a).encode()).hexdigest()}
(r/'evidence/codegen-proof.json').write_text(json.dumps(proof,indent=2)+'\n');(r/'evidence/codegen-summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
e=os.environ.copy();e['GOMAXPROCS']='1';cmd=[str(r/'candidate-dsp.test'),'-test.run=^$','-test.bench=^BenchmarkIntraDCFillExact$','-test.benchtime=1x','-test.cpu=1','-test.count=1','-test.benchmem']
with(r/'evidence/candidate-public-oneshot.log').open('w')as f:run=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT)
assert run.returncode==0;(r/'evidence/oneshot-command.json').write_text(json.dumps({'command':cmd,'exit':run.returncode},indent=2)+'\n');print(json.dumps(proof,indent=2));print('All codegen and twelve public one-shot fixtures PASS')

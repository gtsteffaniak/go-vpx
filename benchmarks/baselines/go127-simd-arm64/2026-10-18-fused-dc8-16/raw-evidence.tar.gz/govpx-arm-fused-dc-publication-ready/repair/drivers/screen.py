from pathlib import Path
import os,subprocess,time,json,hashlib
r=Path('/private/tmp/govpx-arm-fused-dc-noref');initial=Path('/private/tmp/govpx-arm-fused-dc');out=r/'screen';out.mkdir();e=os.environ.copy();e.update(GOMAXPROCS='1',GOVPX_REQUIRE_SIMD='1');records=[];bins={'parent':initial/'parent-dsp.test','initial':initial/'candidate-dsp.test','repaired':r/'candidate-dsp.test'}
# Exactly PR44 versus the frozen first fused helper versus no-ref routing repair.
(r/'evidence/screen-binaries.json').write_text(json.dumps({v:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for v,p in bins.items()},indent=2)+'\n')
for rnd,order in enumerate([['parent','initial','repaired'],['initial','repaired','parent'],['repaired','parent','initial']],1):
 for v in order:
  cmd=[str(bins[v]),'-test.run=^$','-test.bench=^BenchmarkIntraDCFillExact$','-test.benchtime=75ms','-test.cpu=1','-test.count=1','-test.benchmem'];start=time.time()
  with(out/f'r{rnd}-{v}.log').open('w')as f:run=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT)
  records.append({'round':rnd,'variant':v,'command':cmd,'start':start,'end':time.time(),'exit':run.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert run.returncode==0
 print('round',rnd,'complete',flush=True)
print('SCREEN END',flush=True)

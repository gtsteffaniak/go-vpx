# Private ARM fused DC no-reference route repair

Status: provisional three-round screen only; awaiting parent decision before fresh confirmation, whole-encoder timing, or profiling. No root repository/PR changes. Source baseline is exact PR44 `46b89f5ab4c6c469755323a61c77fe3a766b4081`.

The initial fused helper and its 108 first-screen samples remain unchanged at `/private/tmp/govpx-arm-fused-dc`. The failed eligibility-wrapper inline experiment remains separately at `/private/tmp/govpx-arm-fused-dc-inline`; Go reported cost110 above budget80, so no performance measurement was run for that extra-call variant.

This repair adds an architecture constant and routes only ARM n8/n16 no-reference calls directly to `pixel.FillBlock(...,128)` before the existing fused helper call. This is exactly the original no-reference `intraDCGo` operation, including invalid geometry, partial-write/panic, slice capacity, and alias behavior. The initial sum/round/store helper body remains unchanged. Other architectures compile the routing condition away. n4 dispatch and generic `intraDCGo` remain unchanged.

Nine focused correctness/build commands passed, including exhaustive attainable sums, complete backing/canaries, aliases, minimal and short windows with spare/clipped capacity, extreme strides, exact panic diagnostics/partial outputs, selected backend, race/checkptr2, purego, and experiment-disabled fallback. All12 public live B.Loop one-shot cases also passed.

Optimized codegen proof: ARM n4 (42 entries) and generic DC (92) match exact44 after address normalization. AMD n4 (74), generic DC (95), and public fixture closure (568) match exact44. The repaired ARM fused helper matches the initial 112-entry body exactly after address normalization. Full LLVM output and proof JSON are in evidence/.

Native screen: Apple M4 Max, official Go1.27.2 SIMD, PGO off, GOMAXPROCS=1, 75ms, three cyclic orders of exact44 / initial / repaired. All108 samples report zero B/op and allocs/op and pass independent complete-output/canary oracles. Full raw logs, commands, binary hashes, per-pair ratios, and medians are in screen/ and evidence/. These are not acceptance results and are not pooled with the separate first-screen old691 window.

Both-neighbor repaired medians improve1.573–1.620× (16x16) and1.769–1.822× (8x8) over exact44, every paired ratio remains above1.5. None medians improve1.029–1.046× (16x16) and1.152–1.189× (8x8), repairing the original16x16 none regression. The extra no-ref branch makes both-neighbor cases approximately3.7–8.5% slower than the initial fused candidate, disclosed in every paired ratio. No old691 timing was rerun in this repair window.

Future plan, only after approval: fresh six balanced exact44/repaired/old691 public component rounds; six balanced300-input whole runs with22 semantic fields and allocation equality; separate untimed600-input profiles on the same three exact source/binary variants, official SDK and PGO off. The remaining whole-encoder gap against old assembly is open.

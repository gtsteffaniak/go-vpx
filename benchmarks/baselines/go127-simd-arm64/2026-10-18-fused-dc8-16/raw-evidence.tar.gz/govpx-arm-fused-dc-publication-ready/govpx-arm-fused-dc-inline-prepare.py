from pathlib import Path
import shutil,json,hashlib
r=Path('/private/tmp/govpx-arm-fused-dc-inline');r.mkdir();(r/'drivers').mkdir();(r/'evidence').mkdir();original=Path('/private/tmp/govpx-arm-fused-dc/candidate');shutil.copytree(original,r/'candidate')
f=r/'candidate/internal/pixel/intra_dc_fill_arm64.go';s=f.read_text();signature='func IntraDCFill(dst []byte, ds int, above, left []byte, n int, up, lf bool) bool {';assert s.count(signature)==1;start=s.index(signature);body=s[start+len(signature):];guard_end=body.index('\n\tvalue := byte(128)');guard=body[:guard_end];work=body[guard_end:];assert work.endswith('\n\treturn true\n}\n');work=work.removesuffix('\n\treturn true\n}\n')
s=s[:start]+signature+guard+'\n\tintraDCFillUnchecked(dst, ds, above, left, n, up, lf)\n\treturn true\n}\n\nfunc intraDCFillUnchecked(dst []byte, ds int, above, left []byte, n int, up, lf bool) {'+work+'\n}\n';f.write_text(s)
(r/'evidence/scope.json').write_text(json.dumps({'base_initial_source_sha256':hashlib.sha256((original/'internal/pixel/intra_dc_fill_arm64.go').read_bytes()).hexdigest(),'single_repair':'exported eligibility function calls private void unchecked worker; no math/store/guard changes'},indent=2)+'\n')
print(r)

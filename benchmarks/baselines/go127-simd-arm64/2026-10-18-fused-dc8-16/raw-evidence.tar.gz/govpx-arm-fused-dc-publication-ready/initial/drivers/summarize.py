from pathlib import Path
import re,json,statistics
r=Path('/private/tmp/govpx-arm-fused-dc');groups={};pairs={};samples=[]
for p in sorted((r/'screen').glob('r*-*.log')):
 rnd=int(p.stem.split('-')[0][1:]);v=p.stem.split('-',1)[1];s=p.read_text();assert re.search(r'^PASS$',s,re.M),p
 rows=re.findall(r'^(Benchmark\S+)\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',s,re.M);assert len(rows)==12,(p,len(rows))
 for case,it,ns,byte,alloc in rows:
  assert byte==alloc=='0'and float(ns)>0;assert (v,case,rnd)not in pairs;pairs[v,case,rnd]=float(ns);groups.setdefault((v,case),[]).append(float(ns));samples.append({'round':rnd,'variant':v,'case':case,'ns':float(ns),'iterations':int(it),'B/op':0,'allocs/op':0,'log':p.name})
assert len(samples)==108
out=[]
for case in sorted({s['case']for s in samples}):
 med={v:statistics.median(groups[v,case])for v in ['parent','candidate','old691']};pr=[pairs['parent',case,i]/pairs['candidate',case,i]for i in range(1,4)];orr=[pairs['old691',case,i]/pairs['candidate',case,i]for i in range(1,4)];item={'case':case,'medians_ns':med,'parent_over_candidate':med['parent']/med['candidate'],'old_over_candidate':med['old691']/med['candidate'],'all3paired_parent_ratios':pr,'all3paired_old_ratios':orr,'candidate_faster_pairs':sum(x>1for x in pr)};out.append(item)
(r/'screen/summary.json').write_text(json.dumps({'hardware':'Apple M4 Max','SDK':'officialGo1.27.2SIMD','PGO':'off','GOMAXPROCS':1,'benchtime':'75ms','rounds':3,'orders':['parent candidate old691','candidate old691 parent','old691 parent candidate'],'cases':out,'samples':samples,'all_zero_alloc':True},indent=2)+'\n')
for x in out:
 m=x['medians_ns'];pr=x['all3paired_parent_ratios'];orr=x['all3paired_old_ratios'];print(x['case'].split('Exact/')[1],f"parent={m['parent']:.4f} new={m['candidate']:.4f} old={m['old691']:.4f} ns; parent/new={x['parent_over_candidate']:.4f}x pairs {min(pr):.4f}..{max(pr):.4f}; old/new={x['old_over_candidate']:.4f}x pairs {min(orr):.4f}..{max(orr):.4f}")

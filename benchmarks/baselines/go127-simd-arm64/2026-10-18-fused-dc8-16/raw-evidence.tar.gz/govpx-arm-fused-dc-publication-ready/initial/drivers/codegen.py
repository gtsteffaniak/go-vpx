from pathlib import Path
import subprocess,json,re,hashlib
r=Path('/private/tmp/govpx-arm-fused-dc');summaries={};bodies={};commands=[]
for v in ['parent','candidate']:
 syms=['internal/vp8/dsp.intraDCPredict8x8','internal/vp8/dsp.intraDCPredict16x16','internal/vp8/dsp.intraDCGo','internal/vp8/dsp.Intra4x4DCPredict']
 if v=='candidate':syms+=['internal/pixel.IntraDCFill']
 cmd=['xcrun','llvm-objdump','--disassemble','--demangle','--disassemble-symbols='+','.join('_github.com/thesyncim/govpx/'+s for s in syms),str(r/(v+'-dsp.test'))];run=subprocess.run(cmd,capture_output=True,text=True);assert run.returncode==0;(r/'evidence'/f'{v}-dc-llvm.txt').write_text(run.stdout+run.stderr);commands.append(cmd)
 blocks=re.split(r'^[0-9a-f]+ <_github.com/thesyncim/govpx/([^>]+)>:\n',run.stdout,flags=re.M);summaries[v]={};bodies[v]={}
 for i in range(1,len(blocks),2):
  name,body=blocks[i:i+2];ins=re.findall(r'^[0-9a-f]+:\s+[0-9a-f]+\s+([^\n]+)',body,re.M);norm=[re.sub(r'0x[0-9a-f]+','ADDR',x)for x in ins];bodies[v][name]=norm;summaries[v][name]={'instructions':len(ins),'calls':[x for x in norm if re.match(r'bl\s',x)],'sdiv':sum(bool(re.match(r'sdiv\s',x))for x in ins),'addv':sum('addv' in x for x in ins),'vector_stack_stores':len(re.findall(r'\b(?:str|stur)\s+q\d+, \[sp',body)),'stack_store_instructions':[x for x in norm if re.match(r'(?:stp|str|stur)\s',x)and'[sp'in x]}
proof={}
for name in ['internal/vp8/dsp.Intra4x4DCPredict','internal/vp8/dsp.intraDCGo']:
 a,b=bodies['parent'][name],bodies['candidate'][name];proof[name]={'normalized_codegen_identical':a==b,'instructions_parent_candidate':[len(a),len(b)],'normalized_sha256':hashlib.sha256('\n'.join(a).encode()).hexdigest()};assert a==b,(name,a,b)
(r/'evidence/codegen-summary.json').write_text(json.dumps(summaries,indent=2)+'\n');(r/'evidence/n4-codegen-proof.json').write_text(json.dumps(proof,indent=2)+'\n');(r/'evidence/codegen-commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(summaries,indent=2));print('n4+generic original codegen identical')

from pathlib import Path
import io,tarfile,subprocess,json,hashlib,os
r=Path('/private/tmp/govpx-arm-fused-dc');root=Path('/Users/thesyncim/GolandProjects/govpx');old=r/'old691';old.mkdir();sha='691cd0512c4829d9ee40d483205dd223f9eb028d'
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',sha],cwd=root)))as t:t.extractall(old)
f='internal/vp8/dsp/fill_exact_native_test.go';(old/f).write_bytes((r/'parent'/f).read_bytes());assert (r/'candidate'/f).read_bytes()==(r/'parent'/f).read_bytes()
e=os.environ.copy();e.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-fused-dc-reference',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go');records=[]
for v,extra,dest in [('parent',{'GOARCH':'amd64','GOOS':'linux'},'parent-amd64-dsp.test'),('candidate',{'GOARCH':'amd64','GOOS':'linux'},'candidate-amd64-dsp.test'),('old691',{},'old691-dsp.test')]:
 env=e.copy();env.update(extra);cmd=[str(root/'scripts/go.sh'),'-C',str(r/v),'test','-pgo=off','-c','./internal/vp8/dsp','-o',str(r/dest)]
 with (r/'evidence'/f'{v}-reference-build.log').open('w')as f:run=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append({'variant':v,'command':cmd,'env_overrides':extra,'exit':run.returncode});assert run.returncode==0,v;print(v,'built',flush=True)
(r/'evidence/reference-build.json').write_text(json.dumps(records,indent=2)+'\n');(r/'evidence/public-fixture-hashes.json').write_text(json.dumps({v:hashlib.sha256((r/v/'internal/vp8/dsp/fill_exact_native_test.go').read_bytes()).hexdigest()for v in ['parent','candidate','old691']},indent=2)+'\n')

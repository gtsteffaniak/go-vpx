from pathlib import Path
import subprocess,re,json,os,hashlib
r=Path('/private/tmp/govpx-arm-fused-dc');syms=['internal/vp8/dsp.Intra4x4DCPredict','internal/vp8/dsp.intraDCGo','internal/vp8/dsp.BenchmarkIntraDCFillExact.func1'];norms={};commands=[]
for v in ['parent','candidate']:
 cmd=['xcrun','llvm-objdump','--disassemble','--demangle','--disassemble-symbols='+','.join('github.com/thesyncim/govpx/'+s for s in syms),str(r/(v+'-amd64-dsp.test'))];run=subprocess.run(cmd,capture_output=True,text=True);assert run.returncode==0;(r/'evidence'/f'{v}-amd64-dc-llvm.txt').write_text(run.stdout+run.stderr);commands.append(cmd)
 blocks=re.split(r'^[0-9a-f]+ <github.com/thesyncim/govpx/([^>]+)>:\n',run.stdout,flags=re.M);norms[v]={}
 for i in range(1,len(blocks),2):
  name,body=blocks[i:i+2];ins=re.findall(r'^\s*[0-9a-f]+:\s+(.+)$',body,re.M);norms[v][name]=[re.sub(r'0x[0-9a-f]+','ADDR',s)for s in ins]
proof={}
for name in syms:
 assert name in norms['parent']and name in norms['candidate'],name
 a,b=norms['parent'][name],norms['candidate'][name];proof[name]={'normalized_codegen_identical':a==b,'instruction_counts':[len(a),len(b)],'normalized_sha256':hashlib.sha256('\n'.join(a).encode()).hexdigest()};assert a==b,(name,a,b)
(r/'evidence/amd64-false-stub-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print('AMD public fixture, n4 and genericDC codegen identical')
e=os.environ.copy();e['GOMAXPROCS']='1';runs=[]
for v in ['parent','candidate','old691']:
 cmd=[str(r/(v+'-dsp.test')),'-test.run=^$','-test.bench=^BenchmarkIntraDCFillExact$','-test.benchtime=1x','-test.cpu=1','-test.count=1','-test.benchmem']
 with (r/'evidence'/f'{v}-public-oneshot.log').open('w')as f:run=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT)
 runs.append({'variant':v,'command':cmd,'exit':run.returncode});assert run.returncode==0
(r/'evidence/oneshot-commands.json').write_text(json.dumps(runs,indent=2)+'\n');print('all12public fixtures parent/current44/candidate/oldNEON scalar outputs passed')

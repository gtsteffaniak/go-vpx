from pathlib import Path
import os,subprocess,time,json
r=Path('/private/tmp/govpx-arm-fused-dc');out=r/'screen';out.mkdir();e=os.environ.copy();e.update(GOMAXPROCS='1',GOVPX_REQUIRE_SIMD='1');records=[]
for rnd,order in enumerate([['parent','candidate','old691'],['candidate','old691','parent'],['old691','parent','candidate']],1):
 for v in order:
  cmd=[str(r/(v+'-dsp.test')),'-test.run=^$','-test.bench=^BenchmarkIntraDCFillExact$','-test.benchtime=75ms','-test.cpu=1','-test.count=1','-test.benchmem'];start=time.time()
  with (out/f'r{rnd}-{v}.log').open('w')as f:run=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT)
  records.append({'round':rnd,'variant':v,'command':cmd,'start':start,'end':time.time(),'exit':run.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert run.returncode==0
 print('round',rnd,'complete',flush=True)
print('SCREEN END',flush=True)

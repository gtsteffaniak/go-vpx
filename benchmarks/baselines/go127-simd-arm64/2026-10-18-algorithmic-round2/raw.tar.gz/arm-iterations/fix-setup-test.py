exec(open('/private/tmp/govpx-iterations100/prepare.py').read().split('# 51:')[0])
for p in [base]+[p for p in D.glob('[0-9][0-9]-*') if p.is_dir()]:
 f=p/'vp8_algorithm_round2_test.go';s=f.read_text();a,b,body=function(s,'TestVP8Algorithm2BlockSetup');old='if regular{vp8enc.InitRegularBlockQuant(40,da,&a);frozen2InitRegularBlockQuant(40,db,&b)}else{vp8enc.InitFastBlockQuant(da,&a);frozen2InitFastBlockQuant(db,&b)};if a!=b';new='''var pa,pb any
 func(){defer func(){pa=recover()}();if regular{vp8enc.InitRegularBlockQuant(40,da,&a)}else{vp8enc.InitFastBlockQuant(da,&a)}}()
 func(){defer func(){pb=recover()}();if regular{frozen2InitRegularBlockQuant(40,db,&b)}else{frozen2InitFastBlockQuant(db,&b)}}()
 if (pa==nil)!=(pb==nil)||a!=b''';assert old in body;f.write_text(s[:a]+body.replace(old,new)+s[b:])

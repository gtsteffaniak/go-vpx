exec(open('/private/tmp/govpx-iterations100/prepare.py').read().split('# 51:')[0])
I='vp8_encoder_intra_pick.go';Q='internal/vp8/encoder/quant.go'
#58 Reconstruct the winning RD candidate once, after all ten scores.
p=variant(58,'keyrd-reconstruct-winner');s=(p/I).read_text();a,b,body=function(s,'predictBestBPredLumaModeRDWithRDConstantsAndEOBs');body=body.replace('var bestRecon [16]byte','var bestPred [16]byte\n var bestDQ [16]int16');start=body.index('\t\t\t\tvar candidateRecon');end=body.index('\n\t\t\t\tbestEOB',start);body=body[:start]+'''bestMode = candidate
                bestPred = candidatePred
                bestDQ = dqcoeff'''+body[end:];body=body.replace('\t\tvp8enc.CopyBPredBlock(bestRecon[:], y, pred.YStride, block)','''var bestRecon [16]byte
        if bestEOB > 1 { dsp.IDCT4x4Add(&bestDQ,bestPred[:],4,bestRecon[:],4) } else { dsp.DCOnlyIDCT4x4Add(bestDQ[0],bestPred[:],4,bestRecon[:],4) }
        vp8enc.CopyBPredBlock(bestRecon[:],y,pred.YStride,block)''');put(p,I,s[:a]+body+s[b:])
#59/60 The batch DCT scratch already holds each contiguous block.
for n,name,fn,index in [(59,'yrd-reuse-dct-storage','wholeBlockYTransformRDWithEOBs','block'),(60,'uvrd-reuse-dct-storage','wholeBlockChromaTransformRDWithEOBs','slot')]:
 p=variant(n,name);s=(p/I).read_text();a,b,body=function(s,fn);body=body.replace('\tvar dct [16]int16\n','',1).replace('\t\tvar dct [16]int16\n','',1);body=body.replace(f'copy(dct[:], dcts[{index}*16:{index}*16+16])',f'dct := (*[16]int16)(dcts[{index}*16:{index}*16+16])').replace('&dct,','dct,');put(p,I,s[:a]+body+s[b:])
#61 Four selected indices need dequantization, not all128 indices.
p=variant(61,'segments-selected-q');s=(p/Q).read_text();s=s.replace('\tcommon.BuildFrameDequantTables(deltas, &tables)\n','');needle='\t\tcommon.InitMacroblockDequant(&tables, qIndex, &dequant)';new='''q:=common.ClampQIndex(qIndex)
        tables.Y1[q]=[2]int16{int16(common.DCQuant(q,deltas.Y1DC)),int16(common.ACYQuant(q))}
        tables.Y2[q]=[2]int16{int16(common.DC2Quant(q,deltas.Y2DC)),int16(common.AC2Quant(q,deltas.Y2AC))}
        tables.UV[q]=[2]int16{int16(common.DCUVQuant(q,deltas.UVDC)),int16(common.ACUVQuant(q,deltas.UVAC))}
'''+needle;assert needle in s;s=s.replace(needle,new);put(p,Q,s)
#62 The four default segments share exactly the same quantizer.
p=variant(62,'segments-reuse-same-q');s=(p/Q).read_text();s=s.replace('\tfor segment := range common.MaxMBSegments {','\tvar previousQ [common.MaxMBSegments]int\n\tfor segment := range common.MaxMBSegments {',1);needle='\t\tcommon.InitMacroblockDequant(&tables, qIndex, &dequant)';new='''q:=common.ClampQIndex(qIndex)
        previousQ[segment]=q
        reused:=false
        for prior:=0;prior<segment;prior++ {if previousQ[prior]==q {out[segment]=out[prior];reused=true;break}}
        if reused {continue}
'''+needle;assert needle in s;s=s.replace(needle,new);put(p,Q,s)
#63 RD token and above/left mode contexts do not change between candidates.
p=variant(63,'keyrd-reuse-context');s=(p/I).read_text();a,b,body=function(s,'predictBestBPredLumaModeRDWithRDConstantsAndEOBs');lines=['tokenCtx := int(tokenAbove[block&3] + tokenLeft[(block&0x0c)>>2])','aboveMode := bPredAnalysisAboveMode(keyFrame, above, modes, block)','leftMode := bPredAnalysisLeftMode(keyFrame, left, modes, block)'];
for line in lines:body=body.replace('\t\t\t'+line+'\n','')
body=body.replace('\t\tfor i, candidate := range bPredIntraModeCandidates {','\n'.join('\t\t'+x for x in lines)+'\n\t\tfor i, candidate := range bPredIntraModeCandidates {');put(p,I,s[:a]+body+s[b:])
#64/65 Write reconstructed winners directly to their final strided destination.
for n,name,file,fn,stride in [(64,'keyfast-direct-reconstruction',I,'pickFastBPredLumaModeKFWithRDConstants','pred.YStride'),(65,'bpred-direct-reconstruction','vp8_encoder_inter_modes_fast_helpers.go','estimateFastBPredIntraModeScore','yStride')]:
 p=variant(n,name);s=(p/file).read_text();a,b,body=function(s,fn);body=body.replace('var recon [16]byte',f'recon:=y[((block&12)>>2)*4*{stride}+(block&3)*4:]');body=body.replace('recon[:], 4)',f'recon, {stride})');body=body.replace(f'\n\t\tvp8enc.CopyBPredBlock(recon[:], y, {stride}, block)','');put(p,file,s[:a]+body+s[b:])
#66/67 EOB0 is the unchanged predictor: avoid DC IDCT arithmetic.
for n,name,file,fn,stride in [(66,'keyfast-zero-reconstruction',I,'pickFastBPredLumaModeKFWithRDConstants','pred.YStride'),(67,'bpred-zero-reconstruction','vp8_encoder_inter_modes_fast_helpers.go','estimateFastBPredIntraModeScore','yStride')]:
 p=variant(n,name);s=(p/file).read_text();a,b,body=function(s,fn);body=body.replace('if eob > 1 {','if eob == 0 { recon = bestPred } else if eob > 1 {',1);put(p,file,s[:a]+body+s[b:])
# Extend independent fixtures to batch RD and setup, copied identically to all sides.
fixture=(base/'vp8_algorithm_round2_test.go').read_text()
for fn in ['wholeBlockYTransformRDWithEOBs','wholeBlockChromaTransformRDWithEOBs']:
 _,_,body=function((base/I).read_text(),fn);fixture+='\n'+body.replace(fn,'frozen2'+fn,1)+'\n'
fixture=fixture.replace('case "keyrd":','''case "yrd":
  var eob uint8; var coeff [16]int16
  if old {out[0],out[1],eob,coeff,out[2]=frozen2wholeBlockYTransformRDWithEOBs(src,&e.analysis.Img,row,col,0,0,nil,nil,q,&e.coefProbs,true,nil)} else {out[0],out[1],eob,coeff,out[2]=wholeBlockYTransformRDWithEOBs(src,&e.analysis.Img,row,col,0,0,nil,nil,q,&e.coefProbs,true,nil)}
  out[3]=int(eob);for i,v:=range coeff {out[4]+=int(v)*(i+1)}
 case "uvrd":
  if old {out[0],out[1],out[2]=frozen2wholeBlockChromaTransformRDWithEOBs(src,&e.analysis.Img,row,col,0,0,nil,nil,q,&e.coefProbs,true,nil)} else {out[0],out[1],out[2]=wholeBlockChromaTransformRDWithEOBs(src,&e.analysis.Img,row,col,0,0,nil,nil,q,&e.coefProbs,true,nil)}
 case "keyrd":''').replace('"keyfast","keyrd"','"keyfast","keyrd","yrd","uvrd"')
# Segment quant oracle frozen high level, independent lookup/setup calls.
_,_,body=function((base/Q).read_text(),'InitSegmentMacroblockQuants');body=body.replace('InitSegmentMacroblockQuants','frozen2SegmentQuants',1).replace('common.','vp8common.').replace('SegmentationConfig','vp8enc.SegmentationConfig').replace('MacroblockQuant','vp8enc.MacroblockQuant').replace('ErrInvalidPacketConfig','vp8enc.ErrInvalidPacketConfig').replace('validvp8enc.SegmentationConfig','validSegmentationConfig').replace('!validSegmentationConfig(segmentation)','false').replace('InitRegularMacroblockQuant','vp8enc.InitRegularMacroblockQuant')
# Correct names after type substitution.
body=body.replace('InitRegularvp8enc.MacroblockQuant','vp8enc.InitRegularMacroblockQuant')
fixture+='\n'+body+'\n'+'''var round2QuantSink [4]vp8enc.MacroblockQuant
func TestVP8Algorithm2SegmentSetup(t *testing.T){for q:=0;q<128;q++ {var a,b [4]vp8enc.MacroblockQuant;d:=vp8common.QuantDeltas{Y1DC:-3,Y2DC:2,Y2AC:4,UVDC:1,UVAC:-2};s:=vp8enc.SegmentationConfig{};if q&1!=0{s.Enabled=true;s.FeatureEnabled[vp8common.MBLvlAltQ]=[4]bool{true,true,true,true};s.FeatureData[vp8common.MBLvlAltQ]=[4]int8{-10,0,10,20}}
 if err:=vp8enc.InitSegmentMacroblockQuants(q,d,s,&a);err!=nil{t.Fatal(err)};if err:=frozen2SegmentQuants(q,d,s,&b);err!=nil{t.Fatal(err)};if a!=b{t.Fatalf("q%d mismatch",q)}}}
func BenchmarkVP8Algorithm2SegmentSetup(b *testing.B){for b.Loop(){if err:=vp8enc.InitSegmentMacroblockQuants(40,vp8common.QuantDeltas{},vp8enc.SegmentationConfig{},&round2QuantSink);err!=nil{b.Fatal(err)}}}
'''
for p in [base]+[p for p in D.glob('[0-9][0-9]-*') if p.is_dir()]:put(p,'vp8_algorithm_round2_test.go',fixture)
print('prepared58–67')

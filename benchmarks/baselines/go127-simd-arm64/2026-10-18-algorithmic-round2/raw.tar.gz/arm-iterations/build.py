from pathlib import Path
import os,subprocess,hashlib,json,sys
D=Path('/private/tmp/govpx-iterations100');R=Path('/Users/thesyncim/GolandProjects/govpx')
env=os.environ|{'CODEX_AGENT_ID':'root-round2','CODEX_PROJECT_CACHE_ROOT':'/private/tmp/codex-projects','GOTOOLCHAIN':'local','GO':'/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go','GOEXPERIMENT':'simd','GOMAXPROCS':'2','GOFLAGS':'-p=2','CGO_ENABLED':'1'}
for name in sys.argv[1:] or ['base']+[p.name for p in sorted(D.glob('[0-9][0-9]-*')) if p.is_dir()]:
 p=D/name;log=D/(name+'-build.log');binary=D/(name+'.test')
 with log.open('w') as f:
  cmd=[str(R/'scripts/go.sh'),'-C',str(p),'test','-c','-pgo=off','-o',str(binary),'.']
  f.write(repr(cmd)+'\n');f.flush();r=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
  if r.returncode==0:r=subprocess.run([str(binary),'-test.run=^TestVP8Algorithm2','-test.count=1','-test.v'],cwd=p,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,'PASS' if r.returncode==0 else 'FAIL',flush=True)
 if r.returncode:print(log.read_text()[-3500:],flush=True)
 else:(D/(name+'-binding.json')).write_text(json.dumps({'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'sources':{str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*.go')}},indent=2))

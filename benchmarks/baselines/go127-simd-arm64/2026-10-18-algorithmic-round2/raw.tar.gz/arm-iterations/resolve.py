exec(open('/private/tmp/govpx-iterations100/prepare.py').read().split('# 51:')[0])
p=D/'integrated';f='vp8_encoder_inter_modes_fast_helpers.go';s=(p/f).read_text();s=re.sub(r'<<<<<<<[^\n]*\n.*?>>>>>>>[^\n]*\n','\t\t\tmodeRate := modeCosts[j]\n\t\t\tmodeSum, modeDist := vp8enc.BPredBlockStats(src, mbRow, mbCol, block, blockPred[:], 4)\n',s,flags=re.S);put(p,f,s)
f='vp8_encoder_analysis_reconstruct.go';s=(base/f).read_text();_,_,helper=function((D/'55-bpred-reuse-block-edges'/f).read_text(),'analysisBPredEdges');_,_,chroma=function((D/'70-chroma-reuse-predictor-edges'/f).read_text(),'predictAnalysisChromaWithRefs');put(p,f,s+'\n'+helper+'\n'+chroma+'\n')
f='vp8_encoder_intra_pick.go';s=(p/f).read_text();s=re.sub(r'<<<<<<<[^\n]*\n.*?>>>>>>>[^\n]*\n','\t\tif !vp8dec.PredictIntraY16x16(yMode,pred.Y[yOff:],pred.YStride,refs.YAbove,refs.YLeft,refs.YTopLeft,refs.UpAvailable,refs.LeftAvailable) {\n',s,flags=re.S);needle='refs:=vp8dec.BuildIntraPredictorRefs(pred,mbRow,mbCol,&scratch.Refs)\n\tfor i, yMode';assert needle in s;s=s.replace(needle,'refs:=vp8dec.BuildIntraPredictorRefsLuma(pred,mbRow,mbCol,&scratch.Refs)\n yOff:=mbRow*16*pred.YStride+mbCol*16\n\tfor i, yMode');put(p,f,s)
f='internal/vp8/encoder/quant.go';s=(D/'62-segments-reuse-same-q'/f).read_text().replace('\tcommon.BuildFrameDequantTables(deltas, &tables)\n','');needle='\t\tcommon.InitMacroblockDequant(&tables, qIndex, &dequant)';s=s.replace(needle,'''tables.Y1[q]=[2]int16{int16(common.DCQuant(q,deltas.Y1DC)),int16(common.ACYQuant(q))}
        tables.Y2[q]=[2]int16{int16(common.DC2Quant(q,deltas.Y2DC)),int16(common.AC2Quant(q,deltas.Y2AC))}
        tables.UV[q]=[2]int16{int16(common.DCUVQuant(q,deltas.UVDC)),int16(common.ACUVQuant(q,deltas.UVAC))}
'''+needle);put(p,f,s)
changed=[str(f) for f in p.rglob('*.go') if not(base/f.relative_to(p)).exists() or f.read_bytes()!=(base/f.relative_to(p)).read_bytes()]
subprocess.run(['/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/gofmt','-w']+changed,check=True)
print('resolved/formatted',len(changed))

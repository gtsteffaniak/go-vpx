exec(open('/private/tmp/govpx-iterations100/prepare.py').read().split('# 51:')[0])
f='''package govpx
import("testing";"fmt";"crypto/sha256";"encoding/binary")
// TestVP8Algorithm2Stream pins packets and frame flags to the immutable b57 baseline.
func TestVP8Algorithm2Stream(t *testing.T){for _,sz:=range [][2]int{{48,48},{65,49},{160,90}}{for _,tune:=range []Tuning{TunePSNR,TuneSSIM}{t.Run(fmt.Sprintf("%dx%d/tune%d",sz[0],sz[1],tune),func(t *testing.T){e:=newSizedTestEncoder(t,sz[0],sz[1]);e.opts.Tuning=tune;dst:=make([]byte,sz[0]*sz[1]*6+4096);h:=sha256.New();var length [8]byte
 for frame:=0;frame<16;frame++{img:=testImage(sz[0],sz[1]);for y:=0;y<sz[1];y++{for x:=0;x<sz[0];x++{v:=byte((x*7+y*11+frame*13)^(x*y+frame*19));if frame<4{v=byte(96+frame)};img.Y[y*img.YStride+x]=v}};for i:=range img.U{img.U[i]=byte(i*13+frame*7);img.V[i]=byte(i*29+frame*11)}
 r,err:=e.EncodeInto(dst,img,uint64(frame),1,0);if err!=nil{t.Fatal(err)};binary.LittleEndian.PutUint64(length[:],uint64(len(r.Data)));h.Write(length[:]);h.Write(r.Data);fmt.Fprintf(h,"%t,%t,%t,%d|",r.KeyFrame,r.Dropped,r.Droppable,r.LookaheadDepth)}
 got:=fmt.Sprintf("%x",h.Sum(nil));t.Logf("vp8_stream_sha256=%s",got)
 })}}}
'''
for p in [base,D/'integrated']:put(p,'vp8_algorithm_stream_round2_test.go',f)
# Copy only retained production changes; leave all losing overlays in the ledger.
for f in (D/'integrated').rglob('*.go'):
 rel=f.relative_to(D/'integrated');before=base/rel
 if rel.name=='vp8_algorithm_stream_round2_test.go' or (before.exists() and f.read_bytes()==before.read_bytes()):continue
 shutil.copy2(f,R/rel)
shutil.copy2(D/'integrated/vp8_algorithm_round2_test.go',R/'vp8_algorithm_round2_test.go')
print('copied retained production and fixture')

from pathlib import Path
import subprocess,os,re,statistics,json,sys
D=Path('/private/tmp/govpx-iterations100');env=os.environ|{'GOMAXPROCS':'1'}
kinds={51:'activity-edge',52:'activity-inner',53:'bpred',54:'bpred',55:'bpred',56:'keyfast',57:'keyrd',58:'keyrd',59:'yrd',60:'uvrd',61:'SegmentSetup',62:'SegmentSetup',63:'keyrd',64:'keyfast',65:'bpred',66:'keyfast',67:'bpred',68:'whole',69:'whole',70:'chroma',71:'activity-edge',72:'keyfast',73:'keyrd',74:'BlockSetup/fast',75:'BlockSetup/regular'}
def rows(s):
 r={}
 for l in s.splitlines():
  m=re.match(r'(Benchmark\S+)\s+\d+\s+(\S+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',l)
  if m:r[m[1]]={'ns':float(m[2]),'bytes':int(m[3]),'allocs':int(m[4])}
 assert r,s
 return r
summary={}
for p in sorted(D.glob('[0-9][0-9]-*')):
 if not p.is_dir():continue
 n=int(p.name[:2]);kind=kinds[n];regex='^BenchmarkVP8Algorithm2'+(kind if kind.startswith(('Segment','Block')) else '/'+kind) +'($|/)'
 if sys.argv[1:] and str(n) not in sys.argv[1:]:continue
 if 'PASS' not in (D/(p.name+'-build.log')).read_text() or 'FAIL' in (D/(p.name+'-build.log')).read_text():print(n,'reject-build-or-correctness',flush=True);continue
 samples={'base':[],'candidate':[]}
 for rnd,order in enumerate([['base','candidate'],['candidate','base']],1):
  for name in order:
   binary=D/(('base' if name=='base' else p.name)+'.test');out=D/(f'{n}-r{rnd}-{name}.txt');cmd=[str(binary),'-test.run=^$','-test.bench='+regex,'-test.benchtime=60ms','-test.cpu=1','-test.count=1','-test.benchmem'];r=subprocess.run(cmd,cwd=p,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);out.write_text(repr(cmd)+'\n'+r.stdout);assert r.returncode==0,out;samples[name].append(rows(r.stdout))
 cases={}
 assert set(samples['base'][0])==set(samples['candidate'][0])
 for case in samples['base'][0]:
  ratios=[samples['base'][i][case]['ns']/samples['candidate'][i][case]['ns'] for i in range(2)]
  cases[case]={'speedup_pairs':ratios,'median_speedup':statistics.median(ratios),'samples':{k:[x[case] for x in v] for k,v in samples.items()}}
 summary[str(n)]={'name':p.name,'preliminary':True,'cases':cases};print(n,{k:round(v['median_speedup'],3) for k,v in cases.items()},flush=True)
 (D/'arm-summary.json').write_text(json.dumps(summary,indent=2)+'\n')

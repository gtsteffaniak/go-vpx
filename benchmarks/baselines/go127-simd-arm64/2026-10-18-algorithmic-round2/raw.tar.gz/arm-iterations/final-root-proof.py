exec(open('/private/tmp/govpx-iterations100/build.py').read().split('for name in sys.argv')[0])
f=R/'vp8_algorithm_round2_test.go';s=f.read_text().replace('out[4]+=int(v)*(i+1)','out[4+i/4] |= int(uint64(uint16(v))<<uint((i%4)*16))');s=s.replace('package govpx','// Frozen b57aac772af29e85f4b5b34ae33600cc84cd6a0f entrypoints are exact-state\n// oracles for the algorithmic work-elision paths. Benchmarks call the live\n// production entrypoints with identical fixtures on both revisions.\npackage govpx',1)
s+='''
func TestVP8Algorithm2ClampedEdges(t *testing.T){for _,kind:=range []string{"activity-edge","activity-inner","bpred","keyfast","keyrd","yrd","uvrd","whole","chroma"}{for _,rc:=range [][2]int{{0,2},{2,0},{2,2}}{a,src,q:=round2Inputs(t,2);b,_,_:=round2Inputs(t,2);src.Width=43;src.Height=41;x,m:=round2Call(a,src,&q,kind,false,rc[0],rc[1]);y,n:=round2Call(b,src,&q,kind,true,rc[0],rc[1]);if x!=y||m!=n||!reflect.DeepEqual(a.analysis.Img.YFull,b.analysis.Img.YFull)||!reflect.DeepEqual(a.analysis.Img.UFull,b.analysis.Img.UFull)||!reflect.DeepEqual(a.analysis.Img.VFull,b.analysis.Img.VFull){t.Fatalf("%s @%v got%v/%v want%v/%v",kind,rc,x,m,y,n)}}}}
'''
f.write_text(s)
# Production docs explain why the retained loops may share inputs.
f=R/'vp8_encoder_intra_pick.go';s=f.read_text().replace('//  3. Reconstruction: dsp.IDCT4x4Add is invoked inside the winning branch\n//     and the resulting bestRecon is written via vp8enc.CopyBPredBlock at the end\n//     of each block iteration, equivalent to libvpx\'s deferred','//  3. Reconstruction: retain the winning predictor/dequantized coefficients,\n//     then reconstruct it once after scoring all candidates, matching libvpx\'s deferred');s=s.replace('refs := vp8dec.BuildIntraPredictorRefsLuma(pred, mbRow, mbCol, &scratch.Refs)\n\tyOff', '// Candidate writes stay inside this macroblock; its neighbor edges are fixed.\n\trefs := vp8dec.BuildIntraPredictorRefsLuma(pred, mbRow, mbCol, &scratch.Refs)\n\tyOff');f.write_text(s)
f=R/'internal/vp8/dsp/variance.go';s=f.read_text().replace('func PixelStats4x4','// PixelStats4x4 returns the signed residual sum and its sum of squares.\nfunc PixelStats4x4');f.write_text(s)
f=R/'internal/vp8/encoder/bpred_block.go';s=f.read_text().replace('func BPredBlockStats','// BPredBlockStats preserves the selected predictor statistics for macroblock variance.\nfunc BPredBlockStats');f.write_text(s)
files=[str(R/x) for x in ['vp8_algorithm_round2_test.go','vp8_algorithm_stream_round2_test.go','vp8_encoder_intra_pick.go','internal/vp8/dsp/variance.go','internal/vp8/encoder/bpred_block.go']]
subprocess.run(['/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/gofmt','-w']+files,check=True)
selector='^Test(VP8Algorithm2|MLCacheStreamNative|PredictBestBPred|PickFastBPred|PredictBestWholeBlockIntra|EstimateFastBPred|SelectFastInterFrameModeDecisionCanChooseInterleavedIntra|EncodeInto(BPred|KeyFrameSelectsBPred|InterFrameCanChooseBPred))'
cmd=[str(R/'scripts/go.sh'),'test','-pgo=off','.', '-run',selector,'-count=1','-v']
with (D/'root-retained-tests.log').open('w') as log:r=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
print('root focused tests',r.returncode,flush=True)
if r.returncode:print((D/'root-retained-tests.log').read_text()[-6000:]);raise SystemExit(r.returncode)
for name,source in [('b57',D/'base'),('root',R)]:
 cmd=[str(R/'scripts/go.sh'),'-C',str(source),'build','-pgo=off','-o',str(D/(name+'-whole')),'./cmd/govpx-bench']
 with (D/(name+'-whole-build.log')).open('w') as log:r=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(name,'whole build',r.returncode,flush=True)
 if r.returncode:raise RuntimeError((D/(name+'-whole-build.log')).read_text())

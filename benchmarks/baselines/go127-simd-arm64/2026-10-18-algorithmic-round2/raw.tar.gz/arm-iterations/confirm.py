exec(open('/private/tmp/govpx-iterations100/time.py').read().split('summary={}')[0])
samples={'base':[],'integrated':[]}
for rnd,order in enumerate([['base','integrated'],['integrated','base']],1):
 for name in order:
  cmd=[str(D/(name+'.test')),'-test.run=^$','-test.bench=^BenchmarkVP8Algorithm2($|SegmentSetup$)','-test.benchtime=60ms','-test.cpu=1','-test.count=1','-test.benchmem'];r=subprocess.run(cmd,cwd=D,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(D/f'composition-r{rnd}-{name}.txt').write_text(repr(cmd)+'\n'+r.stdout);assert r.returncode==0,r.stdout;samples[name].append(rows(r.stdout))
summary={}
for case in samples['base'][0]:
 ratios=[samples['base'][i][case]['ns']/samples['integrated'][i][case]['ns'] for i in range(2)];summary[case]={'speedup_pairs':ratios,'median_speedup':statistics.median(ratios),'samples':{k:[r[case] for r in v] for k,v in samples.items()}}
(D/'arm-composition.json').write_text(json.dumps(summary,indent=2)+'\n');print({k:round(v['median_speedup'],3) for k,v in summary.items()},flush=True)

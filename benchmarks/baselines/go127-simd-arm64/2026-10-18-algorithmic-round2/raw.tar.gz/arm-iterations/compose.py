exec(open('/private/tmp/govpx-iterations100/prepare.py').read().split('# 51:')[0])
accepted=[51]+list(range(53,66))+[68,69,70]
p=D/'integrated';shutil.copytree(base,p,dirs_exist_ok=True)
conflicts=[]
for n in accepted:
 v=next(v for v in D.glob(f'{n}-*') if v.is_dir())
 for f in v.rglob('*.go'):
  rel=f.relative_to(v)
  if rel.name=='vp8_algorithm_round2_test.go':continue
  baseline=base/rel;current=p/rel
  data=f.read_bytes();before=baseline.read_bytes() if baseline.exists() else b''
  if data==before:continue
  if not current.exists():current.parent.mkdir(parents=True,exist_ok=True);current.write_bytes(data);continue
  if current.read_bytes()==data:continue
  if current.read_bytes()==before:current.write_bytes(data);continue
  r=subprocess.run(['git','merge-file','-p',str(current),str(baseline),str(f)],capture_output=True)
  current.write_bytes(r.stdout)
  if r.returncode:conflicts.append((n,str(rel)));print('CONFLICT',n,rel,flush=True)
print('composition prepared',accepted,conflicts)

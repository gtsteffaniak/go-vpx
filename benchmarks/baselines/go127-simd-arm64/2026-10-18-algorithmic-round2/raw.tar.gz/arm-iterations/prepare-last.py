exec(open('/private/tmp/govpx-iterations100/prepare.py').read().split('# 51:')[0])
I='vp8_encoder_intra_pick.go';A='vp8_encoder_analysis_reconstruct.go';Q='internal/vp8/encoder/quant.go'
whole='predictBestWholeBlockIntraModeRDWithProbsAndRDConstants';chroma='predictBestIntraChromaModeRDWithProbsAndRDConstantsAndEOBs'
#68 Y mode scoring does not consume chroma predictors; UV picker overwrites them.
p=variant(68,'whole-y-only-prediction');s=(p/I).read_text();a,b,body=function(s,whole);old='''mode := vp8dec.MacroblockMode{RefFrame: vp8common.IntraFrame, Mode: yMode, UVMode: vp8common.DCPred}
		if !predictAnalysisMacroblock(pred, mbRow, mbCol, &mode, scratch)''';new='''refs:=vp8dec.BuildIntraPredictorRefsLuma(pred,mbRow,mbCol,&scratch.Refs)
        yOff:=mbRow*16*pred.YStride+mbCol*16
        if !vp8dec.PredictIntraY16x16(yMode,pred.Y[yOff:],pred.YStride,refs.YAbove,refs.YLeft,refs.YTopLeft,refs.UpAvailable,refs.LeftAvailable)''';assert old in body;body=body.replace(old,new);put(p,I,s[:a]+body+s[b:])
#69 Reuse immutable whole-MB reference edges for four complete predictors.
p=variant(69,'whole-reuse-predictor-edges');s=(p/I).read_text();a,b,body=function(s,whole);body=body.replace('\tfor i, yMode := range wholeBlockIntraYModeCandidates {','\trefs:=vp8dec.BuildIntraPredictorRefs(pred,mbRow,mbCol,&scratch.Refs)\n\tfor i, yMode := range wholeBlockIntraYModeCandidates {').replace('predictAnalysisMacroblock(pred, mbRow, mbCol, &mode, scratch)','predictAnalysisMacroblockWithRefs(pred,mbRow,mbCol,&mode,refs)');put(p,I,s[:a]+body+s[b:]);s=(p/A).read_text();_,_,body=function(s,'predictAnalysisMacroblock');body=body.replace('func predictAnalysisMacroblock(','func predictAnalysisMacroblockWithRefs(').replace('scratch *vp8dec.IntraReconstructionScratch','refs vp8dec.IntraPredictorRefs').replace('\trefs := vp8dec.BuildIntraPredictorRefs(img, row, col, &scratch.Refs)\n','');put(p,A,s+'\n'+body+'\n')
#70 Chroma candidates also share fixed above/left edges.
p=variant(70,'chroma-reuse-predictor-edges');s=(p/I).read_text();a,b,body=function(s,chroma);body=body.replace('\tfor i, uvMode := range wholeBlockIntraUVModeCandidates {','\trefs:=vp8dec.BuildIntraPredictorRefs(pred,mbRow,mbCol,&scratch.Refs)\n\tfor i, uvMode := range wholeBlockIntraUVModeCandidates {').replace('predictAnalysisChroma(pred, mbRow, mbCol, uvMode, scratch)','predictAnalysisChromaWithRefs(pred,mbRow,mbCol,uvMode,refs)');put(p,I,s[:a]+body+s[b:]);s=(p/A).read_text();_,_,body=function(s,'predictAnalysisChroma');body=body.replace('func predictAnalysisChroma(','func predictAnalysisChromaWithRefs(').replace('scratch *vp8dec.IntraReconstructionScratch','refs vp8dec.IntraPredictorRefs').replace('\trefs := vp8dec.BuildIntraPredictorRefs(img, row, col, &scratch.Refs)\n','');put(p,A,s+'\n'+body+'\n')
#71–73 BPred consumers only use luma edges; do not gather U/V.
for n,name,file,fn in [(71,'bpred-luma-only-edges','vp8_encoder_inter_modes_fast_helpers.go','estimateFastBPredIntraModeScore'),(72,'keyfast-luma-only-edges',I,'pickFastBPredLumaModeKFWithRDConstants'),(73,'keyrd-luma-only-edges',I,'predictBestBPredLumaModeRDWithRDConstantsAndEOBs')]:
 p=variant(n,name);s=(p/file).read_text();a,b,body=function(s,fn);body=body.replace('vp8dec.BuildIntraPredictorRefs(','vp8dec.BuildIntraPredictorRefsLuma(');put(p,file,s[:a]+body+s[b:])
#74 Equal dequants reuse division results while retaining input read/store order.
p=variant(74,'fast-quant-setup-reuse');s=(p/Q).read_text();a,b,body=function(s,'InitFastBlockQuant');body=body.replace('\tfor i := range 16 {','\tlastD,lastFast,lastRound:=0,int16(0),int16(0)\n\tfor i := range 16 {',1).replace('\t\tout.QuantFast[i] = int16((1 << 16) / d)\n\t\tout.Round[i] = int16((quantRoundFactor * d) >> 7)','''if i==0 || d!=lastD {lastFast=int16((1<<16)/d);lastRound=int16((quantRoundFactor*d)>>7);lastD=d}
        out.QuantFast[i]=lastFast
        out.Round[i]=lastRound''');put(p,Q,s[:a]+body+s[b:])
#75 Equal dequants reuse regular reciprocal inversion, not just fast setup.
p=variant(75,'regular-quant-setup-reuse');s=(p/Q).read_text();a,b,body=function(s,'InitRegularBlockQuant');body=body.replace('\tfor i := range 16 {','\tlastD:=0\n var lastQuant,lastShift int16\n\tfor i := range 16 {',1).replace('\t\tinvertRegularQuant(d, &out.Quant[i], &out.QuantShift[i])','''if i==0 || d!=lastD {invertRegularQuant(d,&lastQuant,&lastShift);lastD=d}
        out.Quant[i]=lastQuant
        out.QuantShift[i]=lastShift''');put(p,Q,s[:a]+body+s[b:])
# Add frozen high-level entrypoints and branch cases to the shared comparator.
f=(base/'vp8_algorithm_round2_test.go').read_text()
for fn in [whole,chroma]:
 _,_,body=function((base/I).read_text(),fn);f+='\n'+body.replace(fn,'frozen2'+fn,1)+'\n'
f=f.replace('case "yrd":','''case "whole":
  var scratch vp8dec.IntraReconstructionScratch;var ym,uv vp8common.MBPredictionMode;var ok bool
  if old {ym,uv,out[0],out[1],out[2],out[3],ok=frozen2predictBestWholeBlockIntraModeRDWithProbsAndRDConstants(src,40,0,0,true,row,col,nil,nil,q,&e.analysis.Img,&scratch,&e.coefProbs,nil,nil,true,128,1)}else{ym,uv,out[0],out[1],out[2],out[3],ok=predictBestWholeBlockIntraModeRDWithProbsAndRDConstants(src,40,0,0,true,row,col,nil,nil,q,&e.analysis.Img,&scratch,&e.coefProbs,nil,nil,true,128,1)};out[4]=int(ym);out[5]=int(uv);if ok{out[7]=1}
 case "chroma":
  var scratch vp8dec.IntraReconstructionScratch;var uv vp8common.MBPredictionMode;var ok bool
  if old{uv,out[0],out[1],out[2],ok=frozen2predictBestIntraChromaModeRDWithProbsAndRDConstantsAndEOBs(src,40,0,0,true,row,col,nil,nil,q,&e.analysis.Img,&scratch,&e.coefProbs,nil,true,128,1,nil)}else{uv,out[0],out[1],out[2],ok=predictBestIntraChromaModeRDWithProbsAndRDConstantsAndEOBs(src,40,0,0,true,row,col,nil,nil,q,&e.analysis.Img,&scratch,&e.coefProbs,nil,true,128,1,nil)};out[4]=int(uv);if ok{out[7]=1}
 case "yrd":''').replace('"keyrd","yrd","uvrd"','"keyrd","yrd","uvrd","whole","chroma"')
# The frozen segment oracle must also freeze setup callees for74/75.
for name in ['InitFastBlockQuant','InitRegularBlockQuant','InitRegularMacroblockQuant','invertRegularQuant']:
 _,_,body=function((base/Q).read_text(),name)
 body=body.replace('common.','vp8common.').replace('*BlockQuant','*vp8enc.BlockQuant').replace('*MacroblockQuant','*vp8enc.MacroblockQuant').replace('quantRoundFactor','48').replace('quantZbinBoost','round2ZbinBoost').replace('bits.Len','bits.Len')
 for sub in ['InitFastBlockQuant','InitRegularBlockQuant','InitRegularMacroblockQuant','invertRegularQuant']:body=body.replace(sub,'frozen2'+sub)
 f+='\n'+body+'\n'
f=f.replace('vp8enc.InitRegularMacroblockQuant(qIndex, &dequant, &out[segment])','frozen2InitRegularMacroblockQuant(qIndex, &dequant, &out[segment])').replace('import("testing"','import("math/bits";"testing"')
f+='\nvar round2ZbinBoost=[16]int{0,0,8,10,12,14,16,20,24,28,32,36,40,44,44,44}\n'
for p in [base]+[p for p in D.glob('[0-9][0-9]-*') if p.is_dir()]:put(p,'vp8_algorithm_round2_test.go',f)
print('prepared68–75')

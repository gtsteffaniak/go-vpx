from pathlib import Path
D=Path('/private/tmp/govpx-iterations100');extra='''
func TestVP8Algorithm2BlockSetup(t *testing.T){for pattern:=0;pattern<4;pattern++ {var d [16]int16;for i:=range d{switch pattern{case 0:d[i]=100;case 1:d[i]=int16(i+1);case 2:d[i]=int16(32767-i);case 3:d[i]=int16(10+i%3)}};for _,regular:=range []bool{false,true}{for _,alias:=range []int{0,1,2,3}{var a,b vp8enc.BlockQuant;a.Dequant=d;a.Round=d;a.QuantFast=d;b=a;da,db:=&d,&d;switch alias{case 1:da=&a.Dequant;db=&b.Dequant;case 2:da=&a.Round;db=&b.Round;case 3:da=&a.QuantFast;db=&b.QuantFast};if regular{vp8enc.InitRegularBlockQuant(40,da,&a);frozen2InitRegularBlockQuant(40,db,&b)}else{vp8enc.InitFastBlockQuant(da,&a);frozen2InitFastBlockQuant(db,&b)};if a!=b{t.Fatalf("pattern%d regular%v alias%d",pattern,regular,alias)}}}}}
var round2BlockSink vp8enc.BlockQuant
func BenchmarkVP8Algorithm2BlockSetup(b *testing.B){var d [16]int16;for i:=range d{d[i]=100};d[0]=30;for _,kind:=range []string{"fast","regular"}{b.Run(kind,func(b *testing.B){for b.Loop(){if kind=="fast"{vp8enc.InitFastBlockQuant(&d,&round2BlockSink)}else{vp8enc.InitRegularBlockQuant(40,&d,&round2BlockSink)}}})}}
'''
for p in [D/'base']+[p for p in D.glob('[0-9][0-9]-*') if p.is_dir()]:
 f=p/'vp8_algorithm_round2_test.go';f.write_text(f.read_text()+extra)

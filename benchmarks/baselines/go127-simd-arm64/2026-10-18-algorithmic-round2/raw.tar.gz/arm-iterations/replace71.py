exec(open('/private/tmp/govpx-iterations100/prepare.py').read().split('# 51:')[0])
p=D/'71-bpred-luma-only-edges';f='vp8_encoder_inter_modes_fast_helpers.go';put(p,f,(base/f).read_text());T='vp8_encoder_tuning.go';s=(base/T).read_text();s=s.replace('\t\tvar tokens vp8dec.MacroblockTokens\n\t\tvp8enc.ConvertMacroblockCoefficients(&coeffs, false, &tokens)\n','');s=s.replace('\t\t_ = reconstructAnalysisMacroblock(img, mbRow, mbCol, &mode, &tokens, &dequant, &e.reconstructScratch)','''if !predictAnalysisMacroblock(img,mbRow,mbCol,&mode,&e.reconstructScratch) {return vp8ActivityAvgMin}
        uOff:=mbRow*8*img.UStride+mbCol*8
        vOff:=mbRow*8*img.VStride+mbCol*8
        vp8dec.DequantIDCTAddMacroblockCoefficients(&coeffs.QCoeff,&coeffs.EOB,&dequant,false,y,img.YStride,img.U[uOff:],img.UStride,img.V[vOff:],img.VStride)''');put(p,T,s)

from pathlib import Path
import subprocess,shutil,re,json
R=Path('/Users/thesyncim/GolandProjects/govpx');D=Path('/private/tmp/govpx-iterations100');base=D/'base'
if not base.exists():
 for f in subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0'):
  if not f or f.startswith(('benchmarks/baselines/','internal/coracle/build/')):continue
  p=base/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/f,p)
 (D/'baseline.json').write_text(json.dumps({'batch_base':'b57aac772af29e85f4b5b34ae33600cc84cd6a0f','full_gate_baseline':'c4a8bd9f66805fc9b7b4f99e26752cc68505e572','Go':'1.27.2','host':'Apple M4 Max/Darwin arm64','PGO':'off','CGO':1,'GOMAXPROCS':1},indent=2)+'\n')
def function(s,name):
 m=re.search(r'^func (?:\([^\n]*\) )?'+re.escape(name)+r'\(',s,re.M);assert m,name
 clean=re.sub(r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|`[^`]*`',lambda x:' '*len(x[0]),s,flags=re.S)
 a=clean.index('{',m.start());n=1;b=a+1
 while n:
  if clean[b]=='{':n+=1
  elif clean[b]=='}':n-=1
  b+=1
 return m.start(),b,s[m.start():b]
def variant(n,name):
 p=D/f'{n:02d}-{name}';shutil.copytree(base,p,dirs_exist_ok=True);return p
def put(p,f,s):(p/f).write_text(s)
T='vp8_encoder_tuning.go';F='vp8_encoder_inter_modes_fast_helpers.go';A='vp8_encoder_analysis_reconstruct.go';I='vp8_encoder_intra_pick.go'
# 51: only one quantizer index is used by this activity reconstruction.
p=variant(51,'activity-one-q');s=(p/T).read_text();old='vp8common.BuildFrameDequantTables(quantDeltas, &dequantTables)\n\t\tvp8common.InitMacroblockDequant(&dequantTables, qIndex, &dequant)';new='''q := vp8common.ClampQIndex(qIndex)
        dequantTables.Y1[q] = [2]int16{int16(vp8common.DCQuant(q,quantDeltas.Y1DC)), int16(vp8common.ACYQuant(q))}
        dequantTables.Y2[q] = [2]int16{int16(vp8common.DC2Quant(q,quantDeltas.Y2DC)), int16(vp8common.AC2Quant(q,quantDeltas.Y2AC))}
        dequantTables.UV[q] = [2]int16{int16(vp8common.DCUVQuant(q,quantDeltas.UVDC)), int16(vp8common.ACUVQuant(q,quantDeltas.UVAC))}
        vp8common.InitMacroblockDequant(&dequantTables,qIndex,&dequant)''';assert old in s;s=s.replace(old,new);put(p,T,s)
# 52: input residuals are already required by the transform; reuse their squares.
p=variant(52,'activity-reuse-residual-sse');s=(p/T).read_text();s=s.replace('\t\t\tsse += vp8enc.BPredBlockSSE(src, mbRow, mbCol, block, y[blockOffset:], img.YStride)\n','');needle='vp8enc.ForwardDCT4x4(input[:], 4, &dct)';s=s.replace(needle,'for _,v := range input { sse += int(v)*int(v) }\n\t\t\t'+needle,1);put(p,T,s)
# 53: frame probability row and mode set are invariant across all16 blocks.
p=variant(53,'bpred-reuse-mode-costs');s=(p/F).read_text();a,b,body=function(s,'estimateFastBPredIntraModeScore');body=body.replace('\tquantY1 := &quant.Y1','''var modeCosts [4]int
    for j,bMode := range fastBPredIntraModeCandidates { modeCosts[j]=libvpxInterFastBpredModeCostWithProbs(bMode,e.modeProbs.BMode[:]) }
    quantY1 := &quant.Y1''');body=body.replace('for _, bMode := range fastBPredIntraModeCandidates','for j, bMode := range fastBPredIntraModeCandidates').replace('modeRate := libvpxInterFastBpredModeCostWithProbs(bMode, e.modeProbs.BMode[:])','modeRate := modeCosts[j]');put(p,F,s[:a]+body+s[b:])
# 54: the4x4 stats kernel already computes sum and SSE. Keep the selected sums,
#     eliminating the full predictor copy and the final256-pixel rescan.
p=variant(54,'bpred-reuse-selected-stats');f='internal/vp8/dsp/variance.go';s=(p/f).read_text();s+='\nfunc PixelStats4x4(src []byte,ss int,ref []byte,rs int)(int,int){ return varianceBlock(src,ss,ref,rs,4,4) }\n';put(p,f,s)
f='internal/vp8/encoder/bpred_block.go';s=(p/f).read_text();a,b,body=function(s,'BPredBlockSSE');body=body.replace('func BPredBlockSSE','func BPredBlockStats').replace(') int {',') (int,int) {',1).replace('return dsp.SSE4x4(', 'return dsp.PixelStats4x4(').replace('\tsse := 0','\tsum,sse := 0,0').replace('\t\t\tsse += diff * diff','\t\t\tsum += diff\n\t\t\tsse += diff * diff').replace('\treturn sse','\treturn sum,sse');s+='\n'+body+'\n';put(p,f,s)
s=(p/F).read_text();a,b,body=function(s,'estimateFastBPredIntraModeScore');body=body.replace('\tvar predictor [256]byte','\tpredictorSum := 0').replace('\t\tbestDist := 0','\t\tbestDist := 0\n bestSum := 0').replace('modeDist := vp8enc.BPredBlockSSE(', 'modeSum, modeDist := vp8enc.BPredBlockStats(').replace('\t\t\t\tbestDist = modeDist','\t\t\t\tbestDist = modeDist\n bestSum = modeSum').replace('\t\tvp8enc.CopyBPredBlock(bestPred[:], predictor[:], 16, block)','\t\tpredictorSum += bestSum').replace('variance, sse := macroblockLumaVarianceSSEFromPredictor(src, mbRow, mbCol, &predictor)','sse := distortion\n variance := sse - ((predictorSum*predictorSum)>>8)');put(p,F,s[:a]+body+s[b:])
# 55–57: resolve one block's immutable predictor edges once, then use all modes.
g=(base/A).read_text();a,b,body=function(g,'predictAnalysisBPredBlock');h=body[:body.index('\n\treturn dsp.Intra4x4Predict')];h=h.replace('func predictAnalysisBPredBlock(mode vp8common.BPredictionMode, dst []byte, stride int, ','func analysisBPredEdges(').replace(') bool {',') ([8]byte,[4]byte,byte) {',1);h+='\nreturn blockAbove,blockLeft,blockTopLeft\n}\n'
for n,name,file,fn,modevar,outvar,stride in [(55,'bpred-reuse-block-edges',F,'estimateFastBPredIntraModeScore','bMode','blockPred','yStride'),(56,'keyfast-reuse-block-edges',I,'pickFastBPredLumaModeKFWithRDConstants','candidate','blockPred','pred.YStride'),(57,'keyrd-reuse-block-edges',I,'predictBestBPredLumaModeRDWithRDConstantsAndEOBs','candidate','candidatePred','pred.YStride')]:
 p=variant(n,name);put(p,A,(p/A).read_text()+'\n'+h);s=(p/file).read_text();a,b,body=function(s,fn);needle='\tfor block := range 16 {';body=body.replace(needle,needle+f'\n blockAbove,blockLeft,blockTopLeft:=analysisBPredEdges(y,{stride},refs.YAbove,refs.YLeft,refs.YTopLeft,block)',1) if n!=55 else body.replace(needle,needle+'\n blockAbove,blockLeft,blockTopLeft:=analysisBPredEdges(y,yStride,refsYAbove,refsYLeft,refsYTopLeft,block)',1)
 old=f'predictAnalysisBPredBlock({modevar}, {outvar}[:], 4, y, {stride}, '+('refsYAbove, refsYLeft, refsYTopLeft' if n==55 else 'refs.YAbove, refs.YLeft, refs.YTopLeft')+', block)';assert old in body,(n,old);body=body.replace(old,f'dsp.Intra4x4Predict({outvar}[:],4,{modevar},blockAbove[:],blockLeft[:],blockTopLeft)');put(p,file,s[:a]+body+s[b:])
# Frozen original entrypoints form independent, exact-state comparators.
heads='''package govpx
import("testing";"reflect";"fmt";vp8common "github.com/thesyncim/govpx/internal/vp8/common";vp8dec "github.com/thesyncim/govpx/internal/vp8/decoder";vp8enc "github.com/thesyncim/govpx/internal/vp8/encoder";vp8tables "github.com/thesyncim/govpx/internal/vp8/tables";"github.com/thesyncim/govpx/internal/vp8/dsp")
'''
frozen=''
for file,names in [(T,['ssimActivityMeasure']),(F,['estimateFastBPredIntraModeScore']),(I,['pickFastBPredLumaModeKFWithRDConstants','predictBestBPredLumaModeRDWithRDConstantsAndEOBs'])]:
 for name in names:
  _,_,body=function((base/file).read_text(),name);frozen+=body.replace(name,'frozen2'+name,1)+'\n'
fixture='''
func round2Inputs(tb testing.TB,pattern int)(*VP8Encoder,vp8enc.SourceImage,vp8enc.MacroblockQuant){
 e:=newSizedTestEncoder(tb,48,48);img:=testImage(48,48)
 for i:=range img.Y {if pattern==0{img.Y[i]=128}else{img.Y[i]=byte(i*37+pattern*19)}}
 for i:=range img.U {img.U[i]=byte(i*13+pattern*7);img.V[i]=byte(i*29+pattern*3)}
 for i:=range e.analysis.Img.YFull {e.analysis.Img.YFull[i]=byte(i*23+pattern*31)}
 for i:=range e.analysis.Img.UFull {e.analysis.Img.UFull[i]=byte(i*17+pattern*7);e.analysis.Img.VFull[i]=byte(i*31+pattern*3)}
 var qt [4]vp8enc.MacroblockQuant;if err:=vp8enc.InitSegmentMacroblockQuants(40,vp8common.QuantDeltas{},vp8enc.SegmentationConfig{},&qt);err!=nil{tb.Fatal(err)}
 return e,sourceImageFromPublic(img),qt[0]
}
func round2Call(e *VP8Encoder,src vp8enc.SourceImage,q *vp8enc.MacroblockQuant,kind string,old bool,row,col int)(out [8]int,mode vp8enc.InterFrameMacroblockMode){
 switch kind {
 case "activity-edge","activity-inner":
  if old{out[0]=int(e.frozen2ssimActivityMeasure(src,row,col,40,0,0,q,true,false,128,1))}else{out[0]=int(e.ssimActivityMeasure(src,row,col,40,0,0,q,true,false,128,1))}
 case "bpred":
  var ctx fastInterModeLoopContext;var ok bool
  if old{mode,out[0],out[1],out[2],out[3],ok=e.frozen2estimateFastBPredIntraModeScore(src,row,col,40,maxInt(),q,&ctx)}else{mode,out[0],out[1],out[2],out[3],ok=e.estimateFastBPredIntraModeScore(src,row,col,40,maxInt(),q,&ctx)};if ok{out[7]=1}
 case "keyfast":
  var scratch vp8dec.IntraReconstructionScratch;var modes [16]vp8common.BPredictionMode;var ok bool
  if old{modes,out[0],out[1],ok= frozen2pickFastBPredLumaModeKFWithRDConstants(src,40,0,row,col,nil,nil,q,&e.analysis.Img,&scratch,true,128,1)}else{modes,out[0],out[1],ok=pickFastBPredLumaModeKFWithRDConstants(src,40,0,row,col,nil,nil,q,&e.analysis.Img,&scratch,true,128,1)};mode.BModes=modes;if ok{out[7]=1}
 case "keyrd":
  var scratch vp8dec.IntraReconstructionScratch;var modes [16]vp8common.BPredictionMode;var ok bool
  if old{modes,out[0],out[1],out[2],ok=frozen2predictBestBPredLumaModeRDWithRDConstantsAndEOBs(src,40,0,0,true,row,col,nil,nil,nil,nil,q,&e.analysis.Img,&scratch,maxInt(),&e.coefProbs,nil,true,128,1,nil)}else{modes,out[0],out[1],out[2],ok=predictBestBPredLumaModeRDWithRDConstantsAndEOBs(src,40,0,0,true,row,col,nil,nil,nil,nil,q,&e.analysis.Img,&scratch,maxInt(),&e.coefProbs,nil,true,128,1,nil)};mode.BModes=modes;if ok{out[7]=1}
 }
 return
}
func TestVP8Algorithm2(t *testing.T){for pat:=0;pat<3;pat++{for _,kind:=range []string{"activity-edge","activity-inner","bpred","keyfast","keyrd"}{for _,rc:=range [][2]int{{0,0},{0,1},{1,0},{1,1},{2,2}}{
 if kind=="activity-edge" && rc[0]==rc[1]{continue};if kind=="activity-inner" && rc[0]!=rc[1]{continue}
 a,src,q:=round2Inputs(t,pat);b,_,_:=round2Inputs(t,pat);x,m:=round2Call(a,src,&q,kind,false,rc[0],rc[1]);y,n:=round2Call(b,src,&q,kind,true,rc[0],rc[1]);
 if x!=y||m!=n||!reflect.DeepEqual(a.analysis.Img.YFull,b.analysis.Img.YFull)||!reflect.DeepEqual(a.analysis.Img.UFull,b.analysis.Img.UFull)||!reflect.DeepEqual(a.analysis.Img.VFull,b.analysis.Img.VFull){t.Fatalf("%s pat%d @%v got%v/%v want%v/%v",kind,pat,rc,x,m,y,n)}
 }}}}
var round2Sink [8]int
func BenchmarkVP8Algorithm2(b *testing.B){for _,kind:=range []string{"activity-edge","activity-inner","bpred","keyfast","keyrd"}{for _,pat:=range []int{0,1}{b.Run(fmt.Sprintf("%s/p%d",kind,pat),func(b *testing.B){e,src,q:=round2Inputs(b,pat);row,col:=1,1;if kind=="activity-edge"{row=0};b.ReportAllocs();for b.Loop(){round2Sink,_=round2Call(e,src,&q,kind,false,row,col)}})}}}
'''
text=heads+frozen+fixture
for p in [base]+[p for p in D.glob('[0-9][0-9]-*') if p.is_dir()]:put(p,'vp8_algorithm_round2_test.go',text)
print('Prepared51–57')

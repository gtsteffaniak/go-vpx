from pathlib import Path
import os,json,subprocess,statistics
D=Path('/private/tmp/govpx-iterations100');O=D/'whole-final';env=os.environ|{'GOMAXPROCS':'1'}
args=['-codec=vp9','-width=320','-height=180','-frames=120','-fps=30','-bitrate=500','-mode=realtime','-cpu-used=8','-threads=1','-encode-only','-auto-libvpx=false','-format=json'];rows=[]
for rnd,order in enumerate([['b57','candidate'],['candidate','b57']],3):
 for ref in order:
  cmd=[str(D/('b57-whole' if ref=='b57' else 'final-whole'))]+args;p=O/f'r{rnd}-vp9-320-{ref}.json'
  with p.open('w') as f,p.with_suffix('.stderr').open('w') as err:r=subprocess.run(cmd,cwd=D,env=env,stdout=f,stderr=err)
  assert r.returncode==0;row=json.loads(p.read_text());rows.append({'round':rnd,'ref':ref,'cmd':cmd,'value':row});print(rnd,ref,row['ns_per_frame'],flush=True)
old=json.loads((O/'summary.json').read_text());old['additional_vp9_320_rows']=rows;ratios=old['summary']['vp9-320']['paired_speedups'][:];ignore={'ns_per_frame','encode_fps','macroblocks_per_second','allocs_per_frame','latency_ns'}
for rnd in [3,4]:
 a=next(r['value'] for r in rows if r['round']==rnd and r['ref']=='b57');b=next(r['value'] for r in rows if r['round']==rnd and r['ref']=='candidate');assert {k:v for k,v in a.items() if k not in ignore}=={k:v for k,v in b.items() if k not in ignore};ratios.append(a['ns_per_frame']/b['ns_per_frame'])
old['vp9_320_recheck']={'reason':'Initial paired screen slower on both samples; one compact affected-scope repeat, preserve all samples.','all_four_paired_speedups':ratios,'median_speedup':statistics.median(ratios),'preliminary':True};(O/'summary.json').write_text(json.dumps(old,indent=2)+'\n');print(old['vp9_320_recheck'],flush=True)

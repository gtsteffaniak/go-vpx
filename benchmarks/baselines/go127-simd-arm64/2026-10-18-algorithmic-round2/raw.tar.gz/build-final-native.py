exec(open('/private/tmp/govpx-iterations100/build.py').read().split('for name in sys.argv')[0])
import shutil
for f in ['internal/pixel/x64_round2_native_test.go','internal/vp9/encoder/x64_round2_native_test.go']:shutil.copy2(R/f,D/'base'/f)
for name,source in [('b57',D/'base'),('final',R)]:
 for kind,package in [('whole','./cmd/govpx-bench'),('pixel','./internal/pixel'),('encoder','./internal/vp9/encoder')]:
  binary=D/f'{name}-{kind}';cmd=[str(R/'scripts/go.sh'),'-C',str(source),*(['build'] if kind=='whole' else ['test','-c']),'-pgo=off','-o',str(binary),package]
  with (D/f'{name}-{kind}-final-build.log').open('w') as f:r=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
  assert r.returncode==0,(name,kind);print(name,kind,'built',flush=True)
  if kind!='whole':
   with (D/f'{name}-{kind}-final-oracle.log').open('w') as f:r=subprocess.run([str(binary),'-test.run=^TestX64Round2','-test.count=1','-test.v'],cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT)
   assert r.returncode==0,(name,kind,'oracle');print(name,kind,'oraclePASS',flush=True)

# Native x64 round2 first cohort

https://github.com/thesyncim/govpx/actions/runs/39146736111

Head 7f53682325c48c7c5ca47b8eef61cbe4f59ab8a5; base b57aac772af29e85f4b5b34ae33600cc84cd6a0f

AMD EPYC 9V45; actual SDK AVX2=true, AVX512=true, Enabled=true. Two AB/BA pairs at 40ms; preliminary component results only. All312 timing samples zero allocation. All six statuses screened; ordinary baseline/candidate selectors passed. Variant76 remains diagnostic only because its UV numerical scalar oracle is missing.

Speedup = baseline/candidate; median is median of the two paired ratios. Every loss is retained below.

## Variant 76 — diagnostic only

Skip UV correction and strided stores when the exact rounded correction is zero.

| Case | Paired speedups | Median | Slower pairs |
|---|---:|---:|---:|
| BenchmarkX64Round2UV/verticalfalse/kind4/dense | 0.9985x, 0.9302x | 0.9643x | 2/2 |
| BenchmarkX64Round2UV/verticalfalse/kind4/edge | 1.1688x, 1.1743x | 1.1715x | 0/2 |
| BenchmarkX64Round2UV/verticalfalse/kind4/flat | 1.1566x, 1.0198x | 1.0882x | 0/2 |
| BenchmarkX64Round2UV/verticalfalse/kind6/dense | 1.0038x, 1.0004x | 1.0021x | 0/2 |
| BenchmarkX64Round2UV/verticalfalse/kind6/edge | 1.0006x, 0.9210x | 0.9608x | 1/2 |
| BenchmarkX64Round2UV/verticalfalse/kind6/flat | 1.2575x, 0.6105x | 0.9340x | 1/2 |
| BenchmarkX64Round2UV/verticaltrue/kind4/dense | 0.9956x, 1.0044x | 1.0000x | 1/2 |
| BenchmarkX64Round2UV/verticaltrue/kind4/edge | 0.9930x, 1.0002x | 0.9966x | 1/2 |
| BenchmarkX64Round2UV/verticaltrue/kind4/flat | 1.4082x, 1.4103x | 1.4093x | 0/2 |
| BenchmarkX64Round2UV/verticaltrue/kind6/dense | 0.7351x, 0.9897x | 0.8624x | 2/2 |
| BenchmarkX64Round2UV/verticaltrue/kind6/edge | 0.9891x, 1.0000x | 0.9945x | 1/2 |
| BenchmarkX64Round2UV/verticaltrue/kind6/flat | 1.6200x, 1.6314x | 1.6257x | 0/2 |

## Variant 77

Use aggregate-only DCT4 scoring instead of q/dq materialization, scan/EOB and second reduction pass.

| Case | Paired speedups | Median | Slower pairs |
|---|---:|---:|---:|
| BenchmarkX64Round2Yrd/tx16/size16/constant | 0.9956x, 0.9895x | 0.9926x | 2/2 |
| BenchmarkX64Round2Yrd/tx16/size16/dense | 1.0085x, 0.9986x | 1.0036x | 1/2 |
| BenchmarkX64Round2Yrd/tx16/size16/zero | 1.0023x, 1.0076x | 1.0050x | 0/2 |
| BenchmarkX64Round2Yrd/tx16/size64/constant | 1.0196x, 0.9872x | 1.0034x | 1/2 |
| BenchmarkX64Round2Yrd/tx16/size64/dense | 0.9991x, 1.0120x | 1.0055x | 1/2 |
| BenchmarkX64Round2Yrd/tx16/size64/zero | 1.0042x, 0.9368x | 0.9705x | 1/2 |
| BenchmarkX64Round2Yrd/tx4/size16/constant | 1.6383x, 1.7148x | 1.6766x | 0/2 |
| BenchmarkX64Round2Yrd/tx4/size16/dense | 1.8435x, 1.8568x | 1.8501x | 0/2 |
| BenchmarkX64Round2Yrd/tx4/size16/zero | 15.3720x, 15.4199x | 15.3960x | 0/2 |
| BenchmarkX64Round2Yrd/tx4/size64/constant | 1.7161x, 1.7497x | 1.7329x | 0/2 |
| BenchmarkX64Round2Yrd/tx4/size64/dense | 1.9100x, 1.9260x | 1.9180x | 0/2 |
| BenchmarkX64Round2Yrd/tx4/size64/zero | 53.6880x, 60.6070x | 57.1475x | 0/2 |
| BenchmarkX64Round2Yrd/tx8/size16/constant | 0.9931x, 0.9939x | 0.9935x | 2/2 |
| BenchmarkX64Round2Yrd/tx8/size16/dense | 0.9884x, 1.0000x | 0.9942x | 1/2 |
| BenchmarkX64Round2Yrd/tx8/size16/zero | 0.9952x, 1.0014x | 0.9983x | 1/2 |
| BenchmarkX64Round2Yrd/tx8/size64/constant | 0.9952x, 0.9957x | 0.9954x | 2/2 |
| BenchmarkX64Round2Yrd/tx8/size64/dense | 1.0131x, 1.0009x | 1.0070x | 0/2 |
| BenchmarkX64Round2Yrd/tx8/size64/zero | 1.0066x, 0.9982x | 1.0024x | 1/2 |

## Variant 78

Reuse exact quantizer reciprocals instead of dividing twice for every BlockYrd candidate.

| Case | Paired speedups | Median | Slower pairs |
|---|---:|---:|---:|
| BenchmarkX64Round2Yrd/tx16/size16/constant | 0.9949x, 1.0364x | 1.0157x | 1/2 |
| BenchmarkX64Round2Yrd/tx16/size16/dense | 1.0063x, 0.9950x | 1.0006x | 1/2 |
| BenchmarkX64Round2Yrd/tx16/size16/zero | 0.9608x, 0.9661x | 0.9634x | 2/2 |
| BenchmarkX64Round2Yrd/tx16/size64/constant | 0.9786x, 0.9951x | 0.9868x | 2/2 |
| BenchmarkX64Round2Yrd/tx16/size64/dense | 1.0000x, 1.0093x | 1.0047x | 0/2 |
| BenchmarkX64Round2Yrd/tx16/size64/zero | 1.0280x, 1.0103x | 1.0192x | 0/2 |
| BenchmarkX64Round2Yrd/tx4/size16/constant | 0.9799x, 1.0358x | 1.0078x | 1/2 |
| BenchmarkX64Round2Yrd/tx4/size16/dense | 1.0240x, 1.1753x | 1.0996x | 0/2 |
| BenchmarkX64Round2Yrd/tx4/size16/zero | 0.9907x, 1.0080x | 0.9993x | 1/2 |
| BenchmarkX64Round2Yrd/tx4/size64/constant | 0.9967x, 0.9887x | 0.9927x | 2/2 |
| BenchmarkX64Round2Yrd/tx4/size64/dense | 0.9927x, 0.9968x | 0.9948x | 2/2 |
| BenchmarkX64Round2Yrd/tx4/size64/zero | 0.9980x, 0.9856x | 0.9918x | 2/2 |
| BenchmarkX64Round2Yrd/tx8/size16/constant | 1.0024x, 0.9639x | 0.9831x | 1/2 |
| BenchmarkX64Round2Yrd/tx8/size16/dense | 1.0020x, 1.0116x | 1.0068x | 0/2 |
| BenchmarkX64Round2Yrd/tx8/size16/zero | 0.9620x, 0.9713x | 0.9666x | 2/2 |
| BenchmarkX64Round2Yrd/tx8/size64/constant | 1.0235x, 1.1408x | 1.0822x | 0/2 |
| BenchmarkX64Round2Yrd/tx8/size64/dense | 1.0123x, 1.0289x | 1.0206x | 0/2 |
| BenchmarkX64Round2Yrd/tx8/size64/zero | 1.0208x, 1.0526x | 1.0367x | 0/2 |

## Variant 80

Fuse Hadamard16 quadrant combination and aggregate quantization, eliminating combined-coefficient write/reload.

| Case | Paired speedups | Median | Slower pairs |
|---|---:|---:|---:|
| BenchmarkX64Round2Yrd/tx16/size16/constant | 1.0027x, 1.0092x | 1.0060x | 0/2 |
| BenchmarkX64Round2Yrd/tx16/size16/dense | 0.9635x, 0.9758x | 0.9697x | 2/2 |
| BenchmarkX64Round2Yrd/tx16/size16/zero | 1.0002x, 1.0129x | 1.0066x | 0/2 |
| BenchmarkX64Round2Yrd/tx16/size64/constant | 0.9816x, 0.9894x | 0.9855x | 2/2 |
| BenchmarkX64Round2Yrd/tx16/size64/dense | 0.9455x, 0.8796x | 0.9125x | 2/2 |
| BenchmarkX64Round2Yrd/tx16/size64/zero | 1.0006x, 1.0060x | 1.0033x | 0/2 |
| BenchmarkX64Round2Yrd/tx4/size16/constant | 0.9943x, 1.0465x | 1.0204x | 1/2 |
| BenchmarkX64Round2Yrd/tx4/size16/dense | 1.0105x, 1.0038x | 1.0072x | 0/2 |
| BenchmarkX64Round2Yrd/tx4/size16/zero | 0.9992x, 1.5599x | 1.2796x | 1/2 |
| BenchmarkX64Round2Yrd/tx4/size64/constant | 1.0011x, 0.9953x | 0.9982x | 1/2 |
| BenchmarkX64Round2Yrd/tx4/size64/dense | 1.0036x, 0.9965x | 1.0001x | 1/2 |
| BenchmarkX64Round2Yrd/tx4/size64/zero | 1.0120x, 0.9960x | 1.0040x | 1/2 |
| BenchmarkX64Round2Yrd/tx8/size16/constant | 0.9897x, 0.9087x | 0.9492x | 2/2 |
| BenchmarkX64Round2Yrd/tx8/size16/dense | 0.9971x, 1.0039x | 1.0005x | 1/2 |
| BenchmarkX64Round2Yrd/tx8/size16/zero | 0.9984x, 0.9758x | 0.9871x | 2/2 |
| BenchmarkX64Round2Yrd/tx8/size64/constant | 1.0055x, 1.0059x | 1.0057x | 0/2 |
| BenchmarkX64Round2Yrd/tx8/size64/dense | 1.0044x, 1.0009x | 1.0026x | 0/2 |
| BenchmarkX64Round2Yrd/tx8/size64/zero | 1.0042x, 1.0000x | 1.0021x | 0/2 |

## Variant 94

Use SSE-only native kernels for the BlockSSE consumer instead of computing an unused signed sum.

| Case | Paired speedups | Median | Slower pairs |
|---|---:|---:|---:|
| BenchmarkX64Round2SSE/16 | 0.7127x, 0.7149x | 0.7138x | 2/2 |
| BenchmarkX64Round2SSE/32 | 1.6099x, 1.6296x | 1.6197x | 0/2 |
| BenchmarkX64Round2SSE/64 | 1.7615x, 1.7832x | 1.7724x | 0/2 |
| BenchmarkX64Round2SSE/8 | 2.0332x, 2.0258x | 2.0295x | 0/2 |

## Variant 100

Prepare repeated border pixels once and reuse native residual statistics instead of clamping every scalar pixel.

| Case | Paired speedups | Median | Slower pairs |
|---|---:|---:|---:|
| BenchmarkX64Round2EdgeStats/size16/x0/y0 | 1.0074x, 0.9977x | 1.0025x | 1/2 |
| BenchmarkX64Round2EdgeStats/size16/x0/y40 | 2.3632x, 2.2736x | 2.3184x | 0/2 |
| BenchmarkX64Round2EdgeStats/size16/x40/y0 | 0.9991x, 1.0023x | 1.0007x | 1/2 |
| BenchmarkX64Round2EdgeStats/size16/x40/y40 | 2.3089x, 2.2776x | 2.2932x | 0/2 |
| BenchmarkX64Round2EdgeStats/size64/x0/y0 | 5.2940x, 5.2213x | 5.2577x | 0/2 |
| BenchmarkX64Round2EdgeStats/size64/x0/y40 | 5.3966x, 5.5875x | 5.4920x | 0/2 |
| BenchmarkX64Round2EdgeStats/size64/x40/y0 | 3.2204x, 3.1310x | 3.1757x | 0/2 |
| BenchmarkX64Round2EdgeStats/size64/x40/y40 | 4.6903x, 4.4556x | 4.5729x | 0/2 |


# Second native x64 cohort

https://github.com/thesyncim/govpx/actions/runs/39147718292

Head dd5873e98dbe963ff55f8a9e6d1f3f815daec3a5; exact baseline b57aac772af29e85f4b5b34ae33600cc84cd6a0f

AMD EPYC7763, actual SDK AVX2=true/AVX512=false/Enabled=true. Two balanced40ms AB/BA pairs; preliminary components only. No whole-codec/C/profile/full-validation run. All measured samples zero allocation.

19 variants screened.86 rejected with SIGILL;94/100 rejected by the known baseline overflow fixture error. The corrected76 scalar UV boundary oracle passed.

Ratios below are baseline/candidate. Median is median of the two paired ratios, not a pooled or cross-host result.

## Variant 76

Validate and retain exact rounded-zero UV correction/store elision.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2UV/verticalfalse/kind4/dense | 0.9994x | 1.0036x | 1.0015x | 1/2 |
| BenchmarkX64Round2UV/verticalfalse/kind4/edge | 1.1176x | 1.1189x | 1.1183x | 0/2 |
| BenchmarkX64Round2UV/verticalfalse/kind4/flat | 1.1012x | 1.1090x | 1.1051x | 0/2 |
| BenchmarkX64Round2UV/verticalfalse/kind6/dense | 0.9963x | 1.0008x | 0.9985x | 1/2 |
| BenchmarkX64Round2UV/verticalfalse/kind6/edge | 0.9940x | 0.9957x | 0.9948x | 2/2 |
| BenchmarkX64Round2UV/verticalfalse/kind6/flat | 1.2283x | 1.2358x | 1.2320x | 0/2 |
| BenchmarkX64Round2UV/verticaltrue/kind4/dense | 0.9989x | 0.9943x | 0.9966x | 2/2 |
| BenchmarkX64Round2UV/verticaltrue/kind4/edge | 0.9964x | 0.9885x | 0.9925x | 2/2 |
| BenchmarkX64Round2UV/verticaltrue/kind4/flat | 1.2484x | 1.2465x | 1.2475x | 0/2 |
| BenchmarkX64Round2UV/verticaltrue/kind6/dense | 0.9954x | 0.9901x | 0.9928x | 2/2 |
| BenchmarkX64Round2UV/verticaltrue/kind6/edge | 0.9847x | 0.9853x | 0.9850x | 2/2 |
| BenchmarkX64Round2UV/verticaltrue/kind6/flat | 1.4741x | 1.4740x | 1.4741x | 0/2 |

## Variant 79

Recognize a whole uniform residual before writing it or rescanning each transform.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2Yrd/tx16/size16/constant | 1.9641x | 1.9592x | 1.9617x | 0/2 |
| BenchmarkX64Round2Yrd/tx16/size16/dense | 0.9782x | 0.9696x | 0.9739x | 2/2 |
| BenchmarkX64Round2Yrd/tx16/size16/zero | 1.1596x | 1.3120x | 1.2358x | 0/2 |
| BenchmarkX64Round2Yrd/tx16/size64/constant | 3.2657x | 3.2754x | 3.2705x | 0/2 |
| BenchmarkX64Round2Yrd/tx16/size64/dense | 1.0078x | 1.1691x | 1.0884x | 0/2 |
| BenchmarkX64Round2Yrd/tx16/size64/zero | 0.9061x | 0.9159x | 0.9110x | 2/2 |
| BenchmarkX64Round2Yrd/tx4/size16/constant | 0.9959x | 0.9967x | 0.9963x | 2/2 |
| BenchmarkX64Round2Yrd/tx4/size16/dense | 0.7184x | 0.7174x | 0.7179x | 2/2 |
| BenchmarkX64Round2Yrd/tx4/size16/zero | 0.9723x | 0.9909x | 0.9816x | 2/2 |
| BenchmarkX64Round2Yrd/tx4/size64/constant | 0.9917x | 0.9987x | 0.9952x | 2/2 |
| BenchmarkX64Round2Yrd/tx4/size64/dense | 0.6971x | 0.7034x | 0.7002x | 2/2 |
| BenchmarkX64Round2Yrd/tx4/size64/zero | 0.9896x | 0.9941x | 0.9918x | 2/2 |
| BenchmarkX64Round2Yrd/tx8/size16/constant | 2.2634x | 2.2500x | 2.2567x | 0/2 |
| BenchmarkX64Round2Yrd/tx8/size16/dense | 0.9516x | 0.9441x | 0.9479x | 2/2 |
| BenchmarkX64Round2Yrd/tx8/size16/zero | 1.3008x | 1.3109x | 1.3058x | 0/2 |
| BenchmarkX64Round2Yrd/tx8/size64/constant | 4.3595x | 4.3547x | 4.3571x | 0/2 |
| BenchmarkX64Round2Yrd/tx8/size64/dense | 0.9594x | 1.0017x | 0.9805x | 1/2 |
| BenchmarkX64Round2Yrd/tx8/size64/zero | 0.9129x | 0.9049x | 0.9089x | 2/2 |

## Variant 81

Process16 bounded aggregate scoring coefficients per packet instead of8, eliminating half the packet setup and reductions.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2Yrd/tx16/size16/constant | 1.0203x | 1.0110x | 1.0157x | 0/2 |
| BenchmarkX64Round2Yrd/tx16/size16/dense | 1.0439x | 1.0401x | 1.0420x | 0/2 |
| BenchmarkX64Round2Yrd/tx16/size16/zero | 1.0073x | 1.0027x | 1.0050x | 0/2 |
| BenchmarkX64Round2Yrd/tx16/size64/constant | 1.0136x | 1.0160x | 1.0148x | 0/2 |
| BenchmarkX64Round2Yrd/tx16/size64/dense | 1.0911x | 1.0903x | 1.0907x | 0/2 |
| BenchmarkX64Round2Yrd/tx16/size64/zero | 0.9782x | 1.0011x | 0.9896x | 1/2 |
| BenchmarkX64Round2Yrd/tx4/size16/constant | 1.0067x | 1.0067x | 1.0067x | 0/2 |
| BenchmarkX64Round2Yrd/tx4/size16/dense | 1.0935x | 1.0101x | 1.0518x | 0/2 |
| BenchmarkX64Round2Yrd/tx4/size16/zero | 1.3361x | 0.9868x | 1.1614x | 1/2 |
| BenchmarkX64Round2Yrd/tx4/size64/constant | 0.9933x | 0.9980x | 0.9957x | 2/2 |
| BenchmarkX64Round2Yrd/tx4/size64/dense | 0.9859x | 0.9957x | 0.9908x | 2/2 |
| BenchmarkX64Round2Yrd/tx4/size64/zero | 0.9885x | 0.9846x | 0.9866x | 2/2 |
| BenchmarkX64Round2Yrd/tx8/size16/constant | 1.0121x | 0.9788x | 0.9955x | 1/2 |
| BenchmarkX64Round2Yrd/tx8/size16/dense | 1.0087x | 1.2509x | 1.1298x | 0/2 |
| BenchmarkX64Round2Yrd/tx8/size16/zero | 0.9984x | 0.9993x | 0.9988x | 2/2 |
| BenchmarkX64Round2Yrd/tx8/size64/constant | 0.9569x | 0.9075x | 0.9322x | 2/2 |
| BenchmarkX64Round2Yrd/tx8/size64/dense | 0.9972x | 1.0090x | 1.0031x | 1/2 |
| BenchmarkX64Round2Yrd/tx8/size64/zero | 0.9982x | 0.9968x | 0.9975x | 2/2 |

## Variant 82

Remove repeated checked slice construction from the validated8-coefficient quantizer fallback while preserving its alias order.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2FP/n16/dc/optional0 | 1.1368x | 1.1582x | 1.1475x | 0/2 |
| BenchmarkX64Round2FP/n16/dc/optional1 | 1.1854x | 1.1873x | 1.1863x | 0/2 |
| BenchmarkX64Round2FP/n16/dc/optional2 | 1.2055x | 1.2089x | 1.2072x | 0/2 |
| BenchmarkX64Round2FP/n16/dc/optional3 | 1.2273x | 1.2315x | 1.2294x | 0/2 |
| BenchmarkX64Round2FP/n16/dense/optional0 | 1.1346x | 1.1354x | 1.1350x | 0/2 |
| BenchmarkX64Round2FP/n16/dense/optional1 | 1.1631x | 1.1658x | 1.1644x | 0/2 |
| BenchmarkX64Round2FP/n16/dense/optional2 | 1.1810x | 1.1846x | 1.1828x | 0/2 |
| BenchmarkX64Round2FP/n16/dense/optional3 | 1.2072x | 1.2022x | 1.2047x | 0/2 |
| BenchmarkX64Round2FP/n16/zero/optional0 | 1.1559x | 1.1545x | 1.1552x | 0/2 |
| BenchmarkX64Round2FP/n16/zero/optional1 | 1.2232x | 0.9115x | 1.0674x | 1/2 |
| BenchmarkX64Round2FP/n16/zero/optional2 | 1.2390x | 1.0837x | 1.1614x | 0/2 |
| BenchmarkX64Round2FP/n16/zero/optional3 | 1.2812x | 1.2809x | 1.2811x | 0/2 |
| BenchmarkX64Round2FP/n256/dc/optional0 | 0.9875x | 0.9893x | 0.9884x | 2/2 |
| BenchmarkX64Round2FP/n256/dc/optional1 | 1.0767x | 1.0836x | 1.0801x | 0/2 |
| BenchmarkX64Round2FP/n256/dc/optional2 | 0.9819x | 0.9817x | 0.9818x | 2/2 |
| BenchmarkX64Round2FP/n256/dc/optional3 | 1.0135x | 1.0192x | 1.0163x | 0/2 |
| BenchmarkX64Round2FP/n256/dense/optional0 | 1.0226x | 1.0171x | 1.0199x | 0/2 |
| BenchmarkX64Round2FP/n256/dense/optional1 | 1.0510x | 1.0431x | 1.0471x | 0/2 |
| BenchmarkX64Round2FP/n256/dense/optional2 | 0.9903x | 0.9997x | 0.9950x | 2/2 |
| BenchmarkX64Round2FP/n256/dense/optional3 | 1.0022x | 0.9959x | 0.9991x | 1/2 |
| BenchmarkX64Round2FP/n256/zero/optional0 | 0.9915x | 0.9876x | 0.9895x | 2/2 |
| BenchmarkX64Round2FP/n256/zero/optional1 | 1.0653x | 1.0752x | 1.0703x | 0/2 |
| BenchmarkX64Round2FP/n256/zero/optional2 | 0.9837x | 0.9808x | 0.9822x | 2/2 |
| BenchmarkX64Round2FP/n256/zero/optional3 | 1.0154x | 1.0245x | 1.0199x | 0/2 |
| BenchmarkX64Round2FP/n32/dc/optional0 | 1.2441x | 1.2497x | 1.2469x | 0/2 |
| BenchmarkX64Round2FP/n32/dc/optional1 | 1.3299x | 1.3411x | 1.3355x | 0/2 |
| BenchmarkX64Round2FP/n32/dc/optional2 | 1.3775x | 1.3768x | 1.3771x | 0/2 |
| BenchmarkX64Round2FP/n32/dc/optional3 | 1.4105x | 1.4130x | 1.4117x | 0/2 |
| BenchmarkX64Round2FP/n32/dense/optional0 | 1.1940x | 1.2159x | 1.2050x | 0/2 |
| BenchmarkX64Round2FP/n32/dense/optional1 | 1.2386x | 1.2381x | 1.2383x | 0/2 |
| BenchmarkX64Round2FP/n32/dense/optional2 | 1.2642x | 1.5950x | 1.4296x | 0/2 |
| BenchmarkX64Round2FP/n32/dense/optional3 | 1.3020x | 1.7792x | 1.5406x | 0/2 |
| BenchmarkX64Round2FP/n32/zero/optional0 | 1.2735x | 1.2689x | 1.2712x | 0/2 |
| BenchmarkX64Round2FP/n32/zero/optional1 | 1.3838x | 1.3808x | 1.3823x | 0/2 |
| BenchmarkX64Round2FP/n32/zero/optional2 | 1.4136x | 1.4148x | 1.4142x | 0/2 |
| BenchmarkX64Round2FP/n32/zero/optional3 | 1.4598x | 1.4643x | 1.4620x | 0/2 |
| BenchmarkX64Round2FP/n64/dc/optional0 | 0.9925x | 0.9877x | 0.9901x | 2/2 |
| BenchmarkX64Round2FP/n64/dc/optional1 | 1.0160x | 1.0130x | 1.0145x | 0/2 |
| BenchmarkX64Round2FP/n64/dc/optional2 | 1.0040x | 0.9985x | 1.0013x | 1/2 |
| BenchmarkX64Round2FP/n64/dc/optional3 | 1.0049x | 1.0021x | 1.0035x | 0/2 |
| BenchmarkX64Round2FP/n64/dense/optional0 | 0.9925x | 0.9851x | 0.9888x | 2/2 |
| BenchmarkX64Round2FP/n64/dense/optional1 | 1.0241x | 1.0203x | 1.0222x | 0/2 |
| BenchmarkX64Round2FP/n64/dense/optional2 | 0.9928x | 0.9902x | 0.9915x | 2/2 |
| BenchmarkX64Round2FP/n64/dense/optional3 | 0.9506x | 1.0018x | 0.9762x | 1/2 |
| BenchmarkX64Round2FP/n64/zero/optional0 | 0.9872x | 0.9884x | 0.9878x | 2/2 |
| BenchmarkX64Round2FP/n64/zero/optional1 | 1.0089x | 1.0186x | 1.0137x | 0/2 |
| BenchmarkX64Round2FP/n64/zero/optional2 | 1.0143x | 1.0004x | 1.0073x | 0/2 |
| BenchmarkX64Round2FP/n64/zero/optional3 | 1.0037x | 0.9978x | 1.0007x | 1/2 |

## Variant 83

Specialize optional quantizer outputs once per call rather than testing q/classes presence in every packet.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2FP/n16/dc/optional0 | 0.9463x | 0.9404x | 0.9434x | 2/2 |
| BenchmarkX64Round2FP/n16/dc/optional1 | 0.9139x | 0.9153x | 0.9146x | 2/2 |
| BenchmarkX64Round2FP/n16/dc/optional2 | 0.9487x | 0.9480x | 0.9484x | 2/2 |
| BenchmarkX64Round2FP/n16/dc/optional3 | 0.9316x | 0.9284x | 0.9300x | 2/2 |
| BenchmarkX64Round2FP/n16/dense/optional0 | 0.9341x | 0.9335x | 0.9338x | 2/2 |
| BenchmarkX64Round2FP/n16/dense/optional1 | 0.9198x | 0.9060x | 0.9129x | 2/2 |
| BenchmarkX64Round2FP/n16/dense/optional2 | 0.9457x | 0.9397x | 0.9427x | 2/2 |
| BenchmarkX64Round2FP/n16/dense/optional3 | 0.9141x | 0.9207x | 0.9174x | 2/2 |
| BenchmarkX64Round2FP/n16/zero/optional0 | 0.9585x | 0.9400x | 0.9493x | 2/2 |
| BenchmarkX64Round2FP/n16/zero/optional1 | 0.9209x | 0.8447x | 0.8828x | 2/2 |
| BenchmarkX64Round2FP/n16/zero/optional2 | 0.9561x | 0.9529x | 0.9545x | 2/2 |
| BenchmarkX64Round2FP/n16/zero/optional3 | 0.9464x | 0.9463x | 0.9463x | 2/2 |
| BenchmarkX64Round2FP/n256/dc/optional0 | 1.0180x | 1.0231x | 1.0205x | 0/2 |
| BenchmarkX64Round2FP/n256/dc/optional1 | 1.0326x | 1.0305x | 1.0315x | 0/2 |
| BenchmarkX64Round2FP/n256/dc/optional2 | 1.0046x | 1.0046x | 1.0046x | 0/2 |
| BenchmarkX64Round2FP/n256/dc/optional3 | 0.9209x | 0.8446x | 0.8827x | 2/2 |
| BenchmarkX64Round2FP/n256/dense/optional0 | 1.0187x | 1.0163x | 1.0175x | 0/2 |
| BenchmarkX64Round2FP/n256/dense/optional1 | 1.0617x | 1.0596x | 1.0607x | 0/2 |
| BenchmarkX64Round2FP/n256/dense/optional2 | 0.9299x | 0.9268x | 0.9283x | 2/2 |
| BenchmarkX64Round2FP/n256/dense/optional3 | 0.9401x | 0.9539x | 0.9470x | 2/2 |
| BenchmarkX64Round2FP/n256/zero/optional0 | 1.0281x | 1.0312x | 1.0296x | 0/2 |
| BenchmarkX64Round2FP/n256/zero/optional1 | 1.0629x | 1.0618x | 1.0623x | 0/2 |
| BenchmarkX64Round2FP/n256/zero/optional2 | 1.0178x | 1.0138x | 1.0158x | 0/2 |
| BenchmarkX64Round2FP/n256/zero/optional3 | 0.9411x | 0.9468x | 0.9440x | 2/2 |
| BenchmarkX64Round2FP/n32/dc/optional0 | 0.9896x | 0.9918x | 0.9907x | 2/2 |
| BenchmarkX64Round2FP/n32/dc/optional1 | 0.9480x | 0.9500x | 0.9490x | 2/2 |
| BenchmarkX64Round2FP/n32/dc/optional2 | 0.9888x | 0.9910x | 0.9899x | 2/2 |
| BenchmarkX64Round2FP/n32/dc/optional3 | 0.9779x | 0.9757x | 0.9768x | 2/2 |
| BenchmarkX64Round2FP/n32/dense/optional0 | 0.9673x | 0.9696x | 0.9685x | 2/2 |
| BenchmarkX64Round2FP/n32/dense/optional1 | 0.9239x | 0.9294x | 0.9267x | 2/2 |
| BenchmarkX64Round2FP/n32/dense/optional2 | 0.9689x | 0.9709x | 0.9699x | 2/2 |
| BenchmarkX64Round2FP/n32/dense/optional3 | 0.9346x | 0.7567x | 0.8457x | 2/2 |
| BenchmarkX64Round2FP/n32/zero/optional0 | 1.3762x | 1.0000x | 1.1881x | 0/2 |
| BenchmarkX64Round2FP/n32/zero/optional1 | 1.5338x | 0.9547x | 1.2443x | 1/2 |
| BenchmarkX64Round2FP/n32/zero/optional2 | 1.0235x | 1.0006x | 1.0120x | 0/2 |
| BenchmarkX64Round2FP/n32/zero/optional3 | 0.9918x | 0.9913x | 0.9916x | 2/2 |
| BenchmarkX64Round2FP/n64/dc/optional0 | 0.9281x | 0.9271x | 0.9276x | 2/2 |
| BenchmarkX64Round2FP/n64/dc/optional1 | 0.9454x | 0.9327x | 0.9391x | 2/2 |
| BenchmarkX64Round2FP/n64/dc/optional2 | 0.9589x | 0.9343x | 0.9466x | 2/2 |
| BenchmarkX64Round2FP/n64/dc/optional3 | 0.9488x | 0.9471x | 0.9480x | 2/2 |
| BenchmarkX64Round2FP/n64/dense/optional0 | 0.8786x | 0.8815x | 0.8800x | 2/2 |
| BenchmarkX64Round2FP/n64/dense/optional1 | 0.9125x | 0.9100x | 0.9113x | 2/2 |
| BenchmarkX64Round2FP/n64/dense/optional2 | 0.8540x | 0.8576x | 0.8558x | 2/2 |
| BenchmarkX64Round2FP/n64/dense/optional3 | 0.8641x | 0.8582x | 0.8612x | 2/2 |
| BenchmarkX64Round2FP/n64/zero/optional0 | 0.9424x | 0.9326x | 0.9375x | 2/2 |
| BenchmarkX64Round2FP/n64/zero/optional1 | 0.9431x | 0.9427x | 0.9429x | 2/2 |
| BenchmarkX64Round2FP/n64/zero/optional2 | 0.9326x | 0.9327x | 0.9326x | 2/2 |
| BenchmarkX64Round2FP/n64/zero/optional3 | 0.9358x | 0.9349x | 0.9353x | 2/2 |

## Variant 84

Use one16-coefficient packet for short disjoint quantizer blocks instead of repeated8-packet setup.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2FP/n16/dc/optional0 | 1.1435x | 1.1130x | 1.1282x | 0/2 |
| BenchmarkX64Round2FP/n16/dc/optional1 | 1.1247x | 1.1186x | 1.1217x | 0/2 |
| BenchmarkX64Round2FP/n16/dc/optional2 | 1.1329x | 1.1290x | 1.1310x | 0/2 |
| BenchmarkX64Round2FP/n16/dc/optional3 | 1.1244x | 1.1266x | 1.1255x | 0/2 |
| BenchmarkX64Round2FP/n16/dense/optional0 | 1.1786x | 1.1787x | 1.1787x | 0/2 |
| BenchmarkX64Round2FP/n16/dense/optional1 | 1.1474x | 1.1429x | 1.1451x | 0/2 |
| BenchmarkX64Round2FP/n16/dense/optional2 | 1.1803x | 1.1799x | 1.1801x | 0/2 |
| BenchmarkX64Round2FP/n16/dense/optional3 | 1.1635x | 1.1596x | 1.1615x | 0/2 |
| BenchmarkX64Round2FP/n16/zero/optional0 | 1.1313x | 1.1052x | 1.1183x | 0/2 |
| BenchmarkX64Round2FP/n16/zero/optional1 | 1.1112x | 1.2603x | 1.1858x | 0/2 |
| BenchmarkX64Round2FP/n16/zero/optional2 | 1.1412x | 1.5768x | 1.3590x | 0/2 |
| BenchmarkX64Round2FP/n16/zero/optional3 | 1.1885x | 1.1545x | 1.1715x | 0/2 |
| BenchmarkX64Round2FP/n256/dc/optional0 | 1.0036x | 0.9995x | 1.0015x | 1/2 |
| BenchmarkX64Round2FP/n256/dc/optional1 | 1.0268x | 1.0012x | 1.0140x | 0/2 |
| BenchmarkX64Round2FP/n256/dc/optional2 | 1.0030x | 0.9903x | 0.9966x | 1/2 |
| BenchmarkX64Round2FP/n256/dc/optional3 | 1.0054x | 0.8152x | 0.9103x | 1/2 |
| BenchmarkX64Round2FP/n256/dense/optional0 | 1.0021x | 0.9184x | 0.9603x | 1/2 |
| BenchmarkX64Round2FP/n256/dense/optional1 | 1.0023x | 0.9667x | 0.9845x | 1/2 |
| BenchmarkX64Round2FP/n256/dense/optional2 | 1.0017x | 0.9609x | 0.9813x | 1/2 |
| BenchmarkX64Round2FP/n256/dense/optional3 | 1.0088x | 0.6112x | 0.8100x | 1/2 |
| BenchmarkX64Round2FP/n256/zero/optional0 | 1.0047x | 0.9945x | 0.9996x | 1/2 |
| BenchmarkX64Round2FP/n256/zero/optional1 | 0.9832x | 1.0101x | 0.9966x | 1/2 |
| BenchmarkX64Round2FP/n256/zero/optional2 | 1.0013x | 0.9995x | 1.0004x | 1/2 |
| BenchmarkX64Round2FP/n256/zero/optional3 | 0.9961x | 1.0118x | 1.0039x | 1/2 |
| BenchmarkX64Round2FP/n32/dc/optional0 | 1.3380x | 1.3632x | 1.3506x | 0/2 |
| BenchmarkX64Round2FP/n32/dc/optional1 | 1.3190x | 1.3698x | 1.3444x | 0/2 |
| BenchmarkX64Round2FP/n32/dc/optional2 | 1.4052x | 1.4154x | 1.4103x | 0/2 |
| BenchmarkX64Round2FP/n32/dc/optional3 | 1.4241x | 1.4244x | 1.4243x | 0/2 |
| BenchmarkX64Round2FP/n32/dense/optional0 | 1.4414x | 1.4264x | 1.4339x | 0/2 |
| BenchmarkX64Round2FP/n32/dense/optional1 | 1.3926x | 1.3911x | 1.3918x | 0/2 |
| BenchmarkX64Round2FP/n32/dense/optional2 | 1.4687x | 1.4695x | 1.4691x | 0/2 |
| BenchmarkX64Round2FP/n32/dense/optional3 | 1.4555x | 1.4423x | 1.4489x | 0/2 |
| BenchmarkX64Round2FP/n32/zero/optional0 | 1.3436x | 1.3386x | 1.3411x | 0/2 |
| BenchmarkX64Round2FP/n32/zero/optional1 | 1.3645x | 1.3608x | 1.3627x | 0/2 |
| BenchmarkX64Round2FP/n32/zero/optional2 | 1.4319x | 1.4249x | 1.4284x | 0/2 |
| BenchmarkX64Round2FP/n32/zero/optional3 | 1.4850x | 1.4720x | 1.4785x | 0/2 |
| BenchmarkX64Round2FP/n64/dc/optional0 | 1.0008x | 1.0008x | 1.0008x | 0/2 |
| BenchmarkX64Round2FP/n64/dc/optional1 | 0.9992x | 0.9970x | 0.9981x | 2/2 |
| BenchmarkX64Round2FP/n64/dc/optional2 | 1.0000x | 0.9985x | 0.9993x | 1/2 |
| BenchmarkX64Round2FP/n64/dc/optional3 | 0.9990x | 0.9990x | 0.9990x | 2/2 |
| BenchmarkX64Round2FP/n64/dense/optional0 | 1.0007x | 0.9971x | 0.9989x | 1/2 |
| BenchmarkX64Round2FP/n64/dense/optional1 | 1.0007x | 0.9973x | 0.9990x | 1/2 |
| BenchmarkX64Round2FP/n64/dense/optional2 | 1.1448x | 0.9984x | 1.0716x | 1/2 |
| BenchmarkX64Round2FP/n64/dense/optional3 | 1.0030x | 0.9958x | 0.9994x | 1/2 |
| BenchmarkX64Round2FP/n64/zero/optional0 | 1.0000x | 0.9852x | 0.9926x | 1/2 |
| BenchmarkX64Round2FP/n64/zero/optional1 | 0.9992x | 0.7670x | 0.8831x | 2/2 |
| BenchmarkX64Round2FP/n64/zero/optional2 | 1.0031x | 0.9904x | 0.9968x | 1/2 |
| BenchmarkX64Round2FP/n64/zero/optional3 | 1.0018x | 0.9982x | 1.0000x | 1/2 |

## Variant 85

Clear a wholly zero AC suffix once instead of running round/mask/store/scan logic for each packet.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2FP/n16/dc/optional0 | 1.0387x | 1.0460x | 1.0424x | 0/2 |
| BenchmarkX64Round2FP/n16/dc/optional1 | 1.0369x | 0.8742x | 0.9555x | 1/2 |
| BenchmarkX64Round2FP/n16/dc/optional2 | 1.0214x | 1.0245x | 1.0230x | 0/2 |
| BenchmarkX64Round2FP/n16/dc/optional3 | 1.0226x | 1.0101x | 1.0163x | 0/2 |
| BenchmarkX64Round2FP/n16/dense/optional0 | 1.0501x | 1.0472x | 1.0487x | 0/2 |
| BenchmarkX64Round2FP/n16/dense/optional1 | 1.0278x | 0.7350x | 0.8814x | 1/2 |
| BenchmarkX64Round2FP/n16/dense/optional2 | 1.0313x | 1.0313x | 1.0313x | 0/2 |
| BenchmarkX64Round2FP/n16/dense/optional3 | 1.0161x | 1.0197x | 1.0179x | 0/2 |
| BenchmarkX64Round2FP/n16/zero/optional0 | 1.0249x | 1.0103x | 1.0176x | 0/2 |
| BenchmarkX64Round2FP/n16/zero/optional1 | 1.0386x | 0.7734x | 0.9060x | 1/2 |
| BenchmarkX64Round2FP/n16/zero/optional2 | 1.0035x | 1.0004x | 1.0019x | 0/2 |
| BenchmarkX64Round2FP/n16/zero/optional3 | 1.0226x | 0.6574x | 0.8400x | 1/2 |
| BenchmarkX64Round2FP/n256/dc/optional0 | 0.9973x | 0.9650x | 0.9811x | 2/2 |
| BenchmarkX64Round2FP/n256/dc/optional1 | 0.9898x | 0.9501x | 0.9699x | 2/2 |
| BenchmarkX64Round2FP/n256/dc/optional2 | 0.9371x | 0.9397x | 0.9384x | 2/2 |
| BenchmarkX64Round2FP/n256/dc/optional3 | 0.9303x | 0.9288x | 0.9295x | 2/2 |
| BenchmarkX64Round2FP/n256/dense/optional0 | 1.0050x | 1.0050x | 1.0050x | 0/2 |
| BenchmarkX64Round2FP/n256/dense/optional1 | 1.0199x | 1.0219x | 1.0209x | 0/2 |
| BenchmarkX64Round2FP/n256/dense/optional2 | 0.9829x | 0.9890x | 0.9859x | 2/2 |
| BenchmarkX64Round2FP/n256/dense/optional3 | 0.9840x | 0.9909x | 0.9874x | 2/2 |
| BenchmarkX64Round2FP/n256/zero/optional0 | 1.0028x | 1.0017x | 1.0022x | 0/2 |
| BenchmarkX64Round2FP/n256/zero/optional1 | 0.6660x | 0.9477x | 0.8069x | 2/2 |
| BenchmarkX64Round2FP/n256/zero/optional2 | 0.9324x | 0.9384x | 0.9354x | 2/2 |
| BenchmarkX64Round2FP/n256/zero/optional3 | 0.8275x | 0.9232x | 0.8753x | 2/2 |
| BenchmarkX64Round2FP/n32/dc/optional0 | 1.0287x | 1.0327x | 1.0307x | 0/2 |
| BenchmarkX64Round2FP/n32/dc/optional1 | 1.0500x | 0.9905x | 1.0202x | 1/2 |
| BenchmarkX64Round2FP/n32/dc/optional2 | 1.0000x | 1.0009x | 1.0004x | 0/2 |
| BenchmarkX64Round2FP/n32/dc/optional3 | 1.0163x | 1.0188x | 1.0175x | 0/2 |
| BenchmarkX64Round2FP/n32/dense/optional0 | 1.0605x | 1.0599x | 1.0602x | 0/2 |
| BenchmarkX64Round2FP/n32/dense/optional1 | 1.0182x | 0.9327x | 0.9755x | 1/2 |
| BenchmarkX64Round2FP/n32/dense/optional2 | 1.0975x | 1.0400x | 1.0688x | 0/2 |
| BenchmarkX64Round2FP/n32/dense/optional3 | 1.0179x | 1.0151x | 1.0165x | 0/2 |
| BenchmarkX64Round2FP/n32/zero/optional0 | 1.0267x | 1.0224x | 1.0246x | 0/2 |
| BenchmarkX64Round2FP/n32/zero/optional1 | 1.0199x | 0.9924x | 1.0062x | 1/2 |
| BenchmarkX64Round2FP/n32/zero/optional2 | 0.9460x | 0.9824x | 0.9642x | 2/2 |
| BenchmarkX64Round2FP/n32/zero/optional3 | 1.0139x | 1.0178x | 1.0159x | 0/2 |
| BenchmarkX64Round2FP/n64/dc/optional0 | 0.9100x | 0.9082x | 0.9091x | 2/2 |
| BenchmarkX64Round2FP/n64/dc/optional1 | 0.8336x | 0.7807x | 0.8071x | 2/2 |
| BenchmarkX64Round2FP/n64/dc/optional2 | 0.8709x | 0.8694x | 0.8701x | 2/2 |
| BenchmarkX64Round2FP/n64/dc/optional3 | 0.8057x | 0.8043x | 0.8050x | 2/2 |
| BenchmarkX64Round2FP/n64/dense/optional0 | 0.9555x | 0.9547x | 0.9551x | 2/2 |
| BenchmarkX64Round2FP/n64/dense/optional1 | 0.9973x | 0.9318x | 0.9646x | 2/2 |
| BenchmarkX64Round2FP/n64/dense/optional2 | 0.9698x | 0.9704x | 0.9701x | 2/2 |
| BenchmarkX64Round2FP/n64/dense/optional3 | 0.9780x | 0.9778x | 0.9779x | 2/2 |
| BenchmarkX64Round2FP/n64/zero/optional0 | 0.9085x | 0.8891x | 0.8988x | 2/2 |
| BenchmarkX64Round2FP/n64/zero/optional1 | 0.8324x | 0.7787x | 0.8056x | 2/2 |
| BenchmarkX64Round2FP/n64/zero/optional2 | 0.8627x | 0.8734x | 0.8680x | 2/2 |
| BenchmarkX64Round2FP/n64/zero/optional3 | 0.8036x | 0.8045x | 0.8040x | 2/2 |

## Variant 87

Remove per-row and per-vector slice checks after SSEPlane has already proved both complete windows.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2Plane/w128/h16/pad0 | 1.3311x | 1.3378x | 1.3345x | 0/2 |
| BenchmarkX64Round2Plane/w128/h16/pad17 | 1.3387x | 1.3466x | 1.3426x | 0/2 |
| BenchmarkX64Round2Plane/w128/h64/pad0 | 1.3741x | 1.3745x | 1.3743x | 0/2 |
| BenchmarkX64Round2Plane/w128/h64/pad17 | 1.3744x | 1.3743x | 1.3743x | 0/2 |
| BenchmarkX64Round2Plane/w16/h16/pad0 | 1.2476x | 1.2624x | 1.2550x | 0/2 |
| BenchmarkX64Round2Plane/w16/h16/pad17 | 1.2766x | 1.2996x | 1.2881x | 0/2 |
| BenchmarkX64Round2Plane/w16/h64/pad0 | 1.3064x | 1.3069x | 1.3067x | 0/2 |
| BenchmarkX64Round2Plane/w16/h64/pad17 | 1.3137x | 1.3159x | 1.3148x | 0/2 |
| BenchmarkX64Round2Plane/w64/h16/pad0 | 1.3313x | 1.3369x | 1.3341x | 0/2 |
| BenchmarkX64Round2Plane/w64/h16/pad17 | 1.3344x | 1.3315x | 1.3329x | 0/2 |
| BenchmarkX64Round2Plane/w64/h64/pad0 | 1.3459x | 1.3524x | 1.3491x | 0/2 |
| BenchmarkX64Round2Plane/w64/h64/pad17 | 1.3469x | 1.3509x | 1.3489x | 0/2 |

## Variant 88

Flatten contiguous narrow SSE planes into bounded streaming reductions instead of repeating row setup and four-row sums.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2Plane/w128/h16/pad0 | 0.9962x | 1.0044x | 1.0003x | 1/2 |
| BenchmarkX64Round2Plane/w128/h16/pad17 | 0.9994x | 0.9956x | 0.9975x | 2/2 |
| BenchmarkX64Round2Plane/w128/h64/pad0 | 0.9987x | 0.9946x | 0.9966x | 2/2 |
| BenchmarkX64Round2Plane/w128/h64/pad17 | 0.9968x | 0.9993x | 0.9981x | 2/2 |
| BenchmarkX64Round2Plane/w16/h16/pad0 | 2.3054x | 2.3237x | 2.3145x | 0/2 |
| BenchmarkX64Round2Plane/w16/h16/pad17 | 0.9952x | 0.9954x | 0.9953x | 2/2 |
| BenchmarkX64Round2Plane/w16/h64/pad0 | 3.4488x | 3.4547x | 3.4517x | 0/2 |
| BenchmarkX64Round2Plane/w16/h64/pad17 | 0.9960x | 0.9943x | 0.9951x | 2/2 |
| BenchmarkX64Round2Plane/w64/h16/pad0 | 1.8346x | 1.8308x | 1.8327x | 0/2 |
| BenchmarkX64Round2Plane/w64/h16/pad17 | 0.9965x | 0.9979x | 0.9972x | 2/2 |
| BenchmarkX64Round2Plane/w64/h64/pad0 | 1.9949x | 1.9983x | 1.9966x | 0/2 |
| BenchmarkX64Round2Plane/w64/h64/pad17 | 1.0006x | 0.9994x | 1.0000x | 1/2 |

## Variant 89

Use exact rounded averages for half-pel bilinear filters instead of multiplied weighted sums.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2Subpel/n16/halffalse/axis0 | 0.9735x | 0.9769x | 0.9752x | 2/2 |
| BenchmarkX64Round2Subpel/n16/halffalse/axis1 | 0.9081x | 0.9202x | 0.9142x | 2/2 |
| BenchmarkX64Round2Subpel/n16/halffalse/axis2 | 0.9984x | 0.9954x | 0.9969x | 2/2 |
| BenchmarkX64Round2Subpel/n16/halftrue/axis0 | 1.1109x | 1.1007x | 1.1058x | 0/2 |
| BenchmarkX64Round2Subpel/n16/halftrue/axis1 | 1.1414x | 1.1396x | 1.1405x | 0/2 |
| BenchmarkX64Round2Subpel/n16/halftrue/axis2 | 1.3869x | 1.3922x | 1.3895x | 0/2 |
| BenchmarkX64Round2Subpel/n64/halffalse/axis0 | 0.9567x | 0.9569x | 0.9568x | 2/2 |
| BenchmarkX64Round2Subpel/n64/halffalse/axis1 | 0.8875x | 0.8861x | 0.8868x | 2/2 |
| BenchmarkX64Round2Subpel/n64/halffalse/axis2 | 0.9984x | 0.9996x | 0.9990x | 2/2 |
| BenchmarkX64Round2Subpel/n64/halftrue/axis0 | 1.2329x | 1.2371x | 1.2350x | 0/2 |
| BenchmarkX64Round2Subpel/n64/halftrue/axis1 | 1.3691x | 1.3584x | 1.3637x | 0/2 |
| BenchmarkX64Round2Subpel/n64/halftrue/axis2 | 1.6696x | 1.6676x | 1.6686x | 0/2 |

## Variant 90

Accumulate bounded signed differences across a strip before widening, removing one horizontal sum per row.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2Subpel/n16/halffalse/axis0 | 1.0047x | 0.9965x | 1.0006x | 1/2 |
| BenchmarkX64Round2Subpel/n16/halffalse/axis1 | 0.9632x | 0.9587x | 0.9610x | 2/2 |
| BenchmarkX64Round2Subpel/n16/halffalse/axis2 | 0.9788x | 0.9781x | 0.9784x | 2/2 |
| BenchmarkX64Round2Subpel/n16/halftrue/axis0 | 0.9790x | 0.9842x | 0.9816x | 2/2 |
| BenchmarkX64Round2Subpel/n16/halftrue/axis1 | 0.9692x | 0.7489x | 0.8591x | 2/2 |
| BenchmarkX64Round2Subpel/n16/halftrue/axis2 | 0.9742x | 0.8778x | 0.9260x | 2/2 |
| BenchmarkX64Round2Subpel/n64/halffalse/axis0 | 1.0657x | 1.0718x | 1.0688x | 0/2 |
| BenchmarkX64Round2Subpel/n64/halffalse/axis1 | 1.1059x | 1.1035x | 1.1047x | 0/2 |
| BenchmarkX64Round2Subpel/n64/halffalse/axis2 | 1.0573x | 1.0573x | 1.0573x | 0/2 |
| BenchmarkX64Round2Subpel/n64/halftrue/axis0 | 1.0671x | 1.0699x | 1.0685x | 0/2 |
| BenchmarkX64Round2Subpel/n64/halftrue/axis1 | 1.1080x | 1.1028x | 1.1054x | 0/2 |
| BenchmarkX64Round2Subpel/n64/halftrue/axis2 | 1.0587x | 1.0566x | 1.0576x | 0/2 |

## Variant 91

Once the remaining SAD maximum cannot cross the limit, finish without per-row reductions and comparisons.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2SADLimit/10000 | 0.8723x | 0.8690x | 0.8706x | 2/2 |
| BenchmarkX64Round2SADLimit/2000 | 0.9165x | 0.9518x | 0.9341x | 2/2 |
| BenchmarkX64Round2SADLimit/40000 | 1.0409x | 1.0396x | 1.0402x | 0/2 |
| BenchmarkX64Round2SADLimit/65000 | 1.7270x | 1.7354x | 1.7312x | 0/2 |

## Variant 92

Replace8 separate row-copy calls with exact8-byte loads/stores while preserving row memmove alias order.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2Copy8/32 | 1.0391x | 1.0438x | 1.0415x | 0/2 |
| BenchmarkX64Round2Copy8/8 | 1.0681x | 1.0736x | 1.0709x | 0/2 |

## Variant 93

Reuse complete-window proofs in projection and quadrant-average reducers instead of repeated row bounds checks.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2Projection/average | 1.5982x | 1.6165x | 1.6073x | 0/2 |
| BenchmarkX64Round2Projection/cols16 | 1.2577x | 1.3959x | 1.3268x | 0/2 |
| BenchmarkX64Round2Projection/cols64 | 1.6995x | 1.8580x | 1.7787x | 0/2 |

## Variant 95

Skip reconstruction and stores for exact zero rounded corrections in fused macro/internal filtering.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2Macro/verticalfalse/dense | 0.9696x | 0.9670x | 0.9683x | 2/2 |
| BenchmarkX64Round2Macro/verticalfalse/edge | 0.9380x | 0.9400x | 0.9390x | 2/2 |
| BenchmarkX64Round2Macro/verticalfalse/flat | 1.3225x | 1.3484x | 1.3354x | 0/2 |
| BenchmarkX64Round2Macro/verticaltrue/dense | 0.9743x | 0.9744x | 0.9743x | 2/2 |
| BenchmarkX64Round2Macro/verticaltrue/edge | 0.9850x | 0.9870x | 0.9860x | 2/2 |
| BenchmarkX64Round2Macro/verticaltrue/flat | 1.8977x | 1.8833x | 1.8905x | 0/2 |

## Variant 96

Retain finalized vertical columns through four sequential edges and transpose/store them once.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2Macro/verticalfalse/dense | 1.0209x | 1.0192x | 1.0200x | 0/2 |
| BenchmarkX64Round2Macro/verticalfalse/edge | 0.9949x | 0.9996x | 0.9972x | 2/2 |
| BenchmarkX64Round2Macro/verticalfalse/flat | 0.9851x | 0.9993x | 0.9922x | 2/2 |
| BenchmarkX64Round2Macro/verticaltrue/dense | 0.7549x | 0.9364x | 0.8456x | 2/2 |
| BenchmarkX64Round2Macro/verticaltrue/edge | 0.8177x | 0.8764x | 0.8471x | 2/2 |
| BenchmarkX64Round2Macro/verticaltrue/flat | 0.8714x | 0.8772x | 0.8743x | 2/2 |

## Variant 97

Avoid reloading the same VP9 edge after an unsuccessful nonflat prepass by using one full filter pass.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2Flat/kind16/verticalfalse/dense | 0.6380x | 0.6357x | 0.6368x | 2/2 |
| BenchmarkX64Round2Flat/kind16/verticalfalse/flat | 1.0434x | 0.9983x | 1.0208x | 1/2 |
| BenchmarkX64Round2Flat/kind16/verticalfalse/nearflat | 0.6323x | 0.6288x | 0.6306x | 2/2 |
| BenchmarkX64Round2Flat/kind16/verticaltrue/dense | 0.6992x | 0.6981x | 0.6986x | 2/2 |
| BenchmarkX64Round2Flat/kind16/verticaltrue/flat | 1.0498x | 1.0456x | 1.0477x | 0/2 |
| BenchmarkX64Round2Flat/kind16/verticaltrue/nearflat | 0.6040x | 0.5997x | 0.6018x | 2/2 |
| BenchmarkX64Round2Flat/kind8/verticalfalse/dense | 0.6441x | 0.6330x | 0.6386x | 2/2 |
| BenchmarkX64Round2Flat/kind8/verticalfalse/flat | 1.0688x | 1.0439x | 1.0564x | 0/2 |
| BenchmarkX64Round2Flat/kind8/verticalfalse/nearflat | 0.6267x | 0.6434x | 0.6350x | 2/2 |
| BenchmarkX64Round2Flat/kind8/verticaltrue/dense | 0.7070x | 0.6975x | 0.7023x | 2/2 |
| BenchmarkX64Round2Flat/kind8/verticaltrue/flat | 1.1925x | 1.1915x | 1.1920x | 0/2 |
| BenchmarkX64Round2Flat/kind8/verticaltrue/nearflat | 0.6020x | 0.6025x | 0.6022x | 2/2 |

## Variant 98

Return unchanged uniform flat8 packets before weighted filtering and output stores.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2Flat/kind16/verticalfalse/dense | 0.9433x | 0.9344x | 0.9388x | 2/2 |
| BenchmarkX64Round2Flat/kind16/verticalfalse/flat | 0.9648x | 0.9746x | 0.9697x | 2/2 |
| BenchmarkX64Round2Flat/kind16/verticalfalse/nearflat | 0.9600x | 0.9620x | 0.9610x | 2/2 |
| BenchmarkX64Round2Flat/kind16/verticaltrue/dense | 0.9364x | 0.9396x | 0.9380x | 2/2 |
| BenchmarkX64Round2Flat/kind16/verticaltrue/flat | 0.9783x | 0.9804x | 0.9793x | 2/2 |
| BenchmarkX64Round2Flat/kind16/verticaltrue/nearflat | 0.9676x | 0.9780x | 0.9728x | 2/2 |
| BenchmarkX64Round2Flat/kind8/verticalfalse/dense | 0.9314x | 0.9438x | 0.9376x | 2/2 |
| BenchmarkX64Round2Flat/kind8/verticalfalse/flat | 1.5299x | 1.5261x | 1.5280x | 0/2 |
| BenchmarkX64Round2Flat/kind8/verticalfalse/nearflat | 0.9589x | 0.9586x | 0.9587x | 2/2 |
| BenchmarkX64Round2Flat/kind8/verticaltrue/dense | 0.9381x | 0.9388x | 0.9385x | 2/2 |
| BenchmarkX64Round2Flat/kind8/verticaltrue/flat | 1.9754x | 1.9523x | 1.9638x | 0/2 |
| BenchmarkX64Round2Flat/kind8/verticaltrue/nearflat | 0.9730x | 0.9749x | 0.9739x | 2/2 |

## Variant 99

Accumulate8 vector-variance samples per packet while preserving wrapping32-bit sum/error semantics.

| Case | Pair1 | Pair2 | Median | Slower pairs |
|---|---:|---:|---:|---:|
| BenchmarkX64Round2Variance/16 | 1.2872x | 1.2959x | 1.2916x | 0/2 |
| BenchmarkX64Round2Variance/256 | 4.5692x | 4.5597x | 4.5644x | 0/2 |
| BenchmarkX64Round2Variance/64 | 2.6577x | 2.6717x | 2.6647x | 0/2 |


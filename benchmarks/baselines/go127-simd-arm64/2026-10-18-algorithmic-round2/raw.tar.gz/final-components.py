from pathlib import Path
import os,json,hashlib,subprocess,re,statistics
D=Path('/private/tmp/govpx-iterations100');O=D/'final-components';O.mkdir(exist_ok=True);env=os.environ|{'GOMAXPROCS':'1'}
plans={'pixel':'^BenchmarkX64Round2Flat$','encoder':'^BenchmarkX64Round2(Yrd|EdgeStats)$'}
bind={'base':'b57aac772af29e85f4b5b34ae33600cc84cd6a0f','head':'7cc9a0f4dace308315bdf19121f28ee912cfbbc5','PGO':'off','CGO':1,'GOMAXPROCS':1,'Go':'1.27.2','hardware':'Apple M4 Max','binaries':{}}
samples={}
for name in ['b57','final']:
 for kind in plans:
  f=D/f'{name}-{kind}';bind['binaries'][name+'-'+kind]=hashlib.sha256(f.read_bytes()).hexdigest()
(O/'binding.json').write_text(json.dumps(bind,indent=2)+'\n')
for rnd,order in enumerate([['b57','final'],['final','b57']],1):
 for ref in order:
  for kind,bench in plans.items():
   cmd=[str(D/f'{ref}-{kind}'),'-test.run=^$','-test.bench='+bench,'-test.benchtime=40ms','-test.cpu=1','-test.count=1','-test.benchmem'];r=subprocess.run(cmd,cwd=D,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(O/f'r{rnd}-{ref}-{kind}.txt').write_text(repr(cmd)+'\n'+r.stdout);assert r.returncode==0,r.stdout;rows={}
   for l in r.stdout.splitlines():
    m=re.match(r'(Benchmark\S+)\s+\d+\s+(\S+) ns/op\s+0 B/op\s+0 allocs/op',l)
    if m:rows[m[1]]=float(m[2])
   assert rows,(ref,kind);samples[rnd,ref,kind]=rows
summary={}
for kind in plans:
 for name in samples[1,'b57',kind]:
  raw={ref:[samples[i,ref,kind][name] for i in [1,2]] for ref in ['b57','final']};ratios=[a/b for a,b in zip(raw['b57'],raw['final'])];summary[name]={'raw_ns':raw,'paired_speedups':ratios,'median_speedup':statistics.median(ratios),'preliminary':True}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('M4final component cases',len(summary),flush=True)
for name,v in summary.items():print(name,round(v['median_speedup'],3),flush=True)

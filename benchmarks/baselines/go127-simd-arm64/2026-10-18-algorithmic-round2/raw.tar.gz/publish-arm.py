from pathlib import Path
import json,subprocess,difflib,shutil,tarfile,hashlib
D=Path('/private/tmp/govpx-iterations100');R=Path('/Users/thesyncim/GolandProjects/govpx');out=D/'arm-evidence';out.mkdir(exist_ok=True);raw=out/'raw';raw.mkdir(exist_ok=True)
accepted={51,*range(53,66),68,69,70};s=json.loads((D/'arm-summary.json').read_text());basebind=json.loads((D/'base-binding.json').read_text())['sources']
(raw/'shared-source-hashes.json').write_text(json.dumps(basebind,indent=2)+'\n')
ledger=['id\thypothesis\tdecision\tmedian_speedup_range\tpaired_speedups\tcorrectness\tnotes']
for n,v in s.items():
 i=int(n);p=next(p for p in D.glob(n+'-*') if p.is_dir());b=json.loads((D/(p.name+'-binding.json')).read_text());patch=''
 for path,digest in b['sources'].items():
  if path.endswith('_test.go') or digest==basebind.get(path):continue
  a=D/'base'/path;z=p/path
  patch+=''.join(difflib.unified_diff(a.read_text().splitlines(True) if a.exists() else [],z.read_text().splitlines(True),fromfile='a/'+path,tofile='b/'+path))
 (raw/(n+'.patch')).write_text(patch)
 name='activity-direct-coefficient-reconstruction' if i==71 else v['name'][3:]
 cases=list(v['cases'].values());ratios=[x['median_speedup'] for x in cases];notes={52:'flat input win; dense mixed/no clear gain',59:'YRD source storage reuse; regex also recorded unchanged keyrd controls',66:'dense control loses',67:'mixed/regresses',71:'dense control loses',72:'mixed/no clear gain',73:'within short-screen noise',74:'repeated-value cache overhead loses',75:'reciprocal cache overhead loses'}.get(i,'native component retained; codec benefit is separate')
 ledger.append('\t'.join([n,name,'keep' if i in accepted else 'reject',f'{min(ratios):.6f}..{max(ratios):.6f}',json.dumps({k:x['speedup_pairs'] for k,x in v['cases'].items()},separators=(',',':')),'PASS frozen b57 exact-state + setup oracle',notes]))
 shutil.copy2(D/(p.name+'-build.log'),raw/(p.name+'-build.log'))
 condensed={'binary_sha256':b['binary_sha256'],'shared_sources':'shared-source-hashes.json','source_overrides':{k:v for k,v in b['sources'].items() if basebind.get(k)!=v},'absent_sources':[k for k in basebind if k not in b['sources']],'original_binding_sha256':hashlib.sha256((D/(p.name+'-binding.json')).read_bytes()).hexdigest()}
 (raw/(p.name+'-binding.json')).write_text(json.dumps(condensed,indent=2)+'\n')
 for f in D.glob(n+'-r*-*.txt'):shutil.copy2(f,raw/f.name)
(out/'arm-ledger.tsv').write_text('\n'.join(ledger)+'\n')
for name in ['baseline.json','arm-summary.json','arm-composition.json','vp8-stream-comparison.json','root-retained-tests.log','root-vp9-keepers-tests.log','build.py','time.py','confirm.py','whole.py','prepare.py','prepare-next.py','prepare-last.py','replace71.py','fix-setup-test.py','extend-setup.py','compose.py','resolve.py','streams.py','final-root-proof.py']:
 shutil.copy2(D/name,raw/name)
for f in D.glob('composition-r*-*.txt'):shutil.copy2(f,raw/f.name)
shutil.copy2(D/'51-activity-one-q/vp8_algorithm_round2_test.go',raw/'component-shared-fixture.go.txt')
shutil.copy2(R/'vp8_algorithm_round2_test.go',raw/'retained-correctness-fixture.go.txt')
shutil.copytree(D/'whole-root',raw/'whole-root',dirs_exist_ok=True)
with tarfile.open(out/'arm-raw.tar.gz','w:gz') as tf:
 for p in sorted(raw.rglob('*')):
  if p.is_file():tf.add(p,arcname=str(p.relative_to(raw)))
(out/'SHA256SUMS').write_text(hashlib.sha256((out/'arm-raw.tar.gz').read_bytes()).hexdigest()+'  arm-raw.tar.gz\n')
print('arm evidence ready',len(s),'iterations', (out/'arm-raw.tar.gz').stat().st_size,'bytes')

# Final combined native quick result

https://github.com/thesyncim/govpx/actions/runs/39149274752

Head 7cc9a0f4dace308315bdf19121f28ee912cfbbc5; baseline b57aac772af29e85f4b5b34ae33600cc84cd6a0f

AMD EPYC7763. Actual SDK AVX2=true, AVX512=false, Enabled=true on both variants. All ordinary oracle commands passed, including corrected Metrics/UV boundaries.144 component cases,576 timing samples, all zero allocation. No C/full/profile runs. Two40ms AB/BA pairs and one whole pair per scope are preliminary.

| WholeVP9scope | Parentms | Currentms | Time delta | Allocations/frame |
|---|---:|---:|---:|---:|
| 320 | 3.965675 | 3.944695 | -0.5290% | 0.616666667=0.616666667 |
| 1280 | 26.310652 | 26.181637 | -0.4904% | 1.250000000=1.250000000 |

All22 output/semantic fields equal in both whole scope pairs. The1.5× codec throughput gate remains unmet.

Speedup below = parent/current; summary median is ratio of medians. Every control and loss is retained.

## BenchmarkX64Round2Copy8

| Case | Parentns | Currentns | Speedup | Paired speedups |
|---|---|---|---:|---|
| ./internal/pixel:BenchmarkX64Round2Copy8/32 | 11.67,9.514 | 9.297,9.206 | 1.1449x | 1.2552x,1.0335x |
| ./internal/pixel:BenchmarkX64Round2Copy8/8 | 10.16,9.545 | 9.235,9.205 | 1.0686x | 1.1002x,1.0369x |

## BenchmarkX64Round2FP

| Case | Parentns | Currentns | Speedup | Paired speedups |
|---|---|---|---:|---|
| ./internal/pixel:BenchmarkX64Round2FP/n16/dc/optional0 | 25.26,26.72 | 22.16,22.31 | 1.1689x | 1.1399x,1.1977x |
| ./internal/pixel:BenchmarkX64Round2FP/n16/dc/optional1 | 25.85,27.2 | 21.8,21.91 | 1.2137x | 1.1858x,1.2414x |
| ./internal/pixel:BenchmarkX64Round2FP/n16/dc/optional2 | 27.09,27.45 | 22.41,22.76 | 1.2074x | 1.2088x,1.2061x |
| ./internal/pixel:BenchmarkX64Round2FP/n16/dc/optional3 | 28.05,28.09 | 22.73,22.78 | 1.2336x | 1.2341x,1.2331x |
| ./internal/pixel:BenchmarkX64Round2FP/n16/dense/optional0 | 26.19,26.31 | 23.1,23.11 | 1.1361x | 1.1338x,1.1385x |
| ./internal/pixel:BenchmarkX64Round2FP/n16/dense/optional1 | 26.53,26.49 | 24.48,23.06 | 1.1153x | 1.0837x,1.1487x |
| ./internal/pixel:BenchmarkX64Round2FP/n16/dense/optional2 | 28.41,28.47 | 23.99,24.03 | 1.1845x | 1.1842x,1.1848x |
| ./internal/pixel:BenchmarkX64Round2FP/n16/dense/optional3 | 29.01,29.0 | 24.33,24.37 | 1.1912x | 1.1924x,1.1900x |
| ./internal/pixel:BenchmarkX64Round2FP/n16/zero/optional0 | 24.43,24.33 | 21.5,21.56 | 1.1324x | 1.1363x,1.1285x |
| ./internal/pixel:BenchmarkX64Round2FP/n16/zero/optional1 | 25.22,25.24 | 21.53,21.83 | 1.1637x | 1.1714x,1.1562x |
| ./internal/pixel:BenchmarkX64Round2FP/n16/zero/optional2 | 25.91,25.86 | 24.01,21.41 | 1.1398x | 1.0791x,1.2078x |
| ./internal/pixel:BenchmarkX64Round2FP/n16/zero/optional3 | 27.1,27.13 | 21.25,21.22 | 1.2769x | 1.2753x,1.2785x |
| ./internal/pixel:BenchmarkX64Round2FP/n256/dc/optional0 | 36.32,36.25 | 36.09,40.95 | 0.9420x | 1.0064x,0.8852x |
| ./internal/pixel:BenchmarkX64Round2FP/n256/dc/optional1 | 41.53,41.33 | 38.97,39.05 | 1.0620x | 1.0657x,1.0584x |
| ./internal/pixel:BenchmarkX64Round2FP/n256/dc/optional2 | 39.76,39.73 | 40.21,40.42 | 0.9859x | 0.9888x,0.9829x |
| ./internal/pixel:BenchmarkX64Round2FP/n256/dc/optional3 | 44.56,44.0 | 43.43,43.11 | 1.0233x | 1.0260x,1.0206x |
| ./internal/pixel:BenchmarkX64Round2FP/n256/dense/optional0 | 51.85,51.86 | 56.97,52.29 | 0.9492x | 0.9101x,0.9918x |
| ./internal/pixel:BenchmarkX64Round2FP/n256/dense/optional1 | 59.29,55.9 | 58.21,61.67 | 0.9609x | 1.0186x,0.9064x |
| ./internal/pixel:BenchmarkX64Round2FP/n256/dense/optional2 | 66.6,66.42 | 67.53,67.89 | 0.9823x | 0.9862x,0.9783x |
| ./internal/pixel:BenchmarkX64Round2FP/n256/dense/optional3 | 83.84,68.6 | 68.46,69.12 | 1.1080x | 1.2247x,0.9925x |
| ./internal/pixel:BenchmarkX64Round2FP/n256/zero/optional0 | 36.05,35.94 | 37.17,36.88 | 0.9722x | 0.9699x,0.9745x |
| ./internal/pixel:BenchmarkX64Round2FP/n256/zero/optional1 | 42.08,40.97 | 42.97,38.88 | 1.0147x | 0.9793x,1.0538x |
| ./internal/pixel:BenchmarkX64Round2FP/n256/zero/optional2 | 42.74,38.38 | 40.83,39.22 | 1.0134x | 1.0468x,0.9786x |
| ./internal/pixel:BenchmarkX64Round2FP/n256/zero/optional3 | 43.1,42.06 | 41.14,41.56 | 1.0297x | 1.0476x,1.0120x |
| ./internal/pixel:BenchmarkX64Round2FP/n32/dc/optional0 | 31.46,31.56 | 23.9,23.48 | 1.3301x | 1.3163x,1.3441x |
| ./internal/pixel:BenchmarkX64Round2FP/n32/dc/optional1 | 33.39,33.36 | 24.93,24.93 | 1.3387x | 1.3394x,1.3381x |
| ./internal/pixel:BenchmarkX64Round2FP/n32/dc/optional2 | 35.23,35.32 | 26.46,28.38 | 1.2865x | 1.3314x,1.2445x |
| ./internal/pixel:BenchmarkX64Round2FP/n32/dc/optional3 | 37.4,37.43 | 26.19,26.24 | 1.4272x | 1.4280x,1.4264x |
| ./internal/pixel:BenchmarkX64Round2FP/n32/dense/optional0 | 34.44,34.33 | 24.32,24.37 | 1.4124x | 1.4161x,1.4087x |
| ./internal/pixel:BenchmarkX64Round2FP/n32/dense/optional1 | 35.2,35.27 | 28.1,28.08 | 1.2544x | 1.2527x,1.2561x |
| ./internal/pixel:BenchmarkX64Round2FP/n32/dense/optional2 | 38.93,38.97 | 30.46,30.24 | 1.2834x | 1.2781x,1.2887x |
| ./internal/pixel:BenchmarkX64Round2FP/n32/dense/optional3 | 40.27,40.25 | 31.2,30.7 | 1.3008x | 1.2907x,1.3111x |
| ./internal/pixel:BenchmarkX64Round2FP/n32/zero/optional0 | 30.61,30.69 | 23.43,23.44 | 1.3079x | 1.3064x,1.3093x |
| ./internal/pixel:BenchmarkX64Round2FP/n32/zero/optional1 | 32.7,32.91 | 23.98,24.21 | 1.3615x | 1.3636x,1.3594x |
| ./internal/pixel:BenchmarkX64Round2FP/n32/zero/optional2 | 34.0,34.06 | 25.64,26.64 | 1.3018x | 1.3261x,1.2785x |
| ./internal/pixel:BenchmarkX64Round2FP/n32/zero/optional3 | 36.43,36.45 | 27.01,24.65 | 1.4108x | 1.3488x,1.4787x |
| ./internal/pixel:BenchmarkX64Round2FP/n64/dc/optional0 | 25.69,25.04 | 24.62,24.72 | 1.0282x | 1.0435x,1.0129x |
| ./internal/pixel:BenchmarkX64Round2FP/n64/dc/optional1 | 26.55,26.71 | 26.96,25.99 | 1.0059x | 0.9848x,1.0277x |
| ./internal/pixel:BenchmarkX64Round2FP/n64/dc/optional2 | 27.16,27.12 | 28.81,27.23 | 0.9686x | 0.9427x,0.9960x |
| ./internal/pixel:BenchmarkX64Round2FP/n64/dc/optional3 | 28.71,28.73 | 29.04,29.0 | 0.9897x | 0.9886x,0.9907x |
| ./internal/pixel:BenchmarkX64Round2FP/n64/dense/optional0 | 28.04,27.73 | 27.42,27.52 | 1.0151x | 1.0226x,1.0076x |
| ./internal/pixel:BenchmarkX64Round2FP/n64/dense/optional1 | 29.75,29.65 | 29.02,29.13 | 1.0215x | 1.0252x,1.0179x |
| ./internal/pixel:BenchmarkX64Round2FP/n64/dense/optional2 | 31.52,31.46 | 32.13,32.24 | 0.9784x | 0.9810x,0.9758x |
| ./internal/pixel:BenchmarkX64Round2FP/n64/dense/optional3 | 33.33,33.45 | 33.39,33.86 | 0.9930x | 0.9982x,0.9879x |
| ./internal/pixel:BenchmarkX64Round2FP/n64/zero/optional0 | 24.63,24.61 | 25.57,24.69 | 0.9797x | 0.9632x,0.9968x |
| ./internal/pixel:BenchmarkX64Round2FP/n64/zero/optional1 | 26.17,26.22 | 25.61,25.98 | 1.0155x | 1.0219x,1.0092x |
| ./internal/pixel:BenchmarkX64Round2FP/n64/zero/optional2 | 25.86,25.88 | 25.85,26.59 | 0.9867x | 1.0004x,0.9733x |
| ./internal/pixel:BenchmarkX64Round2FP/n64/zero/optional3 | 27.16,27.11 | 26.78,27.52 | 0.9994x | 1.0142x,0.9851x |

## BenchmarkX64Round2Flat

| Case | Parentns | Currentns | Speedup | Paired speedups |
|---|---|---|---:|---|
| ./internal/pixel:BenchmarkX64Round2Flat/kind16/verticalfalse/dense | 40.83,41.25 | 41.65,41.52 | 0.9869x | 0.9803x,0.9935x |
| ./internal/pixel:BenchmarkX64Round2Flat/kind16/verticalfalse/flat | 172.8,172.7 | 176.3,180.2 | 0.9691x | 0.9801x,0.9584x |
| ./internal/pixel:BenchmarkX64Round2Flat/kind16/verticalfalse/nearflat | 52.01,51.8 | 51.71,51.86 | 1.0023x | 1.0058x,0.9988x |
| ./internal/pixel:BenchmarkX64Round2Flat/kind16/verticaltrue/dense | 53.54,46.27 | 46.97,54.22 | 0.9864x | 1.1399x,0.8534x |
| ./internal/pixel:BenchmarkX64Round2Flat/kind16/verticaltrue/flat | 400.7,405.3 | 402.1,404.6 | 0.9991x | 0.9965x,1.0017x |
| ./internal/pixel:BenchmarkX64Round2Flat/kind16/verticaltrue/nearflat | 63.66,63.74 | 64.48,64.54 | 0.9874x | 0.9873x,0.9876x |
| ./internal/pixel:BenchmarkX64Round2Flat/kind8/verticalfalse/dense | 40.6,40.88 | 40.97,40.92 | 0.9950x | 0.9910x,0.9990x |
| ./internal/pixel:BenchmarkX64Round2Flat/kind8/verticalfalse/flat | 116.5,107.9 | 68.2,77.31 | 1.5422x | 1.7082x,1.3957x |
| ./internal/pixel:BenchmarkX64Round2Flat/kind8/verticalfalse/nearflat | 51.87,51.71 | 51.6,51.99 | 0.9999x | 1.0052x,0.9946x |
| ./internal/pixel:BenchmarkX64Round2Flat/kind8/verticaltrue/dense | 54.01,46.37 | 47.2,51.82 | 1.0137x | 1.1443x,0.8948x |
| ./internal/pixel:BenchmarkX64Round2Flat/kind8/verticaltrue/flat | 152.7,152.2 | 74.58,74.94 | 2.0392x | 2.0475x,2.0310x |
| ./internal/pixel:BenchmarkX64Round2Flat/kind8/verticaltrue/nearflat | 66.5,63.62 | 64.76,64.42 | 1.0073x | 1.0269x,0.9876x |

## BenchmarkX64Round2Macro

| Case | Parentns | Currentns | Speedup | Paired speedups |
|---|---|---|---:|---|
| ./internal/pixel:BenchmarkX64Round2Macro/verticalfalse/dense | 38.26,38.07 | 38.0,38.16 | 1.0022x | 1.0068x,0.9976x |
| ./internal/pixel:BenchmarkX64Round2Macro/verticalfalse/edge | 66.7,66.85 | 69.0,68.64 | 0.9703x | 0.9667x,0.9739x |
| ./internal/pixel:BenchmarkX64Round2Macro/verticalfalse/flat | 66.79,66.84 | 48.82,49.05 | 1.3654x | 1.3681x,1.3627x |
| ./internal/pixel:BenchmarkX64Round2Macro/verticaltrue/dense | 69.25,69.01 | 69.48,70.07 | 0.9908x | 0.9967x,0.9849x |
| ./internal/pixel:BenchmarkX64Round2Macro/verticaltrue/edge | 151.3,151.9 | 151.7,152.7 | 0.9961x | 0.9974x,0.9948x |
| ./internal/pixel:BenchmarkX64Round2Macro/verticaltrue/flat | 151.2,150.9 | 79.9,80.02 | 1.8891x | 1.8924x,1.8858x |

## BenchmarkX64Round2Plane

| Case | Parentns | Currentns | Speedup | Paired speedups |
|---|---|---|---:|---|
| ./internal/pixel:BenchmarkX64Round2Plane/w128/h16/pad0 | 158.6,160.3 | 118.1,119.3 | 1.3433x | 1.3429x,1.3437x |
| ./internal/pixel:BenchmarkX64Round2Plane/w128/h16/pad17 | 158.5,158.8 | 118.0,118.5 | 1.3416x | 1.3432x,1.3401x |
| ./internal/pixel:BenchmarkX64Round2Plane/w128/h64/pad0 | 592.2,593.9 | 430.3,428.6 | 1.3810x | 1.3762x,1.3857x |
| ./internal/pixel:BenchmarkX64Round2Plane/w128/h64/pad17 | 593.4,594.2 | 426.9,491.9 | 1.2926x | 1.3900x,1.2080x |
| ./internal/pixel:BenchmarkX64Round2Plane/w16/h16/pad0 | 76.74,47.33 | 20.41,20.39 | 3.0409x | 3.7599x,2.3212x |
| ./internal/pixel:BenchmarkX64Round2Plane/w16/h16/pad17 | 76.21,47.44 | 36.14,40.9 | 1.6050x | 2.1087x,1.1599x |
| ./internal/pixel:BenchmarkX64Round2Plane/w16/h64/pad0 | 210.6,173.8 | 50.24,53.22 | 3.7154x | 4.1919x,3.2657x |
| ./internal/pixel:BenchmarkX64Round2Plane/w16/h64/pad17 | 174.9,173.7 | 151.8,128.3 | 1.2446x | 1.1522x,1.3539x |
| ./internal/pixel:BenchmarkX64Round2Plane/w64/h16/pad0 | 92.16,92.16 | 53.61,50.02 | 1.7786x | 1.7191x,1.8425x |
| ./internal/pixel:BenchmarkX64Round2Plane/w64/h16/pad17 | 91.98,92.02 | 68.88,69.47 | 1.3300x | 1.3354x,1.3246x |
| ./internal/pixel:BenchmarkX64Round2Plane/w64/h64/pad0 | 353.1,353.6 | 175.8,213.0 | 1.8176x | 2.0085x,1.6601x |
| ./internal/pixel:BenchmarkX64Round2Plane/w64/h64/pad17 | 373.0,353.0 | 263.7,266.1 | 1.3703x | 1.4145x,1.3266x |

## BenchmarkX64Round2Projection

| Case | Parentns | Currentns | Speedup | Paired speedups |
|---|---|---|---:|---|
| ./internal/pixel:BenchmarkX64Round2Projection/average | 17.5,17.53 | 10.9,12.52 | 1.4957x | 1.6055x,1.4002x |
| ./internal/pixel:BenchmarkX64Round2Projection/cols16 | 124.4,124.5 | 89.25,89.54 | 1.3921x | 1.3938x,1.3904x |
| ./internal/pixel:BenchmarkX64Round2Projection/cols64 | 295.1,295.8 | 159.1,165.2 | 1.8221x | 1.8548x,1.7906x |

## BenchmarkX64Round2SADLimit

| Case | Parentns | Currentns | Speedup | Paired speedups |
|---|---|---|---:|---|
| ./internal/pixel:BenchmarkX64Round2SADLimit/10000 | 12.73,12.7 | 12.72,12.71 | 1.0000x | 1.0008x,0.9992x |
| ./internal/pixel:BenchmarkX64Round2SADLimit/2000 | 5.411,5.0 | 4.982,4.996 | 1.0434x | 1.0861x,1.0008x |
| ./internal/pixel:BenchmarkX64Round2SADLimit/40000 | 24.36,25.99 | 23.48,25.69 | 1.0240x | 1.0375x,1.0117x |
| ./internal/pixel:BenchmarkX64Round2SADLimit/65000 | 24.43,24.43 | 19.77,17.34 | 1.3166x | 1.2357x,1.4089x |

## BenchmarkX64Round2Subpel

| Case | Parentns | Currentns | Speedup | Paired speedups |
|---|---|---|---:|---|
| ./internal/pixel:BenchmarkX64Round2Subpel/n16/halffalse/axis0 | 31.16,31.12 | 32.75,32.89 | 0.9488x | 0.9515x,0.9462x |
| ./internal/pixel:BenchmarkX64Round2Subpel/n16/halffalse/axis1 | 29.45,29.29 | 35.28,32.86 | 0.8620x | 0.8348x,0.8914x |
| ./internal/pixel:BenchmarkX64Round2Subpel/n16/halffalse/axis2 | 43.17,42.8 | 43.84,43.88 | 0.9801x | 0.9847x,0.9754x |
| ./internal/pixel:BenchmarkX64Round2Subpel/n16/halftrue/axis0 | 31.17,31.22 | 32.77,32.94 | 0.9495x | 0.9512x,0.9478x |
| ./internal/pixel:BenchmarkX64Round2Subpel/n16/halftrue/axis1 | 29.23,29.27 | 32.96,36.85 | 0.8380x | 0.8868x,0.7943x |
| ./internal/pixel:BenchmarkX64Round2Subpel/n16/halftrue/axis2 | 43.08,42.89 | 44.04,44.27 | 0.9735x | 0.9782x,0.9688x |
| ./internal/pixel:BenchmarkX64Round2Subpel/n64/halffalse/axis0 | 325.0,324.0 | 305.1,312.7 | 1.0505x | 1.0652x,1.0361x |
| ./internal/pixel:BenchmarkX64Round2Subpel/n64/halffalse/axis1 | 300.0,300.0 | 281.6,270.9 | 1.0860x | 1.0653x,1.1074x |
| ./internal/pixel:BenchmarkX64Round2Subpel/n64/halffalse/axis2 | 487.8,488.6 | 463.1,466.5 | 1.0503x | 1.0533x,1.0474x |
| ./internal/pixel:BenchmarkX64Round2Subpel/n64/halftrue/axis0 | 324.6,323.8 | 289.7,299.6 | 1.1003x | 1.1205x,1.0808x |
| ./internal/pixel:BenchmarkX64Round2Subpel/n64/halftrue/axis1 | 300.3,301.2 | 228.0,225.6 | 1.3261x | 1.3171x,1.3351x |
| ./internal/pixel:BenchmarkX64Round2Subpel/n64/halftrue/axis2 | 488.9,489.6 | 292.9,293.5 | 1.6687x | 1.6692x,1.6681x |

## BenchmarkX64Round2UV

| Case | Parentns | Currentns | Speedup | Paired speedups |
|---|---|---|---:|---|
| ./internal/pixel:BenchmarkX64Round2UV/verticalfalse/kind4/dense | 50.86,50.75 | 50.64,53.84 | 0.9725x | 1.0043x,0.9426x |
| ./internal/pixel:BenchmarkX64Round2UV/verticalfalse/kind4/edge | 61.42,58.77 | 52.99,52.37 | 1.1408x | 1.1591x,1.1222x |
| ./internal/pixel:BenchmarkX64Round2UV/verticalfalse/kind4/flat | 67.72,59.88 | 57.5,52.73 | 1.1576x | 1.1777x,1.1356x |
| ./internal/pixel:BenchmarkX64Round2UV/verticalfalse/kind6/dense | 52.69,52.9 | 50.63,52.55 | 1.0234x | 1.0407x,1.0067x |
| ./internal/pixel:BenchmarkX64Round2UV/verticalfalse/kind6/edge | 64.35,66.74 | 65.14,65.29 | 1.0051x | 0.9879x,1.0222x |
| ./internal/pixel:BenchmarkX64Round2UV/verticalfalse/kind6/flat | 64.39,66.87 | 52.49,52.76 | 1.2471x | 1.2267x,1.2674x |
| ./internal/pixel:BenchmarkX64Round2UV/verticaltrue/kind4/dense | 61.0,61.07 | 64.96,61.83 | 0.9628x | 0.9390x,0.9877x |
| ./internal/pixel:BenchmarkX64Round2UV/verticaltrue/kind4/edge | 80.69,80.8 | 85.74,83.67 | 0.9532x | 0.9411x,0.9657x |
| ./internal/pixel:BenchmarkX64Round2UV/verticaltrue/kind4/flat | 80.95,80.47 | 64.41,65.36 | 1.2439x | 1.2568x,1.2312x |
| ./internal/pixel:BenchmarkX64Round2UV/verticaltrue/kind6/dense | 61.14,64.27 | 61.65,61.87 | 1.0153x | 0.9917x,1.0388x |
| ./internal/pixel:BenchmarkX64Round2UV/verticaltrue/kind6/edge | 95.03,97.84 | 96.34,96.44 | 1.0005x | 0.9864x,1.0145x |
| ./internal/pixel:BenchmarkX64Round2UV/verticaltrue/kind6/flat | 95.45,95.62 | 64.21,65.98 | 1.4676x | 1.4865x,1.4492x |

## BenchmarkX64Round2Variance

| Case | Parentns | Currentns | Speedup | Paired speedups |
|---|---|---|---:|---|
| ./internal/pixel:BenchmarkX64Round2Variance/16 | 10.48,10.46 | 7.787,7.836 | 1.3403x | 1.3458x,1.3349x |
| ./internal/pixel:BenchmarkX64Round2Variance/256 | 123.7,122.2 | 32.66,26.84 | 4.1328x | 3.7875x,4.5529x |
| ./internal/pixel:BenchmarkX64Round2Variance/64 | 31.65,31.62 | 12.18,11.59 | 2.6618x | 2.5985x,2.7282x |

## BenchmarkX64Round2EdgeStats

| Case | Parentns | Currentns | Speedup | Paired speedups |
|---|---|---|---:|---|
| ./internal/vp9/encoder:BenchmarkX64Round2EdgeStats/size16/x0/y0 | 44.63,44.47 | 42.55,48.58 | 0.9777x | 1.0489x,0.9154x |
| ./internal/vp9/encoder:BenchmarkX64Round2EdgeStats/size16/x0/y40 | 416.2,392.8 | 212.1,211.6 | 1.9094x | 1.9623x,1.8563x |
| ./internal/vp9/encoder:BenchmarkX64Round2EdgeStats/size16/x40/y0 | 45.3,44.74 | 41.3,41.38 | 1.0890x | 1.0969x,1.0812x |
| ./internal/vp9/encoder:BenchmarkX64Round2EdgeStats/size16/x40/y40 | 397.8,391.7 | 212.4,211.2 | 1.8638x | 1.8729x,1.8546x |
| ./internal/vp9/encoder:BenchmarkX64Round2EdgeStats/size64/x0/y0 | 5756.0,5742.0 | 1266.0,1269.0 | 4.5357x | 4.5466x,4.5248x |
| ./internal/vp9/encoder:BenchmarkX64Round2EdgeStats/size64/x0/y40 | 5726.0,5814.0 | 1123.0,1159.0 | 5.0570x | 5.0988x,5.0164x |
| ./internal/vp9/encoder:BenchmarkX64Round2EdgeStats/size64/x40/y0 | 6391.0,6269.0 | 1917.0,2134.0 | 3.1252x | 3.3339x,2.9377x |
| ./internal/vp9/encoder:BenchmarkX64Round2EdgeStats/size64/x40/y40 | 6428.0,6220.0 | 1291.0,1342.0 | 4.8036x | 4.9791x,4.6349x |

## BenchmarkX64Round2SSE

| Case | Parentns | Currentns | Speedup | Paired speedups |
|---|---|---|---:|---|
| ./internal/vp9/encoder:BenchmarkX64Round2SSE/16 | 36.93,33.13 | 30.61,30.89 | 1.1392x | 1.2065x,1.0725x |
| ./internal/vp9/encoder:BenchmarkX64Round2SSE/32 | 214.6,214.1 | 98.95,97.52 | 2.1820x | 2.1688x,2.1954x |
| ./internal/vp9/encoder:BenchmarkX64Round2SSE/64 | 643.6,643.9 | 186.2,196.5 | 3.3643x | 3.4565x,3.2768x |
| ./internal/vp9/encoder:BenchmarkX64Round2SSE/8 | 39.8,35.53 | 18.76,24.04 | 1.7600x | 2.1215x,1.4780x |

## BenchmarkX64Round2Yrd

| Case | Parentns | Currentns | Speedup | Paired speedups |
|---|---|---|---:|---|
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx16/size16/constant | 121.2,120.4 | 66.7,66.46 | 1.8144x | 1.8171x,1.8116x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx16/size16/dense | 164.2,163.8 | 173.6,167.9 | 0.9605x | 0.9459x,0.9756x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx16/size16/zero | 81.34,80.23 | 86.28,86.34 | 0.9360x | 0.9427x,0.9292x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx16/size64/constant | 1018.0,1017.0 | 344.3,361.5 | 2.8833x | 2.9567x,2.8133x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx16/size64/dense | 1669.0,1683.0 | 1580.0,1595.0 | 1.0557x | 1.0563x,1.0552x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx16/size64/zero | 280.7,281.3 | 285.3,287.9 | 0.9805x | 0.9839x,0.9771x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx4/size16/constant | 1206.0,1204.0 | 626.4,625.0 | 1.9258x | 1.9253x,1.9264x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx4/size16/dense | 1313.0,1303.0 | 623.1,622.0 | 2.1010x | 2.1072x,2.0949x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx4/size16/zero | 1191.0,1199.0 | 78.41,77.9 | 15.2901x | 15.1894x,15.3915x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx4/size64/constant | 18206.0,18252.0 | 8942.0,8960.0 | 2.0365x | 2.0360x,2.0371x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx4/size64/dense | 19743.0,19703.0 | 8924.0,8990.0 | 2.2020x | 2.2123x,2.1917x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx4/size64/zero | 18056.0,18037.0 | 276.5,279.0 | 64.9739x | 65.3020x,64.6487x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx8/size16/constant | 140.2,140.0 | 67.19,69.99 | 2.0426x | 2.0866x,2.0003x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx8/size16/dense | 174.0,173.5 | 185.7,186.9 | 0.9326x | 0.9370x,0.9283x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx8/size16/zero | 83.41,80.14 | 86.1,85.95 | 0.9506x | 0.9688x,0.9324x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx8/size64/constant | 1350.0,1344.0 | 344.2,358.8 | 3.8321x | 3.9221x,3.7458x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx8/size64/dense | 1808.0,1797.0 | 1838.0,1855.0 | 0.9762x | 0.9837x,0.9687x |
| ./internal/vp9/encoder:BenchmarkX64Round2Yrd/tx8/size64/zero | 283.5,287.1 | 288.0,286.2 | 0.9937x | 0.9844x,1.0031x |


Preliminary native feedback: 144 cases, 576 zero-allocation samples; two whole VP9 scope pairs, all 22 output fields match. All losses remain in summary.json. No acceptance speed claim.

from pathlib import Path
import tarfile,json,subprocess,hashlib,shutil,io
R=Path('/Users/thesyncim/GolandProjects/govpx');E=R/'benchmarks/baselines/go127-simd-arm64/2026-10-18-algorithmic-round2';E.mkdir(parents=True,exist_ok=True)
B=R/'scripts/x64-round2';archive=E/'x64-source-overlays.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(B.rglob('*')):
  if p.is_file():tf.add(p,arcname=str(p.relative_to(R)))
 bad=subprocess.check_output(['git','show','dd5873e98dbe963ff55f8a9e6d1f3f815daec3a5:scripts/x64-round2/fixtures2/internal/vp9/encoder/x64_round2_native_test.go.txt'],cwd=R)
 info=tarfile.TarInfo('history/dd5873e9/encoder-fixture-with-invalid-Y-overflow-expectation.go.txt');info.size=len(bad);tf.addfile(info,io.BytesIO(bad))
for source,dest in [('manifest.json','x64-cohort-first.json'),('manifest-second.json','x64-cohort-second.json')]:
 m=json.loads((B/source).read_text());m['bundle_archive']=str(archive.relative_to(R));(E/dest).write_text(json.dumps(m,indent=2)+'\n')
# Verify every virtual blob referenced by each archived manifest, without a build.
with tarfile.open(archive) as tf:
 members={m.name:tf.extractfile(m).read() for m in tf.getmembers()}
for dest in ['x64-cohort-first.json','x64-cohort-second.json']:
 m=json.loads((E/dest).read_text())
 for source in list(m['fixtures'].values())+[p for v in m['variants'] for p in v['files'].values()]:
  assert members[source]==(R/source).read_bytes(),source
shutil.rmtree(B)
print('archived exact experiment bundle:',archive.stat().st_size,'bytes')

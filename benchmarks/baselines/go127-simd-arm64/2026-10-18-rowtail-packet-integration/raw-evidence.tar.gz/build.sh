#!/bin/sh
set -eu
export CODEX_AGENT_ID=root-rowtail53-build CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go GOEXPERIMENT=simd GOMAXPROCS=2 GOFLAGS=-p=2 CGO_ENABLED=1
r=/Users/thesyncim/GolandProjects/govpx
p=/private/tmp/govpx-rowtail53-proof
for variant in parent candidate; do
  src=/private/tmp/govpx-rowtail53
  if [ "$variant" = parent ]; then src=/private/tmp/govpx-rowtail53-parent; fi
  "$r/scripts/go.sh" -C "$src" test -pgo=off -c -o "$p/$variant-pixel.test" ./internal/pixel
  "$r/scripts/go.sh" -C "$src" test -pgo=off -c -o "$p/$variant-dsp.test" ./internal/vp8/dsp
  "$r/scripts/go.sh" -C "$src" build -pgo=off -o "$p/$variant-whole" ./cmd/govpx-bench
done

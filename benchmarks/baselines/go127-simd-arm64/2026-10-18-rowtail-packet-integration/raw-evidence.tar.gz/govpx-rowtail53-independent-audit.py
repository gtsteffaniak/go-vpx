from pathlib import Path
import json,hashlib,re,statistics
p=Path('/private/tmp/govpx-rowtail53-proof');b=json.loads((p/'binding.json').read_text());s=json.loads((p/'summary.json').read_text());H=lambda z:hashlib.sha256(z).hexdigest();q={'scope':'Independent read-only audit; no builds/tests/timing rerun','source':{},'components':{},'codegen':{}};bh=H((p/'binding.json').read_bytes());maps={}
for v,z in b['variants'].items():
 r=Path(z['source']);a={str(f.relative_to(r)):H(f.read_bytes())for f in r.rglob('*.go')};assert a==z['all_go_sha256'];maps[v]=a;q['source'][v]={'count':len(a),'all_match':True,'binaries':z['binaries']}
 for x in z['binaries'].values():assert H(Path(x['path']).read_bytes())==x['sha256']and Path(x['path']).stat().st_size==x['bytes']
assert H(Path(b['old691']['path']).read_bytes())==b['old691']['sha256']
q['source_delta']=[f for f in sorted(set(maps['parent'])|set(maps['candidate']))if maps['parent'].get(f)!=maps['candidate'].get(f)];assert q['source_delta']==['internal/pixel/loopfilter_rowvalues_arm64.go','scripts/gensimd.go']
# Every fixture is source-identical by the complete maps except the two production deltas above.
pat=re.compile(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op\s+([\d.]+) B/op\s+([\d.]+) allocs/op',re.M);a={};counts={}
orders=[['parent','candidate','old691'],['candidate','old691','parent'],['old691','parent','candidate'],['old691','candidate','parent'],['parent','old691','candidate'],['candidate','parent','old691']]
for mode in ['preflight','components','whole']:
 d=p/('native-'+mode);c=json.loads((d/'commands.json').read_text());assert c['binding_sha256']==bh and c['excluded_from_performance']==(mode=='preflight');counts[mode]=0
 assert c['orders']==([['parent','candidate']]if mode=='preflight'else([['parent','candidate'],['candidate','parent']]*3 if mode=='components'else orders));assert len(c['measurements'])=={'preflight':6,'components':36,'whole':18}[mode]
 for z in c['measurements']:
  i,v,t=z['round'],z['variant'],z['type'];assert z['exit_code']==0and z['start_utc']<z['end_utc'];assert z['command'][0]==(b['old691']['path']if v=='old691'else b['variants'][v]['binaries'][t]['path'])
  if mode=='whole':continue
  txt=(d/f'r{i}-{v}-{t}.txt').read_text();rs=pat.findall(txt);assert len(rs)=={'pixel':12,'dsp':24,'decoder':10}[t]and len({x[0]for x in rs})==len(rs)and '\nPASS\n'in txt
  for n,ns,by,al in rs:assert float(by)==float(al)==0;a[mode,i,v,n]=float(ns);counts[mode]+=1
assert counts['components']==552and counts['preflight']==92
for n in sorted({n for mode,i,v,n in a if mode=='components'}):
 vs={v:[a['components',i,v,n]for i in range(1,7)]for v in ['parent','candidate']};r=[x/y for x,y in zip(vs['parent'],vs['candidate'])];m=statistics.median(vs['parent'])/statistics.median(vs['candidate']);assert m==s['components'][n]['median_speedup']and r==s['components'][n]['pair_speedups'];q['components'][n]={'raw_ns':vs,'median_speedup':m,'pairs':r,'faster':sum(x>1for x in r),'slower':sum(x<1for x in r)}
ign={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'};w={v:[json.loads((p/'native-whole'/f'r{i}-{v}-whole.txt').read_text())for i in range(1,7)]for v in ['parent','candidate','old691']};sem={k:v for k,v in w['parent'][0].items()if k not in ign};assert len(sem)==22and all({k:v for k,v in z.items()if k not in ign}==sem and z['allocs_per_frame']==0for ds in w.values()for z in ds);ns={v:[x['ns_per_frame']for x in ds]for v,ds in w.items()};med={v:statistics.median(x)for v,x in ns.items()};q['whole']={'raw_ns':ns,'all22semantic_fields':sem,'all18allocations_zero':True,'comparisons':{}}
for v in ['parent','old691']:
 r=[100*(x/y-1)for x,y in zip(ns['candidate'],ns[v])];m=100*(med['candidate']/med[v]-1);assert r==s['whole']['paired_candidate_time_change_pct'][v]and m==s['whole']['candidate_time_change_pct'][v];q['whole']['comparisons'][v]={'median_time_change_pct':m,'paired_time_change_pct':r,'faster':sum(x<0for x in r),'slower':sum(x>0for x in r)}
for v in ['parent','candidate']:
 ins=re.findall(r'^[0-9a-f]+:\s+(.+)$',(p/(v+'-store-LLVM.txt')).read_text(),re.M);ret=next(i for i,x in enumerate(ins)if x.strip()=='ret');q['codegen'][v]={'total':len(ins),'through_first_ret':ret+1,'panicBounds_calls':sum('panicBounds'in x and x.startswith('bl')for x in ins),'hot_calls':[x for x in ins[:ret+1]if x.startswith('bl\t')]};assert len(ins)==(280 if v=='parent'else 180)and ret+1==(217 if v=='parent'else 177)
q['counts']=counts;q['binding_sha256']=bh;q['judgment']='Discretionary componentKEEP:12store cases all72pairs faster,13–15.6%median, improvedcodegen/provenbounds; belowmandatory1.5. Whole−.35968%5/6small/one+.7969%loss; no stablewholegain or gapclosureclaim. Same-runold−2.79668%median4/6faster but old6.867–7.455msstrongvariance. Hunchangedcontrolgain is caller/layoutdiagnostic, not Hkernelgain.'
out=Path('/private/tmp/govpx-rowtail53-independent-audit.json');out.write_text(json.dumps(q,indent=2)+'\n');print(out);print(H(out.read_bytes()));print(q['codegen']);print(q['whole']['comparisons'])
for cat in ['RowTail','verticaltrue','verticalfalse','Picker']:
 z=[v for n,v in q['components'].items()if cat in n];print(cat,len(z),'range',min(x['median_speedup']for x in z),max(x['median_speedup']for x in z),'slowerpairs',sum(x['slower']for x in z))

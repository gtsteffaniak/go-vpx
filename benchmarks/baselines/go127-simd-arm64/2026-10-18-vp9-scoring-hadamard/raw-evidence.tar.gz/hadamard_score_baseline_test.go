package encoder
// Benchmark shim for the exact old BlockYrd call shape. It delegates to the
// unchanged parent production transforms; it does not introduce a new kernel.
func hadamardBlockYrd(src []int16,stride int,coeff []int16,n int) {
 if n==16 {hadamard16x16Into(src,stride,coeff)} else {hadamard8x8Into(src,stride,coeff)}
}

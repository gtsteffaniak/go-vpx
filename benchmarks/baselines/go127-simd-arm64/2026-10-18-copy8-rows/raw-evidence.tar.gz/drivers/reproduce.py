#!/usr/bin/python3
"""Explicitly rerun the final native copy8 experiment; never changes a checkout."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True, type=Path)
parser.add_argument('--work', required=True, type=Path, help='New private directory')
parser.add_argument('--go', default='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go')
args = parser.parse_args()
package = Path(__file__).resolve().parent.parent
metadata = json.loads((package/'environment.json').read_text())
args.work.mkdir(parents=True, exist_ok=False)
env = os.environ.copy()
env.update(GO=args.go, GOTOOLCHAIN='local', GOEXPERIMENT='simd',
           CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',
           CODEX_AGENT_ID='ci-copy8-reproduction', GOFLAGS='-p=2', GOMAXPROCS='2')
commands = []

def run(cmd, logfile, runenv=None):
    commands.append(cmd)
    with logfile.open('w') as output:
        output.write(repr(cmd)+'\n')
        output.flush()
        subprocess.run(cmd, cwd=args.repo, env=runenv or env, stdout=output,
                       stderr=subprocess.STDOUT, check=True)

for name, source in [('parent','parent'),('candidate','candidate'),('asm','oldbuild')]:
    revision = metadata['oldbuild_head'] if name == 'asm' else metadata['parent_head']
    snapshot = args.work/name
    snapshot.mkdir()
    archive = subprocess.check_output(['git','archive',revision], cwd=args.repo)
    with tarfile.open(fileobj=io.BytesIO(archive)) as contents:
        contents.extractall(snapshot)
    for src in (package/'sources'/source).rglob('*'):
        if src.is_file():
            target = snapshot/src.relative_to(package/'sources'/source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src,target)
wrapper = str(args.repo/'scripts/go.sh')
selected = str(args.work/'candidate')
for extra, label, testsenv in [([], 'ordinary', env),
                               (['-race','-gcflags=all=-d=checkptr=2'], 'race-checkptr', env),
                               (['-tags=purego'], 'purego', env),
                               ([], 'nosimd', dict(env,GOEXPERIMENT='nosimd'))]:
    packages = ['./internal/vp8/dsp','.'] if label in ('purego','nosimd') else ['./internal/pixel','./internal/vp8/dsp','.']
    run([wrapper,'-C',selected,'test','-pgo=off']+extra+packages+
        ['-run','TestCopy8Rows|TestCopyBlocks','-count=1'],args.work/(label+'.log'),testsenv)
for name in ('parent','candidate','asm'):
    for pkg, label in [('./internal/vp8/dsp','dsp'),('.','root')]:
        run([wrapper,'-C',str(args.work/name),'test','-pgo=off','-c','-o',
             str(args.work/(name+'-'+label+'.test')),pkg],args.work/(name+'-'+label+'-build.log'))
    run([wrapper,'-C',str(args.work/name),'build','-pgo=off','-o',
         str(args.work/(name+'-bench')),'./cmd/govpx-bench'],args.work/(name+'-cli-build.log'))
timing_env = dict(env,GOMAXPROCS='1')
for name in ('parent','candidate','asm'):
    for pkg in ('root','dsp'):
        run([str(args.work/(name+'-'+pkg+'.test')),'-test.run=TestCopy8RowsPublicState',
             '-test.bench=^BenchmarkCopy8RowsNative$','-test.benchtime=1x',
             '-test.cpu=1','-test.benchmem'],args.work/(name+'-'+pkg+'-fixture1x.log'),timing_env)
orders = [('candidate','asm','parent'),('parent','asm','candidate'),
          ('asm','parent','candidate'),('candidate','parent','asm'),
          ('parent','candidate','asm'),('asm','candidate','parent')]
for index, order in enumerate(orders,1):
    for name in order:
        for pkg in (('root','dsp') if index%2 else ('dsp','root')):
            run([str(args.work/(name+'-'+pkg+'.test')),'-test.run=^$',
                 '-test.bench=^BenchmarkCopy8RowsNative$','-test.benchtime=100ms',
                 '-test.cpu=1','-test.benchmem'],
                args.work/('round%d-%s-%s.log'%(index,name,pkg)),timing_env)
rows = []
for frames in (60,300):
    for index, order in enumerate(orders,1):
        for name in order:
            cmd = [str(args.work/(name+'-bench')),'-codec=vp8','-width=1280','-height=720',
                   '-frames='+str(frames),'-fps=30','-bitrate=2500','-mode=realtime',
                   '-cpu-used=8','-threads=1','-encode-only','-auto-libvpx=false','-format=json']
            commands.append(cmd)
            result = subprocess.run(cmd,cwd=args.repo,env=timing_env,text=True,capture_output=True,check=True)
            (args.work/('public%d-round%d-%s.json'%(frames,index,name))).write_text(result.stdout)
            (args.work/('public%d-round%d-%s.stderr'%(frames,index,name))).write_text(result.stderr)
            rows.append(dict(frames=frames,round=index,variant=name,command=cmd,result=json.loads(result.stdout)))
        (args.work/'public-samples.json').write_text(json.dumps(dict(samples=rows),indent=2)+'\n')
(args.work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')

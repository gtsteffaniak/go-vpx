from pathlib import Path
import subprocess,os,json,statistics
p=Path('/private/tmp/govpx-next-copy8-rows');repo=Path('/Users/thesyncim/GolandProjects/govpx');mode=__import__('sys').argv[1];env=dict(os.environ,CODEX_AGENT_ID='ci-copy8',CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',GOTOOLCHAIN='local',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',GOMAXPROCS='2',GOFLAGS='-p=2');commands=[]
if mode=='build':
 for v in ['parent','candidate','oldbuild']:
  cmd=[str(repo/'scripts/go.sh'),'-C',str(p/v),'build','-pgo=off','-o',str(p/(v+'-bench')),'./cmd/govpx-bench'];commands.append(cmd)
  with (p/(v+'-cli-build.log')).open('w') as f:subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 (p/'cli-build-commands.json').write_text(json.dumps(commands,indent=2)+'\n');print('CLI BUILDS PASS')
else:
 out=p/'public';out.mkdir(exist_ok=False);samples=[];timing=dict(env,GOMAXPROCS='1')
 orders=[['candidate','oldbuild','parent'],['parent','oldbuild','candidate'],['oldbuild','parent','candidate'],['candidate','parent','oldbuild'],['parent','candidate','oldbuild'],['oldbuild','candidate','parent']]
 for frames in [60,300]:
  for r,order in enumerate(orders,1):
   for v in order:
    cmd=[str(p/(v+'-bench')),'-codec=vp8','-width=1280','-height=720','-frames='+str(frames),'-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8','-threads=1','-encode-only','-auto-libvpx=false','-format=json'];commands.append(cmd)
    q=subprocess.run(cmd,cwd=repo,env=timing,text=True,capture_output=True,check=True);(out/f'{frames}-round{r}-{v}.json').write_text(q.stdout);(out/f'{frames}-round{r}-{v}.stderr').write_text(q.stderr);samples.append(dict(frames=frames,round=r,variant=v,command=cmd,result=json.loads(q.stdout)))
   (out/'samples.json').write_text(json.dumps(samples,indent=2)+'\n')
  print('INPUT LENGTH FINISHED',frames,flush=True)
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 summary={};timers={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns'}
 for frames in [60,300]:
  rows=[s for s in samples if s['frames']==frames];variants=['parent','candidate','oldbuild'];med={v:statistics.median(s['result']['ns_per_frame'] for s in rows if s['variant']==v) for v in variants};ratios=[];parity=[]
  for r in range(1,7):
   a={s['variant']:s['result'] for s in rows if s['round']==r};ratios.append((a['candidate']['ns_per_frame']/a['parent']['ns_per_frame']-1)*100);parity.append({k:len({json.dumps(a[v][k],sort_keys=True) for v in variants})==1 for k in a['parent'] if k not in timers})
  summary[frames]={'median_ns_per_frame':med,'candidate_time_change_pct_vs_parent':(med['candidate']/med['parent']-1)*100,'candidate_time_change_pct_vs_oldbuild':(med['candidate']/med['oldbuild']-1)*100,'paired_candidate_time_change_pct_vs_parent':ratios,'faster_pairs':sum(x<0 for x in ratios),'all_23_nontiming_and_allocation_fields_match_all_rounds':all(all(x.values()) for x in parity),'every_field_each_round':parity,'allocations':{v:[s['result']['allocs_per_frame'] for s in rows if s['variant']==v] for v in variants}}
 (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

import os,pathlib,subprocess,json,re,statistics,sys
p=pathlib.Path('/private/tmp/govpx-next-copy8-rows');mode=sys.argv[1];out=p/mode;out.mkdir(exist_ok=False)
orders=[['parent','candidate','oldbuild'],['candidate','oldbuild','parent'],['oldbuild','parent','candidate']] if mode=='screen' else [['candidate','oldbuild','parent'],['parent','oldbuild','candidate'],['oldbuild','parent','candidate'],['candidate','parent','oldbuild'],['parent','candidate','oldbuild'],['oldbuild','candidate','parent']]
env=dict(os.environ,GOMAXPROCS='1');samples=[];commands=[]
for r,order in enumerate(orders,1):
 for v in order:
  for api in (['dsp','root'] if r%2 else ['root','dsp']):
   cmd=[str(p/(v+'-'+api+'.test')),'-test.run=^$','-test.bench=^BenchmarkCopy8RowsNative$','-test.benchtime='+('75ms' if mode=='screen' else '100ms'),'-test.cpu=1','-test.benchmem'];commands.append(cmd)
   raw=subprocess.check_output(cmd,env=env,text=True,stderr=subprocess.STDOUT);(out/f'round{r}-{v}-{api}.log').write_text(raw)
   for line in raw.splitlines():
    m=re.match(r'(BenchmarkCopy8RowsNative/\S+)\s+\d+\s+([0-9.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',line)
    if m:samples.append(dict(round=r,variant=v,api=api,case=m[1],ns=float(m[2]),B=int(m[3]),allocs=int(m[4])))
 (out/'samples.json').write_text(json.dumps(samples,indent=2)+'\n')
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
summary={}
for api,case in sorted(set((s['api'],s['case']) for s in samples)):
 rows=[s for s in samples if s['api']==api and s['case']==case]
 med={v:statistics.median([s['ns'] for s in rows if s['variant']==v]) for v in ['parent','candidate','oldbuild']}
 ratios=[]
 for r in range(1,len(orders)+1):
  a={s['variant']:s['ns'] for s in rows if s['round']==r};ratios.append(a['parent']/a['candidate'])
 summary[api+'/'+case]={'medians_ns':med,'parent_over_candidate':med['parent']/med['candidate'],'oldbuild_over_candidate':med['oldbuild']/med['candidate'],'paired_parent_over_candidate':ratios,'all_zero_allocation_readings':all(s['B']==s['allocs']==0 for s in rows)}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(mode,'complete',len(samples),'samples')
for k,v in summary.items():print(k,round(v['parent_over_candidate'],6),'minpair',round(min(v['paired_parent_over_candidate']),6),'faster',sum(x>1 for x in v['paired_parent_over_candidate']))

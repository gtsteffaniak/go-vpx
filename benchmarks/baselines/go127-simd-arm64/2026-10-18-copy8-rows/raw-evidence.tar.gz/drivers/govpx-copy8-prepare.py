from pathlib import Path
import subprocess,tarfile,io,shutil,json
repo=Path('/Users/thesyncim/GolandProjects/govpx');work=Path('/private/tmp/govpx-next-copy8-rows');work.mkdir(exist_ok=False)
base='f8dd8c7472e91c1f147511b04ceec716aca95aa7';old='691cd0512c4829d9ee40d483205dd223f9eb028d'
for label,rev in [('parent',base),('candidate',base),('oldbuild',old)]:
 p=work/label;p.mkdir()
 raw=subprocess.check_output(['git','archive',rev],cwd=repo)
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:
  t.extractall(p,members=[m for m in t.getmembers() if not m.name.startswith('benchmarks/')])
for f in ['copy16_rows_native_test.go','internal/vp8/dsp/copy16_rows_native_test.go']:
 s=(repo/f).read_text().replace('16','8').replace('15*','7*')
 # Expose the actual untouched root and DSP eight-row entry points.
 s=s.replace('copyMacroblockY','copyMacroblock8x8').replace('Copy8x8','Copy8x8')
 target=f.replace('copy16','copy8')
 for label in ['parent','candidate','oldbuild']:
  p=work/label/target;p.write_text(s)
p=work/'candidate'
(p/'internal/pixel/copy8_rows_arm64.go').write_text('''//go:build goexperiment.simd && arm64 && !purego

package pixel

import "unsafe"

// Copy8Rows preserves libvpx v1.16.0 vp8/common/reconinter.c row order.
// Exact eight-byte row dataflow is adapted from goav1 recon_gosimd.go.
// Each full row is loaded before its store, preserving per-row memmove aliases.
func Copy8Rows(src []byte, ss int, dst []byte, ds int) bool {
 if !Enabled || (uint(ss)|uint(ds))>>30 != 0 || 7*ss+8 > len(src) || 7*ds+8 > len(dst) { return false }
 sp,dp := unsafe.Pointer(unsafe.SliceData(src)),unsafe.Pointer(unsafe.SliceData(dst))
 for row:=0;row<8;row++ {
  v:=*(*uint64)(unsafe.Add(sp,row*ss))
  *(*uint64)(unsafe.Add(dp,row*ds))=v
 }
 return true
}
''')
(p/'internal/pixel/copy8_rows_other.go').write_text('''//go:build !goexperiment.simd || !arm64 || purego

package pixel

func Copy8Rows(src []byte, ss int, dst []byte, ds int) bool { return false }
''')
f=p/'vp8_encoder_denoiser.go';s=f.read_text();a='func copyMacroblock8x8(dst []byte, dstStride int, src []byte, srcStride int) {\n';assert s.count(a)==1;s=s.replace(a,a+'\tif pixel.Copy8Rows(src, srcStride, dst, dstStride) { return }\n');f.write_text(s)
f=p/'internal/vp8/dsp/recon.go';s=f.read_text();a='func Copy8x8(src []byte, srcStride int, dst []byte, dstStride int) {\n';assert s.count(a)==1;s=s.replace(a,a+'\tif pixel.Copy8Rows(src, srcStride, dst, dstStride) { return }\n');f.write_text(s)
s=(repo/'internal/pixel/copy16_rows_arm64_test.go').read_text().replace('16','8').replace('15*','7*')
(p/'internal/pixel/copy8_rows_arm64_test.go').write_text(s)
# Record exact provenance; no Git changes in root.
(work/'provenance.json').write_text(json.dumps({'parent':base,'oldbuild':old,'copied_goav1_file':'internal/av1/encoder/recon_gosimd.go','goav1_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/Users/thesyncim/GolandProjects/goav1',text=True).strip(),'snapshots_omit_only_benchmark_evidence_directory':True},indent=2)+'\n')
print(work)

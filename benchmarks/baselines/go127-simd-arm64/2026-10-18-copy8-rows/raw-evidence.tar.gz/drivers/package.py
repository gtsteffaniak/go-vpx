from pathlib import Path
import os,shutil,hashlib,json,subprocess,tarfile,re,statistics
repo=Path('/Users/thesyncim/GolandProjects/govpx');work=Path('/private/tmp/govpx-next-copy8-rows');out=Path('/private/tmp/govpx-copy8-final-ready')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((work/'provenance.json').read_text());meta.update(parent_head=meta['parent'],oldbuild_head=meta['oldbuild'],compiler='Go 1.27.2-X:simd',GOEXPERIMENT='simd',GOAMD64='not applicable native ARM64',GOARCH='arm64',GOOS='darwin',PGO='off',benchmark_GOMAXPROCS=1,encoder_threads=1,cpu='Apple M4 Max (benchmark runtime header)',macos='26.3.1(a), build25D771280a',wrapper=str(repo/'scripts/go.sh'),CODEX_AGENT_ID='ci-copy8',initial_screen_scope='Exploratory only: parent reports an overlapping read-only git/hash audit; not pooled into fresh acceptance results.',final_source_frozen_before_fresh_component_and_whole_runs=True)
(out/'environment.json').write_text(json.dumps(meta,indent=2)+'\n')
for folder in ['screen','final','public','initial-source','guard-outlined-source']:
 shutil.copytree(work/folder,out/folder)
for label in ['parent','oldbuild']:
 for f in ['internal/vp8/dsp/recon.go','vp8_encoder_denoiser.go','copy8_rows_native_test.go','internal/vp8/dsp/copy8_rows_native_test.go']:
  p=out/'sources'/label/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(work/label/f,p)
# Exact original copied source and license, pinned without reading a possibly dirty sibling tree.
for f in ['internal/av1/encoder/recon_gosimd.go','LICENSE']:
 data=subprocess.check_output(['git','show',meta['goav1_head']+':'+f],cwd='/Users/thesyncim/GolandProjects/goav1')
 p=out/'upstream-goav1'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
for f in work.iterdir():
 if f.is_file() and (f.suffix in ['.log','.txt','.json']):
  p=out/('codegen' if ('llvm' in f.name or 'inliner' in f.name) else 'validation')/f.name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,p)
for name in ['prepare','build','build-final','measure','public']:
 src=Path('/private/tmp/govpx-copy8-'+name+'.py');p=out/'drivers'/src.name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,p)
# Reproduction is explicit and isolated, retaining the established project wrapper protocol.
s=(Path('/private/tmp/govpx-copy16-final-ready/drivers/reproduce.py').read_text().replace('copy16','copy8').replace('Copy16','Copy8'))
(out/'drivers/reproduce.py').write_text(s)
shutil.copy2('/private/tmp/govpx-copy8-package.py',out/'drivers/package.py')
sourcehash={};binaries={}
for label in ['parent','candidate','oldbuild']:
 sourcehash[label]={}
 for p in sorted((work/label).rglob('*')):
  if p.is_file() and (p.suffix in ['.go','.s','.h'] or p.name in ['go.mod','go.sum']):sourcehash[label][str(p.relative_to(work/label))]=sha(p)
 for suffix in ['root.test','dsp.test','bench']:
  p=work/(label+'-'+suffix);binaries[p.name]=sha(p)
(out/'all-go-asm-module-source-sha256.json').write_text(json.dumps(sourcehash,indent=2)+'\n');(out/'executable-sha256.json').write_text(json.dumps(binaries,indent=2)+'\n')
summary=json.loads((out/'final/summary.json').read_text());screen=json.loads((out/'screen/summary.json').read_text());public=json.loads((out/'public/summary.json').read_text())
# Independently recalculate all key claims from raw benchmark rows and public JSON.
rawsamples={}
for stage,rounds in [('screen',3),('final',6)]:
 rows=[]
 for p in sorted((out/stage).glob('round*-*.log')):
  r,v,api=re.match(r'round(\d+)-(parent|candidate|oldbuild)-(root|dsp)\.log',p.name).groups()
  t=p.read_text();assert t.rstrip().endswith(('PASS','ok')) or '\nPASS\n' in t
  for l in t.splitlines():
   m=re.match(r'(BenchmarkCopy8RowsNative/\S+)\s+(\d+)\s+([0-9.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',l)
   if m:rows.append(dict(round=int(r),variant=v,api=api,case=m[1],ns=float(m[3]),B=int(m[4]),allocs=int(m[5])))
 assert len(rows)==16*3*rounds and all(x['B']==x['allocs']==0 for x in rows)
 saved=json.loads((out/stage/'samples.json').read_text());assert sorted(rows,key=lambda x:tuple(map(str,x.values())))==sorted(saved,key=lambda x:tuple(map(str,x.values())))
 rawsamples[stage]={'case_count':16,'rounds':rounds,'variants':3,'raw_samples':len(rows),'all_zero_bytes_and_allocations':True}
 for api,case in sorted({(x['api'],x['case']) for x in rows}):
  rs=[x for x in rows if x['api']==api and x['case']==case];m={v:statistics.median(x['ns'] for x in rs if x['variant']==v) for v in ['parent','candidate','oldbuild']};claim=(summary if stage=='final' else screen)[api+'/'+case]
  assert m==claim['medians_ns']
  assert m['parent']/m['candidate']==claim['parent_over_candidate']
checks={};timers={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns'}
for frames in [60,300]:
 rows=[];ratios=[];oldratios=[]
 for r in range(1,7):
  a={v:json.loads((out/'public'/f'{frames}-round{r}-{v}.json').read_text()) for v in ['parent','candidate','oldbuild']}
  assert len(a['parent'])==27
  fields=[k for k in a['parent'] if k not in timers and k!='allocs_per_frame'];assert len(fields)==22
  assert all(all(a[v][k]==a['parent'][k] for v in a) for k in fields)
  assert all(a[v]['allocs_per_frame']==0 for v in a)
  ratios.append((a['candidate']['ns_per_frame']/a['parent']['ns_per_frame']-1)*100);oldratios.append((a['candidate']['ns_per_frame']/a['oldbuild']['ns_per_frame']-1)*100)
 checks[frames]={'semantic_field_count':22,'semantic_fields_match_every_variant_every_round':True,'allocations_separately_match_zero_every_variant_every_round':True,'raw_json_count':18,'paired_time_pct_vs_parent':ratios,'paired_time_pct_vs_oldbuild':oldratios}
proof={'raw_component_recalculation':rawsamples,'public_deep_audit':checks,'qualifying_case':'root/BenchmarkCopy8RowsNative/pitch8_8/aliasfalse','qualifying_parent_median_speedup':summary['root/BenchmarkCopy8RowsNative/pitch8_8/aliasfalse']['parent_over_candidate'],'qualifying_two_individual_pairs_below_1_5':sum(x<1.5 for x in summary['root/BenchmarkCopy8RowsNative/pitch8_8/aliasfalse']['paired_parent_over_candidate'])==2,'all_final_cases_faster_in_all_six_pairs':all(all(x>1 for x in a['paired_parent_over_candidate']) for a in summary.values()),'whole_encoder_gain_claim':False,'copy_oldbuild_denominator':'compiler-generated Go GPR row copies; not handwritten assembly','whole_oldbuild_control':'original 691 codec assembly, same compiler/native machine/run','final_source_overlay_manifest_sha256':sha(out/'overlay-sha256.json')}
(out/'verification.json').write_text(json.dumps(proof,indent=2)+'\n')
(out/'final-kernel-summary.json').write_text(json.dumps(summary,indent=2)+'\n');(out/'final-public-summary.json').write_text(json.dumps(public,indent=2)+'\n')
table=[]
for k,a in summary.items():
 case=k.replace('/BenchmarkCopy8RowsNative','');m=a['medians_ns'];pairs=a['paired_parent_over_candidate']
 table.append(f"| {case} | {m['parent']:.4f} | {m['candidate']:.4f} | {m['oldbuild']:.4f} | {a['parent_over_candidate']:.6f}× | {min(pairs):.6f}× | {sum(x>1 for x in pairs)}/6 |")
(out/'REPORT.md').write_text('''# ARM Copy8 rows: final component confirmation

Retain the correctness-verified ARM helper and public glue under the user's explicit component rule. A representative packed, disjoint root copy improves **1.556568×** versus its pinned SIMD parent and **1.569303×** versus oldbuild. All six pairs are faster; two individual ratios are below 1.5× (minimum 1.403698×). Padded and other ordinary layouts improve less than 1.5×. Whole-encoder results are small/mixed and do not establish an improvement.

## Provenance and contract

Parent: f8dd8c7472e91c1f147511b04ceec716aca95aa7. Oldbuild: 691cd0512c4829d9ee40d483205dd223f9eb028d. Native Apple M4 Max, macOS26.3.1(a), Go1.27.2 SIMD, PGO off, GOMAXPROCS1/encoder thread1. Exact formatted measured sources are frozen in sources/candidate; overlay-sha256.json pins the seven transplant files. No root checkout, index, branch or README was changed by this experiment.

The eight-byte row dataflow is adapted from goav1 0f40b2bd848d8c5c7bdbaa016f2ced3085f7fc7a internal/av1/encoder/recon_gosimd.go, preserving its pinned source/license under upstream-goav1. No dependency is added. Only SIMD ARM64 selects the helper; AMD64, unsupported architectures, purego and experiment-off use the false stub and existing loops. Eight-by-four and four-byte paths are untouched.

Unsigned stride bounds reject negatives and strides>=2^30 before multiplication. Accepted 7*stride+8 endpoints fit int64 and must lie inside visible slice lengths. Exact source/destination pointer equality with equal strides returns handled only AFTER these checks. Every other accepted row performs one full uint64 load before its store, in original order. Within-row overlap, cross-row alias chains, overlapping/repeated rows, unaligned addresses and different strides remain supported. No terminal pointer is formed. Invalid/short inputs decline before any access or write; original fallback preserves slice-capacity extension and partial-write/panic order.

The compiler already uses one GPR load/store per eight-byte copy. This removes repeated slice checks/address work; it does not replace a memmove call or active handwritten assembly in the copy component. The oldbuild component denominator is compiler-generated Go. Its complete codec separately retains the original assembly.

## Correctness and source layouts

Independent public root/DSP oracles stage each eight-byte row, compare the complete backing allocation and panic outcome, and cover both alias directions, exact aliases, different/zero/overlapping strides, minimal lengths, source-only/destination-only/both short windows, spare capacity and negative/huge strides. Direct ARM tests assert handled/decline behavior, no-write declines, all16×16 source/destination alignments and short exact-alias validation. Final ordinary, race/checkptr2, purego and nosimd tests pass. Parent/candidate/oldbuild one-shot public fixtures all pass before timing.

The initial helper lacked the exact-alias shortcut; its root zero-stride exact-alias control regressed to0.697×. All144 exploratory samples and exact initial sources remain preserved. Parent reports an overlapping read-only source/hash audit during that screen, so it is not acceptance evidence or pooled with final results. An early-return exact-alias layout passed validation but cost83 inline units, over Go's80 budget; it was not timed. Its source and compiler diagnostic are preserved. The equivalent single-return/range-loop final layout costs74 and inlines. No further designs were tried.

## Fresh-six public component measurements

Six balanced three-way permutations,100ms testing.B.Loop per case, root/DSP order alternating by round, exact same fixture source in all variants, full scalar/canary checks and observable outputs. All288 final samples report0 B/op and0 allocs/op; every case improves in all six pairs. Exact-alias no-op controls improve2.531–2.848× but are NOT the acceptance basis. Only the packed disjoint root case establishes the new>=1.5× ordinary-copy gain. No broad ARM/x64 claim is inferred.

| Public case | Parent ns | Candidate ns | Oldbuild ns | Parent/candidate | Minimum paired ratio | Faster pairs |
|---|---:|---:|---:|---:|---:|---:|
'''+ '\n'.join(table)+'''

## Whole VP8 measured separately

Each length uses six fresh balanced parent/candidate/oldbuild permutations:1280×720,60 or300 inputs,30fps,2500kbps,realtime CPU-used+8,one thread,encode-only,PGO off,no libvpx autodetection. CPU-used+8 is adaptive. All22 recorded semantic/configuration fields match exactly in every variant/round, and allocations separately match at zero (23 non-timing fields including allocations). Quality is skipped in this encode-only workload; matching recorded statistics are not a bitstream identity claim.

| Inputs | Parent ms/input | Candidate ms/input | Oldbuild ms/input | Candidate time vs parent | Faster parent pairs | Candidate time vs oldbuild |
|---|---:|---:|---:|---:|---:|---:|
|60|7.3342505|7.3575705|6.5313160|+0.317960%|4/6|+12.650659%|
|300|7.3290805|7.3451660|6.6777765|+0.219475%|2/6|+9.994187%|

Parent paired time ranges are-1.354488%..+1.629794% at60 and-0.408606%..+0.768934% at300. Small mixed results establish no whole-encoder gain. The complete oldbuild codec remains faster. Its assembly gap is scoped to this same native run; no cross-run subtraction or arithmetic attribution is made. Every slower sample and all36 raw JSON/stderr pairs are retained.

## Evidence and reproduction

The frozen overlay/patch, exact original context/identical fixtures, three source layouts, both compiler inliner reports, optimized selected code/callers, source/executable hashes, all432 exploratory+fresh component samples and whole raw/audits are included. verification.json independently recalculates medians, ratios, allocations and all22 semantic fields from raw files. drivers/reproduce.py reconstructs private snapshots via git archive and invokes the root project wrapper; executing it explicitly starts correctness/build/native timing. Original experiment drivers are retained too. No complete source snapshot or binaries are copied. raw-evidence.tar.gz contains the delivery members with an inner SHA manifest; SHA256SUMS covers every outer file except itself.
''')
# Inner archive preserves sources and raw material without requiring .go files in repository baselines.
paths=[p for p in sorted(out.rglob('*')) if p.is_file()]
inner={str(p.relative_to(out)):sha(p) for p in paths}
(out/'raw-member-sha256.json').write_text(json.dumps(inner,indent=2)+'\n')
with tarfile.open(out/'raw-evidence.tar.gz','w:gz') as t:
 for p in paths+[out/'raw-member-sha256.json']:t.add(p,arcname=str(p.relative_to(out)))
outer=[sha(p)+'  '+str(p.relative_to(out)) for p in sorted(out.rglob('*')) if p.is_file()]
(out/'SHA256SUMS').write_text('\n'.join(outer)+'\n')
print(json.dumps({'package':str(out),'members_excluding_SHA256SUMS':len(outer),'manifest_sha256':sha(out/'SHA256SUMS'),'raw_tar_sha256':sha(out/'raw-evidence.tar.gz')},indent=2))

import os,pathlib,subprocess,json
root=pathlib.Path('/Users/thesyncim/GolandProjects/govpx');p=pathlib.Path('/private/tmp/govpx-next-copy8-rows');env=os.environ.copy();env.update(CODEX_AGENT_ID='ci-copy8',CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',GOTOOLCHAIN='local',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',GOMAXPROCS='2',GOFLAGS='-p=2')
cmds=[]
def run(args,label,environ=env):
 cmd=[str(root/'scripts/go.sh'),'-C',str(p/'candidate')]+args;cmds.append(cmd)
 with (p/('final-'+label+'.log')).open('w') as f:subprocess.run(cmd,cwd=root,env=environ,stdout=f,stderr=subprocess.STDOUT,check=True)
run(['test','-pgo=off','./internal/pixel','./internal/vp8/dsp','.','-run','TestCopy8Rows','-count=1'],'ordinary')
run(['test','-pgo=off','-race','-gcflags=all=-d=checkptr=2','./internal/pixel','./internal/vp8/dsp','.','-run','TestCopy8Rows','-count=1'],'race-checkptr')
run(['test','-pgo=off','-tags=purego','./internal/vp8/dsp','.','-run','TestCopy8Rows','-count=1'],'purego')
run(['test','-pgo=off','./internal/vp8/dsp','.','-run','TestCopy8Rows','-count=1'],'nosimd',dict(env,GOEXPERIMENT='nosimd'))
for name in ['candidate']:
 for pkg,label in [('./internal/vp8/dsp','dsp'),('.','root')]:
  cmd=[str(root/'scripts/go.sh'),'-C',str(p/name),'test','-pgo=off','-c','-o',str(p/(name+'-'+label+'.test')),pkg];cmds.append(cmd)
  with (p/('final-'+name+'-'+label+'-build.log')).open('w') as f:subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
  cmd=[str(p/(name+'-'+label+'.test')),'-test.run=TestCopy8RowsPublicState','-test.bench=^BenchmarkCopy8RowsNative$','-test.benchtime=1x','-test.cpu=1','-test.benchmem'];cmds.append(cmd)
  with (p/('final-'+name+'-'+label+'-one-shot.log')).open('w') as f:subprocess.run(cmd,cwd=root,env=dict(env,GOMAXPROCS='1'),stdout=f,stderr=subprocess.STDOUT,check=True)
(p/'final-build-commands.json').write_text(json.dumps(cmds,indent=2)+'\n')
print('ALL BUILDS AND CORRECTNESS PASS')

import json,collections
from pathlib import Path
ns={};exec(Path('/private/tmp/govpx-arm-family-1200/analyze_profiles.py').read_text().split('rules=[')[0],ns)
P=Path('/private/tmp/govpx-arm-family-1200');out={}
for variant,path in [('old691',P/'old691.pgo'),('f8parent',P/'f8parent.pgo'),('prior_f8',Path('/private/tmp/govpx-arm-next-profile/current-1200.pgo'))]:
 samples=ns['parse'](path);groups=collections.defaultdict(collections.Counter)
 for value,stack in samples:
  for name in stack:
   if 'loopFilterMacroInternalFusedHorizontal' in name or any(x in name for x in ['loopFilterHorizontalEdgesYSharedNEON','mbLoopFilterEdgeH16NEON']):fam='luma_horizontal_macro_and_internal';break
   if 'loopFilterMacroInternalFusedVertical' in name or any(x in name for x in ['loopFilterVerticalEdgesYSharedNEON','mbLoopFilterEdgeV16NEON']):fam='luma_vertical_macro_and_internal';break
   if 'SSEPlane16' in name or 'sseBlock16xNDotProd' in name:fam='plane_or_column_sse';break
  else:continue
  groups[fam][stack[0]]+=value
 out[variant]={fam:dict(seconds=round(sum(c.values()),6),flat_leaf_contributions=dict(c.most_common())) for fam,c in groups.items()}
(P/'orientation-and-plane.json').write_text(json.dumps(out,indent=2)+'\n')
for n,o in out.items():print(n,{k:v['seconds'] for k,v in o.items()})

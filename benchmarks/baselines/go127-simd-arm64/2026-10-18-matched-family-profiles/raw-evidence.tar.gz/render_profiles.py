import os,subprocess,json
from pathlib import Path
p=Path('/private/tmp/govpx-arm-family-1200'); root=Path('/Users/thesyncim/GolandProjects/govpx')
env=os.environ.copy();env.update(CODEX_AGENT_ID='ci-arm-family-profile',CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',GOTOOLCHAIN='local',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',GOMAXPROCS='2',GOFLAGS='-p=2')
records=[]
for name,binary in [('old691','/private/tmp/govpx-next-copy8-rows/oldbuild-bench'),('f8parent','/private/tmp/govpx-next-copy8-rows/parent-bench')]:
 for mode in ['flat','cum']:
  args=[str(root/'scripts/go.sh'),'tool','pprof','-top','-nodecount=0','-nodefraction=0']+(['-cum'] if mode=='cum' else [])+[binary,str(p/(name+'.pgo'))]
  with open(p/(name+'-'+mode+'.txt'),'w') as out,open(p/(name+'-'+mode+'.stderr'),'w') as err:r=subprocess.run(args,cwd=root,env=env,stdout=out,stderr=err)
  records.append(dict(argv=args,exit=r.returncode));print(name,mode,r.returncode,flush=True);assert r.returncode==0
(p/'pprof-commands.json').write_text(json.dumps(records,indent=2)+'\n')

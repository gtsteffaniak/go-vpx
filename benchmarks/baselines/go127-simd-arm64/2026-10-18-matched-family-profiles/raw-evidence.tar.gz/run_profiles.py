import hashlib,json,os,subprocess,time
from pathlib import Path
p=Path('/private/tmp/govpx-arm-family-1200')
variants=[('old691','/private/tmp/govpx-next-copy8-rows/oldbuild-bench','cc7e3670376e2033a5d0a04c7fac1044b8901ad56770ef5687963b76a946a33d'),('f8parent','/private/tmp/govpx-next-copy8-rows/parent-bench','0358fba58663a99639fe1348c17311c716cb3ca6fc84477bdc94cda1d1e198ea')]
records=[]
for name,binary,want in variants:
 got=hashlib.sha256(Path(binary).read_bytes()).hexdigest();assert got==want,(name,got)
 args=[binary,'-codec=vp8','-width=1280','-height=720','-frames=1200','-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8','-threads=1','-encode-only','-auto-libvpx=false','-format=json','-cpuprofile='+str(p/(name+'.pgo'))]
 env=os.environ.copy();env['GOMAXPROCS']='1'
 start=time.time();print('START',name,time.strftime('%Y-%m-%dT%H:%M:%S%z'),flush=True)
 with open(p/(name+'.json'),'w') as out,open(p/(name+'.stderr'),'w') as err:r=subprocess.run(args,stdout=out,stderr=err,env=env)
 rec=dict(name=name,binary=binary,sha256=got,argv=args,GOMAXPROCS=1,start_unix=start,end_unix=time.time(),exit=r.returncode)
 records.append(rec);(p/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print('END',name,r.returncode,flush=True);assert r.returncode==0

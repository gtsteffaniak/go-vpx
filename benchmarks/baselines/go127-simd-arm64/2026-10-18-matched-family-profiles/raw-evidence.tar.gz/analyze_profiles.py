import gzip,json,re,collections
from pathlib import Path
P=Path('/private/tmp/govpx-arm-family-1200')
def varint(b,i):
 x=s=0
 while True:
  c=b[i];i+=1;x|=(c&127)<<s
  if c<128:return x,i
  s+=7

def fields(b):
 i=0
 while i<len(b):
  k,i=varint(b,i);n,w=k>>3,k&7
  if w==0:v,i=varint(b,i)
  elif w==2:l,i=varint(b,i);v=b[i:i+l];i+=l
  elif w==1:v=b[i:i+8];i+=8
  elif w==5:v=b[i:i+4];i+=4
  else:raise ValueError(w)
  yield n,w,v

def packed(b):
 if isinstance(b,int):return [b]
 a=[];i=0
 while i<len(b):v,i=varint(b,i);a.append(v)
 return a

def parse(path):
 f=list(fields(gzip.decompress(Path(path).read_bytes())));st=[v.decode() for n,w,v in f if n==6]; funcs={};locs={};types=[]
 for n,w,v in f:
  if n==5:
   d={a:c for a,b,c in fields(v)};funcs[d[1]]=st[d[2]]
  if n==1:
   d={a:c for a,b,c in fields(v)};types.append(st[d[1]])
 for n,w,v in f:
  if n==4:
   fs=list(fields(v));lid=next(c for a,b,c in fs if a==1);lines=[]
   for a,b,c in fs:
    if a==4:
     d={x:z for x,y,z in fields(c)};lines.append(funcs.get(d[1],'<unknown>'))
   locs[lid]=lines
 ci=types.index('cpu');samples=[]
 for n,w,v in f:
  if n==2:
   ls=[];vs=[]
   for a,b,c in fields(v):
    if a==1:ls+=packed(c)
    elif a==2:vs+=packed(c)
   names=[name for lid in ls for name in locs[lid]]
   if names:samples.append((vs[ci]/1e9,names))
 return samples

rules=[
('loop_filter',r'(?:pixel\.(?:[Ll]oopFilter|LoopFilter|storeLF|loadLF|lf[A-Z])|dsp\.(?:loopFilter|mbLoopFilter)|decoder\.applyNormalLoopFilter)'),
('forward_transforms',r'(?:forwardDCT|forwardWalsh|ForwardDCT|ForwardWalsh|walsh4|forward4)'),
('inverse_dc_pair',r'(?:AddConstantPair4|dcOnlyIDCT4x4AddPair|DCOnlyIDCT4x4AddPair)'),
('inverse_other',r'(?:dequantIDCT|idctDequant|inverse4Go|InverseTransform|IDCT4x4Add)'),
('squared_error_variance_sad',r'(?:pixel\.(?:SSE|sse|Stats|pixelStats|Subpel|subpel|SAD|sad)|dsp\.(?:SSE|sse|[Vv]ariance|[Ss]ubpelVariance|[Ss]ad|SAD))'),
('quantization',r'(?:pixel\.Quantize|encoder\.(?:fastQuantize|FastQuantize)|encoder\.(?:quantize|Quantize)[A-Z])'),
('six_tap_prediction',r'(?:pixel\.(?:[Ff]ilter|filterSix|filterVertical|filterHorizontal)|sixTapPredict|SixTapPredict)'),
('residual_gather_subtract',r'(?:Gather|[Rr]esidualGather|Subtract|[Ss]ubtract)'),
('denoise_kernel',r'(?:[Dd]enoiserFilter|DenoiseLuma|[Dd]enoiseComplete|DenoiserComplete)'),
('token_records_and_writer',r'(?:[Cc]oefficientToken|[Cc]oefficient.*Tokens|[Pp]reparedCoefficient|BoolWriter|appendTokenUnchecked|getToken[UY]V?Context|countBlockCoefficient)'),
('copies_and_memmove',r'(?:runtime\.memmove|[Cc]opyMacroblock|[Cc]opyDenoiserNoFilter|pixel\.Copy|dsp\.copyBlock|dsp\.Copy)'),
]
rules=[(a,re.compile(b)) for a,b in rules]
result={}
for variant,path in [('old691',P/'old691.pgo'),('f8parent',P/'f8parent.pgo'),('prior_f8','/private/tmp/govpx-arm-next-profile/current-1200.pgo')]:
 samples=parse(path);total=sum(v for v,s in samples);costs=collections.Counter();leaves=collections.defaultdict(collections.Counter);allleaf=collections.Counter()
 for value,stack in samples:
  allleaf[stack[0]]+=value
  # Attribute each flat sample exactly once, to its nearest recognized semantic ancestor.
  family='other'
  for name in stack:
   found=next((f for f,rx in rules if rx.search(name)),None)
   if found:family=found;break
  costs[family]+=value;leaves[family][stack[0]]+=value
 out=dict(profile=str(path),total_sample_seconds=round(total,6),sample_count=len(samples),families={f:dict(seconds=round(v,6),percent=100*v/total,leaf_functions=dict(leaves[f].most_common())) for f,v in costs.most_common()},flat_functions=dict(allleaf.most_common()))
 result[variant]=out
(P/'family-audit.json').write_text(json.dumps(dict(method='Each CPU sample assigned once by nearest matching operation-family ancestor; leaf retains flat attribution. This is sampled diagnostic data, not timings or causal speed attribution.',rules=[(a,b.pattern) for a,b in rules],profiles=result),indent=2)+'\n')
for variant,out in result.items():
 print(variant,out['total_sample_seconds'])
 for f,v in out['families'].items():print(' ',f,round(v['seconds'],3),round(v['percent'],2))

from pathlib import Path
import shutil
base=Path('/private/tmp/govpx-next-sse8-abs-candidate')
root=Path('/private/tmp/govpx-next-sse8-insert-candidate');shutil.copytree(base,root,dirs_exist_ok=True)
p=root/'internal/pixel/sse_simd.go';s=p.read_text()
import re
# Build both lanes directly from a zero vector instead of broadcasting a lane
# that is immediately overwritten. Exact loads and arithmetic stay identical.
s,n=re.subn(r'archsimd.BroadcastUint64x2\((\*\(\*uint64\)\(unsafe.Add\([^)]+\)\))\)\.SetElem\(1,',r'(archsimd.Uint64x2{}).SetElem(0, \1).SetElem(1,',s)
assert n==2,n;p.write_text(s);print(p)

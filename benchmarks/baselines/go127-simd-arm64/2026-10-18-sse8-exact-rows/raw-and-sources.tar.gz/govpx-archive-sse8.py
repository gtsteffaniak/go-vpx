from pathlib import Path
import hashlib,io,json,statistics,tarfile
base=Path('/private/tmp');repo=Path('/Users/thesyncim/GolandProjects/govpx');out=base/'govpx-sse8-ready';out.mkdir(exist_ok=True);payload={}
for p in base.glob('govpx-next-sse8*'):
 if p.is_file() and p.suffix in ['.py','.log','.txt','.json','.go']:payload[p.name]=p.read_bytes()
 if p.is_dir() and (p/'summary.json').exists():
  for q in p.iterdir():
   if q.is_file() and q.suffix in ['.json','.txt']:payload[p.name+'/'+q.name]=q.read_bytes()
names=['internal/pixel/sse_simd.go','internal/pixel/sse8_rows_simd_test.go','internal/vp8/dsp/sse8_rows_native_test.go','scripts/benchmark-amd64.sh']
for v in ['rows-parent','rows-candidate','unroll-candidate','abs-candidate','abs-unroll-candidate','insert-candidate']:
 for n in names:
  p=base/('govpx-next-sse8-'+v)/n
  if p.exists():payload['sources/'+v+'/'+n]=p.read_bytes()
for n in names:payload['final-production/'+n]=(repo/n).read_bytes()
for n in ['govpx-prepare-sse8-rows.py','govpx-tune-sse8.py','govpx-tune-sse8-insert.py','govpx-archive-sse8.py','govpx-summarize-public.py','govpx-summarize-public-followup.py']:payload[n]=(base/n).read_bytes()
followup=json.loads((base/'govpx-next-sse8-insert-public-followup-summary.json').read_text());data=json.loads((base/'govpx-next-sse8-insert-confirm/summary.json').read_text());whole=json.loads((base/'govpx-next-sse8-insert-public-summary.json').read_text());assert len(data)==36
for v in data.values():assert all(len(v['samples'][k])==6 for k in ['rows-parent','rows-assembly','insert-candidate'])
qual=[v for n,v in data.items() if '/slice8x16/' in n];assert len(qual)==9
minimum=min(a/b for v in qual for a,b in zip(v['samples']['rows-parent'],v['samples']['insert-candidate']));assert minimum>=1.5
for n in names:assert (repo/n).read_bytes()==(base/'govpx-next-sse8-insert-candidate'/n).read_bytes(),n
with tarfile.open(out/'raw-and-sources.tar.gz','w:gz') as t:
 for n,b in sorted(payload.items()):
  info=tarfile.TarInfo(n);info.size=len(b);info.mtime=0;t.addfile(info,io.BytesIO(b))
(out/'raw-sha256.json').write_text(json.dumps({n:hashlib.sha256(b).hexdigest() for n,b in sorted(payload.items())},indent=2)+'\n')
for name,value in [('component-summary',data),('public-summary',whole),('public-followup-summary',followup)]: (out/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n')
env=json.loads((base/'govpx-next-sse8-environment.json').read_text());env['raw_members']=len(payload);env['final_source_sha256']={n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in names};(out/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
report='''# Exact-row SIMD squared error

Apple M4 Max, Go1.27.2 darwin/arm64 archsimd, PGO off, GOMAXPROCS1.
Immediate parent1e8809b63498b77fb6a347b0c085ebfe3c9aab49 (PR37), old assembly
691cd0512c4829d9ee40d483205dd223f9eb028d. Native speed only; Rosetta results
are correctness checks, never x64 performance evidence.

SSE8's bounded path proves h1..64 and nonnegative strides<2^30, then checks
both final eight-byte row endpoints. Exact uint64 row loads need no padding,
including unaligned, zero-stride, overlapping or mutually aliased read-only
rows. Typed unsafe pointers stay live and are never retained or written.
Offsets and unused final increments fit int64. Larger heights and unusual
strides keep the original checked-slice fallback byte for byte, including
h1 with an unused negative or maximal stride and empty geometry behavior.

Pack two rows by inserting both uint64 lanes directly. Compute unsigned byte
Max-Min before widening: this is |a-b| in0..255 for every ordered byte pair,
so squaring is exact. Separate low/high int32 sums cover each row once; an odd
tail accumulates only low8 bytes. At64 rows total SSE<=33,292,800 fits int32.
No new AVX256 state, CPU requirements, assembly, dependencies or production cgo.

Fresh six balanced parent/assembly/current orders,100ms per36 identical public
B.Loop fixtures. Four APIs, three strides8/8,32/37,1312/1320, and random,
maximum-error, identical-pixel patterns. Exact visible spans, origins3/5,
independent per-pixel scalar SSE before/after timing and full backing canaries.
All samples allocate zero. Ranges below cover all three pixel patterns.

| Public API / strides | Parent/current time | Assembly/current time |
|---|---:|---:|
'''
for api in ['slice8x4','slice8x8','slice8x16','pointer8x8']:
 for pitch in ['8-8','32-37','1312-1320']:
  rows=[v for n,v in data.items() if '/'+api+'/pitch'+pitch+'/' in n];assert len(rows)==3
  speeds=[v['speedups']['insert-candidate'] for v in rows];assembly=[statistics.median(v['samples']['rows-assembly'])/statistics.median(v['samples']['insert-candidate']) for v in rows]
  report+=f'| {api} / {pitch} | {min(speeds):.4f}–{max(speeds):.4f}x | {min(assembly):.4f}–{max(assembly):.4f}x |\n'
report+=f'''
All nine8x16 cases qualify: median {min(v['speedups']['insert-candidate'] for v in qual):.4f}–{max(v['speedups']['insert-candidate'] for v in qual):.4f}x parent;
all54 paired samples exceed {minimum:.4f}x. Keep this correctness-verified
component gain independently of whole-codec changes. Other sizes remain
below1.5x parent; eight/sixteen-row and pointer paths still include assembly
deficits. This does not establish blanket assembly parity.

Whole synthetic1280x720 VP8, realtime CPU8,2500kbps,one thread, six balanced
orders, separate from kernel timing (positive means more time/slower):
'''
for frames,v in whole.items():report+=f"\n* {frames}frames: {v['vs_parent_percent']:+.4f}% versus parent ({v['faster_parent_pairs']}/6 faster), {v['vs_assembly_percent']:+.4f}% versus old assembly ({v['faster_assembly_pairs']}/6 faster).\n"
v=followup['60'];report+=f"\nFresh separate60-frame follow-up: {v['vs_parent_percent']:+.4f}% versus parent ({v['faster_parent_pairs']}/6 faster), {v['vs_assembly_percent']:+.4f}% versus old assembly ({v['faster_assembly_pairs']}/6 faster). Retain both runs; do not replace the first regression with this follow-up.\n"
report+='''
All23 non-timing fields and every allocation sample match, with zero allocations.
These output statistics do not assert bitstream identity. Shared-desktop timing
and varied assembly samples do not support causal/additive claims across runs.
The whole ARM assembly gap remains open. No libvpx C result is inferred from
these assembly comparisons; C has its own native CI job and quality scope.

Correctness: full native suite passes, ARM race/checkptr2 passes, x64 checkptr2
under Rosetta passes, and actual AVX-off fallback passes (SIMD-only tests
explicitly skip there). New tests exercise720 disjoint +720 mutual-alias calls,
14 short-window panics, unused extreme strides, odd/boundary/fallback heights,
and every one of65,536 ordered byte pairs in512 eight-by-sixteen calls.
Independent static review verified arithmetic, endpoints, pointer lifetime,
odd tails, fallback equivalence and live benchmark scope. The first private
full-suite run lacked two upstream C control-table fixtures; both its failure
and the successful rerun with exact pinned fixture hashes are retained.
Refreshed PGO and repository gates are logged. Native x64 performance awaits
this successor PR's exact-head CI; its harness retains246 controls and adds36
public fixtures, both new source hashes and focused selected/race checks.

Every diagnostic, rejected variant, raw sample and source snapshot is retained.
The initial row-pointer-only change topped out below1.5x. Four-row unrolling
alone did not qualify; byte absolute differences helped16-row cases, and
removing the overwritten broadcast produced the selected winner. Fresh runs
confirm it independently of those exploratory measurements. Generated code
is diagnostic evidence, never a substitute for timing. No competing local
Go builds/tests/profiles ran during native measurements. README files are
untouched; experiment records belong here.
'''
for a,b in [('Go1.27.2','Go 1.27.2'),('GOMAXPROCS1','GOMAXPROCS=1'),('parent1e','parent 1e'),('h1..64','h=1..64'),('in0..255','in 0..255'),('At64','At 64'),('per36','per 36'),('strides8/8','strides 8/8'),('all54','all 54'),('nine8x16','nine 8x16'),('below1.5x','below 1.5x'),('synthetic1280x720','synthetic 1280x720'),('CPU8,2500kbps,one','CPU 8, 2500 kbps, one'),('300frames','300 frames'),('60frames','60 frames'),('separate60-frame','separate 60-frame'),('All23','All 23'),('exercise720','exercise 720'),('+720','+720'),('of65,536','of 65,536'),('in512','in 512'),('retains246','retains 246'),('adds36','adds 36'),('helped16-row','helped 16-row')]: report=report.replace(a,b)
(out/'REPORT.md').write_text(report);print(out,len(payload))

import pathlib,os,subprocess,re,json,statistics
out=pathlib.Path('/private/tmp/govpx-next-sse8-insert-confirm');out.mkdir(exist_ok=True)
bins={v:'/private/tmp/govpx-next-sse8-'+v+'.test' for v in ['rows-parent','rows-assembly','insert-candidate']};rows={v:{} for v in bins};env=dict(os.environ,GOMAXPROCS='1')
for r,order in enumerate([['rows-parent','rows-assembly','insert-candidate'],['rows-assembly','insert-candidate','rows-parent'],['insert-candidate','rows-parent','rows-assembly'],['rows-parent','insert-candidate','rows-assembly'],['insert-candidate','rows-assembly','rows-parent'],['rows-assembly','rows-parent','insert-candidate']],1):
 for v in order:
  p=subprocess.run([bins[v],'-test.run=^$','-test.bench=^BenchmarkSSE8RowsNative$','-test.benchtime=100ms','-test.count=1','-test.cpu=1','-test.benchmem'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (out/f'{r}-{v}.txt').write_text(p.stdout);assert p.returncode==0,p.stdout
  matches=re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op[^\n]*?\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout,re.M);assert len(matches)==36,len(matches)
  for n,ns,b,a in matches:assert b==a=='0';rows[v].setdefault(n,[]).append(float(ns))
 print('round',r,'done',flush=True)
x={n:{'samples':{v:rows[v][n] for v in bins},'speedups':{v:statistics.median(rows['rows-parent'][n])/statistics.median(rows[v][n]) for v in bins}} for n in rows['rows-parent']}
(out/'summary.json').write_text(json.dumps(x,indent=2)+'\n')
for v in bins:
 if v.startswith('rows-'):continue
 print(v,'range',min(x[n]['speedups'][v] for n in x),max(x[n]['speedups'][v] for n in x),'qualifying',sum(x[n]['speedups'][v]>=1.5 for n in x),flush=True)
 for n in x:
  if n.endswith('pattern0'):print(n,x[n]['speedups'][v],flush=True)

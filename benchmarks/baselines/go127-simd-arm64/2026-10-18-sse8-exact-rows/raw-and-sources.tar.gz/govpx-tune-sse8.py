from pathlib import Path
import shutil
base=Path('/private/tmp/govpx-next-sse8-rows-candidate')
for variant in ['unroll','abs','abs-unroll']:
 root=Path('/private/tmp/govpx-next-sse8-'+variant+'-candidate')
 shutil.copytree(base,root,dirs_exist_ok=True)
 p=root/'internal/pixel/sse_simd.go';s=p.read_text()
 if 'abs' in variant:
  old='dl := widen8(a).Sub(widen8(b))\n\t\t\tdh := widen8(highBytes(a)).Sub(widen8(highBytes(b)))'
  new='d := a.Max(b).Sub(a.Min(b))\n\t\t\tdl := widen8(d)\n\t\t\tdh := widen8(highBytes(d))'
  assert s.count(old)==1;s=s.replace(old,new)
  old='lo = lo.Add(square8(widen8(a).Sub(widen8(b))))'
  new='lo = lo.Add(square8(widen8(a.Max(b).Sub(a.Min(b)))))'
  assert s.count(old)==1;s=s.replace(old,new)
 if 'unroll' in variant:
  start=s.index('\t\tfor ; y+2 <= h; y += 2 {')
  stop=s.index('\n\t\tif y < h {',start)
  loop=s[start:stop]
  body=loop[loop.index('\n')+1:loop.rindex('\n\t\t}')]
  # Four rows per main iteration, two independent packet scopes.
  unroll='\t\tfor ; y+4 <= h; y += 4 {\n\t\t\t{\n'+body+'\n\t\t\t}\n\t\t\t{\n'+body+'\n\t\t\t}\n\t\t}\n'
  s=s[:start]+unroll+loop+s[stop:]
 p.write_text(s)
 print(variant,p)

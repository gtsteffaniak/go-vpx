import json, statistics, sys
from pathlib import Path
prefix = sys.argv[1]
samples = json.loads(Path(prefix + '.json').read_text())['samples']
assert len(samples) == 36
ignore = {'ns_per_frame', 'encode_fps', 'macroblocks_per_second', 'latency_ns'}
out = {}
for frames in [300, 60]:
    rows = [r for r in samples if r['frames'] == frames]
    ref = {k: v for k, v in rows[0]['result'].items() if k not in ignore}
    assert all({k: v for k, v in r['result'].items() if k not in ignore} == ref for r in rows)
    assert all(r['result']['allocs_per_frame'] == 0 for r in rows)
    raw = {v: [r['result']['ns_per_frame'] for r in sorted(rows, key=lambda x: x['round']) if r['variant'] == v] for v in ['assembly', 'parent', 'candidate']}
    assert all(len(a) == 6 for a in raw.values())
    median = {v: statistics.median(a) for v, a in raw.items()}
    out[str(frames)] = {
        'samples': raw, 'median_ns': median,
        'vs_parent_percent': (median['candidate'] / median['parent'] - 1) * 100,
        'vs_assembly_percent': (median['candidate'] / median['assembly'] - 1) * 100,
        'faster_parent_pairs': sum(a < b for a, b in zip(raw['candidate'], raw['parent'])),
        'faster_assembly_pairs': sum(a < b for a, b in zip(raw['candidate'], raw['assembly'])),
        'exact_fields': sorted(ref), 'allocations': 0,
        'limits': 'Balanced serial shared-desktop measurements. No isolated causal attribution for shifts larger than component/profile expectation.'}
Path(prefix + '-summary.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out))

from pathlib import Path
import subprocess,tarfile,io
repo=Path.cwd();head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for variant in ['parent','candidate']:
 root=Path('/private/tmp/govpx-next-sse8-rows-'+variant);root.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',head]))) as t:t.extractall(root,members=[m for m in t.getmembers() if not m.name.startswith('benchmarks/baselines/')])
p=Path('/private/tmp/govpx-next-sse8-rows-candidate/internal/pixel/sse_simd.go');s=p.read_text();s=s.replace('import "simd/archsimd"','import ("simd/archsimd"; "unsafe")')
marker='''	if !Enabled {
		return SSE8Scalar(src, ss, ref, rs, h)
	}
''';assert s.count(marker)==1
block='''
 // Bounded nonnegative geometry proves the final row offsets fit int64.
 // The two endpoint checks cover exact8-byte loads, including unaligned,
 // zero-stride and overlapping read-only rows, without requiring padding.
 if h>0 && h<=64 && (uint(ss)|uint(rs))>>30==0 {
  _=src[(h-1)*ss+7];_=ref[(h-1)*rs+7]
  sp,rp:=unsafe.Pointer(unsafe.SliceData(src)),unsafe.Pointer(unsafe.SliceData(ref))
  var lo,hi archsimd.Int32x4
  so,ro,y:=0,0,0
  for ;y+2<=h;y+=2 {
   a:=archsimd.BroadcastUint64x2(*(*uint64)(unsafe.Add(sp,so))).SetElem(1,*(*uint64)(unsafe.Add(sp,so+ss))).ReshapeToUint8s()
   b:=archsimd.BroadcastUint64x2(*(*uint64)(unsafe.Add(rp,ro))).SetElem(1,*(*uint64)(unsafe.Add(rp,ro+rs))).ReshapeToUint8s()
   dl:=widen8(a).Sub(widen8(b));dh:=widen8(highBytes(a)).Sub(widen8(highBytes(b)))
   lo=lo.Add(square8(dl));hi=hi.Add(square8(dh))
   so+=2*ss;ro+=2*rs
  }
  if y<h {
   a:=archsimd.BroadcastUint64x2(*(*uint64)(unsafe.Add(sp,so))).ReshapeToUint8s()
   b:=archsimd.BroadcastUint64x2(*(*uint64)(unsafe.Add(rp,ro))).ReshapeToUint8s()
   lo=lo.Add(square8(widen8(a).Sub(widen8(b))))
  }
  return uint32(sum32(lo.Add(hi)))
 }
'''
s=s.replace(marker,marker+block);p.write_text(s)
Path('/private/tmp/govpx-next-sse8-rows-base.txt').write_text(head+'\n');print(head)

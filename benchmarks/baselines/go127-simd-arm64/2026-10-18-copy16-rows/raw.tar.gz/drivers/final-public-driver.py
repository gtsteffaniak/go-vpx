import os,json,subprocess
from pathlib import Path
p=Path(__file__).parent
env=dict(os.environ,GOMAXPROCS='1')
orders=[['candidate','asm','parent'],['parent','asm','candidate'],['asm','parent','candidate'],['candidate','parent','asm'],['parent','candidate','asm'],['asm','candidate','parent']]
rows=[]
for frames in [60,300]:
 for r,order in enumerate(orders,1):
  for n in order:
   args=[str(p/(n+'-bench')),'-codec=vp8','-width=1280','-height=720','-frames='+str(frames),'-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8','-threads=1','-encode-only','-auto-libvpx=false','-format=json']
   result=subprocess.run(args,env=env,text=True,capture_output=True,check=True)
   (p/('final-public-%d-round%d-%s.json'%(frames,r,n))).write_text(result.stdout)
   (p/('final-public-%d-round%d-%s.stderr'%(frames,r,n))).write_text(result.stderr)
   rows.append(dict(frames=frames,round=r,variant=n,command=args,result=json.loads(result.stdout)))
  (p/'final-public-samples.json').write_text(json.dumps(dict(samples=rows),indent=2)+'\n')
  print('whole',frames,'round',r,'done',flush=True)

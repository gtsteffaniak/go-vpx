import pathlib,json,re,statistics,hashlib,subprocess
p=pathlib.Path('/private/tmp/govpx-next-copy16-rows');r=pathlib.Path('/Users/thesyncim/GolandProjects/govpx');rows={}
for api in ['dsp','root']:
 for v in ['parent','candidate','asm']:
  for n in range(1,7):
   log=(p/('final-round%d-%s-%s.log'%(n,v,api))).read_text();assert '\nPASS\n' in log
   found=0
   for name,ns,bs,alloc in re.findall(r'BenchmarkCopy16RowsNative/(\S+)\s+\d+\s+(\S+)\s+ns/op\s+(\S+)\s+B/op\s+(\S+)\s+allocs/op',log):
    assert float(bs)==float(alloc)==0;rows.setdefault(api+'/'+name,{}).setdefault(v,[]).append(float(ns));found+=1
   assert found==8
assert len(rows)==16
qual={};controls={}
for k,z in rows.items():
 assert all(len(a)==6 for a in z.values());pa=[a/b for a,b in zip(z['parent'],z['candidate'])];assert min(pa)>1
 rec={'speedup':statistics.median(z['parent'])/statistics.median(z['candidate']),'paired':pa}
 (controls if '/pitch0_0/aliastrue' in k else qual)[k]=rec
assert len(qual)==14;assert all(z['speedup']>=1.5 and min(z['paired'])>=1.5 for z in qual.values())
ignored={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'};pub={}
for frames in [60,300]:
 rr={v:[json.loads((p/('final-public-%d-round%d-%s.json'%(frames,i,v))).read_text()) for i in range(1,7)] for v in ['parent','candidate','asm']};allr=[a for b in rr.values() for a in b];fields=set(allr[0])-ignored;assert len(fields)==22
 assert all({k:a[k] for k in fields}=={k:allr[0][k] for k in fields} for a in allr);assert all(a['allocs_per_frame']==0 for a in allr)
 med={v:statistics.median(a['ns_per_frame'] for a in b) for v,b in rr.items()};pairs=[100*(b['ns_per_frame']/a['ns_per_frame']-1) for a,b in zip(rr['parent'],rr['candidate'])]
 pub[frames]={'medians':med,'vs_parent_percent':100*(med['candidate']/med['parent']-1),'vs_oldbuild_percent':100*(med['candidate']/med['asm']-1),'pairs':pairs,'faster_parent_pairs':sum(x<0 for x in pairs),'all23_fields_match':True}
files=['internal/pixel/copy16_rows_arm64.go','internal/pixel/copy16_rows_other.go','internal/vp8/dsp/recon.go','vp8_encoder_denoiser.go','internal/vp8/dsp/copy16_rows_native_test.go','copy16_rows_native_test.go'];shas={}
for f in files:
 a=hashlib.sha256((p/'candidate'/f).read_bytes()).hexdigest();b=hashlib.sha256((r/f).read_bytes()).hexdigest();assert a==b,f;shas[f]=a
old=(p/'candidate/internal/pixel/copy16_rows_arm64_test.go').read_bytes();new=(r/'internal/pixel/copy16_rows_arm64_test.go').read_bytes();assert new.startswith(old.rstrip()+b'\n\nfunc TestCopy16RowsUnaligned')
out={'parent':'34c4e4a17b231a24a3d3774c9621b7e5b80bac03','hardware':'Apple M4 Max','native_samples_verified':288,'all_zero_bytes_and_allocations':True,'qualifying_cases':14,'qualifying_median_speedup_range':[min(z['speedup'] for z in qual.values()),max(z['speedup'] for z in qual.values())],'minimum_qualifying_paired_speedup':min(x for z in qual.values() for x in z['paired']),'all16_cases_faster_every_pair':True,'two_nonqualifying_controls':controls,'public':pub,'exact_measured_production_and_benchmark_fixture_shas':shas,'supplemental_test':'Only direct ARM test file extended after timing with 1024 alignment/alias minimum-window cases; production and both timed fixture files unchanged. Root race/checkptr log passes.','old_copy_reference':'Go compiler vector-copy implementation, not handwritten assembly; wholeoldbuild still contains other NEON kernels.'}
pathlib.Path('/private/tmp/govpx-root-copy16-proof.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['exact_measured_production_and_benchmark_fixture_shas','two_nonqualifying_controls']},indent=2))

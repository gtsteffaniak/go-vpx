from pathlib import Path
import json,hashlib,subprocess,re,collections,statistics,datetime,math,difflib,os
R=Path('/Users/thesyncim/GolandProjects/govpx');S=Path('/private/tmp/govpx-next-token-count51');D=Path('/private/tmp/govpx-ci-token51-audit');D.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();base='10caaa67ed53f8c3c1248f20070e5a4117245852';fixture='internal/vp8/encoder/token_count51_private_test.go';prod='internal/vp8/encoder/probability_tokens.go'
B={n:json.loads((S/(n+'-binding.json')).read_text())for n in ('fresh','countonly')};assert B['fresh']['variants']=={n:B['countonly']['variants'][n]for n in ('parent','candidate')}
proof={'base':base,'binding_files':{},'source_variants':{},'binary_receipts':{},'scope':'Apple M4 Max native ARM64 component only; no new measurements/whole/x64 claim'}
for name,b in B.items():
 assert b['hardware']=='Apple M4 Max / Darwin ARM64'and b['SDK']=='Go1.27.2'and b['CGO_ENABLED']==1 and b['PGO']=='off'and b['GOMAXPROCS']==1 and b['types']=={'encoder':['^BenchmarkTokenCountMacro51$',12]}
 proof['binding_files'][name]=sha((S/(name+'-binding.json')).read_bytes())
for v,x in B['countonly']['variants'].items():
 src=Path(x['source']);actual={str(p.relative_to(src)):sha(p.read_bytes())for p in src.rglob('*.go')};assert actual==x['all_go_sha256'],v;proof['source_variants'][v]=actual
 for kind,b in x['binaries'].items():
  p=Path(b['path']);assert sha(p.read_bytes())==b['sha256'];proof['binary_receipts'][v+'/'+kind]={'path':str(p),'sha256':b['sha256'],'bytes':p.stat().st_size}
parent=proof['source_variants']['parent'];refpaths=subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=R).decode().splitlines();refpaths=[p for p in refpaths if p.endswith('.go')];assert set(parent)==set(refpaths+[fixture])
blob=subprocess.check_output(['git','cat-file','--batch'],input=''.join(base+':'+p+'\n'for p in refpaths).encode(),cwd=R);off=0
for p in refpaths:
 e=blob.index(b'\n',off);h=blob[off:e].decode().split();assert h[1]=='blob';n=int(h[2]);assert sha(blob[e+1:e+1+n])==parent[p],p;off=e+1+n+1
assert off==len(blob);proof['parent_Git_exact_Go_files']=len(refpaths)
for v in ('candidate','countonly'):
 a=proof['source_variants'][v];assert set(a)==set(parent);assert [p for p in a if a[p]!=parent[p]]==[prod]
assert len({proof['source_variants'][v][fixture]for v in ('parent','candidate','countonly')})==1

def function(text,name):
 st=text.index('func '+name+'(');p=text.index('{',st);level=1;i=p+1
 while level:
  level+=(text[i]=='{')-(text[i]=='}');i+=1
 return text[st:i]
fs=(S/'parent'/fixture).read_text();orig=(S/'parent'/prod).read_text();assert function(fs,'tokenCountFrozenMacro51').replace('tokenCountFrozenMacro51','countCoefficientMacroblockTokensAndRecords',1)==function(orig,'countCoefficientMacroblockTokensAndRecords')
for v in ('candidate','countonly'):
 text=(S/v/prod).read_text()
 for n in ('countBlockCoefficientTokens','countBlockCoefficientTokensAndRecords'):assert function(text,n)==function(orig,n),(v,n)
expected=function(orig,'countCoefficientMacroblockTokensAndRecords').replace('countCoefficientMacroblockTokensAndRecords','countCoefficientMacroblockTokens',1).replace(', records *InterCoefficientTokenRecords','').replace('countBlockCoefficientTokensAndRecords(counts, records,','countBlockCoefficientTokens(counts,')
assert function((S/'countonly'/prod).read_text(),'countCoefficientMacroblockTokens')==expected
proof['frozen_macro_oracle_exact_original']=True;proof['shared_block_workers_exact_original']=True;proof['countonly_walk_exact_original_minus_record_forwarding']=True
for v in ('candidate','countonly'):
 (D/(v+'-vs-parent.patch')).write_text(''.join(difflib.unified_diff(orig.splitlines(True),(S/v/prod).read_text().splitlines(True),fromfile='parent/'+prod,tofile=v+'/'+prod)))
expected={f'BenchmarkTokenCountMacro51/is4{a}/{p}/records{b}'for a in ('false','true')for p in ('zero','sparse','dense')for b in ('false','true')};pat=re.compile(r'^(Benchmark\S+)\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op$',re.M);results={}
for phase in ('fresh','countonly'):
 d=S/(phase+'-screen');c=json.loads((d/'commands.json').read_text());assert c['binding_sha256']==proof['binding_files'][phase];orders=c['orders'];variants=('parent','candidate')if phase=='fresh'else('parent','candidate','countonly');assert len(orders)==6
 if phase=='fresh':assert orders==[['parent','candidate']if r%2 else['candidate','parent']for r in range(1,7)]
 else:
  assert len(set(tuple(x)for x in orders))==6
  for i in range(3):assert collections.Counter(x[i]for x in orders)=={v:2 for v in variants}
 m=c['measurements'];assert [(x['round'],x['variant'])for x in m]==[(r,v)for r,order in enumerate(orders,1)for v in order]
 samples=collections.defaultdict(list);previous=None
 for x in m:
  v=x['variant'];r=x['round'];assert x['exit_code']==0 and x['kind']=='encoder';assert x['command']==[B[phase]['variants'][v]['binaries']['encoder']['path'],'-test.run','^$','-test.bench','^BenchmarkTokenCountMacro51$','-test.benchtime=75ms','-test.count=1','-test.cpu=1','-test.benchmem'];start=datetime.datetime.fromisoformat(x['start_utc']);end=datetime.datetime.fromisoformat(x['end_utc']);assert start<end and(previous is None or previous<=start);previous=end
  t=(d/f'r{r}-{v}-encoder.txt').read_text();assert not(d/f'r{r}-{v}-encoder.stderr').read_text();assert re.search(r'^PASS$',t,re.M)and'FAIL'not in t;assert 'goos: darwin'in t and'goarch: arm64'in t and'cpu: Apple M4 Max'in t;rows=pat.findall(t);assert len(rows)==12 and {x[0]for x in rows}==expected
  for n,it,ns,byte,alloc in rows:assert int(it)>0 and float(ns)>0 and math.isfinite(float(ns))and int(byte)==int(alloc)==0;samples[(v,n)].append({'round':r,'ns':float(ns),'iterations':int(it)})
 cases={}
 for n in sorted(expected):
  rows={v:samples[(v,n)]for v in variants};assert all([x['round']for x in a]==list(range(1,7))for a in rows.values());med={v:statistics.median(x['ns']for x in a)for v,a in rows.items()};cases[n]={'samples':rows,'median_ns':med,'speedup_vs_parent':{v:med['parent']/med[v]for v in variants if v!='parent'},'all6_speedups_vs_parent':{v:[a['ns']/b['ns']for a,b in zip(rows['parent'],rows[v])]for v in variants if v!='parent'}}
 results[phase]={'orders':orders,'samples':sum(len(x)for x in samples.values()),'cases':cases,'all_zeroalloc':True}
assert results['fresh']['samples']==144 and results['countonly']['samples']==216
logs={}
for v in ('parent','candidate','countonly'):
 for suffix in ('frozen-state.log','preflight.log','encoder-test.log','race-checkptr.log'):
  f=S/(v+'-'+suffix)
  if not f.exists():continue
  t=f.read_text();assert 'FAIL'not in t and'panic:'not in t
  if suffix in ('frozen-state.log','race-checkptr.log'):assert 'full-state/error/panic/backing cases=12288'in t and'--- PASS: TestTokenCount51FrozenState'in t
  if suffix=='preflight.log':rows=pat.findall(t);assert len(rows)==12 and{r[0]for r in rows}==expected and all(int(it)==1 and int(b)==int(a)==0 for n,it,ns,b,a in rows)
  if suffix=='encoder-test.log':assert re.search(r'^ok\s+github.com/thesyncim/govpx/internal/vp8/encoder',t,re.M)
  logs[f.name]={'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size}
assert 'candidate-race-checkptr.log'in logs and'countonly-race-checkptr.log'in logs;assert(S/'parent-frozen-state-attempt1.log').read_text().find("expected declaration, found '}'")>=0
proof['validation_logs']=logs;proof['fixture_liveness']={'B_Loop':True,'pre_post_context_and_record_oracle':True,'all_counters_vs_reference_times_b_N':True,'counts_accumulate_across_iterations':True,'per_iteration_context_and_record_length_reset':True,'post_timing_output_sink':True,'fixtures12':sorted(expected),'ordinary_full_state_cases':12288,'scope':'Typed above/left alias plus nil/error/invalidEOB/fullcoeff extremes/backingcapacity; arbitrary unsafe cross-type alias not claimed'}
(D/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');(D/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'proof':str(D/'proof.json'),'results':str(D/'results.json'),'all_source_binary_hashes_PASS':True,'original_Git_Go_files':len(refpaths),'fixture_shared_sha':parent[fixture],'samples':[results[p]['samples']for p in ('fresh','countonly')],'all_zeroalloc':True,'frozen_oracle_and_blockworkers_exact':True,'new_measurements':0},indent=2))
for n,v in results['countonly']['cases'].items():print(n,','.join(k+'='+format(x,'.4f')for k,x in v['speedup_vs_parent'].items()))

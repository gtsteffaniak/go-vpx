
/private/tmp/govpx-next-token-count51/countonly-encoder.test:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001001f60a0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens>:
1001f60a0: f9400b90    	ldr	x16, [x28, #0x10]
1001f60a4: d10043f1    	sub	x17, sp, #0x10
1001f60a8: eb10023f    	cmp	x17, x16
1001f60ac: 54001c29    	b.ls	0x1001f6430 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x390>
1001f60b0: f8170ffe    	str	x30, [sp, #-0x90]!
1001f60b4: f81f83fd    	stur	x29, [sp, #-0x8]
1001f60b8: d10023fd    	sub	x29, sp, #0x8
1001f60bc: b40006e1    	cbz	x1, 0x1001f6198 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0xf8>
1001f60c0: b40006c2    	cbz	x2, 0x1001f6198 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0xf8>
1001f60c4: b40006a3    	cbz	x3, 0x1001f6198 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0xf8>
1001f60c8: b4000684    	cbz	x4, 0x1001f6198 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0xf8>
1001f60cc: f90053e1    	str	x1, [sp, #0xa0]
1001f60d0: f90057e2    	str	x2, [sp, #0xa8]
1001f60d4: f9005be3    	str	x3, [sp, #0xb0]
1001f60d8: f9005fe4    	str	x4, [sp, #0xb8]
1001f60dc: 36000080    	tbz	w0, #0x0, 0x1001f60ec <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x4c>
1001f60e0: aa1f03e0    	mov	x0, xzr
1001f60e4: b24007e5    	orr	x5, xzr, #0x3
1001f60e8: 1400001f    	b	0x1001f6164 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0xc4>
1001f60ec: 39402026    	ldrb	w6, [x1, #0x8]
1001f60f0: 39402047    	ldrb	w7, [x2, #0x8]
1001f60f4: 8b0700c6    	add	x6, x6, x7
1001f60f8: d3401cc6    	ubfx	x6, x6, #0, #8
1001f60fc: d503201f    	nop
1001f6100: f1000cdf    	cmp	x6, #0x3
1001f6104: 540003ea    	b.ge	0x1001f6180 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0xe0>
1001f6108: 910c0067    	add	x7, x3, #0x300
1001f610c: 394ce065    	ldrb	w5, [x3, #0x338]
1001f6110: f90027e5    	str	x5, [sp, #0x48]
1001f6114: aa0403e0    	mov	x0, x4
1001f6118: b24003e1    	orr	x1, xzr, #0x1
1001f611c: aa0603e2    	mov	x2, x6
1001f6120: aa1f03e3    	mov	x3, xzr
1001f6124: aa0703e4    	mov	x4, x7
1001f6128: 94000232    	bl	0x1001f69f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens>
1001f612c: b5000240    	cbnz	x0, 0x1001f6174 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0xd4>
1001f6130: f94027e6    	ldr	x6, [sp, #0x48]
1001f6134: f10000df    	cmp	x6, #0x0
1001f6138: 9a9fd7e6    	cset	x6, gt
1001f613c: f94053e7    	ldr	x7, [sp, #0xa0]
1001f6140: 390020e6    	strb	w6, [x7, #0x8]
1001f6144: f94057e8    	ldr	x8, [sp, #0xa8]
1001f6148: 39002106    	strb	w6, [x8, #0x8]
1001f614c: aa0703e1    	mov	x1, x7
1001f6150: aa0803e2    	mov	x2, x8
1001f6154: f9405be3    	ldr	x3, [sp, #0xb0]
1001f6158: f9405fe4    	ldr	x4, [sp, #0xb8]
1001f615c: b24003e0    	orr	x0, xzr, #0x1
1001f6160: aa1f03e5    	mov	x5, xzr
1001f6164: f90033e5    	str	x5, [sp, #0x60]
1001f6168: f9002be0    	str	x0, [sp, #0x50]
1001f616c: aa1f03e6    	mov	x6, xzr
1001f6170: 1400001f    	b	0x1001f61ec <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x14c>
1001f6174: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6178: f84907fe    	ldr	x30, [sp], #0x90
1001f617c: d65f03c0    	ret
1001f6180: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6184: 9132437b    	add	x27, x27, #0xc90
1001f6188: a9400760    	ldp	x0, x1, [x27]
1001f618c: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6190: f84907fe    	ldr	x30, [sp], #0x90
1001f6194: d65f03c0    	ret
1001f6198: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f619c: 9132437b    	add	x27, x27, #0xc90
1001f61a0: a9400760    	ldp	x0, x1, [x27]
1001f61a4: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f61a8: f84907fe    	ldr	x30, [sp], #0x90
1001f61ac: d65f03c0    	ret
1001f61b0: f9403be7    	ldr	x7, [sp, #0x70]
1001f61b4: d3420ce8    	ubfx	x8, x7, #2, #2
1001f61b8: f9402be0    	ldr	x0, [sp, #0x50]
1001f61bc: f94023e9    	ldr	x9, [sp, #0x40]
1001f61c0: eb09001f    	cmp	x0, x9
1001f61c4: 9a9fa7e9    	cset	x9, lt
1001f61c8: f94043ea    	ldr	x10, [sp, #0x80]
1001f61cc: f94053e1    	ldr	x1, [sp, #0xa0]
1001f61d0: 382a6829    	strb	w9, [x1, x10]
1001f61d4: f94057e2    	ldr	x2, [sp, #0xa8]
1001f61d8: 38286849    	strb	w9, [x2, x8]
1001f61dc: 910004e6    	add	x6, x7, #0x1
1001f61e0: f9405be3    	ldr	x3, [sp, #0xb0]
1001f61e4: f9405fe4    	ldr	x4, [sp, #0xb8]
1001f61e8: f94033e5    	ldr	x5, [sp, #0x60]
1001f61ec: f10040df    	cmp	x6, #0x10
1001f61f0: 5400046a    	b.ge	0x1001f627c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x1dc>
1001f61f4: 924004c7    	and	x7, x6, #0x3
1001f61f8: 927e04c8    	and	x8, x6, #0xc
1001f61fc: 38676829    	ldrb	w9, [x1, x7]
1001f6200: 8b480848    	add	x8, x2, x8, lsr #2
1001f6204: 39400108    	ldrb	w8, [x8]
1001f6208: 8b090108    	add	x8, x8, x9
1001f620c: d3401d08    	ubfx	x8, x8, #0, #8
1001f6210: 910c8069    	add	x9, x3, #0x320
1001f6214: 38666929    	ldrb	w9, [x9, x6]
1001f6218: eb09001f    	cmp	x0, x9
1001f621c: 9a89c009    	csel	x9, x0, x9, gt
1001f6220: f1000d1f    	cmp	x8, #0x3
1001f6224: 5400020a    	b.ge	0x1001f6264 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x1c4>
1001f6228: f9003be6    	str	x6, [sp, #0x70]
1001f622c: f90023e9    	str	x9, [sp, #0x40]
1001f6230: f90043e7    	str	x7, [sp, #0x80]
1001f6234: 8b061466    	add	x6, x3, x6, lsl #5
1001f6238: aa0503e1    	mov	x1, x5
1001f623c: aa0803e2    	mov	x2, x8
1001f6240: aa0003e3    	mov	x3, x0
1001f6244: aa0903e5    	mov	x5, x9
1001f6248: aa0403e0    	mov	x0, x4
1001f624c: aa0603e4    	mov	x4, x6
1001f6250: 940001e8    	bl	0x1001f69f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens>
1001f6254: b4fffae0    	cbz	x0, 0x1001f61b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x110>
1001f6258: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f625c: f84907fe    	ldr	x30, [sp], #0x90
1001f6260: d65f03c0    	ret
1001f6264: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6268: 9132437b    	add	x27, x27, #0xc90
1001f626c: a9400760    	ldp	x0, x1, [x27]
1001f6270: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6274: f84907fe    	ldr	x30, [sp], #0x90
1001f6278: d65f03c0    	ret
1001f627c: b27c03e0    	orr	x0, xzr, #0x10
1001f6280: 14000007    	b	0x1001f629c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x1fc>
1001f6284: f94037e6    	ldr	x6, [sp, #0x68]
1001f6288: 910004c0    	add	x0, x6, #0x1
1001f628c: aa0803e1    	mov	x1, x8
1001f6290: aa0903e2    	mov	x2, x9
1001f6294: f9405be3    	ldr	x3, [sp, #0xb0]
1001f6298: f9405fe4    	ldr	x4, [sp, #0xb8]
1001f629c: f100601f    	cmp	x0, #0x18
1001f62a0: 54000b4a    	b.ge	0x1001f6408 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x368>
1001f62a4: 910c8066    	add	x6, x3, #0x320
1001f62a8: d503201f    	nop
1001f62ac: 386068c5    	ldrb	w5, [x6, x0]
1001f62b0: f1004c1f    	cmp	x0, #0x13
1001f62b4: 5400006d    	b.le	0x1001f62c0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x220>
1001f62b8: b27f03e6    	orr	x6, xzr, #0x2
1001f62bc: 14000002    	b	0x1001f62c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x224>
1001f62c0: aa1f03e6    	mov	x6, xzr
1001f62c4: 92400007    	and	x7, x0, #0x1
1001f62c8: 92400408    	and	x8, x0, #0x3
1001f62cc: 8b0700c7    	add	x7, x6, x7
1001f62d0: f100051f    	cmp	x8, #0x1
1001f62d4: 5400004d    	b.le	0x1001f62dc <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x23c>
1001f62d8: 910004c6    	add	x6, x6, #0x1
1001f62dc: f10008ff    	cmp	x7, #0x2
1001f62e0: 5400008a    	b.ge	0x1001f62f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x250>
1001f62e4: 91001028    	add	x8, x1, #0x4
1001f62e8: 38676908    	ldrb	w8, [x8, x7]
1001f62ec: 14000004    	b	0x1001f62fc <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x25c>
1001f62f0: 91001829    	add	x9, x1, #0x6
1001f62f4: d10008ea    	sub	x10, x7, #0x2
1001f62f8: 386a6928    	ldrb	w8, [x9, x10]
1001f62fc: f10008df    	cmp	x6, #0x2
1001f6300: 540000aa    	b.ge	0x1001f6314 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x274>
1001f6304: 54000922    	b.hs	0x1001f6428 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x388>
1001f6308: 91001049    	add	x9, x2, #0x4
1001f630c: 38666929    	ldrb	w9, [x9, x6]
1001f6310: 14000006    	b	0x1001f6328 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x288>
1001f6314: d10008c9    	sub	x9, x6, #0x2
1001f6318: f100093f    	cmp	x9, #0x2
1001f631c: 54000842    	b.hs	0x1001f6424 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x384>
1001f6320: 9100184a    	add	x10, x2, #0x6
1001f6324: 38696949    	ldrb	w9, [x10, x9]
1001f6328: 8b090108    	add	x8, x8, x9
1001f632c: d3401d08    	ubfx	x8, x8, #0, #8
1001f6330: f1000d1f    	cmp	x8, #0x3
1001f6334: 540005ea    	b.ge	0x1001f63f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x350>
1001f6338: f90037e0    	str	x0, [sp, #0x68]
1001f633c: f9003fe7    	str	x7, [sp, #0x78]
1001f6340: f9002fe6    	str	x6, [sp, #0x58]
1001f6344: 8b001466    	add	x6, x3, x0, lsl #5
1001f6348: f9001fe5    	str	x5, [sp, #0x38]
1001f634c: aa0403e0    	mov	x0, x4
1001f6350: b27f03e1    	orr	x1, xzr, #0x2
1001f6354: aa0803e2    	mov	x2, x8
1001f6358: aa1f03e3    	mov	x3, xzr
1001f635c: aa0603e4    	mov	x4, x6
1001f6360: 940001a4    	bl	0x1001f69f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens>
1001f6364: b5000400    	cbnz	x0, 0x1001f63e4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x344>
1001f6368: f9401fe6    	ldr	x6, [sp, #0x38]
1001f636c: f10000df    	cmp	x6, #0x0
1001f6370: 9a9fd7e6    	cset	x6, gt
1001f6374: f9403fe7    	ldr	x7, [sp, #0x78]
1001f6378: f10008ff    	cmp	x7, #0x2
1001f637c: 540000ea    	b.ge	0x1001f6398 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x2f8>
1001f6380: f94053e8    	ldr	x8, [sp, #0xa0]
1001f6384: 91001109    	add	x9, x8, #0x4
1001f6388: 38276926    	strb	w6, [x9, x7]
1001f638c: f9402fe7    	ldr	x7, [sp, #0x58]
1001f6390: f10008ff    	cmp	x7, #0x2
1001f6394: 14000007    	b	0x1001f63b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x310>
1001f6398: f94053e8    	ldr	x8, [sp, #0xa0]
1001f639c: 91001909    	add	x9, x8, #0x6
1001f63a0: d10008e7    	sub	x7, x7, #0x2
1001f63a4: 38276926    	strb	w6, [x9, x7]
1001f63a8: f9402fe7    	ldr	x7, [sp, #0x58]
1001f63ac: f10008ff    	cmp	x7, #0x2
1001f63b0: 540000ca    	b.ge	0x1001f63c8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x328>
1001f63b4: 54000362    	b.hs	0x1001f6420 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x380>
1001f63b8: f94057e9    	ldr	x9, [sp, #0xa8]
1001f63bc: 9100112a    	add	x10, x9, #0x4
1001f63c0: 38276946    	strb	w6, [x10, x7]
1001f63c4: 17ffffb0    	b	0x1001f6284 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x1e4>
1001f63c8: d10008e7    	sub	x7, x7, #0x2
1001f63cc: f10008ff    	cmp	x7, #0x2
1001f63d0: 54000262    	b.hs	0x1001f641c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x37c>
1001f63d4: f94057e9    	ldr	x9, [sp, #0xa8]
1001f63d8: 9100192a    	add	x10, x9, #0x6
1001f63dc: 38276946    	strb	w6, [x10, x7]
1001f63e0: 17ffffa9    	b	0x1001f6284 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens+0x1e4>
1001f63e4: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f63e8: f84907fe    	ldr	x30, [sp], #0x90
1001f63ec: d65f03c0    	ret
1001f63f0: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f63f4: 9132437b    	add	x27, x27, #0xc90
1001f63f8: a9400760    	ldp	x0, x1, [x27]
1001f63fc: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6400: f84907fe    	ldr	x30, [sp], #0x90
1001f6404: d65f03c0    	ret
1001f6408: aa1f03e0    	mov	x0, xzr
1001f640c: aa1f03e1    	mov	x1, xzr
1001f6410: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6414: f84907fe    	ldr	x30, [sp], #0x90
1001f6418: d65f03c0    	ret
1001f641c: 97fa4225    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6420: 97fa4224    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6424: 97fa4223    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6428: 97fa4222    	bl	0x100086cb0 <_runtime.panicBounds>
1001f642c: d503201f    	nop
1001f6430: 390023e0    	strb	w0, [sp, #0x8]
1001f6434: a9010be1    	stp	x1, x2, [sp, #0x10]
1001f6438: a90213e3    	stp	x3, x4, [sp, #0x20]
1001f643c: aa1e03e3    	mov	x3, x30
1001f6440: 97fa39d8    	bl	0x100084ba0 <_runtime.morestack_noctxt.abi0>
1001f6444: 394023e0    	ldrb	w0, [sp, #0x8]
1001f6448: a9410be1    	ldp	x1, x2, [sp, #0x10]
1001f644c: a94213e3    	ldp	x3, x4, [sp, #0x20]
1001f6450: 17ffff14    	b	0x1001f60a0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens>
		...

00000001001f6460 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords>:
1001f6460: f9400b90    	ldr	x16, [x28, #0x10]
1001f6464: d100c3f1    	sub	x17, sp, #0x30
1001f6468: eb10023f    	cmp	x17, x16
1001f646c: 54002aa9    	b.ls	0x1001f69c0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x560>
1001f6470: f8150ffe    	str	x30, [sp, #-0xb0]!
1001f6474: f81f83fd    	stur	x29, [sp, #-0x8]
1001f6478: d10023fd    	sub	x29, sp, #0x8
1001f647c: b4000c05    	cbz	x5, 0x1001f65fc <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x19c>
1001f6480: b4000b21    	cbz	x1, 0x1001f65e4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x184>
1001f6484: b4000b02    	cbz	x2, 0x1001f65e4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x184>
1001f6488: b4000ae3    	cbz	x3, 0x1001f65e4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x184>
1001f648c: b4000ac4    	cbz	x4, 0x1001f65e4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x184>
1001f6490: f90063e1    	str	x1, [sp, #0xc0]
1001f6494: f90067e2    	str	x2, [sp, #0xc8]
1001f6498: f9006be3    	str	x3, [sp, #0xd0]
1001f649c: f9006fe4    	str	x4, [sp, #0xd8]
1001f64a0: f90073e5    	str	x5, [sp, #0xe0]
1001f64a4: 36000080    	tbz	w0, #0x0, 0x1001f64b4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x54>
1001f64a8: aa1f03e0    	mov	x0, xzr
1001f64ac: b24007e6    	orr	x6, xzr, #0x3
1001f64b0: 1400003a    	b	0x1001f6598 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x138>
1001f64b4: 39402027    	ldrb	w7, [x1, #0x8]
1001f64b8: 39402048    	ldrb	w8, [x2, #0x8]
1001f64bc: 8b0800e7    	add	x7, x7, x8
1001f64c0: d3401ce8    	ubfx	x8, x7, #0, #8
1001f64c4: d503201f    	nop
1001f64c8: f1000d1f    	cmp	x8, #0x3
1001f64cc: 5400080a    	b.ge	0x1001f65cc <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x16c>
1001f64d0: 394ce066    	ldrb	w6, [x3, #0x338]
1001f64d4: f10000df    	cmp	x6, #0x0
1001f64d8: 5400032c    	b.gt	0x1001f653c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0xdc>
1001f64dc: 91240089    	add	x9, x4, #0x900
1001f64e0: d37b1ce7    	ubfiz	x7, x7, #5, #8
1001f64e4: 8b0704e7    	add	x7, x7, x7, lsl #1
1001f64e8: 8b070127    	add	x7, x9, x7
1001f64ec: f9402ce9    	ldr	x9, [x7, #0x58]
1001f64f0: 91000529    	add	x9, x9, #0x1
1001f64f4: f9002ce9    	str	x9, [x7, #0x58]
1001f64f8: d2800167    	mov	x7, #0xb                ; =11
1001f64fc: 9b087ce8    	mul	x8, x7, x8
1001f6500: 91042108    	add	x8, x8, #0x108
1001f6504: d37ced08    	lsl	x8, x8, #4
1001f6508: a940a8a9    	ldp	x9, x10, [x5, #0x8]
1001f650c: 9100052b    	add	x11, x9, #0x1
1001f6510: d280016c    	mov	x12, #0xb               ; =11
1001f6514: aa0c0108    	orr	x8, x8, x12
1001f6518: eb0b015f    	cmp	x10, x11
1001f651c: 540024e3    	b.lo	0x1001f69b8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x558>
1001f6520: f90004ab    	str	x11, [x5, #0x8]
1001f6524: eb0b013f    	cmp	x9, x11
1001f6528: 54002462    	b.hs	0x1001f69b4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x554>
1001f652c: f94000aa    	ldr	x10, [x5]
1001f6530: b8297948    	str	w8, [x10, x9, lsl #2]
1001f6534: f10000df    	cmp	x6, #0x0
1001f6538: 14000013    	b	0x1001f6584 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x124>
1001f653c: f9002fe6    	str	x6, [sp, #0x58]
1001f6540: 910c0067    	add	x7, x3, #0x300
1001f6544: aa0403e0    	mov	x0, x4
1001f6548: aa0503e1    	mov	x1, x5
1001f654c: b24003e2    	orr	x2, xzr, #0x1
1001f6550: aa0803e3    	mov	x3, x8
1001f6554: aa1f03e4    	mov	x4, xzr
1001f6558: aa0703e5    	mov	x5, x7
1001f655c: 940001b1    	bl	0x1001f6c20 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>
1001f6560: f9402fe7    	ldr	x7, [sp, #0x58]
1001f6564: f10000ff    	cmp	x7, #0x0
1001f6568: b50002c0    	cbnz	x0, 0x1001f65c0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x160>
1001f656c: f94063e1    	ldr	x1, [sp, #0xc0]
1001f6570: f94067e2    	ldr	x2, [sp, #0xc8]
1001f6574: f9406be3    	ldr	x3, [sp, #0xd0]
1001f6578: f9406fe4    	ldr	x4, [sp, #0xd8]
1001f657c: f94073e5    	ldr	x5, [sp, #0xe0]
1001f6580: d2800167    	mov	x7, #0xb                ; =11
1001f6584: 9a9fd7e8    	cset	x8, gt
1001f6588: 39002028    	strb	w8, [x1, #0x8]
1001f658c: 39002048    	strb	w8, [x2, #0x8]
1001f6590: b24003e0    	orr	x0, xzr, #0x1
1001f6594: aa1f03e6    	mov	x6, xzr
1001f6598: f9003be6    	str	x6, [sp, #0x70]
1001f659c: f90033e0    	str	x0, [sp, #0x60]
1001f65a0: d378dcc7    	lsl	x7, x6, #8
1001f65a4: 8b060c08    	add	x8, x0, x6, lsl #3
1001f65a8: 8b070ce7    	add	x7, x7, x7, lsl #3
1001f65ac: f90053e7    	str	x7, [sp, #0xa0]
1001f65b0: 8b080508    	add	x8, x8, x8, lsl #1
1001f65b4: f9004fe8    	str	x8, [sp, #0x98]
1001f65b8: aa1f03e9    	mov	x9, xzr
1001f65bc: 14000019    	b	0x1001f6620 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x1c0>
1001f65c0: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f65c4: f84b07fe    	ldr	x30, [sp], #0xb0
1001f65c8: d65f03c0    	ret
1001f65cc: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f65d0: 9132437b    	add	x27, x27, #0xc90
1001f65d4: a9400760    	ldp	x0, x1, [x27]
1001f65d8: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f65dc: f84b07fe    	ldr	x30, [sp], #0xb0
1001f65e0: d65f03c0    	ret
1001f65e4: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f65e8: 9132437b    	add	x27, x27, #0xc90
1001f65ec: a9400760    	ldp	x0, x1, [x27]
1001f65f0: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f65f4: f84b07fe    	ldr	x30, [sp], #0xb0
1001f65f8: d65f03c0    	ret
1001f65fc: 97fffea9    	bl	0x1001f60a0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokens>
1001f6600: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6604: f84b07fe    	ldr	x30, [sp], #0xb0
1001f6608: d65f03c0    	ret
1001f660c: 9a9fa7eb    	cset	x11, lt
1001f6610: 382a682b    	strb	w11, [x1, x10]
1001f6614: d3420d2a    	ubfx	x10, x9, #2, #2
1001f6618: 382a684b    	strb	w11, [x2, x10]
1001f661c: 91000529    	add	x9, x9, #0x1
1001f6620: f100413f    	cmp	x9, #0x10
1001f6624: 54000aea    	b.ge	0x1001f6780 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x320>
1001f6628: 9240052a    	and	x10, x9, #0x3
1001f662c: 927e052b    	and	x11, x9, #0xc
1001f6630: 386a682c    	ldrb	w12, [x1, x10]
1001f6634: 8b4b084b    	add	x11, x2, x11, lsr #2
1001f6638: 3940016b    	ldrb	w11, [x11]
1001f663c: 8b0c016b    	add	x11, x11, x12
1001f6640: d3401d6c    	ubfx	x12, x11, #0, #8
1001f6644: 910c806d    	add	x13, x3, #0x320
1001f6648: 386969ad    	ldrb	w13, [x13, x9]
1001f664c: eb0d001f    	cmp	x0, x13
1001f6650: 9a8dc00d    	csel	x13, x0, x13, gt
1001f6654: f1000d9f    	cmp	x12, #0x3
1001f6658: 5400088a    	b.ge	0x1001f6768 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x308>
1001f665c: eb0d001f    	cmp	x0, x13
1001f6660: 540003eb    	b.lt	0x1001f66dc <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x27c>
1001f6664: 8b07008e    	add	x14, x4, x7
1001f6668: d37b1d6b    	ubfiz	x11, x11, #5, #8
1001f666c: 8b0b056b    	add	x11, x11, x11, lsl #1
1001f6670: 8b0c010c    	add	x12, x8, x12
1001f6674: d280016f    	mov	x15, #0xb               ; =11
1001f6678: 9b0f7d8c    	mul	x12, x12, x15
1001f667c: d37ced8c    	lsl	x12, x12, #4
1001f6680: d2800170    	mov	x16, #0xb               ; =11
1001f6684: aa10018c    	orr	x12, x12, x16
1001f6688: f100001f    	cmp	x0, #0x0
1001f668c: 9a9f07f1    	cset	x17, ne
1001f6690: 7200023f    	tst	w17, #0x1
1001f6694: d2802411    	mov	x17, #0x120             ; =288
1001f6698: 9a9f1233    	csel	x19, x17, xzr, ne
1001f669c: 8b0e026e    	add	x14, x19, x14
1001f66a0: 8b0b01cb    	add	x11, x14, x11
1001f66a4: f9402d6e    	ldr	x14, [x11, #0x58]
1001f66a8: 910005ce    	add	x14, x14, #0x1
1001f66ac: f9002d6e    	str	x14, [x11, #0x58]
1001f66b0: a940b8ab    	ldp	x11, x14, [x5, #0x8]
1001f66b4: 91000573    	add	x19, x11, #0x1
1001f66b8: eb1301df    	cmp	x14, x19
1001f66bc: 54001783    	b.lo	0x1001f69ac <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x54c>
1001f66c0: f90004b3    	str	x19, [x5, #0x8]
1001f66c4: eb13017f    	cmp	x11, x19
1001f66c8: 540016e2    	b.hs	0x1001f69a4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x544>
1001f66cc: f94000ae    	ldr	x14, [x5]
1001f66d0: b82b79cc    	str	w12, [x14, x11, lsl #2]
1001f66d4: eb0d001f    	cmp	x0, x13
1001f66d8: 17ffffcd    	b	0x1001f660c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x1ac>
1001f66dc: f90043e9    	str	x9, [sp, #0x80]
1001f66e0: f9002bed    	str	x13, [sp, #0x50]
1001f66e4: f9004bea    	str	x10, [sp, #0x90]
1001f66e8: 8b091467    	add	x7, x3, x9, lsl #5
1001f66ec: aa0503e1    	mov	x1, x5
1001f66f0: aa0603e2    	mov	x2, x6
1001f66f4: aa0c03e3    	mov	x3, x12
1001f66f8: aa0703e5    	mov	x5, x7
1001f66fc: aa0d03e6    	mov	x6, x13
1001f6700: aa0003e7    	mov	x7, x0
1001f6704: aa0403e0    	mov	x0, x4
1001f6708: aa0703e4    	mov	x4, x7
1001f670c: 94000145    	bl	0x1001f6c20 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>
1001f6710: f94033e4    	ldr	x4, [sp, #0x60]
1001f6714: f9402be7    	ldr	x7, [sp, #0x50]
1001f6718: eb07009f    	cmp	x4, x7
1001f671c: b5000200    	cbnz	x0, 0x1001f675c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x2fc>
1001f6720: aa0403e0    	mov	x0, x4
1001f6724: f94063e1    	ldr	x1, [sp, #0xc0]
1001f6728: f94067e2    	ldr	x2, [sp, #0xc8]
1001f672c: f9406be3    	ldr	x3, [sp, #0xd0]
1001f6730: f9406fe4    	ldr	x4, [sp, #0xd8]
1001f6734: f94073e5    	ldr	x5, [sp, #0xe0]
1001f6738: f9403be6    	ldr	x6, [sp, #0x70]
1001f673c: f94053e7    	ldr	x7, [sp, #0xa0]
1001f6740: f9404fe8    	ldr	x8, [sp, #0x98]
1001f6744: f94043e9    	ldr	x9, [sp, #0x80]
1001f6748: f9404bea    	ldr	x10, [sp, #0x90]
1001f674c: d280016f    	mov	x15, #0xb               ; =11
1001f6750: d2800170    	mov	x16, #0xb               ; =11
1001f6754: d2802411    	mov	x17, #0x120             ; =288
1001f6758: 17ffffad    	b	0x1001f660c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x1ac>
1001f675c: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6760: f84b07fe    	ldr	x30, [sp], #0xb0
1001f6764: d65f03c0    	ret
1001f6768: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f676c: 9132437b    	add	x27, x27, #0xc90
1001f6770: a9400760    	ldp	x0, x1, [x27]
1001f6774: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6778: f84b07fe    	ldr	x30, [sp], #0xb0
1001f677c: d65f03c0    	ret
1001f6780: b27c03e7    	orr	x7, xzr, #0x10
1001f6784: 14000002    	b	0x1001f678c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x32c>
1001f6788: 910004e7    	add	x7, x7, #0x1
1001f678c: f10060ff    	cmp	x7, #0x18
1001f6790: 54000f4a    	b.ge	0x1001f6978 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x518>
1001f6794: 910c8068    	add	x8, x3, #0x320
1001f6798: d503201f    	nop
1001f679c: 38676906    	ldrb	w6, [x8, x7]
1001f67a0: f1004cff    	cmp	x7, #0x13
1001f67a4: 5400006d    	b.le	0x1001f67b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x350>
1001f67a8: b27f03e0    	orr	x0, xzr, #0x2
1001f67ac: 14000002    	b	0x1001f67b4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x354>
1001f67b0: aa1f03e0    	mov	x0, xzr
1001f67b4: 924000e8    	and	x8, x7, #0x1
1001f67b8: 924004e9    	and	x9, x7, #0x3
1001f67bc: 8b000108    	add	x8, x8, x0
1001f67c0: f100053f    	cmp	x9, #0x1
1001f67c4: 5400004d    	b.le	0x1001f67cc <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x36c>
1001f67c8: 91000400    	add	x0, x0, #0x1
1001f67cc: f100091f    	cmp	x8, #0x2
1001f67d0: 5400008a    	b.ge	0x1001f67e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x380>
1001f67d4: 91001029    	add	x9, x1, #0x4
1001f67d8: 38686929    	ldrb	w9, [x9, x8]
1001f67dc: 14000004    	b	0x1001f67ec <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x38c>
1001f67e0: 9100182a    	add	x10, x1, #0x6
1001f67e4: d100090b    	sub	x11, x8, #0x2
1001f67e8: 386b6949    	ldrb	w9, [x10, x11]
1001f67ec: f100081f    	cmp	x0, #0x2
1001f67f0: 540000aa    	b.ge	0x1001f6804 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x3a4>
1001f67f4: 54000d62    	b.hs	0x1001f69a0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x540>
1001f67f8: 9100104a    	add	x10, x2, #0x4
1001f67fc: 3860694a    	ldrb	w10, [x10, x0]
1001f6800: 14000006    	b	0x1001f6818 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x3b8>
1001f6804: d100080a    	sub	x10, x0, #0x2
1001f6808: f100095f    	cmp	x10, #0x2
1001f680c: 54000c82    	b.hs	0x1001f699c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x53c>
1001f6810: 9100184b    	add	x11, x2, #0x6
1001f6814: 386a696a    	ldrb	w10, [x11, x10]
1001f6818: 8b0a0129    	add	x9, x9, x10
1001f681c: d3401d2a    	ubfx	x10, x9, #0, #8
1001f6820: f1000d5f    	cmp	x10, #0x3
1001f6824: 540009ea    	b.ge	0x1001f6960 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x500>
1001f6828: f10000df    	cmp	x6, #0x0
1001f682c: 5400034c    	b.gt	0x1001f6894 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x434>
1001f6830: d282400b    	mov	x11, #0x1200            ; =4608
1001f6834: 8b04016c    	add	x12, x11, x4
1001f6838: d37b1d29    	ubfiz	x9, x9, #5, #8
1001f683c: 8b090529    	add	x9, x9, x9, lsl #1
1001f6840: 8b090189    	add	x9, x12, x9
1001f6844: f9402d2c    	ldr	x12, [x9, #0x58]
1001f6848: 9100058c    	add	x12, x12, #0x1
1001f684c: f9002d2c    	str	x12, [x9, #0x58]
1001f6850: d2800169    	mov	x9, #0xb                ; =11
1001f6854: 9b097d4a    	mul	x10, x10, x9
1001f6858: 9108414a    	add	x10, x10, #0x210
1001f685c: d37ced4a    	lsl	x10, x10, #4
1001f6860: a940b4ac    	ldp	x12, x13, [x5, #0x8]
1001f6864: 9100058e    	add	x14, x12, #0x1
1001f6868: d280016f    	mov	x15, #0xb               ; =11
1001f686c: aa0f014a    	orr	x10, x10, x15
1001f6870: eb0e01bf    	cmp	x13, x14
1001f6874: 54000923    	b.lo	0x1001f6998 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x538>
1001f6878: f90004ae    	str	x14, [x5, #0x8]
1001f687c: eb0e019f    	cmp	x12, x14
1001f6880: 540008a2    	b.hs	0x1001f6994 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x534>
1001f6884: f94000ad    	ldr	x13, [x5]
1001f6888: b82c79aa    	str	w10, [x13, x12, lsl #2]
1001f688c: f10000df    	cmp	x6, #0x0
1001f6890: 1400001b    	b	0x1001f68fc <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x49c>
1001f6894: f9003fe7    	str	x7, [sp, #0x78]
1001f6898: f90027e6    	str	x6, [sp, #0x48]
1001f689c: f90047e8    	str	x8, [sp, #0x88]
1001f68a0: f90037e0    	str	x0, [sp, #0x68]
1001f68a4: 8b071467    	add	x7, x3, x7, lsl #5
1001f68a8: aa0403e0    	mov	x0, x4
1001f68ac: aa0503e1    	mov	x1, x5
1001f68b0: b27f03e2    	orr	x2, xzr, #0x2
1001f68b4: aa0a03e3    	mov	x3, x10
1001f68b8: aa1f03e4    	mov	x4, xzr
1001f68bc: aa0703e5    	mov	x5, x7
1001f68c0: 940000d8    	bl	0x1001f6c20 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>
1001f68c4: f94027e7    	ldr	x7, [sp, #0x48]
1001f68c8: f10000ff    	cmp	x7, #0x0
1001f68cc: b5000440    	cbnz	x0, 0x1001f6954 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x4f4>
1001f68d0: f94037e0    	ldr	x0, [sp, #0x68]
1001f68d4: f94063e1    	ldr	x1, [sp, #0xc0]
1001f68d8: f94067e2    	ldr	x2, [sp, #0xc8]
1001f68dc: f9406be3    	ldr	x3, [sp, #0xd0]
1001f68e0: f9406fe4    	ldr	x4, [sp, #0xd8]
1001f68e4: f94073e5    	ldr	x5, [sp, #0xe0]
1001f68e8: f9403fe7    	ldr	x7, [sp, #0x78]
1001f68ec: f94047e8    	ldr	x8, [sp, #0x88]
1001f68f0: d2800169    	mov	x9, #0xb                ; =11
1001f68f4: d282400b    	mov	x11, #0x1200            ; =4608
1001f68f8: d280016f    	mov	x15, #0xb               ; =11
1001f68fc: 9a9fd7ea    	cset	x10, gt
1001f6900: f100091f    	cmp	x8, #0x2
1001f6904: 540000aa    	b.ge	0x1001f6918 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x4b8>
1001f6908: 9100102c    	add	x12, x1, #0x4
1001f690c: 3828698a    	strb	w10, [x12, x8]
1001f6910: f100081f    	cmp	x0, #0x2
1001f6914: 14000005    	b	0x1001f6928 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x4c8>
1001f6918: 9100182c    	add	x12, x1, #0x6
1001f691c: d1000908    	sub	x8, x8, #0x2
1001f6920: 3828698a    	strb	w10, [x12, x8]
1001f6924: f100081f    	cmp	x0, #0x2
1001f6928: 540000aa    	b.ge	0x1001f693c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x4dc>
1001f692c: 54000322    	b.hs	0x1001f6990 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x530>
1001f6930: 91001048    	add	x8, x2, #0x4
1001f6934: 3820690a    	strb	w10, [x8, x0]
1001f6938: 17ffff94    	b	0x1001f6788 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x328>
1001f693c: d1000808    	sub	x8, x0, #0x2
1001f6940: f100091f    	cmp	x8, #0x2
1001f6944: 54000242    	b.hs	0x1001f698c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x52c>
1001f6948: 9100184c    	add	x12, x2, #0x6
1001f694c: 3828698a    	strb	w10, [x12, x8]
1001f6950: 17ffff8e    	b	0x1001f6788 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x328>
1001f6954: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6958: f84b07fe    	ldr	x30, [sp], #0xb0
1001f695c: d65f03c0    	ret
1001f6960: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6964: 9132437b    	add	x27, x27, #0xc90
1001f6968: a9400760    	ldp	x0, x1, [x27]
1001f696c: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6970: f84b07fe    	ldr	x30, [sp], #0xb0
1001f6974: d65f03c0    	ret
1001f6978: aa1f03e0    	mov	x0, xzr
1001f697c: aa1f03e1    	mov	x1, xzr
1001f6980: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6984: f84b07fe    	ldr	x30, [sp], #0xb0
1001f6988: d65f03c0    	ret
1001f698c: 97fa40c9    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6990: 97fa40c8    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6994: 97fa40c7    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6998: 97fa40c6    	bl	0x100086cb0 <_runtime.panicBounds>
1001f699c: 97fa40c5    	bl	0x100086cb0 <_runtime.panicBounds>
1001f69a0: 97fa40c4    	bl	0x100086cb0 <_runtime.panicBounds>
1001f69a4: aa1303e0    	mov	x0, x19
1001f69a8: 97fa40c2    	bl	0x100086cb0 <_runtime.panicBounds>
1001f69ac: aa1303e0    	mov	x0, x19
1001f69b0: 97fa40c0    	bl	0x100086cb0 <_runtime.panicBounds>
1001f69b4: 97fa40bf    	bl	0x100086cb0 <_runtime.panicBounds>
1001f69b8: 97fa40be    	bl	0x100086cb0 <_runtime.panicBounds>
1001f69bc: d503201f    	nop
1001f69c0: 390023e0    	strb	w0, [sp, #0x8]
1001f69c4: a9010be1    	stp	x1, x2, [sp, #0x10]
1001f69c8: a90213e3    	stp	x3, x4, [sp, #0x20]
1001f69cc: f9001be5    	str	x5, [sp, #0x30]
1001f69d0: aa1e03e3    	mov	x3, x30
1001f69d4: 97fa3873    	bl	0x100084ba0 <_runtime.morestack_noctxt.abi0>
1001f69d8: 394023e0    	ldrb	w0, [sp, #0x8]
1001f69dc: a9410be1    	ldp	x1, x2, [sp, #0x10]
1001f69e0: a94213e3    	ldp	x3, x4, [sp, #0x20]
1001f69e4: f9401be5    	ldr	x5, [sp, #0x30]
1001f69e8: 17fffe9e    	b	0x1001f6460 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords>
1001f69ec: 00000000    	udf	#0x0

00000001001f69f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens>:
1001f69f0: f9400b90    	ldr	x16, [x28, #0x10]
1001f69f4: eb3063ff    	cmp	sp, x16
1001f69f8: 54000fc9    	b.ls	0x1001f6bf0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x200>
1001f69fc: f81f0ffe    	str	x30, [sp, #-0x10]!
1001f6a00: f81f83fd    	stur	x29, [sp, #-0x8]
1001f6a04: d10023fd    	sub	x29, sp, #0x8
1001f6a08: b4000540    	cbz	x0, 0x1001f6ab0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f6a0c: b4000524    	cbz	x4, 0x1001f6ab0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f6a10: f100103f    	cmp	x1, #0x4
1001f6a14: 540004e2    	b.hs	0x1001f6ab0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f6a18: f1000c5f    	cmp	x2, #0x3
1001f6a1c: 540004a2    	b.hs	0x1001f6ab0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f6a20: f100047f    	cmp	x3, #0x1
1001f6a24: 54000468    	b.hi	0x1001f6ab0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f6a28: eb0300bf    	cmp	x5, x3
1001f6a2c: 540001ad    	b.le	0x1001f6a60 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x70>
1001f6a30: f10040bf    	cmp	x5, #0x10
1001f6a34: 540000ac    	b.gt	0x1001f6a48 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x58>
1001f6a38: d378dc26    	lsl	x6, x1, #8
1001f6a3c: 8b060cc6    	add	x6, x6, x6, lsl #3
1001f6a40: aa0303e7    	mov	x7, x3
1001f6a44: 14000021    	b	0x1001f6ac8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xd8>
1001f6a48: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6a4c: 9132437b    	add	x27, x27, #0xc90
1001f6a50: a9400760    	ldp	x0, x1, [x27]
1001f6a54: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6a58: f84107fe    	ldr	x30, [sp], #0x10
1001f6a5c: d65f03c0    	ret
1001f6a60: d378dc24    	lsl	x4, x1, #8
1001f6a64: 8b040c84    	add	x4, x4, x4, lsl #3
1001f6a68: 8b040004    	add	x4, x0, x4
1001f6a6c: d37be842    	lsl	x2, x2, #5
1001f6a70: 8b020442    	add	x2, x2, x2, lsl #1
1001f6a74: f100007f    	cmp	x3, #0x0
1001f6a78: 9a9f07e3    	cset	x3, ne
1001f6a7c: 7200007f    	tst	w3, #0x1
1001f6a80: d2802403    	mov	x3, #0x120              ; =288
1001f6a84: 9a9f1063    	csel	x3, x3, xzr, ne
1001f6a88: 8b040063    	add	x3, x3, x4
1001f6a8c: 8b020062    	add	x2, x3, x2
1001f6a90: f9402c43    	ldr	x3, [x2, #0x58]
1001f6a94: 91000463    	add	x3, x3, #0x1
1001f6a98: f9002c43    	str	x3, [x2, #0x58]
1001f6a9c: aa1f03e0    	mov	x0, xzr
1001f6aa0: aa1f03e1    	mov	x1, xzr
1001f6aa4: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6aa8: f84107fe    	ldr	x30, [sp], #0x10
1001f6aac: d65f03c0    	ret
1001f6ab0: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6ab4: 9132437b    	add	x27, x27, #0xc90
1001f6ab8: a9400760    	ldp	x0, x1, [x27]
1001f6abc: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6ac0: f84107fe    	ldr	x30, [sp], #0x10
1001f6ac4: d65f03c0    	ret
1001f6ac8: eb0300bf    	cmp	x5, x3
1001f6acc: 5400060d    	b.le	0x1001f6b8c <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x19c>
1001f6ad0: f0001948    	adrp	x8, 0x100521000 <_context..inittask+0xc0>
1001f6ad4: 911b0108    	add	x8, x8, #0x6c0
1001f6ad8: 78a37909    	ldrsh	x9, [x8, x3, lsl #1]
1001f6adc: 92400d29    	and	x9, x9, #0xf
1001f6ae0: 78a97889    	ldrsh	x9, [x4, x9, lsl #1]
1001f6ae4: ca89fd2a    	eor	x10, x9, x9, asr #63
1001f6ae8: cb89fd49    	sub	x9, x10, x9, asr #63
1001f6aec: f120013f    	cmp	x9, #0x800
1001f6af0: 54000428    	b.hi	0x1001f6b74 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x184>
1001f6af4: 8b06000a    	add	x10, x0, x6
1001f6af8: d37b08eb    	ubfiz	x11, x7, #5, #3
1001f6afc: 8b0b0d6b    	add	x11, x11, x11, lsl #3
1001f6b00: b0001c4c    	adrp	x12, 0x10057f000 <_github.com/thesyncim/govpx/internal/vp8/encoder.coefficientTokenLUT+0x1e0>
1001f6b04: 9119018c    	add	x12, x12, #0x640
1001f6b08: 38696989    	ldrb	w9, [x12, x9]
1001f6b0c: 8b0b014a    	add	x10, x10, x11
1001f6b10: f1000c5f    	cmp	x2, #0x3
1001f6b14: 540006a2    	b.hs	0x1001f6be8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x1f8>
1001f6b18: d37be84b    	lsl	x11, x2, #5
1001f6b1c: 8b0b056b    	add	x11, x11, x11, lsl #1
1001f6b20: 8b0b014a    	add	x10, x10, x11
1001f6b24: f100313f    	cmp	x9, #0xc
1001f6b28: 540005e2    	b.hs	0x1001f6be4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x1f4>
1001f6b2c: f869794b    	ldr	x11, [x10, x9, lsl #3]
1001f6b30: 9100056b    	add	x11, x11, #0x1
1001f6b34: f829794b    	str	x11, [x10, x9, lsl #3]
1001f6b38: 91000463    	add	x3, x3, #0x1
1001f6b3c: f100407f    	cmp	x3, #0x10
1001f6b40: 5400010a    	b.ge	0x1001f6b60 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x170>
1001f6b44: d000194a    	adrp	x10, 0x100520000 <_go:buildinfo>
1001f6b48: 912c814a    	add	x10, x10, #0xb20
1001f6b4c: 38636947    	ldrb	w7, [x10, x3]
1001f6b50: d000194b    	adrp	x11, 0x100520000 <_go:buildinfo>
1001f6b54: 9126e16b    	add	x11, x11, #0x9b8
1001f6b58: 38696962    	ldrb	w2, [x11, x9]
1001f6b5c: 17ffffdb    	b	0x1001f6ac8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xd8>
1001f6b60: d000194a    	adrp	x10, 0x100520000 <_go:buildinfo>
1001f6b64: 912c814a    	add	x10, x10, #0xb20
1001f6b68: d000194b    	adrp	x11, 0x100520000 <_go:buildinfo>
1001f6b6c: 9126e16b    	add	x11, x11, #0x9b8
1001f6b70: 17ffffd6    	b	0x1001f6ac8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xd8>
1001f6b74: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6b78: 9132437b    	add	x27, x27, #0xc90
1001f6b7c: a9400760    	ldp	x0, x1, [x27]
1001f6b80: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6b84: f84107fe    	ldr	x30, [sp], #0x10
1001f6b88: d65f03c0    	ret
1001f6b8c: f10040bf    	cmp	x5, #0x10
1001f6b90: 540001ea    	b.ge	0x1001f6bcc <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x1dc>
1001f6b94: d378dc23    	lsl	x3, x1, #8
1001f6b98: 8b030c63    	add	x3, x3, x3, lsl #3
1001f6b9c: 8b030003    	add	x3, x0, x3
1001f6ba0: d37b08e4    	ubfiz	x4, x7, #5, #3
1001f6ba4: 8b040c84    	add	x4, x4, x4, lsl #3
1001f6ba8: 8b040063    	add	x3, x3, x4
1001f6bac: f1000c5f    	cmp	x2, #0x3
1001f6bb0: 54000182    	b.hs	0x1001f6be0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x1f0>
1001f6bb4: d37be842    	lsl	x2, x2, #5
1001f6bb8: 8b020442    	add	x2, x2, x2, lsl #1
1001f6bbc: 8b020062    	add	x2, x3, x2
1001f6bc0: f9402c43    	ldr	x3, [x2, #0x58]
1001f6bc4: 91000463    	add	x3, x3, #0x1
1001f6bc8: f9002c43    	str	x3, [x2, #0x58]
1001f6bcc: aa1f03e0    	mov	x0, xzr
1001f6bd0: aa1f03e1    	mov	x1, xzr
1001f6bd4: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6bd8: f84107fe    	ldr	x30, [sp], #0x10
1001f6bdc: d65f03c0    	ret
1001f6be0: 97fa4034    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6be4: 97fa4033    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6be8: 97fa4032    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6bec: d503201f    	nop
1001f6bf0: a90087e0    	stp	x0, x1, [sp, #0x8]
1001f6bf4: a9018fe2    	stp	x2, x3, [sp, #0x18]
1001f6bf8: a90297e4    	stp	x4, x5, [sp, #0x28]
1001f6bfc: aa1e03e3    	mov	x3, x30
1001f6c00: 97fa37e8    	bl	0x100084ba0 <_runtime.morestack_noctxt.abi0>
1001f6c04: a94087e0    	ldp	x0, x1, [sp, #0x8]
1001f6c08: a9418fe2    	ldp	x2, x3, [sp, #0x18]
1001f6c0c: a94297e4    	ldp	x4, x5, [sp, #0x28]
1001f6c10: 17ffff78    	b	0x1001f69f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens>
		...

00000001001f6c20 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>:
1001f6c20: f9400b90    	ldr	x16, [x28, #0x10]
1001f6c24: eb3063ff    	cmp	sp, x16
1001f6c28: 54001a09    	b.ls	0x1001f6f68 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x348>
1001f6c2c: f81c0ffe    	str	x30, [sp, #-0x40]!
1001f6c30: f81f83fd    	stur	x29, [sp, #-0x8]
1001f6c34: d10023fd    	sub	x29, sp, #0x8
1001f6c38: b4000881    	cbz	x1, 0x1001f6d48 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x128>
1001f6c3c: b40007a0    	cbz	x0, 0x1001f6d30 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f6c40: b4000785    	cbz	x5, 0x1001f6d30 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f6c44: f100105f    	cmp	x2, #0x4
1001f6c48: 54000742    	b.hs	0x1001f6d30 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f6c4c: f1000c7f    	cmp	x3, #0x3
1001f6c50: 54000702    	b.hs	0x1001f6d30 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f6c54: f100049f    	cmp	x4, #0x1
1001f6c58: 540006c8    	b.hi	0x1001f6d30 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f6c5c: eb0400df    	cmp	x6, x4
1001f6c60: 540001cd    	b.le	0x1001f6c98 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x78>
1001f6c64: f10040df    	cmp	x6, #0x10
1001f6c68: 540000cc    	b.gt	0x1001f6c80 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x60>
1001f6c6c: d378dc47    	lsl	x7, x2, #8
1001f6c70: 8b070ce7    	add	x7, x7, x7, lsl #3
1001f6c74: aa1f03e8    	mov	x8, xzr
1001f6c78: aa0403e9    	mov	x9, x4
1001f6c7c: 1400003e    	b	0x1001f6d74 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x154>
1001f6c80: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6c84: 9132437b    	add	x27, x27, #0xc90
1001f6c88: a9400760    	ldp	x0, x1, [x27]
1001f6c8c: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6c90: f84407fe    	ldr	x30, [sp], #0x40
1001f6c94: d65f03c0    	ret
1001f6c98: d378dc45    	lsl	x5, x2, #8
1001f6c9c: 8b050ca5    	add	x5, x5, x5, lsl #3
1001f6ca0: 8b050005    	add	x5, x0, x5
1001f6ca4: d37be866    	lsl	x6, x3, #5
1001f6ca8: 8b0604c6    	add	x6, x6, x6, lsl #1
1001f6cac: 8b020c82    	add	x2, x4, x2, lsl #3
1001f6cb0: 8b020442    	add	x2, x2, x2, lsl #1
1001f6cb4: 8b020062    	add	x2, x3, x2
1001f6cb8: d2800163    	mov	x3, #0xb                ; =11
1001f6cbc: 9b037c42    	mul	x2, x2, x3
1001f6cc0: d37cec42    	lsl	x2, x2, #4
1001f6cc4: d2800163    	mov	x3, #0xb                ; =11
1001f6cc8: aa030042    	orr	x2, x2, x3
1001f6ccc: f100009f    	cmp	x4, #0x0
1001f6cd0: 9a9f07e3    	cset	x3, ne
1001f6cd4: 7200007f    	tst	w3, #0x1
1001f6cd8: d2802403    	mov	x3, #0x120              ; =288
1001f6cdc: 9a9f1063    	csel	x3, x3, xzr, ne
1001f6ce0: 8b050063    	add	x3, x3, x5
1001f6ce4: 8b060063    	add	x3, x3, x6
1001f6ce8: f9402c64    	ldr	x4, [x3, #0x58]
1001f6cec: 91000484    	add	x4, x4, #0x1
1001f6cf0: f9002c64    	str	x4, [x3, #0x58]
1001f6cf4: a9409023    	ldp	x3, x4, [x1, #0x8]
1001f6cf8: 91000465    	add	x5, x3, #0x1
1001f6cfc: d503201f    	nop
1001f6d00: eb05009f    	cmp	x4, x5
1001f6d04: 54000363    	b.lo	0x1001f6d70 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x150>
1001f6d08: f9000425    	str	x5, [x1, #0x8]
1001f6d0c: eb05007f    	cmp	x3, x5
1001f6d10: 540002e2    	b.hs	0x1001f6d6c <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x14c>
1001f6d14: f9400024    	ldr	x4, [x1]
1001f6d18: b8237882    	str	w2, [x4, x3, lsl #2]
1001f6d1c: aa1f03e0    	mov	x0, xzr
1001f6d20: aa1f03e1    	mov	x1, xzr
1001f6d24: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6d28: f84407fe    	ldr	x30, [sp], #0x40
1001f6d2c: d65f03c0    	ret
1001f6d30: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6d34: 9132437b    	add	x27, x27, #0xc90
1001f6d38: a9400760    	ldp	x0, x1, [x27]
1001f6d3c: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6d40: f84407fe    	ldr	x30, [sp], #0x40
1001f6d44: d65f03c0    	ret
1001f6d48: aa0203e1    	mov	x1, x2
1001f6d4c: aa0303e2    	mov	x2, x3
1001f6d50: aa0403e3    	mov	x3, x4
1001f6d54: aa0503e4    	mov	x4, x5
1001f6d58: aa0603e5    	mov	x5, x6
1001f6d5c: 97ffff25    	bl	0x1001f69f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens>
1001f6d60: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6d64: f84407fe    	ldr	x30, [sp], #0x40
1001f6d68: d65f03c0    	ret
1001f6d6c: 97fa3fd1    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6d70: 97fa3fd0    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6d74: eb0400df    	cmp	x6, x4
1001f6d78: 5400094d    	b.le	0x1001f6ea0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x280>
1001f6d7c: f000194a    	adrp	x10, 0x100521000 <_context..inittask+0xc0>
1001f6d80: 911b014a    	add	x10, x10, #0x6c0
1001f6d84: 78a4794b    	ldrsh	x11, [x10, x4, lsl #1]
1001f6d88: 92400d6b    	and	x11, x11, #0xf
1001f6d8c: 78ab78ab    	ldrsh	x11, [x5, x11, lsl #1]
1001f6d90: ca8bfd6c    	eor	x12, x11, x11, asr #63
1001f6d94: cb8bfd8c    	sub	x12, x12, x11, asr #63
1001f6d98: f120019f    	cmp	x12, #0x800
1001f6d9c: 54000768    	b.hi	0x1001f6e88 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x268>
1001f6da0: 8b07000d    	add	x13, x0, x7
1001f6da4: d37b092e    	ubfiz	x14, x9, #5, #3
1001f6da8: 8b0e0dce    	add	x14, x14, x14, lsl #3
1001f6dac: b0001c4f    	adrp	x15, 0x10057f000 <_github.com/thesyncim/govpx/internal/vp8/encoder.coefficientTokenLUT+0x1e0>
1001f6db0: 911901ef    	add	x15, x15, #0x640
1001f6db4: 386c69f0    	ldrb	w16, [x15, x12]
1001f6db8: 8b0e01ad    	add	x13, x13, x14
1001f6dbc: f1000c7f    	cmp	x3, #0x3
1001f6dc0: 54000d02    	b.hs	0x1001f6f60 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x340>
1001f6dc4: aa1003ee    	mov	x14, x16
1001f6dc8: d37be871    	lsl	x17, x3, #5
1001f6dcc: 8b110631    	add	x17, x17, x17, lsl #1
1001f6dd0: 8b1101ad    	add	x13, x13, x17
1001f6dd4: f10031df    	cmp	x14, #0xc
1001f6dd8: 54000c22    	b.hs	0x1001f6f5c <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x33c>
1001f6ddc: 937ffd6b    	asr	x11, x11, #63
1001f6de0: f86e79b1    	ldr	x17, [x13, x14, lsl #3]
1001f6de4: 91000631    	add	x17, x17, #0x1
1001f6de8: f82e79b1    	str	x17, [x13, x14, lsl #3]
1001f6dec: aa1003ed    	mov	x13, x16
1001f6df0: 8b020d30    	add	x16, x9, x2, lsl #3
1001f6df4: 8b100610    	add	x16, x16, x16, lsl #1
1001f6df8: 8b100070    	add	x16, x3, x16
1001f6dfc: d2800171    	mov	x17, #0xb               ; =11
1001f6e00: 9b107e30    	mul	x16, x17, x16
1001f6e04: aa1011ad    	orr	x13, x13, x16, lsl #4
1001f6e08: aa0c3dac    	orr	x12, x13, x12, lsl #15
1001f6e0c: 9240016b    	and	x11, x11, #0x1
1001f6e10: aa0b6d8b    	orr	x11, x12, x11, lsl #27
1001f6e14: d3401d0c    	ubfx	x12, x8, #0, #8
1001f6e18: a940c02d    	ldp	x13, x16, [x1, #0x8]
1001f6e1c: 910005b3    	add	x19, x13, #0x1
1001f6e20: d503201f    	nop
1001f6e24: aa0c716b    	orr	x11, x11, x12, lsl #28
1001f6e28: eb13021f    	cmp	x16, x19
1001f6e2c: 54000923    	b.lo	0x1001f6f50 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x330>
1001f6e30: f9000433    	str	x19, [x1, #0x8]
1001f6e34: eb1301bf    	cmp	x13, x19
1001f6e38: 54000882    	b.hs	0x1001f6f48 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x328>
1001f6e3c: 91000484    	add	x4, x4, #0x1
1001f6e40: f940002c    	ldr	x12, [x1]
1001f6e44: b82d798b    	str	w11, [x12, x13, lsl #2]
1001f6e48: f100409f    	cmp	x4, #0x10
1001f6e4c: 5400014a    	b.ge	0x1001f6e74 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x254>
1001f6e50: d000194b    	adrp	x11, 0x100520000 <_go:buildinfo>
1001f6e54: 912c816b    	add	x11, x11, #0xb20
1001f6e58: 38646969    	ldrb	w9, [x11, x4]
1001f6e5c: d000194c    	adrp	x12, 0x100520000 <_go:buildinfo>
1001f6e60: 9126e18c    	add	x12, x12, #0x9b8
1001f6e64: 386e6983    	ldrb	w3, [x12, x14]
1001f6e68: f100007f    	cmp	x3, #0x0
1001f6e6c: 9a9f17e8    	cset	x8, eq
1001f6e70: 17ffffc1    	b	0x1001f6d74 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x154>
1001f6e74: d000194b    	adrp	x11, 0x100520000 <_go:buildinfo>
1001f6e78: 912c816b    	add	x11, x11, #0xb20
1001f6e7c: d000194c    	adrp	x12, 0x100520000 <_go:buildinfo>
1001f6e80: 9126e18c    	add	x12, x12, #0x9b8
1001f6e84: 17ffffbc    	b	0x1001f6d74 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x154>
1001f6e88: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6e8c: 9132437b    	add	x27, x27, #0xc90
1001f6e90: a9400760    	ldp	x0, x1, [x27]
1001f6e94: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6e98: f84407fe    	ldr	x30, [sp], #0x40
1001f6e9c: d65f03c0    	ret
1001f6ea0: f10040df    	cmp	x6, #0x10
1001f6ea4: 5400042a    	b.ge	0x1001f6f28 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x308>
1001f6ea8: d378dc44    	lsl	x4, x2, #8
1001f6eac: 8b040c84    	add	x4, x4, x4, lsl #3
1001f6eb0: 8b040004    	add	x4, x0, x4
1001f6eb4: d37b0925    	ubfiz	x5, x9, #5, #3
1001f6eb8: 8b050ca5    	add	x5, x5, x5, lsl #3
1001f6ebc: 8b050084    	add	x4, x4, x5
1001f6ec0: f1000c7f    	cmp	x3, #0x3
1001f6ec4: 54000402    	b.hs	0x1001f6f44 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x324>
1001f6ec8: d37be865    	lsl	x5, x3, #5
1001f6ecc: 8b0504a5    	add	x5, x5, x5, lsl #1
1001f6ed0: 8b050084    	add	x4, x4, x5
1001f6ed4: f9402c85    	ldr	x5, [x4, #0x58]
1001f6ed8: 910004a5    	add	x5, x5, #0x1
1001f6edc: f9002c85    	str	x5, [x4, #0x58]
1001f6ee0: 8b020d22    	add	x2, x9, x2, lsl #3
1001f6ee4: 8b020442    	add	x2, x2, x2, lsl #1
1001f6ee8: 8b020062    	add	x2, x3, x2
1001f6eec: d2800163    	mov	x3, #0xb                ; =11
1001f6ef0: 9b027c62    	mul	x2, x3, x2
1001f6ef4: d37cec42    	lsl	x2, x2, #4
1001f6ef8: a9409023    	ldp	x3, x4, [x1, #0x8]
1001f6efc: 91000465    	add	x5, x3, #0x1
1001f6f00: d503201f    	nop
1001f6f04: d2800166    	mov	x6, #0xb                ; =11
1001f6f08: aa060042    	orr	x2, x2, x6
1001f6f0c: eb05009f    	cmp	x4, x5
1001f6f10: 54000183    	b.lo	0x1001f6f40 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x320>
1001f6f14: f9000425    	str	x5, [x1, #0x8]
1001f6f18: eb05007f    	cmp	x3, x5
1001f6f1c: 54000102    	b.hs	0x1001f6f3c <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x31c>
1001f6f20: f9400024    	ldr	x4, [x1]
1001f6f24: b8237882    	str	w2, [x4, x3, lsl #2]
1001f6f28: aa1f03e0    	mov	x0, xzr
1001f6f2c: aa1f03e1    	mov	x1, xzr
1001f6f30: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6f34: f84407fe    	ldr	x30, [sp], #0x40
1001f6f38: d65f03c0    	ret
1001f6f3c: 97fa3f5d    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6f40: 97fa3f5c    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6f44: 97fa3f5b    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6f48: aa1303e0    	mov	x0, x19
1001f6f4c: 97fa3f59    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6f50: aa1303e0    	mov	x0, x19
1001f6f54: aa1003e1    	mov	x1, x16
1001f6f58: 97fa3f56    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6f5c: 97fa3f55    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6f60: 97fa3f54    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6f64: d503201f    	nop
1001f6f68: a90087e0    	stp	x0, x1, [sp, #0x8]
1001f6f6c: a9018fe2    	stp	x2, x3, [sp, #0x18]
1001f6f70: a90297e4    	stp	x4, x5, [sp, #0x28]
1001f6f74: f9001fe6    	str	x6, [sp, #0x38]
1001f6f78: aa1e03e3    	mov	x3, x30
1001f6f7c: 97fa3709    	bl	0x100084ba0 <_runtime.morestack_noctxt.abi0>
1001f6f80: a94087e0    	ldp	x0, x1, [sp, #0x8]
1001f6f84: a9418fe2    	ldp	x2, x3, [sp, #0x18]
1001f6f88: a94297e4    	ldp	x4, x5, [sp, #0x28]
1001f6f8c: f9401fe6    	ldr	x6, [sp, #0x38]
1001f6f90: 17ffff24    	b	0x1001f6c20 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>
		...

0000000100237bd0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51>:
100237bd0: f9400b90    	ldr	x16, [x28, #0x10]
100237bd4: d10183f1    	sub	x17, sp, #0x60
100237bd8: eb10023f    	cmp	x17, x16
100237bdc: 540012a9    	b.ls	0x100237e30 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x260>
100237be0: f8120ffe    	str	x30, [sp, #-0xe0]!
100237be4: f81f83fd    	stur	x29, [sp, #-0x8]
100237be8: d10023fd    	sub	x29, sp, #0x8
100237bec: f90077e0    	str	x0, [sp, #0xe8]
100237bf0: 79006fff    	strh	wzr, [sp, #0x36]
100237bf4: b24003e1    	orr	x1, xzr, #0x1
100237bf8: 3900dfe1    	strb	w1, [sp, #0x37]
100237bfc: aa1f03e1    	mov	x1, xzr
100237c00: 14000004    	b	0x100237c10 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x40>
100237c04: f9402be2    	ldr	x2, [sp, #0x50]
100237c08: 91000441    	add	x1, x2, #0x1
100237c0c: f94077e0    	ldr	x0, [sp, #0xe8]
100237c10: f100083f    	cmp	x1, #0x2
100237c14: 5400108a    	b.ge	0x100237e24 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x254>
100237c18: f9002be1    	str	x1, [sp, #0x50]
100237c1c: 9100dbe2    	add	x2, sp, #0x36
100237c20: 38616841    	ldrb	w1, [x2, x1]
100237c24: 3900cfe1    	strb	w1, [sp, #0x33]
100237c28: 90001580    	adrp	x0, 0x1004e7000 <_type:*+0x3a188>
100237c2c: 913bc000    	add	x0, x0, #0xef0
100237c30: 97f788d0    	bl	0x100019f70 <_runtime.newobject>
100237c34: f9006be0    	str	x0, [sp, #0xd0]
100237c38: 3940cfe1    	ldrb	w1, [sp, #0x33]
100237c3c: 39000001    	strb	w1, [x0]
100237c40: f0000161    	adrp	x1, 0x100266000 <_runtime.rodata+0x1a0>
100237c44: 91032021    	add	x1, x1, #0xc8
100237c48: b27e03e2    	orr	x2, xzr, #0x4
100237c4c: a9068be1    	stp	x1, x2, [sp, #0x68]
100237c50: f0000161    	adrp	x1, 0x100266000 <_runtime.rodata+0x1a0>
100237c54: 9115f021    	add	x1, x1, #0x57c
100237c58: b27f07e2    	orr	x2, xzr, #0x6
100237c5c: a9078be1    	stp	x1, x2, [sp, #0x78]
100237c60: f0000161    	adrp	x1, 0x100266000 <_runtime.rodata+0x1a0>
100237c64: 910bb821    	add	x1, x1, #0x2ee
100237c68: d28000a2    	mov	x2, #0x5                ; =5
100237c6c: a9088be1    	stp	x1, x2, [sp, #0x88]
100237c70: 9101a3e1    	add	x1, sp, #0x68
100237c74: aa1f03e2    	mov	x2, xzr
100237c78: 14000007    	b	0x100237c94 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0xc4>
100237c7c: f94033e3    	ldr	x3, [sp, #0x60]
100237c80: 91004061    	add	x1, x3, #0x10
100237c84: f94027e3    	ldr	x3, [sp, #0x48]
100237c88: 91000463    	add	x3, x3, #0x1
100237c8c: f9406be0    	ldr	x0, [sp, #0xd0]
100237c90: aa0303e2    	mov	x2, x3
100237c94: f1000c5f    	cmp	x2, #0x3
100237c98: 54fffb6a    	b.ge	0x100237c04 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x34>
100237c9c: f90027e2    	str	x2, [sp, #0x48]
100237ca0: f90033e1    	str	x1, [sp, #0x60]
100237ca4: a9401023    	ldp	x3, x4, [x1]
100237ca8: f90023e4    	str	x4, [sp, #0x40]
100237cac: f9002fe3    	str	x3, [sp, #0x58]
100237cb0: b27c03e0    	orr	x0, xzr, #0x10
100237cb4: 90001581    	adrp	x1, 0x1004e7000 <_type:*+0x3a188>
100237cb8: 912bc021    	add	x1, x1, #0xaf0
100237cbc: b24003e2    	orr	x2, xzr, #0x1
100237cc0: 97f78aec    	bl	0x10001a870 <_runtime.mallocgcSmallScanNoHeaderSC2>
100237cc4: f94023e3    	ldr	x3, [sp, #0x40]
100237cc8: f9000403    	str	x3, [x0, #0x8]
100237ccc: b0001a1b    	adrp	x27, 0x100578000 <_runtime.mheap_+0x187e0>
100237cd0: b94dc363    	ldr	w3, [x27, #0xdc0]
100237cd4: 35000063    	cbnz	w3, 0x100237ce0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x110>
100237cd8: f9402fe3    	ldr	x3, [sp, #0x58]
100237cdc: 14000004    	b	0x100237cec <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x11c>
100237ce0: 97f93b3c    	bl	0x1000869d0 <_runtime.gcWriteBarrier1>
100237ce4: f9402fe3    	ldr	x3, [sp, #0x58]
100237ce8: f9000323    	str	x3, [x25]
100237cec: f90067e0    	str	x0, [sp, #0xc8]
100237cf0: f9000003    	str	x3, [x0]
100237cf4: 79006bff    	strh	wzr, [sp, #0x34]
100237cf8: b24003e2    	orr	x2, xzr, #0x1
100237cfc: 3900d7e2    	strb	w2, [sp, #0x35]
100237d00: aa1f03e1    	mov	x1, xzr
100237d04: 1400000e    	b	0x100237d3c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x16c>
100237d08: f9000404    	str	x4, [x0, #0x8]
100237d0c: 3940cbe4    	ldrb	w4, [sp, #0x32]
100237d10: 39004004    	strb	w4, [x0, #0x10]
100237d14: f9000c05    	str	x5, [x0, #0x18]
100237d18: f9402fe1    	ldr	x1, [sp, #0x58]
100237d1c: f9401fe2    	ldr	x2, [sp, #0x38]
100237d20: aa0003e3    	mov	x3, x0
100237d24: f94077e0    	ldr	x0, [sp, #0xe8]
100237d28: 97fae67e    	bl	0x1000f1720 <_testing.(*B).Run>
100237d2c: f94023e4    	ldr	x4, [sp, #0x40]
100237d30: 91000481    	add	x1, x4, #0x1
100237d34: f94067e0    	ldr	x0, [sp, #0xc8]
100237d38: b24003e2    	orr	x2, xzr, #0x1
100237d3c: f100083f    	cmp	x1, #0x2
100237d40: 54fff9ea    	b.ge	0x100237c7c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0xac>
100237d44: f90023e1    	str	x1, [sp, #0x40]
100237d48: 9100d3e2    	add	x2, sp, #0x34
100237d4c: 38616842    	ldrb	w2, [x2, x1]
100237d50: 3900cbe2    	strb	w2, [sp, #0x32]
100237d54: 910263e2    	add	x2, sp, #0x98
100237d58: a9007c5f    	stp	xzr, xzr, [x2]
100237d5c: a9017c5f    	stp	xzr, xzr, [x2, #0x10]
100237d60: a9027c5f    	stp	xzr, xzr, [x2, #0x20]
100237d64: f9406be2    	ldr	x2, [sp, #0xd0]
100237d68: 39400042    	ldrb	w2, [x2]
100237d6c: d0000283    	adrp	x3, 0x100289000 <_runtime.modinfo.str+0x13c0>
100237d70: 910d8063    	add	x3, x3, #0x360
100237d74: 8b020c62    	add	x2, x3, x2, lsl #3
100237d78: 90001583    	adrp	x3, 0x1004e7000 <_type:*+0x3a188>
100237d7c: 913bc063    	add	x3, x3, #0xef0
100237d80: a9098be3    	stp	x3, x2, [sp, #0x98]
100237d84: a9400400    	ldp	x0, x1, [x0]
100237d88: 97f91752    	bl	0x10007dad0 <_runtime.convTstring>
100237d8c: 90001582    	adrp	x2, 0x1004e7000 <_type:*+0x3a188>
100237d90: 912bc042    	add	x2, x2, #0xaf0
100237d94: a90a83e2    	stp	x2, x0, [sp, #0xa8]
100237d98: 3940cbe2    	ldrb	w2, [sp, #0x32]
100237d9c: d0000283    	adrp	x3, 0x100289000 <_runtime.modinfo.str+0x13c0>
100237da0: 910d8063    	add	x3, x3, #0x360
100237da4: 8b020c62    	add	x2, x3, x2, lsl #3
100237da8: 90001583    	adrp	x3, 0x1004e7000 <_type:*+0x3a188>
100237dac: 913bc063    	add	x3, x3, #0xef0
100237db0: a90b8be3    	stp	x3, x2, [sp, #0xb8]
100237db4: f0000180    	adrp	x0, 0x10026a000 <_runtime.rodata+0x41a0>
100237db8: 910bdc00    	add	x0, x0, #0x2f7
100237dbc: d2800241    	mov	x1, #0x12               ; =18
100237dc0: 910263e2    	add	x2, sp, #0x98
100237dc4: b24007e3    	orr	x3, xzr, #0x3
100237dc8: aa0303e4    	mov	x4, x3
100237dcc: 97fa7071    	bl	0x1000d3f90 <_fmt.Sprintf>
100237dd0: f9002fe0    	str	x0, [sp, #0x58]
100237dd4: f9001fe1    	str	x1, [sp, #0x38]
100237dd8: b27b03e0    	orr	x0, xzr, #0x20
100237ddc: b0001641    	adrp	x1, 0x100500000 <_type:*+0x53188>
100237de0: 913ec021    	add	x1, x1, #0xfb0
100237de4: b24003e2    	orr	x2, xzr, #0x1
100237de8: 97f78c6e    	bl	0x10001afa0 <_runtime.mallocgcSmallScanNoHeaderSC4>
100237dec: b0000082    	adrp	x2, 0x100248000 <_github.com/thesyncim/govpx/internal/vp8/encoder.TestWriteKeyFrameStateHeaderAllocatesZero.func1+0x10>
100237df0: 91078042    	add	x2, x2, #0x1e0
100237df4: f9000002    	str	x2, [x0]
100237df8: b0001a1b    	adrp	x27, 0x100578000 <_runtime.mheap_+0x187e0>
100237dfc: b94dc362    	ldr	w2, [x27, #0xdc0]
100237e00: 35000082    	cbnz	w2, 0x100237e10 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x240>
100237e04: f94067e4    	ldr	x4, [sp, #0xc8]
100237e08: f9406be5    	ldr	x5, [sp, #0xd0]
100237e0c: 17ffffbf    	b	0x100237d08 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x138>
100237e10: 97f93af4    	bl	0x1000869e0 <_runtime.gcWriteBarrier2>
100237e14: f94067e4    	ldr	x4, [sp, #0xc8]
100237e18: f9406be5    	ldr	x5, [sp, #0xd0]
100237e1c: a9001724    	stp	x4, x5, [x25]
100237e20: 17ffffba    	b	0x100237d08 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x138>
100237e24: f85f83fd    	ldur	x29, [sp, #-0x8]
100237e28: f84e07fe    	ldr	x30, [sp], #0xe0
100237e2c: d65f03c0    	ret
100237e30: f90007e0    	str	x0, [sp, #0x8]
100237e34: aa1e03e3    	mov	x3, x30
100237e38: 97f9335a    	bl	0x100084ba0 <_runtime.morestack_noctxt.abi0>
100237e3c: f94007e0    	ldr	x0, [sp, #0x8]
100237e40: 17ffff64    	b	0x100237bd0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51>
		...

00000001002481e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1>:
1002481e0: f9400b90    	ldr	x16, [x28, #0x10]
1002481e4: d28f9a1b    	mov	x27, #0x7cd0            ; =31952
1002481e8: eb3b63f1    	subs	x17, sp, x27
1002481ec: 54004723    	b.lo	0x100248ad0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x8f0>
1002481f0: eb10023f    	cmp	x17, x16
1002481f4: 540046e9    	b.ls	0x100248ad0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x8f0>
1002481f8: d28faa1b    	mov	x27, #0x7d50            ; =32080
1002481fc: cb3b63f4    	sub	x20, sp, x27
100248200: a93ffa9d    	stp	x29, x30, [x20, #-0x8]
100248204: 9100029f    	mov	sp, x20
100248208: d10023fd    	sub	x29, sp, #0x8
10024820c: f93eafe0    	str	x0, [sp, #0x7d58]
100248210: f9400743    	ldr	x3, [x26, #0x8]
100248214: f9400f44    	ldr	x4, [x26, #0x18]
100248218: f93ea3e4    	str	x4, [sp, #0x7d40]
10024821c: 39404345    	ldrb	w5, [x26, #0x10]
100248220: 390143e5    	strb	w5, [sp, #0x50]
100248224: 9101fbe6    	add	x6, sp, #0x7e
100248228: b27e07e7    	orr	x7, xzr, #0xc
10024822c: a8817cdf    	stp	xzr, xzr, [x6], #0x10
100248230: a8817cdf    	stp	xzr, xzr, [x6], #0x10
100248234: a8817cdf    	stp	xzr, xzr, [x6], #0x10
100248238: a8817cdf    	stp	xzr, xzr, [x6], #0x10
10024823c: d10004e7    	sub	x7, x7, #0x1
100248240: b5ffff67    	cbnz	x7, 0x10024822c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4c>
100248244: a9007cdf    	stp	xzr, xzr, [x6]
100248248: a9017cdf    	stp	xzr, xzr, [x6, #0x10]
10024824c: a9027cdf    	stp	xzr, xzr, [x6, #0x20]
100248250: f90018df    	str	xzr, [x6, #0x30]
100248254: f80320df    	stur	xzr, [x6, #0x32]
100248258: a9401c66    	ldp	x6, x7, [x3]
10024825c: f10010ff    	cmp	x7, #0x4
100248260: 540000c1    	b.ne	0x100248278 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x98>
100248264: b94000c6    	ldr	w6, [x6]
100248268: d28caf47    	mov	x7, #0x657a             ; =25978
10024826c: f2adee47    	movk	x7, #0x6f72, lsl #16
100248270: 6b0700df    	cmp	w6, w7
100248274: 54000060    	b.eq	0x100248280 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0xa0>
100248278: aa1f03e1    	mov	x1, xzr
10024827c: 140001eb    	b	0x100248a28 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x848>
100248280: f80633ff    	stur	xzr, [sp, #0x63]
100248284: 3901afff    	strb	wzr, [sp, #0x6b]
100248288: b24003e3    	orr	x3, xzr, #0x1
10024828c: 39018fe3    	strb	w3, [sp, #0x63]
100248290: 390197e3    	strb	w3, [sp, #0x65]
100248294: 39019fe3    	strb	w3, [sp, #0x67]
100248298: d2802023    	mov	x3, #0x101              ; =257
10024829c: 7900d7e3    	strh	w3, [sp, #0x6a]
1002482a0: f805a3ff    	stur	xzr, [sp, #0x5a]
1002482a4: 39018bff    	strb	wzr, [sp, #0x62]
1002482a8: 910ee3e3    	add	x3, sp, #0x3b8
1002482ac: d2801204    	mov	x4, #0x90               ; =144
1002482b0: a8817c7f    	stp	xzr, xzr, [x3], #0x10
1002482b4: a8817c7f    	stp	xzr, xzr, [x3], #0x10
1002482b8: a8817c7f    	stp	xzr, xzr, [x3], #0x10
1002482bc: a8817c7f    	stp	xzr, xzr, [x3], #0x10
1002482c0: d1000484    	sub	x4, x4, #0x1
1002482c4: b5ffff64    	cbnz	x4, 0x1002482b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0xd0>
1002482c8: 91400be3    	add	x3, sp, #0x2, lsl #12   ; =0x2000
1002482cc: 911f0063    	add	x3, x3, #0x7c0
1002482d0: d2801204    	mov	x4, #0x90               ; =144
1002482d4: a8817c7f    	stp	xzr, xzr, [x3], #0x10
1002482d8: a8817c7f    	stp	xzr, xzr, [x3], #0x10
1002482dc: a8817c7f    	stp	xzr, xzr, [x3], #0x10
1002482e0: a8817c7f    	stp	xzr, xzr, [x3], #0x10
1002482e4: d1000484    	sub	x4, x4, #0x1
1002482e8: b5ffff64    	cbnz	x4, 0x1002482d4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0xf4>
1002482ec: f84633e3    	ldur	x3, [sp, #0x63]
1002482f0: 3941afe4    	ldrb	w4, [sp, #0x6b]
1002482f4: f80513e3    	stur	x3, [sp, #0x51]
1002482f8: 390167e4    	strb	w4, [sp, #0x59]
1002482fc: f845a3e3    	ldur	x3, [sp, #0x5a]
100248300: 39418be4    	ldrb	w4, [sp, #0x62]
100248304: f80473e3    	stur	x3, [sp, #0x47]
100248308: 39013fe4    	strb	w4, [sp, #0x4f]
10024830c: f84633e3    	ldur	x3, [sp, #0x63]
100248310: 3941afe4    	ldrb	w4, [sp, #0x6b]
100248314: f80753e3    	stur	x3, [sp, #0x75]
100248318: 3901f7e4    	strb	w4, [sp, #0x7d]
10024831c: f845a3e3    	ldur	x3, [sp, #0x5a]
100248320: 39418be4    	ldrb	w4, [sp, #0x62]
100248324: f806c3e3    	stur	x3, [sp, #0x6c]
100248328: 3901d3e4    	strb	w4, [sp, #0x74]
10024832c: f00014e0    	adrp	x0, 0x1004e7000 <_type:*+0x3a188>
100248330: 912ac000    	add	x0, x0, #0xab0
100248334: aa1f03e1    	mov	x1, xzr
100248338: b27907e2    	orr	x2, xzr, #0x180
10024833c: 97f8e5f5    	bl	0x100081b10 <_runtime.makeslice>
100248340: f93e9fe0    	str	x0, [sp, #0x7d38]
100248344: f00014e0    	adrp	x0, 0x1004e7000 <_type:*+0x3a188>
100248348: 912ac000    	add	x0, x0, #0xab0
10024834c: aa1f03e1    	mov	x1, xzr
100248350: b27907e2    	orr	x2, xzr, #0x180
100248354: 97f8e5ef    	bl	0x100081b10 <_runtime.makeslice>
100248358: 91401be3    	add	x3, sp, #0x6, lsl #12   ; =0x6000
10024835c: 9133a063    	add	x3, x3, #0xce8
100248360: d2800824    	mov	x4, #0x41               ; =65
100248364: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100248368: a8817c7f    	stp	xzr, xzr, [x3], #0x10
10024836c: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100248370: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100248374: d1000484    	sub	x4, x4, #0x1
100248378: b5ffff64    	cbnz	x4, 0x100248364 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x184>
10024837c: f93677e0    	str	x0, [sp, #0x6ce8]
100248380: b27907e3    	orr	x3, xzr, #0x180
100248384: f9367fe3    	str	x3, [sp, #0x6cf8]
100248388: 914013e4    	add	x4, sp, #0x4, lsl #12   ; =0x4000
10024838c: 91314084    	add	x4, x4, #0xc50
100248390: d2800825    	mov	x5, #0x41               ; =65
100248394: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100248398: a8817c9f    	stp	xzr, xzr, [x4], #0x10
10024839c: a8817c9f    	stp	xzr, xzr, [x4], #0x10
1002483a0: a8817c9f    	stp	xzr, xzr, [x4], #0x10
1002483a4: d10004a5    	sub	x5, x5, #0x1
1002483a8: b5ffff65    	cbnz	x5, 0x100248394 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x1b4>
1002483ac: f97e9fe4    	ldr	x4, [sp, #0x7d38]
1002483b0: f9262be4    	str	x4, [sp, #0x4c50]
1002483b4: f92633e3    	str	x3, [sp, #0x4c60]
1002483b8: 914017e3    	add	x3, sp, #0x5, lsl #12   ; =0x5000
1002483bc: 91324063    	add	x3, x3, #0xc90
1002483c0: 91401be4    	add	x4, sp, #0x6, lsl #12   ; =0x6000
1002483c4: 9133a084    	add	x4, x4, #0xce8
1002483c8: d2800838    	mov	x24, #0x41              ; =65
1002483cc: acc14490    	ldp	q16, q17, [x4], #0x20
1002483d0: ac814470    	stp	q16, q17, [x3], #0x20
1002483d4: acc14490    	ldp	q16, q17, [x4], #0x20
1002483d8: ac814470    	stp	q16, q17, [x3], #0x20
1002483dc: d1000718    	sub	x24, x24, #0x1
1002483e0: b5ffff78    	cbnz	x24, 0x1002483cc <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x1ec>
1002483e4: f97ea3e3    	ldr	x3, [sp, #0x7d40]
1002483e8: 39400060    	ldrb	w0, [x3]
1002483ec: 394143e3    	ldrb	w3, [sp, #0x50]
1002483f0: 7200007f    	tst	w3, #0x1
1002483f4: 914013e3    	add	x3, sp, #0x4, lsl #12   ; =0x4000
1002483f8: 91314063    	add	x3, x3, #0xc50
1002483fc: 9a9f1065    	csel	x5, x3, xzr, ne
100248400: 910147e1    	add	x1, sp, #0x51
100248404: 91011fe2    	add	x2, sp, #0x47
100248408: 9101fbe3    	add	x3, sp, #0x7e
10024840c: 910ee3e4    	add	x4, sp, #0x3b8
100248410: 97ffbe90    	bl	0x100237e50 <_github.com/thesyncim/govpx/internal/vp8/encoder.tokenCountFrozenMacro51>
100248414: 394143e3    	ldrb	w3, [sp, #0x50]
100248418: 7200007f    	tst	w3, #0x1
10024841c: b4000240    	cbz	x0, 0x100248464 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x284>
100248420: 9134a3fb    	add	x27, sp, #0xd28
100248424: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
100248428: a9007f7f    	stp	xzr, xzr, [x27]
10024842c: b4000040    	cbz	x0, 0x100248434 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x254>
100248430: f9400400    	ldr	x0, [x0, #0x8]
100248434: 9134a3fb    	add	x27, sp, #0xd28
100248438: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
10024843c: a9000760    	stp	x0, x1, [x27]
100248440: f97eafe0    	ldr	x0, [sp, #0x7d58]
100248444: 3980001b    	ldrsb	x27, [x0]
100248448: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
10024844c: 9134a021    	add	x1, x1, #0xd28
100248450: b24003e2    	orr	x2, xzr, #0x1
100248454: aa0203e3    	mov	x3, x2
100248458: 97fac4d2    	bl	0x1000f97a0 <_testing.(*common).Fatal>
10024845c: 394143e4    	ldrb	w4, [sp, #0x50]
100248460: 7200009f    	tst	w4, #0x1
100248464: 914017e6    	add	x6, sp, #0x5, lsl #12   ; =0x5000
100248468: 913240c6    	add	x6, x6, #0xc90
10024846c: 9a9f10c5    	csel	x5, x6, xzr, ne
100248470: f9366be5    	str	x5, [sp, #0x6cd0]
100248474: f97ea3e6    	ldr	x6, [sp, #0x7d40]
100248478: 394000c0    	ldrb	w0, [x6]
10024847c: 9101d7e1    	add	x1, sp, #0x75
100248480: 9101b3e2    	add	x2, sp, #0x6c
100248484: 9101fbe3    	add	x3, sp, #0x7e
100248488: 91400be4    	add	x4, sp, #0x2, lsl #12   ; =0x2000
10024848c: 911f0084    	add	x4, x4, #0x7c0
100248490: 97feb7f4    	bl	0x1001f6460 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords>
100248494: b4000200    	cbz	x0, 0x1002484d4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x2f4>
100248498: 9134a3fb    	add	x27, sp, #0xd28
10024849c: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
1002484a0: a9007f7f    	stp	xzr, xzr, [x27]
1002484a4: b4000040    	cbz	x0, 0x1002484ac <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x2cc>
1002484a8: f9400400    	ldr	x0, [x0, #0x8]
1002484ac: 9134a3fb    	add	x27, sp, #0xd28
1002484b0: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
1002484b4: a9000760    	stp	x0, x1, [x27]
1002484b8: f97eafe0    	ldr	x0, [sp, #0x7d58]
1002484bc: 3980001b    	ldrsb	x27, [x0]
1002484c0: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
1002484c4: 9134a021    	add	x1, x1, #0xd28
1002484c8: b24003e2    	orr	x2, xzr, #0x1
1002484cc: aa0203e3    	mov	x3, x2
1002484d0: 97fac4b4    	bl	0x1000f97a0 <_testing.(*common).Fatal>
1002484d4: b84753e4    	ldur	w4, [sp, #0x75]
1002484d8: b84513e5    	ldur	w5, [sp, #0x51]
1002484dc: d503201f    	nop
1002484e0: 6b0400bf    	cmp	w5, w4
1002484e4: 540007c1    	b.ne	0x1002485dc <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3fc>
1002484e8: 784793e4    	ldurh	w4, [sp, #0x79]
1002484ec: 784553e5    	ldurh	w5, [sp, #0x55]
1002484f0: 6b05009f    	cmp	w4, w5
1002484f4: 54000701    	b.ne	0x1002485d4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3f4>
1002484f8: 7847b3e4    	ldurh	w4, [sp, #0x7b]
1002484fc: 784573e5    	ldurh	w5, [sp, #0x57]
100248500: 6b05009f    	cmp	w4, w5
100248504: 54000641    	b.ne	0x1002485cc <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3ec>
100248508: 394167e4    	ldrb	w4, [sp, #0x59]
10024850c: 3941f7e5    	ldrb	w5, [sp, #0x7d]
100248510: 6b0400bf    	cmp	w5, w4
100248514: 54000581    	b.ne	0x1002485c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3e4>
100248518: b9406fe4    	ldr	w4, [sp, #0x6c]
10024851c: b84473e5    	ldur	w5, [sp, #0x47]
100248520: 6b0400bf    	cmp	w5, w4
100248524: 540004c1    	b.ne	0x1002485bc <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3dc>
100248528: 7940e3e4    	ldrh	w4, [sp, #0x70]
10024852c: 7844b3e5    	ldurh	w5, [sp, #0x4b]
100248530: 6b0400bf    	cmp	w5, w4
100248534: 54000401    	b.ne	0x1002485b4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3d4>
100248538: 7940e7e4    	ldrh	w4, [sp, #0x72]
10024853c: 7844d3e5    	ldurh	w5, [sp, #0x4d]
100248540: 6b0400bf    	cmp	w5, w4
100248544: 54000341    	b.ne	0x1002485ac <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3cc>
100248548: 39413fe4    	ldrb	w4, [sp, #0x4f]
10024854c: 3941d3e5    	ldrb	w5, [sp, #0x74]
100248550: 6b05009f    	cmp	w4, w5
100248554: 54000060    	b.eq	0x100248560 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x380>
100248558: b24003e3    	orr	x3, xzr, #0x1
10024855c: 14000021    	b	0x1002485e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
100248560: 913143fb    	add	x27, sp, #0xc50
100248564: 9140137b    	add	x27, x27, #0x4, lsl #12 ; =0x4000
100248568: a9400760    	ldp	x0, x1, [x27]
10024856c: f96633e2    	ldr	x2, [sp, #0x4c60]
100248570: 97f8d580    	bl	0x10007db70 <_runtime.convTslice>
100248574: f93e9fe0    	str	x0, [sp, #0x7d38]
100248578: 913243fb    	add	x27, sp, #0xc90
10024857c: 9140177b    	add	x27, x27, #0x5, lsl #12 ; =0x5000
100248580: a9400760    	ldp	x0, x1, [x27]
100248584: f96e53e2    	ldr	x2, [sp, #0x5ca0]
100248588: 97f8d57a    	bl	0x10007db70 <_runtime.convTslice>
10024858c: f97e9fe1    	ldr	x1, [sp, #0x7d38]
100248590: 90001422    	adrp	x2, 0x1004cc000 <_type:*+0x1f188>
100248594: 91108042    	add	x2, x2, #0x420
100248598: aa0003e3    	mov	x3, x0
10024859c: aa0203e0    	mov	x0, x2
1002485a0: 97f9d650    	bl	0x1000bdee0 <_reflect.DeepEqual>
1002485a4: d2400003    	eor	x3, x0, #0x1
1002485a8: 1400000e    	b	0x1002485e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
1002485ac: b24003e3    	orr	x3, xzr, #0x1
1002485b0: 1400000c    	b	0x1002485e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
1002485b4: b24003e3    	orr	x3, xzr, #0x1
1002485b8: 1400000a    	b	0x1002485e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
1002485bc: b24003e3    	orr	x3, xzr, #0x1
1002485c0: 14000008    	b	0x1002485e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
1002485c4: b24003e3    	orr	x3, xzr, #0x1
1002485c8: 14000006    	b	0x1002485e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
1002485cc: b24003e3    	orr	x3, xzr, #0x1
1002485d0: 14000004    	b	0x1002485e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
1002485d4: b24003e3    	orr	x3, xzr, #0x1
1002485d8: 14000002    	b	0x1002485e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
1002485dc: b24003e3    	orr	x3, xzr, #0x1
1002485e0: 360001e3    	tbz	w3, #0x0, 0x10024861c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x43c>
1002485e4: f00014e4    	adrp	x4, 0x1004e7000 <_type:*+0x3a188>
1002485e8: 912bc084    	add	x4, x4, #0xaf0
1002485ec: 900012e5    	adrp	x5, 0x1004a4000 <_cmp..dict.isNaN[string]>
1002485f0: 9119c0a5    	add	x5, x5, #0x670
1002485f4: 9134a3fb    	add	x27, sp, #0xd28
1002485f8: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
1002485fc: a9001764    	stp	x4, x5, [x27]
100248600: f97eafe0    	ldr	x0, [sp, #0x7d58]
100248604: 3980001b    	ldrsb	x27, [x0]
100248608: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
10024860c: 9134a021    	add	x1, x1, #0xd28
100248610: b24003e2    	orr	x2, xzr, #0x1
100248614: aa0203e3    	mov	x3, x2
100248618: 97fac462    	bl	0x1000f97a0 <_testing.(*common).Fatal>
10024861c: 910ee3e0    	add	x0, sp, #0x3b8
100248620: 91400be1    	add	x1, sp, #0x2, lsl #12   ; =0x2000
100248624: 911f0021    	add	x1, x1, #0x7c0
100248628: d2848002    	mov	x2, #0x2400             ; =9216
10024862c: 97f6e581    	bl	0x100001c30 <_runtime.memequal>
100248630: 370001e0    	tbnz	w0, #0x0, 0x10024866c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x48c>
100248634: f00014e4    	adrp	x4, 0x1004e7000 <_type:*+0x3a188>
100248638: 912bc084    	add	x4, x4, #0xaf0
10024863c: 900012e5    	adrp	x5, 0x1004a4000 <_cmp..dict.isNaN[string]>
100248640: 911a00a5    	add	x5, x5, #0x680
100248644: 9134a3fb    	add	x27, sp, #0xd28
100248648: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
10024864c: a9001764    	stp	x4, x5, [x27]
100248650: f97eafe0    	ldr	x0, [sp, #0x7d58]
100248654: 3980001b    	ldrsb	x27, [x0]
100248658: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
10024865c: 9134a021    	add	x1, x1, #0xd28
100248660: b24003e2    	orr	x2, xzr, #0x1
100248664: aa0203e3    	mov	x3, x2
100248668: 97fac44e    	bl	0x1000f97a0 <_testing.(*common).Fatal>
10024866c: 91400be4    	add	x4, sp, #0x2, lsl #12   ; =0x2000
100248670: 911f0084    	add	x4, x4, #0x7c0
100248674: d2801206    	mov	x6, #0x90               ; =144
100248678: a8817c9f    	stp	xzr, xzr, [x4], #0x10
10024867c: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100248680: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100248684: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100248688: d10004c6    	sub	x6, x6, #0x1
10024868c: b5ffff66    	cbnz	x6, 0x100248678 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x498>
100248690: f92e4fff    	str	xzr, [sp, #0x5c98]
100248694: f97eafe6    	ldr	x6, [sp, #0x7d58]
100248698: b24003e7    	orr	x7, xzr, #0x1
10024869c: 390948c7    	strb	w7, [x6, #0x252]
1002486a0: f97eafe0    	ldr	x0, [sp, #0x7d58]
1002486a4: 910ae01b    	add	x27, x0, #0x2b8
1002486a8: a9401f66    	ldp	x6, x7, [x27]
1002486ac: eb0700df    	cmp	x6, x7
1002486b0: 540000a9    	b.ls	0x1002486c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4e4>
1002486b4: 910004e6    	add	x6, x7, #0x1
1002486b8: f9016006    	str	x6, [x0, #0x2c0]
1002486bc: b24003e0    	orr	x0, xzr, #0x1
1002486c0: 14000002    	b	0x1002486c8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4e8>
1002486c4: 97fa9e2b    	bl	0x1000eff70 <_testing.(*B).loopSlowPath>
1002486c8: 36000540    	tbz	w0, #0x0, 0x100248770 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x590>
1002486cc: f84633e6    	ldur	x6, [sp, #0x63]
1002486d0: 3941afe7    	ldrb	w7, [sp, #0x6b]
1002486d4: f80753e6    	stur	x6, [sp, #0x75]
1002486d8: 3901f7e7    	strb	w7, [sp, #0x7d]
1002486dc: f845a3e6    	ldur	x6, [sp, #0x5a]
1002486e0: 39418be7    	ldrb	w7, [sp, #0x62]
1002486e4: f806c3e6    	stur	x6, [sp, #0x6c]
1002486e8: 3901d3e7    	strb	w7, [sp, #0x74]
1002486ec: f92e4fff    	str	xzr, [sp, #0x5c98]
1002486f0: f97ea3e6    	ldr	x6, [sp, #0x7d40]
1002486f4: 394000c0    	ldrb	w0, [x6]
1002486f8: 9101d7e1    	add	x1, sp, #0x75
1002486fc: 9101b3e2    	add	x2, sp, #0x6c
100248700: 9101fbe3    	add	x3, sp, #0x7e
100248704: 91400be4    	add	x4, sp, #0x2, lsl #12   ; =0x2000
100248708: 911f0084    	add	x4, x4, #0x7c0
10024870c: f9766be5    	ldr	x5, [sp, #0x6cd0]
100248710: 97feb754    	bl	0x1001f6460 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords>
100248714: 913363fb    	add	x27, sp, #0xcd8
100248718: 91401b7b    	add	x27, x27, #0x6, lsl #12 ; =0x6000
10024871c: a9000760    	stp	x0, x1, [x27]
100248720: b4fffc00    	cbz	x0, 0x1002486a0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4c0>
100248724: 9134a3fb    	add	x27, sp, #0xd28
100248728: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
10024872c: a9007f7f    	stp	xzr, xzr, [x27]
100248730: 913363fb    	add	x27, sp, #0xcd8
100248734: 91401b7b    	add	x27, x27, #0x6, lsl #12 ; =0x6000
100248738: a9401764    	ldp	x4, x5, [x27]
10024873c: b4000044    	cbz	x4, 0x100248744 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x564>
100248740: f9400484    	ldr	x4, [x4, #0x8]
100248744: 9134a3fb    	add	x27, sp, #0xd28
100248748: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
10024874c: a9001764    	stp	x4, x5, [x27]
100248750: f97eafe0    	ldr	x0, [sp, #0x7d58]
100248754: 3980001b    	ldrsb	x27, [x0]
100248758: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
10024875c: 9134a021    	add	x1, x1, #0xd28
100248760: b24003e2    	orr	x2, xzr, #0x1
100248764: aa0203e3    	mov	x3, x2
100248768: 97fac40e    	bl	0x1000f97a0 <_testing.(*common).Fatal>
10024876c: 17ffffcd    	b	0x1002486a0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4c0>
100248770: aa1f03e4    	mov	x4, xzr
100248774: 14000002    	b	0x10024877c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x59c>
100248778: 91000484    	add	x4, x4, #0x1
10024877c: f100109f    	cmp	x4, #0x4
100248780: 540009ca    	b.ge	0x1002488b8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x6d8>
100248784: f925e7e4    	str	x4, [sp, #0x4bc8]
100248788: aa1f03e5    	mov	x5, xzr
10024878c: 14000002    	b	0x100248794 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x5b4>
100248790: 910004a5    	add	x5, x5, #0x1
100248794: f10020bf    	cmp	x5, #0x8
100248798: 54ffff0a    	b.ge	0x100248778 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x598>
10024879c: f925ebe5    	str	x5, [sp, #0x4bd0]
1002487a0: aa1f03e6    	mov	x6, xzr
1002487a4: 14000002    	b	0x1002487ac <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x5cc>
1002487a8: 910004c6    	add	x6, x6, #0x1
1002487ac: f1000cdf    	cmp	x6, #0x3
1002487b0: 54ffff0a    	b.ge	0x100248790 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x5b0>
1002487b4: f925e3e6    	str	x6, [sp, #0x4bc0]
1002487b8: d378dc87    	lsl	x7, x4, #8
1002487bc: 8b070ce7    	add	x7, x7, x7, lsl #3
1002487c0: f92627e7    	str	x7, [sp, #0x4c48]
1002487c4: 910ee3e8    	add	x8, sp, #0x3b8
1002487c8: 8b070109    	add	x9, x8, x7
1002487cc: d37be8aa    	lsl	x10, x5, #5
1002487d0: 8b0a0d4a    	add	x10, x10, x10, lsl #3
1002487d4: f92623ea    	str	x10, [sp, #0x4c40]
1002487d8: 8b0a0129    	add	x9, x9, x10
1002487dc: d37be8cb    	lsl	x11, x6, #5
1002487e0: 8b0b056b    	add	x11, x11, x11, lsl #1
1002487e4: f9261feb    	str	x11, [sp, #0x4c38]
1002487e8: 8b0b0129    	add	x9, x9, x11
1002487ec: 914013ec    	add	x12, sp, #0x4, lsl #12  ; =0x4000
1002487f0: 912f618c    	add	x12, x12, #0xbd8
1002487f4: ad404530    	ldp	q16, q17, [x9]
1002487f8: ad004590    	stp	q16, q17, [x12]
1002487fc: ad414530    	ldp	q16, q17, [x9, #0x20]
100248800: ad014590    	stp	q16, q17, [x12, #0x20]
100248804: ad424530    	ldp	q16, q17, [x9, #0x40]
100248808: ad024590    	stp	q16, q17, [x12, #0x40]
10024880c: aa1f03e9    	mov	x9, xzr
100248810: 14000002    	b	0x100248818 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x638>
100248814: 91000529    	add	x9, x9, #0x1
100248818: f100313f    	cmp	x9, #0xc
10024881c: 54fffc6a    	b.ge	0x1002487a8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x5c8>
100248820: f869798d    	ldr	x13, [x12, x9, lsl #3]
100248824: 91400bee    	add	x14, sp, #0x2, lsl #12  ; =0x2000
100248828: 911f01ce    	add	x14, x14, #0x7c0
10024882c: 8b0701cf    	add	x15, x14, x7
100248830: 8b0a01ef    	add	x15, x15, x10
100248834: 8b0b01ef    	add	x15, x15, x11
100248838: f86979ef    	ldr	x15, [x15, x9, lsl #3]
10024883c: f97eafe0    	ldr	x0, [sp, #0x7d58]
100248840: f9410810    	ldr	x16, [x0, #0x210]
100248844: 9b107dad    	mul	x13, x13, x16
100248848: eb0d01ff    	cmp	x15, x13
10024884c: 54fffe40    	b.eq	0x100248814 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x634>
100248850: f913dfe9    	str	x9, [sp, #0x27b8]
100248854: f00014e4    	adrp	x4, 0x1004e7000 <_type:*+0x3a188>
100248858: 912bc084    	add	x4, x4, #0xaf0
10024885c: 900012e5    	adrp	x5, 0x1004a4000 <_cmp..dict.isNaN[string]>
100248860: 911a40a5    	add	x5, x5, #0x690
100248864: 9134a3fb    	add	x27, sp, #0xd28
100248868: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
10024886c: a9001764    	stp	x4, x5, [x27]
100248870: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
100248874: 9134a021    	add	x1, x1, #0xd28
100248878: b24003e2    	orr	x2, xzr, #0x1
10024887c: aa0203e3    	mov	x3, x2
100248880: 97fac3c8    	bl	0x1000f97a0 <_testing.(*common).Fatal>
100248884: f965e7e4    	ldr	x4, [sp, #0x4bc8]
100248888: f965ebe5    	ldr	x5, [sp, #0x4bd0]
10024888c: f965e3e6    	ldr	x6, [sp, #0x4bc0]
100248890: f96627e7    	ldr	x7, [sp, #0x4c48]
100248894: 910ee3e8    	add	x8, sp, #0x3b8
100248898: f953dfe9    	ldr	x9, [sp, #0x27b8]
10024889c: f96623ea    	ldr	x10, [sp, #0x4c40]
1002488a0: f9661feb    	ldr	x11, [sp, #0x4c38]
1002488a4: 914013ec    	add	x12, sp, #0x4, lsl #12  ; =0x4000
1002488a8: 912f618c    	add	x12, x12, #0xbd8
1002488ac: 91400bee    	add	x14, sp, #0x2, lsl #12  ; =0x2000
1002488b0: 911f01ce    	add	x14, x14, #0x7c0
1002488b4: 17ffffd8    	b	0x100248814 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x634>
1002488b8: b84753e4    	ldur	w4, [sp, #0x75]
1002488bc: b84513e5    	ldur	w5, [sp, #0x51]
1002488c0: d503201f    	nop
1002488c4: 6b0400bf    	cmp	w5, w4
1002488c8: 540007c1    	b.ne	0x1002489c0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e0>
1002488cc: 784793e4    	ldurh	w4, [sp, #0x79]
1002488d0: 784553e5    	ldurh	w5, [sp, #0x55]
1002488d4: 6b0400bf    	cmp	w5, w4
1002488d8: 54000701    	b.ne	0x1002489b8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7d8>
1002488dc: 7847b3e4    	ldurh	w4, [sp, #0x7b]
1002488e0: 784573e5    	ldurh	w5, [sp, #0x57]
1002488e4: 6b0400bf    	cmp	w5, w4
1002488e8: 54000641    	b.ne	0x1002489b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7d0>
1002488ec: 394167e4    	ldrb	w4, [sp, #0x59]
1002488f0: 3941f7e5    	ldrb	w5, [sp, #0x7d]
1002488f4: 6b0400bf    	cmp	w5, w4
1002488f8: 54000581    	b.ne	0x1002489a8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7c8>
1002488fc: b84473e4    	ldur	w4, [sp, #0x47]
100248900: b9406fe5    	ldr	w5, [sp, #0x6c]
100248904: 6b0400bf    	cmp	w5, w4
100248908: 540004c1    	b.ne	0x1002489a0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7c0>
10024890c: 7940e3e4    	ldrh	w4, [sp, #0x70]
100248910: 7844b3e5    	ldurh	w5, [sp, #0x4b]
100248914: 6b0400bf    	cmp	w5, w4
100248918: 54000401    	b.ne	0x100248998 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7b8>
10024891c: 7940e7e4    	ldrh	w4, [sp, #0x72]
100248920: 7844d3e5    	ldurh	w5, [sp, #0x4d]
100248924: 6b0400bf    	cmp	w5, w4
100248928: 54000341    	b.ne	0x100248990 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7b0>
10024892c: 39413fe4    	ldrb	w4, [sp, #0x4f]
100248930: 3941d3e5    	ldrb	w5, [sp, #0x74]
100248934: 6b05009f    	cmp	w4, w5
100248938: 54000060    	b.eq	0x100248944 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x764>
10024893c: b24003e3    	orr	x3, xzr, #0x1
100248940: 14000021    	b	0x1002489c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
100248944: 913143fb    	add	x27, sp, #0xc50
100248948: 9140137b    	add	x27, x27, #0x4, lsl #12 ; =0x4000
10024894c: a9400760    	ldp	x0, x1, [x27]
100248950: f96633e2    	ldr	x2, [sp, #0x4c60]
100248954: 97f8d487    	bl	0x10007db70 <_runtime.convTslice>
100248958: f93e9fe0    	str	x0, [sp, #0x7d38]
10024895c: 913243fb    	add	x27, sp, #0xc90
100248960: 9140177b    	add	x27, x27, #0x5, lsl #12 ; =0x5000
100248964: a9400760    	ldp	x0, x1, [x27]
100248968: f96e53e2    	ldr	x2, [sp, #0x5ca0]
10024896c: 97f8d481    	bl	0x10007db70 <_runtime.convTslice>
100248970: f97e9fe1    	ldr	x1, [sp, #0x7d38]
100248974: 90001422    	adrp	x2, 0x1004cc000 <_type:*+0x1f188>
100248978: 91108042    	add	x2, x2, #0x420
10024897c: aa0003e3    	mov	x3, x0
100248980: aa0203e0    	mov	x0, x2
100248984: 97f9d557    	bl	0x1000bdee0 <_reflect.DeepEqual>
100248988: d2400003    	eor	x3, x0, #0x1
10024898c: 1400000e    	b	0x1002489c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
100248990: b24003e3    	orr	x3, xzr, #0x1
100248994: 1400000c    	b	0x1002489c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
100248998: b24003e3    	orr	x3, xzr, #0x1
10024899c: 1400000a    	b	0x1002489c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
1002489a0: b24003e3    	orr	x3, xzr, #0x1
1002489a4: 14000008    	b	0x1002489c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
1002489a8: b24003e3    	orr	x3, xzr, #0x1
1002489ac: 14000006    	b	0x1002489c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
1002489b0: b24003e3    	orr	x3, xzr, #0x1
1002489b4: 14000004    	b	0x1002489c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
1002489b8: b24003e3    	orr	x3, xzr, #0x1
1002489bc: 14000002    	b	0x1002489c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
1002489c0: b24003e3    	orr	x3, xzr, #0x1
1002489c4: 360001e3    	tbz	w3, #0x0, 0x100248a00 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x820>
1002489c8: f00014e4    	adrp	x4, 0x1004e7000 <_type:*+0x3a188>
1002489cc: 912bc084    	add	x4, x4, #0xaf0
1002489d0: 900012e5    	adrp	x5, 0x1004a4000 <_cmp..dict.isNaN[string]>
1002489d4: 9119c0a5    	add	x5, x5, #0x670
1002489d8: 9134a3fb    	add	x27, sp, #0xd28
1002489dc: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
1002489e0: a9001764    	stp	x4, x5, [x27]
1002489e4: f97eafe0    	ldr	x0, [sp, #0x7d58]
1002489e8: 3980001b    	ldrsb	x27, [x0]
1002489ec: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
1002489f0: 9134a021    	add	x1, x1, #0xd28
1002489f4: b24003e2    	orr	x2, xzr, #0x1
1002489f8: aa0203e3    	mov	x3, x2
1002489fc: 97fac369    	bl	0x1000f97a0 <_testing.(*common).Fatal>
100248a00: f953e3e0    	ldr	x0, [sp, #0x27c0]
100248a04: f96e4fe1    	ldr	x1, [sp, #0x5c98]
100248a08: 8b000020    	add	x0, x1, x0
100248a0c: 9000199b    	adrp	x27, 0x100578000 <_runtime.mheap_+0x187e0>
100248a10: f9047760    	str	x0, [x27, #0x8e8]
100248a14: a97ffbfd    	ldp	x29, x30, [sp, #-0x8]
100248a18: d28faa1b    	mov	x27, #0x7d50            ; =32080
100248a1c: 8b3b63ff    	add	sp, sp, x27
100248a20: d65f03c0    	ret
100248a24: aa0703e1    	mov	x1, x7
100248a28: f100643f    	cmp	x1, #0x19
100248a2c: 54ffc2aa    	b.ge	0x100248280 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0xa0>
100248a30: 9101fbe6    	add	x6, sp, #0x7e
100248a34: 8b0114c6    	add	x6, x6, x1, lsl #5
100248a38: 91000427    	add	x7, x1, #0x1
100248a3c: 790000c7    	strh	w7, [x6]
100248a40: b24003e8    	orr	x8, xzr, #0x1
100248a44: 910e7be9    	add	x9, sp, #0x39e
100248a48: 38216928    	strb	w8, [x9, x1]
100248a4c: a9402c6a    	ldp	x10, x11, [x3]
100248a50: f100157f    	cmp	x11, #0x5
100248a54: 54fffe81    	b.ne	0x100248a24 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x844>
100248a58: b940014b    	ldr	w11, [x10]
100248a5c: d28cac8c    	mov	x12, #0x6564            ; =25956
100248a60: f2ae6dcc    	movk	x12, #0x736e, lsl #16
100248a64: 6b0c017f    	cmp	w11, w12
100248a68: 54fffde1    	b.ne	0x100248a24 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x844>
100248a6c: 3940114a    	ldrb	w10, [x10, #0x4]
100248a70: 7101955f    	cmp	w10, #0x65
100248a74: 54fffd81    	b.ne	0x100248a24 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x844>
100248a78: b27c03ea    	orr	x10, xzr, #0x10
100248a7c: 3821692a    	strb	w10, [x9, x1]
100248a80: d37be829    	lsl	x9, x1, #5
100248a84: cb010129    	sub	x9, x9, x1
100248a88: aa1f03e1    	mov	x1, xzr
100248a8c: 1400000e    	b	0x100248ac4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x8e4>
100248a90: d28001ab    	mov	x11, #0xd               ; =13
100248a94: 9b0b242c    	madd	x12, x1, x11, x9
100248a98: d290412d    	mov	x13, #0x8209            ; =33289
100248a9c: f2a1040d    	movk	x13, #0x820, lsl #16
100248aa0: f2c4104d    	movk	x13, #0x2082, lsl #32
100248aa4: f2f0410d    	movk	x13, #0x8208, lsl #48
100248aa8: 9bcd7d8e    	umulh	x14, x12, x13
100248aac: 8b4e158c    	add	x12, x12, x14, lsr #5
100248ab0: d345fdce    	lsr	x14, x14, #5
100248ab4: cb0e198c    	sub	x12, x12, x14, lsl #6
100248ab8: d1007d8c    	sub	x12, x12, #0x1f
100248abc: 782178cc    	strh	w12, [x6, x1, lsl #1]
100248ac0: 91000421    	add	x1, x1, #0x1
100248ac4: f100403f    	cmp	x1, #0x10
100248ac8: 54fffe4b    	b.lt	0x100248a90 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x8b0>
100248acc: 17ffffd6    	b	0x100248a24 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x844>
100248ad0: f90007e0    	str	x0, [sp, #0x8]
100248ad4: aa1e03e3    	mov	x3, x30
100248ad8: 97f8f012    	bl	0x100084b20 <_runtime.morestack.abi0>
100248adc: f94007e0    	ldr	x0, [sp, #0x8]
100248ae0: 17fffdc0    	b	0x1002481e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1>
		...

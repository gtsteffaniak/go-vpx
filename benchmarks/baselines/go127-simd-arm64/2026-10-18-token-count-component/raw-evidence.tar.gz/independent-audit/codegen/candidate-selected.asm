
/private/tmp/govpx-next-token-count51/candidate-encoder.test:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001001f60b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords>:
1001f60b0: f9400b90    	ldr	x16, [x28, #0x10]
1001f60b4: d100c3f1    	sub	x17, sp, #0x30
1001f60b8: eb10023f    	cmp	x17, x16
1001f60bc: 540029e9    	b.ls	0x1001f65f8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x548>
1001f60c0: f8150ffe    	str	x30, [sp, #-0xb0]!
1001f60c4: f81f83fd    	stur	x29, [sp, #-0x8]
1001f60c8: d10023fd    	sub	x29, sp, #0x8
1001f60cc: b4000b21    	cbz	x1, 0x1001f6230 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x180>
1001f60d0: b4000b02    	cbz	x2, 0x1001f6230 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x180>
1001f60d4: b4000ae3    	cbz	x3, 0x1001f6230 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x180>
1001f60d8: b4000ac4    	cbz	x4, 0x1001f6230 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x180>
1001f60dc: f90063e1    	str	x1, [sp, #0xc0]
1001f60e0: f90067e2    	str	x2, [sp, #0xc8]
1001f60e4: f9006be3    	str	x3, [sp, #0xd0]
1001f60e8: f9006fe4    	str	x4, [sp, #0xd8]
1001f60ec: f90073e5    	str	x5, [sp, #0xe0]
1001f60f0: 36000080    	tbz	w0, #0x0, 0x1001f6100 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x50>
1001f60f4: aa1f03e0    	mov	x0, xzr
1001f60f8: b24007e6    	orr	x6, xzr, #0x3
1001f60fc: 1400003a    	b	0x1001f61e4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x134>
1001f6100: 39402027    	ldrb	w7, [x1, #0x8]
1001f6104: 39402048    	ldrb	w8, [x2, #0x8]
1001f6108: 8b0800e7    	add	x7, x7, x8
1001f610c: d3401ce8    	ubfx	x8, x7, #0, #8
1001f6110: d503201f    	nop
1001f6114: f1000d1f    	cmp	x8, #0x3
1001f6118: 5400080a    	b.ge	0x1001f6218 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x168>
1001f611c: 394ce066    	ldrb	w6, [x3, #0x338]
1001f6120: b4000345    	cbz	x5, 0x1001f6188 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0xd8>
1001f6124: f10000df    	cmp	x6, #0x0
1001f6128: 5400030c    	b.gt	0x1001f6188 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0xd8>
1001f612c: 91240089    	add	x9, x4, #0x900
1001f6130: d37b1ce7    	ubfiz	x7, x7, #5, #8
1001f6134: 8b0704e7    	add	x7, x7, x7, lsl #1
1001f6138: 8b070127    	add	x7, x9, x7
1001f613c: f9402ce9    	ldr	x9, [x7, #0x58]
1001f6140: 91000529    	add	x9, x9, #0x1
1001f6144: f9002ce9    	str	x9, [x7, #0x58]
1001f6148: d2800167    	mov	x7, #0xb                ; =11
1001f614c: 9b087ce8    	mul	x8, x7, x8
1001f6150: 91042108    	add	x8, x8, #0x108
1001f6154: d37ced08    	lsl	x8, x8, #4
1001f6158: a940a8a9    	ldp	x9, x10, [x5, #0x8]
1001f615c: 9100052b    	add	x11, x9, #0x1
1001f6160: d280016c    	mov	x12, #0xb               ; =11
1001f6164: aa0c0108    	orr	x8, x8, x12
1001f6168: eb0b015f    	cmp	x10, x11
1001f616c: 54002423    	b.lo	0x1001f65f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x540>
1001f6170: f90004ab    	str	x11, [x5, #0x8]
1001f6174: eb0b013f    	cmp	x9, x11
1001f6178: 540023a2    	b.hs	0x1001f65ec <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x53c>
1001f617c: f94000aa    	ldr	x10, [x5]
1001f6180: b8297948    	str	w8, [x10, x9, lsl #2]
1001f6184: 14000012    	b	0x1001f61cc <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x11c>
1001f6188: f9002fe6    	str	x6, [sp, #0x58]
1001f618c: 910c0067    	add	x7, x3, #0x300
1001f6190: aa0403e0    	mov	x0, x4
1001f6194: aa0503e1    	mov	x1, x5
1001f6198: b24003e2    	orr	x2, xzr, #0x1
1001f619c: aa0803e3    	mov	x3, x8
1001f61a0: aa1f03e4    	mov	x4, xzr
1001f61a4: aa0703e5    	mov	x5, x7
1001f61a8: 940001ae    	bl	0x1001f6860 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>
1001f61ac: b5000300    	cbnz	x0, 0x1001f620c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x15c>
1001f61b0: f94063e1    	ldr	x1, [sp, #0xc0]
1001f61b4: f94067e2    	ldr	x2, [sp, #0xc8]
1001f61b8: f9406be3    	ldr	x3, [sp, #0xd0]
1001f61bc: f9406fe4    	ldr	x4, [sp, #0xd8]
1001f61c0: f94073e5    	ldr	x5, [sp, #0xe0]
1001f61c4: f9402fe6    	ldr	x6, [sp, #0x58]
1001f61c8: d2800167    	mov	x7, #0xb                ; =11
1001f61cc: f10000df    	cmp	x6, #0x0
1001f61d0: 9a9fd7e8    	cset	x8, gt
1001f61d4: 39002028    	strb	w8, [x1, #0x8]
1001f61d8: 39002048    	strb	w8, [x2, #0x8]
1001f61dc: b24003e0    	orr	x0, xzr, #0x1
1001f61e0: aa1f03e6    	mov	x6, xzr
1001f61e4: f9003be6    	str	x6, [sp, #0x70]
1001f61e8: f90033e0    	str	x0, [sp, #0x60]
1001f61ec: d378dcc7    	lsl	x7, x6, #8
1001f61f0: 8b060c08    	add	x8, x0, x6, lsl #3
1001f61f4: 8b070ce7    	add	x7, x7, x7, lsl #3
1001f61f8: f90053e7    	str	x7, [sp, #0xa0]
1001f61fc: 8b080508    	add	x8, x8, x8, lsl #1
1001f6200: f9004fe8    	str	x8, [sp, #0x98]
1001f6204: aa1f03e9    	mov	x9, xzr
1001f6208: 14000016    	b	0x1001f6260 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x1b0>
1001f620c: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6210: f84b07fe    	ldr	x30, [sp], #0xb0
1001f6214: d65f03c0    	ret
1001f6218: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f621c: 9132437b    	add	x27, x27, #0xc90
1001f6220: a9400760    	ldp	x0, x1, [x27]
1001f6224: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6228: f84b07fe    	ldr	x30, [sp], #0xb0
1001f622c: d65f03c0    	ret
1001f6230: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6234: 9132437b    	add	x27, x27, #0xc90
1001f6238: a9400760    	ldp	x0, x1, [x27]
1001f623c: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6240: f84b07fe    	ldr	x30, [sp], #0xb0
1001f6244: d65f03c0    	ret
1001f6248: d3420d2b    	ubfx	x11, x9, #2, #2
1001f624c: eb0d001f    	cmp	x0, x13
1001f6250: 9a9fa7ec    	cset	x12, lt
1001f6254: 382a682c    	strb	w12, [x1, x10]
1001f6258: 382b684c    	strb	w12, [x2, x11]
1001f625c: 91000529    	add	x9, x9, #0x1
1001f6260: f100413f    	cmp	x9, #0x10
1001f6264: 54000aaa    	b.ge	0x1001f63b8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x308>
1001f6268: 9240052a    	and	x10, x9, #0x3
1001f626c: 927e052b    	and	x11, x9, #0xc
1001f6270: 386a682c    	ldrb	w12, [x1, x10]
1001f6274: 8b4b084b    	add	x11, x2, x11, lsr #2
1001f6278: 3940016b    	ldrb	w11, [x11]
1001f627c: 8b0c016b    	add	x11, x11, x12
1001f6280: d3401d6c    	ubfx	x12, x11, #0, #8
1001f6284: 910c806d    	add	x13, x3, #0x320
1001f6288: 386969ad    	ldrb	w13, [x13, x9]
1001f628c: eb0d001f    	cmp	x0, x13
1001f6290: 9a8dc00d    	csel	x13, x0, x13, gt
1001f6294: f1000d9f    	cmp	x12, #0x3
1001f6298: 5400084a    	b.ge	0x1001f63a0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x2f0>
1001f629c: f9004bea    	str	x10, [sp, #0x90]
1001f62a0: b4000405    	cbz	x5, 0x1001f6320 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x270>
1001f62a4: eb0d001f    	cmp	x0, x13
1001f62a8: 540003cb    	b.lt	0x1001f6320 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x270>
1001f62ac: 8b07008e    	add	x14, x4, x7
1001f62b0: d37b1d6b    	ubfiz	x11, x11, #5, #8
1001f62b4: 8b0b056b    	add	x11, x11, x11, lsl #1
1001f62b8: 8b0c010c    	add	x12, x8, x12
1001f62bc: d280016f    	mov	x15, #0xb               ; =11
1001f62c0: 9b0f7d8c    	mul	x12, x12, x15
1001f62c4: d37ced8c    	lsl	x12, x12, #4
1001f62c8: d2800170    	mov	x16, #0xb               ; =11
1001f62cc: aa10018c    	orr	x12, x12, x16
1001f62d0: f100001f    	cmp	x0, #0x0
1001f62d4: 9a9f07f1    	cset	x17, ne
1001f62d8: 7200023f    	tst	w17, #0x1
1001f62dc: d2802411    	mov	x17, #0x120             ; =288
1001f62e0: 9a9f1233    	csel	x19, x17, xzr, ne
1001f62e4: 8b0e026e    	add	x14, x19, x14
1001f62e8: 8b0b01cb    	add	x11, x14, x11
1001f62ec: f9402d6e    	ldr	x14, [x11, #0x58]
1001f62f0: 910005ce    	add	x14, x14, #0x1
1001f62f4: f9002d6e    	str	x14, [x11, #0x58]
1001f62f8: a940b8ab    	ldp	x11, x14, [x5, #0x8]
1001f62fc: 91000573    	add	x19, x11, #0x1
1001f6300: eb1301df    	cmp	x14, x19
1001f6304: 54001703    	b.lo	0x1001f65e4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x534>
1001f6308: f90004b3    	str	x19, [x5, #0x8]
1001f630c: eb13017f    	cmp	x11, x19
1001f6310: 54001662    	b.hs	0x1001f65dc <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x52c>
1001f6314: f94000ae    	ldr	x14, [x5]
1001f6318: b82b79cc    	str	w12, [x14, x11, lsl #2]
1001f631c: 17ffffcb    	b	0x1001f6248 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x198>
1001f6320: f90043e9    	str	x9, [sp, #0x80]
1001f6324: f9002bed    	str	x13, [sp, #0x50]
1001f6328: 8b091467    	add	x7, x3, x9, lsl #5
1001f632c: aa0503e1    	mov	x1, x5
1001f6330: aa0603e2    	mov	x2, x6
1001f6334: aa0c03e3    	mov	x3, x12
1001f6338: aa0703e5    	mov	x5, x7
1001f633c: aa0d03e6    	mov	x6, x13
1001f6340: aa0003e7    	mov	x7, x0
1001f6344: aa0403e0    	mov	x0, x4
1001f6348: aa0703e4    	mov	x4, x7
1001f634c: 94000145    	bl	0x1001f6860 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>
1001f6350: b5000220    	cbnz	x0, 0x1001f6394 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x2e4>
1001f6354: f94033e0    	ldr	x0, [sp, #0x60]
1001f6358: f94063e1    	ldr	x1, [sp, #0xc0]
1001f635c: f94067e2    	ldr	x2, [sp, #0xc8]
1001f6360: f9406be3    	ldr	x3, [sp, #0xd0]
1001f6364: f9406fe4    	ldr	x4, [sp, #0xd8]
1001f6368: f94073e5    	ldr	x5, [sp, #0xe0]
1001f636c: f9403be6    	ldr	x6, [sp, #0x70]
1001f6370: f94053e7    	ldr	x7, [sp, #0xa0]
1001f6374: f9404fe8    	ldr	x8, [sp, #0x98]
1001f6378: f94043e9    	ldr	x9, [sp, #0x80]
1001f637c: f9404bea    	ldr	x10, [sp, #0x90]
1001f6380: f9402bed    	ldr	x13, [sp, #0x50]
1001f6384: d280016f    	mov	x15, #0xb               ; =11
1001f6388: d2800170    	mov	x16, #0xb               ; =11
1001f638c: d2802411    	mov	x17, #0x120             ; =288
1001f6390: 17ffffae    	b	0x1001f6248 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x198>
1001f6394: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6398: f84b07fe    	ldr	x30, [sp], #0xb0
1001f639c: d65f03c0    	ret
1001f63a0: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f63a4: 9132437b    	add	x27, x27, #0xc90
1001f63a8: a9400760    	ldp	x0, x1, [x27]
1001f63ac: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f63b0: f84b07fe    	ldr	x30, [sp], #0xb0
1001f63b4: d65f03c0    	ret
1001f63b8: b27c03e7    	orr	x7, xzr, #0x10
1001f63bc: 14000002    	b	0x1001f63c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x314>
1001f63c0: 910004e7    	add	x7, x7, #0x1
1001f63c4: f10060ff    	cmp	x7, #0x18
1001f63c8: 54000f4a    	b.ge	0x1001f65b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x500>
1001f63cc: 910c8068    	add	x8, x3, #0x320
1001f63d0: d503201f    	nop
1001f63d4: 38676906    	ldrb	w6, [x8, x7]
1001f63d8: f1004cff    	cmp	x7, #0x13
1001f63dc: 5400006d    	b.le	0x1001f63e8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x338>
1001f63e0: b27f03e0    	orr	x0, xzr, #0x2
1001f63e4: 14000002    	b	0x1001f63ec <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x33c>
1001f63e8: aa1f03e0    	mov	x0, xzr
1001f63ec: 924000e8    	and	x8, x7, #0x1
1001f63f0: 924004e9    	and	x9, x7, #0x3
1001f63f4: 8b000108    	add	x8, x8, x0
1001f63f8: f100053f    	cmp	x9, #0x1
1001f63fc: 5400004d    	b.le	0x1001f6404 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x354>
1001f6400: 91000400    	add	x0, x0, #0x1
1001f6404: f100091f    	cmp	x8, #0x2
1001f6408: 5400008a    	b.ge	0x1001f6418 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x368>
1001f640c: 91001029    	add	x9, x1, #0x4
1001f6410: 38686929    	ldrb	w9, [x9, x8]
1001f6414: 14000004    	b	0x1001f6424 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x374>
1001f6418: 9100182a    	add	x10, x1, #0x6
1001f641c: d100090b    	sub	x11, x8, #0x2
1001f6420: 386b6949    	ldrb	w9, [x10, x11]
1001f6424: f100081f    	cmp	x0, #0x2
1001f6428: 540000aa    	b.ge	0x1001f643c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x38c>
1001f642c: 54000d62    	b.hs	0x1001f65d8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x528>
1001f6430: 9100104a    	add	x10, x2, #0x4
1001f6434: 3860694a    	ldrb	w10, [x10, x0]
1001f6438: 14000006    	b	0x1001f6450 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x3a0>
1001f643c: d100080a    	sub	x10, x0, #0x2
1001f6440: f100095f    	cmp	x10, #0x2
1001f6444: 54000c82    	b.hs	0x1001f65d4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x524>
1001f6448: 9100184b    	add	x11, x2, #0x6
1001f644c: 386a696a    	ldrb	w10, [x11, x10]
1001f6450: 8b0a0129    	add	x9, x9, x10
1001f6454: d3401d2a    	ubfx	x10, x9, #0, #8
1001f6458: f1000d5f    	cmp	x10, #0x3
1001f645c: 540009ea    	b.ge	0x1001f6598 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x4e8>
1001f6460: f90047e8    	str	x8, [sp, #0x88]
1001f6464: f90037e0    	str	x0, [sp, #0x68]
1001f6468: b4000365    	cbz	x5, 0x1001f64d4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x424>
1001f646c: f10000df    	cmp	x6, #0x0
1001f6470: 5400032c    	b.gt	0x1001f64d4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x424>
1001f6474: d282400b    	mov	x11, #0x1200            ; =4608
1001f6478: 8b04016c    	add	x12, x11, x4
1001f647c: d37b1d29    	ubfiz	x9, x9, #5, #8
1001f6480: 8b090529    	add	x9, x9, x9, lsl #1
1001f6484: 8b090189    	add	x9, x12, x9
1001f6488: f9402d2c    	ldr	x12, [x9, #0x58]
1001f648c: 9100058c    	add	x12, x12, #0x1
1001f6490: f9002d2c    	str	x12, [x9, #0x58]
1001f6494: d2800169    	mov	x9, #0xb                ; =11
1001f6498: 9b097d4a    	mul	x10, x10, x9
1001f649c: 9108414a    	add	x10, x10, #0x210
1001f64a0: d37ced4a    	lsl	x10, x10, #4
1001f64a4: a940b4ac    	ldp	x12, x13, [x5, #0x8]
1001f64a8: 9100058e    	add	x14, x12, #0x1
1001f64ac: d280016f    	mov	x15, #0xb               ; =11
1001f64b0: aa0f014a    	orr	x10, x10, x15
1001f64b4: eb0e01bf    	cmp	x13, x14
1001f64b8: 540008c3    	b.lo	0x1001f65d0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x520>
1001f64bc: f90004ae    	str	x14, [x5, #0x8]
1001f64c0: eb0e019f    	cmp	x12, x14
1001f64c4: 54000842    	b.hs	0x1001f65cc <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x51c>
1001f64c8: f94000ad    	ldr	x13, [x5]
1001f64cc: b82c79aa    	str	w10, [x13, x12, lsl #2]
1001f64d0: 14000018    	b	0x1001f6530 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x480>
1001f64d4: f9003fe7    	str	x7, [sp, #0x78]
1001f64d8: f90027e6    	str	x6, [sp, #0x48]
1001f64dc: 8b071467    	add	x7, x3, x7, lsl #5
1001f64e0: aa0403e0    	mov	x0, x4
1001f64e4: aa0503e1    	mov	x1, x5
1001f64e8: b27f03e2    	orr	x2, xzr, #0x2
1001f64ec: aa0a03e3    	mov	x3, x10
1001f64f0: aa1f03e4    	mov	x4, xzr
1001f64f4: aa0703e5    	mov	x5, x7
1001f64f8: 940000da    	bl	0x1001f6860 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>
1001f64fc: b5000480    	cbnz	x0, 0x1001f658c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x4dc>
1001f6500: f94037e0    	ldr	x0, [sp, #0x68]
1001f6504: f94063e1    	ldr	x1, [sp, #0xc0]
1001f6508: f94067e2    	ldr	x2, [sp, #0xc8]
1001f650c: f9406be3    	ldr	x3, [sp, #0xd0]
1001f6510: f9406fe4    	ldr	x4, [sp, #0xd8]
1001f6514: f94073e5    	ldr	x5, [sp, #0xe0]
1001f6518: f94027e6    	ldr	x6, [sp, #0x48]
1001f651c: f9403fe7    	ldr	x7, [sp, #0x78]
1001f6520: f94047e8    	ldr	x8, [sp, #0x88]
1001f6524: d2800169    	mov	x9, #0xb                ; =11
1001f6528: d282400b    	mov	x11, #0x1200            ; =4608
1001f652c: d280016f    	mov	x15, #0xb               ; =11
1001f6530: f10000df    	cmp	x6, #0x0
1001f6534: 9a9fd7ea    	cset	x10, gt
1001f6538: f100091f    	cmp	x8, #0x2
1001f653c: 540000aa    	b.ge	0x1001f6550 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x4a0>
1001f6540: 9100102c    	add	x12, x1, #0x4
1001f6544: 3828698a    	strb	w10, [x12, x8]
1001f6548: f100081f    	cmp	x0, #0x2
1001f654c: 14000005    	b	0x1001f6560 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x4b0>
1001f6550: 9100182c    	add	x12, x1, #0x6
1001f6554: d1000908    	sub	x8, x8, #0x2
1001f6558: 3828698a    	strb	w10, [x12, x8]
1001f655c: f100081f    	cmp	x0, #0x2
1001f6560: 540000aa    	b.ge	0x1001f6574 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x4c4>
1001f6564: 54000322    	b.hs	0x1001f65c8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x518>
1001f6568: 91001048    	add	x8, x2, #0x4
1001f656c: 3820690a    	strb	w10, [x8, x0]
1001f6570: 17ffff94    	b	0x1001f63c0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x310>
1001f6574: d1000808    	sub	x8, x0, #0x2
1001f6578: f100091f    	cmp	x8, #0x2
1001f657c: 54000242    	b.hs	0x1001f65c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x514>
1001f6580: 9100184c    	add	x12, x2, #0x6
1001f6584: 3828698a    	strb	w10, [x12, x8]
1001f6588: 17ffff8e    	b	0x1001f63c0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x310>
1001f658c: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6590: f84b07fe    	ldr	x30, [sp], #0xb0
1001f6594: d65f03c0    	ret
1001f6598: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f659c: 9132437b    	add	x27, x27, #0xc90
1001f65a0: a9400760    	ldp	x0, x1, [x27]
1001f65a4: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f65a8: f84b07fe    	ldr	x30, [sp], #0xb0
1001f65ac: d65f03c0    	ret
1001f65b0: aa1f03e0    	mov	x0, xzr
1001f65b4: aa1f03e1    	mov	x1, xzr
1001f65b8: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f65bc: f84b07fe    	ldr	x30, [sp], #0xb0
1001f65c0: d65f03c0    	ret
1001f65c4: 97fa41bb    	bl	0x100086cb0 <_runtime.panicBounds>
1001f65c8: 97fa41ba    	bl	0x100086cb0 <_runtime.panicBounds>
1001f65cc: 97fa41b9    	bl	0x100086cb0 <_runtime.panicBounds>
1001f65d0: 97fa41b8    	bl	0x100086cb0 <_runtime.panicBounds>
1001f65d4: 97fa41b7    	bl	0x100086cb0 <_runtime.panicBounds>
1001f65d8: 97fa41b6    	bl	0x100086cb0 <_runtime.panicBounds>
1001f65dc: aa1303e0    	mov	x0, x19
1001f65e0: 97fa41b4    	bl	0x100086cb0 <_runtime.panicBounds>
1001f65e4: aa1303e0    	mov	x0, x19
1001f65e8: 97fa41b2    	bl	0x100086cb0 <_runtime.panicBounds>
1001f65ec: 97fa41b1    	bl	0x100086cb0 <_runtime.panicBounds>
1001f65f0: 97fa41b0    	bl	0x100086cb0 <_runtime.panicBounds>
1001f65f4: d503201f    	nop
1001f65f8: 390023e0    	strb	w0, [sp, #0x8]
1001f65fc: a9010be1    	stp	x1, x2, [sp, #0x10]
1001f6600: a90213e3    	stp	x3, x4, [sp, #0x20]
1001f6604: f9001be5    	str	x5, [sp, #0x30]
1001f6608: aa1e03e3    	mov	x3, x30
1001f660c: 97fa3965    	bl	0x100084ba0 <_runtime.morestack_noctxt.abi0>
1001f6610: 394023e0    	ldrb	w0, [sp, #0x8]
1001f6614: a9410be1    	ldp	x1, x2, [sp, #0x10]
1001f6618: a94213e3    	ldp	x3, x4, [sp, #0x20]
1001f661c: f9401be5    	ldr	x5, [sp, #0x30]
1001f6620: 17fffea4    	b	0x1001f60b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords>
		...

00000001001f6630 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens>:
1001f6630: f9400b90    	ldr	x16, [x28, #0x10]
1001f6634: eb3063ff    	cmp	sp, x16
1001f6638: 54000fc9    	b.ls	0x1001f6830 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x200>
1001f663c: f81f0ffe    	str	x30, [sp, #-0x10]!
1001f6640: f81f83fd    	stur	x29, [sp, #-0x8]
1001f6644: d10023fd    	sub	x29, sp, #0x8
1001f6648: b4000540    	cbz	x0, 0x1001f66f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f664c: b4000524    	cbz	x4, 0x1001f66f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f6650: f100103f    	cmp	x1, #0x4
1001f6654: 540004e2    	b.hs	0x1001f66f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f6658: f1000c5f    	cmp	x2, #0x3
1001f665c: 540004a2    	b.hs	0x1001f66f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f6660: f100047f    	cmp	x3, #0x1
1001f6664: 54000468    	b.hi	0x1001f66f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f6668: eb0300bf    	cmp	x5, x3
1001f666c: 540001ad    	b.le	0x1001f66a0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x70>
1001f6670: f10040bf    	cmp	x5, #0x10
1001f6674: 540000ac    	b.gt	0x1001f6688 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x58>
1001f6678: d378dc26    	lsl	x6, x1, #8
1001f667c: 8b060cc6    	add	x6, x6, x6, lsl #3
1001f6680: aa0303e7    	mov	x7, x3
1001f6684: 14000021    	b	0x1001f6708 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xd8>
1001f6688: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f668c: 9132437b    	add	x27, x27, #0xc90
1001f6690: a9400760    	ldp	x0, x1, [x27]
1001f6694: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6698: f84107fe    	ldr	x30, [sp], #0x10
1001f669c: d65f03c0    	ret
1001f66a0: d378dc24    	lsl	x4, x1, #8
1001f66a4: 8b040c84    	add	x4, x4, x4, lsl #3
1001f66a8: 8b040004    	add	x4, x0, x4
1001f66ac: d37be842    	lsl	x2, x2, #5
1001f66b0: 8b020442    	add	x2, x2, x2, lsl #1
1001f66b4: f100007f    	cmp	x3, #0x0
1001f66b8: 9a9f07e3    	cset	x3, ne
1001f66bc: 7200007f    	tst	w3, #0x1
1001f66c0: d2802403    	mov	x3, #0x120              ; =288
1001f66c4: 9a9f1063    	csel	x3, x3, xzr, ne
1001f66c8: 8b040063    	add	x3, x3, x4
1001f66cc: 8b020062    	add	x2, x3, x2
1001f66d0: f9402c43    	ldr	x3, [x2, #0x58]
1001f66d4: 91000463    	add	x3, x3, #0x1
1001f66d8: f9002c43    	str	x3, [x2, #0x58]
1001f66dc: aa1f03e0    	mov	x0, xzr
1001f66e0: aa1f03e1    	mov	x1, xzr
1001f66e4: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f66e8: f84107fe    	ldr	x30, [sp], #0x10
1001f66ec: d65f03c0    	ret
1001f66f0: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f66f4: 9132437b    	add	x27, x27, #0xc90
1001f66f8: a9400760    	ldp	x0, x1, [x27]
1001f66fc: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6700: f84107fe    	ldr	x30, [sp], #0x10
1001f6704: d65f03c0    	ret
1001f6708: eb0300bf    	cmp	x5, x3
1001f670c: 5400060d    	b.le	0x1001f67cc <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x19c>
1001f6710: f0001948    	adrp	x8, 0x100521000 <_context..inittask+0xc0>
1001f6714: 911b0108    	add	x8, x8, #0x6c0
1001f6718: 78a37909    	ldrsh	x9, [x8, x3, lsl #1]
1001f671c: 92400d29    	and	x9, x9, #0xf
1001f6720: 78a97889    	ldrsh	x9, [x4, x9, lsl #1]
1001f6724: ca89fd2a    	eor	x10, x9, x9, asr #63
1001f6728: cb89fd49    	sub	x9, x10, x9, asr #63
1001f672c: f120013f    	cmp	x9, #0x800
1001f6730: 54000428    	b.hi	0x1001f67b4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x184>
1001f6734: 8b06000a    	add	x10, x0, x6
1001f6738: d37b08eb    	ubfiz	x11, x7, #5, #3
1001f673c: 8b0b0d6b    	add	x11, x11, x11, lsl #3
1001f6740: b0001c4c    	adrp	x12, 0x10057f000 <_github.com/thesyncim/govpx/internal/vp8/encoder.coefficientTokenLUT+0x1e0>
1001f6744: 9119018c    	add	x12, x12, #0x640
1001f6748: 38696989    	ldrb	w9, [x12, x9]
1001f674c: 8b0b014a    	add	x10, x10, x11
1001f6750: f1000c5f    	cmp	x2, #0x3
1001f6754: 540006a2    	b.hs	0x1001f6828 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x1f8>
1001f6758: d37be84b    	lsl	x11, x2, #5
1001f675c: 8b0b056b    	add	x11, x11, x11, lsl #1
1001f6760: 8b0b014a    	add	x10, x10, x11
1001f6764: f100313f    	cmp	x9, #0xc
1001f6768: 540005e2    	b.hs	0x1001f6824 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x1f4>
1001f676c: f869794b    	ldr	x11, [x10, x9, lsl #3]
1001f6770: 9100056b    	add	x11, x11, #0x1
1001f6774: f829794b    	str	x11, [x10, x9, lsl #3]
1001f6778: 91000463    	add	x3, x3, #0x1
1001f677c: f100407f    	cmp	x3, #0x10
1001f6780: 5400010a    	b.ge	0x1001f67a0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x170>
1001f6784: d000194a    	adrp	x10, 0x100520000 <_go:buildinfo>
1001f6788: 912c814a    	add	x10, x10, #0xb20
1001f678c: 38636947    	ldrb	w7, [x10, x3]
1001f6790: d000194b    	adrp	x11, 0x100520000 <_go:buildinfo>
1001f6794: 9126e16b    	add	x11, x11, #0x9b8
1001f6798: 38696962    	ldrb	w2, [x11, x9]
1001f679c: 17ffffdb    	b	0x1001f6708 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xd8>
1001f67a0: d000194a    	adrp	x10, 0x100520000 <_go:buildinfo>
1001f67a4: 912c814a    	add	x10, x10, #0xb20
1001f67a8: d000194b    	adrp	x11, 0x100520000 <_go:buildinfo>
1001f67ac: 9126e16b    	add	x11, x11, #0x9b8
1001f67b0: 17ffffd6    	b	0x1001f6708 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xd8>
1001f67b4: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f67b8: 9132437b    	add	x27, x27, #0xc90
1001f67bc: a9400760    	ldp	x0, x1, [x27]
1001f67c0: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f67c4: f84107fe    	ldr	x30, [sp], #0x10
1001f67c8: d65f03c0    	ret
1001f67cc: f10040bf    	cmp	x5, #0x10
1001f67d0: 540001ea    	b.ge	0x1001f680c <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x1dc>
1001f67d4: d378dc23    	lsl	x3, x1, #8
1001f67d8: 8b030c63    	add	x3, x3, x3, lsl #3
1001f67dc: 8b030003    	add	x3, x0, x3
1001f67e0: d37b08e4    	ubfiz	x4, x7, #5, #3
1001f67e4: 8b040c84    	add	x4, x4, x4, lsl #3
1001f67e8: 8b040063    	add	x3, x3, x4
1001f67ec: f1000c5f    	cmp	x2, #0x3
1001f67f0: 54000182    	b.hs	0x1001f6820 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x1f0>
1001f67f4: d37be842    	lsl	x2, x2, #5
1001f67f8: 8b020442    	add	x2, x2, x2, lsl #1
1001f67fc: 8b020062    	add	x2, x3, x2
1001f6800: f9402c43    	ldr	x3, [x2, #0x58]
1001f6804: 91000463    	add	x3, x3, #0x1
1001f6808: f9002c43    	str	x3, [x2, #0x58]
1001f680c: aa1f03e0    	mov	x0, xzr
1001f6810: aa1f03e1    	mov	x1, xzr
1001f6814: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6818: f84107fe    	ldr	x30, [sp], #0x10
1001f681c: d65f03c0    	ret
1001f6820: 97fa4124    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6824: 97fa4123    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6828: 97fa4122    	bl	0x100086cb0 <_runtime.panicBounds>
1001f682c: d503201f    	nop
1001f6830: a90087e0    	stp	x0, x1, [sp, #0x8]
1001f6834: a9018fe2    	stp	x2, x3, [sp, #0x18]
1001f6838: a90297e4    	stp	x4, x5, [sp, #0x28]
1001f683c: aa1e03e3    	mov	x3, x30
1001f6840: 97fa38d8    	bl	0x100084ba0 <_runtime.morestack_noctxt.abi0>
1001f6844: a94087e0    	ldp	x0, x1, [sp, #0x8]
1001f6848: a9418fe2    	ldp	x2, x3, [sp, #0x18]
1001f684c: a94297e4    	ldp	x4, x5, [sp, #0x28]
1001f6850: 17ffff78    	b	0x1001f6630 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens>
		...

00000001001f6860 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>:
1001f6860: f9400b90    	ldr	x16, [x28, #0x10]
1001f6864: eb3063ff    	cmp	sp, x16
1001f6868: 54001a09    	b.ls	0x1001f6ba8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x348>
1001f686c: f81c0ffe    	str	x30, [sp, #-0x40]!
1001f6870: f81f83fd    	stur	x29, [sp, #-0x8]
1001f6874: d10023fd    	sub	x29, sp, #0x8
1001f6878: b4000881    	cbz	x1, 0x1001f6988 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x128>
1001f687c: b40007a0    	cbz	x0, 0x1001f6970 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f6880: b4000785    	cbz	x5, 0x1001f6970 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f6884: f100105f    	cmp	x2, #0x4
1001f6888: 54000742    	b.hs	0x1001f6970 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f688c: f1000c7f    	cmp	x3, #0x3
1001f6890: 54000702    	b.hs	0x1001f6970 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f6894: f100049f    	cmp	x4, #0x1
1001f6898: 540006c8    	b.hi	0x1001f6970 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f689c: eb0400df    	cmp	x6, x4
1001f68a0: 540001cd    	b.le	0x1001f68d8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x78>
1001f68a4: f10040df    	cmp	x6, #0x10
1001f68a8: 540000cc    	b.gt	0x1001f68c0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x60>
1001f68ac: d378dc47    	lsl	x7, x2, #8
1001f68b0: 8b070ce7    	add	x7, x7, x7, lsl #3
1001f68b4: aa1f03e8    	mov	x8, xzr
1001f68b8: aa0403e9    	mov	x9, x4
1001f68bc: 1400003e    	b	0x1001f69b4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x154>
1001f68c0: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f68c4: 9132437b    	add	x27, x27, #0xc90
1001f68c8: a9400760    	ldp	x0, x1, [x27]
1001f68cc: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f68d0: f84407fe    	ldr	x30, [sp], #0x40
1001f68d4: d65f03c0    	ret
1001f68d8: d378dc45    	lsl	x5, x2, #8
1001f68dc: 8b050ca5    	add	x5, x5, x5, lsl #3
1001f68e0: 8b050005    	add	x5, x0, x5
1001f68e4: d37be866    	lsl	x6, x3, #5
1001f68e8: 8b0604c6    	add	x6, x6, x6, lsl #1
1001f68ec: 8b020c82    	add	x2, x4, x2, lsl #3
1001f68f0: 8b020442    	add	x2, x2, x2, lsl #1
1001f68f4: 8b020062    	add	x2, x3, x2
1001f68f8: d2800163    	mov	x3, #0xb                ; =11
1001f68fc: 9b037c42    	mul	x2, x2, x3
1001f6900: d37cec42    	lsl	x2, x2, #4
1001f6904: d2800163    	mov	x3, #0xb                ; =11
1001f6908: aa030042    	orr	x2, x2, x3
1001f690c: f100009f    	cmp	x4, #0x0
1001f6910: 9a9f07e3    	cset	x3, ne
1001f6914: 7200007f    	tst	w3, #0x1
1001f6918: d2802403    	mov	x3, #0x120              ; =288
1001f691c: 9a9f1063    	csel	x3, x3, xzr, ne
1001f6920: 8b050063    	add	x3, x3, x5
1001f6924: 8b060063    	add	x3, x3, x6
1001f6928: f9402c64    	ldr	x4, [x3, #0x58]
1001f692c: 91000484    	add	x4, x4, #0x1
1001f6930: f9002c64    	str	x4, [x3, #0x58]
1001f6934: a9409023    	ldp	x3, x4, [x1, #0x8]
1001f6938: 91000465    	add	x5, x3, #0x1
1001f693c: d503201f    	nop
1001f6940: eb05009f    	cmp	x4, x5
1001f6944: 54000363    	b.lo	0x1001f69b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x150>
1001f6948: f9000425    	str	x5, [x1, #0x8]
1001f694c: eb05007f    	cmp	x3, x5
1001f6950: 540002e2    	b.hs	0x1001f69ac <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x14c>
1001f6954: f9400024    	ldr	x4, [x1]
1001f6958: b8237882    	str	w2, [x4, x3, lsl #2]
1001f695c: aa1f03e0    	mov	x0, xzr
1001f6960: aa1f03e1    	mov	x1, xzr
1001f6964: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6968: f84407fe    	ldr	x30, [sp], #0x40
1001f696c: d65f03c0    	ret
1001f6970: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6974: 9132437b    	add	x27, x27, #0xc90
1001f6978: a9400760    	ldp	x0, x1, [x27]
1001f697c: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6980: f84407fe    	ldr	x30, [sp], #0x40
1001f6984: d65f03c0    	ret
1001f6988: aa0203e1    	mov	x1, x2
1001f698c: aa0303e2    	mov	x2, x3
1001f6990: aa0403e3    	mov	x3, x4
1001f6994: aa0503e4    	mov	x4, x5
1001f6998: aa0603e5    	mov	x5, x6
1001f699c: 97ffff25    	bl	0x1001f6630 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens>
1001f69a0: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f69a4: f84407fe    	ldr	x30, [sp], #0x40
1001f69a8: d65f03c0    	ret
1001f69ac: 97fa40c1    	bl	0x100086cb0 <_runtime.panicBounds>
1001f69b0: 97fa40c0    	bl	0x100086cb0 <_runtime.panicBounds>
1001f69b4: eb0400df    	cmp	x6, x4
1001f69b8: 5400094d    	b.le	0x1001f6ae0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x280>
1001f69bc: f000194a    	adrp	x10, 0x100521000 <_context..inittask+0xc0>
1001f69c0: 911b014a    	add	x10, x10, #0x6c0
1001f69c4: 78a4794b    	ldrsh	x11, [x10, x4, lsl #1]
1001f69c8: 92400d6b    	and	x11, x11, #0xf
1001f69cc: 78ab78ab    	ldrsh	x11, [x5, x11, lsl #1]
1001f69d0: ca8bfd6c    	eor	x12, x11, x11, asr #63
1001f69d4: cb8bfd8c    	sub	x12, x12, x11, asr #63
1001f69d8: f120019f    	cmp	x12, #0x800
1001f69dc: 54000768    	b.hi	0x1001f6ac8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x268>
1001f69e0: 8b07000d    	add	x13, x0, x7
1001f69e4: d37b092e    	ubfiz	x14, x9, #5, #3
1001f69e8: 8b0e0dce    	add	x14, x14, x14, lsl #3
1001f69ec: b0001c4f    	adrp	x15, 0x10057f000 <_github.com/thesyncim/govpx/internal/vp8/encoder.coefficientTokenLUT+0x1e0>
1001f69f0: 911901ef    	add	x15, x15, #0x640
1001f69f4: 386c69f0    	ldrb	w16, [x15, x12]
1001f69f8: 8b0e01ad    	add	x13, x13, x14
1001f69fc: f1000c7f    	cmp	x3, #0x3
1001f6a00: 54000d02    	b.hs	0x1001f6ba0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x340>
1001f6a04: aa1003ee    	mov	x14, x16
1001f6a08: d37be871    	lsl	x17, x3, #5
1001f6a0c: 8b110631    	add	x17, x17, x17, lsl #1
1001f6a10: 8b1101ad    	add	x13, x13, x17
1001f6a14: f10031df    	cmp	x14, #0xc
1001f6a18: 54000c22    	b.hs	0x1001f6b9c <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x33c>
1001f6a1c: 937ffd6b    	asr	x11, x11, #63
1001f6a20: f86e79b1    	ldr	x17, [x13, x14, lsl #3]
1001f6a24: 91000631    	add	x17, x17, #0x1
1001f6a28: f82e79b1    	str	x17, [x13, x14, lsl #3]
1001f6a2c: aa1003ed    	mov	x13, x16
1001f6a30: 8b020d30    	add	x16, x9, x2, lsl #3
1001f6a34: 8b100610    	add	x16, x16, x16, lsl #1
1001f6a38: 8b100070    	add	x16, x3, x16
1001f6a3c: d2800171    	mov	x17, #0xb               ; =11
1001f6a40: 9b107e30    	mul	x16, x17, x16
1001f6a44: aa1011ad    	orr	x13, x13, x16, lsl #4
1001f6a48: aa0c3dac    	orr	x12, x13, x12, lsl #15
1001f6a4c: 9240016b    	and	x11, x11, #0x1
1001f6a50: aa0b6d8b    	orr	x11, x12, x11, lsl #27
1001f6a54: d3401d0c    	ubfx	x12, x8, #0, #8
1001f6a58: a940c02d    	ldp	x13, x16, [x1, #0x8]
1001f6a5c: 910005b3    	add	x19, x13, #0x1
1001f6a60: d503201f    	nop
1001f6a64: aa0c716b    	orr	x11, x11, x12, lsl #28
1001f6a68: eb13021f    	cmp	x16, x19
1001f6a6c: 54000923    	b.lo	0x1001f6b90 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x330>
1001f6a70: f9000433    	str	x19, [x1, #0x8]
1001f6a74: eb1301bf    	cmp	x13, x19
1001f6a78: 54000882    	b.hs	0x1001f6b88 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x328>
1001f6a7c: 91000484    	add	x4, x4, #0x1
1001f6a80: f940002c    	ldr	x12, [x1]
1001f6a84: b82d798b    	str	w11, [x12, x13, lsl #2]
1001f6a88: f100409f    	cmp	x4, #0x10
1001f6a8c: 5400014a    	b.ge	0x1001f6ab4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x254>
1001f6a90: d000194b    	adrp	x11, 0x100520000 <_go:buildinfo>
1001f6a94: 912c816b    	add	x11, x11, #0xb20
1001f6a98: 38646969    	ldrb	w9, [x11, x4]
1001f6a9c: d000194c    	adrp	x12, 0x100520000 <_go:buildinfo>
1001f6aa0: 9126e18c    	add	x12, x12, #0x9b8
1001f6aa4: 386e6983    	ldrb	w3, [x12, x14]
1001f6aa8: f100007f    	cmp	x3, #0x0
1001f6aac: 9a9f17e8    	cset	x8, eq
1001f6ab0: 17ffffc1    	b	0x1001f69b4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x154>
1001f6ab4: d000194b    	adrp	x11, 0x100520000 <_go:buildinfo>
1001f6ab8: 912c816b    	add	x11, x11, #0xb20
1001f6abc: d000194c    	adrp	x12, 0x100520000 <_go:buildinfo>
1001f6ac0: 9126e18c    	add	x12, x12, #0x9b8
1001f6ac4: 17ffffbc    	b	0x1001f69b4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x154>
1001f6ac8: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6acc: 9132437b    	add	x27, x27, #0xc90
1001f6ad0: a9400760    	ldp	x0, x1, [x27]
1001f6ad4: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6ad8: f84407fe    	ldr	x30, [sp], #0x40
1001f6adc: d65f03c0    	ret
1001f6ae0: f10040df    	cmp	x6, #0x10
1001f6ae4: 5400042a    	b.ge	0x1001f6b68 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x308>
1001f6ae8: d378dc44    	lsl	x4, x2, #8
1001f6aec: 8b040c84    	add	x4, x4, x4, lsl #3
1001f6af0: 8b040004    	add	x4, x0, x4
1001f6af4: d37b0925    	ubfiz	x5, x9, #5, #3
1001f6af8: 8b050ca5    	add	x5, x5, x5, lsl #3
1001f6afc: 8b050084    	add	x4, x4, x5
1001f6b00: f1000c7f    	cmp	x3, #0x3
1001f6b04: 54000402    	b.hs	0x1001f6b84 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x324>
1001f6b08: d37be865    	lsl	x5, x3, #5
1001f6b0c: 8b0504a5    	add	x5, x5, x5, lsl #1
1001f6b10: 8b050084    	add	x4, x4, x5
1001f6b14: f9402c85    	ldr	x5, [x4, #0x58]
1001f6b18: 910004a5    	add	x5, x5, #0x1
1001f6b1c: f9002c85    	str	x5, [x4, #0x58]
1001f6b20: 8b020d22    	add	x2, x9, x2, lsl #3
1001f6b24: 8b020442    	add	x2, x2, x2, lsl #1
1001f6b28: 8b020062    	add	x2, x3, x2
1001f6b2c: d2800163    	mov	x3, #0xb                ; =11
1001f6b30: 9b027c62    	mul	x2, x3, x2
1001f6b34: d37cec42    	lsl	x2, x2, #4
1001f6b38: a9409023    	ldp	x3, x4, [x1, #0x8]
1001f6b3c: 91000465    	add	x5, x3, #0x1
1001f6b40: d503201f    	nop
1001f6b44: d2800166    	mov	x6, #0xb                ; =11
1001f6b48: aa060042    	orr	x2, x2, x6
1001f6b4c: eb05009f    	cmp	x4, x5
1001f6b50: 54000183    	b.lo	0x1001f6b80 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x320>
1001f6b54: f9000425    	str	x5, [x1, #0x8]
1001f6b58: eb05007f    	cmp	x3, x5
1001f6b5c: 54000102    	b.hs	0x1001f6b7c <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x31c>
1001f6b60: f9400024    	ldr	x4, [x1]
1001f6b64: b8237882    	str	w2, [x4, x3, lsl #2]
1001f6b68: aa1f03e0    	mov	x0, xzr
1001f6b6c: aa1f03e1    	mov	x1, xzr
1001f6b70: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6b74: f84407fe    	ldr	x30, [sp], #0x40
1001f6b78: d65f03c0    	ret
1001f6b7c: 97fa404d    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6b80: 97fa404c    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6b84: 97fa404b    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6b88: aa1303e0    	mov	x0, x19
1001f6b8c: 97fa4049    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6b90: aa1303e0    	mov	x0, x19
1001f6b94: aa1003e1    	mov	x1, x16
1001f6b98: 97fa4046    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6b9c: 97fa4045    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6ba0: 97fa4044    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6ba4: d503201f    	nop
1001f6ba8: a90087e0    	stp	x0, x1, [sp, #0x8]
1001f6bac: a9018fe2    	stp	x2, x3, [sp, #0x18]
1001f6bb0: a90297e4    	stp	x4, x5, [sp, #0x28]
1001f6bb4: f9001fe6    	str	x6, [sp, #0x38]
1001f6bb8: aa1e03e3    	mov	x3, x30
1001f6bbc: 97fa37f9    	bl	0x100084ba0 <_runtime.morestack_noctxt.abi0>
1001f6bc0: a94087e0    	ldp	x0, x1, [sp, #0x8]
1001f6bc4: a9418fe2    	ldp	x2, x3, [sp, #0x18]
1001f6bc8: a94297e4    	ldp	x4, x5, [sp, #0x28]
1001f6bcc: f9401fe6    	ldr	x6, [sp, #0x38]
1001f6bd0: 17ffff24    	b	0x1001f6860 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>
		...

0000000100237810 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51>:
100237810: f9400b90    	ldr	x16, [x28, #0x10]
100237814: d10183f1    	sub	x17, sp, #0x60
100237818: eb10023f    	cmp	x17, x16
10023781c: 540012a9    	b.ls	0x100237a70 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x260>
100237820: f8120ffe    	str	x30, [sp, #-0xe0]!
100237824: f81f83fd    	stur	x29, [sp, #-0x8]
100237828: d10023fd    	sub	x29, sp, #0x8
10023782c: f90077e0    	str	x0, [sp, #0xe8]
100237830: 79006fff    	strh	wzr, [sp, #0x36]
100237834: b24003e1    	orr	x1, xzr, #0x1
100237838: 3900dfe1    	strb	w1, [sp, #0x37]
10023783c: aa1f03e1    	mov	x1, xzr
100237840: 14000004    	b	0x100237850 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x40>
100237844: f9402be2    	ldr	x2, [sp, #0x50]
100237848: 91000441    	add	x1, x2, #0x1
10023784c: f94077e0    	ldr	x0, [sp, #0xe8]
100237850: f100083f    	cmp	x1, #0x2
100237854: 5400108a    	b.ge	0x100237a64 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x254>
100237858: f9002be1    	str	x1, [sp, #0x50]
10023785c: 9100dbe2    	add	x2, sp, #0x36
100237860: 38616841    	ldrb	w1, [x2, x1]
100237864: 3900cfe1    	strb	w1, [sp, #0x33]
100237868: 90001580    	adrp	x0, 0x1004e7000 <_type:*+0x3a188>
10023786c: 913bc000    	add	x0, x0, #0xef0
100237870: 97f789c0    	bl	0x100019f70 <_runtime.newobject>
100237874: f9006be0    	str	x0, [sp, #0xd0]
100237878: 3940cfe1    	ldrb	w1, [sp, #0x33]
10023787c: 39000001    	strb	w1, [x0]
100237880: d0000161    	adrp	x1, 0x100265000 <_crypto/internal/fips140/aes/gcm.(*CMAC).deriveSubkeys+0x40>
100237884: 91342021    	add	x1, x1, #0xd08
100237888: b27e03e2    	orr	x2, xzr, #0x4
10023788c: a9068be1    	stp	x1, x2, [sp, #0x68]
100237890: f0000161    	adrp	x1, 0x100266000 <_runtime.rodata+0x560>
100237894: 9106f021    	add	x1, x1, #0x1bc
100237898: b27f07e2    	orr	x2, xzr, #0x6
10023789c: a9078be1    	stp	x1, x2, [sp, #0x78]
1002378a0: d0000161    	adrp	x1, 0x100265000 <_crypto/internal/fips140/aes/gcm.(*CMAC).deriveSubkeys+0x40>
1002378a4: 913cb821    	add	x1, x1, #0xf2e
1002378a8: d28000a2    	mov	x2, #0x5                ; =5
1002378ac: a9088be1    	stp	x1, x2, [sp, #0x88]
1002378b0: 9101a3e1    	add	x1, sp, #0x68
1002378b4: aa1f03e2    	mov	x2, xzr
1002378b8: 14000007    	b	0x1002378d4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0xc4>
1002378bc: f94033e3    	ldr	x3, [sp, #0x60]
1002378c0: 91004061    	add	x1, x3, #0x10
1002378c4: f94027e3    	ldr	x3, [sp, #0x48]
1002378c8: 91000463    	add	x3, x3, #0x1
1002378cc: f9406be0    	ldr	x0, [sp, #0xd0]
1002378d0: aa0303e2    	mov	x2, x3
1002378d4: f1000c5f    	cmp	x2, #0x3
1002378d8: 54fffb6a    	b.ge	0x100237844 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x34>
1002378dc: f90027e2    	str	x2, [sp, #0x48]
1002378e0: f90033e1    	str	x1, [sp, #0x60]
1002378e4: a9401023    	ldp	x3, x4, [x1]
1002378e8: f90023e4    	str	x4, [sp, #0x40]
1002378ec: f9002fe3    	str	x3, [sp, #0x58]
1002378f0: b27c03e0    	orr	x0, xzr, #0x10
1002378f4: 90001581    	adrp	x1, 0x1004e7000 <_type:*+0x3a188>
1002378f8: 912bc021    	add	x1, x1, #0xaf0
1002378fc: b24003e2    	orr	x2, xzr, #0x1
100237900: 97f78bdc    	bl	0x10001a870 <_runtime.mallocgcSmallScanNoHeaderSC2>
100237904: f94023e3    	ldr	x3, [sp, #0x40]
100237908: f9000403    	str	x3, [x0, #0x8]
10023790c: b0001a1b    	adrp	x27, 0x100578000 <_runtime.mheap_+0x187e0>
100237910: b94dc363    	ldr	w3, [x27, #0xdc0]
100237914: 35000063    	cbnz	w3, 0x100237920 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x110>
100237918: f9402fe3    	ldr	x3, [sp, #0x58]
10023791c: 14000004    	b	0x10023792c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x11c>
100237920: 97f93c2c    	bl	0x1000869d0 <_runtime.gcWriteBarrier1>
100237924: f9402fe3    	ldr	x3, [sp, #0x58]
100237928: f9000323    	str	x3, [x25]
10023792c: f90067e0    	str	x0, [sp, #0xc8]
100237930: f9000003    	str	x3, [x0]
100237934: 79006bff    	strh	wzr, [sp, #0x34]
100237938: b24003e2    	orr	x2, xzr, #0x1
10023793c: 3900d7e2    	strb	w2, [sp, #0x35]
100237940: aa1f03e1    	mov	x1, xzr
100237944: 1400000e    	b	0x10023797c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x16c>
100237948: f9000404    	str	x4, [x0, #0x8]
10023794c: 3940cbe4    	ldrb	w4, [sp, #0x32]
100237950: 39004004    	strb	w4, [x0, #0x10]
100237954: f9000c05    	str	x5, [x0, #0x18]
100237958: f9402fe1    	ldr	x1, [sp, #0x58]
10023795c: f9401fe2    	ldr	x2, [sp, #0x38]
100237960: aa0003e3    	mov	x3, x0
100237964: f94077e0    	ldr	x0, [sp, #0xe8]
100237968: 97fae76e    	bl	0x1000f1720 <_testing.(*B).Run>
10023796c: f94023e4    	ldr	x4, [sp, #0x40]
100237970: 91000481    	add	x1, x4, #0x1
100237974: f94067e0    	ldr	x0, [sp, #0xc8]
100237978: b24003e2    	orr	x2, xzr, #0x1
10023797c: f100083f    	cmp	x1, #0x2
100237980: 54fff9ea    	b.ge	0x1002378bc <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0xac>
100237984: f90023e1    	str	x1, [sp, #0x40]
100237988: 9100d3e2    	add	x2, sp, #0x34
10023798c: 38616842    	ldrb	w2, [x2, x1]
100237990: 3900cbe2    	strb	w2, [sp, #0x32]
100237994: 910263e2    	add	x2, sp, #0x98
100237998: a9007c5f    	stp	xzr, xzr, [x2]
10023799c: a9017c5f    	stp	xzr, xzr, [x2, #0x10]
1002379a0: a9027c5f    	stp	xzr, xzr, [x2, #0x20]
1002379a4: f9406be2    	ldr	x2, [sp, #0xd0]
1002379a8: 39400042    	ldrb	w2, [x2]
1002379ac: b0000283    	adrp	x3, 0x100288000 <_runtime.modinfo.str+0x780>
1002379b0: 913e8063    	add	x3, x3, #0xfa0
1002379b4: 8b020c62    	add	x2, x3, x2, lsl #3
1002379b8: 90001583    	adrp	x3, 0x1004e7000 <_type:*+0x3a188>
1002379bc: 913bc063    	add	x3, x3, #0xef0
1002379c0: a9098be3    	stp	x3, x2, [sp, #0x98]
1002379c4: a9400400    	ldp	x0, x1, [x0]
1002379c8: 97f91842    	bl	0x10007dad0 <_runtime.convTstring>
1002379cc: 90001582    	adrp	x2, 0x1004e7000 <_type:*+0x3a188>
1002379d0: 912bc042    	add	x2, x2, #0xaf0
1002379d4: a90a83e2    	stp	x2, x0, [sp, #0xa8]
1002379d8: 3940cbe2    	ldrb	w2, [sp, #0x32]
1002379dc: b0000283    	adrp	x3, 0x100288000 <_runtime.modinfo.str+0x780>
1002379e0: 913e8063    	add	x3, x3, #0xfa0
1002379e4: 8b020c62    	add	x2, x3, x2, lsl #3
1002379e8: 90001583    	adrp	x3, 0x1004e7000 <_type:*+0x3a188>
1002379ec: 913bc063    	add	x3, x3, #0xef0
1002379f0: a90b8be3    	stp	x3, x2, [sp, #0xb8]
1002379f4: d0000180    	adrp	x0, 0x100269000 <_runtime.rodata+0x3560>
1002379f8: 913cdc00    	add	x0, x0, #0xf37
1002379fc: d2800241    	mov	x1, #0x12               ; =18
100237a00: 910263e2    	add	x2, sp, #0x98
100237a04: b24007e3    	orr	x3, xzr, #0x3
100237a08: aa0303e4    	mov	x4, x3
100237a0c: 97fa7161    	bl	0x1000d3f90 <_fmt.Sprintf>
100237a10: f9002fe0    	str	x0, [sp, #0x58]
100237a14: f9001fe1    	str	x1, [sp, #0x38]
100237a18: b27b03e0    	orr	x0, xzr, #0x20
100237a1c: b0001641    	adrp	x1, 0x100500000 <_type:*+0x53188>
100237a20: 913ec021    	add	x1, x1, #0xfb0
100237a24: b24003e2    	orr	x2, xzr, #0x1
100237a28: 97f78d5e    	bl	0x10001afa0 <_runtime.mallocgcSmallScanNoHeaderSC4>
100237a2c: 90000082    	adrp	x2, 0x100247000 <_github.com/thesyncim/govpx/internal/vp8/encoder.TestFastQuantizeBlockSIMDMatchesScalar.func2+0x30>
100237a30: 91388042    	add	x2, x2, #0xe20
100237a34: f9000002    	str	x2, [x0]
100237a38: b0001a1b    	adrp	x27, 0x100578000 <_runtime.mheap_+0x187e0>
100237a3c: b94dc362    	ldr	w2, [x27, #0xdc0]
100237a40: 35000082    	cbnz	w2, 0x100237a50 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x240>
100237a44: f94067e4    	ldr	x4, [sp, #0xc8]
100237a48: f9406be5    	ldr	x5, [sp, #0xd0]
100237a4c: 17ffffbf    	b	0x100237948 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x138>
100237a50: 97f93be4    	bl	0x1000869e0 <_runtime.gcWriteBarrier2>
100237a54: f94067e4    	ldr	x4, [sp, #0xc8]
100237a58: f9406be5    	ldr	x5, [sp, #0xd0]
100237a5c: a9001724    	stp	x4, x5, [x25]
100237a60: 17ffffba    	b	0x100237948 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x138>
100237a64: f85f83fd    	ldur	x29, [sp, #-0x8]
100237a68: f84e07fe    	ldr	x30, [sp], #0xe0
100237a6c: d65f03c0    	ret
100237a70: f90007e0    	str	x0, [sp, #0x8]
100237a74: aa1e03e3    	mov	x3, x30
100237a78: 97f9344a    	bl	0x100084ba0 <_runtime.morestack_noctxt.abi0>
100237a7c: f94007e0    	ldr	x0, [sp, #0x8]
100237a80: 17ffff64    	b	0x100237810 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51>
		...

0000000100247e20 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1>:
100247e20: f9400b90    	ldr	x16, [x28, #0x10]
100247e24: d28f9a1b    	mov	x27, #0x7cd0            ; =31952
100247e28: eb3b63f1    	subs	x17, sp, x27
100247e2c: 54004723    	b.lo	0x100248710 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x8f0>
100247e30: eb10023f    	cmp	x17, x16
100247e34: 540046e9    	b.ls	0x100248710 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x8f0>
100247e38: d28faa1b    	mov	x27, #0x7d50            ; =32080
100247e3c: cb3b63f4    	sub	x20, sp, x27
100247e40: a93ffa9d    	stp	x29, x30, [x20, #-0x8]
100247e44: 9100029f    	mov	sp, x20
100247e48: d10023fd    	sub	x29, sp, #0x8
100247e4c: f93eafe0    	str	x0, [sp, #0x7d58]
100247e50: f9400743    	ldr	x3, [x26, #0x8]
100247e54: f9400f44    	ldr	x4, [x26, #0x18]
100247e58: f93ea3e4    	str	x4, [sp, #0x7d40]
100247e5c: 39404345    	ldrb	w5, [x26, #0x10]
100247e60: 390143e5    	strb	w5, [sp, #0x50]
100247e64: 9101fbe6    	add	x6, sp, #0x7e
100247e68: b27e07e7    	orr	x7, xzr, #0xc
100247e6c: a8817cdf    	stp	xzr, xzr, [x6], #0x10
100247e70: a8817cdf    	stp	xzr, xzr, [x6], #0x10
100247e74: a8817cdf    	stp	xzr, xzr, [x6], #0x10
100247e78: a8817cdf    	stp	xzr, xzr, [x6], #0x10
100247e7c: d10004e7    	sub	x7, x7, #0x1
100247e80: b5ffff67    	cbnz	x7, 0x100247e6c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4c>
100247e84: a9007cdf    	stp	xzr, xzr, [x6]
100247e88: a9017cdf    	stp	xzr, xzr, [x6, #0x10]
100247e8c: a9027cdf    	stp	xzr, xzr, [x6, #0x20]
100247e90: f90018df    	str	xzr, [x6, #0x30]
100247e94: f80320df    	stur	xzr, [x6, #0x32]
100247e98: a9401c66    	ldp	x6, x7, [x3]
100247e9c: f10010ff    	cmp	x7, #0x4
100247ea0: 540000c1    	b.ne	0x100247eb8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x98>
100247ea4: b94000c6    	ldr	w6, [x6]
100247ea8: d28caf47    	mov	x7, #0x657a             ; =25978
100247eac: f2adee47    	movk	x7, #0x6f72, lsl #16
100247eb0: 6b0700df    	cmp	w6, w7
100247eb4: 54000060    	b.eq	0x100247ec0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0xa0>
100247eb8: aa1f03e1    	mov	x1, xzr
100247ebc: 140001eb    	b	0x100248668 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x848>
100247ec0: f80633ff    	stur	xzr, [sp, #0x63]
100247ec4: 3901afff    	strb	wzr, [sp, #0x6b]
100247ec8: b24003e3    	orr	x3, xzr, #0x1
100247ecc: 39018fe3    	strb	w3, [sp, #0x63]
100247ed0: 390197e3    	strb	w3, [sp, #0x65]
100247ed4: 39019fe3    	strb	w3, [sp, #0x67]
100247ed8: d2802023    	mov	x3, #0x101              ; =257
100247edc: 7900d7e3    	strh	w3, [sp, #0x6a]
100247ee0: f805a3ff    	stur	xzr, [sp, #0x5a]
100247ee4: 39018bff    	strb	wzr, [sp, #0x62]
100247ee8: 910ee3e3    	add	x3, sp, #0x3b8
100247eec: d2801204    	mov	x4, #0x90               ; =144
100247ef0: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247ef4: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247ef8: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247efc: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247f00: d1000484    	sub	x4, x4, #0x1
100247f04: b5ffff64    	cbnz	x4, 0x100247ef0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0xd0>
100247f08: 91400be3    	add	x3, sp, #0x2, lsl #12   ; =0x2000
100247f0c: 911f0063    	add	x3, x3, #0x7c0
100247f10: d2801204    	mov	x4, #0x90               ; =144
100247f14: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247f18: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247f1c: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247f20: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247f24: d1000484    	sub	x4, x4, #0x1
100247f28: b5ffff64    	cbnz	x4, 0x100247f14 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0xf4>
100247f2c: f84633e3    	ldur	x3, [sp, #0x63]
100247f30: 3941afe4    	ldrb	w4, [sp, #0x6b]
100247f34: f80513e3    	stur	x3, [sp, #0x51]
100247f38: 390167e4    	strb	w4, [sp, #0x59]
100247f3c: f845a3e3    	ldur	x3, [sp, #0x5a]
100247f40: 39418be4    	ldrb	w4, [sp, #0x62]
100247f44: f80473e3    	stur	x3, [sp, #0x47]
100247f48: 39013fe4    	strb	w4, [sp, #0x4f]
100247f4c: f84633e3    	ldur	x3, [sp, #0x63]
100247f50: 3941afe4    	ldrb	w4, [sp, #0x6b]
100247f54: f80753e3    	stur	x3, [sp, #0x75]
100247f58: 3901f7e4    	strb	w4, [sp, #0x7d]
100247f5c: f845a3e3    	ldur	x3, [sp, #0x5a]
100247f60: 39418be4    	ldrb	w4, [sp, #0x62]
100247f64: f806c3e3    	stur	x3, [sp, #0x6c]
100247f68: 3901d3e4    	strb	w4, [sp, #0x74]
100247f6c: 90001500    	adrp	x0, 0x1004e7000 <_type:*+0x3a188>
100247f70: 912ac000    	add	x0, x0, #0xab0
100247f74: aa1f03e1    	mov	x1, xzr
100247f78: b27907e2    	orr	x2, xzr, #0x180
100247f7c: 97f8e6e5    	bl	0x100081b10 <_runtime.makeslice>
100247f80: f93e9fe0    	str	x0, [sp, #0x7d38]
100247f84: 90001500    	adrp	x0, 0x1004e7000 <_type:*+0x3a188>
100247f88: 912ac000    	add	x0, x0, #0xab0
100247f8c: aa1f03e1    	mov	x1, xzr
100247f90: b27907e2    	orr	x2, xzr, #0x180
100247f94: 97f8e6df    	bl	0x100081b10 <_runtime.makeslice>
100247f98: 91401be3    	add	x3, sp, #0x6, lsl #12   ; =0x6000
100247f9c: 9133a063    	add	x3, x3, #0xce8
100247fa0: d2800824    	mov	x4, #0x41               ; =65
100247fa4: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247fa8: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247fac: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247fb0: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247fb4: d1000484    	sub	x4, x4, #0x1
100247fb8: b5ffff64    	cbnz	x4, 0x100247fa4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x184>
100247fbc: f93677e0    	str	x0, [sp, #0x6ce8]
100247fc0: b27907e3    	orr	x3, xzr, #0x180
100247fc4: f9367fe3    	str	x3, [sp, #0x6cf8]
100247fc8: 914013e4    	add	x4, sp, #0x4, lsl #12   ; =0x4000
100247fcc: 91314084    	add	x4, x4, #0xc50
100247fd0: d2800825    	mov	x5, #0x41               ; =65
100247fd4: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100247fd8: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100247fdc: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100247fe0: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100247fe4: d10004a5    	sub	x5, x5, #0x1
100247fe8: b5ffff65    	cbnz	x5, 0x100247fd4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x1b4>
100247fec: f97e9fe4    	ldr	x4, [sp, #0x7d38]
100247ff0: f9262be4    	str	x4, [sp, #0x4c50]
100247ff4: f92633e3    	str	x3, [sp, #0x4c60]
100247ff8: 914017e3    	add	x3, sp, #0x5, lsl #12   ; =0x5000
100247ffc: 91324063    	add	x3, x3, #0xc90
100248000: 91401be4    	add	x4, sp, #0x6, lsl #12   ; =0x6000
100248004: 9133a084    	add	x4, x4, #0xce8
100248008: d2800838    	mov	x24, #0x41              ; =65
10024800c: acc14490    	ldp	q16, q17, [x4], #0x20
100248010: ac814470    	stp	q16, q17, [x3], #0x20
100248014: acc14490    	ldp	q16, q17, [x4], #0x20
100248018: ac814470    	stp	q16, q17, [x3], #0x20
10024801c: d1000718    	sub	x24, x24, #0x1
100248020: b5ffff78    	cbnz	x24, 0x10024800c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x1ec>
100248024: f97ea3e3    	ldr	x3, [sp, #0x7d40]
100248028: 39400060    	ldrb	w0, [x3]
10024802c: 394143e3    	ldrb	w3, [sp, #0x50]
100248030: 7200007f    	tst	w3, #0x1
100248034: 914013e3    	add	x3, sp, #0x4, lsl #12   ; =0x4000
100248038: 91314063    	add	x3, x3, #0xc50
10024803c: 9a9f1065    	csel	x5, x3, xzr, ne
100248040: 910147e1    	add	x1, sp, #0x51
100248044: 91011fe2    	add	x2, sp, #0x47
100248048: 9101fbe3    	add	x3, sp, #0x7e
10024804c: 910ee3e4    	add	x4, sp, #0x3b8
100248050: 97ffbe90    	bl	0x100237a90 <_github.com/thesyncim/govpx/internal/vp8/encoder.tokenCountFrozenMacro51>
100248054: 394143e3    	ldrb	w3, [sp, #0x50]
100248058: 7200007f    	tst	w3, #0x1
10024805c: b4000240    	cbz	x0, 0x1002480a4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x284>
100248060: 9134a3fb    	add	x27, sp, #0xd28
100248064: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
100248068: a9007f7f    	stp	xzr, xzr, [x27]
10024806c: b4000040    	cbz	x0, 0x100248074 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x254>
100248070: f9400400    	ldr	x0, [x0, #0x8]
100248074: 9134a3fb    	add	x27, sp, #0xd28
100248078: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
10024807c: a9000760    	stp	x0, x1, [x27]
100248080: f97eafe0    	ldr	x0, [sp, #0x7d58]
100248084: 3980001b    	ldrsb	x27, [x0]
100248088: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
10024808c: 9134a021    	add	x1, x1, #0xd28
100248090: b24003e2    	orr	x2, xzr, #0x1
100248094: aa0203e3    	mov	x3, x2
100248098: 97fac5c2    	bl	0x1000f97a0 <_testing.(*common).Fatal>
10024809c: 394143e4    	ldrb	w4, [sp, #0x50]
1002480a0: 7200009f    	tst	w4, #0x1
1002480a4: 914017e6    	add	x6, sp, #0x5, lsl #12   ; =0x5000
1002480a8: 913240c6    	add	x6, x6, #0xc90
1002480ac: 9a9f10c5    	csel	x5, x6, xzr, ne
1002480b0: f9366be5    	str	x5, [sp, #0x6cd0]
1002480b4: f97ea3e6    	ldr	x6, [sp, #0x7d40]
1002480b8: 394000c0    	ldrb	w0, [x6]
1002480bc: 9101d7e1    	add	x1, sp, #0x75
1002480c0: 9101b3e2    	add	x2, sp, #0x6c
1002480c4: 9101fbe3    	add	x3, sp, #0x7e
1002480c8: 91400be4    	add	x4, sp, #0x2, lsl #12   ; =0x2000
1002480cc: 911f0084    	add	x4, x4, #0x7c0
1002480d0: 97feb7f8    	bl	0x1001f60b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords>
1002480d4: b4000200    	cbz	x0, 0x100248114 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x2f4>
1002480d8: 9134a3fb    	add	x27, sp, #0xd28
1002480dc: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
1002480e0: a9007f7f    	stp	xzr, xzr, [x27]
1002480e4: b4000040    	cbz	x0, 0x1002480ec <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x2cc>
1002480e8: f9400400    	ldr	x0, [x0, #0x8]
1002480ec: 9134a3fb    	add	x27, sp, #0xd28
1002480f0: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
1002480f4: a9000760    	stp	x0, x1, [x27]
1002480f8: f97eafe0    	ldr	x0, [sp, #0x7d58]
1002480fc: 3980001b    	ldrsb	x27, [x0]
100248100: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
100248104: 9134a021    	add	x1, x1, #0xd28
100248108: b24003e2    	orr	x2, xzr, #0x1
10024810c: aa0203e3    	mov	x3, x2
100248110: 97fac5a4    	bl	0x1000f97a0 <_testing.(*common).Fatal>
100248114: b84753e4    	ldur	w4, [sp, #0x75]
100248118: b84513e5    	ldur	w5, [sp, #0x51]
10024811c: d503201f    	nop
100248120: 6b0400bf    	cmp	w5, w4
100248124: 540007c1    	b.ne	0x10024821c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3fc>
100248128: 784793e4    	ldurh	w4, [sp, #0x79]
10024812c: 784553e5    	ldurh	w5, [sp, #0x55]
100248130: 6b05009f    	cmp	w4, w5
100248134: 54000701    	b.ne	0x100248214 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3f4>
100248138: 7847b3e4    	ldurh	w4, [sp, #0x7b]
10024813c: 784573e5    	ldurh	w5, [sp, #0x57]
100248140: 6b05009f    	cmp	w4, w5
100248144: 54000641    	b.ne	0x10024820c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3ec>
100248148: 394167e4    	ldrb	w4, [sp, #0x59]
10024814c: 3941f7e5    	ldrb	w5, [sp, #0x7d]
100248150: 6b0400bf    	cmp	w5, w4
100248154: 54000581    	b.ne	0x100248204 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3e4>
100248158: b9406fe4    	ldr	w4, [sp, #0x6c]
10024815c: b84473e5    	ldur	w5, [sp, #0x47]
100248160: 6b0400bf    	cmp	w5, w4
100248164: 540004c1    	b.ne	0x1002481fc <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3dc>
100248168: 7940e3e4    	ldrh	w4, [sp, #0x70]
10024816c: 7844b3e5    	ldurh	w5, [sp, #0x4b]
100248170: 6b0400bf    	cmp	w5, w4
100248174: 54000401    	b.ne	0x1002481f4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3d4>
100248178: 7940e7e4    	ldrh	w4, [sp, #0x72]
10024817c: 7844d3e5    	ldurh	w5, [sp, #0x4d]
100248180: 6b0400bf    	cmp	w5, w4
100248184: 54000341    	b.ne	0x1002481ec <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3cc>
100248188: 39413fe4    	ldrb	w4, [sp, #0x4f]
10024818c: 3941d3e5    	ldrb	w5, [sp, #0x74]
100248190: 6b05009f    	cmp	w4, w5
100248194: 54000060    	b.eq	0x1002481a0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x380>
100248198: b24003e3    	orr	x3, xzr, #0x1
10024819c: 14000021    	b	0x100248220 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
1002481a0: 913143fb    	add	x27, sp, #0xc50
1002481a4: 9140137b    	add	x27, x27, #0x4, lsl #12 ; =0x4000
1002481a8: a9400760    	ldp	x0, x1, [x27]
1002481ac: f96633e2    	ldr	x2, [sp, #0x4c60]
1002481b0: 97f8d670    	bl	0x10007db70 <_runtime.convTslice>
1002481b4: f93e9fe0    	str	x0, [sp, #0x7d38]
1002481b8: 913243fb    	add	x27, sp, #0xc90
1002481bc: 9140177b    	add	x27, x27, #0x5, lsl #12 ; =0x5000
1002481c0: a9400760    	ldp	x0, x1, [x27]
1002481c4: f96e53e2    	ldr	x2, [sp, #0x5ca0]
1002481c8: 97f8d66a    	bl	0x10007db70 <_runtime.convTslice>
1002481cc: f97e9fe1    	ldr	x1, [sp, #0x7d38]
1002481d0: 90001422    	adrp	x2, 0x1004cc000 <_type:*+0x1f188>
1002481d4: 91108042    	add	x2, x2, #0x420
1002481d8: aa0003e3    	mov	x3, x0
1002481dc: aa0203e0    	mov	x0, x2
1002481e0: 97f9d740    	bl	0x1000bdee0 <_reflect.DeepEqual>
1002481e4: d2400003    	eor	x3, x0, #0x1
1002481e8: 1400000e    	b	0x100248220 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
1002481ec: b24003e3    	orr	x3, xzr, #0x1
1002481f0: 1400000c    	b	0x100248220 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
1002481f4: b24003e3    	orr	x3, xzr, #0x1
1002481f8: 1400000a    	b	0x100248220 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
1002481fc: b24003e3    	orr	x3, xzr, #0x1
100248200: 14000008    	b	0x100248220 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
100248204: b24003e3    	orr	x3, xzr, #0x1
100248208: 14000006    	b	0x100248220 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
10024820c: b24003e3    	orr	x3, xzr, #0x1
100248210: 14000004    	b	0x100248220 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
100248214: b24003e3    	orr	x3, xzr, #0x1
100248218: 14000002    	b	0x100248220 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
10024821c: b24003e3    	orr	x3, xzr, #0x1
100248220: 360001e3    	tbz	w3, #0x0, 0x10024825c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x43c>
100248224: f00014e4    	adrp	x4, 0x1004e7000 <_type:*+0x3a188>
100248228: 912bc084    	add	x4, x4, #0xaf0
10024822c: 900012e5    	adrp	x5, 0x1004a4000 <_cmp..dict.isNaN[string]>
100248230: 9119c0a5    	add	x5, x5, #0x670
100248234: 9134a3fb    	add	x27, sp, #0xd28
100248238: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
10024823c: a9001764    	stp	x4, x5, [x27]
100248240: f97eafe0    	ldr	x0, [sp, #0x7d58]
100248244: 3980001b    	ldrsb	x27, [x0]
100248248: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
10024824c: 9134a021    	add	x1, x1, #0xd28
100248250: b24003e2    	orr	x2, xzr, #0x1
100248254: aa0203e3    	mov	x3, x2
100248258: 97fac552    	bl	0x1000f97a0 <_testing.(*common).Fatal>
10024825c: 910ee3e0    	add	x0, sp, #0x3b8
100248260: 91400be1    	add	x1, sp, #0x2, lsl #12   ; =0x2000
100248264: 911f0021    	add	x1, x1, #0x7c0
100248268: d2848002    	mov	x2, #0x2400             ; =9216
10024826c: 97f6e671    	bl	0x100001c30 <_runtime.memequal>
100248270: 370001e0    	tbnz	w0, #0x0, 0x1002482ac <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x48c>
100248274: f00014e4    	adrp	x4, 0x1004e7000 <_type:*+0x3a188>
100248278: 912bc084    	add	x4, x4, #0xaf0
10024827c: 900012e5    	adrp	x5, 0x1004a4000 <_cmp..dict.isNaN[string]>
100248280: 911a00a5    	add	x5, x5, #0x680
100248284: 9134a3fb    	add	x27, sp, #0xd28
100248288: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
10024828c: a9001764    	stp	x4, x5, [x27]
100248290: f97eafe0    	ldr	x0, [sp, #0x7d58]
100248294: 3980001b    	ldrsb	x27, [x0]
100248298: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
10024829c: 9134a021    	add	x1, x1, #0xd28
1002482a0: b24003e2    	orr	x2, xzr, #0x1
1002482a4: aa0203e3    	mov	x3, x2
1002482a8: 97fac53e    	bl	0x1000f97a0 <_testing.(*common).Fatal>
1002482ac: 91400be4    	add	x4, sp, #0x2, lsl #12   ; =0x2000
1002482b0: 911f0084    	add	x4, x4, #0x7c0
1002482b4: d2801206    	mov	x6, #0x90               ; =144
1002482b8: a8817c9f    	stp	xzr, xzr, [x4], #0x10
1002482bc: a8817c9f    	stp	xzr, xzr, [x4], #0x10
1002482c0: a8817c9f    	stp	xzr, xzr, [x4], #0x10
1002482c4: a8817c9f    	stp	xzr, xzr, [x4], #0x10
1002482c8: d10004c6    	sub	x6, x6, #0x1
1002482cc: b5ffff66    	cbnz	x6, 0x1002482b8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x498>
1002482d0: f92e4fff    	str	xzr, [sp, #0x5c98]
1002482d4: f97eafe6    	ldr	x6, [sp, #0x7d58]
1002482d8: b24003e7    	orr	x7, xzr, #0x1
1002482dc: 390948c7    	strb	w7, [x6, #0x252]
1002482e0: f97eafe0    	ldr	x0, [sp, #0x7d58]
1002482e4: 910ae01b    	add	x27, x0, #0x2b8
1002482e8: a9401f66    	ldp	x6, x7, [x27]
1002482ec: eb0700df    	cmp	x6, x7
1002482f0: 540000a9    	b.ls	0x100248304 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4e4>
1002482f4: 910004e6    	add	x6, x7, #0x1
1002482f8: f9016006    	str	x6, [x0, #0x2c0]
1002482fc: b24003e0    	orr	x0, xzr, #0x1
100248300: 14000002    	b	0x100248308 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4e8>
100248304: 97fa9f1b    	bl	0x1000eff70 <_testing.(*B).loopSlowPath>
100248308: 36000540    	tbz	w0, #0x0, 0x1002483b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x590>
10024830c: f84633e6    	ldur	x6, [sp, #0x63]
100248310: 3941afe7    	ldrb	w7, [sp, #0x6b]
100248314: f80753e6    	stur	x6, [sp, #0x75]
100248318: 3901f7e7    	strb	w7, [sp, #0x7d]
10024831c: f845a3e6    	ldur	x6, [sp, #0x5a]
100248320: 39418be7    	ldrb	w7, [sp, #0x62]
100248324: f806c3e6    	stur	x6, [sp, #0x6c]
100248328: 3901d3e7    	strb	w7, [sp, #0x74]
10024832c: f92e4fff    	str	xzr, [sp, #0x5c98]
100248330: f97ea3e6    	ldr	x6, [sp, #0x7d40]
100248334: 394000c0    	ldrb	w0, [x6]
100248338: 9101d7e1    	add	x1, sp, #0x75
10024833c: 9101b3e2    	add	x2, sp, #0x6c
100248340: 9101fbe3    	add	x3, sp, #0x7e
100248344: 91400be4    	add	x4, sp, #0x2, lsl #12   ; =0x2000
100248348: 911f0084    	add	x4, x4, #0x7c0
10024834c: f9766be5    	ldr	x5, [sp, #0x6cd0]
100248350: 97feb758    	bl	0x1001f60b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords>
100248354: 913363fb    	add	x27, sp, #0xcd8
100248358: 91401b7b    	add	x27, x27, #0x6, lsl #12 ; =0x6000
10024835c: a9000760    	stp	x0, x1, [x27]
100248360: b4fffc00    	cbz	x0, 0x1002482e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4c0>
100248364: 9134a3fb    	add	x27, sp, #0xd28
100248368: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
10024836c: a9007f7f    	stp	xzr, xzr, [x27]
100248370: 913363fb    	add	x27, sp, #0xcd8
100248374: 91401b7b    	add	x27, x27, #0x6, lsl #12 ; =0x6000
100248378: a9401764    	ldp	x4, x5, [x27]
10024837c: b4000044    	cbz	x4, 0x100248384 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x564>
100248380: f9400484    	ldr	x4, [x4, #0x8]
100248384: 9134a3fb    	add	x27, sp, #0xd28
100248388: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
10024838c: a9001764    	stp	x4, x5, [x27]
100248390: f97eafe0    	ldr	x0, [sp, #0x7d58]
100248394: 3980001b    	ldrsb	x27, [x0]
100248398: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
10024839c: 9134a021    	add	x1, x1, #0xd28
1002483a0: b24003e2    	orr	x2, xzr, #0x1
1002483a4: aa0203e3    	mov	x3, x2
1002483a8: 97fac4fe    	bl	0x1000f97a0 <_testing.(*common).Fatal>
1002483ac: 17ffffcd    	b	0x1002482e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4c0>
1002483b0: aa1f03e4    	mov	x4, xzr
1002483b4: 14000002    	b	0x1002483bc <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x59c>
1002483b8: 91000484    	add	x4, x4, #0x1
1002483bc: f100109f    	cmp	x4, #0x4
1002483c0: 540009ca    	b.ge	0x1002484f8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x6d8>
1002483c4: f925e7e4    	str	x4, [sp, #0x4bc8]
1002483c8: aa1f03e5    	mov	x5, xzr
1002483cc: 14000002    	b	0x1002483d4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x5b4>
1002483d0: 910004a5    	add	x5, x5, #0x1
1002483d4: f10020bf    	cmp	x5, #0x8
1002483d8: 54ffff0a    	b.ge	0x1002483b8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x598>
1002483dc: f925ebe5    	str	x5, [sp, #0x4bd0]
1002483e0: aa1f03e6    	mov	x6, xzr
1002483e4: 14000002    	b	0x1002483ec <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x5cc>
1002483e8: 910004c6    	add	x6, x6, #0x1
1002483ec: f1000cdf    	cmp	x6, #0x3
1002483f0: 54ffff0a    	b.ge	0x1002483d0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x5b0>
1002483f4: f925e3e6    	str	x6, [sp, #0x4bc0]
1002483f8: d378dc87    	lsl	x7, x4, #8
1002483fc: 8b070ce7    	add	x7, x7, x7, lsl #3
100248400: f92627e7    	str	x7, [sp, #0x4c48]
100248404: 910ee3e8    	add	x8, sp, #0x3b8
100248408: 8b070109    	add	x9, x8, x7
10024840c: d37be8aa    	lsl	x10, x5, #5
100248410: 8b0a0d4a    	add	x10, x10, x10, lsl #3
100248414: f92623ea    	str	x10, [sp, #0x4c40]
100248418: 8b0a0129    	add	x9, x9, x10
10024841c: d37be8cb    	lsl	x11, x6, #5
100248420: 8b0b056b    	add	x11, x11, x11, lsl #1
100248424: f9261feb    	str	x11, [sp, #0x4c38]
100248428: 8b0b0129    	add	x9, x9, x11
10024842c: 914013ec    	add	x12, sp, #0x4, lsl #12  ; =0x4000
100248430: 912f618c    	add	x12, x12, #0xbd8
100248434: ad404530    	ldp	q16, q17, [x9]
100248438: ad004590    	stp	q16, q17, [x12]
10024843c: ad414530    	ldp	q16, q17, [x9, #0x20]
100248440: ad014590    	stp	q16, q17, [x12, #0x20]
100248444: ad424530    	ldp	q16, q17, [x9, #0x40]
100248448: ad024590    	stp	q16, q17, [x12, #0x40]
10024844c: aa1f03e9    	mov	x9, xzr
100248450: 14000002    	b	0x100248458 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x638>
100248454: 91000529    	add	x9, x9, #0x1
100248458: f100313f    	cmp	x9, #0xc
10024845c: 54fffc6a    	b.ge	0x1002483e8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x5c8>
100248460: f869798d    	ldr	x13, [x12, x9, lsl #3]
100248464: 91400bee    	add	x14, sp, #0x2, lsl #12  ; =0x2000
100248468: 911f01ce    	add	x14, x14, #0x7c0
10024846c: 8b0701cf    	add	x15, x14, x7
100248470: 8b0a01ef    	add	x15, x15, x10
100248474: 8b0b01ef    	add	x15, x15, x11
100248478: f86979ef    	ldr	x15, [x15, x9, lsl #3]
10024847c: f97eafe0    	ldr	x0, [sp, #0x7d58]
100248480: f9410810    	ldr	x16, [x0, #0x210]
100248484: 9b107dad    	mul	x13, x13, x16
100248488: eb0d01ff    	cmp	x15, x13
10024848c: 54fffe40    	b.eq	0x100248454 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x634>
100248490: f913dfe9    	str	x9, [sp, #0x27b8]
100248494: f00014e4    	adrp	x4, 0x1004e7000 <_type:*+0x3a188>
100248498: 912bc084    	add	x4, x4, #0xaf0
10024849c: 900012e5    	adrp	x5, 0x1004a4000 <_cmp..dict.isNaN[string]>
1002484a0: 911a40a5    	add	x5, x5, #0x690
1002484a4: 9134a3fb    	add	x27, sp, #0xd28
1002484a8: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
1002484ac: a9001764    	stp	x4, x5, [x27]
1002484b0: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
1002484b4: 9134a021    	add	x1, x1, #0xd28
1002484b8: b24003e2    	orr	x2, xzr, #0x1
1002484bc: aa0203e3    	mov	x3, x2
1002484c0: 97fac4b8    	bl	0x1000f97a0 <_testing.(*common).Fatal>
1002484c4: f965e7e4    	ldr	x4, [sp, #0x4bc8]
1002484c8: f965ebe5    	ldr	x5, [sp, #0x4bd0]
1002484cc: f965e3e6    	ldr	x6, [sp, #0x4bc0]
1002484d0: f96627e7    	ldr	x7, [sp, #0x4c48]
1002484d4: 910ee3e8    	add	x8, sp, #0x3b8
1002484d8: f953dfe9    	ldr	x9, [sp, #0x27b8]
1002484dc: f96623ea    	ldr	x10, [sp, #0x4c40]
1002484e0: f9661feb    	ldr	x11, [sp, #0x4c38]
1002484e4: 914013ec    	add	x12, sp, #0x4, lsl #12  ; =0x4000
1002484e8: 912f618c    	add	x12, x12, #0xbd8
1002484ec: 91400bee    	add	x14, sp, #0x2, lsl #12  ; =0x2000
1002484f0: 911f01ce    	add	x14, x14, #0x7c0
1002484f4: 17ffffd8    	b	0x100248454 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x634>
1002484f8: b84753e4    	ldur	w4, [sp, #0x75]
1002484fc: b84513e5    	ldur	w5, [sp, #0x51]
100248500: d503201f    	nop
100248504: 6b0400bf    	cmp	w5, w4
100248508: 540007c1    	b.ne	0x100248600 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e0>
10024850c: 784793e4    	ldurh	w4, [sp, #0x79]
100248510: 784553e5    	ldurh	w5, [sp, #0x55]
100248514: 6b0400bf    	cmp	w5, w4
100248518: 54000701    	b.ne	0x1002485f8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7d8>
10024851c: 7847b3e4    	ldurh	w4, [sp, #0x7b]
100248520: 784573e5    	ldurh	w5, [sp, #0x57]
100248524: 6b0400bf    	cmp	w5, w4
100248528: 54000641    	b.ne	0x1002485f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7d0>
10024852c: 394167e4    	ldrb	w4, [sp, #0x59]
100248530: 3941f7e5    	ldrb	w5, [sp, #0x7d]
100248534: 6b0400bf    	cmp	w5, w4
100248538: 54000581    	b.ne	0x1002485e8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7c8>
10024853c: b84473e4    	ldur	w4, [sp, #0x47]
100248540: b9406fe5    	ldr	w5, [sp, #0x6c]
100248544: 6b0400bf    	cmp	w5, w4
100248548: 540004c1    	b.ne	0x1002485e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7c0>
10024854c: 7940e3e4    	ldrh	w4, [sp, #0x70]
100248550: 7844b3e5    	ldurh	w5, [sp, #0x4b]
100248554: 6b0400bf    	cmp	w5, w4
100248558: 54000401    	b.ne	0x1002485d8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7b8>
10024855c: 7940e7e4    	ldrh	w4, [sp, #0x72]
100248560: 7844d3e5    	ldurh	w5, [sp, #0x4d]
100248564: 6b0400bf    	cmp	w5, w4
100248568: 54000341    	b.ne	0x1002485d0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7b0>
10024856c: 39413fe4    	ldrb	w4, [sp, #0x4f]
100248570: 3941d3e5    	ldrb	w5, [sp, #0x74]
100248574: 6b05009f    	cmp	w4, w5
100248578: 54000060    	b.eq	0x100248584 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x764>
10024857c: b24003e3    	orr	x3, xzr, #0x1
100248580: 14000021    	b	0x100248604 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
100248584: 913143fb    	add	x27, sp, #0xc50
100248588: 9140137b    	add	x27, x27, #0x4, lsl #12 ; =0x4000
10024858c: a9400760    	ldp	x0, x1, [x27]
100248590: f96633e2    	ldr	x2, [sp, #0x4c60]
100248594: 97f8d577    	bl	0x10007db70 <_runtime.convTslice>
100248598: f93e9fe0    	str	x0, [sp, #0x7d38]
10024859c: 913243fb    	add	x27, sp, #0xc90
1002485a0: 9140177b    	add	x27, x27, #0x5, lsl #12 ; =0x5000
1002485a4: a9400760    	ldp	x0, x1, [x27]
1002485a8: f96e53e2    	ldr	x2, [sp, #0x5ca0]
1002485ac: 97f8d571    	bl	0x10007db70 <_runtime.convTslice>
1002485b0: f97e9fe1    	ldr	x1, [sp, #0x7d38]
1002485b4: 90001422    	adrp	x2, 0x1004cc000 <_type:*+0x1f188>
1002485b8: 91108042    	add	x2, x2, #0x420
1002485bc: aa0003e3    	mov	x3, x0
1002485c0: aa0203e0    	mov	x0, x2
1002485c4: 97f9d647    	bl	0x1000bdee0 <_reflect.DeepEqual>
1002485c8: d2400003    	eor	x3, x0, #0x1
1002485cc: 1400000e    	b	0x100248604 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
1002485d0: b24003e3    	orr	x3, xzr, #0x1
1002485d4: 1400000c    	b	0x100248604 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
1002485d8: b24003e3    	orr	x3, xzr, #0x1
1002485dc: 1400000a    	b	0x100248604 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
1002485e0: b24003e3    	orr	x3, xzr, #0x1
1002485e4: 14000008    	b	0x100248604 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
1002485e8: b24003e3    	orr	x3, xzr, #0x1
1002485ec: 14000006    	b	0x100248604 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
1002485f0: b24003e3    	orr	x3, xzr, #0x1
1002485f4: 14000004    	b	0x100248604 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
1002485f8: b24003e3    	orr	x3, xzr, #0x1
1002485fc: 14000002    	b	0x100248604 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
100248600: b24003e3    	orr	x3, xzr, #0x1
100248604: 360001e3    	tbz	w3, #0x0, 0x100248640 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x820>
100248608: f00014e4    	adrp	x4, 0x1004e7000 <_type:*+0x3a188>
10024860c: 912bc084    	add	x4, x4, #0xaf0
100248610: 900012e5    	adrp	x5, 0x1004a4000 <_cmp..dict.isNaN[string]>
100248614: 9119c0a5    	add	x5, x5, #0x670
100248618: 9134a3fb    	add	x27, sp, #0xd28
10024861c: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
100248620: a9001764    	stp	x4, x5, [x27]
100248624: f97eafe0    	ldr	x0, [sp, #0x7d58]
100248628: 3980001b    	ldrsb	x27, [x0]
10024862c: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
100248630: 9134a021    	add	x1, x1, #0xd28
100248634: b24003e2    	orr	x2, xzr, #0x1
100248638: aa0203e3    	mov	x3, x2
10024863c: 97fac459    	bl	0x1000f97a0 <_testing.(*common).Fatal>
100248640: f953e3e0    	ldr	x0, [sp, #0x27c0]
100248644: f96e4fe1    	ldr	x1, [sp, #0x5c98]
100248648: 8b000020    	add	x0, x1, x0
10024864c: 9000199b    	adrp	x27, 0x100578000 <_runtime.mheap_+0x187e0>
100248650: f9047760    	str	x0, [x27, #0x8e8]
100248654: a97ffbfd    	ldp	x29, x30, [sp, #-0x8]
100248658: d28faa1b    	mov	x27, #0x7d50            ; =32080
10024865c: 8b3b63ff    	add	sp, sp, x27
100248660: d65f03c0    	ret
100248664: aa0703e1    	mov	x1, x7
100248668: f100643f    	cmp	x1, #0x19
10024866c: 54ffc2aa    	b.ge	0x100247ec0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0xa0>
100248670: 9101fbe6    	add	x6, sp, #0x7e
100248674: 8b0114c6    	add	x6, x6, x1, lsl #5
100248678: 91000427    	add	x7, x1, #0x1
10024867c: 790000c7    	strh	w7, [x6]
100248680: b24003e8    	orr	x8, xzr, #0x1
100248684: 910e7be9    	add	x9, sp, #0x39e
100248688: 38216928    	strb	w8, [x9, x1]
10024868c: a9402c6a    	ldp	x10, x11, [x3]
100248690: f100157f    	cmp	x11, #0x5
100248694: 54fffe81    	b.ne	0x100248664 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x844>
100248698: b940014b    	ldr	w11, [x10]
10024869c: d28cac8c    	mov	x12, #0x6564            ; =25956
1002486a0: f2ae6dcc    	movk	x12, #0x736e, lsl #16
1002486a4: 6b0c017f    	cmp	w11, w12
1002486a8: 54fffde1    	b.ne	0x100248664 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x844>
1002486ac: 3940114a    	ldrb	w10, [x10, #0x4]
1002486b0: 7101955f    	cmp	w10, #0x65
1002486b4: 54fffd81    	b.ne	0x100248664 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x844>
1002486b8: b27c03ea    	orr	x10, xzr, #0x10
1002486bc: 3821692a    	strb	w10, [x9, x1]
1002486c0: d37be829    	lsl	x9, x1, #5
1002486c4: cb010129    	sub	x9, x9, x1
1002486c8: aa1f03e1    	mov	x1, xzr
1002486cc: 1400000e    	b	0x100248704 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x8e4>
1002486d0: d28001ab    	mov	x11, #0xd               ; =13
1002486d4: 9b0b242c    	madd	x12, x1, x11, x9
1002486d8: d290412d    	mov	x13, #0x8209            ; =33289
1002486dc: f2a1040d    	movk	x13, #0x820, lsl #16
1002486e0: f2c4104d    	movk	x13, #0x2082, lsl #32
1002486e4: f2f0410d    	movk	x13, #0x8208, lsl #48
1002486e8: 9bcd7d8e    	umulh	x14, x12, x13
1002486ec: 8b4e158c    	add	x12, x12, x14, lsr #5
1002486f0: d345fdce    	lsr	x14, x14, #5
1002486f4: cb0e198c    	sub	x12, x12, x14, lsl #6
1002486f8: d1007d8c    	sub	x12, x12, #0x1f
1002486fc: 782178cc    	strh	w12, [x6, x1, lsl #1]
100248700: 91000421    	add	x1, x1, #0x1
100248704: f100403f    	cmp	x1, #0x10
100248708: 54fffe4b    	b.lt	0x1002486d0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x8b0>
10024870c: 17ffffd6    	b	0x100248664 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x844>
100248710: f90007e0    	str	x0, [sp, #0x8]
100248714: aa1e03e3    	mov	x3, x30
100248718: 97f8f102    	bl	0x100084b20 <_runtime.morestack.abi0>
10024871c: f94007e0    	ldr	x0, [sp, #0x8]
100248720: 17fffdc0    	b	0x100247e20 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1>
		...

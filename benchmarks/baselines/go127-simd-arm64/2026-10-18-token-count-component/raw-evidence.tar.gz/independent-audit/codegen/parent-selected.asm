
/private/tmp/govpx-next-token-count51/parent-encoder.test:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001001f60b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords>:
1001f60b0: f9400b90    	ldr	x16, [x28, #0x10]
1001f60b4: d10083f1    	sub	x17, sp, #0x20
1001f60b8: eb10023f    	cmp	x17, x16
1001f60bc: 54001d29    	b.ls	0x1001f6460 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x3b0>
1001f60c0: f8160ffe    	str	x30, [sp, #-0xa0]!
1001f60c4: f81f83fd    	stur	x29, [sp, #-0x8]
1001f60c8: d10023fd    	sub	x29, sp, #0x8
1001f60cc: b4000741    	cbz	x1, 0x1001f61b4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x104>
1001f60d0: b4000722    	cbz	x2, 0x1001f61b4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x104>
1001f60d4: b4000703    	cbz	x3, 0x1001f61b4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x104>
1001f60d8: b40006e4    	cbz	x4, 0x1001f61b4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x104>
1001f60dc: f9005be1    	str	x1, [sp, #0xb0]
1001f60e0: f9005fe2    	str	x2, [sp, #0xb8]
1001f60e4: f90063e3    	str	x3, [sp, #0xc0]
1001f60e8: f90067e4    	str	x4, [sp, #0xc8]
1001f60ec: f9006be5    	str	x5, [sp, #0xd0]
1001f60f0: 36000080    	tbz	w0, #0x0, 0x1001f6100 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x50>
1001f60f4: aa1f03e0    	mov	x0, xzr
1001f60f8: b24007e6    	orr	x6, xzr, #0x3
1001f60fc: 14000021    	b	0x1001f6180 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0xd0>
1001f6100: 39402027    	ldrb	w7, [x1, #0x8]
1001f6104: 39402048    	ldrb	w8, [x2, #0x8]
1001f6108: 8b0800e7    	add	x7, x7, x8
1001f610c: d3401ce7    	ubfx	x7, x7, #0, #8
1001f6110: d503201f    	nop
1001f6114: f1000cff    	cmp	x7, #0x3
1001f6118: 5400042a    	b.ge	0x1001f619c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0xec>
1001f611c: 910c0068    	add	x8, x3, #0x300
1001f6120: 394ce066    	ldrb	w6, [x3, #0x338]
1001f6124: f9002fe6    	str	x6, [sp, #0x58]
1001f6128: aa0403e0    	mov	x0, x4
1001f612c: aa0503e1    	mov	x1, x5
1001f6130: b24003e2    	orr	x2, xzr, #0x1
1001f6134: aa0703e3    	mov	x3, x7
1001f6138: aa1f03e4    	mov	x4, xzr
1001f613c: aa0803e5    	mov	x5, x8
1001f6140: 94000160    	bl	0x1001f66c0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>
1001f6144: b5000260    	cbnz	x0, 0x1001f6190 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0xe0>
1001f6148: f9402fe7    	ldr	x7, [sp, #0x58]
1001f614c: f10000ff    	cmp	x7, #0x0
1001f6150: 9a9fd7e7    	cset	x7, gt
1001f6154: f9405be8    	ldr	x8, [sp, #0xb0]
1001f6158: 39002107    	strb	w7, [x8, #0x8]
1001f615c: f9405fe9    	ldr	x9, [sp, #0xb8]
1001f6160: 39002127    	strb	w7, [x9, #0x8]
1001f6164: aa0803e1    	mov	x1, x8
1001f6168: aa0903e2    	mov	x2, x9
1001f616c: f94063e3    	ldr	x3, [sp, #0xc0]
1001f6170: f94067e4    	ldr	x4, [sp, #0xc8]
1001f6174: f9406be5    	ldr	x5, [sp, #0xd0]
1001f6178: b24003e0    	orr	x0, xzr, #0x1
1001f617c: aa1f03e6    	mov	x6, xzr
1001f6180: f9003be6    	str	x6, [sp, #0x70]
1001f6184: f90033e0    	str	x0, [sp, #0x60]
1001f6188: aa1f03e7    	mov	x7, xzr
1001f618c: 14000020    	b	0x1001f620c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x15c>
1001f6190: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6194: f84a07fe    	ldr	x30, [sp], #0xa0
1001f6198: d65f03c0    	ret
1001f619c: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f61a0: 9132437b    	add	x27, x27, #0xc90
1001f61a4: a9400760    	ldp	x0, x1, [x27]
1001f61a8: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f61ac: f84a07fe    	ldr	x30, [sp], #0xa0
1001f61b0: d65f03c0    	ret
1001f61b4: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f61b8: 9132437b    	add	x27, x27, #0xc90
1001f61bc: a9400760    	ldp	x0, x1, [x27]
1001f61c0: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f61c4: f84a07fe    	ldr	x30, [sp], #0xa0
1001f61c8: d65f03c0    	ret
1001f61cc: f94043e8    	ldr	x8, [sp, #0x80]
1001f61d0: d3420d09    	ubfx	x9, x8, #2, #2
1001f61d4: f94033e0    	ldr	x0, [sp, #0x60]
1001f61d8: f9402bea    	ldr	x10, [sp, #0x50]
1001f61dc: eb0a001f    	cmp	x0, x10
1001f61e0: 9a9fa7ea    	cset	x10, lt
1001f61e4: f9404beb    	ldr	x11, [sp, #0x90]
1001f61e8: f9405be1    	ldr	x1, [sp, #0xb0]
1001f61ec: 382b682a    	strb	w10, [x1, x11]
1001f61f0: f9405fe2    	ldr	x2, [sp, #0xb8]
1001f61f4: 3829684a    	strb	w10, [x2, x9]
1001f61f8: 91000507    	add	x7, x8, #0x1
1001f61fc: f94063e3    	ldr	x3, [sp, #0xc0]
1001f6200: f94067e4    	ldr	x4, [sp, #0xc8]
1001f6204: f9406be5    	ldr	x5, [sp, #0xd0]
1001f6208: f9403be6    	ldr	x6, [sp, #0x70]
1001f620c: f10040ff    	cmp	x7, #0x10
1001f6210: 540004aa    	b.ge	0x1001f62a4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x1f4>
1001f6214: 924004e8    	and	x8, x7, #0x3
1001f6218: 927e04e9    	and	x9, x7, #0xc
1001f621c: 3868682a    	ldrb	w10, [x1, x8]
1001f6220: 8b490849    	add	x9, x2, x9, lsr #2
1001f6224: 39400129    	ldrb	w9, [x9]
1001f6228: 8b0a0129    	add	x9, x9, x10
1001f622c: d3401d29    	ubfx	x9, x9, #0, #8
1001f6230: 910c806a    	add	x10, x3, #0x320
1001f6234: 3867694a    	ldrb	w10, [x10, x7]
1001f6238: eb0a001f    	cmp	x0, x10
1001f623c: 9a8ac00a    	csel	x10, x0, x10, gt
1001f6240: f1000d3f    	cmp	x9, #0x3
1001f6244: 5400024a    	b.ge	0x1001f628c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x1dc>
1001f6248: f90043e7    	str	x7, [sp, #0x80]
1001f624c: f9002bea    	str	x10, [sp, #0x50]
1001f6250: f9004be8    	str	x8, [sp, #0x90]
1001f6254: 8b071467    	add	x7, x3, x7, lsl #5
1001f6258: aa0503e1    	mov	x1, x5
1001f625c: aa0603e2    	mov	x2, x6
1001f6260: aa0903e3    	mov	x3, x9
1001f6264: aa0703e5    	mov	x5, x7
1001f6268: aa0a03e6    	mov	x6, x10
1001f626c: aa0003e7    	mov	x7, x0
1001f6270: aa0403e0    	mov	x0, x4
1001f6274: aa0703e4    	mov	x4, x7
1001f6278: 94000112    	bl	0x1001f66c0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>
1001f627c: b4fffa80    	cbz	x0, 0x1001f61cc <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x11c>
1001f6280: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6284: f84a07fe    	ldr	x30, [sp], #0xa0
1001f6288: d65f03c0    	ret
1001f628c: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6290: 9132437b    	add	x27, x27, #0xc90
1001f6294: a9400760    	ldp	x0, x1, [x27]
1001f6298: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f629c: f84a07fe    	ldr	x30, [sp], #0xa0
1001f62a0: d65f03c0    	ret
1001f62a4: b27c03e0    	orr	x0, xzr, #0x10
1001f62a8: 14000008    	b	0x1001f62c8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x218>
1001f62ac: f9403fe7    	ldr	x7, [sp, #0x78]
1001f62b0: 910004e0    	add	x0, x7, #0x1
1001f62b4: aa0903e1    	mov	x1, x9
1001f62b8: aa0a03e2    	mov	x2, x10
1001f62bc: f94063e3    	ldr	x3, [sp, #0xc0]
1001f62c0: f94067e4    	ldr	x4, [sp, #0xc8]
1001f62c4: f9406be5    	ldr	x5, [sp, #0xd0]
1001f62c8: f100601f    	cmp	x0, #0x18
1001f62cc: 54000b6a    	b.ge	0x1001f6438 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x388>
1001f62d0: 910c8067    	add	x7, x3, #0x320
1001f62d4: d503201f    	nop
1001f62d8: 386068e6    	ldrb	w6, [x7, x0]
1001f62dc: f1004c1f    	cmp	x0, #0x13
1001f62e0: 5400006d    	b.le	0x1001f62ec <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x23c>
1001f62e4: b27f03e7    	orr	x7, xzr, #0x2
1001f62e8: 14000002    	b	0x1001f62f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x240>
1001f62ec: aa1f03e7    	mov	x7, xzr
1001f62f0: 92400008    	and	x8, x0, #0x1
1001f62f4: 92400409    	and	x9, x0, #0x3
1001f62f8: 8b0800e8    	add	x8, x7, x8
1001f62fc: f100053f    	cmp	x9, #0x1
1001f6300: 5400004d    	b.le	0x1001f6308 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x258>
1001f6304: 910004e7    	add	x7, x7, #0x1
1001f6308: f100091f    	cmp	x8, #0x2
1001f630c: 5400008a    	b.ge	0x1001f631c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x26c>
1001f6310: 91001029    	add	x9, x1, #0x4
1001f6314: 38686929    	ldrb	w9, [x9, x8]
1001f6318: 14000004    	b	0x1001f6328 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x278>
1001f631c: 9100182a    	add	x10, x1, #0x6
1001f6320: d100090b    	sub	x11, x8, #0x2
1001f6324: 386b6949    	ldrb	w9, [x10, x11]
1001f6328: f10008ff    	cmp	x7, #0x2
1001f632c: 540000aa    	b.ge	0x1001f6340 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x290>
1001f6330: 54000942    	b.hs	0x1001f6458 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x3a8>
1001f6334: 9100104a    	add	x10, x2, #0x4
1001f6338: 3867694a    	ldrb	w10, [x10, x7]
1001f633c: 14000006    	b	0x1001f6354 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x2a4>
1001f6340: d10008ea    	sub	x10, x7, #0x2
1001f6344: f100095f    	cmp	x10, #0x2
1001f6348: 54000862    	b.hs	0x1001f6454 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x3a4>
1001f634c: 9100184b    	add	x11, x2, #0x6
1001f6350: 386a696a    	ldrb	w10, [x11, x10]
1001f6354: 8b0a0129    	add	x9, x9, x10
1001f6358: d3401d29    	ubfx	x9, x9, #0, #8
1001f635c: f1000d3f    	cmp	x9, #0x3
1001f6360: 5400060a    	b.ge	0x1001f6420 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x370>
1001f6364: f9003fe0    	str	x0, [sp, #0x78]
1001f6368: f90047e8    	str	x8, [sp, #0x88]
1001f636c: f90037e7    	str	x7, [sp, #0x68]
1001f6370: 8b001467    	add	x7, x3, x0, lsl #5
1001f6374: f90027e6    	str	x6, [sp, #0x48]
1001f6378: aa0403e0    	mov	x0, x4
1001f637c: aa0503e1    	mov	x1, x5
1001f6380: b27f03e2    	orr	x2, xzr, #0x2
1001f6384: aa0903e3    	mov	x3, x9
1001f6388: aa1f03e4    	mov	x4, xzr
1001f638c: aa0703e5    	mov	x5, x7
1001f6390: 940000cc    	bl	0x1001f66c0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>
1001f6394: b5000400    	cbnz	x0, 0x1001f6414 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x364>
1001f6398: f94027e7    	ldr	x7, [sp, #0x48]
1001f639c: f10000ff    	cmp	x7, #0x0
1001f63a0: 9a9fd7e7    	cset	x7, gt
1001f63a4: f94047e8    	ldr	x8, [sp, #0x88]
1001f63a8: f100091f    	cmp	x8, #0x2
1001f63ac: 540000ea    	b.ge	0x1001f63c8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x318>
1001f63b0: f9405be9    	ldr	x9, [sp, #0xb0]
1001f63b4: 9100112a    	add	x10, x9, #0x4
1001f63b8: 38286947    	strb	w7, [x10, x8]
1001f63bc: f94037e8    	ldr	x8, [sp, #0x68]
1001f63c0: f100091f    	cmp	x8, #0x2
1001f63c4: 14000007    	b	0x1001f63e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x330>
1001f63c8: f9405be9    	ldr	x9, [sp, #0xb0]
1001f63cc: 9100192a    	add	x10, x9, #0x6
1001f63d0: d1000908    	sub	x8, x8, #0x2
1001f63d4: 38286947    	strb	w7, [x10, x8]
1001f63d8: f94037e8    	ldr	x8, [sp, #0x68]
1001f63dc: f100091f    	cmp	x8, #0x2
1001f63e0: 540000ca    	b.ge	0x1001f63f8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x348>
1001f63e4: 54000362    	b.hs	0x1001f6450 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x3a0>
1001f63e8: f9405fea    	ldr	x10, [sp, #0xb8]
1001f63ec: 9100114b    	add	x11, x10, #0x4
1001f63f0: 38286967    	strb	w7, [x11, x8]
1001f63f4: 17ffffae    	b	0x1001f62ac <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x1fc>
1001f63f8: d1000908    	sub	x8, x8, #0x2
1001f63fc: f100091f    	cmp	x8, #0x2
1001f6400: 54000262    	b.hs	0x1001f644c <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x39c>
1001f6404: f9405fea    	ldr	x10, [sp, #0xb8]
1001f6408: 9100194b    	add	x11, x10, #0x6
1001f640c: 38286967    	strb	w7, [x11, x8]
1001f6410: 17ffffa7    	b	0x1001f62ac <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords+0x1fc>
1001f6414: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6418: f84a07fe    	ldr	x30, [sp], #0xa0
1001f641c: d65f03c0    	ret
1001f6420: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6424: 9132437b    	add	x27, x27, #0xc90
1001f6428: a9400760    	ldp	x0, x1, [x27]
1001f642c: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6430: f84a07fe    	ldr	x30, [sp], #0xa0
1001f6434: d65f03c0    	ret
1001f6438: aa1f03e0    	mov	x0, xzr
1001f643c: aa1f03e1    	mov	x1, xzr
1001f6440: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6444: f84a07fe    	ldr	x30, [sp], #0xa0
1001f6448: d65f03c0    	ret
1001f644c: 97fa4219    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6450: 97fa4218    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6454: 97fa4217    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6458: 97fa4216    	bl	0x100086cb0 <_runtime.panicBounds>
1001f645c: d503201f    	nop
1001f6460: 390023e0    	strb	w0, [sp, #0x8]
1001f6464: a9010be1    	stp	x1, x2, [sp, #0x10]
1001f6468: a90213e3    	stp	x3, x4, [sp, #0x20]
1001f646c: f9001be5    	str	x5, [sp, #0x30]
1001f6470: aa1e03e3    	mov	x3, x30
1001f6474: 97fa39cb    	bl	0x100084ba0 <_runtime.morestack_noctxt.abi0>
1001f6478: 394023e0    	ldrb	w0, [sp, #0x8]
1001f647c: a9410be1    	ldp	x1, x2, [sp, #0x10]
1001f6480: a94213e3    	ldp	x3, x4, [sp, #0x20]
1001f6484: f9401be5    	ldr	x5, [sp, #0x30]
1001f6488: 17ffff0a    	b	0x1001f60b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords>
1001f648c: 00000000    	udf	#0x0

00000001001f6490 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens>:
1001f6490: f9400b90    	ldr	x16, [x28, #0x10]
1001f6494: eb3063ff    	cmp	sp, x16
1001f6498: 54000fc9    	b.ls	0x1001f6690 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x200>
1001f649c: f81f0ffe    	str	x30, [sp, #-0x10]!
1001f64a0: f81f83fd    	stur	x29, [sp, #-0x8]
1001f64a4: d10023fd    	sub	x29, sp, #0x8
1001f64a8: b4000540    	cbz	x0, 0x1001f6550 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f64ac: b4000524    	cbz	x4, 0x1001f6550 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f64b0: f100103f    	cmp	x1, #0x4
1001f64b4: 540004e2    	b.hs	0x1001f6550 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f64b8: f1000c5f    	cmp	x2, #0x3
1001f64bc: 540004a2    	b.hs	0x1001f6550 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f64c0: f100047f    	cmp	x3, #0x1
1001f64c4: 54000468    	b.hi	0x1001f6550 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xc0>
1001f64c8: eb0300bf    	cmp	x5, x3
1001f64cc: 540001ad    	b.le	0x1001f6500 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x70>
1001f64d0: f10040bf    	cmp	x5, #0x10
1001f64d4: 540000ac    	b.gt	0x1001f64e8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x58>
1001f64d8: d378dc26    	lsl	x6, x1, #8
1001f64dc: 8b060cc6    	add	x6, x6, x6, lsl #3
1001f64e0: aa0303e7    	mov	x7, x3
1001f64e4: 14000021    	b	0x1001f6568 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xd8>
1001f64e8: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f64ec: 9132437b    	add	x27, x27, #0xc90
1001f64f0: a9400760    	ldp	x0, x1, [x27]
1001f64f4: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f64f8: f84107fe    	ldr	x30, [sp], #0x10
1001f64fc: d65f03c0    	ret
1001f6500: d378dc24    	lsl	x4, x1, #8
1001f6504: 8b040c84    	add	x4, x4, x4, lsl #3
1001f6508: 8b040004    	add	x4, x0, x4
1001f650c: d37be842    	lsl	x2, x2, #5
1001f6510: 8b020442    	add	x2, x2, x2, lsl #1
1001f6514: f100007f    	cmp	x3, #0x0
1001f6518: 9a9f07e3    	cset	x3, ne
1001f651c: 7200007f    	tst	w3, #0x1
1001f6520: d2802403    	mov	x3, #0x120              ; =288
1001f6524: 9a9f1063    	csel	x3, x3, xzr, ne
1001f6528: 8b040063    	add	x3, x3, x4
1001f652c: 8b020062    	add	x2, x3, x2
1001f6530: f9402c43    	ldr	x3, [x2, #0x58]
1001f6534: 91000463    	add	x3, x3, #0x1
1001f6538: f9002c43    	str	x3, [x2, #0x58]
1001f653c: aa1f03e0    	mov	x0, xzr
1001f6540: aa1f03e1    	mov	x1, xzr
1001f6544: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6548: f84107fe    	ldr	x30, [sp], #0x10
1001f654c: d65f03c0    	ret
1001f6550: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6554: 9132437b    	add	x27, x27, #0xc90
1001f6558: a9400760    	ldp	x0, x1, [x27]
1001f655c: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6560: f84107fe    	ldr	x30, [sp], #0x10
1001f6564: d65f03c0    	ret
1001f6568: eb0300bf    	cmp	x5, x3
1001f656c: 5400060d    	b.le	0x1001f662c <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x19c>
1001f6570: f0001948    	adrp	x8, 0x100521000 <_context..inittask+0xc0>
1001f6574: 911b0108    	add	x8, x8, #0x6c0
1001f6578: 78a37909    	ldrsh	x9, [x8, x3, lsl #1]
1001f657c: 92400d29    	and	x9, x9, #0xf
1001f6580: 78a97889    	ldrsh	x9, [x4, x9, lsl #1]
1001f6584: ca89fd2a    	eor	x10, x9, x9, asr #63
1001f6588: cb89fd49    	sub	x9, x10, x9, asr #63
1001f658c: f120013f    	cmp	x9, #0x800
1001f6590: 54000428    	b.hi	0x1001f6614 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x184>
1001f6594: 8b06000a    	add	x10, x0, x6
1001f6598: d37b08eb    	ubfiz	x11, x7, #5, #3
1001f659c: 8b0b0d6b    	add	x11, x11, x11, lsl #3
1001f65a0: b0001c4c    	adrp	x12, 0x10057f000 <_github.com/thesyncim/govpx/internal/vp8/encoder.coefficientTokenLUT+0x1e0>
1001f65a4: 9119018c    	add	x12, x12, #0x640
1001f65a8: 38696989    	ldrb	w9, [x12, x9]
1001f65ac: 8b0b014a    	add	x10, x10, x11
1001f65b0: f1000c5f    	cmp	x2, #0x3
1001f65b4: 540006a2    	b.hs	0x1001f6688 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x1f8>
1001f65b8: d37be84b    	lsl	x11, x2, #5
1001f65bc: 8b0b056b    	add	x11, x11, x11, lsl #1
1001f65c0: 8b0b014a    	add	x10, x10, x11
1001f65c4: f100313f    	cmp	x9, #0xc
1001f65c8: 540005e2    	b.hs	0x1001f6684 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x1f4>
1001f65cc: f869794b    	ldr	x11, [x10, x9, lsl #3]
1001f65d0: 9100056b    	add	x11, x11, #0x1
1001f65d4: f829794b    	str	x11, [x10, x9, lsl #3]
1001f65d8: 91000463    	add	x3, x3, #0x1
1001f65dc: f100407f    	cmp	x3, #0x10
1001f65e0: 5400010a    	b.ge	0x1001f6600 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x170>
1001f65e4: d000194a    	adrp	x10, 0x100520000 <_go:buildinfo>
1001f65e8: 912c814a    	add	x10, x10, #0xb20
1001f65ec: 38636947    	ldrb	w7, [x10, x3]
1001f65f0: d000194b    	adrp	x11, 0x100520000 <_go:buildinfo>
1001f65f4: 9126e16b    	add	x11, x11, #0x9b8
1001f65f8: 38696962    	ldrb	w2, [x11, x9]
1001f65fc: 17ffffdb    	b	0x1001f6568 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xd8>
1001f6600: d000194a    	adrp	x10, 0x100520000 <_go:buildinfo>
1001f6604: 912c814a    	add	x10, x10, #0xb20
1001f6608: d000194b    	adrp	x11, 0x100520000 <_go:buildinfo>
1001f660c: 9126e16b    	add	x11, x11, #0x9b8
1001f6610: 17ffffd6    	b	0x1001f6568 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0xd8>
1001f6614: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6618: 9132437b    	add	x27, x27, #0xc90
1001f661c: a9400760    	ldp	x0, x1, [x27]
1001f6620: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6624: f84107fe    	ldr	x30, [sp], #0x10
1001f6628: d65f03c0    	ret
1001f662c: f10040bf    	cmp	x5, #0x10
1001f6630: 540001ea    	b.ge	0x1001f666c <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x1dc>
1001f6634: d378dc23    	lsl	x3, x1, #8
1001f6638: 8b030c63    	add	x3, x3, x3, lsl #3
1001f663c: 8b030003    	add	x3, x0, x3
1001f6640: d37b08e4    	ubfiz	x4, x7, #5, #3
1001f6644: 8b040c84    	add	x4, x4, x4, lsl #3
1001f6648: 8b040063    	add	x3, x3, x4
1001f664c: f1000c5f    	cmp	x2, #0x3
1001f6650: 54000182    	b.hs	0x1001f6680 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens+0x1f0>
1001f6654: d37be842    	lsl	x2, x2, #5
1001f6658: 8b020442    	add	x2, x2, x2, lsl #1
1001f665c: 8b020062    	add	x2, x3, x2
1001f6660: f9402c43    	ldr	x3, [x2, #0x58]
1001f6664: 91000463    	add	x3, x3, #0x1
1001f6668: f9002c43    	str	x3, [x2, #0x58]
1001f666c: aa1f03e0    	mov	x0, xzr
1001f6670: aa1f03e1    	mov	x1, xzr
1001f6674: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6678: f84107fe    	ldr	x30, [sp], #0x10
1001f667c: d65f03c0    	ret
1001f6680: 97fa418c    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6684: 97fa418b    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6688: 97fa418a    	bl	0x100086cb0 <_runtime.panicBounds>
1001f668c: d503201f    	nop
1001f6690: a90087e0    	stp	x0, x1, [sp, #0x8]
1001f6694: a9018fe2    	stp	x2, x3, [sp, #0x18]
1001f6698: a90297e4    	stp	x4, x5, [sp, #0x28]
1001f669c: aa1e03e3    	mov	x3, x30
1001f66a0: 97fa3940    	bl	0x100084ba0 <_runtime.morestack_noctxt.abi0>
1001f66a4: a94087e0    	ldp	x0, x1, [sp, #0x8]
1001f66a8: a9418fe2    	ldp	x2, x3, [sp, #0x18]
1001f66ac: a94297e4    	ldp	x4, x5, [sp, #0x28]
1001f66b0: 17ffff78    	b	0x1001f6490 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens>
		...

00000001001f66c0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>:
1001f66c0: f9400b90    	ldr	x16, [x28, #0x10]
1001f66c4: eb3063ff    	cmp	sp, x16
1001f66c8: 54001a09    	b.ls	0x1001f6a08 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x348>
1001f66cc: f81c0ffe    	str	x30, [sp, #-0x40]!
1001f66d0: f81f83fd    	stur	x29, [sp, #-0x8]
1001f66d4: d10023fd    	sub	x29, sp, #0x8
1001f66d8: b4000881    	cbz	x1, 0x1001f67e8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x128>
1001f66dc: b40007a0    	cbz	x0, 0x1001f67d0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f66e0: b4000785    	cbz	x5, 0x1001f67d0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f66e4: f100105f    	cmp	x2, #0x4
1001f66e8: 54000742    	b.hs	0x1001f67d0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f66ec: f1000c7f    	cmp	x3, #0x3
1001f66f0: 54000702    	b.hs	0x1001f67d0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f66f4: f100049f    	cmp	x4, #0x1
1001f66f8: 540006c8    	b.hi	0x1001f67d0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x110>
1001f66fc: eb0400df    	cmp	x6, x4
1001f6700: 540001cd    	b.le	0x1001f6738 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x78>
1001f6704: f10040df    	cmp	x6, #0x10
1001f6708: 540000cc    	b.gt	0x1001f6720 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x60>
1001f670c: d378dc47    	lsl	x7, x2, #8
1001f6710: 8b070ce7    	add	x7, x7, x7, lsl #3
1001f6714: aa1f03e8    	mov	x8, xzr
1001f6718: aa0403e9    	mov	x9, x4
1001f671c: 1400003e    	b	0x1001f6814 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x154>
1001f6720: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f6724: 9132437b    	add	x27, x27, #0xc90
1001f6728: a9400760    	ldp	x0, x1, [x27]
1001f672c: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6730: f84407fe    	ldr	x30, [sp], #0x40
1001f6734: d65f03c0    	ret
1001f6738: d378dc45    	lsl	x5, x2, #8
1001f673c: 8b050ca5    	add	x5, x5, x5, lsl #3
1001f6740: 8b050005    	add	x5, x0, x5
1001f6744: d37be866    	lsl	x6, x3, #5
1001f6748: 8b0604c6    	add	x6, x6, x6, lsl #1
1001f674c: 8b020c82    	add	x2, x4, x2, lsl #3
1001f6750: 8b020442    	add	x2, x2, x2, lsl #1
1001f6754: 8b020062    	add	x2, x3, x2
1001f6758: d2800163    	mov	x3, #0xb                ; =11
1001f675c: 9b037c42    	mul	x2, x2, x3
1001f6760: d37cec42    	lsl	x2, x2, #4
1001f6764: d2800163    	mov	x3, #0xb                ; =11
1001f6768: aa030042    	orr	x2, x2, x3
1001f676c: f100009f    	cmp	x4, #0x0
1001f6770: 9a9f07e3    	cset	x3, ne
1001f6774: 7200007f    	tst	w3, #0x1
1001f6778: d2802403    	mov	x3, #0x120              ; =288
1001f677c: 9a9f1063    	csel	x3, x3, xzr, ne
1001f6780: 8b050063    	add	x3, x3, x5
1001f6784: 8b060063    	add	x3, x3, x6
1001f6788: f9402c64    	ldr	x4, [x3, #0x58]
1001f678c: 91000484    	add	x4, x4, #0x1
1001f6790: f9002c64    	str	x4, [x3, #0x58]
1001f6794: a9409023    	ldp	x3, x4, [x1, #0x8]
1001f6798: 91000465    	add	x5, x3, #0x1
1001f679c: d503201f    	nop
1001f67a0: eb05009f    	cmp	x4, x5
1001f67a4: 54000363    	b.lo	0x1001f6810 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x150>
1001f67a8: f9000425    	str	x5, [x1, #0x8]
1001f67ac: eb05007f    	cmp	x3, x5
1001f67b0: 540002e2    	b.hs	0x1001f680c <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x14c>
1001f67b4: f9400024    	ldr	x4, [x1]
1001f67b8: b8237882    	str	w2, [x4, x3, lsl #2]
1001f67bc: aa1f03e0    	mov	x0, xzr
1001f67c0: aa1f03e1    	mov	x1, xzr
1001f67c4: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f67c8: f84407fe    	ldr	x30, [sp], #0x40
1001f67cc: d65f03c0    	ret
1001f67d0: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f67d4: 9132437b    	add	x27, x27, #0xc90
1001f67d8: a9400760    	ldp	x0, x1, [x27]
1001f67dc: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f67e0: f84407fe    	ldr	x30, [sp], #0x40
1001f67e4: d65f03c0    	ret
1001f67e8: aa0203e1    	mov	x1, x2
1001f67ec: aa0303e2    	mov	x2, x3
1001f67f0: aa0403e3    	mov	x3, x4
1001f67f4: aa0503e4    	mov	x4, x5
1001f67f8: aa0603e5    	mov	x5, x6
1001f67fc: 97ffff25    	bl	0x1001f6490 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokens>
1001f6800: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6804: f84407fe    	ldr	x30, [sp], #0x40
1001f6808: d65f03c0    	ret
1001f680c: 97fa4129    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6810: 97fa4128    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6814: eb0400df    	cmp	x6, x4
1001f6818: 5400094d    	b.le	0x1001f6940 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x280>
1001f681c: f000194a    	adrp	x10, 0x100521000 <_context..inittask+0xc0>
1001f6820: 911b014a    	add	x10, x10, #0x6c0
1001f6824: 78a4794b    	ldrsh	x11, [x10, x4, lsl #1]
1001f6828: 92400d6b    	and	x11, x11, #0xf
1001f682c: 78ab78ab    	ldrsh	x11, [x5, x11, lsl #1]
1001f6830: ca8bfd6c    	eor	x12, x11, x11, asr #63
1001f6834: cb8bfd8c    	sub	x12, x12, x11, asr #63
1001f6838: f120019f    	cmp	x12, #0x800
1001f683c: 54000768    	b.hi	0x1001f6928 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x268>
1001f6840: 8b07000d    	add	x13, x0, x7
1001f6844: d37b092e    	ubfiz	x14, x9, #5, #3
1001f6848: 8b0e0dce    	add	x14, x14, x14, lsl #3
1001f684c: b0001c4f    	adrp	x15, 0x10057f000 <_github.com/thesyncim/govpx/internal/vp8/encoder.coefficientTokenLUT+0x1e0>
1001f6850: 911901ef    	add	x15, x15, #0x640
1001f6854: 386c69f0    	ldrb	w16, [x15, x12]
1001f6858: 8b0e01ad    	add	x13, x13, x14
1001f685c: f1000c7f    	cmp	x3, #0x3
1001f6860: 54000d02    	b.hs	0x1001f6a00 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x340>
1001f6864: aa1003ee    	mov	x14, x16
1001f6868: d37be871    	lsl	x17, x3, #5
1001f686c: 8b110631    	add	x17, x17, x17, lsl #1
1001f6870: 8b1101ad    	add	x13, x13, x17
1001f6874: f10031df    	cmp	x14, #0xc
1001f6878: 54000c22    	b.hs	0x1001f69fc <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x33c>
1001f687c: 937ffd6b    	asr	x11, x11, #63
1001f6880: f86e79b1    	ldr	x17, [x13, x14, lsl #3]
1001f6884: 91000631    	add	x17, x17, #0x1
1001f6888: f82e79b1    	str	x17, [x13, x14, lsl #3]
1001f688c: aa1003ed    	mov	x13, x16
1001f6890: 8b020d30    	add	x16, x9, x2, lsl #3
1001f6894: 8b100610    	add	x16, x16, x16, lsl #1
1001f6898: 8b100070    	add	x16, x3, x16
1001f689c: d2800171    	mov	x17, #0xb               ; =11
1001f68a0: 9b107e30    	mul	x16, x17, x16
1001f68a4: aa1011ad    	orr	x13, x13, x16, lsl #4
1001f68a8: aa0c3dac    	orr	x12, x13, x12, lsl #15
1001f68ac: 9240016b    	and	x11, x11, #0x1
1001f68b0: aa0b6d8b    	orr	x11, x12, x11, lsl #27
1001f68b4: d3401d0c    	ubfx	x12, x8, #0, #8
1001f68b8: a940c02d    	ldp	x13, x16, [x1, #0x8]
1001f68bc: 910005b3    	add	x19, x13, #0x1
1001f68c0: d503201f    	nop
1001f68c4: aa0c716b    	orr	x11, x11, x12, lsl #28
1001f68c8: eb13021f    	cmp	x16, x19
1001f68cc: 54000923    	b.lo	0x1001f69f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x330>
1001f68d0: f9000433    	str	x19, [x1, #0x8]
1001f68d4: eb1301bf    	cmp	x13, x19
1001f68d8: 54000882    	b.hs	0x1001f69e8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x328>
1001f68dc: 91000484    	add	x4, x4, #0x1
1001f68e0: f940002c    	ldr	x12, [x1]
1001f68e4: b82d798b    	str	w11, [x12, x13, lsl #2]
1001f68e8: f100409f    	cmp	x4, #0x10
1001f68ec: 5400014a    	b.ge	0x1001f6914 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x254>
1001f68f0: d000194b    	adrp	x11, 0x100520000 <_go:buildinfo>
1001f68f4: 912c816b    	add	x11, x11, #0xb20
1001f68f8: 38646969    	ldrb	w9, [x11, x4]
1001f68fc: d000194c    	adrp	x12, 0x100520000 <_go:buildinfo>
1001f6900: 9126e18c    	add	x12, x12, #0x9b8
1001f6904: 386e6983    	ldrb	w3, [x12, x14]
1001f6908: f100007f    	cmp	x3, #0x0
1001f690c: 9a9f17e8    	cset	x8, eq
1001f6910: 17ffffc1    	b	0x1001f6814 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x154>
1001f6914: d000194b    	adrp	x11, 0x100520000 <_go:buildinfo>
1001f6918: 912c816b    	add	x11, x11, #0xb20
1001f691c: d000194c    	adrp	x12, 0x100520000 <_go:buildinfo>
1001f6920: 9126e18c    	add	x12, x12, #0x9b8
1001f6924: 17ffffbc    	b	0x1001f6814 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x154>
1001f6928: 90001a7b    	adrp	x27, 0x100542000 <_crypto/internal/fips140/aes.td3+0x60>
1001f692c: 9132437b    	add	x27, x27, #0xc90
1001f6930: a9400760    	ldp	x0, x1, [x27]
1001f6934: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f6938: f84407fe    	ldr	x30, [sp], #0x40
1001f693c: d65f03c0    	ret
1001f6940: f10040df    	cmp	x6, #0x10
1001f6944: 5400042a    	b.ge	0x1001f69c8 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x308>
1001f6948: d378dc44    	lsl	x4, x2, #8
1001f694c: 8b040c84    	add	x4, x4, x4, lsl #3
1001f6950: 8b040004    	add	x4, x0, x4
1001f6954: d37b0925    	ubfiz	x5, x9, #5, #3
1001f6958: 8b050ca5    	add	x5, x5, x5, lsl #3
1001f695c: 8b050084    	add	x4, x4, x5
1001f6960: f1000c7f    	cmp	x3, #0x3
1001f6964: 54000402    	b.hs	0x1001f69e4 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x324>
1001f6968: d37be865    	lsl	x5, x3, #5
1001f696c: 8b0504a5    	add	x5, x5, x5, lsl #1
1001f6970: 8b050084    	add	x4, x4, x5
1001f6974: f9402c85    	ldr	x5, [x4, #0x58]
1001f6978: 910004a5    	add	x5, x5, #0x1
1001f697c: f9002c85    	str	x5, [x4, #0x58]
1001f6980: 8b020d22    	add	x2, x9, x2, lsl #3
1001f6984: 8b020442    	add	x2, x2, x2, lsl #1
1001f6988: 8b020062    	add	x2, x3, x2
1001f698c: d2800163    	mov	x3, #0xb                ; =11
1001f6990: 9b027c62    	mul	x2, x3, x2
1001f6994: d37cec42    	lsl	x2, x2, #4
1001f6998: a9409023    	ldp	x3, x4, [x1, #0x8]
1001f699c: 91000465    	add	x5, x3, #0x1
1001f69a0: d503201f    	nop
1001f69a4: d2800166    	mov	x6, #0xb                ; =11
1001f69a8: aa060042    	orr	x2, x2, x6
1001f69ac: eb05009f    	cmp	x4, x5
1001f69b0: 54000183    	b.lo	0x1001f69e0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x320>
1001f69b4: f9000425    	str	x5, [x1, #0x8]
1001f69b8: eb05007f    	cmp	x3, x5
1001f69bc: 54000102    	b.hs	0x1001f69dc <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords+0x31c>
1001f69c0: f9400024    	ldr	x4, [x1]
1001f69c4: b8237882    	str	w2, [x4, x3, lsl #2]
1001f69c8: aa1f03e0    	mov	x0, xzr
1001f69cc: aa1f03e1    	mov	x1, xzr
1001f69d0: f85f83fd    	ldur	x29, [sp, #-0x8]
1001f69d4: f84407fe    	ldr	x30, [sp], #0x40
1001f69d8: d65f03c0    	ret
1001f69dc: 97fa40b5    	bl	0x100086cb0 <_runtime.panicBounds>
1001f69e0: 97fa40b4    	bl	0x100086cb0 <_runtime.panicBounds>
1001f69e4: 97fa40b3    	bl	0x100086cb0 <_runtime.panicBounds>
1001f69e8: aa1303e0    	mov	x0, x19
1001f69ec: 97fa40b1    	bl	0x100086cb0 <_runtime.panicBounds>
1001f69f0: aa1303e0    	mov	x0, x19
1001f69f4: aa1003e1    	mov	x1, x16
1001f69f8: 97fa40ae    	bl	0x100086cb0 <_runtime.panicBounds>
1001f69fc: 97fa40ad    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6a00: 97fa40ac    	bl	0x100086cb0 <_runtime.panicBounds>
1001f6a04: d503201f    	nop
1001f6a08: a90087e0    	stp	x0, x1, [sp, #0x8]
1001f6a0c: a9018fe2    	stp	x2, x3, [sp, #0x18]
1001f6a10: a90297e4    	stp	x4, x5, [sp, #0x28]
1001f6a14: f9001fe6    	str	x6, [sp, #0x38]
1001f6a18: aa1e03e3    	mov	x3, x30
1001f6a1c: 97fa3861    	bl	0x100084ba0 <_runtime.morestack_noctxt.abi0>
1001f6a20: a94087e0    	ldp	x0, x1, [sp, #0x8]
1001f6a24: a9418fe2    	ldp	x2, x3, [sp, #0x18]
1001f6a28: a94297e4    	ldp	x4, x5, [sp, #0x28]
1001f6a2c: f9401fe6    	ldr	x6, [sp, #0x38]
1001f6a30: 17ffff24    	b	0x1001f66c0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countBlockCoefficientTokensAndRecords>
		...

0000000100237670 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51>:
100237670: f9400b90    	ldr	x16, [x28, #0x10]
100237674: d10183f1    	sub	x17, sp, #0x60
100237678: eb10023f    	cmp	x17, x16
10023767c: 540012a9    	b.ls	0x1002378d0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x260>
100237680: f8120ffe    	str	x30, [sp, #-0xe0]!
100237684: f81f83fd    	stur	x29, [sp, #-0x8]
100237688: d10023fd    	sub	x29, sp, #0x8
10023768c: f90077e0    	str	x0, [sp, #0xe8]
100237690: 79006fff    	strh	wzr, [sp, #0x36]
100237694: b24003e1    	orr	x1, xzr, #0x1
100237698: 3900dfe1    	strb	w1, [sp, #0x37]
10023769c: aa1f03e1    	mov	x1, xzr
1002376a0: 14000004    	b	0x1002376b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x40>
1002376a4: f9402be2    	ldr	x2, [sp, #0x50]
1002376a8: 91000441    	add	x1, x2, #0x1
1002376ac: f94077e0    	ldr	x0, [sp, #0xe8]
1002376b0: f100083f    	cmp	x1, #0x2
1002376b4: 5400108a    	b.ge	0x1002378c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x254>
1002376b8: f9002be1    	str	x1, [sp, #0x50]
1002376bc: 9100dbe2    	add	x2, sp, #0x36
1002376c0: 38616841    	ldrb	w1, [x2, x1]
1002376c4: 3900cfe1    	strb	w1, [sp, #0x33]
1002376c8: 90001580    	adrp	x0, 0x1004e7000 <_type:*+0x3a188>
1002376cc: 913bc000    	add	x0, x0, #0xef0
1002376d0: 97f78a28    	bl	0x100019f70 <_runtime.newobject>
1002376d4: f9006be0    	str	x0, [sp, #0xd0]
1002376d8: 3940cfe1    	ldrb	w1, [sp, #0x33]
1002376dc: 39000001    	strb	w1, [x0]
1002376e0: d0000161    	adrp	x1, 0x100265000 <_crypto/internal/fips140/aes/gcm.(*CMAC).MAC+0xf0>
1002376e4: 912da021    	add	x1, x1, #0xb68
1002376e8: b27e03e2    	orr	x2, xzr, #0x4
1002376ec: a9068be1    	stp	x1, x2, [sp, #0x68]
1002376f0: f0000161    	adrp	x1, 0x100266000 <_runtime.rodata+0x700>
1002376f4: 91007021    	add	x1, x1, #0x1c
1002376f8: b27f07e2    	orr	x2, xzr, #0x6
1002376fc: a9078be1    	stp	x1, x2, [sp, #0x78]
100237700: d0000161    	adrp	x1, 0x100265000 <_crypto/internal/fips140/aes/gcm.(*CMAC).MAC+0xf0>
100237704: 91363821    	add	x1, x1, #0xd8e
100237708: d28000a2    	mov	x2, #0x5                ; =5
10023770c: a9088be1    	stp	x1, x2, [sp, #0x88]
100237710: 9101a3e1    	add	x1, sp, #0x68
100237714: aa1f03e2    	mov	x2, xzr
100237718: 14000007    	b	0x100237734 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0xc4>
10023771c: f94033e3    	ldr	x3, [sp, #0x60]
100237720: 91004061    	add	x1, x3, #0x10
100237724: f94027e3    	ldr	x3, [sp, #0x48]
100237728: 91000463    	add	x3, x3, #0x1
10023772c: f9406be0    	ldr	x0, [sp, #0xd0]
100237730: aa0303e2    	mov	x2, x3
100237734: f1000c5f    	cmp	x2, #0x3
100237738: 54fffb6a    	b.ge	0x1002376a4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x34>
10023773c: f90027e2    	str	x2, [sp, #0x48]
100237740: f90033e1    	str	x1, [sp, #0x60]
100237744: a9401023    	ldp	x3, x4, [x1]
100237748: f90023e4    	str	x4, [sp, #0x40]
10023774c: f9002fe3    	str	x3, [sp, #0x58]
100237750: b27c03e0    	orr	x0, xzr, #0x10
100237754: 90001581    	adrp	x1, 0x1004e7000 <_type:*+0x3a188>
100237758: 912bc021    	add	x1, x1, #0xaf0
10023775c: b24003e2    	orr	x2, xzr, #0x1
100237760: 97f78c44    	bl	0x10001a870 <_runtime.mallocgcSmallScanNoHeaderSC2>
100237764: f94023e3    	ldr	x3, [sp, #0x40]
100237768: f9000403    	str	x3, [x0, #0x8]
10023776c: b0001a1b    	adrp	x27, 0x100578000 <_runtime.mheap_+0x187e0>
100237770: b94dc363    	ldr	w3, [x27, #0xdc0]
100237774: 35000063    	cbnz	w3, 0x100237780 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x110>
100237778: f9402fe3    	ldr	x3, [sp, #0x58]
10023777c: 14000004    	b	0x10023778c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x11c>
100237780: 97f93c94    	bl	0x1000869d0 <_runtime.gcWriteBarrier1>
100237784: f9402fe3    	ldr	x3, [sp, #0x58]
100237788: f9000323    	str	x3, [x25]
10023778c: f90067e0    	str	x0, [sp, #0xc8]
100237790: f9000003    	str	x3, [x0]
100237794: 79006bff    	strh	wzr, [sp, #0x34]
100237798: b24003e2    	orr	x2, xzr, #0x1
10023779c: 3900d7e2    	strb	w2, [sp, #0x35]
1002377a0: aa1f03e1    	mov	x1, xzr
1002377a4: 1400000e    	b	0x1002377dc <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x16c>
1002377a8: f9000404    	str	x4, [x0, #0x8]
1002377ac: 3940cbe4    	ldrb	w4, [sp, #0x32]
1002377b0: 39004004    	strb	w4, [x0, #0x10]
1002377b4: f9000c05    	str	x5, [x0, #0x18]
1002377b8: f9402fe1    	ldr	x1, [sp, #0x58]
1002377bc: f9401fe2    	ldr	x2, [sp, #0x38]
1002377c0: aa0003e3    	mov	x3, x0
1002377c4: f94077e0    	ldr	x0, [sp, #0xe8]
1002377c8: 97fae7d6    	bl	0x1000f1720 <_testing.(*B).Run>
1002377cc: f94023e4    	ldr	x4, [sp, #0x40]
1002377d0: 91000481    	add	x1, x4, #0x1
1002377d4: f94067e0    	ldr	x0, [sp, #0xc8]
1002377d8: b24003e2    	orr	x2, xzr, #0x1
1002377dc: f100083f    	cmp	x1, #0x2
1002377e0: 54fff9ea    	b.ge	0x10023771c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0xac>
1002377e4: f90023e1    	str	x1, [sp, #0x40]
1002377e8: 9100d3e2    	add	x2, sp, #0x34
1002377ec: 38616842    	ldrb	w2, [x2, x1]
1002377f0: 3900cbe2    	strb	w2, [sp, #0x32]
1002377f4: 910263e2    	add	x2, sp, #0x98
1002377f8: a9007c5f    	stp	xzr, xzr, [x2]
1002377fc: a9017c5f    	stp	xzr, xzr, [x2, #0x10]
100237800: a9027c5f    	stp	xzr, xzr, [x2, #0x20]
100237804: f9406be2    	ldr	x2, [sp, #0xd0]
100237808: 39400042    	ldrb	w2, [x2]
10023780c: b0000283    	adrp	x3, 0x100288000 <_runtime.modinfo.str+0x920>
100237810: 91380063    	add	x3, x3, #0xe00
100237814: 8b020c62    	add	x2, x3, x2, lsl #3
100237818: 90001583    	adrp	x3, 0x1004e7000 <_type:*+0x3a188>
10023781c: 913bc063    	add	x3, x3, #0xef0
100237820: a9098be3    	stp	x3, x2, [sp, #0x98]
100237824: a9400400    	ldp	x0, x1, [x0]
100237828: 97f918aa    	bl	0x10007dad0 <_runtime.convTstring>
10023782c: 90001582    	adrp	x2, 0x1004e7000 <_type:*+0x3a188>
100237830: 912bc042    	add	x2, x2, #0xaf0
100237834: a90a83e2    	stp	x2, x0, [sp, #0xa8]
100237838: 3940cbe2    	ldrb	w2, [sp, #0x32]
10023783c: b0000283    	adrp	x3, 0x100288000 <_runtime.modinfo.str+0x920>
100237840: 91380063    	add	x3, x3, #0xe00
100237844: 8b020c62    	add	x2, x3, x2, lsl #3
100237848: 90001583    	adrp	x3, 0x1004e7000 <_type:*+0x3a188>
10023784c: 913bc063    	add	x3, x3, #0xef0
100237850: a90b8be3    	stp	x3, x2, [sp, #0xb8]
100237854: d0000180    	adrp	x0, 0x100269000 <_runtime.rodata+0x3700>
100237858: 91365c00    	add	x0, x0, #0xd97
10023785c: d2800241    	mov	x1, #0x12               ; =18
100237860: 910263e2    	add	x2, sp, #0x98
100237864: b24007e3    	orr	x3, xzr, #0x3
100237868: aa0303e4    	mov	x4, x3
10023786c: 97fa71c9    	bl	0x1000d3f90 <_fmt.Sprintf>
100237870: f9002fe0    	str	x0, [sp, #0x58]
100237874: f9001fe1    	str	x1, [sp, #0x38]
100237878: b27b03e0    	orr	x0, xzr, #0x20
10023787c: b0001641    	adrp	x1, 0x100500000 <_type:*+0x53188>
100237880: 913ec021    	add	x1, x1, #0xfb0
100237884: b24003e2    	orr	x2, xzr, #0x1
100237888: 97f78dc6    	bl	0x10001afa0 <_runtime.mallocgcSmallScanNoHeaderSC4>
10023788c: 90000082    	adrp	x2, 0x100247000 <_github.com/thesyncim/govpx/internal/vp8/encoder.TestFastQuantizeBlockSIMDMatchesScalar.func2+0x1d0>
100237890: 91320042    	add	x2, x2, #0xc80
100237894: f9000002    	str	x2, [x0]
100237898: b0001a1b    	adrp	x27, 0x100578000 <_runtime.mheap_+0x187e0>
10023789c: b94dc362    	ldr	w2, [x27, #0xdc0]
1002378a0: 35000082    	cbnz	w2, 0x1002378b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x240>
1002378a4: f94067e4    	ldr	x4, [sp, #0xc8]
1002378a8: f9406be5    	ldr	x5, [sp, #0xd0]
1002378ac: 17ffffbf    	b	0x1002377a8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x138>
1002378b0: 97f93c4c    	bl	0x1000869e0 <_runtime.gcWriteBarrier2>
1002378b4: f94067e4    	ldr	x4, [sp, #0xc8]
1002378b8: f9406be5    	ldr	x5, [sp, #0xd0]
1002378bc: a9001724    	stp	x4, x5, [x25]
1002378c0: 17ffffba    	b	0x1002377a8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51+0x138>
1002378c4: f85f83fd    	ldur	x29, [sp, #-0x8]
1002378c8: f84e07fe    	ldr	x30, [sp], #0xe0
1002378cc: d65f03c0    	ret
1002378d0: f90007e0    	str	x0, [sp, #0x8]
1002378d4: aa1e03e3    	mov	x3, x30
1002378d8: 97f934b2    	bl	0x100084ba0 <_runtime.morestack_noctxt.abi0>
1002378dc: f94007e0    	ldr	x0, [sp, #0x8]
1002378e0: 17ffff64    	b	0x100237670 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51>
		...

0000000100247c80 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1>:
100247c80: f9400b90    	ldr	x16, [x28, #0x10]
100247c84: d28f9a1b    	mov	x27, #0x7cd0            ; =31952
100247c88: eb3b63f1    	subs	x17, sp, x27
100247c8c: 54004723    	b.lo	0x100248570 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x8f0>
100247c90: eb10023f    	cmp	x17, x16
100247c94: 540046e9    	b.ls	0x100248570 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x8f0>
100247c98: d28faa1b    	mov	x27, #0x7d50            ; =32080
100247c9c: cb3b63f4    	sub	x20, sp, x27
100247ca0: a93ffa9d    	stp	x29, x30, [x20, #-0x8]
100247ca4: 9100029f    	mov	sp, x20
100247ca8: d10023fd    	sub	x29, sp, #0x8
100247cac: f93eafe0    	str	x0, [sp, #0x7d58]
100247cb0: f9400743    	ldr	x3, [x26, #0x8]
100247cb4: f9400f44    	ldr	x4, [x26, #0x18]
100247cb8: f93ea3e4    	str	x4, [sp, #0x7d40]
100247cbc: 39404345    	ldrb	w5, [x26, #0x10]
100247cc0: 390143e5    	strb	w5, [sp, #0x50]
100247cc4: 9101fbe6    	add	x6, sp, #0x7e
100247cc8: b27e07e7    	orr	x7, xzr, #0xc
100247ccc: a8817cdf    	stp	xzr, xzr, [x6], #0x10
100247cd0: a8817cdf    	stp	xzr, xzr, [x6], #0x10
100247cd4: a8817cdf    	stp	xzr, xzr, [x6], #0x10
100247cd8: a8817cdf    	stp	xzr, xzr, [x6], #0x10
100247cdc: d10004e7    	sub	x7, x7, #0x1
100247ce0: b5ffff67    	cbnz	x7, 0x100247ccc <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4c>
100247ce4: a9007cdf    	stp	xzr, xzr, [x6]
100247ce8: a9017cdf    	stp	xzr, xzr, [x6, #0x10]
100247cec: a9027cdf    	stp	xzr, xzr, [x6, #0x20]
100247cf0: f90018df    	str	xzr, [x6, #0x30]
100247cf4: f80320df    	stur	xzr, [x6, #0x32]
100247cf8: a9401c66    	ldp	x6, x7, [x3]
100247cfc: f10010ff    	cmp	x7, #0x4
100247d00: 540000c1    	b.ne	0x100247d18 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x98>
100247d04: b94000c6    	ldr	w6, [x6]
100247d08: d28caf47    	mov	x7, #0x657a             ; =25978
100247d0c: f2adee47    	movk	x7, #0x6f72, lsl #16
100247d10: 6b0700df    	cmp	w6, w7
100247d14: 54000060    	b.eq	0x100247d20 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0xa0>
100247d18: aa1f03e1    	mov	x1, xzr
100247d1c: 140001eb    	b	0x1002484c8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x848>
100247d20: f80633ff    	stur	xzr, [sp, #0x63]
100247d24: 3901afff    	strb	wzr, [sp, #0x6b]
100247d28: b24003e3    	orr	x3, xzr, #0x1
100247d2c: 39018fe3    	strb	w3, [sp, #0x63]
100247d30: 390197e3    	strb	w3, [sp, #0x65]
100247d34: 39019fe3    	strb	w3, [sp, #0x67]
100247d38: d2802023    	mov	x3, #0x101              ; =257
100247d3c: 7900d7e3    	strh	w3, [sp, #0x6a]
100247d40: f805a3ff    	stur	xzr, [sp, #0x5a]
100247d44: 39018bff    	strb	wzr, [sp, #0x62]
100247d48: 910ee3e3    	add	x3, sp, #0x3b8
100247d4c: d2801204    	mov	x4, #0x90               ; =144
100247d50: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247d54: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247d58: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247d5c: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247d60: d1000484    	sub	x4, x4, #0x1
100247d64: b5ffff64    	cbnz	x4, 0x100247d50 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0xd0>
100247d68: 91400be3    	add	x3, sp, #0x2, lsl #12   ; =0x2000
100247d6c: 911f0063    	add	x3, x3, #0x7c0
100247d70: d2801204    	mov	x4, #0x90               ; =144
100247d74: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247d78: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247d7c: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247d80: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247d84: d1000484    	sub	x4, x4, #0x1
100247d88: b5ffff64    	cbnz	x4, 0x100247d74 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0xf4>
100247d8c: f84633e3    	ldur	x3, [sp, #0x63]
100247d90: 3941afe4    	ldrb	w4, [sp, #0x6b]
100247d94: f80513e3    	stur	x3, [sp, #0x51]
100247d98: 390167e4    	strb	w4, [sp, #0x59]
100247d9c: f845a3e3    	ldur	x3, [sp, #0x5a]
100247da0: 39418be4    	ldrb	w4, [sp, #0x62]
100247da4: f80473e3    	stur	x3, [sp, #0x47]
100247da8: 39013fe4    	strb	w4, [sp, #0x4f]
100247dac: f84633e3    	ldur	x3, [sp, #0x63]
100247db0: 3941afe4    	ldrb	w4, [sp, #0x6b]
100247db4: f80753e3    	stur	x3, [sp, #0x75]
100247db8: 3901f7e4    	strb	w4, [sp, #0x7d]
100247dbc: f845a3e3    	ldur	x3, [sp, #0x5a]
100247dc0: 39418be4    	ldrb	w4, [sp, #0x62]
100247dc4: f806c3e3    	stur	x3, [sp, #0x6c]
100247dc8: 3901d3e4    	strb	w4, [sp, #0x74]
100247dcc: 90001500    	adrp	x0, 0x1004e7000 <_type:*+0x3a188>
100247dd0: 912ac000    	add	x0, x0, #0xab0
100247dd4: aa1f03e1    	mov	x1, xzr
100247dd8: b27907e2    	orr	x2, xzr, #0x180
100247ddc: 97f8e74d    	bl	0x100081b10 <_runtime.makeslice>
100247de0: f93e9fe0    	str	x0, [sp, #0x7d38]
100247de4: 90001500    	adrp	x0, 0x1004e7000 <_type:*+0x3a188>
100247de8: 912ac000    	add	x0, x0, #0xab0
100247dec: aa1f03e1    	mov	x1, xzr
100247df0: b27907e2    	orr	x2, xzr, #0x180
100247df4: 97f8e747    	bl	0x100081b10 <_runtime.makeslice>
100247df8: 91401be3    	add	x3, sp, #0x6, lsl #12   ; =0x6000
100247dfc: 9133a063    	add	x3, x3, #0xce8
100247e00: d2800824    	mov	x4, #0x41               ; =65
100247e04: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247e08: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247e0c: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247e10: a8817c7f    	stp	xzr, xzr, [x3], #0x10
100247e14: d1000484    	sub	x4, x4, #0x1
100247e18: b5ffff64    	cbnz	x4, 0x100247e04 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x184>
100247e1c: f93677e0    	str	x0, [sp, #0x6ce8]
100247e20: b27907e3    	orr	x3, xzr, #0x180
100247e24: f9367fe3    	str	x3, [sp, #0x6cf8]
100247e28: 914013e4    	add	x4, sp, #0x4, lsl #12   ; =0x4000
100247e2c: 91314084    	add	x4, x4, #0xc50
100247e30: d2800825    	mov	x5, #0x41               ; =65
100247e34: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100247e38: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100247e3c: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100247e40: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100247e44: d10004a5    	sub	x5, x5, #0x1
100247e48: b5ffff65    	cbnz	x5, 0x100247e34 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x1b4>
100247e4c: f97e9fe4    	ldr	x4, [sp, #0x7d38]
100247e50: f9262be4    	str	x4, [sp, #0x4c50]
100247e54: f92633e3    	str	x3, [sp, #0x4c60]
100247e58: 914017e3    	add	x3, sp, #0x5, lsl #12   ; =0x5000
100247e5c: 91324063    	add	x3, x3, #0xc90
100247e60: 91401be4    	add	x4, sp, #0x6, lsl #12   ; =0x6000
100247e64: 9133a084    	add	x4, x4, #0xce8
100247e68: d2800838    	mov	x24, #0x41              ; =65
100247e6c: acc14490    	ldp	q16, q17, [x4], #0x20
100247e70: ac814470    	stp	q16, q17, [x3], #0x20
100247e74: acc14490    	ldp	q16, q17, [x4], #0x20
100247e78: ac814470    	stp	q16, q17, [x3], #0x20
100247e7c: d1000718    	sub	x24, x24, #0x1
100247e80: b5ffff78    	cbnz	x24, 0x100247e6c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x1ec>
100247e84: f97ea3e3    	ldr	x3, [sp, #0x7d40]
100247e88: 39400060    	ldrb	w0, [x3]
100247e8c: 394143e3    	ldrb	w3, [sp, #0x50]
100247e90: 7200007f    	tst	w3, #0x1
100247e94: 914013e3    	add	x3, sp, #0x4, lsl #12   ; =0x4000
100247e98: 91314063    	add	x3, x3, #0xc50
100247e9c: 9a9f1065    	csel	x5, x3, xzr, ne
100247ea0: 910147e1    	add	x1, sp, #0x51
100247ea4: 91011fe2    	add	x2, sp, #0x47
100247ea8: 9101fbe3    	add	x3, sp, #0x7e
100247eac: 910ee3e4    	add	x4, sp, #0x3b8
100247eb0: 97ffbe90    	bl	0x1002378f0 <_github.com/thesyncim/govpx/internal/vp8/encoder.tokenCountFrozenMacro51>
100247eb4: 394143e3    	ldrb	w3, [sp, #0x50]
100247eb8: 7200007f    	tst	w3, #0x1
100247ebc: b4000240    	cbz	x0, 0x100247f04 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x284>
100247ec0: 9134a3fb    	add	x27, sp, #0xd28
100247ec4: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
100247ec8: a9007f7f    	stp	xzr, xzr, [x27]
100247ecc: b4000040    	cbz	x0, 0x100247ed4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x254>
100247ed0: f9400400    	ldr	x0, [x0, #0x8]
100247ed4: 9134a3fb    	add	x27, sp, #0xd28
100247ed8: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
100247edc: a9000760    	stp	x0, x1, [x27]
100247ee0: f97eafe0    	ldr	x0, [sp, #0x7d58]
100247ee4: 3980001b    	ldrsb	x27, [x0]
100247ee8: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
100247eec: 9134a021    	add	x1, x1, #0xd28
100247ef0: b24003e2    	orr	x2, xzr, #0x1
100247ef4: aa0203e3    	mov	x3, x2
100247ef8: 97fac62a    	bl	0x1000f97a0 <_testing.(*common).Fatal>
100247efc: 394143e4    	ldrb	w4, [sp, #0x50]
100247f00: 7200009f    	tst	w4, #0x1
100247f04: 914017e6    	add	x6, sp, #0x5, lsl #12   ; =0x5000
100247f08: 913240c6    	add	x6, x6, #0xc90
100247f0c: 9a9f10c5    	csel	x5, x6, xzr, ne
100247f10: f9366be5    	str	x5, [sp, #0x6cd0]
100247f14: f97ea3e6    	ldr	x6, [sp, #0x7d40]
100247f18: 394000c0    	ldrb	w0, [x6]
100247f1c: 9101d7e1    	add	x1, sp, #0x75
100247f20: 9101b3e2    	add	x2, sp, #0x6c
100247f24: 9101fbe3    	add	x3, sp, #0x7e
100247f28: 91400be4    	add	x4, sp, #0x2, lsl #12   ; =0x2000
100247f2c: 911f0084    	add	x4, x4, #0x7c0
100247f30: 97feb860    	bl	0x1001f60b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords>
100247f34: b4000200    	cbz	x0, 0x100247f74 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x2f4>
100247f38: 9134a3fb    	add	x27, sp, #0xd28
100247f3c: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
100247f40: a9007f7f    	stp	xzr, xzr, [x27]
100247f44: b4000040    	cbz	x0, 0x100247f4c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x2cc>
100247f48: f9400400    	ldr	x0, [x0, #0x8]
100247f4c: 9134a3fb    	add	x27, sp, #0xd28
100247f50: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
100247f54: a9000760    	stp	x0, x1, [x27]
100247f58: f97eafe0    	ldr	x0, [sp, #0x7d58]
100247f5c: 3980001b    	ldrsb	x27, [x0]
100247f60: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
100247f64: 9134a021    	add	x1, x1, #0xd28
100247f68: b24003e2    	orr	x2, xzr, #0x1
100247f6c: aa0203e3    	mov	x3, x2
100247f70: 97fac60c    	bl	0x1000f97a0 <_testing.(*common).Fatal>
100247f74: b84753e4    	ldur	w4, [sp, #0x75]
100247f78: b84513e5    	ldur	w5, [sp, #0x51]
100247f7c: d503201f    	nop
100247f80: 6b0400bf    	cmp	w5, w4
100247f84: 540007c1    	b.ne	0x10024807c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3fc>
100247f88: 784793e4    	ldurh	w4, [sp, #0x79]
100247f8c: 784553e5    	ldurh	w5, [sp, #0x55]
100247f90: 6b05009f    	cmp	w4, w5
100247f94: 54000701    	b.ne	0x100248074 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3f4>
100247f98: 7847b3e4    	ldurh	w4, [sp, #0x7b]
100247f9c: 784573e5    	ldurh	w5, [sp, #0x57]
100247fa0: 6b05009f    	cmp	w4, w5
100247fa4: 54000641    	b.ne	0x10024806c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3ec>
100247fa8: 394167e4    	ldrb	w4, [sp, #0x59]
100247fac: 3941f7e5    	ldrb	w5, [sp, #0x7d]
100247fb0: 6b0400bf    	cmp	w5, w4
100247fb4: 54000581    	b.ne	0x100248064 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3e4>
100247fb8: b9406fe4    	ldr	w4, [sp, #0x6c]
100247fbc: b84473e5    	ldur	w5, [sp, #0x47]
100247fc0: 6b0400bf    	cmp	w5, w4
100247fc4: 540004c1    	b.ne	0x10024805c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3dc>
100247fc8: 7940e3e4    	ldrh	w4, [sp, #0x70]
100247fcc: 7844b3e5    	ldurh	w5, [sp, #0x4b]
100247fd0: 6b0400bf    	cmp	w5, w4
100247fd4: 54000401    	b.ne	0x100248054 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3d4>
100247fd8: 7940e7e4    	ldrh	w4, [sp, #0x72]
100247fdc: 7844d3e5    	ldurh	w5, [sp, #0x4d]
100247fe0: 6b0400bf    	cmp	w5, w4
100247fe4: 54000341    	b.ne	0x10024804c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x3cc>
100247fe8: 39413fe4    	ldrb	w4, [sp, #0x4f]
100247fec: 3941d3e5    	ldrb	w5, [sp, #0x74]
100247ff0: 6b05009f    	cmp	w4, w5
100247ff4: 54000060    	b.eq	0x100248000 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x380>
100247ff8: b24003e3    	orr	x3, xzr, #0x1
100247ffc: 14000021    	b	0x100248080 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
100248000: 913143fb    	add	x27, sp, #0xc50
100248004: 9140137b    	add	x27, x27, #0x4, lsl #12 ; =0x4000
100248008: a9400760    	ldp	x0, x1, [x27]
10024800c: f96633e2    	ldr	x2, [sp, #0x4c60]
100248010: 97f8d6d8    	bl	0x10007db70 <_runtime.convTslice>
100248014: f93e9fe0    	str	x0, [sp, #0x7d38]
100248018: 913243fb    	add	x27, sp, #0xc90
10024801c: 9140177b    	add	x27, x27, #0x5, lsl #12 ; =0x5000
100248020: a9400760    	ldp	x0, x1, [x27]
100248024: f96e53e2    	ldr	x2, [sp, #0x5ca0]
100248028: 97f8d6d2    	bl	0x10007db70 <_runtime.convTslice>
10024802c: f97e9fe1    	ldr	x1, [sp, #0x7d38]
100248030: 90001422    	adrp	x2, 0x1004cc000 <_type:*+0x1f188>
100248034: 91108042    	add	x2, x2, #0x420
100248038: aa0003e3    	mov	x3, x0
10024803c: aa0203e0    	mov	x0, x2
100248040: 97f9d7a8    	bl	0x1000bdee0 <_reflect.DeepEqual>
100248044: d2400003    	eor	x3, x0, #0x1
100248048: 1400000e    	b	0x100248080 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
10024804c: b24003e3    	orr	x3, xzr, #0x1
100248050: 1400000c    	b	0x100248080 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
100248054: b24003e3    	orr	x3, xzr, #0x1
100248058: 1400000a    	b	0x100248080 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
10024805c: b24003e3    	orr	x3, xzr, #0x1
100248060: 14000008    	b	0x100248080 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
100248064: b24003e3    	orr	x3, xzr, #0x1
100248068: 14000006    	b	0x100248080 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
10024806c: b24003e3    	orr	x3, xzr, #0x1
100248070: 14000004    	b	0x100248080 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
100248074: b24003e3    	orr	x3, xzr, #0x1
100248078: 14000002    	b	0x100248080 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x400>
10024807c: b24003e3    	orr	x3, xzr, #0x1
100248080: 360001e3    	tbz	w3, #0x0, 0x1002480bc <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x43c>
100248084: f00014e4    	adrp	x4, 0x1004e7000 <_type:*+0x3a188>
100248088: 912bc084    	add	x4, x4, #0xaf0
10024808c: 900012e5    	adrp	x5, 0x1004a4000 <_cmp..dict.isNaN[string]>
100248090: 9119c0a5    	add	x5, x5, #0x670
100248094: 9134a3fb    	add	x27, sp, #0xd28
100248098: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
10024809c: a9001764    	stp	x4, x5, [x27]
1002480a0: f97eafe0    	ldr	x0, [sp, #0x7d58]
1002480a4: 3980001b    	ldrsb	x27, [x0]
1002480a8: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
1002480ac: 9134a021    	add	x1, x1, #0xd28
1002480b0: b24003e2    	orr	x2, xzr, #0x1
1002480b4: aa0203e3    	mov	x3, x2
1002480b8: 97fac5ba    	bl	0x1000f97a0 <_testing.(*common).Fatal>
1002480bc: 910ee3e0    	add	x0, sp, #0x3b8
1002480c0: 91400be1    	add	x1, sp, #0x2, lsl #12   ; =0x2000
1002480c4: 911f0021    	add	x1, x1, #0x7c0
1002480c8: d2848002    	mov	x2, #0x2400             ; =9216
1002480cc: 97f6e6d9    	bl	0x100001c30 <_runtime.memequal>
1002480d0: 370001e0    	tbnz	w0, #0x0, 0x10024810c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x48c>
1002480d4: f00014e4    	adrp	x4, 0x1004e7000 <_type:*+0x3a188>
1002480d8: 912bc084    	add	x4, x4, #0xaf0
1002480dc: 900012e5    	adrp	x5, 0x1004a4000 <_cmp..dict.isNaN[string]>
1002480e0: 911a00a5    	add	x5, x5, #0x680
1002480e4: 9134a3fb    	add	x27, sp, #0xd28
1002480e8: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
1002480ec: a9001764    	stp	x4, x5, [x27]
1002480f0: f97eafe0    	ldr	x0, [sp, #0x7d58]
1002480f4: 3980001b    	ldrsb	x27, [x0]
1002480f8: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
1002480fc: 9134a021    	add	x1, x1, #0xd28
100248100: b24003e2    	orr	x2, xzr, #0x1
100248104: aa0203e3    	mov	x3, x2
100248108: 97fac5a6    	bl	0x1000f97a0 <_testing.(*common).Fatal>
10024810c: 91400be4    	add	x4, sp, #0x2, lsl #12   ; =0x2000
100248110: 911f0084    	add	x4, x4, #0x7c0
100248114: d2801206    	mov	x6, #0x90               ; =144
100248118: a8817c9f    	stp	xzr, xzr, [x4], #0x10
10024811c: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100248120: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100248124: a8817c9f    	stp	xzr, xzr, [x4], #0x10
100248128: d10004c6    	sub	x6, x6, #0x1
10024812c: b5ffff66    	cbnz	x6, 0x100248118 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x498>
100248130: f92e4fff    	str	xzr, [sp, #0x5c98]
100248134: f97eafe6    	ldr	x6, [sp, #0x7d58]
100248138: b24003e7    	orr	x7, xzr, #0x1
10024813c: 390948c7    	strb	w7, [x6, #0x252]
100248140: f97eafe0    	ldr	x0, [sp, #0x7d58]
100248144: 910ae01b    	add	x27, x0, #0x2b8
100248148: a9401f66    	ldp	x6, x7, [x27]
10024814c: eb0700df    	cmp	x6, x7
100248150: 540000a9    	b.ls	0x100248164 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4e4>
100248154: 910004e6    	add	x6, x7, #0x1
100248158: f9016006    	str	x6, [x0, #0x2c0]
10024815c: b24003e0    	orr	x0, xzr, #0x1
100248160: 14000002    	b	0x100248168 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4e8>
100248164: 97fa9f83    	bl	0x1000eff70 <_testing.(*B).loopSlowPath>
100248168: 36000540    	tbz	w0, #0x0, 0x100248210 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x590>
10024816c: f84633e6    	ldur	x6, [sp, #0x63]
100248170: 3941afe7    	ldrb	w7, [sp, #0x6b]
100248174: f80753e6    	stur	x6, [sp, #0x75]
100248178: 3901f7e7    	strb	w7, [sp, #0x7d]
10024817c: f845a3e6    	ldur	x6, [sp, #0x5a]
100248180: 39418be7    	ldrb	w7, [sp, #0x62]
100248184: f806c3e6    	stur	x6, [sp, #0x6c]
100248188: 3901d3e7    	strb	w7, [sp, #0x74]
10024818c: f92e4fff    	str	xzr, [sp, #0x5c98]
100248190: f97ea3e6    	ldr	x6, [sp, #0x7d40]
100248194: 394000c0    	ldrb	w0, [x6]
100248198: 9101d7e1    	add	x1, sp, #0x75
10024819c: 9101b3e2    	add	x2, sp, #0x6c
1002481a0: 9101fbe3    	add	x3, sp, #0x7e
1002481a4: 91400be4    	add	x4, sp, #0x2, lsl #12   ; =0x2000
1002481a8: 911f0084    	add	x4, x4, #0x7c0
1002481ac: f9766be5    	ldr	x5, [sp, #0x6cd0]
1002481b0: 97feb7c0    	bl	0x1001f60b0 <_github.com/thesyncim/govpx/internal/vp8/encoder.countCoefficientMacroblockTokensAndRecords>
1002481b4: 913363fb    	add	x27, sp, #0xcd8
1002481b8: 91401b7b    	add	x27, x27, #0x6, lsl #12 ; =0x6000
1002481bc: a9000760    	stp	x0, x1, [x27]
1002481c0: b4fffc00    	cbz	x0, 0x100248140 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4c0>
1002481c4: 9134a3fb    	add	x27, sp, #0xd28
1002481c8: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
1002481cc: a9007f7f    	stp	xzr, xzr, [x27]
1002481d0: 913363fb    	add	x27, sp, #0xcd8
1002481d4: 91401b7b    	add	x27, x27, #0x6, lsl #12 ; =0x6000
1002481d8: a9401764    	ldp	x4, x5, [x27]
1002481dc: b4000044    	cbz	x4, 0x1002481e4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x564>
1002481e0: f9400484    	ldr	x4, [x4, #0x8]
1002481e4: 9134a3fb    	add	x27, sp, #0xd28
1002481e8: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
1002481ec: a9001764    	stp	x4, x5, [x27]
1002481f0: f97eafe0    	ldr	x0, [sp, #0x7d58]
1002481f4: 3980001b    	ldrsb	x27, [x0]
1002481f8: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
1002481fc: 9134a021    	add	x1, x1, #0xd28
100248200: b24003e2    	orr	x2, xzr, #0x1
100248204: aa0203e3    	mov	x3, x2
100248208: 97fac566    	bl	0x1000f97a0 <_testing.(*common).Fatal>
10024820c: 17ffffcd    	b	0x100248140 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x4c0>
100248210: aa1f03e4    	mov	x4, xzr
100248214: 14000002    	b	0x10024821c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x59c>
100248218: 91000484    	add	x4, x4, #0x1
10024821c: f100109f    	cmp	x4, #0x4
100248220: 540009ca    	b.ge	0x100248358 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x6d8>
100248224: f925e7e4    	str	x4, [sp, #0x4bc8]
100248228: aa1f03e5    	mov	x5, xzr
10024822c: 14000002    	b	0x100248234 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x5b4>
100248230: 910004a5    	add	x5, x5, #0x1
100248234: f10020bf    	cmp	x5, #0x8
100248238: 54ffff0a    	b.ge	0x100248218 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x598>
10024823c: f925ebe5    	str	x5, [sp, #0x4bd0]
100248240: aa1f03e6    	mov	x6, xzr
100248244: 14000002    	b	0x10024824c <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x5cc>
100248248: 910004c6    	add	x6, x6, #0x1
10024824c: f1000cdf    	cmp	x6, #0x3
100248250: 54ffff0a    	b.ge	0x100248230 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x5b0>
100248254: f925e3e6    	str	x6, [sp, #0x4bc0]
100248258: d378dc87    	lsl	x7, x4, #8
10024825c: 8b070ce7    	add	x7, x7, x7, lsl #3
100248260: f92627e7    	str	x7, [sp, #0x4c48]
100248264: 910ee3e8    	add	x8, sp, #0x3b8
100248268: 8b070109    	add	x9, x8, x7
10024826c: d37be8aa    	lsl	x10, x5, #5
100248270: 8b0a0d4a    	add	x10, x10, x10, lsl #3
100248274: f92623ea    	str	x10, [sp, #0x4c40]
100248278: 8b0a0129    	add	x9, x9, x10
10024827c: d37be8cb    	lsl	x11, x6, #5
100248280: 8b0b056b    	add	x11, x11, x11, lsl #1
100248284: f9261feb    	str	x11, [sp, #0x4c38]
100248288: 8b0b0129    	add	x9, x9, x11
10024828c: 914013ec    	add	x12, sp, #0x4, lsl #12  ; =0x4000
100248290: 912f618c    	add	x12, x12, #0xbd8
100248294: ad404530    	ldp	q16, q17, [x9]
100248298: ad004590    	stp	q16, q17, [x12]
10024829c: ad414530    	ldp	q16, q17, [x9, #0x20]
1002482a0: ad014590    	stp	q16, q17, [x12, #0x20]
1002482a4: ad424530    	ldp	q16, q17, [x9, #0x40]
1002482a8: ad024590    	stp	q16, q17, [x12, #0x40]
1002482ac: aa1f03e9    	mov	x9, xzr
1002482b0: 14000002    	b	0x1002482b8 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x638>
1002482b4: 91000529    	add	x9, x9, #0x1
1002482b8: f100313f    	cmp	x9, #0xc
1002482bc: 54fffc6a    	b.ge	0x100248248 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x5c8>
1002482c0: f869798d    	ldr	x13, [x12, x9, lsl #3]
1002482c4: 91400bee    	add	x14, sp, #0x2, lsl #12  ; =0x2000
1002482c8: 911f01ce    	add	x14, x14, #0x7c0
1002482cc: 8b0701cf    	add	x15, x14, x7
1002482d0: 8b0a01ef    	add	x15, x15, x10
1002482d4: 8b0b01ef    	add	x15, x15, x11
1002482d8: f86979ef    	ldr	x15, [x15, x9, lsl #3]
1002482dc: f97eafe0    	ldr	x0, [sp, #0x7d58]
1002482e0: f9410810    	ldr	x16, [x0, #0x210]
1002482e4: 9b107dad    	mul	x13, x13, x16
1002482e8: eb0d01ff    	cmp	x15, x13
1002482ec: 54fffe40    	b.eq	0x1002482b4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x634>
1002482f0: f913dfe9    	str	x9, [sp, #0x27b8]
1002482f4: f00014e4    	adrp	x4, 0x1004e7000 <_type:*+0x3a188>
1002482f8: 912bc084    	add	x4, x4, #0xaf0
1002482fc: 900012e5    	adrp	x5, 0x1004a4000 <_cmp..dict.isNaN[string]>
100248300: 911a40a5    	add	x5, x5, #0x690
100248304: 9134a3fb    	add	x27, sp, #0xd28
100248308: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
10024830c: a9001764    	stp	x4, x5, [x27]
100248310: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
100248314: 9134a021    	add	x1, x1, #0xd28
100248318: b24003e2    	orr	x2, xzr, #0x1
10024831c: aa0203e3    	mov	x3, x2
100248320: 97fac520    	bl	0x1000f97a0 <_testing.(*common).Fatal>
100248324: f965e7e4    	ldr	x4, [sp, #0x4bc8]
100248328: f965ebe5    	ldr	x5, [sp, #0x4bd0]
10024832c: f965e3e6    	ldr	x6, [sp, #0x4bc0]
100248330: f96627e7    	ldr	x7, [sp, #0x4c48]
100248334: 910ee3e8    	add	x8, sp, #0x3b8
100248338: f953dfe9    	ldr	x9, [sp, #0x27b8]
10024833c: f96623ea    	ldr	x10, [sp, #0x4c40]
100248340: f9661feb    	ldr	x11, [sp, #0x4c38]
100248344: 914013ec    	add	x12, sp, #0x4, lsl #12  ; =0x4000
100248348: 912f618c    	add	x12, x12, #0xbd8
10024834c: 91400bee    	add	x14, sp, #0x2, lsl #12  ; =0x2000
100248350: 911f01ce    	add	x14, x14, #0x7c0
100248354: 17ffffd8    	b	0x1002482b4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x634>
100248358: b84753e4    	ldur	w4, [sp, #0x75]
10024835c: b84513e5    	ldur	w5, [sp, #0x51]
100248360: d503201f    	nop
100248364: 6b0400bf    	cmp	w5, w4
100248368: 540007c1    	b.ne	0x100248460 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e0>
10024836c: 784793e4    	ldurh	w4, [sp, #0x79]
100248370: 784553e5    	ldurh	w5, [sp, #0x55]
100248374: 6b0400bf    	cmp	w5, w4
100248378: 54000701    	b.ne	0x100248458 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7d8>
10024837c: 7847b3e4    	ldurh	w4, [sp, #0x7b]
100248380: 784573e5    	ldurh	w5, [sp, #0x57]
100248384: 6b0400bf    	cmp	w5, w4
100248388: 54000641    	b.ne	0x100248450 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7d0>
10024838c: 394167e4    	ldrb	w4, [sp, #0x59]
100248390: 3941f7e5    	ldrb	w5, [sp, #0x7d]
100248394: 6b0400bf    	cmp	w5, w4
100248398: 54000581    	b.ne	0x100248448 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7c8>
10024839c: b84473e4    	ldur	w4, [sp, #0x47]
1002483a0: b9406fe5    	ldr	w5, [sp, #0x6c]
1002483a4: 6b0400bf    	cmp	w5, w4
1002483a8: 540004c1    	b.ne	0x100248440 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7c0>
1002483ac: 7940e3e4    	ldrh	w4, [sp, #0x70]
1002483b0: 7844b3e5    	ldurh	w5, [sp, #0x4b]
1002483b4: 6b0400bf    	cmp	w5, w4
1002483b8: 54000401    	b.ne	0x100248438 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7b8>
1002483bc: 7940e7e4    	ldrh	w4, [sp, #0x72]
1002483c0: 7844d3e5    	ldurh	w5, [sp, #0x4d]
1002483c4: 6b0400bf    	cmp	w5, w4
1002483c8: 54000341    	b.ne	0x100248430 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7b0>
1002483cc: 39413fe4    	ldrb	w4, [sp, #0x4f]
1002483d0: 3941d3e5    	ldrb	w5, [sp, #0x74]
1002483d4: 6b05009f    	cmp	w4, w5
1002483d8: 54000060    	b.eq	0x1002483e4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x764>
1002483dc: b24003e3    	orr	x3, xzr, #0x1
1002483e0: 14000021    	b	0x100248464 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
1002483e4: 913143fb    	add	x27, sp, #0xc50
1002483e8: 9140137b    	add	x27, x27, #0x4, lsl #12 ; =0x4000
1002483ec: a9400760    	ldp	x0, x1, [x27]
1002483f0: f96633e2    	ldr	x2, [sp, #0x4c60]
1002483f4: 97f8d5df    	bl	0x10007db70 <_runtime.convTslice>
1002483f8: f93e9fe0    	str	x0, [sp, #0x7d38]
1002483fc: 913243fb    	add	x27, sp, #0xc90
100248400: 9140177b    	add	x27, x27, #0x5, lsl #12 ; =0x5000
100248404: a9400760    	ldp	x0, x1, [x27]
100248408: f96e53e2    	ldr	x2, [sp, #0x5ca0]
10024840c: 97f8d5d9    	bl	0x10007db70 <_runtime.convTslice>
100248410: f97e9fe1    	ldr	x1, [sp, #0x7d38]
100248414: 90001422    	adrp	x2, 0x1004cc000 <_type:*+0x1f188>
100248418: 91108042    	add	x2, x2, #0x420
10024841c: aa0003e3    	mov	x3, x0
100248420: aa0203e0    	mov	x0, x2
100248424: 97f9d6af    	bl	0x1000bdee0 <_reflect.DeepEqual>
100248428: d2400003    	eor	x3, x0, #0x1
10024842c: 1400000e    	b	0x100248464 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
100248430: b24003e3    	orr	x3, xzr, #0x1
100248434: 1400000c    	b	0x100248464 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
100248438: b24003e3    	orr	x3, xzr, #0x1
10024843c: 1400000a    	b	0x100248464 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
100248440: b24003e3    	orr	x3, xzr, #0x1
100248444: 14000008    	b	0x100248464 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
100248448: b24003e3    	orr	x3, xzr, #0x1
10024844c: 14000006    	b	0x100248464 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
100248450: b24003e3    	orr	x3, xzr, #0x1
100248454: 14000004    	b	0x100248464 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
100248458: b24003e3    	orr	x3, xzr, #0x1
10024845c: 14000002    	b	0x100248464 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x7e4>
100248460: b24003e3    	orr	x3, xzr, #0x1
100248464: 360001e3    	tbz	w3, #0x0, 0x1002484a0 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x820>
100248468: f00014e4    	adrp	x4, 0x1004e7000 <_type:*+0x3a188>
10024846c: 912bc084    	add	x4, x4, #0xaf0
100248470: 900012e5    	adrp	x5, 0x1004a4000 <_cmp..dict.isNaN[string]>
100248474: 9119c0a5    	add	x5, x5, #0x670
100248478: 9134a3fb    	add	x27, sp, #0xd28
10024847c: 91401f7b    	add	x27, x27, #0x7, lsl #12 ; =0x7000
100248480: a9001764    	stp	x4, x5, [x27]
100248484: f97eafe0    	ldr	x0, [sp, #0x7d58]
100248488: 3980001b    	ldrsb	x27, [x0]
10024848c: 91401fe1    	add	x1, sp, #0x7, lsl #12   ; =0x7000
100248490: 9134a021    	add	x1, x1, #0xd28
100248494: b24003e2    	orr	x2, xzr, #0x1
100248498: aa0203e3    	mov	x3, x2
10024849c: 97fac4c1    	bl	0x1000f97a0 <_testing.(*common).Fatal>
1002484a0: f953e3e0    	ldr	x0, [sp, #0x27c0]
1002484a4: f96e4fe1    	ldr	x1, [sp, #0x5c98]
1002484a8: 8b000020    	add	x0, x1, x0
1002484ac: 9000199b    	adrp	x27, 0x100578000 <_runtime.mheap_+0x187e0>
1002484b0: f9047760    	str	x0, [x27, #0x8e8]
1002484b4: a97ffbfd    	ldp	x29, x30, [sp, #-0x8]
1002484b8: d28faa1b    	mov	x27, #0x7d50            ; =32080
1002484bc: 8b3b63ff    	add	sp, sp, x27
1002484c0: d65f03c0    	ret
1002484c4: aa0703e1    	mov	x1, x7
1002484c8: f100643f    	cmp	x1, #0x19
1002484cc: 54ffc2aa    	b.ge	0x100247d20 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0xa0>
1002484d0: 9101fbe6    	add	x6, sp, #0x7e
1002484d4: 8b0114c6    	add	x6, x6, x1, lsl #5
1002484d8: 91000427    	add	x7, x1, #0x1
1002484dc: 790000c7    	strh	w7, [x6]
1002484e0: b24003e8    	orr	x8, xzr, #0x1
1002484e4: 910e7be9    	add	x9, sp, #0x39e
1002484e8: 38216928    	strb	w8, [x9, x1]
1002484ec: a9402c6a    	ldp	x10, x11, [x3]
1002484f0: f100157f    	cmp	x11, #0x5
1002484f4: 54fffe81    	b.ne	0x1002484c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x844>
1002484f8: b940014b    	ldr	w11, [x10]
1002484fc: d28cac8c    	mov	x12, #0x6564            ; =25956
100248500: f2ae6dcc    	movk	x12, #0x736e, lsl #16
100248504: 6b0c017f    	cmp	w11, w12
100248508: 54fffde1    	b.ne	0x1002484c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x844>
10024850c: 3940114a    	ldrb	w10, [x10, #0x4]
100248510: 7101955f    	cmp	w10, #0x65
100248514: 54fffd81    	b.ne	0x1002484c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x844>
100248518: b27c03ea    	orr	x10, xzr, #0x10
10024851c: 3821692a    	strb	w10, [x9, x1]
100248520: d37be829    	lsl	x9, x1, #5
100248524: cb010129    	sub	x9, x9, x1
100248528: aa1f03e1    	mov	x1, xzr
10024852c: 1400000e    	b	0x100248564 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x8e4>
100248530: d28001ab    	mov	x11, #0xd               ; =13
100248534: 9b0b242c    	madd	x12, x1, x11, x9
100248538: d290412d    	mov	x13, #0x8209            ; =33289
10024853c: f2a1040d    	movk	x13, #0x820, lsl #16
100248540: f2c4104d    	movk	x13, #0x2082, lsl #32
100248544: f2f0410d    	movk	x13, #0x8208, lsl #48
100248548: 9bcd7d8e    	umulh	x14, x12, x13
10024854c: 8b4e158c    	add	x12, x12, x14, lsr #5
100248550: d345fdce    	lsr	x14, x14, #5
100248554: cb0e198c    	sub	x12, x12, x14, lsl #6
100248558: d1007d8c    	sub	x12, x12, #0x1f
10024855c: 782178cc    	strh	w12, [x6, x1, lsl #1]
100248560: 91000421    	add	x1, x1, #0x1
100248564: f100403f    	cmp	x1, #0x10
100248568: 54fffe4b    	b.lt	0x100248530 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x8b0>
10024856c: 17ffffd6    	b	0x1002484c4 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1+0x844>
100248570: f90007e0    	str	x0, [sp, #0x8]
100248574: aa1e03e3    	mov	x3, x30
100248578: 97f8f16a    	bl	0x100084b20 <_runtime.morestack.abi0>
10024857c: f94007e0    	ldr	x0, [sp, #0x8]
100248580: 17fffdc0    	b	0x100247c80 <_github.com/thesyncim/govpx/internal/vp8/encoder.BenchmarkTokenCountMacro51.func1>
		...

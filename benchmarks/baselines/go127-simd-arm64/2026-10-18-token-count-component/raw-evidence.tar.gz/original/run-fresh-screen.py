from pathlib import Path
import datetime,hashlib,json,os,platform,re,subprocess
p=Path('/private/tmp/govpx-next-token-count51');out=p/'fresh-screen';out.mkdir();assert platform.machine()=='arm64'
bind=json.loads((p/'fresh-binding.json').read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for v,x in bind['variants'].items():
 for rel,h in x['all_go_sha256'].items():assert sha(Path(x['source'])/rel)==h,(v,rel)
 for k,b in x['binaries'].items():assert sha(Path(b['path']))==b['sha256'],(v,k)
orders=[['parent','candidate'],['candidate','parent']]*3
env=os.environ.copy();env.update(GOMAXPROCS='1',GOVPX_REQUIRE_SIMD='1');now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();records=[]
print('FRESH '+bind['scope']+' START',now(),flush=True)
for rnd,order in enumerate(orders,1):
 for v in order:
  for kind,(pattern,count) in bind['types'].items():
   cmd=[bind['variants'][v]['binaries'][kind]['path'],'-test.run','^$','-test.bench',pattern,'-test.benchtime=75ms','-test.count=1','-test.cpu=1','-test.benchmem'];rec={'round':rnd,'variant':v,'kind':kind,'command':cmd,'start_utc':now()};raw=out/f'r{rnd}-{v}-{kind}.txt';err=out/f'r{rnd}-{v}-{kind}.stderr'
   with raw.open('w')as f,err.open('w')as e:r=subprocess.run(cmd,env=env,stdout=f,stderr=e)
   rec.update(end_utc=now(),exit_code=r.returncode);records.append(rec);(out/'commands.json').write_text(json.dumps({'orders':orders,'binding_sha256':sha(p/'fresh-binding.json'),'measurements':records},indent=2)+'\n');assert r.returncode==0 and not err.read_text(),rec
   text=raw.read_text();rows=re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op$',text,re.M);assert len(rows)==count and all(b==a=='0'for n,ns,b,a in rows);assert re.search(r'^PASS$',text,re.M)
 print('FRESH '+bind['scope']+' round',rnd,'END PASS',flush=True)
print('FRESH '+bind['scope']+' END',now(),'all native processes STOPPED',flush=True)

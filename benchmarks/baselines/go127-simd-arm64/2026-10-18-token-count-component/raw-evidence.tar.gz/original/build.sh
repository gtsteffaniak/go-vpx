#!/bin/sh
set -eu
export CODEX_AGENT_ID=root-token-count51 CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go GOEXPERIMENT=simd GOMAXPROCS=2 GOFLAGS=-p=2 CGO_ENABLED=1
r=/Users/thesyncim/GolandProjects/govpx
p=/private/tmp/govpx-next-token-count51
for v in parent candidate; do
 "$r/scripts/go.sh" -C "$p/$v" test -pgo=off -run '^TestTokenCount51FrozenState$' -count=1 -v ./internal/vp8/encoder > "$p/$v-frozen-state.log" 2>&1
 "$r/scripts/go.sh" -C "$p/$v" test -pgo=off -c -o "$p/$v-encoder.test" ./internal/vp8/encoder > "$p/$v-build.log" 2>&1
 "$r/scripts/go.sh" -C "$p/$v" build -pgo=off -o "$p/$v-whole-bench" ./cmd/govpx-bench > "$p/$v-cli-build.log" 2>&1
 env GOMAXPROCS=1 "$p/$v-encoder.test" -test.run '^$' -test.bench '^BenchmarkTokenCountMacro51$' -test.benchtime=1x -test.count=1 -test.cpu=1 -test.benchmem > "$p/$v-preflight.log" 2>&1
done
"$r/scripts/go.sh" -C "$p/candidate" test -pgo=off -race -gcflags=all=-d=checkptr=2 ./internal/vp8/encoder -run '^TestTokenCount51FrozenState$' -count=1 -v > "$p/candidate-race-checkptr.log" 2>&1

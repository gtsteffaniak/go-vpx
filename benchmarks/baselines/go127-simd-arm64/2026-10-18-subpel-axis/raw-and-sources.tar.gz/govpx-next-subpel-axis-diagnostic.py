import pathlib,os,subprocess,re,json,statistics
out=pathlib.Path('/private/tmp/govpx-next-subpel-axis-diagnostic');out.mkdir(exist_ok=True)
bins={v:'/private/tmp/govpx-next-subpel-axis-'+v+'.test' for v in ['parent','candidate']};bins['assembly']='/private/tmp/govpx-next-subpel-identity-assembly.test';rows={v:{} for v in bins};env=dict(os.environ,GOMAXPROCS='1')
for r,order in enumerate([['parent','assembly','candidate'],['candidate','assembly','parent']],1):
 for v in order:
  p=subprocess.run([bins[v],'-test.run=^$','-test.bench=^BenchmarkVP9SubpelPointerNative$','-test.benchtime=100ms','-test.count=1','-test.cpu=1','-test.benchmem'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (out/f'{r}-{v}.txt').write_text(p.stdout);assert p.returncode==0,p.stdout
  matches=re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op[^\n]*?\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout,re.M);assert len(matches)==40,len(matches)
  for n,ns,b,a in matches:assert b==a=='0';rows[v].setdefault(n,[]).append(float(ns))
 print('round',r,'done',flush=True)
x={n:{'samples':{v:rows[v][n] for v in bins},'speedup':statistics.median(rows['parent'][n])/statistics.median(rows['candidate'][n]),'speedup_assembly':statistics.median(rows['assembly'][n])/statistics.median(rows['candidate'][n]),'faster_parent_pairs':sum(a>b for a,b in zip(rows['parent'][n],rows['candidate'][n]))} for n in rows['parent']}
(out/'summary.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))

from pathlib import Path
import subprocess,tarfile,io
repo=Path('/Users/thesyncim/GolandProjects/govpx');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for v in ['parent','candidate']:
 root=Path('/private/tmp/govpx-next-subpel-axis-'+v);root.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','HEAD'],cwd=repo))) as t:
  t.extractall(root,members=[m for m in t.getmembers() if not m.name.startswith('benchmarks/baselines/')])
root=Path('/private/tmp/govpx-next-subpel-axis-candidate');p=root/'internal/pixel/kernels_simd.go';s=p.read_text()
marker='\n\tif w == 4 {\n\t\treturn subpelStatsKernel[[4]byte]'
addition='''
 if w%16==0 && w<=64 && h<=64 && (uint(ss)|uint(rs))>>30==0 {
  if fy==[2]int16{128,0} {
   _=src[h*ss+w];_=ref[(h-1)*rs+w-1]
   return subpelStatsAxisHorizontal16(src,ss,ref,rs,w,h,fx)
  }
  if fx==[2]int16{128,0} {
   _=src[h*ss+w];_=ref[(h-1)*rs+w-1]
   return subpelStatsAxisVertical16(src,ss,ref,rs,w,h,fy)
  }
 }
'''
assert s.count(marker)==1;s=s.replace(marker,'\n'+addition+marker);p.write_text(s)
for arch in ['amd64','arm64']:
 source='//go:build goexperiment.simd && '+arch+' && !purego\n\npackage pixel\n\nimport ("simd/archsimd";"unsafe")\n\n'
 source+='// The public dispatcher proves the complete bilinear window and bounded\n// positive geometry before these exact read-only loads.\n'
 for vertical in [False,True]:
  name='Vertical' if vertical else 'Horizontal'
  source+=f'func subpelStatsAxis{name}16(src []byte,ss int,ref []byte,rs,w,h int,f [2]int16)(int,uint32){{\n'
  source+='sp,rp:=unsafe.Pointer(unsafe.SliceData(src)),unsafe.Pointer(unsafe.SliceData(ref))\n'
  if arch=='amd64':
   source+='defer archsimd.ClearAVXUpperBits()\nf0,f1,round,ones:=archsimd.BroadcastInt16x16(f[0]),archsimd.BroadcastInt16x16(f[1]),archsimd.BroadcastInt16x16(64),archsimd.BroadcastInt16x16(1)\nvar sum,sse archsimd.Int32x8\n'
  else:
   source+='f0,f1,round:=archsimd.BroadcastInt16x8(f[0]),archsimd.BroadcastInt16x8(f[1]),archsimd.BroadcastInt16x8(64)\nvar sum,sse archsimd.Int32x4\n'
  source+='for x:=0;x<w;x+=16 {\nso,ro:=x,x\n'
  if vertical:source+='a:=archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(sp,x)))\nso+=ss\n'
  source+='for range h {\n'
  if not vertical:source+='a:=archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(sp,so)))\n'
  source+='b:=archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(sp,so'+('' if vertical else '+1')+')))\nr:=archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(rp,ro)))\n'
  if arch=='amd64':
   source+='v:=a.ExtendToUint16().BitsToInt16().Mul(f0).Add(b.ExtendToUint16().BitsToInt16().Mul(f1)).Add(round).ShiftAllRight(7)\nd:=v.Sub(r.ExtendToUint16().BitsToInt16())\nsum=sum.Add(d.DotProductPairs(ones));sse=sse.Add(d.DotProductPairs(d))\n'
  else:
   source+='v0:=filterShift7(widen8(a).Mul(f0).Add(widen8(b).Mul(f1)).Add(round))\nv1:=filterShift7(widen8(highBytes(a)).Mul(f0).Add(widen8(highBytes(b)).Mul(f1)).Add(round))\nd0,d1:=v0.Sub(widen8(r)),v1.Sub(widen8(highBytes(r)))\nsum=sum.Add(sumDiff16(d0.Add(d1)));sse=sse.Add(square8(d0)).Add(square8(d1))\n'
  if vertical:source+='a=b\n'
  source+='so+=ss;ro+=rs\n}\n}\n'
  source+=('return int(sum32(sum.GetLo().Add(sum.GetHi()))),uint32(sum32(sse.GetLo().Add(sse.GetHi())))' if arch=='amd64' else 'return int(sum32(sum)),uint32(sum32(sse))')+'\n}\n'
 (root/f'internal/pixel/subpel_axis_{arch}.go').write_text(source)
subprocess.run(['/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/gofmt','-w',str(p),str(root/'internal/pixel/subpel_axis_arm64.go'),str(root/'internal/pixel/subpel_axis_amd64.go')],check=True)
Path('/private/tmp/govpx-next-subpel-axis-base.txt').write_text(head+'\n');print(head)

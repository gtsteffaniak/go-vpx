//go:build goexperiment.simd && arm64 && !purego

package pixel

import (
	"simd/archsimd"
	"unsafe"
)

// The public dispatcher proves the complete bilinear window and bounded
// positive geometry before these exact read-only loads.
func subpelStatsAxisHorizontal16(src []byte, ss int, ref []byte, rs, w, h int, f [2]int16) (int, uint32) {
	sp, rp := unsafe.Pointer(unsafe.SliceData(src)), unsafe.Pointer(unsafe.SliceData(ref))
	f0, f1, round := archsimd.BroadcastInt16x8(f[0]), archsimd.BroadcastInt16x8(f[1]), archsimd.BroadcastInt16x8(64)
	var sum, sse archsimd.Int32x4
	for x := 0; x < w; x += 16 {
		so, ro := x, x
		for range h {
			a := archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(sp, so)))
			b := archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(sp, so+1)))
			r := archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(rp, ro)))
			v0 := filterShift7(widen8(a).Mul(f0).Add(widen8(b).Mul(f1)).Add(round))
			v1 := filterShift7(widen8(highBytes(a)).Mul(f0).Add(widen8(highBytes(b)).Mul(f1)).Add(round))
			d0, d1 := v0.Sub(widen8(r)), v1.Sub(widen8(highBytes(r)))
			sum = sum.Add(sumDiff16(d0.Add(d1)))
			sse = sse.Add(square8(d0)).Add(square8(d1))
			so += ss
			ro += rs
		}
	}
	return int(sum32(sum)), uint32(sum32(sse))
}
func subpelStatsAxisVertical16(src []byte, ss int, ref []byte, rs, w, h int, f [2]int16) (int, uint32) {
	sp, rp := unsafe.Pointer(unsafe.SliceData(src)), unsafe.Pointer(unsafe.SliceData(ref))
	f0, f1, round := archsimd.BroadcastInt16x8(f[0]), archsimd.BroadcastInt16x8(f[1]), archsimd.BroadcastInt16x8(64)
	var sum, sse archsimd.Int32x4
	for x := 0; x < w; x += 16 {
		so, ro := x, x
		a := archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(sp, x)))
		so += ss
		for range h {
			b := archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(sp, so)))
			r := archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(rp, ro)))
			v0 := filterShift7(widen8(a).Mul(f0).Add(widen8(b).Mul(f1)).Add(round))
			v1 := filterShift7(widen8(highBytes(a)).Mul(f0).Add(widen8(highBytes(b)).Mul(f1)).Add(round))
			d0, d1 := v0.Sub(widen8(r)), v1.Sub(widen8(highBytes(r)))
			sum = sum.Add(sumDiff16(d0.Add(d1)))
			sse = sse.Add(square8(d0)).Add(square8(d1))
			a = b
			so += ss
			ro += rs
		}
	}
	return int(sum32(sum)), uint32(sum32(sse))
}

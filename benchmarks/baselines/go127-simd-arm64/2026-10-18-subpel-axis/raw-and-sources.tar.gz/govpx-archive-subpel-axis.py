from pathlib import Path
import hashlib, io, json, re, tarfile

base = Path('/private/tmp')
repo = Path('/Users/thesyncim/GolandProjects/govpx')
out = base / 'govpx-subpel-axis-ready'
out.mkdir(exist_ok=True)
payload = {}
for p in base.glob('govpx-next-subpel-axis*'):
    if p.is_file() and p.suffix in ['.py', '.log', '.txt', '.json', '.go']:
        payload[p.name] = p.read_bytes()
    if p.is_dir() and (p / 'summary.json').exists():
        for q in p.iterdir():
            if q.is_file() and q.suffix in ['.json', '.txt']:
                payload[p.name + '/' + q.name] = q.read_bytes()
names = ['internal/pixel/kernels_simd.go', 'internal/pixel/subpel_axis_arm64.go', 'internal/pixel/subpel_axis_amd64.go', 'internal/pixel/subpel_axis_simd_test.go', 'internal/vp9/dsp/subpel_pointer_native_test.go', 'scripts/benchmark-amd64.sh', 'cmd/govpx-bench/benchcmd/search_routing_fixed_digest_test.go']
for variant in ['parent', 'candidate', 'mla-candidate', 'narrow-candidate', 'shift-candidate', 'unroll-candidate', 'cache-candidate', 'dispatch-candidate']:
    for name in names:
        p = base / ('govpx-next-subpel-axis-' + variant) / name
        if p.exists():
            payload['sources/' + variant + '/' + name] = p.read_bytes()
for name in names:
    if (repo / name).exists():
        payload['final-production/' + name] = (repo / name).read_bytes()
for name in ['govpx-prepare-subpel-axis.py', 'govpx-archive-subpel-axis.py', 'govpx-summarize-public.py', 'govpx-next-subpel-identity-fixed-packet-digests.log']:
    payload[name] = (base / name).read_bytes()

data = json.loads((base / 'govpx-next-subpel-axis-dispatch-confirm/summary.json').read_text())
whole = json.loads((base / 'govpx-next-subpel-axis-dispatch-public-summary.json').read_text())
assert len(data) == 40
axes = {k: v for k, v in data.items() if 'phase3-0' in k or 'phase0-5' in k}
controls = {k: v for k, v in data.items() if k not in axes}
qualified = {k: v for k, v in axes.items() if '/16x8/phase0-5/' in k}
assert len(axes) == 16 and len(qualified) == 2
assert all(v['minimum_paired_speedup'] >= 1.5 and v['faster_parent_pairs'] == 6 for v in qualified.values())
assert all(len(v['samples'][kind]) == 6 for v in data.values() for kind in ['parent', 'assembly', 'candidate'])
old = re.findall(r'PACKET_DIGEST.*', (base / 'govpx-next-subpel-identity-fixed-packet-digests.log').read_text())
new = re.findall(r'PACKET_DIGEST.*', (base / 'govpx-next-subpel-axis-dispatch-fixed-packet-digests.log').read_text())
assert len(old) == len(new) == 6 and old == new

with tarfile.open(out / 'raw-and-sources.tar.gz', 'w:gz') as t:
    for name, value in sorted(payload.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mtime = len(value), 0
        t.addfile(info, io.BytesIO(value))
(out / 'raw-sha256.json').write_text(json.dumps({k: hashlib.sha256(v).hexdigest() for k, v in sorted(payload.items())}, indent=2) + '\n')
(out / 'component-summary.json').write_text(json.dumps(data, indent=2) + '\n')
(out / 'public-summary.json').write_text(json.dumps(whole, indent=2) + '\n')
bins = ['govpx-next-subpel-axis-parent.test', 'govpx-next-subpel-identity-assembly.test', 'govpx-next-subpel-axis-unroll-candidate.test', 'govpx-next-subpel-axis-dispatch-candidate.test', 'govpx-next-subpel-axis-parent-bench', 'govpx-next-subpel-axis-dispatch-candidate-bench', 'govpx-asm-bench']
environment = {'cpu': 'Apple M4 Max', 'compiler': 'Go1.27.2 darwin/arm64 archsimd', 'pgo': 'off', 'goprocs': 1, 'parent': 'eb820478b9a995b59a266fb4d7d816acd78edbde', 'assembly': '691cd0512c4829d9ee40d483205dd223f9eb028d', 'raw_members': len(payload), 'binary_sha256': {n: hashlib.sha256((base / n).read_bytes()).hexdigest() for n in bins}, 'final_source_sha256': {n: hashlib.sha256((repo / n).read_bytes()).hexdigest() for n in names if (repo / n).exists()}, 'native_x64_performance': 'Pending successor PR native CI. Rosetta is correctness-only.'}
(out / 'environment.json').write_text(json.dumps(environment, indent=2) + '\n')
report = '''# One-axis SIMD subpixel statistics

Native Apple M4 Max, Go1.27.2 archsimd, PGO off, GOMAXPROCS1. Parent eb820478,
old assembly691cd051. This is an immediate-parent comparison, not a comparison
with the earlier PR35 source. Skip an identity bilinear stage, retaining both
original extra-row/column endpoint checks and read-only alias semantics.
The bounded dispatcher proves w/h<=64, w%16==0 and nonnegative strides<2^30.
Every pointer offset is below2^36+64 and each exact load reads16bytes.

ARM uses wrapping int16 multiply-add, separate per-tile narrow difference sums,
independent int32 squared-error sums and paired rows with an odd-row tail.
Even arbitrary int16 coefficients produce a rounded stage in[-256,255]; the
removed identity stage maps that entire range exactly to itself. Differences
are[-511,255], so each separate lane sum over64rows lies[-32704,16320]. Widen
each half before merging. Total SSE<=1,069,551,616 and |sum|<=2,093,056 fit
signedint32. AMD uses one AVX2 packet and retains deferred upper-state cleanup.
Neither input is written or retained. CPU-off and other geometry/filters keep
their original fallbacks. Phase checks precede axis setup to protect controls.

Fresh six balanced parent/assembly/current permutations,100ms per40 public
fixtures, all zero B/op/allocations. Identical B.Loop fixtures, independent
per-pixel two-rounding scalar variance/SSE checks, unaligned3/5 origins, exact
visible spans, minimal/unequal padded strides and full backing canaries.

| One-axis fixture | Parent/current time | Assembly/current time | Minimum paired parent/current |
|---|---:|---:|---:|
'''
for name, value in axes.items():
    report += f"| {name.split('Native/')[1]} | {value['speedup']:.4f}x | {value['speedup_assembly']:.4f}x | {value['minimum_paired_speedup']:.4f}x |\n"
report += f'''
The two vertical16x8 fixtures qualify independently of whole-codec results:
all12 paired samples exceed {min(v['minimum_paired_speedup'] for v in qualified.values()):.4f}x parent.
Other one-axis results and every slower control remain in the summaries/raw
logs; do not round a sub1.5 result into a qualifying gain. The24 identity/two-axis
controls range {min(v['speedup'] for v in controls.values()):.4f}–{max(v['speedup'] for v in controls.values()):.4f}x parent.
Some sizes still trail assembly; this is not a blanket assembly-parity claim.

Whole synthetic720p VP8,realtime CPU8,2500kbps,one thread, six balanced rounds:
'''
for frames, value in whole.items():
    report += f"\n* {frames}frames: {value['vs_parent_percent']:+.4f}% time versus parent ({value['faster_parent_pairs']}/6 faster), {value['vs_assembly_percent']:+.4f}% versus assembly ({value['faster_assembly_pairs']}/6 faster).\n"
report += '''
All23 non-timing fields match and every allocation sample is zero. Six fixed
speed packet/drop digests match the validated parent exactly. Preserve the
verified >=1.5x component gain even if whole-codec performance is unchanged;
the overall ARM assembly gap remains open. Shared-desktop timings and varied
assembly samples do not justify causal/additive claims across checkpoints.

Validation includes the full final native suite, dispatcher-focused tests,
ARM race/checkptr2, AMD correctness/checkptr under
Rosetta, actual AVX-off fallback, independent arithmetic/bounds/alias/dispatch
review, refreshed PGO and repository gates. New coverage includes864 wrapped
coefficient/alias/stride/shape cases,48 short-window cases and40 directed narrow
sum boundary cases including h65 fallback and w48 three-packet geometry.
All64 legal public phases and existing numeric extremes pass scalar oracles.
Selected root/prototype generated-code evidence and final source hashes remain
with the raw logs. Native x64 speed awaits the successor's exact-head CI.

The archive retains every diagnostic, all six rounds, all outliers, the earlier
qualifying unrolled checkpoint, unselected weighted-row cache/shift/multiply
variants and source/driver snapshots. The first packet-digest command matched
no tests; its warning is retained, then the explicit fixture was copied and
six real digests verified. No concurrent local builds/profiles during timing.
README files, dependencies and handwritten-assembly production policy remain
unchanged. No production cgo added.
'''
(out / 'REPORT.md').write_text(report)
print(out, len(payload))

//go:build goexperiment.simd && arm64 && !purego

package pixel

import (
	"simd/archsimd"
	"testing"
)

// The pre-gate is conservative for both HEV branches. Applying a stricter
// lane mask may only retain f or replace it by zero, so it cannot invalidate
// the proof. Keep -128 as unsigned magnitude 128.
func TestHorizontalPreGateSignedProof(t *testing.T) {
	clamp := func(v int) int { return max(-128, min(127, v)) }
	for _, kind := range []int{4, 6} {
		bound := 4
		if kind == 6 {
			bound = 3
		}
		for f := -128; f <= 127; f++ {
			for lane := range 16 {
				var values [16]int8
				values[lane] = int8(f)
				small := int(archsimd.LoadInt8x16Array(&values).Abs().ToBits().ReduceMax()) < bound
				if small != (f > -bound && f < bound) {
					t.Fatalf("kind%d f%d lane%d magnitude", kind, f, lane)
				}
				if !small {
					continue
				}
				for _, keep := range []bool{false, true} {
					full := 0
					if keep {
						full = f
					}
					for _, hev := range []bool{false, true} {
						if kind == 6 && !hev {
							for _, weight := range []int{9, 18, 27} {
								if (weight*full+63)>>7 != 0 {
									t.Fatalf("macro f%d weight%d", full, weight)
								}
							}
						} else {
							f1, f2 := clamp(full+4)>>3, clamp(full+3)>>3
							if f1 != 0 || f2 != 0 {
								t.Fatalf("kind%d f%d hev%v", kind, full, hev)
							}
							if kind == 4 && !hev && (f1+1)>>1 != 0 {
								t.Fatal("internal outer correction")
							}
						}
					}
				}
			}
		}
	}
}

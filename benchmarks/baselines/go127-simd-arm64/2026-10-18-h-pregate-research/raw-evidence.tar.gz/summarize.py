import re,json,statistics
from pathlib import Path
p=Path('/private/tmp/govpx-next-h-pregate');data={}
for r in range(1,7):
 for variant in ['parent','candidate']:
  for line in (p/f'fresh-r{r}-{variant}.log').read_text().splitlines():
   m=re.match(r'(BenchmarkVP8PickerFilterNative/\S+)\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',line)
   if m:
    name,ns,b,a=m.groups();assert int(b)==int(a)==0;data.setdefault(name,{}).setdefault(variant,[]).append(float(ns))
assert len(data)==10
for name,d in data.items():
 assert all(len(d[v])==6 for v in ['parent','candidate']);d['paired_ratios']=[a/b for a,b in zip(d['parent'],d['candidate'])];d['ratio_medians']=statistics.median(d['parent'])/statistics.median(d['candidate']);d['time_change_percent']=(1/d['ratio_medians']-1)*100
 print(name,round(d['ratio_medians'],6),[round(x,5) for x in d['paired_ratios']])
whole={v:[] for v in ['parent','candidate','old691']};excluded={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'}
records=[];ref=json.loads((p/'whole-r1-parent.json').read_text());keys=sorted(set(ref)-excluded)
assert len(keys)==22
for r in range(1,7):
 for v in whole:
  j=json.loads((p/f'whole-r{r}-{v}.json').read_text());assert set(j)==set(ref)
  differences={k:[ref[k],j[k]] for k in keys if ref[k]!=j[k]}
  assert j['allocs_per_frame']==0
  records.append(dict(round=r,variant=v,semantic_differences_vs_first_parent=differences,allocations=j['allocs_per_frame']))
  whole[v].append(j['ns_per_frame'])
comparisons={}
for baseline in ['parent','old691']:
 ds=[(b/a-1)*100 for a,b in zip(whole[baseline],whole['candidate'])]
 comparisons[baseline]={'candidate_time_change_percent_ratio_of_medians':(statistics.median(whole['candidate'])/statistics.median(whole[baseline])-1)*100,'paired_candidate_time_change_percent':ds,'faster_pairs':sum(d<0 for d in ds)}
result=dict(cpu='Apple M4 Max',toolchain='Go1.27.2 SIMD PGOoff',public=dict(rounds=6,all_allocations_zero=True,cases=data),whole=dict(rounds=6,inputs=300,variants_ns_per_frame=whole,medians_ns_per_frame={k:statistics.median(v) for k,v in whole.items()},comparisons=comparisons,semantic_field_count=len(keys),semantic_field_names=keys,all_22_semantics_match=all(not r['semantic_differences_vs_first_parent'] for r in records),all_allocations_zero=True,records=records))
(p/'final-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print('WHOLE',json.dumps(result['whole'],indent=2))

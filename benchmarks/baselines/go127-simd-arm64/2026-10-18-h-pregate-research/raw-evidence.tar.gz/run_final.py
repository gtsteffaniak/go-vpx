import hashlib,json,subprocess,os,time
from pathlib import Path
p=Path('/private/tmp/govpx-next-h-pregate');env=os.environ.copy();env['GOMAXPROCS']='1';records=[]
for binary,want in [('/private/tmp/govpx-next-copy8-rows/parent-bench','0358fba58663a99639fe1348c17311c716cb3ca6fc84477bdc94cda1d1e198ea'),('/private/tmp/govpx-next-copy8-rows/oldbuild-bench','cc7e3670376e2033a5d0a04c7fac1044b8901ad56770ef5687963b76a946a33d')]:assert hashlib.sha256(Path(binary).read_bytes()).hexdigest()==want
for round,order in enumerate([['candidate','parent'],['parent','candidate']]*3,1):
 for name in order:
  args=[str(p/(name+'-decoder.test')),'-test.run=^$','-test.bench=^BenchmarkVP8PickerFilterNative$','-test.benchtime=100ms','-test.count=1']
  start=time.time()
  with open(p/(f'fresh-r{round}-{name}.log'),'w') as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
  records.append(dict(stage='public_picker',round=round,variant=name,argv=args,start=start,end=time.time(),exit=r.returncode));assert r.returncode==0
 print('FRESH ROUND',round,flush=True)
(p/'final-commands.json').write_text(json.dumps(records,indent=2)+'\n')
print('PUBLIC COMPLETE / WHOLE START',flush=True)
perms=[['parent','candidate','old691'],['candidate','old691','parent'],['old691','parent','candidate'],['old691','candidate','parent'],['candidate','parent','old691'],['parent','old691','candidate']]
bins={'parent':'/private/tmp/govpx-next-copy8-rows/parent-bench','old691':'/private/tmp/govpx-next-copy8-rows/oldbuild-bench','candidate':str(p/'candidate-bench')}
for round,order in enumerate(perms,1):
 for name in order:
  args=[bins[name],'-codec=vp8','-width=1280','-height=720','-frames=300','-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8','-threads=1','-encode-only','-auto-libvpx=false','-format=json']
  start=time.time()
  with open(p/(f'whole-r{round}-{name}.json'),'w') as out,open(p/(f'whole-r{round}-{name}.stderr'),'w') as err:r=subprocess.run(args,env=env,stdout=out,stderr=err)
  records.append(dict(stage='whole',round=round,variant=name,argv=args,start=start,end=time.time(),exit=r.returncode));assert r.returncode==0
  (p/'final-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print('WHOLE ROUND',round,flush=True)
print('ALL TIMING COMPLETE',flush=True)

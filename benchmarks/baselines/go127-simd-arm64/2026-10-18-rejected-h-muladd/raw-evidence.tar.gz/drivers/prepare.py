from pathlib import Path
import subprocess,tarfile,io,json
r=Path('/private/tmp/govpx-arm-h-muladd');r.mkdir();(r/'drivers').mkdir();(r/'evidence').mkdir();root=Path('/Users/thesyncim/GolandProjects/govpx');commit='768f2fc2aba7bbd82981494473cbadc026a95570';data=subprocess.check_output(['git','archive',commit],cwd=root)
for v in ['parent','candidate']:
 p=r/v;p.mkdir()
 with tarfile.open(fileobj=io.BytesIO(data))as t:t.extractall(p)
 f=p/'internal/pixel/loopfilter_macro_internal_fused_arm64.go';s=f.read_text();h,sep,vertical=s.partition('func loopFilterMacroInternalFusedVertical(');assert sep
 if v=='candidate':
  assert h.count('lfMacroCorrection(')==6
  h=h.replace('lfMacroCorrection(', 'lfHMacroCorrectionMulAdd(')
  f.write_text(h+sep+vertical)
  (p/'internal/pixel/lf_h_muladd_arm64.go').write_text('''//go:build goexperiment.simd && arm64 && !purego
package pixel
import "simd/archsimd"
func lfHMacroCorrectionMulAdd(f archsimd.Int8x16,c int16)archsimd.Int8x16{
 k,bias:=archsimd.BroadcastInt16x8(c),archsimd.BroadcastInt16x8(63)
 lo:=lfTruncSigned(filterShift7(f.ExtendLo8ToInt16().MulAdd(k,bias)))
 hi:=lfTruncSigned(filterShift7(highBytes(f.ToBits()).BitsToInt8().ExtendLo8ToInt16().MulAdd(k,bias)))
 return lfJoinSigned(lo,hi)
}
''')
 helper='lfHMacroCorrectionMulAdd'if v=='candidate'else'lfMacroCorrection'
 (p/'internal/pixel/lf_h_muladd_private_arm64_test.go').write_text('''//go:build goexperiment.simd && arm64 && !purego
package pixel
import("testing";"simd/archsimd")
func TestHMacroCorrectionAllSigned(t *testing.T){
 if !Enabled{t.Fatal("ARM backend unavailable")}
 for base:=-128;base<128;base+=16{var f [16]int8;for i:=range16{f[i]=int8(base+i)}
 for _,c:=range []int16{9,18,27}{var out [16]int8;HELPER(archsimd.LoadInt8x16Array(&f),c).StoreArray(&out)
 for i,x:=range f{want:=int8((int16(x)*c+63)>>7);if out[i]!=want{t.Fatalf("f%d c%d got%d want%d",x,c,out[i],want)}}}}
}
'''.replace('range16','range 16').replace('HELPER',helper))
(r/'parent-commit.txt').write_text(commit+'\n')
v=Path('/private/tmp/govpx-arm-lf-byte-shift-ready/drivers/validate.py').read_text().replace('govpx-arm-lf-byte-shift','govpx-arm-h-muladd').replace('govpx-ci-lf-byte-shift','govpx-ci-h-muladd').replace("GOMAXPROCS='1'","GOMAXPROCS='2'")
v=v.replace("('backend',[", "('exhaustive',['test','-pgo=off','./internal/pixel','-run','^TestHMacroCorrectionAllSigned$','-count=1','-v']),('backend',[")
(r/'drivers/validate.py').write_text(v)
print(r)

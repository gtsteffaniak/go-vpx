from pathlib import Path
import hashlib,json,shutil,difflib,re
r=Path('/private/tmp/govpx-arm-h-muladd');ready=Path('/private/tmp/govpx-arm-h-muladd-ready');ready.mkdir();shutil.copyfile('/private/tmp/govpx-arm-h-muladd-prepare.py',r/'drivers/prepare.py')
paths=['internal/pixel/loopfilter_macro_internal_fused_arm64.go','internal/pixel/lf_h_muladd_arm64.go','internal/pixel/lf_h_muladd_private_arm64_test.go','internal/pixel/goav1_loopfilter_bytes_simd.go','internal/pixel/goav1_loopfilter_arm64.go','internal/pixel/helpers_arm64.go']
for v in ['parent','candidate']:
 for rel in paths:
  p=r/v/rel
  if p.exists():q=ready/(v+'-source')/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
fixture='internal/vp8/decoder/picker_filter_native_bench_test.go';q=ready/'fixture'/fixture;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/'parent'/fixture,q);assert (r/'parent'/fixture).read_bytes()==(r/'candidate'/fixture).read_bytes()
for d in ['drivers','evidence','screen']:shutil.copytree(r/d,ready/d)
for f in ['parent-commit.txt','screen-summary.json']:shutil.copyfile(r/f,ready/f)
patch=[]
for rel in paths:
 a,b=r/'parent'/rel,r/'candidate'/rel
 patch.extend(difflib.unified_diff(a.read_text().splitlines(True)if a.exists()else[],b.read_text().splitlines(True)if b.exists()else[],fromfile='parent/'+rel,tofile='candidate/'+rel))
(ready/'candidate.patch').write_text(''.join(patch))
# Complete source inventory proves production differences are H callsites plus new H helper only.
proof={};changed=[]
for a in (r/'parent').rglob('*.go'):
 rel=a.relative_to(r/'parent');b=r/'candidate'/rel
 if not b.exists()or a.read_bytes()!=b.read_bytes():changed.append(str(rel))
for b in (r/'candidate').rglob('*.go'):
 rel=b.relative_to(r/'candidate')
 if not (r/'parent'/rel).exists():changed.append(str(rel))
for name in ['loopfilter_macro_internal_fused_arm64.go','loopfilter_macro_internal_fused_amd64.go','goav1_loopfilter_bytes_simd.go']:
 a,b=[(r/v/'internal/pixel'/name).read_bytes()for v in ['parent','candidate']]
 if name.endswith('_arm64.go'):a=a.split(b'func loopFilterMacroInternalFusedVertical(')[1];b=b.split(b'func loopFilterMacroInternalFusedVertical(')[1]
 proof[name]={'compared_region':'vertical function'if name.endswith('_arm64.go')else'whole file','unchanged':a==b,'sha256':hashlib.sha256(a).hexdigest()};assert a==b
proof['changed_go_paths']=changed;(ready/'evidence/source-scope-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
sdk=Path('/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64');rules=sdk/'src/cmd/compile/internal/ssa/_gen/simdARM64.rules'
(ready/'evidence/sdk-rules.txt').write_text('\n'.join(f'{i+1}: {x}'for i,x in enumerate(rules.read_text().splitlines())if 'MulAddInt16x8' in x)+'\n')
env={'cpu':re.search(r'^cpu: (.+)$',(r/'screen/r1-parent.txt').read_text(),re.M).group(1),'compiler':(sdk/'VERSION').read_text().strip(),'GOEXPERIMENT':'simd','GOFLAGS':'-p=2','build_GOMAXPROCS':2,'timing_GOMAXPROCS':1,'GOVPX_REQUIRE_SIMD':1,'PGO':'off','CODEX_AGENT_ID':'govpx-ci-h-muladd','binary_sha256':{v:hashlib.sha256((r/(v+'-decoder.test')).read_bytes()).hexdigest()for v in ['parent','candidate']},'source_sha256':{str(p.relative_to(ready)):hashlib.sha256(p.read_bytes()).hexdigest()for v in ['parent-source','candidate-source']for p in (ready/v).rglob('*.go')}};(ready/'evidence/environment.json').write_text(json.dumps(env,indent=2)+'\n')
s=json.loads((r/'screen-summary.json').read_text());report='''# ARM horizontal-only MulAdd macro correction: rejected after screen

Parent `768f2fc2aba7bbd82981494473cbadc026a95570` (PR43). Stop/archive:
near-noise/mixed public changes, no meaningful representative gain. No root,
README or PR changes; no fresh-six or whole-codec measurements.

The sole candidate changes only ARM fused-horizontal macro correction calls
to a helper computing exactly `(f*c+63)>>7` with Int16x8.MulAdd, coefficients
9/18/27. Full source inventory and source-scope-proof.json establish unchanged
ARM vertical source, AMD source, generic helper, dispatch/gates/window checks,
loads/stores and all alias semantics. The common helper remains unchanged.
A test-only numeric fixture is byte-for-byte equivalent except helper name.

Pinned SDK MulAddInt16x8 lowers to destructive VMLA8H with accumulator in
arg0. Before timing both variants passed all768 signed-byte/coefficient
combinations, live ARM backend detection, five-package short suites and
four-package loop-filter race/checkptr2 oracles. Existing7200 fused-filter
cases, zero-correction/later edges, aliases, minimal windows and sentinels pass.
All commands/build/test outputs are retained. No assertions/thresholds weakened.

Optimized LLVM horizontal body changes6MUL.8H+6ADD.8H to6MLA.8H+5additional
MOV.16B bias copies. It has no calls/vector spills/stack-vector loads in either
variant. Disassembly entries364→362 include one removed trailing UDF alignment
word: the EXECUTABLE body saves only ONE instruction(363→362). No claim of two
hot instructions removed. Earlier conversational speculation about another
eliminated copy is withdrawn; opcode-count-diff.json records the exact delta.
The arithmetic dependency becomes bias-copy→MLA→shift, instead of MUL→ADD→shift;
this alone does not establish M4 latency/throughput benefit. Vertical698 and
generic416 entries/opcode mixes remain unchanged. Complete LLVM is retained.

Native Apple M4 Max, official Go1.27.2 SIMD, PGOoff,GOMAXPROCS1. After exclusive
host release from root, three75ms alternating AB/BA/AB rounds run the existing
actual public10-picker B.Loop fixtures; full output buffer must equal four
separate public edge operations. All60samples0B/op/0allocs; all30paired ratios
and slower controls retained. No artificial correction-only benchmark used.

| Public case | Parent ns | Candidate ns | Parent/candidate | Candidate time change |
|---|---:|---:|---:|---:|
'''
for x in s['results']:report+=f"| {x['case'].split('Native/')[1]} | {x['parent_ns']:.2f} | {x['candidate_ns']:.2f} | {x['speedup']:.5f}× | {x['candidate_time_change_percent']:+.3f}% |\n"
report+='''
Median ratios0.9883–1.0116×; candidate−1.15% to+1.19%time. Mixed cases improve
about1.1% but flat/ramp/noop controls regress or are mixed; this is insufficient
to establish useful gain. No kernel1.5×/whole-codec/x64 performance claim.
All Go/build/test/timing jobs stopped; host explicitly released after screen.

Exact sources, scoped patch/proof, public/numeric fixtures, full optimized LLVM,
SDK rule, ordinary/race/build logs, every raw timing, commands, paired summary,
environment/source/binary hashes retained. Full snapshots/binaries excluded.
Drivers retain original private paths. SHA256SUMS covers every other member.
The prior rejected UQSUB/OR archive remains unchanged.
''';(ready/'REPORT.md').write_text(report)
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ready))+'\n'for p in sorted(ready.rglob('*'))if p.is_file()and p.name!='SHA256SUMS');(ready/'SHA256SUMS').write_text(manifest)
for line in manifest.splitlines():
 sha,p=line.split('  ',1);assert hashlib.sha256((ready/p).read_bytes()).hexdigest()==sha
assert len(s['samples'])==60 and len(s['results'])==10 and all(x['B/op']==x['allocs/op']==0 for x in s['samples'])
assert len(json.loads((ready/'evidence/validation.json').read_text()))==10
print('FILES',len(manifest.splitlines()),'BYTES',sum(p.stat().st_size for p in ready.rglob('*')if p.is_file()),'MANIFEST_SHA256',hashlib.sha256(manifest.encode()).hexdigest())

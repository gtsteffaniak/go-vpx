from pathlib import Path
import os,subprocess,json,sys
r=Path('/private/tmp/govpx-arm-h-muladd');root=Path('/Users/thesyncim/GolandProjects/govpx')
e=os.environ.copy();e.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-h-muladd',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',GOVPX_REQUIRE_SIMD='1')
results=[]
for variant in ['parent','candidate']:
 commands=[('exhaustive',['test','-pgo=off','./internal/pixel','-run','^TestHMacroCorrectionAllSigned$','-count=1','-v']),('backend',['test','-pgo=off','./internal/pixel','-run','^TestBackendSelected$','-count=1','-v']),('native-short',['test','-pgo=off','-short','./internal/pixel','./internal/vp8/dsp','./internal/vp8/encoder','./internal/vp8/decoder','./internal/vp9/dsp']),('race-checkptr2',['test','-pgo=off','-race','-gcflags=all=-d=checkptr=2','./internal/pixel','./internal/vp8/dsp','./internal/vp8/decoder','./internal/vp9/dsp','-run','^Test(.*LoopFilter|MacroInternal)','-count=1','-v']),('decoder-build',['test','-pgo=off','-c','./internal/vp8/decoder','-o',str(r/(variant+'-decoder.test'))])]
 for name,args in commands:
  cmd=[str(root/'scripts/go.sh'),'-C',str(r/variant)]+args
  with (r/'evidence'/(variant+'-'+name+'.log')).open('w')as f:run=subprocess.run(cmd,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
  results.append({'variant':variant,'name':name,'command':cmd,'exit':run.returncode});print(variant,name,run.returncode,flush=True)
  (r/'evidence/validation.json').write_text(json.dumps(results,indent=2)+'\n')
  if run.returncode:sys.exit(run.returncode)
print('CORRECTNESS+BUILD COMPLETE',flush=True)

from pathlib import Path
import subprocess,re,json
r=Path('/private/tmp/govpx-arm-h-muladd');symbols=['loopFilterBytes','loopFilterMacroInternalFusedHorizontal','loopFilterMacroInternalFusedVertical'];out={}
for v in ['parent','candidate']:
 cmd=['xcrun','llvm-objdump','--disassemble','--demangle','--disassemble-symbols='+','.join('_github.com/thesyncim/govpx/internal/pixel.'+s for s in symbols),str(r/(v+'-decoder.test'))]
 run=subprocess.run(cmd,capture_output=True,text=True);assert run.returncode==0;(r/'evidence'/(v+'-llvm.txt')).write_text(run.stdout+run.stderr)
 blocks=re.split(r'^[0-9a-f]+ <_github.com/thesyncim/govpx/internal/pixel\.([^>]+)>:\n',run.stdout,flags=re.M);out[v]={}
 for i in range(1,len(blocks),2):
  name,body=blocks[i:i+2];ins=re.findall(r'^([0-9a-f]+):\s+[0-9a-f]+\s+([^\n]+)',body,re.M)
  out[v][name]={'instructions':len(ins),'mul8h':len(re.findall(r'\bmul\.8h',body)),'mla8h':len(re.findall(r'\bmla\.8h',body)),'add8h':len(re.findall(r'\badd\.8h',body)),'mov16b':len(re.findall(r'\bmov\.16b',body)),'vector_stack_stores':len(re.findall(r'\b(?:str|stur)\s+q\d+, \[sp',body)),'vector_stack_loads':len(re.findall(r'\b(?:ldr|ldur)\s+q\d+, \[sp',body)),'calls':[re.sub(r'0x[0-9a-f]+','ADDR',x[1])for x in ins if re.match(r'bl\s',x[1])]}
(r/'evidence/codegen-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

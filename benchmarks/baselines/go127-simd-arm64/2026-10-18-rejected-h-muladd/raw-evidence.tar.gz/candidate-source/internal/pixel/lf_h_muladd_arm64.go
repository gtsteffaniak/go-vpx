//go:build goexperiment.simd && arm64 && !purego
package pixel
import "simd/archsimd"
func lfHMacroCorrectionMulAdd(f archsimd.Int8x16,c int16)archsimd.Int8x16{
 k,bias:=archsimd.BroadcastInt16x8(c),archsimd.BroadcastInt16x8(63)
 lo:=lfTruncSigned(filterShift7(f.ExtendLo8ToInt16().MulAdd(k,bias)))
 hi:=lfTruncSigned(filterShift7(highBytes(f.ToBits()).BitsToInt8().ExtendLo8ToInt16().MulAdd(k,bias)))
 return lfJoinSigned(lo,hi)
}

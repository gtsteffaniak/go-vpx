//go:build goexperiment.simd && arm64 && !purego
package pixel
import("testing";"simd/archsimd")
func TestHMacroCorrectionAllSigned(t *testing.T){
 if !Enabled{t.Fatal("ARM backend unavailable")}
 for base:=-128;base<128;base+=16{var f [16]int8;for i:=range 16{f[i]=int8(base+i)}
 for _,c:=range []int16{9,18,27}{var out [16]int8;lfHMacroCorrectionMulAdd(archsimd.LoadInt8x16Array(&f),c).StoreArray(&out)
 for i,x:=range f{want:=int8((int16(x)*c+63)>>7);if out[i]!=want{t.Fatalf("f%d c%d got%d want%d",x,c,out[i],want)}}}}
}

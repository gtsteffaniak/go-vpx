from pathlib import Path
import os,subprocess,json,hashlib
r=Path('/private/tmp/govpx-arm-fill-exact');root=Path('/Users/thesyncim/GolandProjects/govpx');e=os.environ.copy();e.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-fill-whole',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go');records=[]
for v in ['parent','candidate','old691']:
 cmd=[str(root/'scripts/go.sh'),'-C',str(r/v),'build','-pgo=off','-o',str(r/(v+'-whole-bench')),'./cmd/govpx-bench']
 with (r/'final-evidence'/f'{v}-whole-build.log').open('w')as f:run=subprocess.run(cmd,env=e,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 assert run.returncode==0,v;records.append({'variant':v,'command':cmd,'exit':run.returncode,'sha256':hashlib.sha256((r/(v+'-whole-bench')).read_bytes()).hexdigest()});print(v,'wholebuilt',flush=True)
(r/'final-evidence/whole-build.json').write_text(json.dumps(records,indent=2)+'\n')
lock=json.loads((r/'final-evidence/production-lock.json').read_text());assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==sha for p,sha in lock.items());print('productionbytesunchanged',flush=True)

from pathlib import Path
import subprocess,json,hashlib,re
r=Path('/private/tmp/govpx-arm-fill-exact');records=[]
for v in ['parent','candidate','old691']:
 kind='dsp'if v=='old691'else'pixel';syms=['_github.com/thesyncim/govpx/internal/pixel.FillBlock']if kind=='pixel'else['_github.com/thesyncim/govpx/internal/vp8/dsp.intraDCPredict8x8','_github.com/thesyncim/govpx/internal/vp8/dsp.intraDCPredict16x16','_github.com/thesyncim/govpx/internal/vp8/dsp.intraFill8x8NEON.abi0','_github.com/thesyncim/govpx/internal/vp8/dsp.intraFill16x16NEON.abi0']
 cmd=['xcrun','llvm-objdump','--disassemble','--demangle','--disassemble-symbols='+','.join(syms),str(r/(v+'-final-'+kind+'.test'))];run=subprocess.run(cmd,capture_output=True,text=True);assert run.returncode==0;(r/'final-evidence'/f'{v}-final-llvm.txt').write_text(run.stdout+run.stderr);records.append({'variant':v,'command':cmd,'exit':0})
(r/'final-evidence/codegen-commands.json').write_text(json.dumps(records,indent=2)+'\n')
for v in ['parent','candidate']:
 p=r/v/'internal/pixel/kernels_simd.go';s=p.read_text();start=s.index('func FillBlock(');end=s.index('func RepeatRow(',start);(r/'final-evidence'/f'{v}-FillBlock-excerpt.go.txt').write_text(s[start:end])
print('Final optimized FillBlock and realoldNEON bodies preserved')

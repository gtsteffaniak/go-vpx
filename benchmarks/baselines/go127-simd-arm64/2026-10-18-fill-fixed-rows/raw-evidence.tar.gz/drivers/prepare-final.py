from pathlib import Path
import json,hashlib,subprocess,tarfile,io
r=Path('/private/tmp/govpx-arm-fill-exact');(r/'drivers').mkdir(exist_ok=True);(r/'final-evidence').mkdir(exist_ok=True);(r/'fresh-pixel').mkdir(exist_ok=True);(r/'fresh-dsp').mkdir(exist_ok=True)
root=Path('/Users/thesyncim/GolandProjects/govpx');old='691cd0512c4829d9ee40d483205dd223f9eb028d';p=r/'old691';p.mkdir()
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',old],cwd=root)))as t:t.extractall(p)
# Lock production bytes before changing any tests.
locked={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest()for v in ['parent','candidate']for p in (r/v/'internal/pixel').glob('*.go')if not p.name.endswith('_test.go')}
(r/'final-evidence/production-lock.json').write_text(json.dumps(locked,indent=2)+'\n')
fixture=(r/'candidate/internal/pixel/fill_exact_native_test.go').read_text().replace('FillBlockScalar(dst, ds, w, h, value)','for y := range h { for x := range w { dst[y*ds+x] = value } }')
extra='''
func TestFillExactCapacityAndValues(t *testing.T) {
 maxInt:=int(^uint(0)>>1)
 for _,w:=range []int{4,8,16}{for _,h:=range []int{0,1,2,4,8,16,64,65}{
 for _,ds:=range []int{-1,0,1,w-1,w,w+3,37,1312,(1<<30)-1,1<<30,maxInt,-maxInt-1}{
 for _,align:=range []int{0,1,7,15}{for _,value:=range []byte{0,1,127,128,213,254,255}{
  need:=w;if h>0&&ds>=0&&ds<1313{need=(h-1)*ds+w};need=min(need,8192)
  windows:=[][2]int{{0,0},{0,8192},{max(0,need-1),max(0,need-1)},{max(0,need-1),need},{need,need},{need,min(8192,need+17)},{w,min(8192,w+max(ds,0))}}
  for _,win:=range windows{visible,capacity:=win[0],win[1];if capacity<visible||capacity>8192{continue}
   a,b:=make([]byte,align+8192+19),make([]byte,align+8192+19);for i:=range a{a[i]=byte(i*37+91)};copy(b,a)
   got:=fillPanic(func(){FillBlock(a[align:align+visible:align+capacity],ds,w,h,value)})
   want:=fillPanic(func(){fillPriorOracle(b[align:align+visible:align+capacity],ds,w,h,value)})
   if got!=want||!bytes.Equal(a,b){t.Fatalf("w%d h%d ds%d align%d len%d cap%d value%d panic%v/%v",w,h,ds,align,visible,capacity,value,got,want)}
  }
 }}}}}
 // Every payload, exact complete capacity, overlapping and disjoint rows.
 for value:=range 256{for _,w:=range []int{4,8,16}{for _,ds:=range []int{0,1,w,w+3}{
  size:=ds+w;a,b:=make([]byte,size+2),make([]byte,size+2);for i:=range a{a[i]=19};copy(b,a)
  FillBlock(a[1:1+size:1+size],ds,w,2,byte(value));fillPriorOracle(b[1:1+size:1+size],ds,w,2,byte(value))
  if !bytes.Equal(a,b){t.Fatalf("payload%d w%d ds%d",value,w,ds)}
 }}}
}
'''
finalbench=fixture[fixture.index('func BenchmarkFillExactPublic'):].replace('func BenchmarkFillExactPublic','func BenchmarkFillExactFinal').replace('[]int{1, 8, 16}','[]int{1, w}')
for v in ['parent','candidate']:(r/v/'internal/pixel/fill_exact_native_test.go').write_text(fixture+extra+'\n'+finalbench)
dsp='''package dsp
import("bytes";"fmt";"testing")
var fillDCNativeSink byte
func fillDCTestOracle(dst []byte,ds,n int,above,left []byte,up,lf bool){
 dc,sum,count:=128,0,0
 if up{for i:=range n{sum+=int(above[i])};count+=n};if lf{for i:=range n{sum+=int(left[i])};count+=n}
 if count>0{dc=(sum+count/2)/count};for y:=range n{for x:=range n{dst[y*ds+x]=byte(dc)}}
}
func fillDCNativeCall(dst []byte,ds,n int,above,left []byte,up,lf bool){
 if n==8{IntraDCPredict8x8(dst,ds,above,left,up,lf)}else{IntraDCPredict16x16(dst,ds,above,left,up,lf)}
}
func TestIntraDCFillExactState(t *testing.T){
 for _,n:=range []int{8,16}{for _,ds:=range []int{n,37,1312}{for _,align:=range []int{0,1,7,15}{for _,both:=range []bool{false,true}{for _,alias:=range []int{0,1,2}{
  size:=(n-1)*ds+n;a,b:=make([]byte,align+size+23),make([]byte,align+size+23);for i:=range a{a[i]=byte(i*37+11)};copy(b,a)
  above,left:=make([]byte,n),make([]byte,n);for i:=range n{above[i]=byte(i*17+91);left[i]=byte(i*23+251)}
  ra,rl:=bytes.Clone(above),bytes.Clone(left)
  if alias==1{above=a[align:align+n];ra=b[align:align+n]};if alias==2{left=a[align:align+n];rl=b[align:align+n]}
  fillDCTestOracle(b[align:align+size:align+size],ds,n,ra,rl,both,both)
  fillDCNativeCall(a[align:align+size:align+size],ds,n,above,left,both,both)
  if !bytes.Equal(a,b){t.Fatalf("n%d ds%d align%d both%v alias%d",n,ds,align,both,alias)}
 }}}}}
}
func BenchmarkIntraDCFillExact(b *testing.B){
 for _,n:=range []int{8,16}{for _,both:=range []bool{false,true}{mode:="none";if both{mode="both"}
 for _,ds:=range []int{n,37,1312}{b.Run(fmt.Sprintf("n%d/%s/pitch%d",n,mode,ds),func(b *testing.B){
  size:=(n-1)*ds+n;storage:=make([]byte,size+31);for i:=range storage{storage[i]=byte(i*19+7)}
  above,left:=make([]byte,n),make([]byte,n);for i:=range n{above[i]=byte(i*17+91);left[i]=byte(i*23+251)}
  beforeA,beforeL:=bytes.Clone(above),bytes.Clone(left);expected:=bytes.Clone(storage);dst:=storage[7:7+size:7+size]
  fillDCTestOracle(expected[7:7+size:7+size],ds,n,above,left,both,both)
  b.ReportAllocs();for b.Loop(){if n==8{IntraDCPredict8x8(dst,ds,above,left,both,both)}else{IntraDCPredict16x16(dst,ds,above,left,both,both)}}
  if !bytes.Equal(storage,expected)||!bytes.Equal(above,beforeA)||!bytes.Equal(left,beforeL){b.Fatal("full output/context/canary mismatch")};fillDCNativeSink=dst[len(dst)-1]
 })}}}
}
'''
for v in ['parent','candidate','old691']:(r/v/'internal/vp8/dsp/fill_exact_native_test.go').write_text(dsp)
(r/'final-evidence/fixture-config.json').write_text(json.dumps({'old':old,'pixel_fresh_cases':18,'dsp_fresh_cases':12,'pixel_variants':['parent','candidate'],'dsp_variants':['parent','candidate','old691'],'original27case_screen_logs':'retained untouched','current_production_locked':True},indent=2)+'\n')
print('prepared fixtures and old691 only; production unchanged')

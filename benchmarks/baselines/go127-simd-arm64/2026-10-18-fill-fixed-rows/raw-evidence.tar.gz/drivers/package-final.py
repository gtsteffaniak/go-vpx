from pathlib import Path
import shutil,json,hashlib,difflib,re,subprocess
r=Path('/private/tmp/govpx-arm-fill-exact');ready=Path('/private/tmp/govpx-arm-fill-exact-ready');ready.mkdir()
shutil.copyfile('/private/tmp/govpx-arm-fill-exact-prepare-final.py',r/'drivers/prepare-final.py')
for d in ['drivers','final-evidence','fresh-pixel','fresh-dsp','fresh-whole']:shutil.copytree(r/d,ready/d)
initial=ready/'initial-and-inline';initial.mkdir()
for p in r.iterdir():
 if p.is_file()and p.suffix in ['.json','.txt']:shutil.copyfile(p,initial/p.name)
paths=['internal/pixel/kernels_simd.go','internal/pixel/fill_fixed_arm64.go','internal/pixel/fill_fixed_other.go','internal/pixel/fill_exact_native_test.go','internal/vp8/dsp/fill_exact_native_test.go','internal/vp8/dsp/intra_dispatch_other.go','internal/vp8/dsp/intra.go']
for v in ['parent','candidate']:
 for rel in paths:
  p=r/v/rel
  if p.exists():q=ready/(v+'-source')/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
for rel in ['internal/vp8/dsp/intra_arm64.go','internal/vp8/dsp/intra_arm64.s','internal/vp8/dsp/intra.go','internal/vp8/dsp/fill_exact_native_test.go']:
 q=ready/'old691-source'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/'old691'/rel,q)
# Keep overlay small and exactly the fresh-measured source; root integration owns citations/generator/gates.
for rel in paths[:5]:
 p=r/'candidate'/rel
 if p.exists():q=ready/'overlay'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
patch=[]
for rel in paths:
 a,b=r/'parent'/rel,r/'candidate'/rel
 patch.extend(difflib.unified_diff(a.read_text().splitlines(True)if a.exists()else[],b.read_text().splitlines(True)if b.exists()else[],fromfile='parent/'+rel,tofile='candidate/'+rel))
(ready/'candidate.patch').write_text(''.join(patch))
lock=json.loads((r/'final-evidence/production-lock.json').read_text());assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==sha for p,sha in lock.items())
changed=[]
for p in (r/'parent').rglob('*.go'):
 rel=p.relative_to(r/'parent');q=r/'candidate'/rel
 if not q.exists()or p.read_bytes()!=q.read_bytes():changed.append(str(rel))
for q in (r/'candidate').rglob('*.go'):
 rel=q.relative_to(r/'candidate')
 if not (r/'parent'/rel).exists():changed.append(str(rel))
assert set(changed)=={'internal/pixel/kernels_simd.go','internal/pixel/fill_fixed_arm64.go','internal/pixel/fill_fixed_other.go'},changed
sdk=Path('/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64');env={'parent':'768f2fc2aba7bbd82981494473cbadc026a95570','old691':'691cd0512c4829d9ee40d483205dd223f9eb028d','cpu':re.search(r'^cpu: (.+)$',(r/'fresh-pixel/r1-parent.log').read_text(),re.M).group(1),'compiler':(sdk/'VERSION').read_text().strip(),'GOEXPERIMENT':'simd','PGO':'off','GOFLAGS':'-p=2','build_GOMAXPROCS':2,'timing_GOMAXPROCS':1,'project_wrapper':'ROOT/scripts/go.sh -C private snapshot -> project-env','agent_ids':['govpx-ci-fill-final','govpx-ci-fill-whole'],'changed_production_paths':changed,'source_sha256':{str(p.relative_to(ready)):hashlib.sha256(p.read_bytes()).hexdigest()for d in ['parent-source','candidate-source','old691-source','overlay']for p in (ready/d).rglob('*')if p.is_file()},'binaries_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in r.glob('*-final-*.test')} ,'whole_binaries':json.loads((r/'final-evidence/whole-build.json').read_text())};(ready/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
pixel=json.loads((r/'fresh-pixel/summary.json').read_text());dsp=json.loads((r/'fresh-dsp/summary.json').read_text());whole=json.loads((r/'fresh-whole/summary.json').read_text())
report='''# ARM exact-width FillBlock: retain scoped component improvement

Pinned parent768f2fc2aba7bbd82981494473cbadc026a95570 (PR43); original real
NEON reference691cd0512c4829d9ee40d483205dd223f9eb028d. Native Apple M4 Max,
official Go1.27.2, GOEXPERIMENT=simd, PGOoff, GOMAXPROCS1 for all timings.
All binaries freshly built with the same SDK/root scripts/go.sh/project-env
cache scope and unique agent IDs. Build concurrency maxGOMAX2, no builds/Go/
heavy hashing during native timing windows. START/END coordinated with root,
ci_validation and merge_checkpoint. Every result/outlier/slower control retained.

Retain under the user's component rule: fresh six-pair public FillBlock square
medians improve1.544–2.090×; actual public IntraDCPredict8x8 with no neighbors
improves1.623–1.814×. Whole VP8 remains small/mixed(−0.363%median,5/6faster),
and original NEON remains faster on every measured DSP case and whole sample.
No additive, whole-codec speedup, cross-hardware or x64 performance claim.

## Frozen production and exact contract

Only FillBlock gains an ARM constant-selected fixed-width path. With SIMD
Enabled,2<=h<=64,nonnegative stride<2^30,w4/8/16 and full (h−1)*stride+w<=LEN,
each row uses exactly one4B/8B integer or16B SIMD store. No overstore, no new
allocation/alias restriction, positive endpoints fit int64, complete window
proven before stores. ds0/overlapping rows retain sequential writes of the same
value. Invalid/short-LEN/negative/extreme strides or other geometry decline
before stores and execute original row slicing/StorePart fallback unchanged.
Capacity remains usable by original fallback; malformed late-row capacity
retains original partial writes and panic. h1 stays in the original body but
added dispatch changes codegen/latency, with slower controls disclosed below.
AMD constantfalse removes specialization; purego/noexperiment remain scalar.
Production byte lock verified before and after all measurements; only test-only
fixtures/drivers changed during this confirmation. Root/PR/README untouched.

Private initial separate-helper and later inline27-case screens are exploratory,
not fresh acceptance. All initial/inline logs, build/correctness outputs, LLVM,
commands, summaries and h1 regressions remain under initial-and-inline.
The exact separately timed initial helper source was not independently archived
before root replaced it; its raw LLVM/commands remain. Final fresh-measured
inline source is fully preserved and hashed. No source identity claim equates
that initial helper with the final inline implementation.

## Independent correctness before fresh timing

The original-state oracle implements scalar writes directly and, for native
SIMD, reproduces prior per-row slice plus StorePart's min(width,16) contract.
Full backing buffers and panic booleans are compared, including clipped3-index
capacity, one-byte-short last rows, shortLEN with spareCAP, zeroLEN/height,
negative/zero/overlapping strides, h64/65, stride2^30−1/2^30/MaxInt/MinInt,
misalignments and every0..255 payload on exact windows. This closes the first
fixture's gap where all positive shortLEN cases had ample spare capacity.

Parent/candidate ordinary and race/checkptr2 pixel tests PASS; purego and
GOEXPERIMENT-empty state oracles PASS independently. Live backend logged native
ARM SIMD=true. DSP8/16 oracle computes DC via independent scalar sums, covers
none/both neighbor availability, exact capacities, packed/37/1312pitches,
misalignments and above/left aliasing destination. Parent/candidate/old691
ordinary DSP oracles PASS; currentparent/candidate DSP race/checkptr2 PASS.
All fresh benchmark fixtures pass1x output/canary/context oracles first.
Old invalid unsafe/short-capacity calls are not benchmarked as supported inputs.

Final LLVM is captured from measured binaries. Current FillBlock exact-store
bodies and old actual intraFill8x8NEON/intraFill16x16NEON calls are preserved,
not inferred merely from build tags. Component API scope: current production
FillBlock caller is VP8 intraDCGo(n8/n16);4x4 is standalone public component
coverage, not a claimed current codec caller.

## Fresh public pixel confirmation

Six balanced AB/BA pairs,100ms,18cases:4x4/8x8/16x16 +each width's one-row
control, packed/37/1312pitches. B.Loop varies payload each iteration; complete
backing/canary output checked after loop. All216samples0B/op,0allocs/op.
Ratios below are ratio of six-sample medians; paired ranges retain all rounds.

| Case | Parent ns | Candidate ns | Median ratio | Six paired ratio range | Faster pairs |
|---|---:|---:|---:|---:|---:|
'''
for x in pixel['cases']:
 pairs=x['pair_ratios_parent_over_candidate'];report+=f"| {x['case'].split('Final/')[1]} | {x['medians_ns']['parent']:.4f} | {x['medians_ns']['candidate']:.4f} | {x['parent_over_candidate']:.5f}× | {min(pairs):.5f}–{max(pairs):.5f}× | {x['candidate_faster_pairs']}/6 |\n"
report+='''
All square cases are faster in6/6 pairs; not every individual pair reaches1.5×.
In particular16x16/pitch1312 round4 is1.47483×, though median1.54441× qualifies.
One-row4B/8B regressions remain: median ratios0.918–0.982× and0.921–0.935×;
16B one-row is near-flat0.999–1.006×. No controls are excluded from reports.

## Fresh actual DSP prediction confirmation versus old NEON

Six balanced permutations of all three variants on the same host,100ms,
12cases. Timed functions directly call public IntraDCPredict8x8/16x16, none or
both neighbors; oracle checks entire output, canaries, immutable contexts.
All216samples0B/op,0allocs/op. Every case improves against parent in6/6pairs,
but old NEON remains faster in every case. old/candidate<1 means candidate
is slower than old; this explicitly records the remaining gap.

| Case | Parent ns | Candidate ns | Old NEON ns | Parent/candidate median | Six paired ratio range | Old/candidate median |
|---|---:|---:|---:|---:|---:|---:|
'''
for x in dsp['cases']:
 pairs=x['pair_ratios_parent_over_candidate'];m=x['medians_ns'];report+=f"| {x['case'].split('Exact/')[1]} | {m['parent']:.4f} | {m['candidate']:.4f} | {m['old691']:.4f} | {x['parent_over_candidate']:.5f}× | {min(pairs):.5f}–{max(pairs):.5f}× | {x['old_over_candidate']:.5f}× |\n"
report+='''
8x8/no-neighbor medians1.623–1.814×; its pitch37 round4 pair is below1.5×
(the exact minimum1.49775× is retained), so no all-pairs1.5 claim. Other DSP
availability/size cases improve1.240–1.498×, reported separately from qualifying
pixel/8x8-none components.

## Fresh whole VP8 quantification

Six balanced three-way permutations,300inputs each,1280x720,30fps,2500kbps,
realtime CPU-used8,one thread,encode-only,auto-libvpx=false. Positive CPU8 is
adaptive, so all recorded workload fields are checked rather than assumed.
All22 semantic fields and separate zero allocations match across all18JSONs:
298encoded/2dropped,3120743outputbytes,133700keyframebytes and identical
quantizer metadata/histogram. Quality is skipped; recorded equality does not
establish bitstream identity. CPU timer excludes fixture setup/alloc sampling.
'''
for v in ['parent','candidate','old691']:report+=f"\n- {v}: median{whole['medians_ns_per_frame'][v]:,.1f}ns/input; six samples{whole['variant_ns_per_frame'][v]}.\n"
for v in ['parent','old691']:
 x=whole['comparisons'][v];report+=f"\nCandidate vs{v}: {x['candidate_time_change_percent_ratio_of_medians']:+.6f}% by ratio of medians;{x['faster_pairs']}/6faster; paired range{x['min_pair_change_percent']:+.6f}..{x['max_pair_change_percent']:+.6f}%.\n"
report+='''
Whole result is small/mixed, not a strong codec improvement claim. Candidate
remains8.32056% slower than old691 in this run,0/6faster, with3.0178–9.6964%
paired gap; do not subtract this from another experiment or runner's figures.
Keep the verified component win under the user's explicit retention rule.

## Package and integration scope

Exact final source/overlay, independent fixtures, full raw initial/inline/fresh
logs, failed/initial build evidence if present, all paired samples/ratios,
18wholeJSONs/stderr, commands, LLVM, production/source/binary hashes retained.
No binaries/full snapshots/dependencies are bundled. SHA256SUMS covers all other
members; verification.json checks inventories, oracle/PASS markers and hashes.
The overlay is private/reviewable; root owns any integration, source citations,
PGO refresh and full CI gates. Root confirmed no per-file citation gate applies to these pixel const files;
preserve exact measured source bytes. No README edit.
'''
(ready/'REPORT.md').write_text(report)
verification={'production_lock_unchanged':True,'changed_production_paths':changed,'pixel_sample_count':len(pixel['samples']),'dsp_sample_count':len(dsp['samples']),'whole_sample_count':len(whole['records']),'all432_component_samples_zero_alloc':all(x['B/op']==x['allocs/op']==0 for s in [pixel,dsp]for x in s['samples']),'whole22_semantics_and_zero_alloc':whole['all22_semantics_match']and whole['all_allocations_zero'],'validation_command_count':len(json.loads((r/'final-evidence/validation.json').read_text())),'all_validation_commands_pass':all(x['exit']==0 for x in json.loads((r/'final-evidence/validation.json').read_text()))}
assert verification['pixel_sample_count']==216 and verification['dsp_sample_count']==216 and verification['whole_sample_count']==18 and verification['all432_component_samples_zero_alloc']and verification['whole22_semantics_and_zero_alloc']and verification['all_validation_commands_pass']
(ready/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ready))+'\n'for p in sorted(ready.rglob('*'))if p.is_file()and p.name!='SHA256SUMS');(ready/'SHA256SUMS').write_text(manifest)
for line in manifest.splitlines():
 sha,p=line.split('  ',1);assert hashlib.sha256((ready/p).read_bytes()).hexdigest()==sha
print('READY',ready,'MEMBERS',len(manifest.splitlines()),'BYTES',sum(p.stat().st_size for p in ready.rglob('*')if p.is_file()),'MANIFEST_SHA',hashlib.sha256(manifest.encode()).hexdigest())

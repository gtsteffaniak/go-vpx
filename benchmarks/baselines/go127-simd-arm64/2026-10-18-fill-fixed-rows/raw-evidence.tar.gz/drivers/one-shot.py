from pathlib import Path
import os,subprocess,json
r=Path('/private/tmp/govpx-arm-fill-exact');e=os.environ.copy();e.update(GOMAXPROCS='1');records=[]
for kind,variants,bench in [('pixel',['parent','candidate'],'^BenchmarkFillExactFinal$'),('dsp',['parent','candidate','old691'],'^BenchmarkIntraDCFillExact$')]:
 for v in variants:
  cmd=[str(r/(v+'-final-'+kind+'.test')),'-test.run=^$','-test.bench='+bench,'-test.benchtime=1x','-test.cpu=1','-test.count=1','-test.benchmem']
  with (r/'final-evidence'/f'{v}-{kind}-oneshot.log').open('w')as f:run=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT)
  records.append({'kind':kind,'variant':v,'command':cmd,'exit':run.returncode});assert run.returncode==0
(r/'final-evidence/oneshot-commands.json').write_text(json.dumps(records,indent=2)+'\n');print('all18pixel+12DSP fixture1x outputoracles passed in allvariants')

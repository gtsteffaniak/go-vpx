from pathlib import Path
import hashlib, io, json, tarfile

base = Path('/private/tmp')
out = base / 'govpx-dc-pair-research-ready'
out.mkdir(exist_ok=True)
payload = {}
for p in base.glob('govpx-next-dc-pair*'):
    if p.is_file() and p.suffix in ['.py', '.go', '.txt', '.json', '.log']:
        payload[p.name] = p.read_bytes()
    if p.is_dir() and (p / 'summary.json').exists():
        for q in p.iterdir():
            if q.is_file() and q.suffix in ['.json', '.txt']:
                payload[p.name + '/' + q.name] = q.read_bytes()
names = ['internal/pixel/dc_pair_simd.go', 'internal/pixel/dc_pair_test.go', 'internal/pixel/dc_pair_guard_simd_test.go', 'internal/pixel/helpers_arm64.go', 'internal/pixel/helpers_amd64.go', 'internal/vp8/dsp/dc_pair_native_bench_test.go', 'internal/vp8/dsp/idct.go', 'internal/vp8/dsp/idct_simd_other.go']
for variant in ['parent', 'candidate', 'guards-candidate', 'narrow-candidate', 'assembly']:
    for name in names:
        p = base / ('govpx-next-dc-pair-' + variant) / name
        if p.exists():
            payload['sources/' + variant + '/' + name] = p.read_bytes()
payload['govpx-archive-dc-pair-research.py'] = Path(__file__).read_bytes()
with tarfile.open(out / 'raw-and-sources.tar.gz', 'w:gz') as t:
    for name, value in sorted(payload.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mtime = len(value), 0
        t.addfile(info, io.BytesIO(value))
(out / 'raw-sha256.json').write_text(json.dumps({k: hashlib.sha256(v).hexdigest() for k, v in sorted(payload.items())}, indent=2) + '\n')
summary = {kind: json.loads((base / ('govpx-next-dc-pair-' + kind + '/summary.json')).read_text()) for kind in ['diagnostic', 'guards-diagnostic', 'narrow-diagnostic']}
assert all(len(x) == 18 for x in summary.values())
(out / 'component-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(out / 'environment.json').write_text(json.dumps({'cpu': 'Apple M4 Max', 'compiler': 'Go1.27.2 darwin/arm64 archsimd', 'pgo': 'off', 'goprocs': 1, 'parent': 'eb820478b9a995b59a266fb4d7d816acd78edbde', 'assembly': '691cd0512c4829d9ee40d483205dd223f9eb028d', 'rounds': 2, 'fixtures': 18, 'raw_members': len(payload), 'production': 'Unchanged; research source is preserved inside the archive.', 'binary_sha256': {n: hashlib.sha256((base / n).read_bytes()).hexdigest() for n in ['govpx-next-dc-pair-parent.test', 'govpx-next-dc-pair-assembly.test', 'govpx-next-dc-pair-candidate.test', 'govpx-next-dc-pair-guards-candidate.test', 'govpx-next-dc-pair-narrow-candidate.test']}}, indent=2) + '\n')
report = '''# DC pair reconstruction research

Native Apple M4 Max, Go1.27.2 archsimd, PGO off, GOMAXPROCS1. Two balanced
parent/ASM/current diagnostic rounds pervariant,100ms per18 public fixtures.
Parent eb820478, assembly691cd051. Preserve every sample/source; these short
diagnostics are not fresh six-round acceptance or whole-codec evidence.

The new B.Loop public fixtures cover pitches8/32/1312, exact in-place and
disjoint unequal pitches, unaligned starts, three DC pairs including clipping
and identity, exact visible spans, independent scalar equations and full
backing canaries. In-place reset restores32 pixels inside the measured loop
identically in every reference; disjoint inputs remain immutable. Results are
observable; all samples have zero B/op/allocations. OldASM remains legitimate.

'''
for name, values in summary.items():
    report += f"* {name}: {min(v['speedup'] for v in values.values()):.4f}–{max(v['speedup'] for v in values.values()):.4f}x parent; {min(v['speedup_assembly'] for v in values.values()):.4f}–{max(v['speedup_assembly'] for v in values.values()):.4f}x assembly.\n"
report += '''
Variants remove closure/slice checks after original bounds/alias guards,
simplify stride/delta interval guards and exact-in-place selection, then use
one signed-delta pattern plus widened add and unsigned narrowing saturation.
All remain below1.5x parent and still trail assembly. Preserve their code and
data for continuing research without claiming a qualifying gain or changing
the production DC path in this checkpoint.

Guard proofs: uint(stride-8)<=maxPitch-8 accepts exactly8..floor((MaxInt-7)/3),
including rejection of MinInt wrapping. Then3*stride+7<len equals the original
stride<=(len-8)/3. uint16(delta+255)<=510 selects exactly[-255,255] over every
signedint16 value. Exact aliases have non-overlapping rows; other accepted
spans are fully disjoint. Thus individual row read/store preserves semantics.
Widened pixel+delta lies[-255,510]; signed add plus unsigned saturation equals
the original positive/negative byte saturation. No padding or retained pointer.

Existing256-byte×511-delta scalar clipping tests and alignment/alias cases pass.
The new451,584-case guard matrix checks original division-based acceptance,
independent delta pairs, negative/extreme strides and short lengths, full96-byte
canaries and immutable inputs. Native pixel/public DSP tests pass. AMD builds
and Rosetta correctness pass after a review caught the first signed narrow
intrinsic was ARM-only: the final version uses the existing architecture
packBytes helper. The original source is recovered exactly by its reviewed
SHA and retained alongside the correction. No emulated speed claim.

Independent numeric/bounds/alias review passed after that correction. No
concurrent local builds/profiles during timing. No README or dependency edits,
production cgo or handwritten assembly introduced.
'''
(out / 'REPORT.md').write_text(report)
print(out, len(payload))

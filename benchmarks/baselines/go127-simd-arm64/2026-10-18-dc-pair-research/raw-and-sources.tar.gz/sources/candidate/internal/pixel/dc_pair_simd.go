//go:build goexperiment.simd && (arm64 || amd64) && !purego

package pixel

import (
	"simd/archsimd"
	"unsafe"
)

// AddConstantPair4 adds independent clamped DC deltas to two adjacent 4x4
// blocks using all sixteen byte lanes. Partial aliases retain block order in
// the caller; exact in-place layouts and disjoint buffers can run together.
func AddConstantPair4(pred []byte, ps int, dst []byte, ds int, d0, d1 int16) bool {
	if !Enabled || ps < 8 || ds < 8 || len(pred) < 8 || len(dst) < 8 || ps > (len(pred)-8)/3 || ds > (len(dst)-8)/3 || d0 < -255 || d0 > 255 || d1 < -255 || d1 > 255 {
		return false
	}
	pp, dp := uintptr(unsafe.Pointer(unsafe.SliceData(pred))), uintptr(unsafe.Pointer(unsafe.SliceData(dst)))
	exact := pp == dp && ps == ds
	disjoint := (pp <= dp && dp-pp >= uintptr(len(pred))) || (dp < pp && pp-dp >= uintptr(len(dst)))
	if !exact && !disjoint {
		return false
	}

	// Each byte lane has either a positive or a negative delta, never both.
	// Unsigned saturation therefore clips exactly without widening pixels.
	pattern := func(lo, hi int16) archsimd.Uint8x16 {
		a, b := uint32(byte(lo))*0x01010101, uint32(byte(hi))*0x01010101
		return archsimd.BroadcastUint64x2(uint64(a) | uint64(b)<<32).ReshapeToUint8s()
	}
	plus := pattern(max(d0, 0), max(d1, 0))
	minus := pattern(max(-d0, 0), max(-d1, 0))

	// The guards above prove all four exact eight-byte rows. Partial aliases
	// already declined; exact in-place rows do not overlap because pitch>=8.
	// Read each pair before writing it, retaining the original row order.
	sp, out := unsafe.Pointer(unsafe.SliceData(pred)), unsafe.Pointer(unsafe.SliceData(dst))
	v0 := archsimd.Uint64x2{}.SetElem(0, *(*uint64)(unsafe.Add(sp, 0*ps))).SetElem(1, *(*uint64)(unsafe.Add(sp, 1*ps))).ReshapeToUint8s().AddSaturated(plus).SubSaturated(minus).ReshapeToUint64s()
	*(*uint64)(unsafe.Add(out, 0*ds)) = v0.GetElem(0)
	*(*uint64)(unsafe.Add(out, 1*ds)) = v0.GetElem(1)
	v2 := archsimd.Uint64x2{}.SetElem(0, *(*uint64)(unsafe.Add(sp, 2*ps))).SetElem(1, *(*uint64)(unsafe.Add(sp, 3*ps))).ReshapeToUint8s().AddSaturated(plus).SubSaturated(minus).ReshapeToUint64s()
	*(*uint64)(unsafe.Add(out, 2*ds)) = v2.GetElem(0)
	*(*uint64)(unsafe.Add(out, 3*ds)) = v2.GetElem(1)

	return true
}

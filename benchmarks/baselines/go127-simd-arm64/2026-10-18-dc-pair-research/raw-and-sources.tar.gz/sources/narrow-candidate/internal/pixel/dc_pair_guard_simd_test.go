//go:build goexperiment.simd && (arm64 || amd64) && !purego

package pixel

import (
	"os"
	"testing"
)

func TestDCPairGuardCompatibility(t *testing.T) {
	if !Enabled {
		if os.Getenv("GOVPX_REQUIRE_SIMD") == "1" {
			t.Fatal("required SIMD unavailable")
		}
		t.Skip("native SIMD disabled")
	}
	maxInt := int(^uint(0) >> 1)
	maxPitch := (maxInt - 7) / 3
	pitches := []int{-maxInt - 1, -1, 0, 7, 8, 9, 16, 24, maxPitch - 1, maxPitch, maxPitch + 1, maxInt}
	lengths := []int{0, 7, 8, 31, 32, 53, 79, 80}
	deltas := []int16{-32768, -256, -255, 0, 255, 256, 32767}
	var original, blank [96]byte
	for i := range original {
		original[i], blank[i] = byte(i*37+11), 0xa7
	}
	for _, ps := range pitches {
		for _, ds := range pitches {
			for _, sn := range lengths {
				for _, dn := range lengths {
					for _, d0 := range deltas {
						for _, d1 := range deltas {
							src, dst, want := original, blank, blank
							// The original division-based guard is an independent
							// oracle for all accepted and rejected integer domains.
							selected := ps >= 8 && ds >= 8 && sn >= 8 && dn >= 8 && ps <= (sn-8)/3 && ds <= (dn-8)/3 && d0 >= -255 && d0 <= 255 && d1 >= -255 && d1 <= 255
							got := AddConstantPair4(src[:sn], ps, dst[:dn], ds, d0, d1)
							if got != selected {
								t.Fatalf("selection ps%d ds%d sn%d dn%d d%d,%d: got%v want%v", ps, ds, sn, dn, d0, d1, got, selected)
							}
							if selected {
								for y := range 4 {
									for x := range 8 {
										delta := d0
										if x >= 4 {
											delta = d1
										}
										want[y*ds+x] = byte(min(255, max(0, int(original[y*ps+x])+int(delta))))
									}
								}
							}
							if src != original || dst != want {
								t.Fatalf("write/canary mismatch ps%d ds%d sn%d dn%d d%d,%d selected%v", ps, ds, sn, dn, d0, d1, selected)
							}
						}
					}
				}
			}
		}
	}
}

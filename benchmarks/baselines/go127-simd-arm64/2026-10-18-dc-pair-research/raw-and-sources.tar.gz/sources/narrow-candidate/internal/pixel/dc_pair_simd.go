//go:build goexperiment.simd && (arm64 || amd64) && !purego

package pixel

import (
	"simd/archsimd"
	"unsafe"
)

// AddConstantPair4 adds independent clamped DC deltas to two adjacent 4x4
// blocks using all sixteen byte lanes. Partial aliases retain block order in
// the caller; exact in-place layouts and disjoint buffers can run together.
func AddConstantPair4(pred []byte, ps int, dst []byte, ds int, d0, d1 int16) bool {
	// Each stride must allow 3*stride+7 without integer overflow. The
	// unsigned interval test also rejects negative values and pitches below eight.
	const maxPitch = (int(^uint(0)>>1) - 7) / 3
	if !Enabled || uint(ps-8) > uint(maxPitch-8) || uint(ds-8) > uint(maxPitch-8) || uint16(d0+255) > 510 || uint16(d1+255) > 510 {
		return false
	}
	if 3*ps+7 >= len(pred) || 3*ds+7 >= len(dst) {
		return false
	}

	pp, dp := uintptr(unsafe.Pointer(unsafe.SliceData(pred))), uintptr(unsafe.Pointer(unsafe.SliceData(dst)))
	if pp != dp || ps != ds {
		disjoint := (pp <= dp && dp-pp >= uintptr(len(pred))) || (dp < pp && pp-dp >= uintptr(len(dst)))
		if !disjoint {
			return false
		}
	}

	// Signed widening needs one shared delta pattern, followed by unsigned
	// narrowing saturation. Pixels plus bounded delta remain in [-255,510].
	lo := uint64(uint16(d0)) * 0x0001000100010001
	hi := uint64(uint16(d1)) * 0x0001000100010001
	delta := archsimd.BroadcastUint64x2(lo).SetElem(1, hi).ReshapeToUint16s().BitsToInt16()
	sp, out := unsafe.Pointer(unsafe.SliceData(pred)), unsafe.Pointer(unsafe.SliceData(dst))
	v0 := archsimd.BroadcastUint64x2(*(*uint64)(unsafe.Add(sp, 0*ps))).ReshapeToUint8s()
	result0 := packBytes(widen8(v0).Add(delta)).ReshapeToUint64s().GetElem(0)
	*(*uint64)(unsafe.Add(out, 0*ds)) = result0
	v1 := archsimd.BroadcastUint64x2(*(*uint64)(unsafe.Add(sp, 1*ps))).ReshapeToUint8s()
	result1 := packBytes(widen8(v1).Add(delta)).ReshapeToUint64s().GetElem(0)
	*(*uint64)(unsafe.Add(out, 1*ds)) = result1
	v2 := archsimd.BroadcastUint64x2(*(*uint64)(unsafe.Add(sp, 2*ps))).ReshapeToUint8s()
	result2 := packBytes(widen8(v2).Add(delta)).ReshapeToUint64s().GetElem(0)
	*(*uint64)(unsafe.Add(out, 2*ds)) = result2
	v3 := archsimd.BroadcastUint64x2(*(*uint64)(unsafe.Add(sp, 3*ps))).ReshapeToUint8s()
	result3 := packBytes(widen8(v3).Add(delta)).ReshapeToUint64s().GetElem(0)
	*(*uint64)(unsafe.Add(out, 3*ds)) = result3

	return true
}

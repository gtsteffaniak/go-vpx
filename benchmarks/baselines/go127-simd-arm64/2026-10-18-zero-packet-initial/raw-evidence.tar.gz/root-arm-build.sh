#!/bin/sh
set -eu
export CODEX_AGENT_ID=root-packet54-arm CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go GOEXPERIMENT=simd GOMAXPROCS=2 GOFLAGS=-p=2 CGO_ENABLED=1
r=/Users/thesyncim/GolandProjects/govpx
p=/private/tmp/govpx-astra-quant-packet54
for v in parent candidate; do
 "$r/scripts/go.sh" -C "$p/$v" test -pgo=off ./internal/pixel ./internal/vp9/encoder -count=1 > "$p/root-arm-$v-test.log" 2>&1
 "$r/scripts/go.sh" -C "$p/$v" test -pgo=off -race -gcflags=all=-d=checkptr=2 ./internal/pixel ./internal/vp9/encoder -run '^(TestFPPacket|TestFP|TestQuantizeFP)' -count=1 -v > "$p/root-arm-$v-race.log" 2>&1
 "$r/scripts/go.sh" -C "$p/$v" test -pgo=off -c -o "$p/root-arm-$v-pixel.test" ./internal/pixel
 "$r/scripts/go.sh" -C "$p/$v" test -pgo=off -c -o "$p/root-arm-$v-encoder.test" ./internal/vp9/encoder
 "$r/scripts/go.sh" -C "$p/$v" build -pgo=off -o "$p/root-arm-$v-whole" ./cmd/govpx-bench
done

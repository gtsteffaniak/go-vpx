from pathlib import Path
import json,hashlib,re,statistics
p=Path('/private/tmp/govpx-astra-quant-packet54');b=json.loads((p/'root-arm-binding.json').read_text());H=lambda z:hashlib.sha256(z).hexdigest();q={'scope':'Native ARM independent raw audit, no builds/timing or source mutations','binding_sha256':H((p/'root-arm-binding.json').read_bytes()),'sources':{},'components':{},'whole':{},'codegen':{}};bh=q['binding_sha256'];maps={}
for v,z in b['variants'].items():
 root=Path(z['source']);a={str(f.relative_to(root)):H(f.read_bytes())for f in root.rglob('*.go')};orig=z['all_go_sha256'];changes={f:{'initial':orig.get(f),'current':a.get(f)}for f in sorted(set(orig)|set(a))if orig.get(f)!=a.get(f)};assert set(changes)<= {'internal/pixel/quantize_fp_packets_test.go'},(v,changes);maps[v]=orig;q['sources'][v]={'initial_go_count':len(orig),'current_go_count':len(a),'unchanged_production':True,'post_timing_test_only_delta':changes,'binaries':z['binaries']}
 for x in z['binaries'].values():assert H(Path(x['path']).read_bytes())==x['sha256']and Path(x['path']).stat().st_size==x['bytes']
assert H(Path(b['old691']['path']).read_bytes())==b['old691']['sha256'];q['original_production_delta']=[f for f in sorted(set(maps['parent'])|set(maps['candidate']))if maps['parent'].get(f)!=maps['candidate'].get(f)];assert q['original_production_delta']==['internal/pixel/quantize_fp32_avx512_amd64.go','internal/pixel/quantize_fp_amd64.go','internal/pixel/quantize_fp_simd.go']
pat=re.compile(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op\s+([\d.]+) B/op\s+([\d.]+) allocs/op',re.M);a={};counts={};orders=[['parent','candidate','old691'],['candidate','old691','parent'],['old691','parent','candidate'],['old691','candidate','parent'],['parent','old691','candidate'],['candidate','parent','old691']]
for mode in ['preflight','components','whole-vp8-720','whole-vp9-320','whole-vp9-720']:
 d=p/('native-'+mode);c=json.loads((d/'commands.json').read_text());assert c['binding_sha256']==bh and c['excluded_from_performance']==(mode=='preflight');counts[mode]=0;whole=mode.startswith('whole')
 assert c['orders']==([['parent','candidate']]if mode=='preflight'else(orders if whole else[['parent','candidate'],['candidate','parent']]*3));assert len(c['measurements'])==(18 if whole else(4 if mode=='preflight'else 24))
 for z in c['measurements']:
  i,v,t=z['round'],z['variant'],z['type'];assert z['exit_code']==0and z['start_utc']<z['end_utc'];assert z['command'][0]==(b['old691']['path']if v=='old691'else b['variants'][v]['binaries'][t]['path'])
  if whole:continue
  text=(d/f'r{i}-{v}-{t}.txt').read_text();rs=pat.findall(text);assert len(rs)==(48 if t=='pixel'else 36)and len({x[0]for x in rs})==len(rs)and '\nPASS\n'in text
  for n,ns,by,al in rs:assert float(by)==float(al)==0;a[mode,i,v,n]=float(ns);counts[mode]+=1
assert counts['components']==1008and counts['preflight']==168
for n in sorted({n for mode,i,v,n in a if mode=='components'}):
 vals={v:[a['components',i,v,n]for i in range(1,7)]for v in ['parent','candidate']};r=[x/y for x,y in zip(vals['parent'],vals['candidate'])];q['components'][n]={'raw_ns':vals,'median_speedup':statistics.median(vals['parent'])/statistics.median(vals['candidate']),'paired_speedup':r,'faster':sum(x>1for x in r),'slower':sum(x<1for x in r),'minimum_pair':min(r),'all_pairs_ge1_5':min(r)>=1.5}
ign={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'}
for mode in ['whole-vp8-720','whole-vp9-320','whole-vp9-720']:
 w={v:[json.loads((p/('native-'+mode)/f'r{i}-{v}-whole.txt').read_text())for i in range(1,7)]for v in ['parent','candidate','old691']};sem={k:v for k,v in w['parent'][0].items()if k not in ign};assert len(sem)==22and all({k:v for k,v in z.items()if k not in ign}==sem and z['allocs_per_frame']=={'whole-vp8-720':0,'whole-vp9-320':74/120,'whole-vp9-720':75/60}[mode]for ds in w.values()for z in ds);ns={v:[x['ns_per_frame']for x in ds]for v,ds in w.items()};med={v:statistics.median(x)for v,x in ns.items()};out={'raw_ns':ns,'medians':med,'all22semantic_fields':sem,'all18allocations_equal_expected':True,'actual_allocations':{v:[z['allocs_per_frame'] for z in ds] for v,ds in w.items()},'comparisons':{}}
 for v in ['parent','old691']:
  r=[100*(x/y-1)for x,y in zip(ns['candidate'],ns[v])];out['comparisons'][v]={'median_time_change_pct':100*(med['candidate']/med[v]-1),'paired_time_change_pct':r,'faster':sum(x<0for x in r),'slower':sum(x>0for x in r)}
 q['whole'][mode]=out
for v in ['parent','candidate']:
 text=(p/f'root-arm-{v}-quantize-LLVM.txt').read_text();ins=re.findall(r'^[0-9a-f]+:\s+(?:[0-9a-f]{8}\s+)?(.+)$',text,re.M);ins=[' '.join(x.split())for x in ins]
 q['codegen'][v]={'total_instructions':len(ins),'all_calls':[x for x in ins if x.startswith('bl ')],'zero_mask_reduce_lines':[x for x in ins if 'umaxv'in x],'scope':'Wholefunctiontextincludescoldpanics; not hotcyclecount.'}
q['counts']=counts;q['scope_limits']=['ARM8nativeevidenceonly, noAMD8/16/32throughputclaim orAVX512executioninference.','Zero/belowthresholdpacketfastpath alignsreferencebyproof; doesnotreplaceexactpublicthresholdwithtable-specificshortcut.','Currentpost-additivetestdelta recordedseparately; original1959maps/timedbinarySHA sourcebindingimmutable.','Allslowercontrols/pairs andeachseparatewholeworkload remainvisible; no crosswindowgap subtraction.']
# Group by exact fixture labels to retain zero/sparse/dense and no-classes controls.
q['groups']={}
for kind in ['zero','sparse','dense']:
 z=[x for n,x in q['components'].items()if '/'+kind+'/'in n];q['groups'][kind]={'cases':len(z),'median_range':[min(x['median_speedup']for x in z),max(x['median_speedup']for x in z)],'median_losses':sum(x['median_speedup']<1for x in z),'slower_pairs':sum(x['slower']for x in z),'all_pairs_ge1_5_cases':sum(x['all_pairs_ge1_5']for x in z)}
out=p/'independent-arm-audit.json';out.write_text(json.dumps(q,indent=2)+'\n');print(out);print(H(out.read_bytes()));print('groups',q['groups']);print('codegen',q['codegen']);print('sources',{v:x['post_timing_test_only_delta']for v,x in q['sources'].items()})
for k,w in q['whole'].items():print(k,w['comparisons'])

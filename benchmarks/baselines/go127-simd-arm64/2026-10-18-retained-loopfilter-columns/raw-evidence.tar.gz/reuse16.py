from pathlib import Path
p=Path('/private/tmp/govpx-astra-hotpaths52/internal/pixel/loopfilter_macro_internal_fused_arm64.go')
s=Path('/private/tmp/govpx-astra-hotpaths52-proof/original-fused-arm64.go').read_text()
h,b=s.split('func loopFilterMacroInternalFusedVertical(',1)
start=b.index('\tptr := unsafe.Pointer(unsafe.SliceData(p))')
end=b.index('\n\tvar lfO0',start)
lines=['\tptr := unsafe.Pointer(unsafe.SliceData(p))']
for i in range(8):
 lines += [f'\tw{i} := archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(ptr, {i}*outer))).ReshapeToUint64s()',f'\tw{i+8} := archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(ptr, {i+8}*outer))).ReshapeToUint64s()',f'\tr{i} := w{i}.InterleaveLo(w{i+8}).ReshapeToUint32s()',f'\th{i} := w{i}.InterleaveHi(w{i+8}).ReshapeToUint32s()']
for pref,root,names in [('a','r',['p3','p2','p1','p0','q0','q1','q2','q3']),('c','h',[f'later{i}' for i in range(8)])]:
 for i in range(4):
  lines += [f'\t{pref}{2*i} := {root}{i}.InterleaveEven({root}{i+4}).ReshapeToUint16s()', f'\t{pref}{2*i+1} := {root}{i}.InterleaveOdd({root}{i+4}).ReshapeToUint16s()']
 # a0,a4 -> col0/1, a2,a6 -> col0/1otherrows etc
 for j,(u,v) in enumerate([(0,4),(2,6),(1,5),(3,7)]):
  lines += [f'\t{pref}b{2*j} := {pref}{u}.InterleaveEven({pref}{v}).ReshapeToUint8s()',f'\t{pref}b{2*j+1} := {pref}{u}.InterleaveOdd({pref}{v}).ReshapeToUint8s()']
 for j,(u,v) in enumerate([(0,2),(1,3),(4,6),(5,7)]):
  op='=' if root=='r' else ':='
  lines += [f'\t{names[2*j]} {op} {pref}b{u}.InterleaveEven({pref}b{v})',f'\t{names[2*j+1]} {op} {pref}b{u}.InterleaveOdd({pref}b{v})']
b=b[:start]+'\n'.join(lines)+b[end:]
marker='\t\t// The wrapper proves all twenty columns, including the wide loads at column four.'
last='q0, q1, q2, q3 = a0.InterleaveEven(a2), a0.InterleaveOdd(a2), a1.InterleaveEven(a3), a1.InterleaveOdd(a3)'
for j in range(2):
 start=b.index(marker)
 end=b.index(last,start)+len(last)
 b=b[:start]+f'\t\tq0, q1, q2, q3 = later{4*j}, later{4*j+1}, later{4*j+2}, later{4*j+3}'+b[end:]
p.write_text(h+'func loopFilterMacroInternalFusedVertical('+b)

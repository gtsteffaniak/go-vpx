from pathlib import Path
import json,statistics,re
p=Path('/private/tmp/govpx-astra-hotpaths52-proof');a={}
for f in (p/'final-native-components').glob('*.txt'):
 r,v,t=f.stem.split('-');a[r,v,t]={m.group(1):{'ns':float(m.group(2)),'bytes':float(m.group(3)),'allocs':float(m.group(4))}for m in re.finditer(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op\s+([\d.]+) B/op\s+([\d.]+) allocs/op',f.read_text(),re.M)}
c={}
for t in ['dsp','decoder']:
 for k in a['r1','parent',t]:
  vs={v:[a['r'+str(i),v,t][k]['ns']for i in range(1,11)] for v in ['parent','final']};ratios=[x/y for x,y in zip(vs['parent'],vs['final'])]
  c[k]={'raw_ns':vs,'median_speedup':statistics.median(vs['parent'])/statistics.median(vs['final']),'pair_speedups':ratios,'pairs_faster':sum(x>1 for x in ratios),'all_zero_alloc':all(a['r'+str(i),v,t][k]['bytes']==0 and a['r'+str(i),v,t][k]['allocs']==0 for i in range(1,11)for v in ['parent','final'])}
w={v:[json.loads((p/'final-native-whole'/f'r{i}-{v}-whole.txt').read_text())for i in range(1,7)]for v in ['parent','final','old691']}
ignore={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'}
semantic={k:v for k,v in w['parent'][0].items()if k not in ignore}
assert len(semantic)==22
assert all({k:v for k,v in d.items()if k not in ignore}==semantic for ds in w.values()for d in ds)
whole={'semantic_fields_equal':list(semantic),'allocs_zero':all(d['allocs_per_frame']==0 for ds in w.values()for d in ds),'ns_per_frame':{v:[d['ns_per_frame']for d in ds]for v,ds in w.items()}}
whole['medians']={v:statistics.median(xs)for v,xs in whole['ns_per_frame'].items()}
whole['candidate_time_change_pct']={v:100*(whole['medians']['final']/whole['medians'][v]-1)for v in ['parent','old691']}
whole['paired_candidate_time_change_pct']={v:[100*(x/y-1)for x,y in zip(whole['ns_per_frame']['final'],whole['ns_per_frame'][v])]for v in ['parent','old691']}
(p/'final-summary.json').write_text(json.dumps({'components':c,'whole':whole},indent=2)+'\n');print(json.dumps(whole,indent=2))

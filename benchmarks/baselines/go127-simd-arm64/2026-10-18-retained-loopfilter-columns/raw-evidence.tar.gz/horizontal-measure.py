from pathlib import Path
import hashlib,json,os,subprocess,datetime,platform
p=Path('/private/tmp/govpx-astra-hotpaths52-proof')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
b=json.loads((p/'horizontal-independent-binding.json').read_text())
for v,d in b['independent'].items():
 assert sha(d['binary'])==d['binary_sha256']
 root=Path(d['source']);assert {str(f.relative_to(root)):sha(f)for f in sorted(root.rglob('*.go'))}==d['source_go_sha256']
fb=json.loads((p/'final-binding.json').read_text());ib=json.loads((p/'binding.json').read_text())
original={'parent':fb['variants']['parent']['binaries']['dsp'],'reuse16':ib['variants']['reuse16']['binaries']['dsp'],'final':fb['variants']['final']['binaries']['dsp']}
for d in original.values():assert sha(d['path'])==d['sha256']
assert platform.machine()=='arm64'
env=os.environ.copy();env['GOMAXPROCS']='1';out=p/'horizontal-native';out.mkdir(exist_ok=True);records=[]
for kind,orders in [('independent',[['parent','final'],['final','parent']]*3),('original',[['parent','reuse16','final'],['reuse16','final','parent'],['final','parent','reuse16'],['final','reuse16','parent'],['parent','final','reuse16'],['reuse16','parent','final']])]:
 print('START',kind,now(),flush=True)
 for rnd,order in enumerate(orders,1):
  for v in order:
   binary=b['independent'][v]['binary'] if kind=='independent' else original[v]['path']
   bench='^BenchmarkLFHorizontalIndependentNative$' if kind=='independent' else '^BenchmarkLFMacroAxisNative$/^verticalfalse$/^pitch(32|1312)$/^flat$'
   cmd=[binary,'-test.run=^$','-test.bench='+bench,'-test.benchtime=100ms','-test.count=1','-test.cpu=1','-test.benchmem']
   raw=out/f'{kind}-r{rnd}-{v}.txt';err=raw.with_suffix('.stderr');rec={'kind':kind,'round':rnd,'variant':v,'command':cmd,'binary_sha256':sha(binary),'start_utc':now()}
   with raw.open('w')as f,err.open('w')as e:r=subprocess.run(cmd,env=env,stdout=f,stderr=e)
   rec.update(end_utc=now(),exit_code=r.returncode);records.append(rec);(out/'commands.json').write_text(json.dumps({'bindings':{n:sha(p/n)for n in ['horizontal-independent-binding.json','final-binding.json','binding.json']},'measurements':records},indent=2)+'\n');assert r.returncode==0,(cmd,raw)
  print(kind,'round',rnd,'PASS',now(),flush=True)
print('END all timing processes STOPPED',now(),flush=True)

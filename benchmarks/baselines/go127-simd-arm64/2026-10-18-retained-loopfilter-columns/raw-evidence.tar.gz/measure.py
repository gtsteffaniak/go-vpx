from pathlib import Path
import hashlib,json,platform,subprocess,os,datetime,sys
p=Path('/private/tmp/govpx-astra-hotpaths52-proof');root=Path('/Users/thesyncim/GolandProjects/govpx')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
bp=Path('/private/tmp/govpx-lf-store52/parent')
cp=Path('/private/tmp/govpx-astra-hotpaths52')
b={'base_commit':'bc4a12a2ea74f6219d26acb5646677016eb6423f','host':'Apple M4 Max/Darwin arm64','compiler':'Go1.27.2','CGO_ENABLED':1,'PGO':'off','GOEXPERIMENT':'simd','GOMAXPROCS':1,'variants':{}}
for v,d,stem in [('parent',bp,Path('/private/tmp/govpx-lf-store52/parent')),('reuse16',cp,p/'reuse16')]:
 b['variants'][v]={'source':str(d),'all_go_sha256':{str(f.relative_to(d)):sha(f)for f in sorted(d.rglob('*.go'))},'binaries':{}}
 for typ,suffix in [('whole','-whole-bench'),('dsp','-dsp.test'),('decoder','-decoder.test')]:
  f=Path(str(stem)+suffix);b['variants'][v]['binaries'][typ]={'path':str(f),'sha256':sha(f)}
old=Path('/private/tmp/govpx-arm48-integrated/old691-whole-bench');b['old691']={'path':str(old),'sha256':sha(old)}
assert b['old691']['sha256']=='61c17b6e5b9848f067ee8d7c2fb55e8521a7fcc5de384bb695128dd90f4412cf'
if sys.argv[1]=='bind':
 (p/'binding.json').write_text(json.dumps(b,indent=2)+'\n'); print('Bound sources and binaries; source counts', {v:len(x['all_go_sha256'])for v,x in b['variants'].items()});sys.exit()
assert b==json.loads((p/'binding.json').read_text());assert platform.machine()=='arm64'
env=os.environ.copy();env['GOMAXPROCS']='1';mode=sys.argv[1];out=p/('native-'+mode);out.mkdir(exist_ok=True)
orders=[['parent','reuse16'],['reuse16','parent']]*3
if mode=='whole':orders=[['parent','reuse16','old691'],['reuse16','old691','parent'],['old691','parent','reuse16'],['old691','reuse16','parent'],['parent','old691','reuse16'],['reuse16','parent','old691']]
recs=[];print('START',mode,now(),flush=True)
for rnd,order in enumerate(orders,1):
 for v in order:
  types=['whole'] if mode=='whole' else ['dsp','decoder']
  for typ in types:
   binary=b['old691']['path'] if v=='old691' else b['variants'][v]['binaries'][typ]['path']
   if typ=='whole':cmd=[binary,'-codec=vp8','-width=1280','-height=720','-frames=300','-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8','-threads=1','-encode-only','-auto-libvpx=false','-format=json']
   else:cmd=[binary,'-test.run=^$','-test.bench=^'+('BenchmarkLFMacroAxisNative' if typ=='dsp' else 'BenchmarkVP8PickerFilterNative')+'$','-test.benchtime=75ms','-test.count=1','-test.cpu=1','-test.benchmem']
   rec={'round':rnd,'variant':v,'type':typ,'command':cmd,'start_utc':now()};raw=out/f'r{rnd}-{v}-{typ}.txt';err=raw.with_suffix('.stderr')
   with raw.open('w')as f,err.open('w')as e:r=subprocess.run(cmd,env=env,stdout=f,stderr=e)
   rec.update(end_utc=now(),exit_code=r.returncode);recs.append(rec);(out/'commands.json').write_text(json.dumps({'orders':orders,'binding_sha256':sha(p/'binding.json'),'measurements':recs},indent=2)+'\n');assert r.returncode==0,(cmd,raw,err)
 print('round',rnd,'PASS',now(),flush=True)
print('END all measurement processes stopped',now(),flush=True)

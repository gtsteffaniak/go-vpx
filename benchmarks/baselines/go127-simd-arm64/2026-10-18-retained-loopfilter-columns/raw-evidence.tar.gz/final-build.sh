#!/bin/sh
set -eu
export CODEX_AGENT_ID=astra-hotpaths52-final CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go GOEXPERIMENT=simd GOMAXPROCS=2 GOFLAGS=-p=2 CGO_ENABLED=1
r=/Users/thesyncim/GolandProjects/govpx
p=/private/tmp/govpx-astra-hotpaths52
proof=/private/tmp/govpx-astra-hotpaths52-proof
"$r/scripts/go.sh" -C "$p" fmt ./internal/pixel ./scripts
"$r/scripts/go.sh" -C "$p" run scripts/gensimd.go
"$r/scripts/go.sh" -C "$p" test -pgo=off ./internal/pixel ./internal/vp8/dsp ./internal/vp8/decoder
"$r/scripts/go.sh" -C "$p" test -pgo=off -race -gcflags=all=-d=checkptr=2 ./internal/pixel ./internal/vp8/dsp ./internal/vp8/decoder -run '(LoopFilter|MacroInternal|MacroAxis|NormalFilter)' -count=1
"$r/scripts/go.sh" -C "$p" test -pgo=off -c -o "$proof/final-dsp.test" ./internal/vp8/dsp
"$r/scripts/go.sh" -C "$p" test -pgo=off -c -o "$proof/final-decoder.test" ./internal/vp8/decoder
"$r/scripts/go.sh" -C "$p" build -pgo=off -o "$proof/final-whole-bench" ./cmd/govpx-bench

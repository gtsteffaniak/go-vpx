from pathlib import Path
import subprocess,re,json,hashlib
p=Path(__file__).resolve().parents[1]
tool='/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/llvm-objdump'
out={}
for v in ['parent','candidate']:
 s=subprocess.check_output([tool,'-d','--disassemble-symbols=_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedHorizontal',str(p/(v+'-pixel.test'))],text=True)
 (p/'evidence'/(v+'-H-llvm.txt')).write_text(s)
 ins=[]
 for line in s.splitlines():
  m=re.match(r'\s*[0-9a-f]+:\s+[0-9a-f]{8}\s+(.*)',line)
  if m:ins.append(m[1])
 out[v]={'instruction_entries':len(ins),'binary_sha256':hashlib.sha256((p/(v+'-pixel.test')).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((p/v/'internal/pixel/loopfilter_macro_internal_fused_arm64.go').read_bytes()).hexdigest(),'calls':[x for x in ins if re.match(r'(bl|blr)\s',x)],'vector_stack_ops':[x for x in ins if re.match(r'(stp|ldp|str|ldr)\s+[qds][0-9]+',x) and ('[sp' in x or '[x29' in x)]}
assert out['parent']['instruction_entries']==364 and out['candidate']['instruction_entries']==557
assert all(not v['calls'] and not v['vector_stack_ops'] for v in out.values())
(p/'evidence/codegen-screen.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

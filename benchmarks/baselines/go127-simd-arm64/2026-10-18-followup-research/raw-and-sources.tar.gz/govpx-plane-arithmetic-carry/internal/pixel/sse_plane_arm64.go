//go:build goexperiment.simd && arm64 && !purego

package pixel

import ("simd/archsimd";"unsafe")

// SSEPlane16 scans complete rows instead of revisiting each 16-pixel column.
// Four-row chunks contain at most 65536 pixels, so their unsigned squared sums
// fit uint32; widening each chunk before adding preserves the full frame sum.
// Height <= 4096 also makes each original column sum fit uint32 exactly.
func SSEPlane16(src []byte, ss int, ref []byte, rs, w, h int) (uint64, bool) {
	if !Enabled || w <= 0 || w > 16384 || w&15 != 0 || h <= 0 || h > 4096 || ss < 0 || rs < 0 || len(src) < w || len(ref) < w {
		return 0, false
	}
	if h > 1 && (ss > (len(src)-w)/(h-1) || rs > (len(ref)-w)/(h-1)) {
		return 0, false
	}
	sp,rp:=unsafe.Pointer(unsafe.SliceData(src)),unsafe.Pointer(unsafe.SliceData(ref))
	var total uint64
	for y := 0; y < h; {
		var l,hv,lc,hc archsimd.Uint16x8
		end := min(y+4, h)
		for ; y < end; y++ {
			so, ro := y*ss, y*rs
			a,b:=unsafe.Add(sp,so),unsafe.Add(rp,ro)
			for x := 0; x <= w-16; x += 16 {
				av,bv:=load16(unsafe.Add(a,x)),load16(unsafe.Add(b,x));d:=av.Max(bv).Sub(av.Min(bv));dh:=highBytes(d)
 nl,nh:=l.Add(d.MulWidenLo(d)),hv.Add(dh.MulWidenLo(dh))
 lc=lc.Sub(l.Greater(nl).ToInt16x8().ToBits());hc=hc.Sub(hv.Greater(nh).ToInt16x8().ToBits());l,hv=nl,nh
			}
		}
		ls:=l.ExtendLo4ToUint32().Add(l.HiToLo().ExtendLo4ToUint32()).Add(hv.ExtendLo4ToUint32()).Add(hv.HiToLo().ExtendLo4ToUint32())
 cs:=lc.ExtendLo4ToUint32().Add(lc.HiToLo().ExtendLo4ToUint32()).Add(hc.ExtendLo4ToUint32()).Add(hc.HiToLo().ExtendLo4ToUint32())
 total+=uint64(uint32(sum32(ls.BitsToInt32()))+(uint32(sum32(cs.BitsToInt32()))<<16))
	}
	return total, true
}

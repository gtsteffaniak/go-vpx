from pathlib import Path
import shutil
p=Path('/private/tmp/govpx-plane-arithmetic-carry');shutil.copytree('/private/tmp/govpx-plane-arithmetic-pointer',p,dirs_exist_ok=True)
f=p/'internal/pixel/sse_plane_arm64.go';s=f.read_text().replace('var lo, hi archsimd.Int32x4','var l,hv,lc,hc archsimd.Uint16x8')
s=s.replace('lo, hi = ssePacket(lo, hi, load16(unsafe.Add(a,x)),load16(unsafe.Add(b,x)))','''av,bv:=load16(unsafe.Add(a,x)),load16(unsafe.Add(b,x));d:=av.Max(bv).Sub(av.Min(bv));dh:=highBytes(d)
 nl,nh:=l.Add(d.MulWidenLo(d)),hv.Add(dh.MulWidenLo(dh))
 lc=lc.Sub(l.Greater(nl).ToInt16x8().ToBits());hc=hc.Sub(hv.Greater(nh).ToInt16x8().ToBits());l,hv=nl,nh''')
s=s.replace('total += uint64(uint32(sum32(lo.Add(hi))))','''ls:=l.ExtendLo4ToUint32().Add(l.HiToLo().ExtendLo4ToUint32()).Add(hv.ExtendLo4ToUint32()).Add(hv.HiToLo().ExtendLo4ToUint32())
 cs:=lc.ExtendLo4ToUint32().Add(lc.HiToLo().ExtendLo4ToUint32()).Add(hc.ExtendLo4ToUint32()).Add(hc.HiToLo().ExtendLo4ToUint32())
 total+=uint64(uint32(sum32(ls.BitsToInt32()))+(uint32(sum32(cs.BitsToInt32()))<<16))''')
assert 'lo, hi =' not in s;f.write_text(s);print('ready')

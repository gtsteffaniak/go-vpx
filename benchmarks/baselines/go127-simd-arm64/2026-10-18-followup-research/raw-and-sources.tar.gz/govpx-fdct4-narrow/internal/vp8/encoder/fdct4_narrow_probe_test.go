package encoder
import("testing";"fmt")
var fdct4ProbeSink [16]int16
func BenchmarkFDCT4NarrowProbe(b *testing.B){for _,s:=range []int{4,17,1312}{for _,pat:=range []int{0,1,2,3}{b.Run(fmt.Sprintf("stride%d/pattern%d",s,pat),func(b *testing.B){
 in:=make([]int16,3*s+4);for i:=range in{switch pat{case 0:in[i]=int16(i*37%511-255);case 1:in[i]=255;case 2:if i&1==0{in[i]=-255}else{in[i]=255}}}
 var out,want [16]int16;forwardDCT4x4Scalar(in,s,&want);ForwardDCT4x4(in,s,&out);if out!=want{b.Fatal(out,want)};b.ReportAllocs();for b.Loop(){ForwardDCT4x4(in,s,&out)};if out!=want{b.Fatal(out,want)};fdct4ProbeSink=out
 })}}}

from pathlib import Path
import os,re,json,subprocess,statistics
vs=['parent','narrow'];out=Path('/private/tmp/govpx-fdct4-measurements');out.mkdir(exist_ok=True);env=dict(os.environ,GOMAXPROCS='1');r={v:{} for v in vs}
for rnd,order in enumerate([vs,vs[::-1],vs],1):
 for v in order:
  p=subprocess.run(['/private/tmp/govpx-fdct4-'+v+'.test','-test.run=^$','-test.bench=^BenchmarkFDCT4NarrowProbe$','-test.benchtime=100ms','-test.cpu=1','-test.benchmem'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'{rnd}-{v}.txt').write_text(p.stdout);assert p.returncode==0,p.stdout
  found=re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op[^\n]*?\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout,re.M);assert len(found)==12
  for name,ns,b,a in found:assert b==a=='0';r[v].setdefault(name,[]).append(float(ns))
 print('round',rnd,'done',flush=True)
s={k:{'samples':{v:r[v][k] for v in vs},'speedup':statistics.median(r['parent'][k])/statistics.median(r['narrow'][k])} for k in r['parent']};(out/'summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))

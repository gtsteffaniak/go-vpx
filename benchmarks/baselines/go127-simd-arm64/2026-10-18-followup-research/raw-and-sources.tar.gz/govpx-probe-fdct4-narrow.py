from pathlib import Path
import subprocess,tarfile,io
root=Path('/Users/thesyncim/GolandProjects/govpx');raw=subprocess.check_output(['git','archive','HEAD',':(exclude)benchmarks/baselines'],cwd=root)
for v in ['parent','narrow']:
 p=Path('/private/tmp/govpx-fdct4-'+v);p.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(p)
 fixture='''package encoder
import("testing";"fmt")
var fdct4ProbeSink [16]int16
func BenchmarkFDCT4NarrowProbe(b *testing.B){for _,s:=range []int{4,17,1312}{for _,pat:=range []int{0,1,2,3}{b.Run(fmt.Sprintf("stride%d/pattern%d",s,pat),func(b *testing.B){
 in:=make([]int16,3*s+4);for i:=range in{switch pat{case 0:in[i]=int16(i*37%511-255);case 1:in[i]=255;case 2:if i&1==0{in[i]=-255}else{in[i]=255}}}
 var out,want [16]int16;forwardDCT4x4Scalar(in,s,&want);ForwardDCT4x4(in,s,&out);if out!=want{b.Fatal(out,want)};b.ReportAllocs();for b.Loop(){ForwardDCT4x4(in,s,&out)};if out!=want{b.Fatal(out,want)};fdct4ProbeSink=out
 })}}}
'''
 (p/'internal/vp8/encoder/fdct4_narrow_probe_test.go').write_text(fixture)
 if v=='parent':continue
 f=p/'internal/vp8/encoder/transform_simd.go';s=f.read_text();marker='\ta, b, c, d := pixel.Transpose4';s=s.replace(marker,'\tif !walsh {return forward4NarrowProbe(input,stride,output)}\n'+marker,1);f.write_text(s)
 (p/'internal/vp8/encoder/fdct4_narrow_probe_arm64.go').write_text('''//go:build goexperiment.simd && arm64 && !purego
package encoder
import("simd/archsimd";"unsafe")
func fdctLoad4Probe(s []int16)archsimd.Int16x8{_=s[3];return archsimd.Uint64x2{}.SetElem(0,*(*uint64)(unsafe.Pointer(unsafe.SliceData(s)))).ReshapeToUint16s().BitsToInt16()}
func fdctTranspose4Probe(a,b,c,d archsimd.Int16x8)(archsimd.Int16x8,archsimd.Int16x8,archsimd.Int16x8,archsimd.Int16x8){
 ab,cd:=a.InterleaveLo(b).ToBits().ReshapeToUint32s(),c.InterleaveLo(d).ToBits().ReshapeToUint32s()
 lo,hi:=ab.InterleaveLo(cd).ReshapeToUint16s().BitsToInt16(),ab.InterleaveHi(cd).ReshapeToUint16s().BitsToInt16()
 return lo,lo.HiToLo(),hi,hi.HiToLo()
}
func forward4NarrowProbe(input []int16,stride int,output *[16]int16)bool{
 r0,r1,r2,r3:=fdctLoad4Probe(input),fdctLoad4Probe(input[stride:]),fdctLoad4Probe(input[2*stride:]),fdctLoad4Probe(input[3*stride:])
 if r0.Abs().ToBits().Max(r1.Abs().ToBits()).Max(r2.Abs().ToBits()).Max(r3.Abs().ToBits()).ReduceMax()>255{return false}
 a,b,c,d:=fdctTranspose4Probe(r0,r1,r2,r3)
 x,y:=a.Add(d).ShiftAllLeft(3),b.Add(c).ShiftAllLeft(3)
 z,w:=b.Sub(c).ShiftAllLeft(3),a.Sub(d).ShiftAllLeft(3)
 v0,v2:=x.Add(y),x.Sub(y)
 k1,k2,kn:=archsimd.BroadcastInt16x8(2217),archsimd.BroadcastInt16x8(5352),archsimd.BroadcastInt16x8(-5352)
 v1:=vp8Right12(z.MulWidenLo(k1).Add(w.MulWidenLo(k2)).Add(archsimd.BroadcastInt32x4(14500))).TruncToInt16()
 v3:=vp8Right12(w.MulWidenLo(k1).Add(z.MulWidenLo(kn)).Add(archsimd.BroadcastInt32x4(7500))).TruncToInt16()
 a,b,c,d=fdctTranspose4Probe(v0,v1,v2,v3)
 x,y,z,w=a.Add(d),b.Add(c),b.Sub(c),a.Sub(d)
 seven:=archsimd.BroadcastInt16x8(7)
 v0,v2=x.Add(y).Add(seven).ShiftAllRight(4),x.Sub(y).Add(seven).ShiftAllRight(4)
 v1=vp8Right16(z.MulWidenLo(k1).Add(w.MulWidenLo(k2)).Add(archsimd.BroadcastInt32x4(12000))).TruncToInt16().Add(w.NotEqual(archsimd.Int16x8{}).ToInt16x8().And(archsimd.BroadcastInt16x8(1)))
 v3=vp8Right16(w.MulWidenLo(k1).Add(z.MulWidenLo(kn)).Add(archsimd.BroadcastInt32x4(51000))).TruncToInt16()
 ptr:=unsafe.Pointer(output)
 *(*uint64)(ptr)=v0.ToBits().ReshapeToUint64s().GetElem(0)
 *(*uint64)(unsafe.Add(ptr,8))=v1.ToBits().ReshapeToUint64s().GetElem(0)
 *(*uint64)(unsafe.Add(ptr,16))=v2.ToBits().ReshapeToUint64s().GetElem(0)
 *(*uint64)(unsafe.Add(ptr,24))=v3.ToBits().ReshapeToUint64s().GetElem(0)
 return true
}
''')
print('ready')

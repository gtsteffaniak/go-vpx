from pathlib import Path
import os,subprocess,re,json,statistics
prefix='/private/tmp/govpx-plane-arithmetic-';vs=['parent','carry'];out=Path(prefix+'carry-measurements');out.mkdir(exist_ok=True);env=dict(os.environ,GOMAXPROCS='1');rows={v:{} for v in vs}
for rnd,order in enumerate([vs,vs[::-1],vs,vs[::-1]],1):
 for v in order:
  p=subprocess.run([prefix+v+'.test','-test.run=^$','-test.bench=^BenchmarkLoopFilterLumaSSENative$','-test.benchtime=150ms','-test.cpu=1','-test.benchmem'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/f'{rnd}-{v}.txt').write_text(p.stdout);assert p.returncode==0,p.stdout
  found=re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op[^\n]*?\s+(\d+) B/op\s+(\d+) allocs/op',p.stdout,re.M);assert len(found)==4
  for name,ns,b,a in found:assert b==a=='0';rows[v].setdefault(name,[]).append(float(ns))
 print('round',rnd,'done',flush=True)
s={k:{'samples':{v:rows[v][k] for v in vs},'speedups':{v:statistics.median(rows['parent'][k])/statistics.median(rows[v][k]) for v in vs}} for k in rows['parent']};(out/'summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))

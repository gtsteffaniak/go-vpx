
/private/tmp/govpx-pr39-arm-libvpx-bench:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000e9ea0 <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical>:
1000e9ea0: f9400b90    	ldr	x16, [x28, #0x10]
1000e9ea4: d10343f1    	sub	x17, sp, #0xd0
1000e9ea8: eb10023f    	cmp	x17, x16
1000e9eac: 54005589    	b.ls	0x1000ea95c <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical+0xabc>
1000e9eb0: d10543f4    	sub	x20, sp, #0x150
1000e9eb4: a93ffa9d    	stp	x29, x30, [x20, #-0x8]
1000e9eb8: 9100029f    	mov	sp, x20
1000e9ebc: d10023fd    	sub	x29, sp, #0x8
1000e9ec0: f900bbe3    	str	x3, [sp, #0x170]
1000e9ec4: f900bfe4    	str	x4, [sp, #0x178]
1000e9ec8: f900c3e5    	str	x5, [sp, #0x180]
1000e9ecc: f900c7e6    	str	x6, [sp, #0x188]
1000e9ed0: f900cbe7    	str	x7, [sp, #0x190]
1000e9ed4: f900b3e1    	str	x1, [sp, #0x160]
1000e9ed8: f900afe0    	str	x0, [sp, #0x158]
1000e9edc: f900b7e2    	str	x2, [sp, #0x168]
1000e9ee0: 97fffb5c    	bl	0x1000e8c50 <_github.com/thesyncim/govpx/internal/pixel.loadLFColumnsWide20>
1000e9ee4: 910123e4    	add	x4, sp, #0x48
1000e9ee8: b27e03e5    	orr	x5, xzr, #0x4
1000e9eec: a8817c9f    	stp	xzr, xzr, [x4], #0x10
1000e9ef0: a8817c9f    	stp	xzr, xzr, [x4], #0x10
1000e9ef4: a8817c9f    	stp	xzr, xzr, [x4], #0x10
1000e9ef8: a8817c9f    	stp	xzr, xzr, [x4], #0x10
1000e9efc: d10004a5    	sub	x5, x5, #0x1
1000e9f00: b5ffff65    	cbnz	x5, 0x1000e9eec <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical+0x4c>
1000e9f04: 3c8483e1    	stur	q1, [sp, #0x48]
1000e9f08: 3c8583e2    	stur	q2, [sp, #0x58]
1000e9f0c: 3c8683e3    	stur	q3, [sp, #0x68]
1000e9f10: 6e226468    	umax.16b	v8, v3, v2
1000e9f14: 6e226c69    	umin.16b	v9, v3, v2
1000e9f18: 6e298508    	sub.16b	v8, v8, v9
1000e9f1c: 6e2464a9    	umax.16b	v9, v5, v4
1000e9f20: 6e246caa    	umin.16b	v10, v5, v4
1000e9f24: 6e2a8529    	sub.16b	v9, v9, v10
1000e9f28: 6e286528    	umax.16b	v8, v9, v8
1000e9f2c: 6e236489    	umax.16b	v9, v4, v3
1000e9f30: 6e236c8a    	umin.16b	v10, v4, v3
1000e9f34: 6e2a8529    	sub.16b	v9, v9, v10
1000e9f38: 6e290d29    	uqadd.16b	v9, v9, v9
1000e9f3c: 6e2264aa    	umax.16b	v10, v5, v2
1000e9f40: 6e226cab    	umin.16b	v11, v5, v2
1000e9f44: 6e2b854a    	sub.16b	v10, v10, v11
1000e9f48: b000333b    	adrp	x27, 0x10074e000 <_runtime.mheap_+0x189a0>
1000e9f4c: 9126c37b    	add	x27, x27, #0x9b0
1000e9f50: 3dc0036b    	ldr	q11, [x27]
1000e9f54: 6e2b454a    	ushl.16b	v10, v10, v11
1000e9f58: 6e290d49    	uqadd.16b	v9, v10, v9
1000e9f5c: 4f00e40a    	movi.16b	v10, #0x0
1000e9f60: f940bfe4    	ldr	x4, [sp, #0x178]
1000e9f64: 4eaa1d4b    	mov.16b	v11, v10
1000e9f68: 4e011c8a    	mov.b	v10[0], w4
1000e9f6c: 4e01054a    	dup.16b	v10, v10[0]
1000e9f70: 6e20642c    	umax.16b	v12, v1, v0
1000e9f74: 6e206c20    	umin.16b	v0, v1, v0
1000e9f78: 6e208580    	sub.16b	v0, v12, v0
1000e9f7c: 6e286400    	umax.16b	v0, v0, v8
1000e9f80: 6e21644c    	umax.16b	v12, v2, v1
1000e9f84: 6e216c4d    	umin.16b	v13, v2, v1
1000e9f88: 6e2d858c    	sub.16b	v12, v12, v13
1000e9f8c: 6e206580    	umax.16b	v0, v12, v0
1000e9f90: 6e2564cc    	umax.16b	v12, v6, v5
1000e9f94: 6e256ccd    	umin.16b	v13, v6, v5
1000e9f98: 6e2d858c    	sub.16b	v12, v12, v13
1000e9f9c: 6e206580    	umax.16b	v0, v12, v0
1000e9fa0: 6e2664ec    	umax.16b	v12, v7, v6
1000e9fa4: 6e266ced    	umin.16b	v13, v7, v6
1000e9fa8: 6e2d858c    	sub.16b	v12, v12, v13
1000e9fac: 6e206580    	umax.16b	v0, v12, v0
1000e9fb0: f940c7e4    	ldr	x4, [sp, #0x188]
1000e9fb4: 4eab1d6c    	mov.16b	v12, v11
1000e9fb8: 4e011c8b    	mov.b	v11[0], w4
1000e9fbc: 4e01056b    	dup.16b	v11, v11[0]
1000e9fc0: 6e293d49    	cmhs.16b	v9, v10, v9
1000e9fc4: 6e203d60    	cmhs.16b	v0, v11, v0
1000e9fc8: 4e201d20    	and.16b	v0, v9, v0
1000e9fcc: 4e083c04    	mov.d	x4, v0[0]
1000e9fd0: 4e183c05    	mov.d	x5, v0[1]
1000e9fd4: d503201f    	nop
1000e9fd8: d503201f    	nop
1000e9fdc: d503201f    	nop
1000e9fe0: d503201f    	nop
1000e9fe4: d503201f    	nop
1000e9fe8: d503201f    	nop
1000e9fec: d503201f    	nop
1000e9ff0: d503201f    	nop
1000e9ff4: aa0400a4    	orr	x4, x5, x4
1000e9ff8: b4000fe4    	cbz	x4, 0x1000ea1f4 <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical+0x354>
1000e9ffc: f940cbe5    	ldr	x5, [sp, #0x190]
1000ea000: 4eac1d89    	mov.16b	v9, v12
1000ea004: 4e011cac    	mov.b	v12[0], w5
1000ea008: 4e01058a    	dup.16b	v10, v12[0]
1000ea00c: 4f04e40c    	movi.16b	v12, #0x80
1000ea010: 6e2c1c42    	eor.16b	v2, v2, v12
1000ea014: 6e2c1c63    	eor.16b	v3, v3, v12
1000ea018: 6e2c1c8d    	eor.16b	v13, v4, v12
1000ea01c: 6e2c1cae    	eor.16b	v14, v5, v12
1000ea020: 4e2e2c4f    	sqsub.16b	v15, v2, v14
1000ea024: 4e232db0    	sqsub.16b	v16, v13, v3
1000ea028: 4e300def    	sqadd.16b	v15, v15, v16
1000ea02c: 4e300def    	sqadd.16b	v15, v15, v16
1000ea030: 4e2f0e0f    	sqadd.16b	v15, v16, v15
1000ea034: 4e201def    	and.16b	v15, v15, v0
1000ea038: 4e20b9f0    	abs.16b	v16, v15
1000ea03c: 6e30aa10    	umaxv.16b	b16, v16
1000ea040: 0e013e06    	umov.b	w6, v16[0]
1000ea044: d3401cc6    	ubfx	x6, x6, #0, #8
1000ea048: d503201f    	nop
1000ea04c: d503201f    	nop
1000ea050: d503201f    	nop
1000ea054: d503201f    	nop
1000ea058: d503201f    	nop
1000ea05c: 6e2a3508    	cmhi.16b	v8, v8, v10
1000ea060: 71000cdf    	cmp	w6, #0x3
1000ea064: 54000c43    	b.lo	0x1000ea1ec <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical+0x34c>
1000ea068: 6e2c1c21    	eor.16b	v1, v1, v12
1000ea06c: 6e2c1cca    	eor.16b	v10, v6, v12
1000ea070: 4f00e470    	movi.16b	v16, #0x3
1000ea074: 4f00e491    	movi.16b	v17, #0x4
1000ea078: 4e281df2    	and.16b	v18, v15, v8
1000ea07c: 4e300e50    	sqadd.16b	v16, v18, v16
1000ea080: 4e310e51    	sqadd.16b	v17, v18, v17
1000ea084: 9000333b    	adrp	x27, 0x10074e000 <_runtime.mheap_+0x189a0>
1000ea088: 9127037b    	add	x27, x27, #0x9c0
1000ea08c: 3dc00372    	ldr	q18, [x27]
1000ea090: 4e324610    	sshl.16b	v16, v16, v18
1000ea094: 4e300c63    	sqadd.16b	v3, v3, v16
1000ea098: 4e324630    	sshl.16b	v16, v17, v18
1000ea09c: 4e302dad    	sqsub.16b	v13, v13, v16
1000ea0a0: 6e205908    	mvn.16b	v8, v8
1000ea0a4: 4e281de8    	and.16b	v8, v15, v8
1000ea0a8: 0f08a50f    	sshll.8h	v15, v8, #0x0
1000ea0ac: 4f08a508    	sshll2.8h	v8, v8, #0x0
1000ea0b0: 4f00e410    	movi.16b	v16, #0x0
1000ea0b4: d2800366    	mov	x6, #0x1b               ; =27
1000ea0b8: 4eb01e11    	mov.16b	v17, v16
1000ea0bc: 4e021cd0    	mov.h	v16[0], w6
1000ea0c0: 4e020610    	dup.8h	v16, v16[0]
1000ea0c4: 4e709df2    	mul.8h	v18, v15, v16
1000ea0c8: 4e709d10    	mul.8h	v16, v8, v16
1000ea0cc: b24017e6    	orr	x6, xzr, #0x3f
1000ea0d0: 4eb11e33    	mov.16b	v19, v17
1000ea0d4: 4e021cd1    	mov.h	v17[0], w6
1000ea0d8: 4e020631    	dup.8h	v17, v17[0]
1000ea0dc: 4e718652    	add.8h	v18, v18, v17
1000ea0e0: 4e718610    	add.8h	v16, v16, v17
1000ea0e4: 9000333b    	adrp	x27, 0x10074e000 <_runtime.mheap_+0x189a0>
1000ea0e8: 9127837b    	add	x27, x27, #0x9e0
1000ea0ec: 3dc00374    	ldr	q20, [x27]
1000ea0f0: 4e744652    	sshl.8h	v18, v18, v20
1000ea0f4: 0e212a52    	xtn.8b	v18, v18
1000ea0f8: 4e744610    	sshl.8h	v16, v16, v20
1000ea0fc: 0e212a10    	xtn.8b	v16, v16
1000ea100: d2800246    	mov	x6, #0x12               ; =18
1000ea104: 4eb31e75    	mov.16b	v21, v19
1000ea108: 4e021cd3    	mov.h	v19[0], w6
1000ea10c: 4e020673    	dup.8h	v19, v19[0]
1000ea110: 4e6f9e76    	mul.8h	v22, v19, v15
1000ea114: 4e7186d6    	add.8h	v22, v22, v17
1000ea118: 4e689e73    	mul.8h	v19, v19, v8
1000ea11c: 4e718673    	add.8h	v19, v19, v17
1000ea120: 4e7446d6    	sshl.8h	v22, v22, v20
1000ea124: 0e212ad6    	xtn.8b	v22, v22
1000ea128: 4e744673    	sshl.8h	v19, v19, v20
1000ea12c: 0e212a73    	xtn.8b	v19, v19
1000ea130: d2800126    	mov	x6, #0x9                ; =9
1000ea134: 4e021cd5    	mov.h	v21[0], w6
1000ea138: 4e0206b5    	dup.8h	v21, v21[0]
1000ea13c: 4e6f9eaf    	mul.8h	v15, v21, v15
1000ea140: 4e7185ef    	add.8h	v15, v15, v17
1000ea144: 4e689ea8    	mul.8h	v8, v21, v8
1000ea148: 4e718508    	add.8h	v8, v8, v17
1000ea14c: 4e7445ef    	sshl.8h	v15, v15, v20
1000ea150: 0e2129ef    	xtn.8b	v15, v15
1000ea154: 4e744508    	sshl.8h	v8, v8, v20
1000ea158: 0e212908    	xtn.8b	v8, v8
1000ea15c: 4ed03a50    	zip1.2d	v16, v18, v16
1000ea160: 4e300c63    	sqadd.16b	v3, v3, v16
1000ea164: 6e2c1c63    	eor.16b	v3, v3, v12
1000ea168: 4e302dad    	sqsub.16b	v13, v13, v16
1000ea16c: 4ed33ad0    	zip1.2d	v16, v22, v19
1000ea170: 4e300c42    	sqadd.16b	v2, v2, v16
1000ea174: 6e2c1c42    	eor.16b	v2, v2, v12
1000ea178: 4e302dce    	sqsub.16b	v14, v14, v16
1000ea17c: 4ec839e8    	zip1.2d	v8, v15, v8
1000ea180: 4e280c21    	sqadd.16b	v1, v1, v8
1000ea184: 6e2c1c21    	eor.16b	v1, v1, v12
1000ea188: 4e282d48    	sqsub.16b	v8, v10, v8
1000ea18c: d503201f    	nop
1000ea190: d503201f    	nop
1000ea194: d503201f    	nop
1000ea198: d503201f    	nop
1000ea19c: d503201f    	nop
1000ea1a0: d503201f    	nop
1000ea1a4: 6e2c1da4    	eor.16b	v4, v13, v12
1000ea1a8: d503201f    	nop
1000ea1ac: 6e2c1dc5    	eor.16b	v5, v14, v12
1000ea1b0: d503201f    	nop
1000ea1b4: 6e2c1d06    	eor.16b	v6, v8, v12
1000ea1b8: d503201f    	nop
1000ea1bc: d503201f    	nop
1000ea1c0: d503201f    	nop
1000ea1c4: d503201f    	nop
1000ea1c8: d503201f    	nop
1000ea1cc: d503201f    	nop
1000ea1d0: d503201f    	nop
1000ea1d4: d503201f    	nop
1000ea1d8: d503201f    	nop
1000ea1dc: d503201f    	nop
1000ea1e0: 3c8483e1    	stur	q1, [sp, #0x48]
1000ea1e4: 3c8583e2    	stur	q2, [sp, #0x58]
1000ea1e8: 3c8683e3    	stur	q3, [sp, #0x68]
1000ea1ec: 9a9f37e6    	cset	x6, hs
1000ea1f0: 14000004    	b	0x1000ea200 <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical+0x360>
1000ea1f4: f940cbe5    	ldr	x5, [sp, #0x190]
1000ea1f8: 4eac1d89    	mov.16b	v9, v12
1000ea1fc: aa1f03e6    	mov	x6, xzr
1000ea200: f940afe0    	ldr	x0, [sp, #0x158]
1000ea204: 3cc04001    	ldur	q1, [x0, #0x4]
1000ea208: 91001007    	add	x7, x0, #0x4
1000ea20c: f940bbe3    	ldr	x3, [sp, #0x170]
1000ea210: 8b0308e8    	add	x8, x7, x3, lsl #2
1000ea214: 3dc00102    	ldr	q2, [x8]
1000ea218: 8b030ce9    	add	x9, x7, x3, lsl #3
1000ea21c: 3dc00123    	ldr	q3, [x9]
1000ea220: d37ef46a    	lsl	x10, x3, #2
1000ea224: 8b0a054a    	add	x10, x10, x10, lsl #1
1000ea228: 8b07014a    	add	x10, x10, x7
1000ea22c: 3dc00148    	ldr	q8, [x10]
1000ea230: 4e826821    	trn2.4s	v1, v1, v2
1000ea234: 4e886862    	trn2.4s	v2, v3, v8
1000ea238: 4ec23821    	zip1.2d	v1, v1, v2
1000ea23c: 8b0300eb    	add	x11, x7, x3
1000ea240: 3dc00162    	ldr	q2, [x11]
1000ea244: 8b03086c    	add	x12, x3, x3, lsl #2
1000ea248: 8b07018c    	add	x12, x12, x7
1000ea24c: 3dc00183    	ldr	q3, [x12]
1000ea250: 8b030c6d    	add	x13, x3, x3, lsl #3
1000ea254: 8b0701ad    	add	x13, x13, x7
1000ea258: 3dc001a8    	ldr	q8, [x13]
1000ea25c: d28001ae    	mov	x14, #0xd               ; =13
1000ea260: 9b0e1c6e    	madd	x14, x3, x14, x7
1000ea264: 3dc001ca    	ldr	q10, [x14]
1000ea268: 4e836842    	trn2.4s	v2, v2, v3
1000ea26c: 4e8a6903    	trn2.4s	v3, v8, v10
1000ea270: 4ec33842    	zip1.2d	v2, v2, v3
1000ea274: 8b0304ef    	add	x15, x7, x3, lsl #1
1000ea278: 3dc001e3    	ldr	q3, [x15]
1000ea27c: 8b030070    	add	x16, x3, x3
1000ea280: 8b100611    	add	x17, x16, x16, lsl #1
1000ea284: 8b070231    	add	x17, x17, x7
1000ea288: 3dc00228    	ldr	q8, [x17]
1000ea28c: 8b100a10    	add	x16, x16, x16, lsl #2
1000ea290: 8b070210    	add	x16, x16, x7
1000ea294: 3dc0020a    	ldr	q10, [x16]
1000ea298: 4e886863    	trn2.4s	v3, v3, v8
1000ea29c: 8b030473    	add	x19, x3, x3, lsl #1
1000ea2a0: 8b070273    	add	x19, x19, x7
1000ea2a4: 3dc00268    	ldr	q8, [x19]
1000ea2a8: d37df074    	lsl	x20, x3, #3
1000ea2ac: cb030294    	sub	x20, x20, x3
1000ea2b0: 8b070294    	add	x20, x20, x7
1000ea2b4: 3dc0028c    	ldr	q12, [x20]
1000ea2b8: d2800175    	mov	x21, #0xb               ; =11
1000ea2bc: 9b151c75    	madd	x21, x3, x21, x7
1000ea2c0: 3dc002ad    	ldr	q13, [x21]
1000ea2c4: d37cec76    	lsl	x22, x3, #4
1000ea2c8: cb0306d7    	sub	x23, x22, x3, lsl #1
1000ea2cc: 8b0702f7    	add	x23, x23, x7
1000ea2d0: 3dc002ee    	ldr	q14, [x23]
1000ea2d4: 4e8e694a    	trn2.4s	v10, v10, v14
1000ea2d8: 4eca3863    	zip1.2d	v3, v3, v10
1000ea2dc: cb0302d6    	sub	x22, x22, x3
1000ea2e0: 8b0702c7    	add	x7, x22, x7
1000ea2e4: 3dc000ea    	ldr	q10, [x7]
1000ea2e8: 4e8c6908    	trn2.4s	v8, v8, v12
1000ea2ec: 4e8a69aa    	trn2.4s	v10, v13, v10
1000ea2f0: 4eca3908    	zip1.2d	v8, v8, v10
1000ea2f4: 4e43282a    	trn1.8h	v10, v1, v3
1000ea2f8: 4e436821    	trn2.8h	v1, v1, v3
1000ea2fc: 4e482843    	trn1.8h	v3, v2, v8
1000ea300: 4e486842    	trn2.8h	v2, v2, v8
1000ea304: 4e032948    	trn1.16b	v8, v10, v3
1000ea308: 4e036943    	trn2.16b	v3, v10, v3
1000ea30c: 4e02282a    	trn1.16b	v10, v1, v2
1000ea310: 4e026821    	trn2.16b	v1, v1, v2
1000ea314: f940c3f6    	ldr	x22, [sp, #0x180]
1000ea318: 4ea91d22    	mov.16b	v2, v9
1000ea31c: 4e011ec9    	mov.b	v9[0], w22
1000ea320: 4e010529    	dup.16b	v9, v9[0]
1000ea324: 4e011ca2    	mov.b	v2[0], w5
1000ea328: 6e2764cc    	umax.16b	v12, v6, v7
1000ea32c: 6e276ccd    	umin.16b	v13, v6, v7
1000ea330: 6e2d858c    	sub.16b	v12, v12, v13
1000ea334: 6e28646d    	umax.16b	v13, v3, v8
1000ea338: 6e286c6e    	umin.16b	v14, v3, v8
1000ea33c: 6e2e85ad    	sub.16b	v13, v13, v14
1000ea340: 6e2c65ac    	umax.16b	v12, v13, v12
1000ea344: 6e27650d    	umax.16b	v13, v8, v7
1000ea348: 6e276d0e    	umin.16b	v14, v8, v7
1000ea34c: 6e2e85ad    	sub.16b	v13, v13, v14
1000ea350: 6e2d0dad    	uqadd.16b	v13, v13, v13
1000ea354: 6e26646e    	umax.16b	v14, v3, v6
1000ea358: 6e266c6f    	umin.16b	v15, v3, v6
1000ea35c: 6e2f85ce    	sub.16b	v14, v14, v15
1000ea360: 6e2464af    	umax.16b	v15, v5, v4
1000ea364: 6e246cb0    	umin.16b	v16, v5, v4
1000ea368: 6e3085ef    	sub.16b	v15, v15, v16
1000ea36c: 6e2c65ef    	umax.16b	v15, v15, v12
1000ea370: 6e2564d0    	umax.16b	v16, v6, v5
1000ea374: 6e256cd1    	umin.16b	v17, v6, v5
1000ea378: 6e318610    	sub.16b	v16, v16, v17
1000ea37c: 6e2f660f    	umax.16b	v15, v16, v15
1000ea380: 6e236550    	umax.16b	v16, v10, v3
1000ea384: 6e236d51    	umin.16b	v17, v10, v3
1000ea388: 6e318610    	sub.16b	v16, v16, v17
1000ea38c: 6e2f660f    	umax.16b	v15, v16, v15
1000ea390: 6e2a6430    	umax.16b	v16, v1, v10
1000ea394: 6e2a6c31    	umin.16b	v17, v1, v10
1000ea398: 6e318610    	sub.16b	v16, v16, v17
1000ea39c: 6e2f660f    	umax.16b	v15, v16, v15
1000ea3a0: 6e2f3d6f    	cmhs.16b	v15, v11, v15
1000ea3a4: d503201f    	nop
1000ea3a8: d503201f    	nop
1000ea3ac: 3c8783e4    	stur	q4, [sp, #0x78]
1000ea3b0: 3c8883e5    	stur	q5, [sp, #0x88]
1000ea3b4: 3c8983e6    	stur	q6, [sp, #0x98]
1000ea3b8: 3c8a83e7    	stur	q7, [sp, #0xa8]
1000ea3bc: 9000333b    	adrp	x27, 0x10074e000 <_runtime.mheap_+0x189a0>
1000ea3c0: 9126c37b    	add	x27, x27, #0x9b0
1000ea3c4: 3dc00364    	ldr	q4, [x27]
1000ea3c8: 6e2445c5    	ushl.16b	v5, v14, v4
1000ea3cc: 6e2d0ca5    	uqadd.16b	v5, v5, v13
1000ea3d0: 6e253d25    	cmhs.16b	v5, v9, v5
1000ea3d4: 4e2f1ca5    	and.16b	v5, v5, v15
1000ea3d8: 4e083ca5    	mov.d	x5, v5[0]
1000ea3dc: 4e183cb6    	mov.d	x22, v5[1]
1000ea3e0: d503201f    	nop
1000ea3e4: d503201f    	nop
1000ea3e8: d503201f    	nop
1000ea3ec: d503201f    	nop
1000ea3f0: d503201f    	nop
1000ea3f4: 4e010442    	dup.16b	v2, v2[0]
1000ea3f8: d503201f    	nop
1000ea3fc: d503201f    	nop
1000ea400: aa0502c5    	orr	x5, x22, x5
1000ea404: b40006a5    	cbz	x5, 0x1000ea4d8 <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical+0x638>
1000ea408: 6e22358c    	cmhi.16b	v12, v12, v2
1000ea40c: 4f04e40d    	movi.16b	v13, #0x80
1000ea410: 6e2d1cc6    	eor.16b	v6, v6, v13
1000ea414: 6e2d1ce7    	eor.16b	v7, v7, v13
1000ea418: 6e2d1d0e    	eor.16b	v14, v8, v13
1000ea41c: 6e2d1c6f    	eor.16b	v15, v3, v13
1000ea420: 4e2f2cd1    	sqsub.16b	v17, v6, v15
1000ea424: 4e2c1e31    	and.16b	v17, v17, v12
1000ea428: 4e272dd2    	sqsub.16b	v18, v14, v7
1000ea42c: 4e310e51    	sqadd.16b	v17, v18, v17
1000ea430: 4e310e51    	sqadd.16b	v17, v18, v17
1000ea434: 4e310e51    	sqadd.16b	v17, v18, v17
1000ea438: 4e251e25    	and.16b	v5, v17, v5
1000ea43c: 4e20b8b1    	abs.16b	v17, v5
1000ea440: 6e30aa31    	umaxv.16b	b17, v17
1000ea444: 0e013e25    	umov.b	w5, v17[0]
1000ea448: d3401ca5    	ubfx	x5, x5, #0, #8
1000ea44c: d503201f    	nop
1000ea450: d503201f    	nop
1000ea454: d503201f    	nop
1000ea458: d503201f    	nop
1000ea45c: d503201f    	nop
1000ea460: 710010bf    	cmp	w5, #0x4
1000ea464: 54000363    	b.lo	0x1000ea4d0 <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical+0x630>
1000ea468: 4f00e471    	movi.16b	v17, #0x3
1000ea46c: 4e310cb1    	sqadd.16b	v17, v5, v17
1000ea470: 4f00e492    	movi.16b	v18, #0x4
1000ea474: 4e320ca5    	sqadd.16b	v5, v5, v18
1000ea478: 9000333b    	adrp	x27, 0x10074e000 <_runtime.mheap_+0x189a0>
1000ea47c: 9127037b    	add	x27, x27, #0x9c0
1000ea480: 3dc00372    	ldr	q18, [x27]
1000ea484: 4e3244a5    	sshl.16b	v5, v5, v18
1000ea488: 4e252dce    	sqsub.16b	v14, v14, v5
1000ea48c: 4e324631    	sshl.16b	v17, v17, v18
1000ea490: 4e310ce7    	sqadd.16b	v7, v7, v17
1000ea494: 6e2d1ce7    	eor.16b	v7, v7, v13
1000ea498: 4f00e431    	movi.16b	v17, #0x1
1000ea49c: 4e3184a5    	add.16b	v5, v5, v17
1000ea4a0: 4e2444a4    	sshl.16b	v4, v5, v4
1000ea4a4: 6e205985    	mvn.16b	v5, v12
1000ea4a8: 4e251c84    	and.16b	v4, v4, v5
1000ea4ac: 4e240cc5    	sqadd.16b	v5, v6, v4
1000ea4b0: 6e2d1ca5    	eor.16b	v5, v5, v13
1000ea4b4: 4e242de4    	sqsub.16b	v4, v15, v4
1000ea4b8: d503201f    	nop
1000ea4bc: d503201f    	nop
1000ea4c0: 6e2d1dc8    	eor.16b	v8, v14, v13
1000ea4c4: 3c8983e5    	stur	q5, [sp, #0x98]
1000ea4c8: 3c8a83e7    	stur	q7, [sp, #0xa8]
1000ea4cc: 6e2d1c83    	eor.16b	v3, v4, v13
1000ea4d0: 9a9f37e5    	cset	x5, hs
1000ea4d4: aa0500c6    	orr	x6, x6, x5
1000ea4d8: 3cc04004    	ldur	q4, [x0, #0x4]
1000ea4dc: 3dc00105    	ldr	q5, [x8]
1000ea4e0: 3dc00126    	ldr	q6, [x9]
1000ea4e4: 3dc00147    	ldr	q7, [x10]
1000ea4e8: 4e852884    	trn1.4s	v4, v4, v5
1000ea4ec: 4e8728c5    	trn1.4s	v5, v6, v7
1000ea4f0: 4ec57884    	zip2.2d	v4, v4, v5
1000ea4f4: 3dc00165    	ldr	q5, [x11]
1000ea4f8: 3dc00186    	ldr	q6, [x12]
1000ea4fc: 3dc001a7    	ldr	q7, [x13]
1000ea500: 3dc001cc    	ldr	q12, [x14]
1000ea504: 4e8628a5    	trn1.4s	v5, v5, v6
1000ea508: 4e8c28e6    	trn1.4s	v6, v7, v12
1000ea50c: 4ec678a5    	zip2.2d	v5, v5, v6
1000ea510: 3dc001e6    	ldr	q6, [x15]
1000ea514: 3dc00227    	ldr	q7, [x17]
1000ea518: 3dc0020c    	ldr	q12, [x16]
1000ea51c: 3dc002ed    	ldr	q13, [x23]
1000ea520: 4e8728c6    	trn1.4s	v6, v6, v7
1000ea524: 4e8d2987    	trn1.4s	v7, v12, v13
1000ea528: 4ec778c6    	zip2.2d	v6, v6, v7
1000ea52c: 3dc00267    	ldr	q7, [x19]
1000ea530: 3dc0028c    	ldr	q12, [x20]
1000ea534: 3dc002ad    	ldr	q13, [x21]
1000ea538: 3dc000ee    	ldr	q14, [x7]
1000ea53c: 3c8b83e8    	stur	q8, [sp, #0xb8]
1000ea540: 3c8c83e3    	stur	q3, [sp, #0xc8]
1000ea544: 3c8d83ea    	stur	q10, [sp, #0xd8]
1000ea548: 3c8e83e1    	stur	q1, [sp, #0xe8]
1000ea54c: 4e8c28e7    	trn1.4s	v7, v7, v12
1000ea550: 4e8e29ac    	trn1.4s	v12, v13, v14
1000ea554: 4ecc78e7    	zip2.2d	v7, v7, v12
1000ea558: 4e46288c    	trn1.8h	v12, v4, v6
1000ea55c: 4e466884    	trn2.8h	v4, v4, v6
1000ea560: 4e4728a6    	trn1.8h	v6, v5, v7
1000ea564: 4e4768a5    	trn2.8h	v5, v5, v7
1000ea568: 4e062987    	trn1.16b	v7, v12, v6
1000ea56c: 4e066986    	trn2.16b	v6, v12, v6
1000ea570: 4e05288c    	trn1.16b	v12, v4, v5
1000ea574: 4e056884    	trn2.16b	v4, v4, v5
1000ea578: 6e2764c5    	umax.16b	v5, v6, v7
1000ea57c: 6e276ccd    	umin.16b	v13, v6, v7
1000ea580: 6e2d84a5    	sub.16b	v5, v5, v13
1000ea584: 6e3064a5    	umax.16b	v5, v5, v16
1000ea588: 6e2164ed    	umax.16b	v13, v7, v1
1000ea58c: 6e216cee    	umin.16b	v14, v7, v1
1000ea590: 6e2e85ad    	sub.16b	v13, v13, v14
1000ea594: 6e2d0dad    	uqadd.16b	v13, v13, v13
1000ea598: 6e2a64ce    	umax.16b	v14, v6, v10
1000ea59c: 6e2a6ccf    	umin.16b	v15, v6, v10
1000ea5a0: 6e2f85ce    	sub.16b	v14, v14, v15
1000ea5a4: 9000333b    	adrp	x27, 0x10074e000 <_runtime.mheap_+0x189a0>
1000ea5a8: 9126c37b    	add	x27, x27, #0x9b0
1000ea5ac: 3dc0036f    	ldr	q15, [x27]
1000ea5b0: 6e2f45ce    	ushl.16b	v14, v14, v15
1000ea5b4: 6e2d0dcd    	uqadd.16b	v13, v14, v13
1000ea5b8: 6e28646e    	umax.16b	v14, v3, v8
1000ea5bc: 6e286c68    	umin.16b	v8, v3, v8
1000ea5c0: 6e2885c8    	sub.16b	v8, v14, v8
1000ea5c4: 6e256508    	umax.16b	v8, v8, v5
1000ea5c8: 6e2a646e    	umax.16b	v14, v3, v10
1000ea5cc: 6e2a6c63    	umin.16b	v3, v3, v10
1000ea5d0: 6e2385c3    	sub.16b	v3, v14, v3
1000ea5d4: 6e286463    	umax.16b	v3, v3, v8
1000ea5d8: 6e266588    	umax.16b	v8, v12, v6
1000ea5dc: 6e266d8e    	umin.16b	v14, v12, v6
1000ea5e0: 6e2e8508    	sub.16b	v8, v8, v14
1000ea5e4: 6e236503    	umax.16b	v3, v8, v3
1000ea5e8: 6e2c6488    	umax.16b	v8, v4, v12
1000ea5ec: 6e2c6c8e    	umin.16b	v14, v4, v12
1000ea5f0: 6e2e8508    	sub.16b	v8, v8, v14
1000ea5f4: 6e236503    	umax.16b	v3, v8, v3
1000ea5f8: 6e2d3d2d    	cmhs.16b	v13, v9, v13
1000ea5fc: 6e233d63    	cmhs.16b	v3, v11, v3
1000ea600: 4e231da3    	and.16b	v3, v13, v3
1000ea604: 4e083c65    	mov.d	x5, v3[0]
1000ea608: 4e183c76    	mov.d	x22, v3[1]
1000ea60c: d503201f    	nop
1000ea610: d503201f    	nop
1000ea614: d503201f    	nop
1000ea618: d503201f    	nop
1000ea61c: d503201f    	nop
1000ea620: d503201f    	nop
1000ea624: aa0502c5    	orr	x5, x22, x5
1000ea628: b40006a5    	cbz	x5, 0x1000ea6fc <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical+0x85c>
1000ea62c: 6e2234a5    	cmhi.16b	v5, v5, v2
1000ea630: 4f04e40d    	movi.16b	v13, #0x80
1000ea634: 6e2d1d4a    	eor.16b	v10, v10, v13
1000ea638: 6e2d1c21    	eor.16b	v1, v1, v13
1000ea63c: 6e2d1cee    	eor.16b	v14, v7, v13
1000ea640: 6e2d1cd0    	eor.16b	v16, v6, v13
1000ea644: 4e302d51    	sqsub.16b	v17, v10, v16
1000ea648: 4e251e31    	and.16b	v17, v17, v5
1000ea64c: 4e212dd2    	sqsub.16b	v18, v14, v1
1000ea650: 4e310e51    	sqadd.16b	v17, v18, v17
1000ea654: 4e320e31    	sqadd.16b	v17, v17, v18
1000ea658: 4e310e51    	sqadd.16b	v17, v18, v17
1000ea65c: 4e231e23    	and.16b	v3, v17, v3
1000ea660: 4e20b871    	abs.16b	v17, v3
1000ea664: 6e30aa31    	umaxv.16b	b17, v17
1000ea668: 0e013e25    	umov.b	w5, v17[0]
1000ea66c: d3401ca5    	ubfx	x5, x5, #0, #8
1000ea670: d503201f    	nop
1000ea674: d503201f    	nop
1000ea678: d503201f    	nop
1000ea67c: d503201f    	nop
1000ea680: d503201f    	nop
1000ea684: 710010bf    	cmp	w5, #0x4
1000ea688: 54000363    	b.lo	0x1000ea6f4 <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical+0x854>
1000ea68c: 4f00e471    	movi.16b	v17, #0x3
1000ea690: 4e310c71    	sqadd.16b	v17, v3, v17
1000ea694: 4f00e492    	movi.16b	v18, #0x4
1000ea698: 4e320c63    	sqadd.16b	v3, v3, v18
1000ea69c: 9000333b    	adrp	x27, 0x10074e000 <_runtime.mheap_+0x189a0>
1000ea6a0: 9127037b    	add	x27, x27, #0x9c0
1000ea6a4: 3dc00372    	ldr	q18, [x27]
1000ea6a8: 4e324463    	sshl.16b	v3, v3, v18
1000ea6ac: 4e232dce    	sqsub.16b	v14, v14, v3
1000ea6b0: 4e324631    	sshl.16b	v17, v17, v18
1000ea6b4: 4e210e21    	sqadd.16b	v1, v17, v1
1000ea6b8: 6e2d1c21    	eor.16b	v1, v1, v13
1000ea6bc: 4f00e431    	movi.16b	v17, #0x1
1000ea6c0: 4e318463    	add.16b	v3, v3, v17
1000ea6c4: 4e2f4463    	sshl.16b	v3, v3, v15
1000ea6c8: 6e2058a5    	mvn.16b	v5, v5
1000ea6cc: 4e251c63    	and.16b	v3, v3, v5
1000ea6d0: 4e2a0c65    	sqadd.16b	v5, v3, v10
1000ea6d4: 6e2d1ca5    	eor.16b	v5, v5, v13
1000ea6d8: 4e232e03    	sqsub.16b	v3, v16, v3
1000ea6dc: d503201f    	nop
1000ea6e0: d503201f    	nop
1000ea6e4: 6e2d1dc7    	eor.16b	v7, v14, v13
1000ea6e8: 3c8d83e5    	stur	q5, [sp, #0xd8]
1000ea6ec: 3c8e83e1    	stur	q1, [sp, #0xe8]
1000ea6f0: 6e2d1c66    	eor.16b	v6, v3, v13
1000ea6f4: 9a9f37e5    	cset	x5, hs
1000ea6f8: aa0500c6    	orr	x6, x6, x5
1000ea6fc: 3cc04001    	ldur	q1, [x0, #0x4]
1000ea700: 3dc00103    	ldr	q3, [x8]
1000ea704: 3dc00125    	ldr	q5, [x9]
1000ea708: 3dc0014a    	ldr	q10, [x10]
1000ea70c: 4e836821    	trn2.4s	v1, v1, v3
1000ea710: 4e8a68a3    	trn2.4s	v3, v5, v10
1000ea714: 4ec37821    	zip2.2d	v1, v1, v3
1000ea718: 3dc00163    	ldr	q3, [x11]
1000ea71c: 3dc00185    	ldr	q5, [x12]
1000ea720: 3dc001aa    	ldr	q10, [x13]
1000ea724: 3dc001cd    	ldr	q13, [x14]
1000ea728: 4e856863    	trn2.4s	v3, v3, v5
1000ea72c: 4e8d6945    	trn2.4s	v5, v10, v13
1000ea730: 4ec57863    	zip2.2d	v3, v3, v5
1000ea734: 3dc001e5    	ldr	q5, [x15]
1000ea738: 3dc0022a    	ldr	q10, [x17]
1000ea73c: 3dc0020d    	ldr	q13, [x16]
1000ea740: 3dc002ee    	ldr	q14, [x23]
1000ea744: 4e8a68a5    	trn2.4s	v5, v5, v10
1000ea748: 4e8e69aa    	trn2.4s	v10, v13, v14
1000ea74c: 4eca78a5    	zip2.2d	v5, v5, v10
1000ea750: 3dc0026a    	ldr	q10, [x19]
1000ea754: 3dc0028d    	ldr	q13, [x20]
1000ea758: 3dc002ae    	ldr	q14, [x21]
1000ea75c: 3dc000ef    	ldr	q15, [x7]
1000ea760: 3c8f83e7    	stur	q7, [sp, #0xf8]
1000ea764: 910423fb    	add	x27, sp, #0x108
1000ea768: 3d800366    	str	q6, [x27]
1000ea76c: 910463fb    	add	x27, sp, #0x118
1000ea770: 3d80036c    	str	q12, [x27]
1000ea774: 9104a3fb    	add	x27, sp, #0x128
1000ea778: 3d800364    	str	q4, [x27]
1000ea77c: 4e8d694a    	trn2.4s	v10, v10, v13
1000ea780: 4e8f69cd    	trn2.4s	v13, v14, v15
1000ea784: 4ecd794a    	zip2.2d	v10, v10, v13
1000ea788: 4e45282d    	trn1.8h	v13, v1, v5
1000ea78c: 4e456821    	trn2.8h	v1, v1, v5
1000ea790: 4e4a2865    	trn1.8h	v5, v3, v10
1000ea794: 4e4a6863    	trn2.8h	v3, v3, v10
1000ea798: 4e0529aa    	trn1.16b	v10, v13, v5
1000ea79c: 4e0569a0    	trn2.16b	v0, v13, v5
1000ea7a0: 4e032825    	trn1.16b	v5, v1, v3
1000ea7a4: 4e036821    	trn2.16b	v1, v1, v3
1000ea7a8: 6e2a6403    	umax.16b	v3, v0, v10
1000ea7ac: 6e2a6c0d    	umin.16b	v13, v0, v10
1000ea7b0: 6e2d8463    	sub.16b	v3, v3, v13
1000ea7b4: 6e286463    	umax.16b	v3, v3, v8
1000ea7b8: 6e246548    	umax.16b	v8, v10, v4
1000ea7bc: 6e246d4d    	umin.16b	v13, v10, v4
1000ea7c0: 6e2d8508    	sub.16b	v8, v8, v13
1000ea7c4: 6e280d08    	uqadd.16b	v8, v8, v8
1000ea7c8: 6e2c640d    	umax.16b	v13, v0, v12
1000ea7cc: 6e2c6c0e    	umin.16b	v14, v0, v12
1000ea7d0: 6e2e85ad    	sub.16b	v13, v13, v14
1000ea7d4: 9000333b    	adrp	x27, 0x10074e000 <_runtime.mheap_+0x189a0>
1000ea7d8: 9126c37b    	add	x27, x27, #0x9b0
1000ea7dc: 3dc0036e    	ldr	q14, [x27]
1000ea7e0: 6e2e45ad    	ushl.16b	v13, v13, v14
1000ea7e4: 6e280da8    	uqadd.16b	v8, v13, v8
1000ea7e8: 6e2764cd    	umax.16b	v13, v6, v7
1000ea7ec: 6e276cc7    	umin.16b	v7, v6, v7
1000ea7f0: 6e2785a7    	sub.16b	v7, v13, v7
1000ea7f4: 6e2364e7    	umax.16b	v7, v7, v3
1000ea7f8: 6e2c64cd    	umax.16b	v13, v6, v12
1000ea7fc: 6e2c6cc6    	umin.16b	v6, v6, v12
1000ea800: 6e2685a6    	sub.16b	v6, v13, v6
1000ea804: 6e2764c6    	umax.16b	v6, v6, v7
1000ea808: 6e2064a7    	umax.16b	v7, v5, v0
1000ea80c: 6e206cad    	umin.16b	v13, v5, v0
1000ea810: 6e2d84e7    	sub.16b	v7, v7, v13
1000ea814: 6e2664e6    	umax.16b	v6, v7, v6
1000ea818: 6e256427    	umax.16b	v7, v1, v5
1000ea81c: 6e256c21    	umin.16b	v1, v1, v5
1000ea820: 6e2184e1    	sub.16b	v1, v7, v1
1000ea824: 6e266421    	umax.16b	v1, v1, v6
1000ea828: 6e283d25    	cmhs.16b	v5, v9, v8
1000ea82c: 6e213d61    	cmhs.16b	v1, v11, v1
1000ea830: 4e211ca1    	and.16b	v1, v5, v1
1000ea834: 4e083c25    	mov.d	x5, v1[0]
1000ea838: 4e183c27    	mov.d	x7, v1[1]
1000ea83c: d503201f    	nop
1000ea840: d503201f    	nop
1000ea844: d503201f    	nop
1000ea848: d503201f    	nop
1000ea84c: d503201f    	nop
1000ea850: d503201f    	nop
1000ea854: aa0500e5    	orr	x5, x7, x5
1000ea858: b40006e5    	cbz	x5, 0x1000ea934 <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical+0xa94>
1000ea85c: 6e223462    	cmhi.16b	v2, v3, v2
1000ea860: 4f04e403    	movi.16b	v3, #0x80
1000ea864: 6e231d85    	eor.16b	v5, v12, v3
1000ea868: 6e231c84    	eor.16b	v4, v4, v3
1000ea86c: 6e231d46    	eor.16b	v6, v10, v3
1000ea870: 6e231c07    	eor.16b	v7, v0, v3
1000ea874: 4e272ca8    	sqsub.16b	v8, v5, v7
1000ea878: 4e221d08    	and.16b	v8, v8, v2
1000ea87c: 4e242cc9    	sqsub.16b	v9, v6, v4
1000ea880: 4e280d28    	sqadd.16b	v8, v9, v8
1000ea884: 4e290d08    	sqadd.16b	v8, v8, v9
1000ea888: 4e280d28    	sqadd.16b	v8, v9, v8
1000ea88c: 4e211d01    	and.16b	v1, v8, v1
1000ea890: 4e20b828    	abs.16b	v8, v1
1000ea894: 6e30a908    	umaxv.16b	b8, v8
1000ea898: 0e013d05    	umov.b	w5, v8[0]
1000ea89c: d3401ca5    	ubfx	x5, x5, #0, #8
1000ea8a0: d503201f    	nop
1000ea8a4: d503201f    	nop
1000ea8a8: d503201f    	nop
1000ea8ac: d503201f    	nop
1000ea8b0: d503201f    	nop
1000ea8b4: 710010bf    	cmp	w5, #0x4
1000ea8b8: 540003a3    	b.lo	0x1000ea92c <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical+0xa8c>
1000ea8bc: 4f00e468    	movi.16b	v8, #0x3
1000ea8c0: 4e280c28    	sqadd.16b	v8, v1, v8
1000ea8c4: 4f00e489    	movi.16b	v9, #0x4
1000ea8c8: 4e290c21    	sqadd.16b	v1, v1, v9
1000ea8cc: 9000333b    	adrp	x27, 0x10074e000 <_runtime.mheap_+0x189a0>
1000ea8d0: 9127037b    	add	x27, x27, #0x9c0
1000ea8d4: 3dc00369    	ldr	q9, [x27]
1000ea8d8: 4e294421    	sshl.16b	v1, v1, v9
1000ea8dc: 4e212cc6    	sqsub.16b	v6, v6, v1
1000ea8e0: 4e294508    	sshl.16b	v8, v8, v9
1000ea8e4: 4e240d04    	sqadd.16b	v4, v8, v4
1000ea8e8: 6e231c84    	eor.16b	v4, v4, v3
1000ea8ec: 4f00e428    	movi.16b	v8, #0x1
1000ea8f0: 4e288421    	add.16b	v1, v1, v8
1000ea8f4: 4e2e4421    	sshl.16b	v1, v1, v14
1000ea8f8: 6e205842    	mvn.16b	v2, v2
1000ea8fc: 4e221c21    	and.16b	v1, v1, v2
1000ea900: 4e250c22    	sqadd.16b	v2, v1, v5
1000ea904: 6e231c42    	eor.16b	v2, v2, v3
1000ea908: 4e212ce1    	sqsub.16b	v1, v7, v1
1000ea90c: d503201f    	nop
1000ea910: d503201f    	nop
1000ea914: 6e231cca    	eor.16b	v10, v6, v3
1000ea918: 910463fb    	add	x27, sp, #0x118
1000ea91c: 3d800362    	str	q2, [x27]
1000ea920: 9104a3fb    	add	x27, sp, #0x128
1000ea924: 3d800364    	str	q4, [x27]
1000ea928: 6e231c20    	eor.16b	v0, v1, v3
1000ea92c: 9a9f37e5    	cset	x5, hs
1000ea930: aa0500c6    	orr	x6, x6, x5
1000ea934: 360000e6    	tbz	w6, #0x0, 0x1000ea950 <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical+0xab0>
1000ea938: 9104e3fb    	add	x27, sp, #0x138
1000ea93c: 3d80036a    	str	q10, [x27]
1000ea940: f940b3e1    	ldr	x1, [sp, #0x160]
1000ea944: f940b7e2    	ldr	x2, [sp, #0x168]
1000ea948: 910123e4    	add	x4, sp, #0x48
1000ea94c: 94000561    	bl	0x1000ebed0 <_github.com/thesyncim/govpx/internal/pixel.storeLFRowVectors>
1000ea950: a97ffbfd    	ldp	x29, x30, [sp, #-0x8]
1000ea954: 910543ff    	add	sp, sp, #0x150
1000ea958: d65f03c0    	ret
1000ea95c: a90087e0    	stp	x0, x1, [sp, #0x8]
1000ea960: a9018fe2    	stp	x2, x3, [sp, #0x18]
1000ea964: a90297e4    	stp	x4, x5, [sp, #0x28]
1000ea968: a9039fe6    	stp	x6, x7, [sp, #0x38]
1000ea96c: aa1e03e3    	mov	x3, x30
1000ea970: 97fe5838    	bl	0x100080a50 <_runtime.morestack_noctxt.abi0>
1000ea974: a94087e0    	ldp	x0, x1, [sp, #0x8]
1000ea978: a9418fe2    	ldp	x2, x3, [sp, #0x18]
1000ea97c: a94297e4    	ldp	x4, x5, [sp, #0x28]
1000ea980: a9439fe6    	ldp	x6, x7, [sp, #0x38]
1000ea984: 17fffd47    	b	0x1000e9ea0 <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical>
		...

from pathlib import Path
import os,json,subprocess,statistics
vs=['assembly','parent','carry'];bins=['/private/tmp/govpx-asm-bench','/private/tmp/govpx-pr39-arm-libvpx-bench','/private/tmp/govpx-plane-arithmetic-carry-bench'];orders=[[0,1,2],[1,2,0],[2,0,1],[0,2,1],[2,1,0],[1,0,2]];rows=[];env=dict(os.environ,GOMAXPROCS='1')
for frames in [60,300]:
 for r,order in enumerate(orders,1):
  for i in order:
   args=[bins[i],'-codec=vp8','-width=1280','-height=720','-frames='+str(frames),'-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8','-threads=1','-encode-only','-auto-libvpx=false','-format=json'];q=json.loads(subprocess.check_output(args,env=env,text=True));rows.append(dict(frames=frames,round=r,variant=vs[i],args=args,result=q))
  Path('/private/tmp/govpx-plane-carry-public.json').write_text(json.dumps({'samples':rows},indent=2)+'\n');print('frames',frames,'round',r,'done',flush=True)
s={}
for frames in [60,300]:
 data={v:[r['result'] for r in rows if r['frames']==frames and r['variant']==v] for v in vs};fields=[k for k in data['parent'][0] if k not in ['ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','reference','reference_first']]
 unequal=[]
 for f in fields:
  vals=[q[f] for a in data.values() for q in a]
  if any(q!=vals[0] for q in vals):unequal.append(f)
 s[frames]={'medians':{v:statistics.median(q['ns_per_frame'] for q in a) for v,a in data.items()},'field_count':len(fields),'unequal':unequal,'allocations':{v:[q['allocs_per_frame'] for q in a] for v,a in data.items()}}
 for v in ['parent','assembly']:
  s[frames]['carry_vs_'+v+'_percent']=(s[frames]['medians']['carry']/s[frames]['medians'][v]-1)*100;s[frames]['faster_pairs_'+v]=sum(a['ns_per_frame']>b['ns_per_frame'] for a,b in zip(data[v],data['carry']))
Path('/private/tmp/govpx-plane-carry-public-summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))

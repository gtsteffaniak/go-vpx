from pathlib import Path
import os,subprocess,json,re,statistics,hashlib
p=Path('/private/tmp/govpx-vp8-fdct-zero55');env=os.environ.copy();env['GOMAXPROCS']='1';rows={};bins={k:p/(v+'.test')for k,v in [('parent','parent'),('initial','candidate'),('range32','candidate-range32')]};meta={'scope':'two balanced 60ms rounds; preliminary native component screen','hardware':'Apple M4 Max/Darwin ARM64','Go':'1.27.2','SIMD':True,'PGO':'off','GOMAXPROCS':1,'binary_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest()for k,v in bins.items()}}
for rnd,order in enumerate([list(bins),list(bins)[::-1]],1):
 for k in order:
  t=subprocess.run([str(bins[k]),'-test.run=^$','-test.bench=^BenchmarkFDCTZeroScreen$','-test.benchtime=60ms','-test.cpu=1','-test.count=1','-test.benchmem'],env=env,text=True,capture_output=True);(p/f'range-r{rnd}-{k}.txt').write_text(t.stdout);assert t.returncode==0
  rs=re.findall(r'^(Benchmark\S+)\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',t.stdout,re.M);assert len(rs)==3
  for name,ns,b,a in rs:assert b==a=='0';rows.setdefault(name,{}).setdefault(k,[]).append(float(ns))
meta['results']={n:{'ns':rs,'speedups_vs_parent':{k:statistics.median(rs['parent'])/statistics.median(v)for k,v in rs.items()if k!='parent'}}for n,rs in rows.items()};(p/'range-summary.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta['results'],indent=2));print('END all timers stopped')

from pathlib import Path
import subprocess, json, re, statistics, os, time

r = Path(__file__).resolve().parent
env = dict(os.environ, GOMAXPROCS='2')
commands = []
samples = {}
for tree, pair in [('base', 1), ('candidate', 1), ('candidate', 2), ('base', 2)]:
    args = [str(r / (tree + '.test')), '-test.run=^$', '-test.bench=^BenchmarkAstraVP8MinimumMotionCost$', '-test.benchtime=40ms', '-test.count=1', '-test.cpu=2']
    log = r / f'native-{pair}-{tree}.log'
    started = time.time()
    with log.open('w') as out:
        rc = subprocess.run(args, env=env, stdout=out, stderr=subprocess.STDOUT).returncode
    commands.append(dict(args=args, log=str(log), exit=rc, elapsed_seconds=time.time()-started))
    if rc:
        raise SystemExit(f'benchmark failed: {log}')
    for line in log.read_text().splitlines():
        m = re.match(r'(Benchmark\S+)-2\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op', line)
        if m:
            name, ns, size, allocs = m.groups()
            samples.setdefault(name, {}).setdefault(tree, {})[pair] = float(ns)
            if size != '0' or allocs != '0':
                raise SystemExit(f'allocation failure: {line}')
    print(tree, pair, flush=True)
summary = {}
for name, values in samples.items():
    raw = {k: [v[1], v[2]] for k,v in values.items()}
    ratios = [raw['base'][i]/raw['candidate'][i] for i in range(2)]
    summary[name] = dict(raw_ns=raw, paired_speedups=ratios, median_speedup=statistics.median(ratios), zero_allocations=True)
(r/'native-commands.json').write_text(json.dumps(commands, indent=2)+'\n')
(r/'native-summary.json').write_text(json.dumps(summary, indent=2)+'\n')
for name, values in summary.items():
    print(name, ' '.join(f'{x:.3f}x' for x in values['paired_speedups']))

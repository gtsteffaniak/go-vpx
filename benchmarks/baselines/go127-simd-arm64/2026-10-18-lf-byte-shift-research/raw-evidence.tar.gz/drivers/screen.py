from pathlib import Path
import os,subprocess,json,sys,datetime
r=Path('/private/tmp/govpx-arm-lf-byte-shift');out=r/'screen';out.mkdir(exist_ok=True)
e=os.environ.copy();e.update(GOMAXPROCS='1',GOVPX_REQUIRE_SIMD='1');commands=[]
for rnd,order in enumerate([['parent','candidate'],['candidate','parent'],['parent','candidate']],1):
 for v in order:
  name=f'r{rnd}-{v}';cmd=[str(r/(v+'-decoder.test')),'-test.run=^$','-test.bench=^BenchmarkVP8PickerFilterNative$','-test.benchtime=75ms','-test.cpu=1','-test.count=1','-test.benchmem']
  commands.append({'round':rnd,'variant':v,'command':cmd})
  with (out/(name+'.txt')).open('w')as f:run=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT)
  if run.returncode:print(name,'FAILED',flush=True);sys.exit(run.returncode)
 print('round',rnd,'complete',flush=True)
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print('SCREEN COMPLETE',flush=True)

from pathlib import Path
import json,re,statistics
r=Path('/private/tmp/govpx-arm-lf-byte-shift');samples=[];groups={};pairs={}
for p in sorted((r/'screen').glob('*.txt')):
 rnd=int(p.stem.split('-')[0][1:]);variant=p.stem.split('-')[1]
 matches=re.findall(r'^(Benchmark\S+)\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',p.read_text(),re.M)
 assert len(matches)==10,(p,len(matches))
 for case,it,ns,byte,alloc in matches:
  assert byte=='0'and alloc=='0'
  sample={'round':rnd,'variant':variant,'case':case,'iterations':int(it),'ns':float(ns),'B/op':int(byte),'allocs/op':int(alloc),'log':p.name};samples.append(sample)
  groups.setdefault((variant,case),[]).append(float(ns));pairs[variant,case,rnd]=float(ns)
results=[]
for case in sorted({x['case']for x in samples}):
 a,b=statistics.median(groups['parent',case]),statistics.median(groups['candidate',case]);results.append({'case':case,'parent_ns':a,'candidate_ns':b,'speedup':a/b,'candidate_time_change_percent':(b/a-1)*100,'pair_ratios':[pairs['parent',case,i]/pairs['candidate',case,i]for i in range(1,4)]})
summary={'hardware':'Apple M4 Max ARM64','compiler':'Go1.27.2 GOEXPERIMENT=simd','pgo':'off','rounds':3,'orders':['parent candidate','candidate parent','parent candidate'],'benchtime':'75ms','all60samples_zero_alloc':True,'oracle':'existing public picker complete buffer vs4 separate public edges; independent scalar pixel/DSP oracles passed before timing','results':results,'samples':samples}
(r/'screen-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(results,indent=2))

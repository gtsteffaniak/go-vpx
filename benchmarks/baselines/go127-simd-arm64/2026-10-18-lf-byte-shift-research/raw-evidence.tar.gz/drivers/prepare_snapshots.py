from pathlib import Path
import subprocess,tarfile,io,shutil,hashlib,json
r=Path('/private/tmp/govpx-arm-lf-byte-shift');project=Path('/Users/thesyncim/GolandProjects/govpx');commit=(r/'parent-commit.txt').read_text().strip()
archive=subprocess.check_output(['git','archive',commit],cwd=project)
for variant in ['parent','candidate']:
 root=r/variant;root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(archive))as tar:
  for member in tar.getmembers():
   if member.name.startswith('/')or'..'in Path(member.name).parts:raise RuntimeError('unsafe path')
  tar.extractall(root)
 path='internal/pixel/goav1_loopfilter_arm64.go'
 (root/path).write_bytes((r/(variant+'-source')/path).read_bytes())
 # The public fixture is pinned, existing and byte-identical in both variants.
 fixture='internal/vp8/decoder/picker_filter_native_bench_test.go'
 assert (root/fixture).read_bytes()==subprocess.check_output(['git','show',commit+':'+fixture],cwd=project)
print('Source snapshots ready; no Go jobs run')

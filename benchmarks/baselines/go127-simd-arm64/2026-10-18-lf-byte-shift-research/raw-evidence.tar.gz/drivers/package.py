from pathlib import Path
import shutil,hashlib,json,subprocess,re
r=Path('/private/tmp/govpx-arm-lf-byte-shift');ready=Path('/private/tmp/govpx-arm-lf-byte-shift-ready');ready.mkdir(exist_ok=True)
for name in ['parent-source','candidate-source','evidence','screen']:
 shutil.copytree(r/name,ready/name,dirs_exist_ok=True)
for p in r.glob('*.py'):
 d=ready/'drivers'/p.name;d.parent.mkdir(exist_ok=True);shutil.copyfile(p,d)
for name in ['parent-commit.txt','candidate.patch','screen-summary.json']:shutil.copyfile(r/name,ready/name)
fixture=Path('internal/vp8/decoder/picker_filter_native_bench_test.go');d=ready/'fixture'/fixture;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/'parent'/fixture,d)
# Verify the production snapshot delta against the pinned Git tree.
paths=subprocess.check_output(['git','ls-tree','-r','--name-only','f8dd8c7472e91c1f147511b04ceec716aca95aa7'],cwd='/Users/thesyncim/GolandProjects/govpx',text=True).splitlines()
changes=[]
for p in paths:
 a,b=r/'parent'/p,r/'candidate'/p
 if a.is_file()and b.is_file()and a.read_bytes()!=b.read_bytes():changes.append(p)
assert changes==['internal/pixel/goav1_loopfilter_arm64.go'],changes
meta={'parent':'f8dd8c7472e91c1f147511b04ceec716aca95aa7','production_delta':changes,'hardware':'Apple M4 Max ARM64','compiler':'officialGo1.27.2 GOEXPERIMENT=simd','pgo':'off','GOFLAGS':'-p=2','GOMAXPROCS':'1','GOVPX_REQUIRE_SIMD':'1','wrapper':'root scripts/go.sh -C private snapshot -> project-env','agent':'govpx-ci-lf-byte-shift','cache':'/private/tmp/codex-projects/99feb44aac13f74a/go-build','fixture_sha256':hashlib.sha256(d.read_bytes()).hexdigest(),'binaries':{v:hashlib.sha256((r/(v+'-decoder.test')).read_bytes()).hexdigest()for v in ['parent','candidate']},'whole_codec_run':False,'fresh6_run':False,'helper_alone_benchmark':False,'decision':'stop/archive; public screen mixed near-noise; no retained optimization or performance claim'}
(ready/'evidence/environment-and-source-delta.json').write_text(json.dumps(meta,indent=2)+'\n')
code=json.loads((r/'evidence/codegen-summary.json').read_text());summary=json.loads((r/'screen-summary.json').read_text())
s='''# ARM byte-shift constant experiment: stopped after screen

Decision: archive the sole candidate. Public picker deltas are small and mixed;
no stable meaningful component gain was established. No fresh-six, whole-codec,
or artificial helper-only benchmark was run. Root source/PRs/README files remain
unchanged.

## Exact source change

Parent `f8dd8c7472e91c1f147511b04ceec716aca95aa7`. The private candidate changes
only `internal/pixel/goav1_loopfilter_arm64.go`: removes two Int8x16 shift globals
and rewrites lfByteShift1, lfByteShift3 and lfByteHalf as ShiftAllRight(1/3/1).
LE/GT/not/other arithmetic, filterShift7/lfShift16, transform helpers, loads,
stores, dispatch and alias checks stay unchanged. Full snapshot comparison
confirmed this single-file production delta. Exact sources/patch and shared
public fixture are included; complete snapshots and binaries are not.

Go1.27.2 SDK simdARM64.rules327/331 lowers ShiftAllRight byte operations to
SSHL/USHL with a signed-byte broadcast; rule392 folds those constant broadcasts
to MOVI.16B. It does not emit immediate SSHR. Actual optimized LLVM confirms the
expected load replacement. Existing exact-f8 profile provenance/saved baseline
LLVM is preserved separately from both fresh test-binary codegen dumps.

| Actual function | Parent instructions | Candidate instructions | Byte global references parent→candidate | Vector stack load/store parent=candidate |
|---|---:|---:|---:|---:|
'''
for name in code['parent']:
 a,b=code['parent'][name],code['candidate'][name]
 s+=f"| {name} | {a['instructions']} | {b['instructions']} | {len(a['global_shift_references'])}→{len(b['global_shift_references'])} | {a['stack_vector_loads']}/{a['stack_vector_stores']} |\n"
s+='''
All calls and frame adjustments remain unchanged. Counts include existing STUR
stores (19 in the vertical body); no claim of zero existing spills is made.
SSHL/USHL operation counts are unchanged. Only byte shift-constant setup changes;
16-bit global shift loads remain intact.

## Correctness before timing

Both parent and candidate passed live ARM backend detection, native short suites
for pixel, VP8 DSP/encoder/decoder and VP9 DSP, and race+checkptr2 loop-filter
oracles for pixel, VP8 DSP/decoder and VP9 DSP. Existing independent scalar filter
oracles cover byte arithmetic/exhaustive signed shifts, minimal bounds, aliased
layouts, invalid/fallback geometry and full public outputs. Build/test commands
and complete outputs are preserved under evidence.

## Public screen (native M4 Max)

Official Go1.27.2, GOEXPERIMENT=simd, PGO off, GOMAXPROCS=1. Three75ms alternating
parent/candidate rounds (AB,BA,AB) cover all10 actual public
BenchmarkVP8PickerFilterNative fixtures. Each iteration restores the relevant
source window and calls applyNormalLoopFilterPartialLumaMB. The complete output
buffer must match four separate public edge operations; independent scalar
pixel/DSP oracles ran beforehand. All60 samples report0B/op and0allocs/op. No
sample or slower control was discarded. Screen order is preliminary; no
six-balanced-pair confirmation was warranted by these small/mixed changes.

| Public picker case | Parent ns | Candidate ns | Parent/candidate | Candidate time change | Three pair ratios |
|---|---:|---:|---:|---:|---|
'''
for row in summary['results']:
 name=row['case'].replace('BenchmarkVP8PickerFilterNative/','');s+=f"| {name} | {row['parent_ns']:.2f} | {row['candidate_ns']:.2f} | {row['speedup']:.5f}× | {row['candidate_time_change_percent']:+.3f}% | "+', '.join(f'{x:.6f}'for x in row['pair_ratios'])+' |\n'
s+='''
Median ratios range0.9886–1.0244×. Candidate times range2.38% faster to1.16%
slower, with textured mixed/smooth controls regressing. Fewer instructions and
removed loads alone do not establish a useful public speedup. This report makes
no whole-codec or cross-architecture claim and does not propose default changes.

All six raw logs, every paired ratio/allocation field, complete correctness logs,
optimized parent/candidate LLVM, SDK rules, source/fixture/binary hashes and
original preparation/build/screen/summarization drivers are retained. Drivers
refer to the original private experiment path. SHA256SUMS covers all delivered
files except itself; no binaries/full snapshots are bundled.
'''
for a,b in [('Go1.27.2','Go 1.27.2'),('rules327/331','rules 327/331'),('rule392','rule 392'),('Three75ms','Three 75ms'),('all10','all 10'),('All60','All 60'),('report0B/op','report 0 B/op'),('and0allocs/op','and 0 allocs/op'),('range0.9886','range 0.9886'),('range2.38%','range 2.38%'),('to1.16%','to 1.16%')]:s=s.replace(a,b)
(ready/'REPORT.md').write_text(s)
files=sorted(p for p in ready.rglob('*')if p.is_file()and p.name!='SHA256SUMS')
(ready/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ready))+'\n'for p in files))
for line in (ready/'SHA256SUMS').read_text().splitlines():
 h,p=line.split('  ',1);assert hashlib.sha256((ready/p).read_bytes()).hexdigest()==h
print(json.dumps({'path':str(ready),'hashed_files':len(files),'bytes':sum(p.stat().st_size for p in ready.rglob('*')if p.is_file()),'all_hashes_verified':True,'manifest_sha256':hashlib.sha256((ready/'SHA256SUMS').read_bytes()).hexdigest()},indent=2))

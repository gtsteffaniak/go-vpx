# Analysis-only corrections

The first independent audit invocation failed before executing its body with `SyntaxError: invalid syntax` at `==not r['quality']`. Parenthesizing the Boolean fixed the private parser.

The second invocation failed at `report['reference_first']` with `KeyError: 'reference_first'`. False comparison order is omitted by JSON omitempty, while true is explicit. The original measurement driver already uses `report.get('reference_first', False)`; the independent parser was corrected to that same documented contract. It then verifies every global command position and all six per-case comparison orders.

No encoding, quality, build, binary, source or raw report was rerun or changed for either parser correction. All original reports and stderr remain byte-identical; analysis context is also preserved inside provenance/context.txt. Both independent audits now pass. Final Git binding remains pending publication and must be added as outer evidence before publication freeze.

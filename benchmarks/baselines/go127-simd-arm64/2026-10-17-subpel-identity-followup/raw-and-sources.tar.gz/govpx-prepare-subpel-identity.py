from pathlib import Path
import subprocess,tarfile,io
repo=Path('/Users/thesyncim/GolandProjects/govpx');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for variant in ['parent','candidate']:
 root=Path('/private/tmp/govpx-next-subpel-identity-'+variant);root.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','HEAD'],cwd=repo))) as t:
  t.extractall(root,members=[m for m in t.getmembers() if not m.name.startswith('benchmarks/baselines/')])
p=Path('/private/tmp/govpx-next-subpel-identity-candidate/internal/pixel/kernels_simd.go');s=p.read_text()
a='\n\tif w == 4 {\n\t\treturn subpelStatsKernel[[4]byte]'
b='''
 // Exact identity filters need only the already optimized SIMD difference
 // statistics. Retain the bilinear read-window checks, including the extra
 // row/column, before taking this shortcut. Codec-sized geometry and bounded
 // nonnegative strides prove the endpoint arithmetic cannot overflow.
 if fx == [2]int16{128,0} && fy == [2]int16{128,0} && w<=64 && h<=64 && (uint(ss)|uint(rs))>>30==0 {
  _ = src[h*ss+w]
  _ = ref[(h-1)*rs+w-1]
  return Stats(src,ss,ref,rs,w,h)
 }
'''
assert s.count(a)==1;s=s.replace(a,'\n'+b+a);p.write_text(s)
subprocess.run(['/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/gofmt','-w',str(p)],check=True)
Path('/private/tmp/govpx-next-subpel-identity-base.txt').write_text(head+'\n');print(head)

from pathlib import Path
import json,statistics
p=Path('/private/tmp/govpx-lf-axis-private');out=p/'fresh-whole300';variants=['parent','candidate','old691']
reference=json.loads((out/'r1-parent.json').read_text());excluded={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'}
semantic=sorted(set(reference)-excluded);assert len(semantic)==22,(len(semantic),semantic)
values={v:[]for v in variants};records=[];differences=[]
for rnd in range(1,7):
 for v in variants:
  f=out/f'r{rnd}-{v}.json';obj=json.loads(f.read_text());assert set(obj)==set(reference),(rnd,v,'schema')
  diff={k:[reference[k],obj[k]] for k in semantic if reference[k]!=obj[k]}
  if diff:differences.append({'round':rnd,'variant':v,'diff':diff})
  values[v].append(obj['ns_per_frame']);records.append({'round':rnd,'variant':v,'all22_semantics_match':not diff,'allocs_per_frame':obj['allocs_per_frame'],'stderr':(out/f'r{rnd}-{v}.stderr').read_text()})
med={v:statistics.median(values[v]) for v in variants};comparisons={}
for v in ['parent','old691']:
 ratios=[values['candidate'][i]/values[v][i] for i in range(6)]
 comparisons[v]={'candidate_time_change_percent_ratio_of_medians':(med['candidate']/med[v]-1)*100,'candidate_over_reference_paired_ratios':ratios,'candidate_time_changes_percent_paired':[(r-1)*100 for r in ratios],'faster_pairs':sum(r<1 for r in ratios),'paired_median_ratio':statistics.median(ratios)}
summary={'base':'accepted TM4 candidate on exact Git47 b6209532fbc30cf9567e0cdc78a21d61a60fe900','old_assembly':'691cd0512c4829d9ee40d483205dd223f9eb028d','hardware':'Apple M4 Max','compiler':'officialGo1.27.2','experiment':'simd','CGO_ENABLED_build':1,'PGO':'off','GOMAXPROCS':1,'codec':'vp8','size':'1280x720','frames':300,'cpu_used':8,'threads':1,'fps':30,'bitrate_kbps':2500,'rounds':6,'separate_from_other_windows':True,'variant_ns_per_frame':values,'median_ns_per_frame':med,'comparisons':comparisons,'semantic_fields':semantic,'semantic_reference':{k:reference[k] for k in semantic},'all22_semantics_match':not differences,'differences':differences,'all_allocations_zero':all(r['allocs_per_frame']==0 for r in records),'records':records,'bitstream_identity_claimed':False}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))

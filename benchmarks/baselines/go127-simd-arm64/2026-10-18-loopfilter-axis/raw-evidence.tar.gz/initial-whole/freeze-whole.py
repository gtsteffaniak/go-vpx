from pathlib import Path
import json,hashlib,shutil
b=Path('/private/tmp/govpx-lf-axis-private');out=Path('/private/tmp/govpx-lf-axis-whole-ready');assert not out.exists();out.mkdir()
for folder in ['evidence','whole300']:
 for p in (b/folder).rglob('*'):
  if p.is_file():q=out/p.relative_to(b);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for name in ['prepare-whole.py','run-whole.py','analyze-whole.py','freeze-whole.py','prepare-whole-progress.log','whole-progress.log','whole-analysis.log','source-freeze.json']:
 shutil.copy2(b/name,out/name)
source=json.loads((b/'evidence/source-proof.json').read_text())
for v in ['parent','candidate','old691']:
 for rel,sha in source[v]['all_go_sha256'].items():assert hashlib.sha256((b/v/rel).read_bytes()).hexdigest()==sha,(v,rel)
(out/'post-measurement-source-proof.json').write_text(json.dumps({'all_go_sources_unchanged':True,'variants':list(source),'screen_ready_manifest_sha256':'bf6c6faa924017f6bbeb964963c3e76e0d0b7f8319bcebb6170423b788deebe7'},indent=2))
(out/'REPORT.md').write_text('''Supplement to frozen /private/tmp/govpx-lf-axis-ready (93members, manifestbf6c6faa...). That initial screen archive remains byte-unchanged; its stop recommendation was provisional. Root separately approved this whole-codec measurement to test the cheap-path signal.

Apple M4 Max, officialGo1.27.2 SIMD, CGO1, PGOoff, GOMAX1. Strong parent is frozen accepted TM4 on Git47b6209532; candidate changes only ARM axis dispatch; old reference actual691cd051. Uniform CLIs freshly built, all Go source hashes checked before and after. Six balanced three-way orders,18 VP8 realtime1280x720300input samples,cpu8,1thread,2500kbps. All22 semantic fields match and all18 allocations/frame zero. No bitstream identity claim.

Medians: parent7.3133385ms,candidate7.2477545ms,old6.706486ms. Candidate -0.89677% time against strongparent;5/6pairs faster, with full paired time deltas[-1.36193,-3.60475,-1.88648,-0.37645,-1.09905,+2.93694]%. This is a modest/noisy gain, not a1.5x component win. Candidate +8.07082% time against old in THIS window; no cross-window old-reference comparison or ARM-gap-closure claim. Component screen separately showed flat/ramp/noop1.0645–1.0832x and textured nearflat, all slower cases preserved in original archive.

No extra profile run, no source changes, no root/PR edits, no additional timer grant used. Exact executableSHA/size/buildinfo/commands retained; only binary payloads remain outside publication archive at private paths described in evidence/whole-binary-hashes.json and build commands. All18rawJSON/stderr and22-field checks preserved. Parent decides retention; this package makes no acceptance claim.
''')
rows=[]
for p in sorted(out.rglob('*')):
 if p.is_file():rows.append({'path':str(p.relative_to(out)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size})
(out/'MANIFEST.json').write_text(json.dumps(rows,indent=2));print(json.dumps({'ready':str(out),'files':len(rows),'manifest_sha256':hashlib.sha256((out/'MANIFEST.json').read_bytes()).hexdigest()},indent=2))

from pathlib import Path
import os,subprocess,hashlib,json,datetime
p=Path('/private/tmp/govpx-lf-axis-private');root=Path('/Users/thesyncim/GolandProjects/govpx');env=os.environ.copy();env.update(CODEX_AGENT_ID='govpx-ci-lfaxis-whole',CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',GOTOOLCHAIN='local',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='1',CGO_ENABLED='1');wrapper=str(root/'scripts/go.sh');records=[];hashes={}
(p/'evidence').mkdir(exist_ok=True)
proof={v:{'all_go_sha256':{str(f.relative_to(p/v)):hashlib.sha256(f.read_bytes()).hexdigest()for f in sorted((p/v).rglob('*.go'))}}for v in ['parent','candidate','old691']}
(p/'evidence/source-proof.json').write_text(json.dumps(proof,indent=2))
for v in ['parent','candidate','old691']:
 for rel,sha in proof[v]['all_go_sha256'].items():assert hashlib.sha256((p/v/rel).read_bytes()).hexdigest()==sha,(v,rel)
 binary=p/(v+'-whole-bench');cmd=[wrapper,'-C',str(p/v),'build','-pgo=off','-o',str(binary),'./cmd/govpx-bench'];rec={'variant':v,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with(p/'evidence'/f'{v}-whole-build.log').open('w')as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=r.returncode);records.append(rec);assert r.returncode==0,rec
 hashes[binary.name]={'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'size':binary.stat().st_size}
 info=subprocess.check_output([wrapper,'version','-m',str(binary)],cwd=root,env=env,text=True);(p/'evidence'/f'{v}-whole-buildinfo.txt').write_text(info);assert 'go1.27.2'in info and 'CGO_ENABLED=1'in info and 'GOEXPERIMENT=simd'in info
 print(v,'whole CLI +buildinfo PASS',flush=True)
(p/'evidence/whole-build-commands.json').write_text(json.dumps({'env':{k:env[k]for k in ['CODEX_AGENT_ID','CODEX_PROJECT_CACHE_ROOT','GO','GOEXPERIMENT','GOFLAGS','GOMAXPROCS','CGO_ENABLED']},'records':records},indent=2)+'\n');(p/'evidence/whole-binary-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
print('WHOLE PREPARATION END: all Go/build jobs STOPPED; no benchmark run',flush=True)

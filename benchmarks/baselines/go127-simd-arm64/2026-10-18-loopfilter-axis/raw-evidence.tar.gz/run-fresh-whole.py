from pathlib import Path
import datetime,hashlib,json,os,platform,subprocess
p=Path('/private/tmp/govpx-lf-axis-private');out=p/'fresh-whole300';out.mkdir(exist_ok=True);assert not list(out.glob('r*-*.json')),'refuse overwrite';assert platform.machine()=='arm64'and platform.system()=='Darwin'
hashes=json.loads((p/'evidence/whole-binary-hashes.json').read_text());source=json.loads((p/'evidence/source-proof.json').read_text())
for v in ['parent','candidate','old691']:
 f=p/(v+'-whole-bench');assert hashlib.sha256(f.read_bytes()).hexdigest()==hashes[f.name]['sha256']
 for rel,sha in source[v]['all_go_sha256'].items():assert hashlib.sha256((p/v/rel).read_bytes()).hexdigest()==sha,(v,rel)
orders=[['parent','candidate','old691'],['candidate','old691','parent'],['old691','parent','candidate'],['parent','old691','candidate'],['candidate','parent','old691'],['old691','candidate','parent']]
flags=['-codec=vp8','-width=1280','-height=720','-frames=300','-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8','-threads=1','-encode-only','-auto-libvpx=false','-format=json'];env=os.environ.copy();env.update(GOMAXPROCS='1',GOVPX_REQUIRE_SIMD='1');records=[];reference=None;excluded={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'}
print('FRESH WHOLE300 START UTC',datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
for rnd,order in enumerate(orders,1):
 for v in order:
  cmd=[str(p/(v+'-whole-bench'))]+flags;rec={'round':rnd,'variant':v,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  raw=out/f'r{rnd}-{v}.json';err=out/f'r{rnd}-{v}.stderr'
  with raw.open('w')as f,err.open('w')as e:r=subprocess.run(cmd,env=env,stdout=f,stderr=e)
  rec.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=r.returncode);records.append(rec);(out/'commands.json').write_text(json.dumps({'orders':orders,'env':{'SDK':'go1.27.2','CGO_ENABLED_build':1,'PGO':'off','GOMAXPROCS':1},'measurements':records},indent=2)+'\n');assert r.returncode==0,rec
  obj=json.loads(raw.read_text());semantic={k:x for k,x in obj.items()if k not in excluded};assert len(semantic)==22,(v,semantic)
  if reference is None:reference=semantic
  diff={k:[reference.get(k),x]for k,x in semantic.items()if reference.get(k)!=x};assert not diff,(rnd,v,'semantic mismatch',diff);assert obj['allocs_per_frame']==0,(rnd,v,'allocation mismatch');assert not err.read_text(),(rnd,v,'stderr')
 print('round',rnd,'END;22 semantics+0alloc PASS',flush=True)
print('FRESH WHOLE300 END UTC',datetime.datetime.now(datetime.timezone.utc).isoformat(),'all18 processes STOPPED;22 semantics+0alloc PASS',flush=True)

from pathlib import Path
import json,hashlib,shutil
b=Path('/private/tmp/govpx-lf-axis-private');out=Path('/private/tmp/govpx-arm-lf-axis-accepted-ready');assert not out.exists();out.mkdir()
for src,dst in [(Path('/private/tmp/govpx-lf-axis-ready'),'initial-screen'),(Path('/private/tmp/govpx-lf-axis-whole-ready'),'initial-whole'),(b/'fresh-screen','fresh-screen'),(b/'fresh-whole300','fresh-whole300')]:shutil.copytree(src,out/dst)
for name in ['run-fresh-screen.py','run-fresh-whole.py','analyze-fresh-screen.py','analyze-fresh-whole.py','fresh-screen-progress.log','fresh-whole-progress.log','fresh-screen-analysis.log','fresh-whole-analysis.log','freeze-accepted.py']:
 shutil.copy2(b/name,out/name)
for name in ['govpx-root-lf-axis-proof.py','govpx-root-lf-axis-proof.json','govpx-root-lf-axis-proof-output.txt','govpx-root-lf-axis-audit-notes.txt']:
 shutil.copy2(Path('/private/tmp')/name,out/name)
for rel in ['internal/pixel/loopfilter_macro_axis_arm64.go','internal/pixel/loopfilter_macro_axis_other.go','internal/vp8/decoder/loopfilter.go','internal/pixel/loopfilter_macro_axis_arm64_test.go','internal/vp8/decoder/loopfilter_axis_frozen_test.go']:
 q=out/'overlay'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(b/'candidate'/rel,q)
(out/'REPORT.md').write_text('''Accepted smaller ARM LF axis dispatch optimization; no1.5x claim.

Strong parent=frozen accepted TM4 on Git47b6209532. Parent/candidate/actualold691, officialGo1.27.2,SIMD,CGO1,PGOoff,GOMAX1,AppleM4Max. All initial/fresh windows remain separate. Existing initial93/whole57archives byte-unchanged, including provisional stop recommendation; root subsequently authorized freshconfirmation and accepted the smaller robust cheap-path gains under engineering judgment.

Initial180publicpicker samples flat/ramp/noop1.0645–1.0832xparent; textured0.9962–1.0093. Fresh180 flat/ramp/noop1.0565–1.0750,all36pairedfaster; all4texturedmedians regress0.3–1.55% (ratios0.9847–0.9972), fully preserved. No qualifying1.5x versus strongparent.

Initial18whole VP81280x720300input median−0.89677%parent,5/6pairsfaster;fresh18−0.80781%,5/6faster. Fresh pairedtimechanges[-1.64198,-0.98336,-0.01178,-0.80800,+0.94117,-0.48532]%. Fresholdgap+8.46627%time, initial+8.07082%, window-specific only; no cross-window assembly/closure claim. All36whole22semanticfields equal,allallocations0. All360kernelallocations0 andfull-output oracles pass. No profiles run.

Independentrootproof audits360kernels+36whole/order/22stats/alloc/source. Pixelcomplete-window/short/spare/clippedcap/misaligned/threshold/huge-stride andfrozen-parentfullbacking/panicstate oracles; racecheckptr2,Enabledfalse,purego,nosimd pass. Existinglibvpx-derived scalar/fused arithmetic remains byte-unchanged, no newdirectC measurement claimed. AMDnormalizedactualdecoderbodyexact344instructions onDarwin/Linux. Splitpredicate28+forwarder69 inline intoactualARMdecoder,onefusedcall/axis; initial99noninlinevariant preserved. Callerframe96B unchanged; originalgeneric80Bframe removed. Generatedarithmetic+originalgenericAPI unchanged.

Overlay5files includes3production+2tests. Public newUncheckedforwarders require matchingpredicate proof; caller establishes it immediately before call, no arithmetic/stores moved. Allunsafe accesses remain existingworkers with exactsamewindow. Rootownsnextintegration/PR; no root/Git/GHchanges here.

Executablebinarypayloads deliberately omitted; originalprivatepaths,SHA,size/buildinfo/commands retained in initialbinary-omissions andwhole receipts. Alloriginalbinaries remain private andunchanged. Frozeninitialarchives retainedasnestedcopies andinoriginalpaths. No moreLFtimers authorized/executed.
''')
rows=[]
for p in sorted(out.rglob('*')):
 if p.is_file():rows.append({'path':str(p.relative_to(out)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size})
(out/'MANIFEST.json').write_text(json.dumps(rows,indent=2));print(json.dumps({'ready':str(out),'files':len(rows),'manifest_sha256':hashlib.sha256((out/'MANIFEST.json').read_bytes()).hexdigest()},indent=2))

from pathlib import Path
import os,subprocess,time,json,itertools,hashlib
b=Path('/private/tmp/govpx-lf-axis-private');bins=b/'screen';out=b/'fresh-screen';out.mkdir(exist_ok=True);assert not list(out.glob('round*.txt'));env=os.environ.copy();env.update(GOMAXPROCS='1',GOVPX_REQUIRE_SIMD='1');prep=json.loads((bins/'prep.json').read_text())
for v in prep['variants']:assert hashlib.sha256((bins/(v['variant']+'.test')).read_bytes()).hexdigest()==v['binary_sha256']
orders=[['parent','candidate','old691'],['candidate','old691','parent'],['old691','parent','candidate'],['parent','old691','candidate'],['candidate','parent','old691'],['old691','candidate','parent']];records=[]
for rnd,order in enumerate(orders,1):
 for pos,v in enumerate(order,1):
  cmd=[str(bins/(v+'.test')),'-test.run=^$','-test.bench=^BenchmarkVP8PickerFilterNative$','-test.benchtime=100ms','-test.count=1'];name=f'round{rnd}-{pos}-{v}.txt';start=time.time()
  with (out/name).open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  records.append(dict(round=rnd,position=pos,variant=v,argv=cmd,log=name,started_unix=start,ended_unix=time.time(),returncode=r.returncode));(out/'run-journal.json').write_text(json.dumps({'orders':orders,'benchtime':'100ms','records':records},indent=2))
  if r.returncode:raise RuntimeError(name)
print('FRESH SCREEN END ALL18 PROCESSES PASS AND STOPPED',flush=True)

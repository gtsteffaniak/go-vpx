from pathlib import Path
import hashlib,json,shutil
b=Path('/private/tmp/govpx-lf-axis-private');out=Path('/private/tmp/govpx-lf-axis-ready');assert not out.exists();out.mkdir()
def copy(p,rel):
 q=out/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for folder in ['validation','codegen','screen']:
 for p in (b/folder).rglob('*'):
  if p.is_file() and not p.name.endswith('.test'):copy(p,p.relative_to(b))
for name in ['validate.py','prove.py','prepare-screen.py','run-screen.py','analyze-screen.py','freeze.py','REPORT.md','SPAN_REVIEW.txt','source-freeze.json','inline-pixel.log','inline-final.log','inline-decoder.log','focused-native.log','validate-progress.log','prepare-screen-progress.log','screen-progress.log','prove-output.log','disabled-overlay.json','enabled-disabled.go']:
 copy(b/name,Path(name))
rels=['internal/pixel/loopfilter_macro_axis_arm64.go','internal/pixel/loopfilter_macro_axis_other.go','internal/vp8/decoder/loopfilter.go','internal/pixel/loopfilter_macro_axis_arm64_test.go','internal/vp8/decoder/loopfilter_axis_frozen_test.go']
for v in ['candidate','initial99']:
 for rel in rels:copy(b/v/rel,Path('sources')/v/rel)
for rel in ['go.mod','internal/vp8/decoder/loopfilter.go','internal/pixel/loopfilter_macro_internal_arm64.go','internal/pixel/loopfilter_macro_internal_fused_arm64.go','internal/vp8/decoder/picker_filter_native_bench_test.go']:
 copy(b/'parent'/rel,Path('sources/strong-parent')/rel)
for rel in ['go.mod','internal/vp8/decoder/loopfilter.go','internal/vp8/decoder/picker_filter_native_bench_test.go']:
 copy(b/'old691'/rel,Path('sources/old691')/rel)
# Explicit binary provenance; binary payloads stay in private work folder.
omitted=[]
for p in b.rglob('*.test'):
 omitted.append(dict(private_path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=p.stat().st_size,omission='binary payload only; no raw log/source/proof omitted'))
(out/'binary-omissions.json').write_text(json.dumps(omitted,indent=2))
a=json.loads((b/'screen/analysis.json').read_text());cases=a['cases'];cheap=[x for n,x in cases.items() if n.endswith(('/flat','/ramp','/noop'))];textured=[x for n,x in cases.items() if n.endswith(('/smooth','/mixed'))]
report='''\n\nNative SCREEN result (Apple M4 Max, Go1.27.2 SIMD, CGO1, PGOoff, GOMAX1): six balanced parent/candidate/old permutations,10 actual public picker cases,75ms,180 samples. All18 process full-output oracles PASS, all180 reported0alloc. Strong-parent speed ratios cheap flat/ramp/no-op1.0645–1.0832; all36 paired cheap cases faster. Smooth/mixed ratios0.9962–1.0093, preserving both regressions and outliers. No case reaches1.5× against the strong accepted TM4 parent. Old NEON values are separate controls, not the acceptance denominator. No whole-codec run or fresh acceptance authorized. Stop/archive recommendation; root decides retention. All initial noninline99 evidence and final checked predicate/unchecked-forwarder source are preserved. Public actual decoder ARM call chain bypasses generic dispatcher, AMD normalized bodies unchanged. No root/PR changes.\n\nThis publication archive intentionally omits only executable binary payloads; exact private paths,SHA256,size are in binary-omissions.json. Original binaries remain unchanged in the private work folder. All sources,drivers,rawlogs,oracles,normalized codegen and reports are retained.\n'''
with (out/'REPORT.md').open('a') as f:f.write(report)
files=[]
for p in sorted(out.rglob('*')):
 if p.is_file():files.append(dict(path=str(p.relative_to(out)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=p.stat().st_size))
(out/'MANIFEST.json').write_text(json.dumps(files,indent=2));print(json.dumps({'ready':str(out),'files':len(files),'manifest_sha256':hashlib.sha256((out/'MANIFEST.json').read_bytes()).hexdigest()},indent=2))

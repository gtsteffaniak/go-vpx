
/private/tmp/govpx-lf-axis-private/validation/candidate-arm.test:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100139c80 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB>:
100139c80: f9400b90    	ldr	x16, [x28, #0x10]
100139c84: eb3063ff    	cmp	sp, x16
100139c88: 54002629    	b.ls	0x10013a14c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4cc>
100139c8c: f81a0ffe    	str	x30, [sp, #-0x60]!
100139c90: f81f83fd    	stur	x29, [sp, #-0x8]
100139c94: d10023fd    	sub	x29, sp, #0x8
100139c98: 39400089    	ldrb	w9, [x4]
100139c9c: 7100113f    	cmp	w9, #0x4
100139ca0: 540000a0    	b.eq	0x100139cb4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x34>
100139ca4: 7100253f    	cmp	w9, #0x9
100139ca8: 54000060    	b.eq	0x100139cb4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x34>
100139cac: 39402489    	ldrb	w9, [x4, #0x9]
100139cb0: 14000002    	b	0x100139cb8 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x38>
100139cb4: aa1f03e9    	mov	x9, xzr
100139cb8: 398000fb    	ldrsb	x27, [x7]
100139cbc: d3401caa    	ubfx	x10, x5, #0, #8
100139cc0: f100095f    	cmp	x10, #0x2
100139cc4: 54002402    	b.hs	0x10013a144 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4c4>
100139cc8: 910310eb    	add	x11, x7, #0xc4
100139ccc: d3401ccc    	ubfx	x12, x6, #0, #8
100139cd0: 8b0a196a    	add	x10, x11, x10, lsl #6
100139cd4: f101019f    	cmp	x12, #0x40
100139cd8: 54002322    	b.hs	0x10013a13c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4bc>
100139cdc: 386c694a    	ldrb	w10, [x10, x12]
100139ce0: f100115f    	cmp	x10, #0x4
100139ce4: 540022a2    	b.hs	0x10013a138 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4b8>
100139ce8: f90037e0    	str	x0, [sp, #0x68]
100139cec: f9003be1    	str	x1, [sp, #0x70]
100139cf0: f90043e3    	str	x3, [sp, #0x80]
100139cf4: 390283e8    	strb	w8, [sp, #0xa0]
100139cf8: 390147e9    	strb	w9, [sp, #0x51]
100139cfc: 910300eb    	add	x11, x7, #0xc0
100139d00: 910100ed    	add	x13, x7, #0x40
100139d04: 910200ee    	add	x14, x7, #0x80
100139d08: 386a6966    	ldrb	w6, [x11, x10]
100139d0c: 390153e6    	strb	w6, [sp, #0x54]
100139d10: 386c68e4    	ldrb	w4, [x7, x12]
100139d14: 39014be4    	strb	w4, [sp, #0x52]
100139d18: 386c69aa    	ldrb	w10, [x13, x12]
100139d1c: 39015fea    	strb	w10, [sp, #0x57]
100139d20: 386c69c5    	ldrb	w5, [x14, x12]
100139d24: 39014fe5    	strb	w5, [sp, #0x53]
100139d28: f100005f    	cmp	x2, #0x0
100139d2c: 5400080d    	b.le	0x100139e2c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x1ac>
100139d30: 36000069    	tbz	w9, #0x0, 0x100139d3c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0xbc>
100139d34: aa1f03ed    	mov	x13, xzr
100139d38: 1400003e    	b	0x100139e30 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x1b0>
100139d3c: a940300b    	ldp	x11, x12, [x0]
100139d40: d100106d    	sub	x13, x3, #0x4
100139d44: eb0d019f    	cmp	x12, x13
100139d48: 54001f63    	b.lo	0x10013a134 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4b4>
100139d4c: f940080e    	ldr	x14, [x0, #0x10]
100139d50: cb0301ce    	sub	x14, x14, x3
100139d54: cb03018c    	sub	x12, x12, x3
100139d58: 910011ce    	add	x14, x14, #0x4
100139d5c: cb0e03ef    	neg	x15, x14
100139d60: 8a8ffdad    	and	x13, x13, x15, asr #63
100139d64: f940580f    	ldr	x15, [x0, #0xb0]
100139d68: d10051f0    	sub	x16, x15, #0x14
100139d6c: 8b0d016b    	add	x11, x11, x13
100139d70: 9100118c    	add	x12, x12, #0x4
100139d74: d35efe0d    	lsr	x13, x16, #30
100139d78: f100005f    	cmp	x2, #0x0
100139d7c: b500022d    	cbnz	x13, 0x100139dc0 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x140>
100139d80: d37ceded    	lsl	x13, x15, #4
100139d84: cb0f01ad    	sub	x13, x13, x15
100139d88: 910051ad    	add	x13, x13, #0x14
100139d8c: eb0c01bf    	cmp	x13, x12
100139d90: 5400016c    	b.gt	0x100139dbc <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x13c>
100139d94: aa0403ed    	mov	x13, x4
100139d98: 7103fdbf    	cmp	w13, #0xff
100139d9c: 540000c0    	b.eq	0x100139db4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x134>
100139da0: aa0a03ed    	mov	x13, x10
100139da4: 7103fdbf    	cmp	w13, #0xff
100139da8: 9a9f07ed    	cset	x13, ne
100139dac: f100005f    	cmp	x2, #0x0
100139db0: 14000005    	b	0x100139dc4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x144>
100139db4: f100005f    	cmp	x2, #0x0
100139db8: 14000002    	b	0x100139dc0 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x140>
100139dbc: f100005f    	cmp	x2, #0x0
100139dc0: aa1f03ed    	mov	x13, xzr
100139dc4: 3600036d    	tbz	w13, #0x0, 0x100139e30 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x1b0>
100139dc8: f9003fe2    	str	x2, [sp, #0x78]
100139dcc: 390157ed    	strb	w13, [sp, #0x55]
100139dd0: aa0a03e8    	mov	x8, x10
100139dd4: aa0503e9    	mov	x9, x5
100139dd8: aa0603e7    	mov	x7, x6
100139ddc: aa0b03e0    	mov	x0, x11
100139de0: aa0c03e1    	mov	x1, x12
100139de4: aa0e03e2    	mov	x2, x14
100139de8: aa0f03e3    	mov	x3, x15
100139dec: aa0803e5    	mov	x5, x8
100139df0: aa0903e6    	mov	x6, x9
100139df4: 97ffb673    	bl	0x1001277c0 <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical>
100139df8: f9403fe8    	ldr	x8, [sp, #0x78]
100139dfc: f100011f    	cmp	x8, #0x0
100139e00: f94037e0    	ldr	x0, [sp, #0x68]
100139e04: f9403be1    	ldr	x1, [sp, #0x70]
100139e08: f94043e3    	ldr	x3, [sp, #0x80]
100139e0c: 39414be4    	ldrb	w4, [sp, #0x52]
100139e10: 39414fe5    	ldrb	w5, [sp, #0x53]
100139e14: 394153e6    	ldrb	w6, [sp, #0x54]
100139e18: 394283e8    	ldrb	w8, [sp, #0xa0]
100139e1c: 394147e9    	ldrb	w9, [sp, #0x51]
100139e20: 39415fea    	ldrb	w10, [sp, #0x57]
100139e24: 394157ed    	ldrb	w13, [sp, #0x55]
100139e28: 14000002    	b	0x100139e30 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x1b0>
100139e2c: aa1f03ed    	mov	x13, xzr
100139e30: 540003ad    	b.le	0x100139ea4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x224>
100139e34: 3700038d    	tbnz	w13, #0x0, 0x100139ea4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x224>
100139e38: a940300b    	ldp	x11, x12, [x0]
100139e3c: d100106e    	sub	x14, x3, #0x4
100139e40: eb0e019f    	cmp	x12, x14
100139e44: 54001763    	b.lo	0x10013a130 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4b0>
100139e48: 390157ed    	strb	w13, [sp, #0x55]
100139e4c: f9400808    	ldr	x8, [x0, #0x10]
100139e50: cb030108    	sub	x8, x8, x3
100139e54: cb030189    	sub	x9, x12, x3
100139e58: 91001102    	add	x2, x8, #0x4
100139e5c: cb0203e8    	neg	x8, x2
100139e60: 8a88fdc8    	and	x8, x14, x8, asr #63
100139e64: 8b080168    	add	x8, x11, x8
100139e68: 91001121    	add	x1, x9, #0x4
100139e6c: f9405803    	ldr	x3, [x0, #0xb0]
100139e70: aa0803e0    	mov	x0, x8
100139e74: b27f03e7    	orr	x7, xzr, #0x2
100139e78: 97ffdf66    	bl	0x100131c10 <_github.com/thesyncim/govpx/internal/vp8/dsp.mbLoopFilterVerticalEdgeDispatch>
100139e7c: f94037e0    	ldr	x0, [sp, #0x68]
100139e80: f9403be1    	ldr	x1, [sp, #0x70]
100139e84: f94043e3    	ldr	x3, [sp, #0x80]
100139e88: 39414be4    	ldrb	w4, [sp, #0x52]
100139e8c: 39414fe5    	ldrb	w5, [sp, #0x53]
100139e90: 394153e6    	ldrb	w6, [sp, #0x54]
100139e94: 394283e8    	ldrb	w8, [sp, #0xa0]
100139e98: 394147e9    	ldrb	w9, [sp, #0x51]
100139e9c: 39415fea    	ldrb	w10, [sp, #0x57]
100139ea0: 394157ed    	ldrb	w13, [sp, #0x55]
100139ea4: 37000309    	tbnz	w9, #0x0, 0x100139f04 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x284>
100139ea8: 370002ed    	tbnz	w13, #0x0, 0x100139f04 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x284>
100139eac: a9402c07    	ldp	x7, x11, [x0]
100139eb0: eb0b007f    	cmp	x3, x11
100139eb4: 540013c8    	b.hi	0x10013a12c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4ac>
100139eb8: f9400808    	ldr	x8, [x0, #0x10]
100139ebc: cb030161    	sub	x1, x11, x3
100139ec0: cb030102    	sub	x2, x8, x3
100139ec4: cb080068    	sub	x8, x3, x8
100139ec8: 8a88fc68    	and	x8, x3, x8, asr #63
100139ecc: 8b0800e7    	add	x7, x7, x8
100139ed0: f9405803    	ldr	x3, [x0, #0xb0]
100139ed4: aa0703e0    	mov	x0, x7
100139ed8: aa0a03e4    	mov	x4, x10
100139edc: 97ffde35    	bl	0x1001317b0 <_github.com/thesyncim/govpx/internal/vp8/dsp.loopFilterVerticalEdgesYDispatch>
100139ee0: f94037e0    	ldr	x0, [sp, #0x68]
100139ee4: f9403be1    	ldr	x1, [sp, #0x70]
100139ee8: f94043e3    	ldr	x3, [sp, #0x80]
100139eec: 39414be4    	ldrb	w4, [sp, #0x52]
100139ef0: 39414fe5    	ldrb	w5, [sp, #0x53]
100139ef4: 394153e6    	ldrb	w6, [sp, #0x54]
100139ef8: 394283e8    	ldrb	w8, [sp, #0xa0]
100139efc: 394147e9    	ldrb	w9, [sp, #0x51]
100139f00: 39415fea    	ldrb	w10, [sp, #0x57]
100139f04: f100003f    	cmp	x1, #0x0
100139f08: 5400004c    	b.gt	0x100139f10 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x290>
100139f0c: 36000928    	tbz	w8, #0x0, 0x10013a030 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3b0>
100139f10: 36000069    	tbz	w9, #0x0, 0x100139f1c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x29c>
100139f14: aa1f03ed    	mov	x13, xzr
100139f18: 14000047    	b	0x10013a034 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3b4>
100139f1c: f940580b    	ldr	x11, [x0, #0xb0]
100139f20: cb0b086c    	sub	x12, x3, x11, lsl #2
100139f24: b7f8018c    	tbnz	x12, #0x3f, 0x100139f54 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x2d4>
100139f28: a940380d    	ldp	x13, x14, [x0]
100139f2c: eb0c01df    	cmp	x14, x12
100139f30: 54000fc3    	b.lo	0x10013a128 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4a8>
100139f34: f940080f    	ldr	x15, [x0, #0x10]
100139f38: cb0f0190    	sub	x16, x12, x15
100139f3c: 8a90fd90    	and	x16, x12, x16, asr #63
100139f40: cb0c01ce    	sub	x14, x14, x12
100139f44: cb0c01e2    	sub	x2, x15, x12
100139f48: 8b1001ac    	add	x12, x13, x16
100139f4c: f100003f    	cmp	x1, #0x0
100139f50: 1400000d    	b	0x100139f84 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x304>
100139f54: a944b80d    	ldp	x13, x14, [x0, #0x48]
100139f58: f940640f    	ldr	x15, [x0, #0xc8]
100139f5c: 8b0c01ec    	add	x12, x15, x12
100139f60: eb0c01df    	cmp	x14, x12
100139f64: 54000e03    	b.lo	0x10013a124 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4a4>
100139f68: f9402c0f    	ldr	x15, [x0, #0x58]
100139f6c: cb0f0190    	sub	x16, x12, x15
100139f70: 8a90fd90    	and	x16, x12, x16, asr #63
100139f74: cb0c01ce    	sub	x14, x14, x12
100139f78: cb0c01e2    	sub	x2, x15, x12
100139f7c: 8b1001ac    	add	x12, x13, x16
100139f80: f100003f    	cmp	x1, #0x0
100139f84: d100416d    	sub	x13, x11, #0x10
100139f88: d35efdad    	lsr	x13, x13, #30
100139f8c: b500022d    	cbnz	x13, 0x100139fd0 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x350>
100139f90: d280026d    	mov	x13, #0x13              ; =19
100139f94: 9b0b7dad    	mul	x13, x13, x11
100139f98: 910041ad    	add	x13, x13, #0x10
100139f9c: eb0d01df    	cmp	x14, x13
100139fa0: 5400016b    	b.lt	0x100139fcc <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x34c>
100139fa4: aa0403ed    	mov	x13, x4
100139fa8: 7103fdbf    	cmp	w13, #0xff
100139fac: 540000c0    	b.eq	0x100139fc4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x344>
100139fb0: aa0a03ed    	mov	x13, x10
100139fb4: 7103fdbf    	cmp	w13, #0xff
100139fb8: 9a9f07ed    	cset	x13, ne
100139fbc: f100003f    	cmp	x1, #0x0
100139fc0: 14000005    	b	0x100139fd4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x354>
100139fc4: f100003f    	cmp	x1, #0x0
100139fc8: 14000002    	b	0x100139fd0 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x350>
100139fcc: f100003f    	cmp	x1, #0x0
100139fd0: aa1f03ed    	mov	x13, xzr
100139fd4: 3600030d    	tbz	w13, #0x0, 0x10013a034 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3b4>
100139fd8: 39015bed    	strb	w13, [sp, #0x56]
100139fdc: aa0a03e8    	mov	x8, x10
100139fe0: aa0503e9    	mov	x9, x5
100139fe4: aa0603e7    	mov	x7, x6
100139fe8: aa0c03e0    	mov	x0, x12
100139fec: aa0e03e1    	mov	x1, x14
100139ff0: aa0b03e3    	mov	x3, x11
100139ff4: aa0803e5    	mov	x5, x8
100139ff8: aa0903e6    	mov	x6, x9
100139ffc: 97ffb485    	bl	0x100127210 <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedHorizontal>
10013a000: f9403be8    	ldr	x8, [sp, #0x70]
10013a004: f100011f    	cmp	x8, #0x0
10013a008: f94037e0    	ldr	x0, [sp, #0x68]
10013a00c: f94043e3    	ldr	x3, [sp, #0x80]
10013a010: 39414be4    	ldrb	w4, [sp, #0x52]
10013a014: 39414fe5    	ldrb	w5, [sp, #0x53]
10013a018: 394153e6    	ldrb	w6, [sp, #0x54]
10013a01c: 394283e8    	ldrb	w8, [sp, #0xa0]
10013a020: 394147e9    	ldrb	w9, [sp, #0x51]
10013a024: 39415fea    	ldrb	w10, [sp, #0x57]
10013a028: 39415bed    	ldrb	w13, [sp, #0x56]
10013a02c: 14000002    	b	0x10013a034 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3b4>
10013a030: aa1f03ed    	mov	x13, xzr
10013a034: 5400004c    	b.gt	0x10013a03c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3bc>
10013a038: 360004c8    	tbz	w8, #0x0, 0x10013a0d0 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x450>
10013a03c: 370004ad    	tbnz	w13, #0x0, 0x10013a0d0 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x450>
10013a040: 39015bed    	strb	w13, [sp, #0x56]
10013a044: f9405808    	ldr	x8, [x0, #0xb0]
10013a048: cb08086b    	sub	x11, x3, x8, lsl #2
10013a04c: b7f8016b    	tbnz	x11, #0x3f, 0x10013a078 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3f8>
10013a050: a940380c    	ldp	x12, x14, [x0]
10013a054: eb0b01df    	cmp	x14, x11
10013a058: 54000643    	b.lo	0x10013a120 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4a0>
10013a05c: f940080f    	ldr	x15, [x0, #0x10]
10013a060: cb0f0170    	sub	x16, x11, x15
10013a064: 8a90fd70    	and	x16, x11, x16, asr #63
10013a068: cb0b01c1    	sub	x1, x14, x11
10013a06c: cb0b01e2    	sub	x2, x15, x11
10013a070: 8b10018b    	add	x11, x12, x16
10013a074: 1400000c    	b	0x10013a0a4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x424>
10013a078: a944b80c    	ldp	x12, x14, [x0, #0x48]
10013a07c: f940640f    	ldr	x15, [x0, #0xc8]
10013a080: 8b0b01eb    	add	x11, x15, x11
10013a084: eb0b01df    	cmp	x14, x11
10013a088: 540004a3    	b.lo	0x10013a11c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x49c>
10013a08c: f9402c0f    	ldr	x15, [x0, #0x58]
10013a090: cb0f0170    	sub	x16, x11, x15
10013a094: 8a90fd70    	and	x16, x11, x16, asr #63
10013a098: cb0b01c1    	sub	x1, x14, x11
10013a09c: cb0b01e2    	sub	x2, x15, x11
10013a0a0: 8b10018b    	add	x11, x12, x16
10013a0a4: aa0b03e0    	mov	x0, x11
10013a0a8: aa0803e3    	mov	x3, x8
10013a0ac: b27f03e7    	orr	x7, xzr, #0x2
10013a0b0: 97ffdea0    	bl	0x100131b30 <_github.com/thesyncim/govpx/internal/vp8/dsp.mbLoopFilterHorizontalEdgeDispatch>
10013a0b4: f94037e0    	ldr	x0, [sp, #0x68]
10013a0b8: f94043e3    	ldr	x3, [sp, #0x80]
10013a0bc: 39414fe5    	ldrb	w5, [sp, #0x53]
10013a0c0: 394153e6    	ldrb	w6, [sp, #0x54]
10013a0c4: 394147e9    	ldrb	w9, [sp, #0x51]
10013a0c8: 39415fea    	ldrb	w10, [sp, #0x57]
10013a0cc: 39415bed    	ldrb	w13, [sp, #0x56]
10013a0d0: 370001e9    	tbnz	w9, #0x0, 0x10013a10c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x48c>
10013a0d4: 370001cd    	tbnz	w13, #0x0, 0x10013a10c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x48c>
10013a0d8: a9402007    	ldp	x7, x8, [x0]
10013a0dc: eb08007f    	cmp	x3, x8
10013a0e0: 540001c8    	b.hi	0x10013a118 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x498>
10013a0e4: f9400809    	ldr	x9, [x0, #0x10]
10013a0e8: cb09006b    	sub	x11, x3, x9
10013a0ec: cb030101    	sub	x1, x8, x3
10013a0f0: cb030122    	sub	x2, x9, x3
10013a0f4: 8a8bfc68    	and	x8, x3, x11, asr #63
10013a0f8: 8b0800e7    	add	x7, x7, x8
10013a0fc: f9405803    	ldr	x3, [x0, #0xb0]
10013a100: aa0703e0    	mov	x0, x7
10013a104: aa0a03e4    	mov	x4, x10
10013a108: 97ffdd1a    	bl	0x100131570 <_github.com/thesyncim/govpx/internal/vp8/dsp.loopFilterHorizontalEdgesYDispatch>
10013a10c: f85f83fd    	ldur	x29, [sp, #-0x8]
10013a110: f84607fe    	ldr	x30, [sp], #0x60
10013a114: d65f03c0    	ret
10013a118: 97fd23ee    	bl	0x1000830d0 <_runtime.panicBounds>
10013a11c: 97fd23ed    	bl	0x1000830d0 <_runtime.panicBounds>
10013a120: 97fd23ec    	bl	0x1000830d0 <_runtime.panicBounds>
10013a124: 97fd23eb    	bl	0x1000830d0 <_runtime.panicBounds>
10013a128: 97fd23ea    	bl	0x1000830d0 <_runtime.panicBounds>
10013a12c: 97fd23e9    	bl	0x1000830d0 <_runtime.panicBounds>
10013a130: 97fd23e8    	bl	0x1000830d0 <_runtime.panicBounds>
10013a134: 97fd23e7    	bl	0x1000830d0 <_runtime.panicBounds>
10013a138: 97fd23e6    	bl	0x1000830d0 <_runtime.panicBounds>
10013a13c: b27a03e0    	orr	x0, xzr, #0x40
10013a140: 97fd23e4    	bl	0x1000830d0 <_runtime.panicBounds>
10013a144: 97fd23e3    	bl	0x1000830d0 <_runtime.panicBounds>
10013a148: d503201f    	nop
10013a14c: a90087e0    	stp	x0, x1, [sp, #0x8]
10013a150: a9018fe2    	stp	x2, x3, [sp, #0x18]
10013a154: f90017e4    	str	x4, [sp, #0x28]
10013a158: 3900c3e5    	strb	w5, [sp, #0x30]
10013a15c: 3900c7e6    	strb	w6, [sp, #0x31]
10013a160: f9001fe7    	str	x7, [sp, #0x38]
10013a164: 390103e8    	strb	w8, [sp, #0x40]
10013a168: aa1e03e3    	mov	x3, x30
10013a16c: 97fd1b95    	bl	0x100080fc0 <_runtime.morestack_noctxt.abi0>
10013a170: a94087e0    	ldp	x0, x1, [sp, #0x8]
10013a174: a9418fe2    	ldp	x2, x3, [sp, #0x18]
10013a178: f94017e4    	ldr	x4, [sp, #0x28]
10013a17c: 3940c3e5    	ldrb	w5, [sp, #0x30]
10013a180: 3940c7e6    	ldrb	w6, [sp, #0x31]
10013a184: f9401fe7    	ldr	x7, [sp, #0x38]
10013a188: 394103e8    	ldrb	w8, [sp, #0x40]
10013a18c: 17fffebd    	b	0x100139c80 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB>


/private/tmp/govpx-lf-axis-private/validation/parent-darwin-amd.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

000000000115d400 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB>:
 115d400: 49 3b 66 10                  	cmpq	0x10(%r14), %rsp
 115d404: 0f 86 21 05 00 00            	jbe	0x115d92b <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x52b>
 115d40a: 55                           	pushq	%rbp
 115d40b: 48 89 e5                     	movq	%rsp, %rbp
 115d40e: 48 83 ec 60                  	subq	$0x60, %rsp
 115d412: 0f b6 16                     	movzbl	(%rsi), %edx
 115d415: 80 fa 04                     	cmpb	$0x4, %dl
 115d418: 74 0b                        	je	0x115d425 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x25>
 115d41a: 80 fa 09                     	cmpb	$0x9, %dl
 115d41d: 74 06                        	je	0x115d425 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x25>
 115d41f: 0f b6 56 09                  	movzbl	0x9(%rsi), %edx
 115d423: eb 02                        	jmp	0x115d427 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x27>
 115d425: 31 d2                        	xorl	%edx, %edx
 115d427: 41 84 02                     	testb	%al, (%r10)
 115d42a: 45 0f b6 e0                  	movzbl	%r8b, %r12d
 115d42e: 49 83 fc 02                  	cmpq	$0x2, %r12
 115d432: 0f 83 ed 04 00 00            	jae	0x115d925 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x525>
 115d438: 49 c1 e4 06                  	shlq	$0x6, %r12
 115d43c: 45 0f b6 e9                  	movzbl	%r9b, %r13d
 115d440: 4f 8d 24 22                  	leaq	(%r10,%r12), %r12
 115d444: 4d 8d a4 24 c4 00 00 00      	leaq	0xc4(%r12), %r12
 115d44c: 49 83 fd 40                  	cmpq	$0x40, %r13
 115d450: 0f 83 c3 04 00 00            	jae	0x115d919 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x519>
 115d456: 47 0f b6 24 2c               	movzbl	(%r12,%r13), %r12d
 115d45b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
 115d460: 49 83 fc 04                  	cmpq	$0x4, %r12
 115d464: 0f 83 aa 04 00 00            	jae	0x115d914 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x514>
 115d46a: 48 89 44 24 70               	movq	%rax, 0x70(%rsp)
 115d46f: 48 89 5c 24 78               	movq	%rbx, 0x78(%rsp)
 115d474: 48 89 bc 24 88 00 00 00      	movq	%rdi, 0x88(%rsp)
 115d47c: 44 88 9c 24 a8 00 00 00      	movb	%r11b, 0xa8(%rsp)
 115d484: 88 54 24 49                  	movb	%dl, 0x49(%rsp)
 115d488: 47 0f b6 8c 22 c0 00 00 00   	movzbl	0xc0(%r10,%r12), %r9d
 115d491: 44 88 4c 24 4c               	movb	%r9b, 0x4c(%rsp)
 115d496: 43 0f b6 34 2a               	movzbl	(%r10,%r13), %esi
 115d49b: 40 88 74 24 4a               	movb	%sil, 0x4a(%rsp)
 115d4a0: 47 0f b6 64 2a 40            	movzbl	0x40(%r10,%r13), %r12d
 115d4a6: 44 88 64 24 4f               	movb	%r12b, 0x4f(%rsp)
 115d4ab: 47 0f b6 84 2a 80 00 00 00   	movzbl	0x80(%r10,%r13), %r8d
 115d4b4: 44 88 44 24 4b               	movb	%r8b, 0x4b(%rsp)
 115d4b9: 0f 1f 80 00 00 00 00         	nopl	(%rax)
 115d4c0: 48 85 c9                     	testq	%rcx, %rcx
 115d4c3: 0f 8e bb 00 00 00            	jle	0x115d584 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x184>
 115d4c9: 84 d2                        	testb	%dl, %dl
 115d4cb: 74 0d                        	je	0x115d4da <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0xda>
 115d4cd: 48 85 c9                     	testq	%rcx, %rcx
 115d4d0: b9 00 00 00 00               	movl	$0x0, %ecx
 115d4d5: e9 af 00 00 00               	jmp	0x115d589 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x189>
 115d4da: 4c 8b 68 08                  	movq	0x8(%rax), %r13
 115d4de: 4c 8d 7f fc                  	leaq	-0x4(%rdi), %r15
 115d4e2: 4d 39 fd                     	cmpq	%r15, %r13
 115d4e5: 0f 82 24 04 00 00            	jb	0x115d90f <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x50f>
 115d4eb: 48 89 8c 24 80 00 00 00      	movq	%rcx, 0x80(%rsp)
 115d4f3: 48 8b 10                     	movq	(%rax), %rdx
 115d4f6: 48 8b 48 10                  	movq	0x10(%rax), %rcx
 115d4fa: 48 29 f9                     	subq	%rdi, %rcx
 115d4fd: 49 29 fd                     	subq	%rdi, %r13
 115d500: 48 83 c1 04                  	addq	$0x4, %rcx
 115d504: 48 89 cb                     	movq	%rcx, %rbx
 115d507: 48 f7 db                     	negq	%rbx
 115d50a: 49 83 c5 04                  	addq	$0x4, %r13
 115d50e: 48 c1 fb 3f                  	sarq	$0x3f, %rbx
 115d512: 4c 21 fb                     	andq	%r15, %rbx
 115d515: 48 01 da                     	addq	%rbx, %rdx
 115d518: 4c 8b b8 b0 00 00 00         	movq	0xb0(%rax), %r15
 115d51f: 48 89 d0                     	movq	%rdx, %rax
 115d522: 4c 89 eb                     	movq	%r13, %rbx
 115d525: bf 01 00 00 00               	movl	$0x1, %edi
 115d52a: 45 89 c2                     	movl	%r8d, %r10d
 115d52d: 45 89 cb                     	movl	%r9d, %r11d
 115d530: 41 89 f0                     	movl	%esi, %r8d
 115d533: 45 89 e1                     	movl	%r12d, %r9d
 115d536: 4c 89 fe                     	movq	%r15, %rsi
 115d539: e8 22 6a fe ff               	callq	0x1143f60 <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16>
 115d53e: 48 8b 94 24 80 00 00 00      	movq	0x80(%rsp), %rdx
 115d546: 48 85 d2                     	testq	%rdx, %rdx
 115d549: 0f b6 54 24 49               	movzbl	0x49(%rsp), %edx
 115d54e: 48 8b 5c 24 78               	movq	0x78(%rsp), %rbx
 115d553: 0f b6 74 24 4a               	movzbl	0x4a(%rsp), %esi
 115d558: 48 8b bc 24 88 00 00 00      	movq	0x88(%rsp), %rdi
 115d560: 44 0f b6 44 24 4b            	movzbl	0x4b(%rsp), %r8d
 115d566: 44 0f b6 4c 24 4c            	movzbl	0x4c(%rsp), %r9d
 115d56c: 44 0f b6 9c 24 a8 00 00 00   	movzbl	0xa8(%rsp), %r11d
 115d575: 44 0f b6 64 24 4f            	movzbl	0x4f(%rsp), %r12d
 115d57b: 89 c1                        	movl	%eax, %ecx
 115d57d: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
 115d582: eb 05                        	jmp	0x115d589 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x189>
 115d584: b9 00 00 00 00               	movl	$0x0, %ecx
 115d589: 0f 8e 94 00 00 00            	jle	0x115d623 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x223>
 115d58f: 84 c9                        	testb	%cl, %cl
 115d591: 0f 85 8c 00 00 00            	jne	0x115d623 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x223>
 115d597: 4c 8b 68 08                  	movq	0x8(%rax), %r13
 115d59b: 4c 8d 7f fc                  	leaq	-0x4(%rdi), %r15
 115d59f: 90                           	nop
 115d5a0: 4d 39 fd                     	cmpq	%r15, %r13
 115d5a3: 0f 82 61 03 00 00            	jb	0x115d90a <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x50a>
 115d5a9: 88 4c 24 4d                  	movb	%cl, 0x4d(%rsp)
 115d5ad: 48 8b 10                     	movq	(%rax), %rdx
 115d5b0: 48 8b 48 10                  	movq	0x10(%rax), %rcx
 115d5b4: 48 29 f9                     	subq	%rdi, %rcx
 115d5b7: 49 29 fd                     	subq	%rdi, %r13
 115d5ba: 48 83 c1 04                  	addq	$0x4, %rcx
 115d5be: 49 89 cb                     	movq	%rcx, %r11
 115d5c1: 49 f7 db                     	negq	%r11
 115d5c4: 49 8d 5d 04                  	leaq	0x4(%r13), %rbx
 115d5c8: 49 c1 fb 3f                  	sarq	$0x3f, %r11
 115d5cc: 4d 21 fb                     	andq	%r15, %r11
 115d5cf: 4c 01 da                     	addq	%r11, %rdx
 115d5d2: 48 8b b8 b0 00 00 00         	movq	0xb0(%rax), %rdi
 115d5d9: 48 89 d0                     	movq	%rdx, %rax
 115d5dc: 41 ba 02 00 00 00            	movl	$0x2, %r10d
 115d5e2: e8 59 43 ff ff               	callq	0x1151940 <_github.com/thesyncim/govpx/internal/vp8/dsp.mbLoopFilterVerticalEdgeDispatch>
 115d5e7: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
 115d5ec: 0f b6 4c 24 4d               	movzbl	0x4d(%rsp), %ecx
 115d5f1: 0f b6 54 24 49               	movzbl	0x49(%rsp), %edx
 115d5f6: 48 8b 5c 24 78               	movq	0x78(%rsp), %rbx
 115d5fb: 0f b6 74 24 4a               	movzbl	0x4a(%rsp), %esi
 115d600: 48 8b bc 24 88 00 00 00      	movq	0x88(%rsp), %rdi
 115d608: 44 0f b6 44 24 4b            	movzbl	0x4b(%rsp), %r8d
 115d60e: 44 0f b6 4c 24 4c            	movzbl	0x4c(%rsp), %r9d
 115d614: 44 0f b6 9c 24 a8 00 00 00   	movzbl	0xa8(%rsp), %r11d
 115d61d: 44 0f b6 64 24 4f            	movzbl	0x4f(%rsp), %r12d
 115d623: 84 d2                        	testb	%dl, %dl
 115d625: 75 7a                        	jne	0x115d6a1 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x2a1>
 115d627: 84 c9                        	testb	%cl, %cl
 115d629: 75 76                        	jne	0x115d6a1 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x2a1>
 115d62b: 4c 8b 50 08                  	movq	0x8(%rax), %r10
 115d62f: 4c 39 d7                     	cmpq	%r10, %rdi
 115d632: 0f 87 cd 02 00 00            	ja	0x115d905 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x505>
 115d638: 48 8b 10                     	movq	(%rax), %rdx
 115d63b: 48 8b 48 10                  	movq	0x10(%rax), %rcx
 115d63f: 48 29 f9                     	subq	%rdi, %rcx
 115d642: 49 29 fa                     	subq	%rdi, %r10
 115d645: 49 89 cb                     	movq	%rcx, %r11
 115d648: 49 f7 db                     	negq	%r11
 115d64b: 49 c1 fb 3f                  	sarq	$0x3f, %r11
 115d64f: 49 21 fb                     	andq	%rdi, %r11
 115d652: 4c 01 da                     	addq	%r11, %rdx
 115d655: 48 8b b8 b0 00 00 00         	movq	0xb0(%rax), %rdi
 115d65c: 48 89 d0                     	movq	%rdx, %rax
 115d65f: 4c 89 d3                     	movq	%r10, %rbx
 115d662: 44 89 e6                     	movl	%r12d, %esi
 115d665: e8 f6 3c ff ff               	callq	0x1151360 <_github.com/thesyncim/govpx/internal/vp8/dsp.loopFilterVerticalEdgesYDispatch>
 115d66a: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
 115d66f: 0f b6 54 24 49               	movzbl	0x49(%rsp), %edx
 115d674: 48 8b 5c 24 78               	movq	0x78(%rsp), %rbx
 115d679: 0f b6 74 24 4a               	movzbl	0x4a(%rsp), %esi
 115d67e: 48 8b bc 24 88 00 00 00      	movq	0x88(%rsp), %rdi
 115d686: 44 0f b6 44 24 4b            	movzbl	0x4b(%rsp), %r8d
 115d68c: 44 0f b6 4c 24 4c            	movzbl	0x4c(%rsp), %r9d
 115d692: 44 0f b6 9c 24 a8 00 00 00   	movzbl	0xa8(%rsp), %r11d
 115d69b: 44 0f b6 64 24 4f            	movzbl	0x4f(%rsp), %r12d
 115d6a1: 48 85 db                     	testq	%rbx, %rbx
 115d6a4: 7e 04                        	jle	0x115d6aa <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x2aa>
 115d6a6: 84 d2                        	testb	%dl, %dl
 115d6a8: eb 0b                        	jmp	0x115d6b5 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x2b5>
 115d6aa: 45 84 db                     	testb	%r11b, %r11b
 115d6ad: 0f 84 fb 00 00 00            	je	0x115d7ae <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3ae>
 115d6b3: 84 d2                        	testb	%dl, %dl
 115d6b5: 74 0e                        	je	0x115d6c5 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x2c5>
 115d6b7: 48 85 db                     	testq	%rbx, %rbx
 115d6ba: b9 00 00 00 00               	movl	$0x0, %ecx
 115d6bf: 90                           	nop
 115d6c0: e9 f1 00 00 00               	jmp	0x115d7b6 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3b6>
 115d6c5: 4c 8b a8 b0 00 00 00         	movq	0xb0(%rax), %r13
 115d6cc: 4d 89 ef                     	movq	%r13, %r15
 115d6cf: 49 c1 e5 02                  	shlq	$0x2, %r13
 115d6d3: 4c 29 ef                     	subq	%r13, %rdi
 115d6d6: 48 85 ff                     	testq	%rdi, %rdi
 115d6d9: 7c 34                        	jl	0x115d70f <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x30f>
 115d6db: 4c 8b 68 08                  	movq	0x8(%rax), %r13
 115d6df: 90                           	nop
 115d6e0: 49 39 fd                     	cmpq	%rdi, %r13
 115d6e3: 0f 82 16 02 00 00            	jb	0x115d8ff <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4ff>
 115d6e9: 4c 8b 10                     	movq	(%rax), %r10
 115d6ec: 48 8b 48 10                  	movq	0x10(%rax), %rcx
 115d6f0: 48 29 f9                     	subq	%rdi, %rcx
 115d6f3: 48 89 4c 24 58               	movq	%rcx, 0x58(%rsp)
 115d6f8: 48 f7 d9                     	negq	%rcx
 115d6fb: 48 c1 f9 3f                  	sarq	$0x3f, %rcx
 115d6ff: 48 21 f9                     	andq	%rdi, %rcx
 115d702: 49 29 fd                     	subq	%rdi, %r13
 115d705: 4c 01 d1                     	addq	%r10, %rcx
 115d708: 48 8b 7c 24 58               	movq	0x58(%rsp), %rdi
 115d70d: eb 3f                        	jmp	0x115d74e <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x34e>
 115d70f: 4c 8b 68 50                  	movq	0x50(%rax), %r13
 115d713: 4c 8b 90 c8 00 00 00         	movq	0xc8(%rax), %r10
 115d71a: 4c 01 d7                     	addq	%r10, %rdi
 115d71d: 0f 1f 00                     	nopl	(%rax)
 115d720: 49 39 fd                     	cmpq	%rdi, %r13
 115d723: 0f 82 d1 01 00 00            	jb	0x115d8fa <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4fa>
 115d729: 4c 8b 50 48                  	movq	0x48(%rax), %r10
 115d72d: 48 8b 48 58                  	movq	0x58(%rax), %rcx
 115d731: 48 29 f9                     	subq	%rdi, %rcx
 115d734: 48 89 4c 24 58               	movq	%rcx, 0x58(%rsp)
 115d739: 48 f7 d9                     	negq	%rcx
 115d73c: 48 c1 f9 3f                  	sarq	$0x3f, %rcx
 115d740: 48 21 f9                     	andq	%rdi, %rcx
 115d743: 49 29 fd                     	subq	%rdi, %r13
 115d746: 4c 01 d1                     	addq	%r10, %rcx
 115d749: 48 8b 7c 24 58               	movq	0x58(%rsp), %rdi
 115d74e: 48 89 c8                     	movq	%rcx, %rax
 115d751: 4c 89 eb                     	movq	%r13, %rbx
 115d754: 48 89 f9                     	movq	%rdi, %rcx
 115d757: 4c 89 ff                     	movq	%r15, %rdi
 115d75a: 45 89 c2                     	movl	%r8d, %r10d
 115d75d: 45 89 cb                     	movl	%r9d, %r11d
 115d760: 41 89 f0                     	movl	%esi, %r8d
 115d763: 45 89 e1                     	movl	%r12d, %r9d
 115d766: be 01 00 00 00               	movl	$0x1, %esi
 115d76b: e8 f0 67 fe ff               	callq	0x1143f60 <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16>
 115d770: 48 8b 54 24 78               	movq	0x78(%rsp), %rdx
 115d775: 48 85 d2                     	testq	%rdx, %rdx
 115d778: 0f b6 54 24 49               	movzbl	0x49(%rsp), %edx
 115d77d: 0f b6 74 24 4a               	movzbl	0x4a(%rsp), %esi
 115d782: 48 8b bc 24 88 00 00 00      	movq	0x88(%rsp), %rdi
 115d78a: 44 0f b6 44 24 4b            	movzbl	0x4b(%rsp), %r8d
 115d790: 44 0f b6 4c 24 4c            	movzbl	0x4c(%rsp), %r9d
 115d796: 44 0f b6 9c 24 a8 00 00 00   	movzbl	0xa8(%rsp), %r11d
 115d79f: 44 0f b6 64 24 4f            	movzbl	0x4f(%rsp), %r12d
 115d7a5: 89 c1                        	movl	%eax, %ecx
 115d7a7: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
 115d7ac: eb 08                        	jmp	0x115d7b6 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3b6>
 115d7ae: 48 85 db                     	testq	%rbx, %rbx
 115d7b1: b9 00 00 00 00               	movl	$0x0, %ecx
 115d7b6: 7f 11                        	jg	0x115d7c9 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3c9>
 115d7b8: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)
 115d7c0: 45 84 db                     	testb	%r11b, %r11b
 115d7c3: 0f 84 d9 00 00 00            	je	0x115d8a2 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4a2>
 115d7c9: 84 c9                        	testb	%cl, %cl
 115d7cb: 74 07                        	je	0x115d7d4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3d4>
 115d7cd: 84 d2                        	testb	%dl, %dl
 115d7cf: e9 d0 00 00 00               	jmp	0x115d8a4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4a4>
 115d7d4: 88 4c 24 4e                  	movb	%cl, 0x4e(%rsp)
 115d7d8: 4c 8b 98 b0 00 00 00         	movq	0xb0(%rax), %r11
 115d7df: 4d 89 dd                     	movq	%r11, %r13
 115d7e2: 49 c1 e3 02                  	shlq	$0x2, %r11
 115d7e6: 4c 29 df                     	subq	%r11, %rdi
 115d7e9: 48 85 ff                     	testq	%rdi, %rdi
 115d7ec: 7c 34                        	jl	0x115d822 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x422>
 115d7ee: 48 8b 58 08                  	movq	0x8(%rax), %rbx
 115d7f2: 48 39 fb                     	cmpq	%rdi, %rbx
 115d7f5: 0f 82 fa 00 00 00            	jb	0x115d8f5 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4f5>
 115d7fb: 4c 8b 18                     	movq	(%rax), %r11
 115d7fe: 4c 8b 50 10                  	movq	0x10(%rax), %r10
 115d802: 49 29 fa                     	subq	%rdi, %r10
 115d805: 4c 89 54 24 50               	movq	%r10, 0x50(%rsp)
 115d80a: 49 f7 da                     	negq	%r10
 115d80d: 49 c1 fa 3f                  	sarq	$0x3f, %r10
 115d811: 49 21 fa                     	andq	%rdi, %r10
 115d814: 48 29 fb                     	subq	%rdi, %rbx
 115d817: 4d 01 d3                     	addq	%r10, %r11
 115d81a: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
 115d81f: 90                           	nop
 115d820: eb 3d                        	jmp	0x115d85f <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x45f>
 115d822: 48 8b 58 50                  	movq	0x50(%rax), %rbx
 115d826: 4c 8b 98 c8 00 00 00         	movq	0xc8(%rax), %r11
 115d82d: 49 01 fb                     	addq	%rdi, %r11
 115d830: 4c 39 db                     	cmpq	%r11, %rbx
 115d833: 0f 82 b7 00 00 00            	jb	0x115d8f0 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4f0>
 115d839: 48 8b 78 48                  	movq	0x48(%rax), %rdi
 115d83d: 4c 8b 50 58                  	movq	0x58(%rax), %r10
 115d841: 4d 29 da                     	subq	%r11, %r10
 115d844: 4c 89 54 24 50               	movq	%r10, 0x50(%rsp)
 115d849: 49 f7 da                     	negq	%r10
 115d84c: 49 c1 fa 3f                  	sarq	$0x3f, %r10
 115d850: 4d 21 da                     	andq	%r11, %r10
 115d853: 4c 29 db                     	subq	%r11, %rbx
 115d856: 4e 8d 1c 17                  	leaq	(%rdi,%r10), %r11
 115d85a: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
 115d85f: 4c 89 d8                     	movq	%r11, %rax
 115d862: 48 89 f9                     	movq	%rdi, %rcx
 115d865: 4c 89 ef                     	movq	%r13, %rdi
 115d868: 41 ba 02 00 00 00            	movl	$0x2, %r10d
 115d86e: e8 8d 3f ff ff               	callq	0x1151800 <_github.com/thesyncim/govpx/internal/vp8/dsp.mbLoopFilterHorizontalEdgeDispatch>
 115d873: 0f b6 54 24 49               	movzbl	0x49(%rsp), %edx
 115d878: 84 d2                        	testb	%dl, %dl
 115d87a: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
 115d87f: 0f b6 4c 24 4e               	movzbl	0x4e(%rsp), %ecx
 115d884: 48 8b bc 24 88 00 00 00      	movq	0x88(%rsp), %rdi
 115d88c: 44 0f b6 44 24 4b            	movzbl	0x4b(%rsp), %r8d
 115d892: 44 0f b6 4c 24 4c            	movzbl	0x4c(%rsp), %r9d
 115d898: 44 0f b6 64 24 4f            	movzbl	0x4f(%rsp), %r12d
 115d89e: 66 90                        	nop
 115d8a0: eb 02                        	jmp	0x115d8a4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4a4>
 115d8a2: 84 d2                        	testb	%dl, %dl
 115d8a4: 75 3f                        	jne	0x115d8e5 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4e5>
 115d8a6: 84 c9                        	testb	%cl, %cl
 115d8a8: 75 3b                        	jne	0x115d8e5 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4e5>
 115d8aa: 48 8b 58 08                  	movq	0x8(%rax), %rbx
 115d8ae: 48 39 df                     	cmpq	%rbx, %rdi
 115d8b1: 77 38                        	ja	0x115d8eb <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4eb>
 115d8b3: 48 8b 10                     	movq	(%rax), %rdx
 115d8b6: 48 8b 48 10                  	movq	0x10(%rax), %rcx
 115d8ba: 48 29 f9                     	subq	%rdi, %rcx
 115d8bd: 48 29 fb                     	subq	%rdi, %rbx
 115d8c0: 49 89 ca                     	movq	%rcx, %r10
 115d8c3: 49 f7 da                     	negq	%r10
 115d8c6: 49 c1 fa 3f                  	sarq	$0x3f, %r10
 115d8ca: 49 21 fa                     	andq	%rdi, %r10
 115d8cd: 4c 01 d2                     	addq	%r10, %rdx
 115d8d0: 48 8b b8 b0 00 00 00         	movq	0xb0(%rax), %rdi
 115d8d7: 48 89 d0                     	movq	%rdx, %rax
 115d8da: 44 89 e6                     	movl	%r12d, %esi
 115d8dd: 0f 1f 00                     	nopl	(%rax)
 115d8e0: e8 7b 37 ff ff               	callq	0x1151060 <_github.com/thesyncim/govpx/internal/vp8/dsp.loopFilterHorizontalEdgesYDispatch>
 115d8e5: 48 83 c4 60                  	addq	$0x60, %rsp
 115d8e9: 5d                           	popq	%rbp
 115d8ea: c3                           	retq
 115d8eb: e8 30 b5 f2 ff               	callq	0x1088e20 <_runtime.panicBounds>
 115d8f0: e8 2b b5 f2 ff               	callq	0x1088e20 <_runtime.panicBounds>
 115d8f5: e8 26 b5 f2 ff               	callq	0x1088e20 <_runtime.panicBounds>
 115d8fa: e8 21 b5 f2 ff               	callq	0x1088e20 <_runtime.panicBounds>
 115d8ff: 90                           	nop
 115d900: e8 1b b5 f2 ff               	callq	0x1088e20 <_runtime.panicBounds>
 115d905: e8 16 b5 f2 ff               	callq	0x1088e20 <_runtime.panicBounds>
 115d90a: e8 11 b5 f2 ff               	callq	0x1088e20 <_runtime.panicBounds>
 115d90f: e8 0c b5 f2 ff               	callq	0x1088e20 <_runtime.panicBounds>
 115d914: e8 07 b5 f2 ff               	callq	0x1088e20 <_runtime.panicBounds>
 115d919: b8 40 00 00 00               	movl	$0x40, %eax
 115d91e: 66 90                        	nop
 115d920: e8 fb b4 f2 ff               	callq	0x1088e20 <_runtime.panicBounds>
 115d925: e8 f6 b4 f2 ff               	callq	0x1088e20 <_runtime.panicBounds>
 115d92a: 90                           	nop
 115d92b: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
 115d930: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
 115d935: 48 89 4c 24 18               	movq	%rcx, 0x18(%rsp)
 115d93a: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
 115d93f: 48 89 74 24 28               	movq	%rsi, 0x28(%rsp)
 115d944: 44 88 44 24 30               	movb	%r8b, 0x30(%rsp)
 115d949: 44 88 4c 24 31               	movb	%r9b, 0x31(%rsp)
 115d94e: 4c 89 54 24 38               	movq	%r10, 0x38(%rsp)
 115d953: 44 88 5c 24 40               	movb	%r11b, 0x40(%rsp)
 115d958: e8 63 98 f2 ff               	callq	0x10871c0 <_runtime.morestack_noctxt.abi0>
 115d95d: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
 115d962: 48 8b 5c 24 10               	movq	0x10(%rsp), %rbx
 115d967: 48 8b 4c 24 18               	movq	0x18(%rsp), %rcx
 115d96c: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
 115d971: 48 8b 74 24 28               	movq	0x28(%rsp), %rsi
 115d976: 44 0f b6 44 24 30            	movzbl	0x30(%rsp), %r8d
 115d97c: 44 0f b6 4c 24 31            	movzbl	0x31(%rsp), %r9d
 115d982: 4c 8b 54 24 38               	movq	0x38(%rsp), %r10
 115d987: 44 0f b6 5c 24 40            	movzbl	0x40(%rsp), %r11d
 115d98d: e9 6e fa ff ff               	jmp	0x115d400 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB>
 115d992: cc                           	int3
 115d993: cc                           	int3
 115d994: cc                           	int3
 115d995: cc                           	int3
 115d996: cc                           	int3
 115d997: cc                           	int3
 115d998: cc                           	int3
 115d999: cc                           	int3
 115d99a: cc                           	int3
 115d99b: cc                           	int3
 115d99c: cc                           	int3
 115d99d: cc                           	int3
 115d99e: cc                           	int3
 115d99f: cc                           	int3

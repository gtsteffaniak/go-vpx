
/private/tmp/govpx-lf-axis-private/validation/parent-arm.test:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100127090 <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16>:
100127090: f9400b90    	ldr	x16, [x28, #0x10]
100127094: eb3063ff    	cmp	sp, x16
100127098: 54000a09    	b.ls	0x1001271d8 <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x148>
10012709c: f81b0ffe    	str	x30, [sp, #-0x50]!
1001270a0: f81f83fd    	stur	x29, [sp, #-0x8]
1001270a4: d10023fd    	sub	x29, sp, #0x8
1001270a8: f9002fe0    	str	x0, [sp, #0x58]
1001270ac: f100007f    	cmp	x3, #0x0
1001270b0: 5400016d    	b.le	0x1001270dc <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x4c>
1001270b4: f100009f    	cmp	x4, #0x0
1001270b8: 5400012d    	b.le	0x1001270dc <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x4c>
1001270bc: f103fcbf    	cmp	x5, #0xff
1001270c0: 540000e2    	b.hs	0x1001270dc <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x4c>
1001270c4: f103fcdf    	cmp	x6, #0xff
1001270c8: 540000a2    	b.hs	0x1001270dc <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x4c>
1001270cc: f103fcff    	cmp	x7, #0xff
1001270d0: 54000068    	b.hi	0x1001270dc <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x4c>
1001270d4: f103fd1f    	cmp	x8, #0xff
1001270d8: 540000a9    	b.ls	0x1001270ec <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x5c>
1001270dc: aa1f03e0    	mov	x0, xzr
1001270e0: f85f83fd    	ldur	x29, [sp, #-0x8]
1001270e4: f84507fe    	ldr	x30, [sp], #0x50
1001270e8: d65f03c0    	ret
1001270ec: f100049f    	cmp	x4, #0x1
1001270f0: 54000061    	b.ne	0x1001270fc <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x6c>
1001270f4: f100407f    	cmp	x3, #0x10
1001270f8: 540000aa    	b.ge	0x10012710c <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x7c>
1001270fc: f100047f    	cmp	x3, #0x1
100127100: 54000641    	b.ne	0x1001271c8 <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x138>
100127104: f100509f    	cmp	x4, #0x14
100127108: 5400060b    	b.lt	0x1001271c8 <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x138>
10012710c: b40005e1    	cbz	x1, 0x1001271c8 <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x138>
100127110: d1000429    	sub	x9, x1, #0x1
100127114: d2886bea    	mov	x10, #0x435f            ; =17247
100127118: f2a1af2a    	movk	x10, #0xd79, lsl #16
10012711c: f2c6bcaa    	movk	x10, #0x35e5, lsl #32
100127120: f2faf28a    	movk	x10, #0xd794, lsl #48
100127124: 9bca7d29    	umulh	x9, x9, x10
100127128: eb49107f    	cmp	x3, x9, lsr #4
10012712c: 5400046c    	b.gt	0x1001271b8 <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x128>
100127130: d2800269    	mov	x9, #0x13               ; =19
100127134: 9b098469    	msub	x9, x3, x9, x1
100127138: d100052a    	sub	x10, x9, #0x1
10012713c: b201e3eb    	mov	x11, #-0x7777777777777778 ; =-8608480567731124088
100127140: f291112b    	movk	x11, #0x8889
100127144: 9b4b7d4b    	smulh	x11, x10, x11
100127148: 8b0b0129    	add	x9, x9, x11
10012714c: d1000529    	sub	x9, x9, #0x1
100127150: 9343fd29    	asr	x9, x9, #3
100127154: cb8afd29    	sub	x9, x9, x10, asr #63
100127158: eb09009f    	cmp	x4, x9
10012715c: 5400026c    	b.gt	0x1001271a8 <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x118>
100127160: f100049f    	cmp	x4, #0x1
100127164: 540000e1    	b.ne	0x100127180 <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0xf0>
100127168: aa0503e4    	mov	x4, x5
10012716c: aa0603e5    	mov	x5, x6
100127170: aa0703e6    	mov	x6, x7
100127174: aa0803e7    	mov	x7, x8
100127178: 94000026    	bl	0x100127210 <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedHorizontal>
10012717c: 14000007    	b	0x100127198 <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16+0x108>
100127180: aa0403e3    	mov	x3, x4
100127184: aa0503e4    	mov	x4, x5
100127188: aa0603e5    	mov	x5, x6
10012718c: aa0703e6    	mov	x6, x7
100127190: aa0803e7    	mov	x7, x8
100127194: 9400018b    	bl	0x1001277c0 <_github.com/thesyncim/govpx/internal/pixel.loopFilterMacroInternalFusedVertical>
100127198: b24003e0    	orr	x0, xzr, #0x1
10012719c: f85f83fd    	ldur	x29, [sp, #-0x8]
1001271a0: f84507fe    	ldr	x30, [sp], #0x50
1001271a4: d65f03c0    	ret
1001271a8: aa1f03e0    	mov	x0, xzr
1001271ac: f85f83fd    	ldur	x29, [sp, #-0x8]
1001271b0: f84507fe    	ldr	x30, [sp], #0x50
1001271b4: d65f03c0    	ret
1001271b8: aa1f03e0    	mov	x0, xzr
1001271bc: f85f83fd    	ldur	x29, [sp, #-0x8]
1001271c0: f84507fe    	ldr	x30, [sp], #0x50
1001271c4: d65f03c0    	ret
1001271c8: aa1f03e0    	mov	x0, xzr
1001271cc: f85f83fd    	ldur	x29, [sp, #-0x8]
1001271d0: f84507fe    	ldr	x30, [sp], #0x50
1001271d4: d65f03c0    	ret
1001271d8: a90087e0    	stp	x0, x1, [sp, #0x8]
1001271dc: a9018fe2    	stp	x2, x3, [sp, #0x18]
1001271e0: a90297e4    	stp	x4, x5, [sp, #0x28]
1001271e4: a9039fe6    	stp	x6, x7, [sp, #0x38]
1001271e8: f90027e8    	str	x8, [sp, #0x48]
1001271ec: aa1e03e3    	mov	x3, x30
1001271f0: 97fd6774    	bl	0x100080fc0 <_runtime.morestack_noctxt.abi0>
1001271f4: a94087e0    	ldp	x0, x1, [sp, #0x8]
1001271f8: a9418fe2    	ldp	x2, x3, [sp, #0x18]
1001271fc: a94297e4    	ldp	x4, x5, [sp, #0x28]
100127200: a9439fe6    	ldp	x6, x7, [sp, #0x38]
100127204: f94027e8    	ldr	x8, [sp, #0x48]
100127208: 17ffffa2    	b	0x100127090 <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16>
10012720c: 00000000    	udf	#0x0

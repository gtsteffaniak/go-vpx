
/private/tmp/govpx-lf-axis-private/validation/parent-linux-amd.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000567740 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB>:
  567740: 49 3b 66 10                  	cmpq	0x10(%r14), %rsp
  567744: 0f 86 21 05 00 00            	jbe	0x567c6b <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x52b>
  56774a: 55                           	pushq	%rbp
  56774b: 48 89 e5                     	movq	%rsp, %rbp
  56774e: 48 83 ec 60                  	subq	$0x60, %rsp
  567752: 0f b6 16                     	movzbl	(%rsi), %edx
  567755: 80 fa 04                     	cmpb	$0x4, %dl
  567758: 74 0b                        	je	0x567765 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x25>
  56775a: 80 fa 09                     	cmpb	$0x9, %dl
  56775d: 74 06                        	je	0x567765 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x25>
  56775f: 0f b6 56 09                  	movzbl	0x9(%rsi), %edx
  567763: eb 02                        	jmp	0x567767 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x27>
  567765: 31 d2                        	xorl	%edx, %edx
  567767: 41 84 02                     	testb	%al, (%r10)
  56776a: 45 0f b6 e0                  	movzbl	%r8b, %r12d
  56776e: 49 83 fc 02                  	cmpq	$0x2, %r12
  567772: 0f 83 ed 04 00 00            	jae	0x567c65 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x525>
  567778: 49 c1 e4 06                  	shlq	$0x6, %r12
  56777c: 45 0f b6 e9                  	movzbl	%r9b, %r13d
  567780: 4f 8d 24 22                  	leaq	(%r10,%r12), %r12
  567784: 4d 8d a4 24 c4 00 00 00      	leaq	0xc4(%r12), %r12
  56778c: 49 83 fd 40                  	cmpq	$0x40, %r13
  567790: 0f 83 c3 04 00 00            	jae	0x567c59 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x519>
  567796: 47 0f b6 24 2c               	movzbl	(%r12,%r13), %r12d
  56779b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  5677a0: 49 83 fc 04                  	cmpq	$0x4, %r12
  5677a4: 0f 83 aa 04 00 00            	jae	0x567c54 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x514>
  5677aa: 48 89 44 24 70               	movq	%rax, 0x70(%rsp)
  5677af: 48 89 5c 24 78               	movq	%rbx, 0x78(%rsp)
  5677b4: 48 89 bc 24 88 00 00 00      	movq	%rdi, 0x88(%rsp)
  5677bc: 44 88 9c 24 a8 00 00 00      	movb	%r11b, 0xa8(%rsp)
  5677c4: 88 54 24 49                  	movb	%dl, 0x49(%rsp)
  5677c8: 47 0f b6 8c 22 c0 00 00 00   	movzbl	0xc0(%r10,%r12), %r9d
  5677d1: 44 88 4c 24 4c               	movb	%r9b, 0x4c(%rsp)
  5677d6: 43 0f b6 34 2a               	movzbl	(%r10,%r13), %esi
  5677db: 40 88 74 24 4a               	movb	%sil, 0x4a(%rsp)
  5677e0: 47 0f b6 64 2a 40            	movzbl	0x40(%r10,%r13), %r12d
  5677e6: 44 88 64 24 4f               	movb	%r12b, 0x4f(%rsp)
  5677eb: 47 0f b6 84 2a 80 00 00 00   	movzbl	0x80(%r10,%r13), %r8d
  5677f4: 44 88 44 24 4b               	movb	%r8b, 0x4b(%rsp)
  5677f9: 0f 1f 80 00 00 00 00         	nopl	(%rax)
  567800: 48 85 c9                     	testq	%rcx, %rcx
  567803: 0f 8e bb 00 00 00            	jle	0x5678c4 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x184>
  567809: 84 d2                        	testb	%dl, %dl
  56780b: 74 0d                        	je	0x56781a <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0xda>
  56780d: 48 85 c9                     	testq	%rcx, %rcx
  567810: b9 00 00 00 00               	movl	$0x0, %ecx
  567815: e9 af 00 00 00               	jmp	0x5678c9 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x189>
  56781a: 4c 8b 68 08                  	movq	0x8(%rax), %r13
  56781e: 4c 8d 7f fc                  	leaq	-0x4(%rdi), %r15
  567822: 4d 39 fd                     	cmpq	%r15, %r13
  567825: 0f 82 24 04 00 00            	jb	0x567c4f <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x50f>
  56782b: 48 89 8c 24 80 00 00 00      	movq	%rcx, 0x80(%rsp)
  567833: 48 8b 10                     	movq	(%rax), %rdx
  567836: 48 8b 48 10                  	movq	0x10(%rax), %rcx
  56783a: 48 29 f9                     	subq	%rdi, %rcx
  56783d: 49 29 fd                     	subq	%rdi, %r13
  567840: 48 83 c1 04                  	addq	$0x4, %rcx
  567844: 48 89 cb                     	movq	%rcx, %rbx
  567847: 48 f7 db                     	negq	%rbx
  56784a: 49 83 c5 04                  	addq	$0x4, %r13
  56784e: 48 c1 fb 3f                  	sarq	$0x3f, %rbx
  567852: 4c 21 fb                     	andq	%r15, %rbx
  567855: 48 01 da                     	addq	%rbx, %rdx
  567858: 4c 8b b8 b0 00 00 00         	movq	0xb0(%rax), %r15
  56785f: 48 89 d0                     	movq	%rdx, %rax
  567862: 4c 89 eb                     	movq	%r13, %rbx
  567865: bf 01 00 00 00               	movl	$0x1, %edi
  56786a: 45 89 c2                     	movl	%r8d, %r10d
  56786d: 45 89 cb                     	movl	%r9d, %r11d
  567870: 41 89 f0                     	movl	%esi, %r8d
  567873: 45 89 e1                     	movl	%r12d, %r9d
  567876: 4c 89 fe                     	movq	%r15, %rsi
  567879: e8 22 6a fe ff               	callq	0x54e2a0 <github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16>
  56787e: 48 8b 94 24 80 00 00 00      	movq	0x80(%rsp), %rdx
  567886: 48 85 d2                     	testq	%rdx, %rdx
  567889: 0f b6 54 24 49               	movzbl	0x49(%rsp), %edx
  56788e: 48 8b 5c 24 78               	movq	0x78(%rsp), %rbx
  567893: 0f b6 74 24 4a               	movzbl	0x4a(%rsp), %esi
  567898: 48 8b bc 24 88 00 00 00      	movq	0x88(%rsp), %rdi
  5678a0: 44 0f b6 44 24 4b            	movzbl	0x4b(%rsp), %r8d
  5678a6: 44 0f b6 4c 24 4c            	movzbl	0x4c(%rsp), %r9d
  5678ac: 44 0f b6 9c 24 a8 00 00 00   	movzbl	0xa8(%rsp), %r11d
  5678b5: 44 0f b6 64 24 4f            	movzbl	0x4f(%rsp), %r12d
  5678bb: 89 c1                        	movl	%eax, %ecx
  5678bd: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
  5678c2: eb 05                        	jmp	0x5678c9 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x189>
  5678c4: b9 00 00 00 00               	movl	$0x0, %ecx
  5678c9: 0f 8e 94 00 00 00            	jle	0x567963 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x223>
  5678cf: 84 c9                        	testb	%cl, %cl
  5678d1: 0f 85 8c 00 00 00            	jne	0x567963 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x223>
  5678d7: 4c 8b 68 08                  	movq	0x8(%rax), %r13
  5678db: 4c 8d 7f fc                  	leaq	-0x4(%rdi), %r15
  5678df: 90                           	nop
  5678e0: 4d 39 fd                     	cmpq	%r15, %r13
  5678e3: 0f 82 61 03 00 00            	jb	0x567c4a <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x50a>
  5678e9: 88 4c 24 4d                  	movb	%cl, 0x4d(%rsp)
  5678ed: 48 8b 10                     	movq	(%rax), %rdx
  5678f0: 48 8b 48 10                  	movq	0x10(%rax), %rcx
  5678f4: 48 29 f9                     	subq	%rdi, %rcx
  5678f7: 49 29 fd                     	subq	%rdi, %r13
  5678fa: 48 83 c1 04                  	addq	$0x4, %rcx
  5678fe: 49 89 cb                     	movq	%rcx, %r11
  567901: 49 f7 db                     	negq	%r11
  567904: 49 8d 5d 04                  	leaq	0x4(%r13), %rbx
  567908: 49 c1 fb 3f                  	sarq	$0x3f, %r11
  56790c: 4d 21 fb                     	andq	%r15, %r11
  56790f: 4c 01 da                     	addq	%r11, %rdx
  567912: 48 8b b8 b0 00 00 00         	movq	0xb0(%rax), %rdi
  567919: 48 89 d0                     	movq	%rdx, %rax
  56791c: 41 ba 02 00 00 00            	movl	$0x2, %r10d
  567922: e8 59 43 ff ff               	callq	0x55bc80 <github.com/thesyncim/govpx/internal/vp8/dsp.mbLoopFilterVerticalEdgeDispatch>
  567927: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
  56792c: 0f b6 4c 24 4d               	movzbl	0x4d(%rsp), %ecx
  567931: 0f b6 54 24 49               	movzbl	0x49(%rsp), %edx
  567936: 48 8b 5c 24 78               	movq	0x78(%rsp), %rbx
  56793b: 0f b6 74 24 4a               	movzbl	0x4a(%rsp), %esi
  567940: 48 8b bc 24 88 00 00 00      	movq	0x88(%rsp), %rdi
  567948: 44 0f b6 44 24 4b            	movzbl	0x4b(%rsp), %r8d
  56794e: 44 0f b6 4c 24 4c            	movzbl	0x4c(%rsp), %r9d
  567954: 44 0f b6 9c 24 a8 00 00 00   	movzbl	0xa8(%rsp), %r11d
  56795d: 44 0f b6 64 24 4f            	movzbl	0x4f(%rsp), %r12d
  567963: 84 d2                        	testb	%dl, %dl
  567965: 75 7a                        	jne	0x5679e1 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x2a1>
  567967: 84 c9                        	testb	%cl, %cl
  567969: 75 76                        	jne	0x5679e1 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x2a1>
  56796b: 4c 8b 50 08                  	movq	0x8(%rax), %r10
  56796f: 4c 39 d7                     	cmpq	%r10, %rdi
  567972: 0f 87 cd 02 00 00            	ja	0x567c45 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x505>
  567978: 48 8b 10                     	movq	(%rax), %rdx
  56797b: 48 8b 48 10                  	movq	0x10(%rax), %rcx
  56797f: 48 29 f9                     	subq	%rdi, %rcx
  567982: 49 29 fa                     	subq	%rdi, %r10
  567985: 49 89 cb                     	movq	%rcx, %r11
  567988: 49 f7 db                     	negq	%r11
  56798b: 49 c1 fb 3f                  	sarq	$0x3f, %r11
  56798f: 49 21 fb                     	andq	%rdi, %r11
  567992: 4c 01 da                     	addq	%r11, %rdx
  567995: 48 8b b8 b0 00 00 00         	movq	0xb0(%rax), %rdi
  56799c: 48 89 d0                     	movq	%rdx, %rax
  56799f: 4c 89 d3                     	movq	%r10, %rbx
  5679a2: 44 89 e6                     	movl	%r12d, %esi
  5679a5: e8 f6 3c ff ff               	callq	0x55b6a0 <github.com/thesyncim/govpx/internal/vp8/dsp.loopFilterVerticalEdgesYDispatch>
  5679aa: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
  5679af: 0f b6 54 24 49               	movzbl	0x49(%rsp), %edx
  5679b4: 48 8b 5c 24 78               	movq	0x78(%rsp), %rbx
  5679b9: 0f b6 74 24 4a               	movzbl	0x4a(%rsp), %esi
  5679be: 48 8b bc 24 88 00 00 00      	movq	0x88(%rsp), %rdi
  5679c6: 44 0f b6 44 24 4b            	movzbl	0x4b(%rsp), %r8d
  5679cc: 44 0f b6 4c 24 4c            	movzbl	0x4c(%rsp), %r9d
  5679d2: 44 0f b6 9c 24 a8 00 00 00   	movzbl	0xa8(%rsp), %r11d
  5679db: 44 0f b6 64 24 4f            	movzbl	0x4f(%rsp), %r12d
  5679e1: 48 85 db                     	testq	%rbx, %rbx
  5679e4: 7e 04                        	jle	0x5679ea <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x2aa>
  5679e6: 84 d2                        	testb	%dl, %dl
  5679e8: eb 0b                        	jmp	0x5679f5 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x2b5>
  5679ea: 45 84 db                     	testb	%r11b, %r11b
  5679ed: 0f 84 fb 00 00 00            	je	0x567aee <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3ae>
  5679f3: 84 d2                        	testb	%dl, %dl
  5679f5: 74 0e                        	je	0x567a05 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x2c5>
  5679f7: 48 85 db                     	testq	%rbx, %rbx
  5679fa: b9 00 00 00 00               	movl	$0x0, %ecx
  5679ff: 90                           	nop
  567a00: e9 f1 00 00 00               	jmp	0x567af6 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3b6>
  567a05: 4c 8b a8 b0 00 00 00         	movq	0xb0(%rax), %r13
  567a0c: 4d 89 ef                     	movq	%r13, %r15
  567a0f: 49 c1 e5 02                  	shlq	$0x2, %r13
  567a13: 4c 29 ef                     	subq	%r13, %rdi
  567a16: 48 85 ff                     	testq	%rdi, %rdi
  567a19: 7c 34                        	jl	0x567a4f <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x30f>
  567a1b: 4c 8b 68 08                  	movq	0x8(%rax), %r13
  567a1f: 90                           	nop
  567a20: 49 39 fd                     	cmpq	%rdi, %r13
  567a23: 0f 82 16 02 00 00            	jb	0x567c3f <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4ff>
  567a29: 4c 8b 10                     	movq	(%rax), %r10
  567a2c: 48 8b 48 10                  	movq	0x10(%rax), %rcx
  567a30: 48 29 f9                     	subq	%rdi, %rcx
  567a33: 48 89 4c 24 58               	movq	%rcx, 0x58(%rsp)
  567a38: 48 f7 d9                     	negq	%rcx
  567a3b: 48 c1 f9 3f                  	sarq	$0x3f, %rcx
  567a3f: 48 21 f9                     	andq	%rdi, %rcx
  567a42: 49 29 fd                     	subq	%rdi, %r13
  567a45: 4c 01 d1                     	addq	%r10, %rcx
  567a48: 48 8b 7c 24 58               	movq	0x58(%rsp), %rdi
  567a4d: eb 3f                        	jmp	0x567a8e <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x34e>
  567a4f: 4c 8b 68 50                  	movq	0x50(%rax), %r13
  567a53: 4c 8b 90 c8 00 00 00         	movq	0xc8(%rax), %r10
  567a5a: 4c 01 d7                     	addq	%r10, %rdi
  567a5d: 0f 1f 00                     	nopl	(%rax)
  567a60: 49 39 fd                     	cmpq	%rdi, %r13
  567a63: 0f 82 d1 01 00 00            	jb	0x567c3a <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4fa>
  567a69: 4c 8b 50 48                  	movq	0x48(%rax), %r10
  567a6d: 48 8b 48 58                  	movq	0x58(%rax), %rcx
  567a71: 48 29 f9                     	subq	%rdi, %rcx
  567a74: 48 89 4c 24 58               	movq	%rcx, 0x58(%rsp)
  567a79: 48 f7 d9                     	negq	%rcx
  567a7c: 48 c1 f9 3f                  	sarq	$0x3f, %rcx
  567a80: 48 21 f9                     	andq	%rdi, %rcx
  567a83: 49 29 fd                     	subq	%rdi, %r13
  567a86: 4c 01 d1                     	addq	%r10, %rcx
  567a89: 48 8b 7c 24 58               	movq	0x58(%rsp), %rdi
  567a8e: 48 89 c8                     	movq	%rcx, %rax
  567a91: 4c 89 eb                     	movq	%r13, %rbx
  567a94: 48 89 f9                     	movq	%rdi, %rcx
  567a97: 4c 89 ff                     	movq	%r15, %rdi
  567a9a: 45 89 c2                     	movl	%r8d, %r10d
  567a9d: 45 89 cb                     	movl	%r9d, %r11d
  567aa0: 41 89 f0                     	movl	%esi, %r8d
  567aa3: 45 89 e1                     	movl	%r12d, %r9d
  567aa6: be 01 00 00 00               	movl	$0x1, %esi
  567aab: e8 f0 67 fe ff               	callq	0x54e2a0 <github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16>
  567ab0: 48 8b 54 24 78               	movq	0x78(%rsp), %rdx
  567ab5: 48 85 d2                     	testq	%rdx, %rdx
  567ab8: 0f b6 54 24 49               	movzbl	0x49(%rsp), %edx
  567abd: 0f b6 74 24 4a               	movzbl	0x4a(%rsp), %esi
  567ac2: 48 8b bc 24 88 00 00 00      	movq	0x88(%rsp), %rdi
  567aca: 44 0f b6 44 24 4b            	movzbl	0x4b(%rsp), %r8d
  567ad0: 44 0f b6 4c 24 4c            	movzbl	0x4c(%rsp), %r9d
  567ad6: 44 0f b6 9c 24 a8 00 00 00   	movzbl	0xa8(%rsp), %r11d
  567adf: 44 0f b6 64 24 4f            	movzbl	0x4f(%rsp), %r12d
  567ae5: 89 c1                        	movl	%eax, %ecx
  567ae7: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
  567aec: eb 08                        	jmp	0x567af6 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3b6>
  567aee: 48 85 db                     	testq	%rbx, %rbx
  567af1: b9 00 00 00 00               	movl	$0x0, %ecx
  567af6: 7f 11                        	jg	0x567b09 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3c9>
  567af8: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)
  567b00: 45 84 db                     	testb	%r11b, %r11b
  567b03: 0f 84 d9 00 00 00            	je	0x567be2 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4a2>
  567b09: 84 c9                        	testb	%cl, %cl
  567b0b: 74 07                        	je	0x567b14 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3d4>
  567b0d: 84 d2                        	testb	%dl, %dl
  567b0f: e9 d0 00 00 00               	jmp	0x567be4 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4a4>
  567b14: 88 4c 24 4e                  	movb	%cl, 0x4e(%rsp)
  567b18: 4c 8b 98 b0 00 00 00         	movq	0xb0(%rax), %r11
  567b1f: 4d 89 dd                     	movq	%r11, %r13
  567b22: 49 c1 e3 02                  	shlq	$0x2, %r11
  567b26: 4c 29 df                     	subq	%r11, %rdi
  567b29: 48 85 ff                     	testq	%rdi, %rdi
  567b2c: 7c 34                        	jl	0x567b62 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x422>
  567b2e: 48 8b 58 08                  	movq	0x8(%rax), %rbx
  567b32: 48 39 fb                     	cmpq	%rdi, %rbx
  567b35: 0f 82 fa 00 00 00            	jb	0x567c35 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4f5>
  567b3b: 4c 8b 18                     	movq	(%rax), %r11
  567b3e: 4c 8b 50 10                  	movq	0x10(%rax), %r10
  567b42: 49 29 fa                     	subq	%rdi, %r10
  567b45: 4c 89 54 24 50               	movq	%r10, 0x50(%rsp)
  567b4a: 49 f7 da                     	negq	%r10
  567b4d: 49 c1 fa 3f                  	sarq	$0x3f, %r10
  567b51: 49 21 fa                     	andq	%rdi, %r10
  567b54: 48 29 fb                     	subq	%rdi, %rbx
  567b57: 4d 01 d3                     	addq	%r10, %r11
  567b5a: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
  567b5f: 90                           	nop
  567b60: eb 3d                        	jmp	0x567b9f <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x45f>
  567b62: 48 8b 58 50                  	movq	0x50(%rax), %rbx
  567b66: 4c 8b 98 c8 00 00 00         	movq	0xc8(%rax), %r11
  567b6d: 49 01 fb                     	addq	%rdi, %r11
  567b70: 4c 39 db                     	cmpq	%r11, %rbx
  567b73: 0f 82 b7 00 00 00            	jb	0x567c30 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4f0>
  567b79: 48 8b 78 48                  	movq	0x48(%rax), %rdi
  567b7d: 4c 8b 50 58                  	movq	0x58(%rax), %r10
  567b81: 4d 29 da                     	subq	%r11, %r10
  567b84: 4c 89 54 24 50               	movq	%r10, 0x50(%rsp)
  567b89: 49 f7 da                     	negq	%r10
  567b8c: 49 c1 fa 3f                  	sarq	$0x3f, %r10
  567b90: 4d 21 da                     	andq	%r11, %r10
  567b93: 4c 29 db                     	subq	%r11, %rbx
  567b96: 4e 8d 1c 17                  	leaq	(%rdi,%r10), %r11
  567b9a: 48 8b 7c 24 50               	movq	0x50(%rsp), %rdi
  567b9f: 4c 89 d8                     	movq	%r11, %rax
  567ba2: 48 89 f9                     	movq	%rdi, %rcx
  567ba5: 4c 89 ef                     	movq	%r13, %rdi
  567ba8: 41 ba 02 00 00 00            	movl	$0x2, %r10d
  567bae: e8 8d 3f ff ff               	callq	0x55bb40 <github.com/thesyncim/govpx/internal/vp8/dsp.mbLoopFilterHorizontalEdgeDispatch>
  567bb3: 0f b6 54 24 49               	movzbl	0x49(%rsp), %edx
  567bb8: 84 d2                        	testb	%dl, %dl
  567bba: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
  567bbf: 0f b6 4c 24 4e               	movzbl	0x4e(%rsp), %ecx
  567bc4: 48 8b bc 24 88 00 00 00      	movq	0x88(%rsp), %rdi
  567bcc: 44 0f b6 44 24 4b            	movzbl	0x4b(%rsp), %r8d
  567bd2: 44 0f b6 4c 24 4c            	movzbl	0x4c(%rsp), %r9d
  567bd8: 44 0f b6 64 24 4f            	movzbl	0x4f(%rsp), %r12d
  567bde: 66 90                        	nop
  567be0: eb 02                        	jmp	0x567be4 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4a4>
  567be2: 84 d2                        	testb	%dl, %dl
  567be4: 75 3f                        	jne	0x567c25 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4e5>
  567be6: 84 c9                        	testb	%cl, %cl
  567be8: 75 3b                        	jne	0x567c25 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4e5>
  567bea: 48 8b 58 08                  	movq	0x8(%rax), %rbx
  567bee: 48 39 df                     	cmpq	%rbx, %rdi
  567bf1: 77 38                        	ja	0x567c2b <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x4eb>
  567bf3: 48 8b 10                     	movq	(%rax), %rdx
  567bf6: 48 8b 48 10                  	movq	0x10(%rax), %rcx
  567bfa: 48 29 f9                     	subq	%rdi, %rcx
  567bfd: 48 29 fb                     	subq	%rdi, %rbx
  567c00: 49 89 ca                     	movq	%rcx, %r10
  567c03: 49 f7 da                     	negq	%r10
  567c06: 49 c1 fa 3f                  	sarq	$0x3f, %r10
  567c0a: 49 21 fa                     	andq	%rdi, %r10
  567c0d: 4c 01 d2                     	addq	%r10, %rdx
  567c10: 48 8b b8 b0 00 00 00         	movq	0xb0(%rax), %rdi
  567c17: 48 89 d0                     	movq	%rdx, %rax
  567c1a: 44 89 e6                     	movl	%r12d, %esi
  567c1d: 0f 1f 00                     	nopl	(%rax)
  567c20: e8 7b 37 ff ff               	callq	0x55b3a0 <github.com/thesyncim/govpx/internal/vp8/dsp.loopFilterHorizontalEdgesYDispatch>
  567c25: 48 83 c4 60                  	addq	$0x60, %rsp
  567c29: 5d                           	popq	%rbp
  567c2a: c3                           	retq
  567c2b: e8 30 52 f2 ff               	callq	0x48ce60 <runtime.panicBounds>
  567c30: e8 2b 52 f2 ff               	callq	0x48ce60 <runtime.panicBounds>
  567c35: e8 26 52 f2 ff               	callq	0x48ce60 <runtime.panicBounds>
  567c3a: e8 21 52 f2 ff               	callq	0x48ce60 <runtime.panicBounds>
  567c3f: 90                           	nop
  567c40: e8 1b 52 f2 ff               	callq	0x48ce60 <runtime.panicBounds>
  567c45: e8 16 52 f2 ff               	callq	0x48ce60 <runtime.panicBounds>
  567c4a: e8 11 52 f2 ff               	callq	0x48ce60 <runtime.panicBounds>
  567c4f: e8 0c 52 f2 ff               	callq	0x48ce60 <runtime.panicBounds>
  567c54: e8 07 52 f2 ff               	callq	0x48ce60 <runtime.panicBounds>
  567c59: b8 40 00 00 00               	movl	$0x40, %eax
  567c5e: 66 90                        	nop
  567c60: e8 fb 51 f2 ff               	callq	0x48ce60 <runtime.panicBounds>
  567c65: e8 f6 51 f2 ff               	callq	0x48ce60 <runtime.panicBounds>
  567c6a: 90                           	nop
  567c6b: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
  567c70: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
  567c75: 48 89 4c 24 18               	movq	%rcx, 0x18(%rsp)
  567c7a: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
  567c7f: 48 89 74 24 28               	movq	%rsi, 0x28(%rsp)
  567c84: 44 88 44 24 30               	movb	%r8b, 0x30(%rsp)
  567c89: 44 88 4c 24 31               	movb	%r9b, 0x31(%rsp)
  567c8e: 4c 89 54 24 38               	movq	%r10, 0x38(%rsp)
  567c93: 44 88 5c 24 40               	movb	%r11b, 0x40(%rsp)
  567c98: e8 83 35 f2 ff               	callq	0x48b220 <runtime.morestack_noctxt.abi0>
  567c9d: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
  567ca2: 48 8b 5c 24 10               	movq	0x10(%rsp), %rbx
  567ca7: 48 8b 4c 24 18               	movq	0x18(%rsp), %rcx
  567cac: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
  567cb1: 48 8b 74 24 28               	movq	0x28(%rsp), %rsi
  567cb6: 44 0f b6 44 24 30            	movzbl	0x30(%rsp), %r8d
  567cbc: 44 0f b6 4c 24 31            	movzbl	0x31(%rsp), %r9d
  567cc2: 4c 8b 54 24 38               	movq	0x38(%rsp), %r10
  567cc7: 44 0f b6 5c 24 40            	movzbl	0x40(%rsp), %r11d
  567ccd: e9 6e fa ff ff               	jmp	0x567740 <github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB>
  567cd2: cc                           	int3
  567cd3: cc                           	int3
  567cd4: cc                           	int3
  567cd5: cc                           	int3
  567cd6: cc                           	int3
  567cd7: cc                           	int3
  567cd8: cc                           	int3
  567cd9: cc                           	int3
  567cda: cc                           	int3
  567cdb: cc                           	int3
  567cdc: cc                           	int3
  567cdd: cc                           	int3
  567cde: cc                           	int3
  567cdf: cc                           	int3

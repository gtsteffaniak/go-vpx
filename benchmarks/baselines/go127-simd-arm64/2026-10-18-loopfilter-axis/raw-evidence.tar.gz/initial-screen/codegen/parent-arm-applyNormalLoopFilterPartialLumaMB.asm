
/private/tmp/govpx-lf-axis-private/validation/parent-arm.test:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100139c80 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB>:
100139c80: f9400b90    	ldr	x16, [x28, #0x10]
100139c84: eb3063ff    	cmp	sp, x16
100139c88: 54002069    	b.ls	0x10013a094 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x414>
100139c8c: f81a0ffe    	str	x30, [sp, #-0x60]!
100139c90: f81f83fd    	stur	x29, [sp, #-0x8]
100139c94: d10023fd    	sub	x29, sp, #0x8
100139c98: 39400089    	ldrb	w9, [x4]
100139c9c: 7100113f    	cmp	w9, #0x4
100139ca0: 540000a0    	b.eq	0x100139cb4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x34>
100139ca4: 7100253f    	cmp	w9, #0x9
100139ca8: 54000060    	b.eq	0x100139cb4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x34>
100139cac: 39402489    	ldrb	w9, [x4, #0x9]
100139cb0: 14000002    	b	0x100139cb8 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x38>
100139cb4: aa1f03e9    	mov	x9, xzr
100139cb8: 398000fb    	ldrsb	x27, [x7]
100139cbc: d3401caa    	ubfx	x10, x5, #0, #8
100139cc0: f100095f    	cmp	x10, #0x2
100139cc4: 54001e42    	b.hs	0x10013a08c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x40c>
100139cc8: 910310eb    	add	x11, x7, #0xc4
100139ccc: d3401ccc    	ubfx	x12, x6, #0, #8
100139cd0: 8b0a196a    	add	x10, x11, x10, lsl #6
100139cd4: f101019f    	cmp	x12, #0x40
100139cd8: 54001d62    	b.hs	0x10013a084 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x404>
100139cdc: 386c694a    	ldrb	w10, [x10, x12]
100139ce0: f100115f    	cmp	x10, #0x4
100139ce4: 54001ce2    	b.hs	0x10013a080 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x400>
100139ce8: f90037e0    	str	x0, [sp, #0x68]
100139cec: f9003be1    	str	x1, [sp, #0x70]
100139cf0: f90043e3    	str	x3, [sp, #0x80]
100139cf4: 390283e8    	strb	w8, [sp, #0xa0]
100139cf8: 390147e9    	strb	w9, [sp, #0x51]
100139cfc: 910300eb    	add	x11, x7, #0xc0
100139d00: 910100ed    	add	x13, x7, #0x40
100139d04: 910200ee    	add	x14, x7, #0x80
100139d08: 386a6966    	ldrb	w6, [x11, x10]
100139d0c: 390153e6    	strb	w6, [sp, #0x54]
100139d10: 386c68e4    	ldrb	w4, [x7, x12]
100139d14: 39014be4    	strb	w4, [sp, #0x52]
100139d18: 386c69aa    	ldrb	w10, [x13, x12]
100139d1c: 39015fea    	strb	w10, [sp, #0x57]
100139d20: 386c69c5    	ldrb	w5, [x14, x12]
100139d24: 39014fe5    	strb	w5, [sp, #0x53]
100139d28: f100005f    	cmp	x2, #0x0
100139d2c: 5400050d    	b.le	0x100139dcc <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x14c>
100139d30: 36000069    	tbz	w9, #0x0, 0x100139d3c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0xbc>
100139d34: aa1f03e2    	mov	x2, xzr
100139d38: 14000026    	b	0x100139dd0 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x150>
100139d3c: a940300b    	ldp	x11, x12, [x0]
100139d40: d100106d    	sub	x13, x3, #0x4
100139d44: eb0d019f    	cmp	x12, x13
100139d48: 540019a3    	b.lo	0x10013a07c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3fc>
100139d4c: f9003fe2    	str	x2, [sp, #0x78]
100139d50: f9400809    	ldr	x9, [x0, #0x10]
100139d54: cb030129    	sub	x9, x9, x3
100139d58: cb03018c    	sub	x12, x12, x3
100139d5c: 91001122    	add	x2, x9, #0x4
100139d60: cb0203e9    	neg	x9, x2
100139d64: 8a89fda9    	and	x9, x13, x9, asr #63
100139d68: 8b090169    	add	x9, x11, x9
100139d6c: 91001181    	add	x1, x12, #0x4
100139d70: f940580b    	ldr	x11, [x0, #0xb0]
100139d74: aa0403ec    	mov	x12, x4
100139d78: aa0503e7    	mov	x7, x5
100139d7c: aa0603e8    	mov	x8, x6
100139d80: aa0903e0    	mov	x0, x9
100139d84: b24003e3    	orr	x3, xzr, #0x1
100139d88: aa0b03e4    	mov	x4, x11
100139d8c: aa0c03e5    	mov	x5, x12
100139d90: aa0a03e6    	mov	x6, x10
100139d94: 97ffb4bf    	bl	0x100127090 <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16>
100139d98: f9403fe9    	ldr	x9, [sp, #0x78]
100139d9c: f100013f    	cmp	x9, #0x0
100139da0: f9403be1    	ldr	x1, [sp, #0x70]
100139da4: f94043e3    	ldr	x3, [sp, #0x80]
100139da8: 39414be4    	ldrb	w4, [sp, #0x52]
100139dac: 39414fe5    	ldrb	w5, [sp, #0x53]
100139db0: 394153e6    	ldrb	w6, [sp, #0x54]
100139db4: 394283e8    	ldrb	w8, [sp, #0xa0]
100139db8: 394147e9    	ldrb	w9, [sp, #0x51]
100139dbc: 39415fea    	ldrb	w10, [sp, #0x57]
100139dc0: aa0003e2    	mov	x2, x0
100139dc4: f94037e0    	ldr	x0, [sp, #0x68]
100139dc8: 14000002    	b	0x100139dd0 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x150>
100139dcc: aa1f03e2    	mov	x2, xzr
100139dd0: 540003ad    	b.le	0x100139e44 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x1c4>
100139dd4: 37000382    	tbnz	w2, #0x0, 0x100139e44 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x1c4>
100139dd8: a940300b    	ldp	x11, x12, [x0]
100139ddc: d100106d    	sub	x13, x3, #0x4
100139de0: eb0d019f    	cmp	x12, x13
100139de4: 540014a3    	b.lo	0x10013a078 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3f8>
100139de8: 390157e2    	strb	w2, [sp, #0x55]
100139dec: f9400808    	ldr	x8, [x0, #0x10]
100139df0: cb030108    	sub	x8, x8, x3
100139df4: cb030189    	sub	x9, x12, x3
100139df8: 91001102    	add	x2, x8, #0x4
100139dfc: cb0203e8    	neg	x8, x2
100139e00: 8a88fda8    	and	x8, x13, x8, asr #63
100139e04: 8b080168    	add	x8, x11, x8
100139e08: 91001121    	add	x1, x9, #0x4
100139e0c: f9405803    	ldr	x3, [x0, #0xb0]
100139e10: aa0803e0    	mov	x0, x8
100139e14: b27f03e7    	orr	x7, xzr, #0x2
100139e18: 97ffdf7e    	bl	0x100131c10 <_github.com/thesyncim/govpx/internal/vp8/dsp.mbLoopFilterVerticalEdgeDispatch>
100139e1c: f94037e0    	ldr	x0, [sp, #0x68]
100139e20: f9403be1    	ldr	x1, [sp, #0x70]
100139e24: 394157e2    	ldrb	w2, [sp, #0x55]
100139e28: f94043e3    	ldr	x3, [sp, #0x80]
100139e2c: 39414be4    	ldrb	w4, [sp, #0x52]
100139e30: 39414fe5    	ldrb	w5, [sp, #0x53]
100139e34: 394153e6    	ldrb	w6, [sp, #0x54]
100139e38: 394283e8    	ldrb	w8, [sp, #0xa0]
100139e3c: 394147e9    	ldrb	w9, [sp, #0x51]
100139e40: 39415fea    	ldrb	w10, [sp, #0x57]
100139e44: 37000309    	tbnz	w9, #0x0, 0x100139ea4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x224>
100139e48: 370002e2    	tbnz	w2, #0x0, 0x100139ea4 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x224>
100139e4c: a9402c07    	ldp	x7, x11, [x0]
100139e50: eb0b007f    	cmp	x3, x11
100139e54: 54001108    	b.hi	0x10013a074 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3f4>
100139e58: f9400808    	ldr	x8, [x0, #0x10]
100139e5c: cb030161    	sub	x1, x11, x3
100139e60: cb030102    	sub	x2, x8, x3
100139e64: cb080068    	sub	x8, x3, x8
100139e68: 8a88fc68    	and	x8, x3, x8, asr #63
100139e6c: 8b0800e7    	add	x7, x7, x8
100139e70: f9405803    	ldr	x3, [x0, #0xb0]
100139e74: aa0703e0    	mov	x0, x7
100139e78: aa0a03e4    	mov	x4, x10
100139e7c: 97ffde4d    	bl	0x1001317b0 <_github.com/thesyncim/govpx/internal/vp8/dsp.loopFilterVerticalEdgesYDispatch>
100139e80: f94037e0    	ldr	x0, [sp, #0x68]
100139e84: f9403be1    	ldr	x1, [sp, #0x70]
100139e88: f94043e3    	ldr	x3, [sp, #0x80]
100139e8c: 39414be4    	ldrb	w4, [sp, #0x52]
100139e90: 39414fe5    	ldrb	w5, [sp, #0x53]
100139e94: 394153e6    	ldrb	w6, [sp, #0x54]
100139e98: 394283e8    	ldrb	w8, [sp, #0xa0]
100139e9c: 394147e9    	ldrb	w9, [sp, #0x51]
100139ea0: 39415fea    	ldrb	w10, [sp, #0x57]
100139ea4: f100003f    	cmp	x1, #0x0
100139ea8: 5400004c    	b.gt	0x100139eb0 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x230>
100139eac: 36000648    	tbz	w8, #0x0, 0x100139f74 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x2f4>
100139eb0: 36000069    	tbz	w9, #0x0, 0x100139ebc <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x23c>
100139eb4: aa1f03e1    	mov	x1, xzr
100139eb8: 14000030    	b	0x100139f78 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x2f8>
100139ebc: f940580b    	ldr	x11, [x0, #0xb0]
100139ec0: cb0b086c    	sub	x12, x3, x11, lsl #2
100139ec4: b7f8016c    	tbnz	x12, #0x3f, 0x100139ef0 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x270>
100139ec8: a940380d    	ldp	x13, x14, [x0]
100139ecc: eb0c01df    	cmp	x14, x12
100139ed0: 54000d03    	b.lo	0x10013a070 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3f0>
100139ed4: f940080f    	ldr	x15, [x0, #0x10]
100139ed8: cb0f0190    	sub	x16, x12, x15
100139edc: 8a90fd90    	and	x16, x12, x16, asr #63
100139ee0: cb0c01ce    	sub	x14, x14, x12
100139ee4: cb0c01e2    	sub	x2, x15, x12
100139ee8: 8b1001ac    	add	x12, x13, x16
100139eec: 1400000c    	b	0x100139f1c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x29c>
100139ef0: a944b80d    	ldp	x13, x14, [x0, #0x48]
100139ef4: f940640f    	ldr	x15, [x0, #0xc8]
100139ef8: 8b0c01ec    	add	x12, x15, x12
100139efc: eb0c01df    	cmp	x14, x12
100139f00: 54000b63    	b.lo	0x10013a06c <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3ec>
100139f04: f9402c0f    	ldr	x15, [x0, #0x58]
100139f08: cb0f0190    	sub	x16, x12, x15
100139f0c: 8a90fd90    	and	x16, x12, x16, asr #63
100139f10: cb0c01ce    	sub	x14, x14, x12
100139f14: cb0c01e2    	sub	x2, x15, x12
100139f18: 8b1001ac    	add	x12, x13, x16
100139f1c: aa0403e9    	mov	x9, x4
100139f20: aa0503e7    	mov	x7, x5
100139f24: aa0603e8    	mov	x8, x6
100139f28: aa0c03e0    	mov	x0, x12
100139f2c: aa0e03e1    	mov	x1, x14
100139f30: aa0b03e3    	mov	x3, x11
100139f34: b24003e4    	orr	x4, xzr, #0x1
100139f38: aa0903e5    	mov	x5, x9
100139f3c: aa0a03e6    	mov	x6, x10
100139f40: 97ffb454    	bl	0x100127090 <_github.com/thesyncim/govpx/internal/pixel.LoopFilterMacroInternal16>
100139f44: f9403be9    	ldr	x9, [sp, #0x70]
100139f48: f100013f    	cmp	x9, #0x0
100139f4c: f94043e3    	ldr	x3, [sp, #0x80]
100139f50: 39414be4    	ldrb	w4, [sp, #0x52]
100139f54: 39414fe5    	ldrb	w5, [sp, #0x53]
100139f58: 394153e6    	ldrb	w6, [sp, #0x54]
100139f5c: 394283e8    	ldrb	w8, [sp, #0xa0]
100139f60: 394147e9    	ldrb	w9, [sp, #0x51]
100139f64: 39415fea    	ldrb	w10, [sp, #0x57]
100139f68: aa0003e1    	mov	x1, x0
100139f6c: f94037e0    	ldr	x0, [sp, #0x68]
100139f70: 14000002    	b	0x100139f78 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x2f8>
100139f74: aa1f03e1    	mov	x1, xzr
100139f78: 5400004c    	b.gt	0x100139f80 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x300>
100139f7c: 360004e8    	tbz	w8, #0x0, 0x10013a018 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x398>
100139f80: 370004c1    	tbnz	w1, #0x0, 0x10013a018 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x398>
100139f84: 39015be1    	strb	w1, [sp, #0x56]
100139f88: f9405808    	ldr	x8, [x0, #0xb0]
100139f8c: cb08086b    	sub	x11, x3, x8, lsl #2
100139f90: b7f8016b    	tbnz	x11, #0x3f, 0x100139fbc <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x33c>
100139f94: a940340c    	ldp	x12, x13, [x0]
100139f98: eb0b01bf    	cmp	x13, x11
100139f9c: 54000663    	b.lo	0x10013a068 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3e8>
100139fa0: f940080e    	ldr	x14, [x0, #0x10]
100139fa4: cb0e016f    	sub	x15, x11, x14
100139fa8: 8a8ffd6f    	and	x15, x11, x15, asr #63
100139fac: cb0b01ad    	sub	x13, x13, x11
100139fb0: cb0b01c2    	sub	x2, x14, x11
100139fb4: 8b0f018b    	add	x11, x12, x15
100139fb8: 1400000c    	b	0x100139fe8 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x368>
100139fbc: a944b40c    	ldp	x12, x13, [x0, #0x48]
100139fc0: f940640e    	ldr	x14, [x0, #0xc8]
100139fc4: 8b0b01cb    	add	x11, x14, x11
100139fc8: eb0b01bf    	cmp	x13, x11
100139fcc: 540004c3    	b.lo	0x10013a064 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3e4>
100139fd0: f9402c0e    	ldr	x14, [x0, #0x58]
100139fd4: cb0e016f    	sub	x15, x11, x14
100139fd8: 8a8ffd6f    	and	x15, x11, x15, asr #63
100139fdc: cb0b01ad    	sub	x13, x13, x11
100139fe0: cb0b01c2    	sub	x2, x14, x11
100139fe4: 8b0f018b    	add	x11, x12, x15
100139fe8: aa0b03e0    	mov	x0, x11
100139fec: aa0d03e1    	mov	x1, x13
100139ff0: aa0803e3    	mov	x3, x8
100139ff4: b27f03e7    	orr	x7, xzr, #0x2
100139ff8: 97ffdece    	bl	0x100131b30 <_github.com/thesyncim/govpx/internal/vp8/dsp.mbLoopFilterHorizontalEdgeDispatch>
100139ffc: f94037e0    	ldr	x0, [sp, #0x68]
10013a000: 39415be1    	ldrb	w1, [sp, #0x56]
10013a004: f94043e3    	ldr	x3, [sp, #0x80]
10013a008: 39414fe5    	ldrb	w5, [sp, #0x53]
10013a00c: 394153e6    	ldrb	w6, [sp, #0x54]
10013a010: 394147e9    	ldrb	w9, [sp, #0x51]
10013a014: 39415fea    	ldrb	w10, [sp, #0x57]
10013a018: 370001e9    	tbnz	w9, #0x0, 0x10013a054 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3d4>
10013a01c: 370001c1    	tbnz	w1, #0x0, 0x10013a054 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3d4>
10013a020: a9402007    	ldp	x7, x8, [x0]
10013a024: eb08007f    	cmp	x3, x8
10013a028: 540001c8    	b.hi	0x10013a060 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB+0x3e0>
10013a02c: f9400809    	ldr	x9, [x0, #0x10]
10013a030: cb09006b    	sub	x11, x3, x9
10013a034: cb030101    	sub	x1, x8, x3
10013a038: cb030122    	sub	x2, x9, x3
10013a03c: 8a8bfc68    	and	x8, x3, x11, asr #63
10013a040: 8b0800e7    	add	x7, x7, x8
10013a044: f9405803    	ldr	x3, [x0, #0xb0]
10013a048: aa0703e0    	mov	x0, x7
10013a04c: aa0a03e4    	mov	x4, x10
10013a050: 97ffdd48    	bl	0x100131570 <_github.com/thesyncim/govpx/internal/vp8/dsp.loopFilterHorizontalEdgesYDispatch>
10013a054: f85f83fd    	ldur	x29, [sp, #-0x8]
10013a058: f84607fe    	ldr	x30, [sp], #0x60
10013a05c: d65f03c0    	ret
10013a060: 97fd241c    	bl	0x1000830d0 <_runtime.panicBounds>
10013a064: 97fd241b    	bl	0x1000830d0 <_runtime.panicBounds>
10013a068: 97fd241a    	bl	0x1000830d0 <_runtime.panicBounds>
10013a06c: 97fd2419    	bl	0x1000830d0 <_runtime.panicBounds>
10013a070: 97fd2418    	bl	0x1000830d0 <_runtime.panicBounds>
10013a074: 97fd2417    	bl	0x1000830d0 <_runtime.panicBounds>
10013a078: 97fd2416    	bl	0x1000830d0 <_runtime.panicBounds>
10013a07c: 97fd2415    	bl	0x1000830d0 <_runtime.panicBounds>
10013a080: 97fd2414    	bl	0x1000830d0 <_runtime.panicBounds>
10013a084: b27a03e0    	orr	x0, xzr, #0x40
10013a088: 97fd2412    	bl	0x1000830d0 <_runtime.panicBounds>
10013a08c: 97fd2411    	bl	0x1000830d0 <_runtime.panicBounds>
10013a090: d503201f    	nop
10013a094: a90087e0    	stp	x0, x1, [sp, #0x8]
10013a098: a9018fe2    	stp	x2, x3, [sp, #0x18]
10013a09c: f90017e4    	str	x4, [sp, #0x28]
10013a0a0: 3900c3e5    	strb	w5, [sp, #0x30]
10013a0a4: 3900c7e6    	strb	w6, [sp, #0x31]
10013a0a8: f9001fe7    	str	x7, [sp, #0x38]
10013a0ac: 390103e8    	strb	w8, [sp, #0x40]
10013a0b0: aa1e03e3    	mov	x3, x30
10013a0b4: 97fd1bc3    	bl	0x100080fc0 <_runtime.morestack_noctxt.abi0>
10013a0b8: a94087e0    	ldp	x0, x1, [sp, #0x8]
10013a0bc: a9418fe2    	ldp	x2, x3, [sp, #0x18]
10013a0c0: f94017e4    	ldr	x4, [sp, #0x28]
10013a0c4: 3940c3e5    	ldrb	w5, [sp, #0x30]
10013a0c8: 3940c7e6    	ldrb	w6, [sp, #0x31]
10013a0cc: f9401fe7    	ldr	x7, [sp, #0x38]
10013a0d0: 394103e8    	ldrb	w8, [sp, #0x40]
10013a0d4: 17fffeeb    	b	0x100139c80 <_github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB>
		...

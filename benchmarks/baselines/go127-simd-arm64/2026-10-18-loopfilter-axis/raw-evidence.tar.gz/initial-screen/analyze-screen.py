from pathlib import Path
import json,re,statistics
b=Path('/private/tmp/govpx-lf-axis-private');out=b/'screen';data={v:{} for v in ['parent','candidate','old691']};journal=json.loads((out/'run-journal.json').read_text());assert len(journal['records'])==18
for row in journal['records']:
 s=(out/row['log']).read_text();assert row['returncode']==0 and '\nPASS\n' in s
 matches=re.findall(r'^(BenchmarkVP8PickerFilterNative/\S+?)(?:-\d+)?\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',s,re.M);assert len(matches)==10,(row['log'],len(matches))
 for name,n,ns,byt,alloc in matches:
  assert int(n)>1 and int(byt)==int(alloc)==0
  data[row['variant']].setdefault(name,[]).append(float(ns))
cases={}
for name in data['parent']:
 vals={v:data[v][name]for v in data};assert all(len(x)==6 for x in vals.values());med={v:statistics.median(x)for v,x in vals.items()};pairs=[a/c for a,c in zip(vals['parent'],vals['candidate'])];old=[a/c for a,c in zip(vals['old691'],vals['candidate'])]
 cases[name]={'samples_ns':vals,'median_ns':med,'parent_over_candidate':med['parent']/med['candidate'],'old_over_candidate':med['old691']/med['candidate'],'paired_parent_over_candidate':pairs,'paired_old_over_candidate':old,'allocs_per_op':0,'bytes_per_op':0}
 print(name,'median parent/candidate/old',*[round(med[v],4)for v in data],'p/c',round(med['parent']/med['candidate'],5),'range',round(min(pairs),5),round(max(pairs),5),'old/c',round(med['old691']/med['candidate'],5))
r={'cpu':'Apple M4 Max','cases':cases,'samples':180,'all_18_processes_pass':True,'all_180_allocs_zero':True,'all_18_caller_full_output_oracles_pass':True,'source_freeze':'../source-freeze.json','orders':journal['orders'],'pgo':'off','GOMAXPROCS':1,'CGO_ENABLED':1,'fresh_acceptance_not_yet_authorized':True}
(out/'analysis.json').write_text(json.dumps(r,indent=2))

from pathlib import Path
import subprocess,re,json,hashlib
b=Path('/private/tmp/govpx-lf-axis-private');out=b/'codegen';out.mkdir(exist_ok=True)
def dis(v,target,sym,arm=False):
 binary=b/'validation'/f'{v}-{target}.test';symbol=('_' if target.startswith(('arm','darwin')) else '')+sym
 s=subprocess.check_output(['xcrun','llvm-objdump','-d','--disassemble-symbols='+symbol,str(binary)],text=True);(out/f'{v}-{target}-{sym.rsplit(".",1)[-1]}.asm').write_text(s)
 pat=r'^\s*([0-9a-f]+):\s+[0-9a-f]{8}\s+(.+)$' if arm else r'^\s*([0-9a-f]+):\s+(?:[0-9a-f]{2}\s+)+(.+)$'
 inst=[(int(m[1],16),m[2]) for l in s.splitlines() if (m:=re.match(pat,l)) and m[2] not in ('int3','udf #0x0')];assert inst,symbol
 lookup={a:i for i,(a,_) in enumerate(inst)};norm=[]
 for a,i in inst:
  i=re.sub(r'0x[0-9a-f]+\s*<([^>]+)>',r'<\1>',i)
  i=re.sub(r'(?<=\s)0x([0-9a-f]+)(?=\s|$)',lambda m:'L'+str(lookup[int(m[1],16)]) if int(m[1],16) in lookup else m[0],i)
  if '(%rip)' in i:
   symbol=i.split('##',1)[1].strip() if '##' in i else i.split('#',1)[1].strip() if '#' in i else ''
   i=re.sub(r'-?0x[0-9a-f]+\(%rip\)',f'RIP({symbol})',i).split('##',1)[0].split('#',1)[0].strip()
  # Relative branch symbol+offset can change when preceding function moves.
  i=re.sub(r'(<[^>]+>)\+0x[0-9a-f]+',r'\1+OFFSET',i)
  norm.append(i)
 return inst,norm
sym='github.com/thesyncim/govpx/internal/vp8/decoder.applyNormalLoopFilterPartialLumaMB'
r={}
for target in ['darwin-amd','linux-amd']:
 a,an=dis('parent',target,sym);c,cn=dis('candidate',target,sym)
 (out/(target+'-parent-normalized.json')).write_text(json.dumps(an,indent=2));(out/(target+'-candidate-normalized.json')).write_text(json.dumps(cn,indent=2))
 assert an==cn,(target,len(an),len(cn),next(((i,x,y) for i,(x,y) in enumerate(zip(an,cn)) if x!=y),None))
 r[target]={'normalized_decoder_identical':True,'meaningful_instructions':len(a)}
for v in ['parent','candidate']:
 a,n=dis(v,'arm',sym,True);calls=[i for p,i in a if i.startswith('bl\t')];r[v+'-arm']={'meaningful_instructions':len(a),'calls':calls,'static_calls_to_generic':sum('pixel.LoopFilterMacroInternal16>' in i for i in calls),'static_calls_to_fused':sum('pixel.loopFilterMacroInternalFused' in i for i in calls)}
# Generic and generated arithmetic are byte-identical; all original production other files unchanged.
changes=[]
for p in (b/'parent').rglob('*.go'):
 if p.name.endswith('_test.go'):continue
 rel=p.relative_to(b/'parent');q=b/'candidate'/rel
 if p.read_bytes()!=q.read_bytes():changes.append(str(rel))
assert changes==['internal/vp8/decoder/loopfilter.go'],changes
for name in ['go.mod','go.sum']:
 p,q=b/'parent'/name,b/'candidate'/name
 assert p.exists()==q.exists()
 if p.exists():assert p.read_bytes()==q.read_bytes()
r['source']={'original_production_delta':changes,'new_arm_helper_sha256':hashlib.sha256((b/'candidate/internal/pixel/loopfilter_macro_axis_arm64.go').read_bytes()).hexdigest(),'other_stub_sha256':hashlib.sha256((b/'candidate/internal/pixel/loopfilter_macro_axis_other.go').read_bytes()).hexdigest(),'generic_and_generated_arithmetic_unchanged':True,'go_modules_unchanged':True,'no_native_performance_claim':True}
(out/'proof.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))

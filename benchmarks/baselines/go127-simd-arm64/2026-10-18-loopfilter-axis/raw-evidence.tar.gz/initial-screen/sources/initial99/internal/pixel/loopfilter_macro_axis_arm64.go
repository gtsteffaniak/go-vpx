//go:build goexperiment.simd && arm64 && !purego

package pixel

const NativeLFByAxis = true

// LoopFilterMacroInternalHorizontal16 proves the complete window before writing.
func LoopFilterMacroInternalHorizontal16(p []byte, pitch int, mblimit, blimit, limit, thresh byte) bool {
	if !Enabled || uint(pitch-16)>>30 != 0 || 19*pitch+16 > len(p) || mblimit == 255 || blimit == 255 {
		return false
	}
	loopFilterMacroInternalFusedHorizontal(p, pitch, int(mblimit), int(blimit), int(limit), int(thresh))
	return true
}

// LoopFilterMacroInternalVertical16 proves the complete window before writing.
func LoopFilterMacroInternalVertical16(p []byte, pitch int, mblimit, blimit, limit, thresh byte) bool {
	if !Enabled || uint(pitch-20)>>30 != 0 || 15*pitch+20 > len(p) || mblimit == 255 || blimit == 255 {
		return false
	}
	loopFilterMacroInternalFusedVertical(p, pitch, int(mblimit), int(blimit), int(limit), int(thresh))
	return true
}

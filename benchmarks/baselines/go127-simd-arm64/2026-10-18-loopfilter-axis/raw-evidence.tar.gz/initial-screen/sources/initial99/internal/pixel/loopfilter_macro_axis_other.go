//go:build !goexperiment.simd || !arm64 || purego

package pixel

const NativeLFByAxis = false

func LoopFilterMacroInternalHorizontal16(p []byte, pitch int, mblimit, blimit, limit, thresh byte) bool {
	return false
}
func LoopFilterMacroInternalVertical16(p []byte, pitch int, mblimit, blimit, limit, thresh byte) bool {
	return false
}

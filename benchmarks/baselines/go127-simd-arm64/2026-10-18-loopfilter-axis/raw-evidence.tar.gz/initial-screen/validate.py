from pathlib import Path
import os,subprocess,json
b=Path('/private/tmp/govpx-lf-axis-private'); logs=b/'validation';logs.mkdir(exist_ok=True)
env=os.environ.copy();env.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-lfaxis',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',CGO_ENABLED='1')
root='/Users/thesyncim/GolandProjects/govpx';cmds=[]
def go(name,variant,args,extra=None):
 e=env.copy();e.update(extra or {});cmd=[root+'/scripts/go.sh','-C',str(b/variant)]+args;cmds.append(dict(name=name,argv=cmd,extra=extra));(logs/'commands.json').write_text(json.dumps(cmds,indent=2))
 with (logs/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError(name)
 print(name,flush=True)
base=['test','-pgo=off'];regex='TestMacro(Axis|Internal)|TestApplyLoopFilter'
go('native','candidate',base+['-run',regex,'./internal/pixel','./internal/vp8/decoder'])
go('race-checkptr2','candidate',base+['-race','-gcflags=all=-d=checkptr=2','-run',regex,'./internal/pixel','./internal/vp8/decoder'])
go('public10-oneshot','candidate',base+['-run','^$','-bench','^BenchmarkVP8PickerFilterNative$','-benchtime=1x','-count=1','./internal/vp8/decoder'])
p=b/'candidate/internal/pixel/enabled_arm64.go'; disabled=b/'enabled-disabled.go';disabled.write_text(p.read_text().replace('const Enabled = true','const Enabled = false')); overlay=b/'disabled-overlay.json';overlay.write_text(json.dumps({'Replace':{str(p):str(disabled)}}))
go('disabled-cpu','candidate',base+['-overlay',str(overlay),'-run','^TestMacroAxis','./internal/pixel','./internal/vp8/decoder'])
go('purego','candidate',base+['-tags=purego','-run','TestMacroAxisCallerFrozenState|TestApplyLoopFilter','./internal/vp8/decoder'])
go('nosimd','candidate',base+['-run','TestMacroAxisCallerFrozenState|TestApplyLoopFilter','./internal/vp8/decoder'],{'GOEXPERIMENT':''})
# The same caller-oracle overlay keeps link liveness/layout comparable.
for variant in ['parent','candidate']:
 if variant=='parent':(b/'parent/internal/vp8/decoder/loopfilter_axis_frozen_test.go').write_bytes((b/'candidate/internal/vp8/decoder/loopfilter_axis_frozen_test.go').read_bytes())
 go(variant+'-arm-codegen',variant,base+['-c','-o',str(logs/(variant+'-arm.test')),'./internal/vp8/decoder'])
 for target in ['darwin','linux']:
  go(variant+'-'+target+'-amd-codegen',variant,base+['-c','-o',str(logs/(variant+'-'+target+'-amd.test')),'./internal/vp8/decoder'],{'GOARCH':'amd64','GOOS':target,'CGO_ENABLED':'0'})
print('ALL PASS',flush=True)

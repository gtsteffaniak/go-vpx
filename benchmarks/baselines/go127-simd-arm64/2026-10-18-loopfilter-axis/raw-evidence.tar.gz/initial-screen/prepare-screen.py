from pathlib import Path
import shutil,os,subprocess,json,hashlib,re
b=Path('/private/tmp/govpx-lf-axis-private');old=b/'old691';shutil.copytree('/private/tmp/govpx-tm4-47-screen/old691',old,ignore=shutil.ignore_patterns('.git','*.test','*.pgo','*.prof','*.out'))
f='internal/vp8/decoder/picker_filter_native_bench_test.go';(old/f).write_bytes((b/'parent'/f).read_bytes());out=b/'screen';out.mkdir(exist_ok=True)
variants=['parent','candidate','old691'];env=os.environ.copy();env.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-lfaxis-screen',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='1',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',CGO_ENABLED='1',GOVPX_REQUIRE_SIMD='1');records=[]
root='/Users/thesyncim/GolandProjects/govpx';fixture_hash=[]
for v in variants:
 fixture_hash.append(hashlib.sha256((b/v/f).read_bytes()).hexdigest());binary=out/(v+'.test');cmd=[root+'/scripts/go.sh','-C',str(b/v),'test','-c','-pgo=off','-o',str(binary),'./internal/vp8/decoder'];records.append({'variant':v,'build_argv':cmd})
 with (out/(v+'-build.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError(v+' build')
 cmd=[str(binary),'-test.run=^$','-test.bench=^BenchmarkVP8PickerFilterNative$','-test.benchtime=1x','-test.count=1'];records[-1]['oneshot_argv']=cmd
 with (out/(v+'-oneshot.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError(v+' oracle')
 rows=[l for l in (out/(v+'-oneshot.log')).read_text().splitlines() if l.startswith('BenchmarkVP8PickerFilterNative/')];assert len(rows)==10 and all(re.search(r'\s0 B/op\s+0 allocs/op',l) for l in rows)
 records[-1].update(binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),binary_size=binary.stat().st_size,oneshots=10,all_allocs_zero=True)
 cmd=[root+'/scripts/go.sh','version','-m',str(binary)]
 with (out/(v+'-buildinfo.txt')).open('w') as log:subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(v+' BUILD+10ORACLES PASS',flush=True)
assert len(set(fixture_hash))==1
(out/'prep.json').write_text(json.dumps({'build_env':{k:env[k] for k in ['CODEX_PROJECT_CACHE_ROOT','CODEX_AGENT_ID','GOTOOLCHAIN','GOEXPERIMENT','GOFLAGS','GOMAXPROCS','GO','CGO_ENABLED']},'fixture':f,'fixture_sha256':fixture_hash[0],'variants':records,'one_shot_times_excluded':True,'native_timing_not_started':True},indent=2))
print('READY ALL GO/BUILD/ORACLE JOBS STOPPED',flush=True)

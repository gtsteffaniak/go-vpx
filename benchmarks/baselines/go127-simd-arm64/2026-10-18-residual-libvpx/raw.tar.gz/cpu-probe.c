#include <stdio.h>
#include "vpx_ports/arm.h"
int main(void) {
 int f=arm_cpu_caps();
 printf("caps=%d NEON=%d DOTPROD=%d I8MM=%d\n",f,!!(f&HAS_NEON),!!(f&HAS_NEON_DOTPROD),!!(f&HAS_NEON_I8MM));
 return 0;
}

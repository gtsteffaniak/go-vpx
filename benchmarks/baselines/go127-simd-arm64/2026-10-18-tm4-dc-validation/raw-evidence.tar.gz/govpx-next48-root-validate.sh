#!/bin/sh
set -eu
cd /Users/thesyncim/GolandProjects/govpx
export CODEX_AGENT_ID=root-next48
export GOFLAGS=-p=2 CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GOMAXPROCS=2
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go
export GOFMT=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/gofmt
scripts/go.sh env GOCACHE GOVERSION GOEXPERIMENT > /private/tmp/govpx-next48-root-cache.log 2>&1
make pgo-refresh > /private/tmp/govpx-next48-root-pgo.log 2>&1
scripts/go.sh test ./... -count=1 > /private/tmp/govpx-next48-root-full.log 2>&1
scripts/go.sh test -pgo=off -race -gcflags=all=-d=checkptr=2 ./internal/pixel ./internal/vp8/dsp ./internal/vp8/decoder -run '^Test(TMPredict|Copy16|FP16|SSE8|DCPair|DCOnly|LoopFilter|NativeLF|MacroAxis)' -count=1 > /private/tmp/govpx-next48-root-race.log 2>&1
make test-noasm test-simd-selection pre-commit > /private/tmp/govpx-next48-root-gates.log 2>&1
printf '%s\n' 'PASS: PGO, full suite, ARM race/checkptr and build/pre-commit gates'

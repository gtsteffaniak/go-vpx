#!/bin/sh
set -eu
export GOMAXPROCS=1
base=/private/tmp/govpx-sse16-u8-unroll2-research
for v in parent u8square unroll2; do
 "$base/$v.test" -test.run '^$' -test.bench '^BenchmarkSSE16WindowNative$' -test.benchtime=1x -test.count=1 -test.cpu=1 -test.benchmem > "$base/$v-one.txt"
 : > "$base/$v-benchmark.txt"
done
: > "$base/orders.txt"
round=0
for order in 'parent u8square unroll2' 'u8square unroll2 parent' 'unroll2 parent u8square' 'parent unroll2 u8square' 'unroll2 u8square parent' 'u8square parent unroll2'; do
 round=$((round+1))
 printf 'round %s: %s
' "$round" "$order" >> "$base/orders.txt"
 for v in $order; do
  "$base/$v.test" -test.run '^$' -test.bench '^BenchmarkSSE16WindowNative$' -test.benchtime=80ms -test.count=1 -test.cpu=1 -test.benchmem >> "$base/$v-benchmark.txt"
 done
done

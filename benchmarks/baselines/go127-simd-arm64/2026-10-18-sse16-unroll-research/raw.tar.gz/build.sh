#!/bin/sh
set -eu
export CODEX_AGENT_ID=govpx-ci-sse-unroll CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GOEXPERIMENT=simd GOFLAGS=-p=2 GOMAXPROCS=1
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go
root=/Users/thesyncim/GolandProjects/govpx
base=/private/tmp/govpx-sse16-u8-unroll2-research
"$root/scripts/go.sh" env GOCACHE > "$base/cache.txt"
for v in parent u8square unroll2; do
 "$root/scripts/go.sh" -C "$base/$v" test -pgo=off ./internal/pixel ./internal/vp8/dsp -run 'TestSquaredError|TestSSE' -count=1 > "$base/$v-correctness.txt" 2>&1
 "$root/scripts/go.sh" -C "$base/$v" test -pgo=off -c -o "$base/$v.test" ./internal/vp8/dsp > "$base/$v-build.txt" 2>&1
done

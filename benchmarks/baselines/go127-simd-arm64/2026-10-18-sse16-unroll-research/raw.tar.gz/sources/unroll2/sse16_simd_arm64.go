//go:build goexperiment.simd && arm64 && !purego

package pixel

import (
 "simd/archsimd"
 "unsafe"
)

// SSE16 accumulates exact sixteen-column squared differences modulo2^32.
func SSE16(src []byte, ss int, ref []byte, rs, h int) uint32 {
 if !Enabled { return SSE16Scalar(src,ss,ref,rs,h) }
 var lo,hi archsimd.Int32x4
 // This guard bounds nonnegative offsets and retains the parent for short calls.
 if h>=8 && h<=4096 && (uint(ss)|uint(rs))>>30==0 {
  _=src[(h-1)*ss+15]; _=ref[(h-1)*rs+15]
  sp,rp:=unsafe.Pointer(unsafe.SliceData(src)),unsafe.Pointer(unsafe.SliceData(ref))
  var lo1,hi1 archsimd.Int32x4
  y:=0
  for ;y+2<=h;y+=2 {
   lo,hi=probeSSEPacket(lo,hi,load16(unsafe.Add(sp,y*ss)),load16(unsafe.Add(rp,y*rs)))
   lo1,hi1=probeSSEPacket(lo1,hi1,load16(unsafe.Add(sp,(y+1)*ss)),load16(unsafe.Add(rp,(y+1)*rs)))
  }
  if y<h { lo,hi=probeSSEPacket(lo,hi,load16(unsafe.Add(sp,y*ss)),load16(unsafe.Add(rp,y*rs))) }
  return uint32(sum32(lo.Add(hi).Add(lo1.Add(hi1))))
 }
 for y:=range h { lo,hi=ssePacket(lo,hi,archsimd.LoadUint8x16(src[y*ss:]),archsimd.LoadUint8x16(ref[y*rs:])) }
 return uint32(sum32(lo.Add(hi)))
}

func probeSSEPacket(lo,hi archsimd.Int32x4,a,b archsimd.Uint8x16)(archsimd.Int32x4,archsimd.Int32x4){d:=a.Max(b).Sub(a.Min(b))
 l:=d.MulWidenLo(d);dh:=highBytes(d);h:=dh.MulWidenLo(dh)
 ls:=l.ExtendLo4ToUint32().Add(l.HiToLo().ExtendLo4ToUint32())
 hs:=h.ExtendLo4ToUint32().Add(h.HiToLo().ExtendLo4ToUint32())
 return lo.Add(ls.BitsToInt32()),hi.Add(hs.BitsToInt32())}

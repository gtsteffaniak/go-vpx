package pixel
import "testing"
func TestSSE16UnrollBoundaries(t *testing.T) {
 for _,h:=range []int{0,1,3,7,8,9,15,16,17,65,720,4096,4097} {for _,ss:=range []int{0,1,15,16,32,1312} {for mode:=range 3 {
  rs:=ss+3;n,m:=16,16;if h>0{n+=(h-1)*ss;m+=(h-1)*rs}
  a,b:=make([]byte,n+3)[3:],make([]byte,m+5)[5:]
  for i:=range a {if mode==1{a[i]=255}else{a[i]=byte(i*37+11)}}
  for i:=range b {if mode==1{b[i]=0}else{b[i]=byte(i*19+53)}}
  if mode==2 {z:=make([]byte,max(n,m)+5);for i:=range z{z[i]=byte(i*17+29)};a,b=z[:n:n],z[5:5+m:5+m]}
  var want uint32;for y:=0;y<h;y++{for x:=range 16{d:=int(a[y*ss+x])-int(b[y*rs+x]);want+=uint32(d*d)}}
  if got:=SSE16(a,ss,b,rs,h);got!=want{t.Fatalf("h%d ss%d mode%d got%d want%d",h,ss,mode,got,want)}
 }} }
 for _,h:=range []int{1,7,8,9,65} {for which:=range 2{a,b:=make([]byte,16*h),make([]byte,16*h);if which==0{a=a[:len(a)-1]}else{b=b[:len(b)-1]};func(){defer func(){if recover()==nil{t.Fatalf("short h%d input%d accepted",h,which)}}();SSE16(a,16,b,16,h)}()}}
}

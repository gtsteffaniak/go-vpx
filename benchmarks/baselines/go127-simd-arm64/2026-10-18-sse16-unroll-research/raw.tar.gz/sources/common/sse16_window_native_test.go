package dsp
import("testing";"fmt")
var sse16WindowNativeSink int
func BenchmarkSSE16WindowNative(b *testing.B) {
 for _, h:=range []int{1,8,16,720}{for _, ss:=range []int{32,1312}{for mode:=range 2{
 b.Run(fmt.Sprintf("h%d/pitch%d/mode%d",h,ss,mode),func(b *testing.B){
 rs:=ss+16;a,r:=make([]byte,3+(h-1)*ss+16)[3:],make([]byte,5+(h-1)*rs+16)[5:]
 for i:=range a {if mode==0{a[i]=byte(i*37+11)}else{a[i]=255}};for i:=range r{if mode==0{r[i]=byte(i*19+53)}}
 want:=0;for y:=range h{for x:=range 16{d:=int(a[y*ss+x])-int(r[y*rs+x]);want+=d*d}}
 got:=0;b.ReportAllocs();for b.Loop(){got=SSE16xNPtrFast(&a[0],ss,&r[0],rs,h)};b.StopTimer();if got!=want{b.Fatalf("got%d want%d",got,want)};sse16WindowNativeSink=got
 })}}}
}

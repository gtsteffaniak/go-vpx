from pathlib import Path
import datetime,hashlib,json,os,platform,subprocess
p=Path('/private/tmp/govpx-next-tm4-guard');out=p/'screen';out.mkdir(exist_ok=True)
assert platform.machine()=='arm64'and platform.system()=='Darwin'
assert not list(out.glob('r*-*.txt')),'refuse overwrite'
proof=json.loads((p/'evidence/source-proof.json').read_text());hashes=json.loads((p/'evidence/binary-hashes.json').read_text())
for variant in ['parent','candidate','old691']:
 binary=p/(variant+'-dsp.test');assert hashlib.sha256(binary.read_bytes()).hexdigest()==hashes[binary.name]['sha256']
 for rel,sha in proof[variant]['all_go_sha256'].items():assert hashlib.sha256((p/variant/rel).read_bytes()).hexdigest()==sha,(variant,rel)
orders=[['parent','candidate','old691'],['candidate','old691','parent'],['old691','parent','candidate']];env=os.environ.copy();env.update(GOMAXPROCS='1',GOVPX_REQUIRE_SIMD='1');records=[]
print('SCREEN START UTC',datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
for rnd,order in enumerate(orders,1):
 for variant in order:
  cmd=[str(p/(variant+'-dsp.test')),'-test.run','^$','-test.bench','^BenchmarkTMPredictRowsNative$','-test.benchtime=75ms','-test.count=1','-test.cpu=1','-test.benchmem'];rec={'round':rnd,'variant':variant,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  with(out/f'r{rnd}-{variant}.txt').open('w')as f,(out/f'r{rnd}-{variant}.stderr').open('w')as e:r=subprocess.run(cmd,env=env,stdout=f,stderr=e)
  rec.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=r.returncode);records.append(rec)
  (out/'commands.json').write_text(json.dumps({'orders':orders,'env':{'GOMAXPROCS':1,'SDK':'go1.27.2','CGO_ENABLED_build':1,'PGO':'off'},'measurements':records},indent=2)+'\n');assert r.returncode==0,rec
 print('round',rnd,'END',flush=True)
print('SCREEN END UTC',datetime.datetime.now(datetime.timezone.utc).isoformat(),'all9 native processes STOPPED',flush=True)

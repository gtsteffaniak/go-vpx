from pathlib import Path
import re,json,statistics
p=Path('/private/tmp/govpx-next-tm4-guard');d=p/'screen';data={};cpus={}
for v in ['parent','candidate','old691']:
 data[v]={}
 for r in range(1,4):
  f=d/f'r{r}-{v}.txt';text=f.read_text();assert re.search('^PASS$',text,re.M),f;assert not(d/f'r{r}-{v}.stderr').read_text(),f
  cpu=re.search('^cpu: (.*)$',text,re.M);assert cpu;cpus[f.name]=cpu[1]
  rows=re.findall(r'^BenchmarkTMPredictRowsNative/(\S+)\s+\d+\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op$',text,re.M);assert len(rows)==27,(f,len(rows))
  for name,ns,byte,alloc in rows:
   assert byte==alloc=='0';data[v].setdefault(name,[]).append(float(ns))
assert len(set(cpus.values()))==1
cases={}
for name in data['parent']:
 vals={v:data[v][name]for v in data};med={v:statistics.median(a)for v,a in vals.items()};cases[name]={'ns':vals,'median_ns':med,'parent_over_candidate':med['parent']/med['candidate'],'old_over_candidate':med['old691']/med['candidate'],'paired_parent_over_candidate':[a/b for a,b in zip(vals['parent'],vals['candidate'])],'paired_old_over_candidate':[a/b for a,b in zip(vals['old691'],vals['candidate'])],'bytes_per_op':0,'allocs_per_op':0}
summary={'phase':'initial screen only, not fresh acceptance','parent_exact_git':'b6209532fbc30cf9567e0cdc78a21d61a60fe900','old_exact_git':'691cd0512c4829d9ee40d483205dd223f9eb028d','hardware':next(iter(cpus.values())),'rounds':3,'samples':243,'all_oracles_pass':True,'all_zero_alloc':True,'buildenv':{'SDK':'go1.27.2','CGO_ENABLED':1,'PGO':'off','GOMAXPROCS':1},'orders':json.loads((d/'commands.json').read_text())['orders'],'cases':cases,'widths':{}}
for w in ['4x4','8x8','16x16']:
 group={n:x for n,x in cases.items()if n.startswith(w+'/')};med=[x['parent_over_candidate']for x in group.values()];pairs=[a for x in group.values()for a in x['paired_parent_over_candidate']];om=[x['old_over_candidate']for x in group.values()];op=[a for x in group.values()for a in x['paired_old_over_candidate']];summary['widths'][w]={'median_parent_ratio_range':[min(med),max(med)],'all27_parent_pair_ratio_range':[min(pairs),max(pairs)],'candidate_faster_vs_parent_pairs':sum(a>1 for a in pairs),'candidate_slower_vs_parent_pairs':[{'case':n,'round':i+1,'parent_over_candidate':a}for n,x in group.items()for i,a in enumerate(x['paired_parent_over_candidate'])if a<1],'median_old_ratio_range':[min(om),max(om)],'all27_old_pair_ratio_range':[min(op),max(op)],'candidate_faster_vs_old_pairs':sum(a>1 for a in op)}
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for w,x in summary['widths'].items():print(w,json.dumps(x))
for n,x in cases.items():print(n,'parent/candidate/old',*[round(x['median_ns'][v],5)for v in ['parent','candidate','old691']],'p/c',round(x['parent_over_candidate'],6),'pairs',*[round(a,6)for a in x['paired_parent_over_candidate']],'old/c',round(x['old_over_candidate'],6))

from pathlib import Path
import hashlib,json,shutil
p=Path('/private/tmp/govpx-next-tm4-guard');out=Path('/private/tmp/govpx-arm-tm4-guard-ready');out.mkdir(exist_ok=False)
for name in ['screen','fresh','evidence']:
 shutil.copytree(p/name,out/name)
for f in p.glob('*.py'):shutil.copy2(f,out/f.name)
for f in [Path('/private/tmp/govpx-tm4-overlap-guard-proposal.patch'),Path('/private/tmp/govpx-tm4-overlap-guard-independent-review.json')]:shutil.copy2(f,out/f.name)
rel=Path('internal/pixel/tmpredict4_native_arm64.go');(out/'overlay'/rel).parent.mkdir(parents=True);shutil.copy2(p/'candidate'/rel,out/'overlay'/rel)
(out/'REPORT.md').write_text('''The accepted ARM TM4 tile kernel has a smaller overlap-guard refinement, measured against the immutable accepted TM4 parent on exact PR47. The byte arithmetic, row stores, original alias/malformed fallback and disabled/public contracts are unchanged. Two interval checks replace the ordered branch trees, with span bounded before arithmetic; the independent modular interval review requires valid non-wrapping Go allocations. Actual measured native helper drops160→149 instructions. TM8/16 normalized actual364-instruction bodies remain identical; their timing regressions are still preserved.

Apple M4 Max, officialGo1.27.2, CGO1, SIMD, PGOoff, GOMAXPROCS1. Initial3cyclic×27×3×75ms=243 samples retained: TM4parent median0.9877–1.1001x with22/27fasterpairs; all27oldNEONpairs faster. Fresh6balanced×27×3×100ms=486 samples: all9TM4medians1.0098–1.1588xparent,51/54pairsfaster; ALL36padded parent pairs faster, three packed slowerpairs retained(min0.99524x). All9oldNEONmedians1.0930–1.1152x, ALL54oldpairs faster(min1.07514x). These are incremental gains below1.5x versus the strong tile parent, separately from the mandatory retained original tile2.286–2.556x gain versus47. No product of separate-window ratios is claimed.

Fresh8x8controls median0.9723–1.0091xparent,21/54pairsfaster;16x16controls0.9733–1.0019x,21/54faster. Every slower control remains. All729timed samples0B/0alloc and full-state benchmark oracles pass. Race/checkptr2 passes all existing arithmetic/full-backing/alias/capacity/partial-panic TMPredict tests for pixel and publicDSP;27excluded newcandidate one-shots0alloc. A900-case unsigned boundary check covers32/64-bit arithmetic including near-wrap valid ranges. Initial analyzer inherited exact-Git metadata before execution; corrected to record Git47 plus the frozen tile overlay, preserving the inherited script as history.

No isolated whole-codec guard measurement or gap-closure claim. Combined integration measurements are separate. Parent/old native binaries are the exact prior frozen uniform specimens; new candidate build command/environment is retained in the task and binary buildinfo/SHA/source inventories here. Executables and full source snapshots are omitted; all original binaries remain in their private paths. No README, dependency or assembly changes.
''')
files=[]
for f in sorted(out.rglob('*')):
 if f.is_file():files.append({'path':str(f.relative_to(out)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'size':f.stat().st_size})
(out/'MANIFEST.json').write_text(json.dumps(files,indent=2)+'\n');print(out,len(files),'members')

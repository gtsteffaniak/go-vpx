#!/bin/sh
set -eu
cd /Users/thesyncim/GolandProjects/govpx
export CODEX_AGENT_ID=root-next47-amd64
export GOFLAGS=-p=2 CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GOMAXPROCS=2
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go
export GOOS=darwin GOARCH=amd64 GOAMD64=v1 CGO_ENABLED=0
scripts/go.sh test -pgo=off -gcflags=all=-d=checkptr=2 -c ./internal/pixel -o /private/tmp/govpx-next47-root-amd64-pixel.test > /private/tmp/govpx-next47-root-amd64-pixel-build.log 2>&1
scripts/go.sh test -pgo=off -gcflags=all=-d=checkptr=2 -c ./internal/vp8/dsp -o /private/tmp/govpx-next47-root-amd64-dsp.test > /private/tmp/govpx-next47-root-amd64-dsp-build.log 2>&1
for mode in on off; do
 case "$mode" in on) cpu_debug=; required_simd=1; fp_off=0 ;; off) cpu_debug=cpu.avx=off,cpu.avx2=off; required_simd=0; fp_off=1 ;; esac
 env ROSETTA_ADVERTISE_AVX=1 GODEBUG="$cpu_debug" GOVPX_REQUIRE_SIMD="$required_simd" GOVPX_REQUIRE_FP16_AVX_OFF="$fp_off" \
 /Users/thesyncim/.codex/bin/project-env arch -x86_64 /private/tmp/govpx-next47-root-amd64-pixel.test -test.run '^Test(BackendSelected|TMPredict|FP16|SSE8|Copy16)' -test.count=1 -test.v > "/private/tmp/govpx-next47-root-amd64-pixel-$mode.log" 2>&1
 env ROSETTA_ADVERTISE_AVX=1 GODEBUG="$cpu_debug" GOVPX_REQUIRE_SIMD="$required_simd" \
 /Users/thesyncim/.codex/bin/project-env arch -x86_64 /private/tmp/govpx-next47-root-amd64-dsp.test -test.run '^Test(TMPredict|Copy16|SSE8)' -test.count=1 -test.v -test.bench '^Benchmark(SSE8RowsNative|TMPredictRowsNative|Copy16RowsNative)$' -test.benchtime=1x -test.cpu=1 -test.benchmem > "/private/tmp/govpx-next47-root-amd64-dsp-$mode.log" 2>&1
done
printf '%s\n' 'PASS: integrated amd64 selected/off checkptr2 tests and 71 public one-shots per mode; Rosetta correctness only'

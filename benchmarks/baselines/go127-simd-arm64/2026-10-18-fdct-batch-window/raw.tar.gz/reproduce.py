#!/usr/bin/python3
"""Rebuild the recorded public protocol; running this starts native benchmarks."""
import argparse
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True, type=Path, help='Existing govpx Git checkout; never changed')
parser.add_argument('--work', required=True, type=Path, help='New private directory for source snapshots/results')
parser.add_argument('--go', default='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go')
args = parser.parse_args()
package = Path(__file__).resolve().parent
metadata = json.loads((package/'environment.json').read_text())
args.work.mkdir(parents=True, exist_ok=False)
env = os.environ.copy()
env.update(GO=args.go, GOTOOLCHAIN='local', GOEXPERIMENT='simd',
           CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',
           CODEX_AGENT_ID='ci-fdct-window-reproduction', GOFLAGS='-p=2', GOMAXPROCS='2')
commands = []

def run(cmd, logfile, runenv=None):
    commands.append(cmd)
    with logfile.open('w') as output:
        output.write(repr(cmd)+'\n')
        output.flush()
        subprocess.run(cmd, cwd=args.repo, env=runenv or env, stdout=output,
                       stderr=subprocess.STDOUT, check=True)

for name in ('parent','candidate','asm'):
    revision = metadata['asm_revision'] if name == 'asm' else metadata['parent_revision']
    snapshot = args.work/name
    snapshot.mkdir()
    archive = subprocess.check_output(['git','archive',revision], cwd=args.repo)
    with tarfile.open(fileobj=io.BytesIO(archive)) as contents:
        contents.extractall(snapshot)
    for source in (package/'sources'/name).rglob('*'):
        if source.is_file():
            target = snapshot/source.relative_to(package/'sources'/name)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
    run([str(args.repo/'scripts/go.sh'),'-C',str(snapshot),'test','-pgo=off',
         '-c','-o',str(args.work/(name+'.test')),'./internal/vp8/encoder'],
        args.work/(name+'-build.log'))
    if name != 'asm':
        run([str(args.work/(name+'.test')),
             '-test.run=TestForwardDCT.*Batch|TestForwardDCTBatch','-test.count=1','-test.v'],
            args.work/(name+'-correctness.log'))
run([str(args.repo/'scripts/go.sh'),'-C',str(args.work/'candidate'),'test','-pgo=off',
     '-race','-gcflags=all=-d=checkptr=2','./internal/vp8/encoder',
     '-run','TestForwardDCT.*Batch|TestForwardDCTBatch','-count=1'],
    args.work/'candidate-race-checkptr.log')
timing_env = env.copy()
timing_env['GOMAXPROCS'] = '1'
for name in ('parent','candidate','asm'):
    run([str(args.work/(name+'.test')),'-test.run=^$',
         '-test.bench=^BenchmarkForwardDCTBatchWindowNative$', '-test.benchtime=1x',
         '-test.cpu=1','-test.benchmem'],args.work/(name+'-fixture1x.log'),timing_env)
orders = [('parent','candidate','asm'),('asm','candidate','parent'),
          ('candidate','asm','parent'),('parent','asm','candidate'),
          ('asm','parent','candidate'),('candidate','parent','asm')]
for index, order in enumerate(orders,1):
    for name in order:
        run([str(args.work/(name+'.test')),'-test.run=^$',
             '-test.bench=^BenchmarkForwardDCTBatchWindowNative$', '-test.benchtime=100ms',
             '-test.cpu=1','-test.benchmem'],args.work/('round%d-%s.log'%(index,name)),timing_env)
(args.work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')

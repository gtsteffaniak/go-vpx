package encoder

import (
 "fmt"
 "testing"
)

var fdctBatchWindowSink int16

func BenchmarkForwardDCTBatchWindowNative(b *testing.B) {
 for _, count := range []int{2,8,16,25} {
  for _, pattern := range []string{"mixed","flat","extreme"} {
   b.Run(fmt.Sprintf("blocks%d/%s",count,pattern),func(b *testing.B) {
    input:=make([]int16,count*16); output:=make([]int16,count*16+2); want:=make([]int16,count*16)
    for i:=range input {
     switch pattern {case "mixed": input[i]=int16((i*37+11)%511-255); case "flat": input[i]=7;case "extreme": if i%2==0 {input[i]=-255} else {input[i]=255}}
    }
    saved:=append([]int16(nil),input...)
    for j:=0;j<count;j++ {forwardDCT4x4Scalar(input[j*16:],4,(*[16]int16)(want[j*16:]))}
    output[0],output[len(output)-1]=1234,-1234
    ForwardDCT4x4Batch(input,output[1:len(output)-1],count)
    check:=func(){
     for i:=range want {if output[i+1]!=want[i] {b.Fatalf("lane %d: %d != %d",i,output[i+1],want[i])};if input[i]!=saved[i] {b.Fatal("input changed")}}
     if output[0]!=1234||output[len(output)-1]!=-1234 {b.Fatal("output canary")}
    }
    check()
    b.ReportAllocs()
    for b.Loop(){ForwardDCT4x4Batch(input,output[1:len(output)-1],count)}
    fdctBatchWindowSink=output[1]+output[len(output)-2]
    check()
   })
  }
 }
}

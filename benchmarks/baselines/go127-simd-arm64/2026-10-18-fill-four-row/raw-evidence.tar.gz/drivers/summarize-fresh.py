from pathlib import Path
import json,re,statistics,sys
r=Path('/private/tmp/govpx-arm-fill-unroll4');kind=sys.argv[1];variants=['parent','candidate']if kind=='pixel'else['parent','candidate','old691'];expected=18 if kind=='pixel' else 12;groups={};pairs={};samples=[]
for p in sorted((r/('fresh-'+kind)).glob('r*-*.log')):
 rnd=int(p.stem.split('-')[0][1:]);v=p.stem.split('-',1)[1];s=p.read_text();assert re.search(r'^PASS$',s,re.M),p
 rows=re.findall(r'^(Benchmark\S+)\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',s,re.M);assert len(rows)==expected,(p,len(rows))
 for case,it,ns,bytes_,alloc in rows:
  assert bytes_==alloc=='0'and float(ns)>0
  key=v,case,rnd;assert key not in pairs;pairs[key]=float(ns);groups.setdefault((v,case),[]).append(float(ns));samples.append({'case':case,'round':rnd,'variant':v,'ns':float(ns),'iterations':int(it),'B/op':int(bytes_),'allocs/op':int(alloc),'log':str(p.relative_to(r))})
assert len(samples)==expected*len(variants)*6
out=[]
for case in sorted({s['case']for s in samples}):
 med={v:statistics.median(groups[v,case])for v in variants};item={'case':case,'medians_ns':med,'parent_over_candidate':med['parent']/med['candidate'],'candidate_time_change_percent':(med['candidate']/med['parent']-1)*100,'pair_ratios_parent_over_candidate':[pairs['parent',case,i]/pairs['candidate',case,i]for i in range(1,7)],'candidate_faster_pairs':sum(pairs['candidate',case,i]<pairs['parent',case,i]for i in range(1,7))}
 if 'old691'in variants:item.update(old_over_candidate=med['old691']/med['candidate'],pair_ratios_old_over_candidate=[pairs['old691',case,i]/pairs['candidate',case,i]for i in range(1,7)])
 out.append(item)
summary={'kind':kind,'hardware':'Apple M4 Max','compiler':'officialGo1.27.2','PGO':'off','GOMAXPROCS':1,'benchtime':'100ms','rounds':6,'all_zero_alloc':True,'cases':out,'samples':samples};(r/('fresh-'+kind)/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for x in out:print(x['case'],x['medians_ns'],f"{x['parent_over_candidate']:.4f}x",f"pairs{x['candidate_faster_pairs']}/6",f"old/cand{x.get('old_over_candidate',0):.4f}")

from pathlib import Path
import json,statistics
r=Path('/private/tmp/govpx-arm-fill-unroll4');out=r/'fresh-whole';variants=['parent','candidate','old691'];ref=json.loads((out/'r1-parent.json').read_text());excluded={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'};keys=sorted(set(ref)-excluded);assert len(keys)==22;values={v:[]for v in variants};records=[]
for rnd in range(1,7):
 for v in variants:
  j=json.loads((out/f'r{rnd}-{v}.json').read_text());assert set(j)==set(ref);diff={k:[ref[k],j[k]]for k in keys if ref[k]!=j[k]};assert not diff,(rnd,v,diff);assert j['allocs_per_frame']==0;values[v].append(j['ns_per_frame']);records.append({'round':rnd,'variant':v,'all22_semantics_match':True,'allocs_per_frame':0})
med={v:statistics.median(values[v])for v in variants};compare={}
for v in ['parent','old691']:
 delta=[(values['candidate'][i]/values[v][i]-1)*100for i in range(6)];compare[v]={'candidate_time_change_percent_ratio_of_medians':(med['candidate']/med[v]-1)*100,'paired_candidate_time_changes_percent':delta,'faster_pairs':sum(x<0for x in delta),'min_pair_change_percent':min(delta),'max_pair_change_percent':max(delta)}
summary={'hardware':'Apple M4 Max','compiler':'officialGo1.27.2SIMD','PGO':'off','GOMAXPROCS':1,'frames':300,'rounds':6,'variant_ns_per_frame':values,'medians_ns_per_frame':med,'comparisons':compare,'semantic_field_names':keys,'all22_semantics_match':True,'all_allocations_zero':True,'records':records};(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

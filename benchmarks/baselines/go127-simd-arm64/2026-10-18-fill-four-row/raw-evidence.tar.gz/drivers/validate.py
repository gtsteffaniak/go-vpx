from pathlib import Path
import os,subprocess,json,sys
r=Path('/private/tmp/govpx-arm-fill-unroll4');root=Path('/Users/thesyncim/GolandProjects/govpx');e=os.environ.copy();e.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-fill-unroll4',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go');records=[]
for v in ['parent','candidate']:
 cmds=[]
 if v!='old691':
  cmds += [('backend',['test','-pgo=off','./internal/pixel','-run','^TestBackendSelected$','-count=1','-v'],{'GOVPX_REQUIRE_SIMD':'1'}),('pixel-state',['test','-pgo=off','./internal/pixel','-run','^TestFillExact','-count=1','-v'],{}),('pixel-race-checkptr2',['test','-pgo=off','-race','-gcflags=all=-d=checkptr=2','./internal/pixel','-run','^TestFillExact','-count=1','-v'],{}),('purego-pixel-state',['test','-pgo=off','-tags=purego','./internal/pixel','-run','^TestFillExact','-count=1','-v'],{}),('nosimd-pixel-state',['test','-pgo=off','./internal/pixel','-run','^TestFillExact','-count=1','-v'],{'GOEXPERIMENT':''}),('pixel-build',['test','-pgo=off','-c','./internal/pixel','-o',str(r/(v+'-final-pixel.test'))],{})]
 cmds += [('dsp-state',['test','-pgo=off','./internal/vp8/dsp','-run','^TestIntraDCFillExactState$','-count=1','-v'],{}),('dsp-build',['test','-pgo=off','-c','./internal/vp8/dsp','-o',str(r/(v+'-final-dsp.test'))],{})]
 if v!='old691':cmds += [('dsp-race-checkptr2',['test','-pgo=off','-race','-gcflags=all=-d=checkptr=2','./internal/vp8/dsp','-run','^TestIntraDCFillExactState$','-count=1','-v'],{})]
 for name,args,extra in cmds:
  env=e.copy();env.update(extra);cmd=[str(root/'scripts/go.sh'),'-C',str(r/v)]+args
  with (r/'final-evidence'/f'{v}-{name}.log').open('w')as f:run=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
  records.append({'variant':v,'name':name,'command':cmd,'env_overrides':extra,'exit':run.returncode});(r/'final-evidence/validation.json').write_text(json.dumps(records,indent=2)+'\n');print(v,name,run.returncode,flush=True)
  if run.returncode:sys.exit(run.returncode)
print('CORRECTNESS/BUILD COMPLETE',flush=True)

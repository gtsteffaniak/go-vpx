from pathlib import Path
import os,subprocess,json,time,sys
r=Path('/private/tmp/govpx-arm-fill-unroll4');e=os.environ.copy();e.update(GOMAXPROCS='1');kind=sys.argv[1];records=[]
if kind=='pixel':orders=[['candidate','parent'],['parent','candidate'],['candidate','parent']];bench='^BenchmarkFillExactFinal$'
elif kind=='dsp':orders=[['parent','candidate','old691'],['candidate','old691','parent'],['old691','parent','candidate']];bench='^BenchmarkIntraDCFillExact$'
else:raise ValueError(kind)
for rnd,order in enumerate(orders,1):
 for v in order:
  binary=(Path('/private/tmp/govpx-arm-fill-exact')if v=='old691'else r)/(v+'-final-'+kind+'.test');cmd=[str(binary),'-test.run=^$','-test.bench='+bench,'-test.benchtime=75ms','-test.cpu=1','-test.count=1','-test.benchmem'];start=time.time()
  with (r/('screen-'+kind)/f'r{rnd}-{v}.log').open('w')as f:run=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT)
  records.append({'round':rnd,'variant':v,'command':cmd,'start':start,'end':time.time(),'exit':run.returncode});(r/('screen-'+kind)/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert run.returncode==0
 print(kind,'round',rnd,'complete',flush=True)
print(kind,'SCREEN END',flush=True)

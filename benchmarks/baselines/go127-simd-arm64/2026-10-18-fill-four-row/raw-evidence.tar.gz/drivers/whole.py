from pathlib import Path
import os,subprocess,json,time
r=Path('/private/tmp/govpx-arm-fill-unroll4');out=r/'fresh-whole';out.mkdir(exist_ok=True);e=os.environ.copy();e.update(GOMAXPROCS='1');records=[]
orders=[['parent','candidate','old691'],['candidate','old691','parent'],['old691','parent','candidate'],['old691','candidate','parent'],['candidate','parent','old691'],['parent','old691','candidate']]
for rnd,order in enumerate(orders,1):
 for v in order:
  cmd=[str((Path('/private/tmp/govpx-arm-fill-exact')if v=='old691'else r)/(v+'-whole-bench')),'-codec=vp8','-width=1280','-height=720','-frames=300','-fps=30','-bitrate=2500','-mode=realtime','-cpu-used=8','-threads=1','-encode-only','-auto-libvpx=false','-format=json'];start=time.time()
  with (out/f'r{rnd}-{v}.json').open('w')as f,(out/f'r{rnd}-{v}.stderr').open('w')as err:run=subprocess.run(cmd,env=e,stdout=f,stderr=err)
  records.append({'round':rnd,'variant':v,'command':cmd,'start':start,'end':time.time(),'exit':run.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert run.returncode==0
 print('whole round',rnd,'complete',flush=True)
print('WHOLE TIMING COMPLETE',flush=True)

from pathlib import Path
import os,subprocess,json,time,sys
r=Path('/private/tmp/govpx-arm-fill-unroll4');e=os.environ.copy();e.update(GOMAXPROCS='1');kind=sys.argv[1];records=[]
if kind=='pixel':orders=[['candidate','parent'],['parent','candidate']]*3;bench='^BenchmarkFillExactFinal$'
elif kind=='dsp':orders=[['parent','candidate','old691'],['candidate','old691','parent'],['old691','parent','candidate'],['old691','candidate','parent'],['candidate','parent','old691'],['parent','old691','candidate']];bench='^BenchmarkIntraDCFillExact$'
else:raise ValueError(kind)
out=r/('fresh-'+kind)
for rnd,order in enumerate(orders,1):
 for v in order:
  cmd=[str((Path('/private/tmp/govpx-arm-fill-exact')if v=='old691'else r)/(v+'-final-'+kind+'.test')),'-test.run=^$','-test.bench='+bench,'-test.benchtime=100ms','-test.cpu=1','-test.count=1','-test.benchmem'];start=time.time()
  with (out/f'r{rnd}-{v}.log').open('w')as f:run=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT)
  records.append({'round':rnd,'variant':v,'command':cmd,'start':start,'end':time.time(),'exit':run.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert run.returncode==0
 print(kind,'round',rnd,'complete',flush=True)
print(kind,'TIMING COMPLETE',flush=True)

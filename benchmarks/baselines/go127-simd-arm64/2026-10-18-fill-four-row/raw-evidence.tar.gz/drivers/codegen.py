from pathlib import Path
import subprocess,re,json
r=Path('/private/tmp/govpx-arm-fill-unroll4');out={};commands=[]
for v in ['parent','candidate']:
 cmd=['xcrun','llvm-objdump','--disassemble','--demangle','--disassemble-symbols=_github.com/thesyncim/govpx/internal/pixel.FillBlock',str(r/(v+'-final-pixel.test'))];run=subprocess.run(cmd,capture_output=True,text=True);assert run.returncode==0;(r/'final-evidence'/f'{v}-FillBlock-llvm.txt').write_text(run.stdout+run.stderr);commands.append(cmd)
 ins=re.findall(r'^([0-9a-f]+):\s+[0-9a-f]+\s+([^\n]+)',run.stdout,re.M);out[v]={'instructions':len(ins),'madd_count':sum(bool(re.match('madd\\b',x[1]))for x in ins),'calls':[x[1]for x in ins if re.match('bl\\s',x[1])],'vector_stack_stores':len(re.findall(r'\b(?:str|stur)\s+q\d+, \[sp',run.stdout))}
(r/'final-evidence/codegen-summary.json').write_text(json.dumps(out,indent=2)+'\n');(r/'final-evidence/codegen-commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(out,indent=2))

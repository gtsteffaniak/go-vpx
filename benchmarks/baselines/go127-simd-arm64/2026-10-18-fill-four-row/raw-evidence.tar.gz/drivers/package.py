from pathlib import Path
import json,hashlib,shutil,difflib,subprocess,re
r=Path('/private/tmp/govpx-arm-fill-unroll4');ready=Path('/private/tmp/govpx-arm-fill-unroll4-ready');ready.mkdir();root=Path('/Users/thesyncim/GolandProjects/govpx');old=Path('/private/tmp/govpx-arm-fill-exact');locked=Path('/private/tmp/govpx-arm-fill-exact-ready')
for d in ['drivers','final-evidence','screen-pixel','screen-dsp','fresh-pixel','fresh-dsp','fresh-whole']:shutil.copytree(r/d,ready/d)
shutil.copyfile(r/'INTEGRATION-NOTES.md',ready/'INTEGRATION-NOTES.md')
paths=['internal/pixel/kernels_simd.go','internal/pixel/fill_fixed_arm64.go','internal/pixel/fill_fixed_other.go','internal/pixel/fill_exact_native_test.go','internal/vp8/dsp/fill_exact_native_test.go','internal/vp8/dsp/intra.go','internal/vp8/dsp/intra_dispatch_other.go','internal/vp8/dsp/intra4x4_other.go']
for v in ['parent','candidate']:
 for rel in paths:
  q=ready/(v+'-source')/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/v/rel,q)
for rel in paths[:5]:
 q=ready/'overlay'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/'candidate'/rel,q)
for rel in ['internal/vp8/dsp/intra_arm64.go','internal/vp8/dsp/intra_arm64.s','internal/vp8/dsp/fill_exact_native_test.go']:
 q=ready/'old691-source'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old/'old691'/rel,q)
patch=[]
for rel in paths:
 a,b=(r/'parent'/rel).read_text(),(r/'candidate'/rel).read_text();patch.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='locked-parent/'+rel,tofile='candidate/'+rel))
(ready/'candidate.patch').write_text(''.join(patch))
# Strong parent, sole production delta, and frozen archive proofs.
proof={}
for rel in paths[:3]:
 a=(r/'parent'/rel).read_bytes();b=(locked/'overlay'/rel).read_bytes();assert a==b;proof[rel]=hashlib.sha256(a).hexdigest()
changes=[]
for p in (r/'parent').rglob('*.go'):
 rel=p.relative_to(r/'parent');q=r/'candidate'/rel
 if not q.exists()or p.read_bytes()!=q.read_bytes():changes.append(str(rel))
for q in (r/'candidate').rglob('*.go'):
 if not (r/'parent'/q.relative_to(r/'candidate')).exists():changes.append(str(q.relative_to(r/'candidate')))
assert changes==['internal/pixel/kernels_simd.go'],changes
pa=(r/'parent/internal/pixel/kernels_simd.go').read_text();ca=(r/'candidate/internal/pixel/kernels_simd.go').read_text();ps,pe=pa.index('func FillBlock('),pa.index('func RepeatRow(');cs,ce=ca.index('func FillBlock('),ca.index('func RepeatRow(');assert pa[:ps]==ca[:cs]and pa[pe:]==ca[ce:]
manifest=(locked/'SHA256SUMS').read_bytes();assert hashlib.sha256(manifest).hexdigest()=='48b1fb9e424d654b19c310f390135724e3dc33a6b9a8b5c61922a3fda689c20c'
bba=subprocess.check_output(['git','rev-parse','bba90959^{tree}'],cwd=root,text=True).strip();base=subprocess.check_output(['git','rev-parse','768f2fc2^{tree}'],cwd=root,text=True).strip();assert bba==base
pixel=json.loads((r/'fresh-pixel/summary.json').read_text());dsp=json.loads((r/'fresh-dsp/summary.json').read_text());whole=json.loads((r/'fresh-whole/summary.json').read_text());screenp=json.loads((r/'screen-pixel/summary.json').read_text());screend=json.loads((r/'screen-dsp/summary.json').read_text());all_samples=[x for s in [pixel,dsp,screenp,screend]for x in s['samples']];assert len(all_samples)==648 and all(x['B/op']==x['allocs/op']==0 for x in all_samples)
sdk=Path('/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64');env={'parent_base_commit':'768f2fc2aba7bbd82981494473cbadc026a95570','merged_base_commit':'bba90959','bba90959_tree_equals_768f2fc2_tree':bba,'strong_parent':'base+exactpreviouslyverifiedlockedFillwinner,NOTbarebase','old691':'691cd0512c4829d9ee40d483205dd223f9eb028d','cpu':re.search(r'^cpu: (.+)$',(r/'fresh-pixel/r1-parent.log').read_text(),re.M).group(1),'compiler':(sdk/'VERSION').read_text().strip(),'PGO':'off','GOEXPERIMENT':'simd','GOFLAGS':'-p=2','build_GOMAXPROCS':2,'timing_GOMAXPROCS':1,'project_wrapper':'ROOT/scripts/go.sh -C private snapshot -> project-env','source_sha256':{str(p.relative_to(ready)):hashlib.sha256(p.read_bytes()).hexdigest()for d in ['parent-source','candidate-source','overlay','old691-source']for p in (ready/d).rglob('*')if p.is_file()},'test_binary_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in r.glob('*-final-*.test')},'old691_dsp_binary_sha256':hashlib.sha256((old/'old691-final-dsp.test').read_bytes()).hexdigest(),'old691_whole_binary_sha256':hashlib.sha256((old/'old691-whole-bench').read_bytes()).hexdigest()};(ready/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
verification={'strong_parent_production_matches_frozen_winner':proof,'only_changed_production_path':changes,'only_FillBlock_body_changed':True,'prior171archive_manifest_unchanged':True,'fresh_pixel_samples':len(pixel['samples']),'fresh_dsp_samples':len(dsp['samples']),'screen_pixel_samples':len(screenp['samples']),'screen_dsp_samples':len(screend['samples']),'all648component_samples_zero_alloc':True,'whole_sample_count':len(whole['records']),'whole_all22_semantics_match':whole['all22_semantics_match'],'whole_allocs_zero':whole['all_allocations_zero'],'all18validation_commands_pass':all(x['exit']==0 for x in json.loads((r/'final-evidence/validation.json').read_text()))};assert verification['fresh_pixel_samples']==verification['fresh_dsp_samples']==216 and verification['whole_sample_count']==18 and verification['whole_all22_semantics_match']and verification['whole_allocs_zero']and verification['all18validation_commands_pass'];(ready/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
report='''# Retain ARM four-row FillBlock unroll: component gain over the locked winner

Native Apple M4 Max, official Go 1.27.2, GOEXPERIMENT=simd, PGO off,
GOMAXPROCS=1. Strong parent is the exact previously verified fixed-store
FillBlock winner, based on 768f2fc2. PR43 merge bba90959 has the identical
Git tree; this equality is independently checked in the package. Comparing
against bare 768 would inflate this new improvement and is not done here.
Old reference is immutable 691cd051, with actual ARM NEON DSP kernels.

Retain under the user's explicit component rule: fresh 8x8 FillBlock improves
1.5908–1.6163× across packed,37,1312 pitches over the already optimized parent;
packed public IntraDCPredict16x16 with no neighbors improves 1.6274×. Whole
VP8 is flat/mixed (−0.091934% median,4/6 faster). Candidate remains8.670979% slower than original assembly in this run. Component gains and whole results are
separate; no additive gains, universal assembly closure, or x64 claim.

## Exact single variant and semantic contract

Only the proven ARM fixed-store path changes, and only when h%4==0. One row
base is computed per four stores; ds,2*ds,3*ds select successive rows. Full
existing Enabled/width/height/bounded-stride/complete-LEN guard stays intact.
The original current loop handles other heights. Stores remain exact4/8/16B,
row0,row1,row2,row3 followed by the next group, preserving overlap semantics
and writes of the same value. Maximum row remains h−1; all offsets lie within
the already-proved window. Decline occurs before stores; invalid/short-LEN/
spare-CAP/late-capacity panic and partial writes remain original behavior.
No allocation, new unsafe contract, dependency, assembly or extra helper call.
AMD selection remains constant false; its source helper/other runtime functions
are unchanged. Source inventory proves one production file and only its
FillBlock body differ. Exact parent and candidate bytes are preserved.

Old NEON fact check: intraFill8x8NEON and intraFill16x16NEON are NOT unrolled.
They use one VST1, pointer ADD, counter SUB, and branch per row. The earlier
unroll hypothesis about old code is withdrawn; source is included. Actual new
LLVM shows one MADD per four stores, no extra calls/vector spills. Full function
entries grow166→218 because both four-row and original fallback loops exist;
counts are diagnostic and not the reason for acceptance.

## Correctness before timing

Both variants passed live ARM backend selection, ordinary/race+checkptr2 pixel
and DSP oracles, purego and no-SIMD state tests. Pixel oracle compares full
backing and panic/partial state against independently coded prior behavior,
including clipped capacities, short LEN with spare CAP, exact windows, negative,
zero and overlapping strides, h3/7/63 plus64/65 boundaries, stride2^30±boundary,
MaxInt/MinInt, misalignment, and every0..255 payload. Added nonmultiple heights
prove the original current loop remains correct. DSP scalar oracle covers
8/16 none/both neighbors, exact windows/pitches, misalignments and contexts
aliasing destination. All one-shot public fixtures pass before timing, including
pinned old NEON. Complete validation commands and logs are preserved.

Call-scope correction to the earlier frozen171 archive: n4 production also
calls intraDCGo via intra4x4_other.go:10. Actual measured DSP callers are n8/n16;
4x4 FillBlock component is measured, while actual4x4 DSP caller performance
is unmeasured. See INTEGRATION-NOTES.md. The earlier archive remains byte-for-byte
unchanged, including its source and raw evidence; this outer correction fixes
the overly narrow caller statement without editing frozen history.

## Exploratory screen and fresh confirmation

The preliminary three75ms pairs/cyclic permutations are preserved, including
all slower one-row controls. They are not acceptance data. Fresh confirmation
uses six balanced AB/BA pairs for pixel and all six three-variant permutations
for DSP,100ms per case. All648 screen+fresh component samples have0B/op and
0allocs/op. Each B.Loop invokes the real public operation; Fill changes payload
each iteration, and DSP checks scalar result, complete output/canaries and
immutable contexts. All samples, paired ranges and order commands are retained.

### Fresh pixel component

| Case | Locked parent ns | Unroll ns | Ratio of medians | All six paired ratios range | Faster pairs |
|---|---:|---:|---:|---:|---:|
'''
for x in pixel['cases']:
 m=x['medians_ns'];pairs=x['pair_ratios_parent_over_candidate'];report+=f"| {x['case'].split('Final/')[1]} | {m['parent']:.4f} | {m['candidate']:.4f} | {x['parent_over_candidate']:.5f}× | {min(pairs):.5f}–{max(pairs):.5f}× | {x['candidate_faster_pairs']}/6 |\n"
report+='''
All square cases improve in6/6 pairs. Only8x8 medians cross1.5× against the
strong parent;4x4 is1.304–1.306× and16x16 is1.272–1.385×. One-row8-byte
packed/large-pitch controls regress to~0.955×; they remain explicit. Other
one-row controls are near-flat/mixed. No bad sample or control is dropped.

### Fresh actual DSP caller, with original NEON comparator

| Case | Locked parent ns | Unroll ns | Old NEON ns | Parent/unroll median | Six-pair range | Old/unroll median |
|---|---:|---:|---:|---:|---:|---:|
'''
for x in dsp['cases']:
 m=x['medians_ns'];pairs=x['pair_ratios_parent_over_candidate'];report+=f"| {x['case'].split('Exact/')[1]} | {m['parent']:.4f} | {m['candidate']:.4f} | {m['old691']:.4f} | {x['parent_over_candidate']:.5f}× | {min(pairs):.5f}–{max(pairs):.5f}× | {x['old_over_candidate']:.5f}× |\n"
report+='''
All12 DSP cases improve in6/6 pairs against the locked parent. Packed16x16
with no neighbors qualifies at1.6274×; other caller gains are below1.5×.
All16x16 no-neighbor median cases beat old NEON (old/unroll1.116–1.348×).
Fresh8x8 no-neighbor remains2.5–5.8% slower than old NEON; preliminary padded
screen wins over old do not survive fresh confirmation. Both-neighbor cases
remain slower than old. Every screen and fresh result is preserved separately.

## Fresh whole-codec quantification

Six balanced three-way permutations; VP8,1280x720,300 inputs,30fps,2500kbps,
realtime CPU-used8,one thread,encode-only,auto-libvpx=false. Strong locked
parent and candidate CLIs were freshly built with the same SDK/PGO-off flags;
old691 was reused only after verifying its previously built SDK/PGO-off hash.
Builds use the root project wrapper, unique IDs, GOMAX2; all builds and heavy
parsing/hashing stop during announced native windows. Root and other agents
confirm exclusive START/END; no competing local benchmark/build/profile.

All22 semantic fields and separate zero allocations match across18 JSONs:
298 encoded,2 dropped,3120743 output bytes,133700 keyframe bytes, identical
quantizer metadata/histogram. Positive CPU8 is adaptive, so work parity is
checked rather than assumed. Quality is skipped; these fields do not prove
bitstream identity. Timer is encode-only and excludes fixture setup.
'''
for v in ['parent','candidate','old691']:report+=f"\n- {v}: median {whole['medians_ns_per_frame'][v]:,.1f} ns/input; six values {whole['variant_ns_per_frame'][v]}.\n"
for v in ['parent','old691']:
 x=whole['comparisons'][v];report+=f"\nCandidate vs {v}: {x['candidate_time_change_percent_ratio_of_medians']:+.6f}% by ratio of medians, {x['faster_pairs']}/6 faster; all paired percent changes {x['paired_candidate_time_changes_percent']}.\n"
report+='''
The whole change is flat/mixed, with no claimed codec gain. Candidate
remains8.670979% slower than original assembly by this run's ratio of medians (slower in all
six rounds; paired gap3.40596–9.89209%). This gap is not comparable by subtraction
with another run or runner. Retain the verified component wins despite flat
whole behavior, as explicitly required by the user's acceptance policy.

## Delivery

Overlay contains exact final source and two strengthened fixtures; root owns
integration, whitespace-only test formatting, fresh PGO and combined full gates.
No root, README or PR edits were made by this agent. Exact source, scoped patch,
LLVM, all ordinary/race/fallback logs, preliminary and fresh raw measurements,
18 whole JSONs/stderr, commands, all paired ratios, hardware/compiler/build/
source/binary hashes and independent scope verification are bundled. No full
snapshots, binaries, dependency copies or source changes to the frozen171 archive.
SHA256SUMS covers every other member. No more timing or experiments are planned.
'''
(ready/'REPORT.md').write_text(report)
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ready))+'\n'for p in sorted(ready.rglob('*'))if p.is_file()and p.name!='SHA256SUMS');(ready/'SHA256SUMS').write_text(manifest)
for line in manifest.splitlines():
 sha,name=line.split('  ',1);assert hashlib.sha256((ready/name).read_bytes()).hexdigest()==sha
print('FROZEN',ready,'MEMBERS',len(manifest.splitlines()),'BYTES',sum(p.stat().st_size for p in ready.rglob('*')if p.is_file()),'MANIFEST_SHA',hashlib.sha256(manifest.encode()).hexdigest())

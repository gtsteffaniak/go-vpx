from pathlib import Path
import shutil,hashlib,json
r=Path('/private/tmp/govpx-arm-fill-unroll4');r.mkdir();(r/'drivers').mkdir();(r/'final-evidence').mkdir();(r/'screen-pixel').mkdir();(r/'screen-dsp').mkdir();old=Path('/private/tmp/govpx-arm-fill-exact')
for v in ['parent','candidate']:shutil.copytree(old/'candidate',r/v)
f=r/'candidate/internal/pixel/kernels_simd.go';s=f.read_text();start=s.index('func FillBlock(');end=s.index('func RepeatRow(',start);body=s[start:end]
needle='\t\tv := archsimd.BroadcastUint8x16(value)\n\t\tswitch w {';assert body.count(needle)==1
new='''		v := archsimd.BroadcastUint8x16(value)
		if h&3 == 0 {
			d2, d3 := 2*ds, 3*ds
			switch w {
			case 16:
				for row := 0; row < h; row += 4 {
					at := unsafe.Add(p, row*ds)
					v.StoreArray((*[16]byte)(at))
					v.StoreArray((*[16]byte)(unsafe.Add(at, ds)))
					v.StoreArray((*[16]byte)(unsafe.Add(at, d2)))
					v.StoreArray((*[16]byte)(unsafe.Add(at, d3)))
				}
			case 8:
				word := v.ReshapeToUint64s().GetElem(0)
				for row := 0; row < h; row += 4 {
					at := unsafe.Add(p, row*ds)
					*(*uint64)(at) = word
					*(*uint64)(unsafe.Add(at, ds)) = word
					*(*uint64)(unsafe.Add(at, d2)) = word
					*(*uint64)(unsafe.Add(at, d3)) = word
				}
			case 4:
				word := v.ReshapeToUint32s().GetElem(0)
				for row := 0; row < h; row += 4 {
					at := unsafe.Add(p, row*ds)
					*(*uint32)(at) = word
					*(*uint32)(unsafe.Add(at, ds)) = word
					*(*uint32)(unsafe.Add(at, d2)) = word
					*(*uint32)(unsafe.Add(at, d3)) = word
				}
			}
			return
		}
		switch w {'''
f.write_text(s[:start]+body.replace(needle,new)+s[end:])
for v in ['parent','candidate']:
 f=r/v/'internal/pixel/fill_exact_native_test.go';t=f.read_text().replace('[]int{0,1,2,4,8,16,64,65}','[]int{0,1,2,3,4,7,8,16,63,64,65}');f.write_text(t)
validation=(old/'drivers/validate-final.py').read_text().replace('govpx-arm-fill-exact','govpx-arm-fill-unroll4').replace('govpx-ci-fill-final','govpx-ci-fill-unroll4').replace("['parent','candidate','old691']","['parent','candidate']")
(r/'drivers/validate.py').write_text(validation)
(r/'final-evidence/scope.json').write_text(json.dumps({'baseline':'exactpreviousfrozenFillcandidateon768f2fc2','baseline_production_source_sha256':hashlib.sha256((r/'parent/internal/pixel/kernels_simd.go').read_bytes()).hexdigest(),'candidate_production_source_sha256':hashlib.sha256((r/'candidate/internal/pixel/kernels_simd.go').read_bytes()).hexdigest(),'solechange':'ARMfixed-store4rowunrollifh%4==0;samefullguard;otherhoriginalcurrentloop','old_NEON_factcheck':'old691actualARMfillisONErowperloop,notunrolled','old691_dsp_binary':str(old/'old691-final-dsp.test'),'old691_dsp_binary_sha256':hashlib.sha256((old/'old691-final-dsp.test').read_bytes()).hexdigest()},indent=2)+'\n')
print(r)

//go:build !goexperiment.simd || !arm64 || purego

package encoder

const denseTokenAvailable = false

func denseTokenPrepack(q *[16]int16, out *[16]uint32) bool { return false }

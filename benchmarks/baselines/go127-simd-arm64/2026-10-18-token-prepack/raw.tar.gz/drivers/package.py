from pathlib import Path
import shutil,re,json,hashlib,subprocess
base=Path('/private/tmp/govpx-vp8-dense-token-clz');ready=Path('/private/tmp/govpx-vp8-dense-token-clz-ready');ready.mkdir(exist_ok=True)
overlay=ready/'kernel-only-overlay/internal/vp8/encoder';overlay.mkdir(parents=True,exist_ok=True)
trial=base/'candidate/internal/vp8/encoder'
common=(trial/'token_dense_private.go').read_text()
def func(name,s):
 a=s.index('func '+name+'(');br=s.index('{',a);depth=1;i=br+1
 while depth:
  if s[i]=='{':depth+=1
  elif s[i]=='}':depth-=1
  i+=1
 return s[a:i]+'\n'
(overlay/'token_dense_overlap.go').write_text('package encoder\n\nimport "unsafe"\n\n// Overlap is declined before preloading so aliased input/output retains scalar semantics.\n'+func('denseTokenOverlap',common))
shutil.copyfile(trial/'token_dense_private_arm64.go',overlay/'token_dense_arm64.go')
shutil.copyfile(trial/'token_dense_private_other.go',overlay/'token_dense_other.go')
tests=(trial/'token_dense_private_test.go').read_text();bench=(trial/'token_dense_private_bench_test.go').read_text()
header='''package encoder

import (
 "fmt"
 "testing"
 "unsafe"
 "github.com/thesyncim/govpx/internal/pixel"
 "github.com/thesyncim/govpx/internal/vp8/tables"
)

'''
t=header+func('denseOracleBase',tests)+func('TestDenseTokenPrivatePrepack',tests)
t+=func('denseTokenPrepackScalar',common)+func('denseTokenPrepackScalarStream',common)
t+=func('TestDenseTokenPrivateScalarComponent',tests)+func('TestDenseTokenPrivateStreamReference',tests)
t+='''
func TestDenseTokenPrepackAvailability(t *testing.T) {
 var q [16]int16; q[15]=-2048
 var out [16]uint32; for i:=range out {out[i]=0xdeadbeef};before:=out
 got:=denseTokenPrepack(&q,&out)
 if got!=(denseTokenAvailable&&pixel.Enabled) {t.Fatalf("availability=%v",got)}
 if !got&&out!=before {t.Fatal("unsupported path changed output")}
}
'''
# fmt is used by the original test only through Fatalf, which needs no fmt.
t=t.replace(' "fmt"\n','')
(overlay/'token_dense_test.go').write_text(t)
b='''package encoder

import (
 "testing"
 "github.com/thesyncim/govpx/internal/pixel"
)

var densePrivateSink uint64

'''+func('BenchmarkDenseTokenPrivatePrepack',bench)
(overlay/'token_dense_bench_test.go').write_text(b)
# Trial source deltas only; no binaries/full snapshots in the delivery.
for v in ['parent','candidate','flatten']:
 d=ready/'trials'/v/'internal/vp8/encoder';d.mkdir(parents=True,exist_ok=True)
 for p in (base/v/'internal/vp8/encoder').glob('token_dense_private*.go'):shutil.copyfile(p,d/p.name)
 shutil.copyfile(base/v/'internal/vp8/encoder/probability_tokens.go',d/'probability_tokens.go')
for folder in ['screen','fresh6','flatten-screen']:
 shutil.copytree(base/folder,ready/'raw'/folder,dirs_exist_ok=True)
for pattern in ['*.py','*.log','*.json','codegen*.txt','commands*.txt','*-tests-before-single-invalid-strengthening.go.txt']:
 for p in base.glob(pattern):
  dest=ready/('drivers' if p.suffix=='.py' else 'evidence')/p.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
shutil.copyfile('/private/tmp/govpx-next-evidence/dense-token-root-numeric-proof.json',ready/'evidence/root-independent-numeric-proof.json')
shutil.copyfile(base/'parent-commit.txt',ready/'parent-commit.txt')
env={'hardware':'Apple M4 Max,16cores','os':'macOS26.3.1(a),Darwin25.3.0 arm64','go':'go1.27.2','experiment':'simd','pgo':'off','GOMAXPROCS':'1','GOVPX_REQUIRE_SIMD':'1','build_GOFLAGS':'-p=2','build_wrapper':'/Users/thesyncim/GolandProjects/govpx/scripts/go.sh via project-env','CODEX_PROJECT_CACHE_ROOT':'/private/tmp/codex-projects','GOCACHE':'/private/tmp/codex-projects/99feb44aac13f74a/go-build','project_cache_scope':'git common directory','native_claim_scope':'standalone16-coefficient record-base prepack only; no codec claim','parent':(base/'parent-commit.txt').read_text().strip(),'benchmark_binary_sha256':{v:hashlib.sha256((base/(v+'.test')).read_bytes()).hexdigest() for v in ['parent','candidate','flatten']}}
(ready/'evidence/environment.json').write_text(json.dumps(env,indent=2)+'\n')
orig=(base/'candidate/internal/vp8/encoder/token_dense_private_arm64.go').read_bytes();retained=(overlay/'token_dense_arm64.go').read_bytes();assert orig==retained
(ready/'evidence/kernel-source-identity.json').write_text(json.dumps({'measured_candidate':hashlib.sha256(orig).hexdigest(),'retained_overlay':hashlib.sha256(retained).hexdigest(),'byte_identical':True,'default_probability_tokens_overlay_present':(overlay/'probability_tokens.go').exists()},indent=2)+'\n')
print(ready)

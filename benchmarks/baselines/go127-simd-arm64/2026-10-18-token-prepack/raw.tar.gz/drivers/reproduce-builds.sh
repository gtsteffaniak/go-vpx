#!/bin/sh
set -eu
project_root=${1:-/Users/thesyncim/GolandProjects/govpx}
package_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
repro_dir=$(mktemp -d /private/tmp/govpx-clz-reproduce.XXXXXX)
parent_ref=$(cat "$package_dir/parent-commit.txt")
export CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects
export CODEX_AGENT_ID=govpx-clz-reproduce
export GOTOOLCHAIN=local GOEXPERIMENT=simd GOFLAGS=-p=2 GOMAXPROCS=1
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go
for variant in parent candidate flatten retention; do
 snapshot="$repro_dir/$variant"
 mkdir -p "$snapshot"
 git -C "$project_root" archive "$parent_ref" | tar -xf - -C "$snapshot"
 if [ "$variant" = retention ]; then
  cp -R "$package_dir/kernel-only-overlay/." "$snapshot/"
 else
  cp -R "$package_dir/trials/$variant/." "$snapshot/"
 fi
 (
  cd "$project_root"
  "$project_root/scripts/go.sh" -C "$snapshot" test -pgo=off -c ./internal/vp8/encoder -o "$repro_dir/$variant.test"
 )
done
printf '%s\n' "$repro_dir"

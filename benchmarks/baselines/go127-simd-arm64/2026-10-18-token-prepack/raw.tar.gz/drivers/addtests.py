from pathlib import Path
base=Path('/private/tmp/govpx-vp8-dense-token-clz')
s='''
func TestDenseTokenPrivatePublicFixtures(t *testing.T){
 for _,name:=range []string{"Dense16","Dense8","Dense16Four","Gappy16","Sparse"}{
  f:=densePrivateFixture(name);var ca,cb InterCoefficientTokenCounts;var ra,rb InterCoefficientTokenRecords;var aa,ab,la,lb [4]TokenContextPlanes
  ra.Reset(4,16);rb.Reset(4,16)
  for repeat:=0;repeat<2;repeat++{ea:=densePrivateFrameRun(&f,&ca,&ra,&aa,&la,true);eb:=densePrivateFrameRun(&f,&cb,&rb,&ab,&lb,false)
  if ea!=eb||ca!=cb||aa!=ab||la!=lb||!reflect.DeepEqual(ra.Records,rb.Records)||!reflect.DeepEqual(ra.RowStartsForMerge(),rb.RowStartsForMerge()){t.Fatal("fixture",name,repeat)}}
 }
}
func TestDenseTokenPrivateScalarComponent(t *testing.T){
 for n:=-32768;n<=32767;n++ {var q [16]int16;for i:=range q {q[i]=int16(n)};var out [16]uint32;for i:=range out {out[i]=0xfedcba98};before:=out;want,valid:=denseOracleBase(int16(n));ok:=denseTokenPrepackScalar(&q,&out);if ok!=valid||!ok&&out!=before {t.Fatal(n)};if ok {for _,v:=range out {if v!=want {t.Fatal(n)}}}}
}
'''
for v in ['parent','candidate']:
 p=base/v/'internal/vp8/encoder/token_dense_private_test.go';p.write_text(p.read_text()+s)

from pathlib import Path
import os,subprocess,sys,json
base=Path('/private/tmp/govpx-vp8-dense-token-clz');logs=base/'flatten-screen';logs.mkdir(exist_ok=True)
env=os.environ.copy();env.update(GOMAXPROCS='1',GOVPX_REQUIRE_SIMD='1')
commands=[]
for rnd,order in enumerate([['parent','flatten'],['flatten','parent'],['flatten','parent'],['parent','flatten']]):
 for variant in order:
  name=f'r{rnd+1}-{variant}'
  cmd=[str(base/(variant+'.test')),'-test.run=^$','-test.bench=^BenchmarkDenseTokenPrivatePublic$','-test.benchtime=100ms','-test.benchmem','-test.count=1','-test.cpu=1'];commands.append({'name':name,'command':cmd})
  with (logs/(name+'.txt')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  if r.returncode:print('FAILED',name,flush=True);sys.exit(r.returncode)
 print('round',rnd+1,'complete',flush=True)
(logs/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print('FLATTEN SCREEN COMPLETE',flush=True)

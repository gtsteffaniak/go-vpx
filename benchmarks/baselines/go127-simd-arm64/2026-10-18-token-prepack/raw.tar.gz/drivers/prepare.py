from pathlib import Path
import re
base=Path('/private/tmp/govpx-vp8-dense-token-clz')
common='''package encoder

import (
 "unsafe"
 "github.com/thesyncim/govpx/internal/vp8/tables"
)

// Ranges are checked before preloading. A legacy scalar iteration may update
// storage aliased by qcoeff; preloading must not change that temporal behavior.
func denseTokenOverlap(a unsafe.Pointer, an uintptr, b unsafe.Pointer, bn uintptr) bool {
 if an == 0 || bn == 0 { return false }
 ap, bp := uintptr(a), uintptr(b)
 if an > ^uintptr(0)-ap || bn > ^uintptr(0)-bp { return true }
 return ap < bp+bn && bp < ap+an
}

func denseTokenDisjoint(counts *coefficientTokenCounts, records *InterCoefficientTokenRecords, q *[16]int16) bool {
 if counts == nil || records == nil || q == nil { return false }
 n := uintptr(cap(records.Records))
 if n > ^uintptr(0)/4 { return false }
 n *= 4
 cp, rp, qp := unsafe.Pointer(counts), unsafe.Pointer(records), unsafe.Pointer(q)
 bp := unsafe.Pointer(unsafe.SliceData(records.Records))
 cn, rn := unsafe.Sizeof(*counts), unsafe.Sizeof(*records)
 return !denseTokenOverlap(qp,32,cp,cn) && !denseTokenOverlap(qp,32,rp,rn) && !denseTokenOverlap(qp,32,bp,n) &&
 !denseTokenOverlap(cp,cn,rp,rn) && !denseTokenOverlap(cp,cn,bp,n) && !denseTokenOverlap(rp,rn,bp,n)
}

// Kept in a separate call so sparse blocks do not carry the descriptor scratch.
func tryDenseTokenBlock(counts *coefficientTokenCounts, records *InterCoefficientTokenRecords, blockType, ctx, skipDC int, q *[16]int16, eob int) bool {
 if !denseTokenDisjoint(counts,records,q) { return false }
 var bases [16]uint32
 if !denseTokenPrepack(q,&bases) { return false }
 band, tokenCtx := skipDC, ctx
 skip := false
 for pos:=skipDC;pos<eob;pos++ {
  value:=bases[tables.DefaultZigZag1D[pos]&15]
  token:=int(value&15)
  counts[blockType&3][band&7][tokenCtx][token]++
  prob:=((blockType*8+band)*3+tokenCtx)*11
  value |= uint32(prob)<<4
  if skip { value |= 1<<28 }
  index:=len(records.Records)
  records.Records=records.Records[:index+1]
  records.Records[index]=CoefficientTokenRecord(value)
  if pos+1<16 { band=int(tables.CoefBandsTable[pos+1]); tokenCtx=int(tables.PrevTokenClass[token]); skip=tokenCtx==0 }
 }
 if eob<16 {
  counts[blockType&3][band&7][tokenCtx][tables.DCTEOBToken]++
  records.appendTokenUnchecked(blockType,band,tokenCtx,tables.DCTEOBToken,0,0,false)
 }
 return true
}

// Same abs/range/LUT work as the original block walker; a strong component
// reference, independent of the vector implementation. No writes on failure.
func denseTokenPrepackScalar(q *[16]int16, out *[16]uint32) bool {
 if q==nil || out==nil || denseTokenOverlap(unsafe.Pointer(q),32,unsafe.Pointer(out),64) { return false }
 for _,c:=range q { v:=int(c); m:=v>>intSignShift; if uint((v^m)-m)>tables.DCTMaxValue { return false } }
 for i,c:=range q { v:=int(c); m:=v>>intSignShift; mag:=(v^m)-m; out[i]=uint32(coeffAbsTokenLUT[mag]) | uint32(mag)<<15 | uint32(m&1)<<27 }
 return true
}
'''
arm='''//go:build goexperiment.simd && arm64 && !purego

package encoder

import (
 "simd/archsimd"
 "unsafe"
 "github.com/thesyncim/govpx/internal/pixel"
)

const denseTokenAvailable = true

func denseTokenPrepack(q *[16]int16, out *[16]uint32) bool {
 if !pixel.Enabled || q==nil || out==nil || denseTokenOverlap(unsafe.Pointer(q),32,unsafe.Pointer(out),64) { return false }
 a,b:=archsimd.LoadInt16x8(q[:8]),archsimd.LoadInt16x8(q[8:])
 ma,mb:=a.Abs().ToBits(),b.Abs().ToBits()
 if ma.Max(mb).ReduceMax()>2048 { return false }
 denseTokenPacket(a,ma,out[:8])
 denseTokenPacket(b,mb,out[8:])
 return true
}

func denseTokenPacket(v archsimd.Int16x8,m archsimd.Uint16x8,out []uint32) {
 large:=archsimd.BroadcastUint16x8(19).Sub(m.Max(archsimd.BroadcastUint16x8(5)).Sub(archsimd.BroadcastUint16x8(3)).LeadingZeros()).Min(archsimd.BroadcastUint16x8(10))
 token:=large.IfElse(m.Greater(archsimd.BroadcastUint16x8(4)),m)
 sign:=v.ToBits().ShiftAllRight(15)
 lo:=m.ExtendLo4ToUint32().ShiftAllLeft(15).Or(sign.ExtendLo4ToUint32().ShiftAllLeft(27)).Or(token.ExtendLo4ToUint32())
 hi:=m.HiToLo().ExtendLo4ToUint32().ShiftAllLeft(15).Or(sign.HiToLo().ExtendLo4ToUint32().ShiftAllLeft(27)).Or(token.HiToLo().ExtendLo4ToUint32())
 lo.Store(out[:4]); hi.Store(out[4:])
}
'''
other='''//go:build !goexperiment.simd || !arm64 || purego

package encoder
const denseTokenAvailable=false
func denseTokenPrepack(q *[16]int16,out *[16]uint32) bool { return false }
'''
for variant in ['parent','candidate']:
 d=base/variant/'internal/vp8/encoder'
 for name,s in [('token_dense_private.go',common),('token_dense_private_arm64.go',arm),('token_dense_private_other.go',other)]: (d/name).write_text(s)
p=base/'candidate/internal/vp8/encoder/probability_tokens.go'
s=p.read_text();start=s.index('func countBlockCoefficientTokensAndRecords(');i=s.index('\n\tband := skipDC',start)
s=s[:i]+'''\n if denseTokenAvailable && eob>=8 && tryDenseTokenBlock(counts,records,blockType,ctx,skipDC,qcoeff,eob) { return nil }
'''+s[i:];p.write_text(s)

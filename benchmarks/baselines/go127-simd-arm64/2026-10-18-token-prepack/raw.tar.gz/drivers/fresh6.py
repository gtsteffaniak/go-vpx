from pathlib import Path
import os,subprocess,sys,json
base=Path('/private/tmp/govpx-vp8-dense-token-clz');logs=base/'fresh6';logs.mkdir(exist_ok=True)
env=os.environ.copy();env.update(GOMAXPROCS='1',GOVPX_REQUIRE_SIMD='1')
commands=[]
patterns=['DenseMixed','DenseSmall','Gappy']
for rnd in range(6):
 order=['ScalarLUTStream','NativeCLZ'] if rnd%2==0 else ['NativeCLZ','ScalarLUTStream']
 for pattern in patterns[rnd%3:]+patterns[:rnd%3]:
  for method in order:
   name=f'r{rnd+1}-{pattern}-{method}'
   cmd=[str(base/'candidate.test'),'-test.run=^$','-test.bench='+f'^BenchmarkDenseTokenPrivatePrepack$/^{pattern}$/^{method}$','-test.benchtime=200ms','-test.benchmem','-test.count=1','-test.cpu=1']
   commands.append({'name':name,'command':cmd})
   with (logs/(name+'.txt')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
   if r.returncode:print('FAILED',name,flush=True);sys.exit(r.returncode)
 print('round',rnd+1,'complete',flush=True)
(logs/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print('FRESH6 COMPLETE',flush=True)

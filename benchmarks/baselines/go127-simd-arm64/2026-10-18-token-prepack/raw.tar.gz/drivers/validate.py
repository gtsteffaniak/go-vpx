from pathlib import Path
import os,subprocess,sys
base=Path('/private/tmp/govpx-vp8-dense-token-clz');root=Path('/Users/thesyncim/GolandProjects/govpx')
env=os.environ.copy();env.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-token-clz',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='1',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go')
commands=[('candidate-short', 'candidate',['test','-pgo=off','-short','./internal/vp8/encoder']),('candidate-race-checkptr2','candidate',['test','-pgo=off','-race','-gcflags=all=-d=checkptr=2','./internal/vp8/encoder','-run','^TestDenseTokenPrivate','-count=1']),('parent-oracle','parent',['test','-pgo=off','./internal/vp8/encoder','-run','^TestDenseTokenPrivate','-count=1']),('candidate-purego','candidate',['test','-pgo=off','-tags=purego','./internal/vp8/encoder','-run','^TestDenseTokenPrivate','-count=1']),('build-candidate','candidate',['test','-pgo=off','-c','./internal/vp8/encoder','-o',str(base/'candidate.test')]),('build-parent','parent',['test','-pgo=off','-c','./internal/vp8/encoder','-o',str(base/'parent.test')])]
with (base/'commands.txt').open('w') as cmds:
 for name,variant,args in commands:
  cmd=[str(root/'scripts/go.sh'),'-C',str(base/variant)]+args
  cmds.write(repr(cmd)+'\n');cmds.flush()
  with (base/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
  print(name,r.returncode,flush=True)
  if r.returncode:sys.exit(r.returncode)

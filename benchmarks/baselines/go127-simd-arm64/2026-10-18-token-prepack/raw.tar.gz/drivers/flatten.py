from pathlib import Path
import shutil
base=Path('/private/tmp/govpx-vp8-dense-token-clz');shutil.copytree(base/'candidate',base/'flatten')
p=base/'flatten/internal/vp8/encoder/probability_tokens.go';s=p.read_text()
needle='''	if denseTokenAvailable && eob >= 8 && tryDenseTokenBlock(counts, records, blockType, ctx, skipDC, qcoeff, eob) {
		return nil
	}'''
assert needle in s
helper=(base/'candidate/internal/vp8/encoder/token_dense_private.go').read_text()
a=helper.index('\tband, tokenCtx := skipDC, ctx',helper.index('func tryDenseTokenBlock'));b=helper.index('\n\treturn true',a)
replay=helper[a:b]
block=''' if denseTokenAvailable && eob>=8 {
  n:=uintptr(cap(records.Records))
  if n<=^uintptr(0)/4 {
   n*=4
   cp,rp,qp:=unsafe.Pointer(counts),unsafe.Pointer(records),unsafe.Pointer(qcoeff)
   bp:=unsafe.Pointer(unsafe.SliceData(records.Records))
   cn,rn:=unsafe.Sizeof(*counts),unsafe.Sizeof(*records)
   if !denseTokenOverlap(qp,32,cp,cn) && !denseTokenOverlap(qp,32,rp,rn) && !denseTokenOverlap(qp,32,bp,n) &&
    !denseTokenOverlap(cp,cn,rp,rn) && !denseTokenOverlap(cp,cn,bp,n) && !denseTokenOverlap(rp,rn,bp,n) {
    var bases [16]uint32
    if denseTokenPrepack(qcoeff,&bases) {
'''+replay+'''
     return nil
    }
   }
  }
 }
'''
s=s.replace(needle,block).replace('import (','import (\n "unsafe"',1);p.write_text(s)
# Improve the existing prepack full-signed test: exactly one potentially-invalid
# lane, preventing another bad lane from masking a rejection bug.
for v in ['parent','candidate','flatten']:
 p=base/v/'internal/vp8/encoder/token_dense_private_test.go';s=p.read_text().replace('int16((n + i*137) & 65535)','int16(i*137)');p.write_text(s)
# Freeze proof of unchanged classifier source.
import hashlib
kernel='internal/vp8/encoder/token_dense_private_arm64.go'
hashes={v:hashlib.sha256((base/v/kernel).read_bytes()).hexdigest()for v in ['parent','candidate','flatten']}
assert len(set(hashes.values()))==1
(base/'kernel-source-sha256.json').write_text(__import__('json').dumps(hashes,indent=2)+'\n')

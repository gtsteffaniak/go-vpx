import re,json,statistics
from pathlib import Path
base=Path('/private/tmp/govpx-vp8-dense-token-clz');groups={};samples=[]
for p in sorted((base/'screen').glob('*.txt')):
 for line in p.read_text().splitlines():
  m=re.match(r'^(Benchmark\S+)\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',line)
  if not m:continue
  bench,it,ns,byt,alloc=m.groups();kind='parent' if p.stem.endswith('-parent') else 'candidate'
  key=kind+'|'+bench;groups.setdefault(key,[]).append(float(ns));samples.append({'log':p.name,'variant':kind,'benchmark':bench,'iterations':int(it),'ns':float(ns),'bytes':int(byt),'allocs':int(alloc)})
assert len(samples)==67,len(samples)
assert all(x['bytes']==0 and x['allocs']==0 for x in samples)
med={k:statistics.median(v) for k,v in groups.items()};ratios={}
for pattern in ['DenseMixed','DenseSmall','Gappy']:
 pref='candidate|BenchmarkDenseTokenPrivatePrepack/'+pattern+'/'
 ratios['prepack/'+pattern]={'stream_ns':med[pref+'ScalarLUTStream'],'native_ns':med[pref+'NativeCLZ'],'atomic_ns':med[pref+'ScalarLUTAtomic'],'stream_over_native':med[pref+'ScalarLUTStream']/med[pref+'NativeCLZ']}
for pattern in ['Dense16','Dense8','Dense16Four','Gappy16','Sparse']:
 suff='|BenchmarkDenseTokenPrivatePublic/'+pattern
 parent=med['parent'+suff];candidate=med['candidate'+suff]
 ratios['public/'+pattern]={'parent_ns':parent,'candidate_ns':candidate,'parent_over_candidate':parent/candidate,'time_change_percent':(candidate/parent-1)*100}
out={'hardware':'Apple M4 Max, 16 cores','go':'go1.27.2 darwin/arm64, GOEXPERIMENT=simd','pgo':'off','component_rounds':3,'public_rounds':4,'benchtime':'80ms','all_67_samples_zero_alloc':True,'ratios':ratios,'samples':samples}
(base/'screen-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(ratios,indent=2))

from pathlib import Path
import os,subprocess,sys
base=Path('/private/tmp/govpx-vp8-dense-token-clz');root=Path('/Users/thesyncim/GolandProjects/govpx')
env=os.environ.copy();env.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-token-clz-flat',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='1',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go')
commands=[('flatten-short','flatten',['test','-pgo=off','-short','./internal/vp8/encoder']),('flatten-race-checkptr2','flatten',['test','-pgo=off','-race','-gcflags=all=-d=checkptr=2','./internal/vp8/encoder','-run','^TestDenseTokenPrivate','-count=1']),('flatten-purego','flatten',['test','-pgo=off','-tags=purego','./internal/vp8/encoder','-run','^TestDenseTokenPrivate','-count=1']),('candidate-strong-invalid','candidate',['test','-pgo=off','./internal/vp8/encoder','-run','^TestDenseTokenPrivate','-count=1']),('build-flatten','flatten',['test','-pgo=off','-c','./internal/vp8/encoder','-o',str(base/'flatten.test')])]
with (base/'commands-flatten.txt').open('w') as cmds:
 for name,v,args in commands:
  cmd=[str(root/'scripts/go.sh'),'-C',str(base/v)]+args;cmds.write(repr(cmd)+'\n');cmds.flush()
  with (base/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
  print(name,r.returncode,flush=True)
  if r.returncode:sys.exit(r.returncode)

from pathlib import Path
import os,subprocess,sys,time,json
base=Path('/private/tmp/govpx-vp8-dense-token-clz');logs=base/'screen';logs.mkdir(exist_ok=True)
env=os.environ.copy();env.update(GOMAXPROCS='1',GOVPX_REQUIRE_SIMD='1')
commands=[]
def run(name,variant,bench):
 cmd=[str(base/(variant+'.test')),'-test.run=^$','-test.bench='+bench,'-test.benchtime=80ms','-test.benchmem','-test.count=1','-test.cpu=1']
 commands.append({'name':name,'variant':variant,'command':cmd})
 with (logs/(name+'.txt')).open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:print('FAILED',name,flush=True);sys.exit(r.returncode)
 print(name,flush=True)
methods=['ScalarLUTStream','NativeCLZ','ScalarLUTAtomic']
for rnd in range(3):
 for pattern in ['DenseMixed','DenseSmall','Gappy']:
  order=methods[rnd:]+methods[:rnd]
  for method in order:run(f'component-r{rnd+1}-{pattern}-{method}','candidate',f'^BenchmarkDenseTokenPrivatePrepack$/^{pattern}$/^{method}$')
for rnd,order in enumerate([['parent','candidate'],['candidate','parent'],['candidate','parent'],['parent','candidate']]):
 for variant in order:run(f'public-r{rnd+1}-{variant}',variant,'^BenchmarkDenseTokenPrivatePublic$')
(logs/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print('SCREEN COMPLETE',flush=True)

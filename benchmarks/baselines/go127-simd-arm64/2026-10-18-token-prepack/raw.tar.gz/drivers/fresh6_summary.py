import re,json,statistics
from pathlib import Path
base=Path('/private/tmp/govpx-vp8-dense-token-clz');g={};samples=[]
for p in sorted((base/'fresh6').glob('*.txt')):
 m=re.search(r'^(Benchmark\S+)\s+(\d+)\s+([\d.]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op',p.read_text(),re.M)
 assert m,p
 bench,it,ns,byt,alloc=m.groups();assert byt=='0'and alloc=='0'
 g.setdefault(bench,[]).append(float(ns));samples.append({'log':p.name,'bench':bench,'ns':float(ns),'iterations':int(it),'B/op':int(byt),'allocs/op':int(alloc)})
r={}
for pattern in ['DenseMixed','DenseSmall','Gappy']:
 pref='BenchmarkDenseTokenPrivatePrepack/'+pattern+'/'
 scalar=g[pref+'ScalarLUTStream'];native=g[pref+'NativeCLZ'];assert len(scalar)==len(native)==6
 r[pattern]={'scalar_ns':statistics.median(scalar),'native_ns':statistics.median(native),'speedup':statistics.median(scalar)/statistics.median(native),'six_pair_ratios':[a/b for a,b in zip(scalar,native)]}
(base/'fresh6-summary.json').write_text(json.dumps({'hardware':'Apple M4 Max 16 cores','go':'Go1.27.2 simd darwin/arm64','pgo':'off','benchtime':'200ms','rounds':6,'all36samples_zero_alloc':True,'results':r,'samples':samples},indent=2)+'\n')
print(json.dumps(r,indent=2))

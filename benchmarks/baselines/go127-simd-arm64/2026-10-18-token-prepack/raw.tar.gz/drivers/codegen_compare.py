#!/usr/bin/python3
import re,sys,json,hashlib
from pathlib import Path

def normalize(path):
 text=Path(path).read_text()
 body=re.search(r'<_github.com/thesyncim/govpx/internal/vp8/encoder.denseTokenPrepack>:\n(.*?)(?=\n[0-9a-f]+ <|\Z)',text,re.S).group(1)
 ins=re.findall(r'^\w+: [a-f0-9]{8}\s+(.+)$',body,re.M)
 out=[]
 for instruction in ins:
  if instruction.startswith('adrp\tx27,'):instruction='adrp\tx27, GLOBAL_PAGE'
  elif instruction.startswith('add\tx27, x27, #'):instruction='add\tx27, x27, GLOBAL_OFFSET'
  else:instruction=re.sub(r'0x[0-9a-f]+ (<[^>]+>)',r'\1',instruction)
  out.append(instruction)
 return out
if __name__=='__main__':
 a,b=normalize(sys.argv[1]),normalize(sys.argv[2])
 print(json.dumps({'equal':a==b,'measured_count':len(a),'retained_count':len(b),'measured_sha256':hashlib.sha256('\n'.join(a).encode()).hexdigest(),'retained_sha256':hashlib.sha256('\n'.join(b).encode()).hexdigest()},indent=2))
 assert a==b

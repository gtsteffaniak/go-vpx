from pathlib import Path
import os,subprocess,sys,shutil,hashlib,json
base=Path('/private/tmp/govpx-vp8-dense-token-clz');ready=Path('/private/tmp/govpx-vp8-dense-token-clz-ready');root=Path('/Users/thesyncim/GolandProjects/govpx')
ret=base/'retention';shutil.copytree(base/'parent',ret)
d=ret/'internal/vp8/encoder'
for p in d.glob('token_dense_private*.go'):p.unlink()
for p in (ready/'kernel-only-overlay/internal/vp8/encoder').glob('*.go'):shutil.copyfile(p,d/p.name)
original=subprocess.check_output(['git','show','c638b7c76eac857affa0780820e86c211cdd84d3:internal/vp8/encoder/probability_tokens.go'],cwd=root)
assert (d/'probability_tokens.go').read_bytes()==original
(ready/'evidence/default-source-identity.json').write_text(json.dumps({'parent':'c638b7c76eac857affa0780820e86c211cdd84d3','path':'internal/vp8/encoder/probability_tokens.go','parent_sha256':hashlib.sha256(original).hexdigest(),'retention_sha256':hashlib.sha256((d/'probability_tokens.go').read_bytes()).hexdigest(),'byte_identical':True},indent=2)+'\n')
env=os.environ.copy();env.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-token-retention',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='1',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go')
cmds=[('retention-native-short',{},['test','-pgo=off','-short','./internal/vp8/encoder']),('retention-race-checkptr2',{},['test','-pgo=off','-race','-gcflags=all=-d=checkptr=2','./internal/vp8/encoder','-run','^TestDenseToken','-count=1']),('retention-purego-short',{},['test','-pgo=off','-tags=purego','-short','./internal/vp8/encoder']),('retention-nosimd',{'GOEXPERIMENT':'nosimd'},['test','-pgo=off','./internal/vp8/encoder','-run','^TestDenseToken','-count=1']),('retention-build',{},['test','-pgo=off','-c','./internal/vp8/encoder','-o',str(base/'retention.test')])]
results=[]
for name,extra,args in cmds:
 cmd=[str(root/'scripts/go.sh'),'-C',str(ret)]+args;e=env.copy();e.update(extra)
 with (ready/'evidence'/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'extra_env':extra,'exit':r.returncode});print(name,r.returncode,flush=True)
 (ready/'evidence/retention-validation.json').write_text(json.dumps(results,indent=2)+'\n')
 if r.returncode:sys.exit(r.returncode)

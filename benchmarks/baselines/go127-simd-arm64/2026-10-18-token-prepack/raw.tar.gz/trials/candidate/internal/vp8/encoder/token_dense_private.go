package encoder

import (
	"github.com/thesyncim/govpx/internal/vp8/tables"
	"unsafe"
)

// Ranges are checked before preloading. A legacy scalar iteration may update
// storage aliased by qcoeff; preloading must not change that temporal behavior.
func denseTokenOverlap(a unsafe.Pointer, an uintptr, b unsafe.Pointer, bn uintptr) bool {
	if an == 0 || bn == 0 {
		return false
	}
	ap, bp := uintptr(a), uintptr(b)
	if an > ^uintptr(0)-ap || bn > ^uintptr(0)-bp {
		return true
	}
	return ap < bp+bn && bp < ap+an
}

func denseTokenDisjoint(counts *coefficientTokenCounts, records *InterCoefficientTokenRecords, q *[16]int16) bool {
	if counts == nil || records == nil || q == nil {
		return false
	}
	n := uintptr(cap(records.Records))
	if n > ^uintptr(0)/4 {
		return false
	}
	n *= 4
	cp, rp, qp := unsafe.Pointer(counts), unsafe.Pointer(records), unsafe.Pointer(q)
	bp := unsafe.Pointer(unsafe.SliceData(records.Records))
	cn, rn := unsafe.Sizeof(*counts), unsafe.Sizeof(*records)
	return !denseTokenOverlap(qp, 32, cp, cn) && !denseTokenOverlap(qp, 32, rp, rn) && !denseTokenOverlap(qp, 32, bp, n) &&
		!denseTokenOverlap(cp, cn, rp, rn) && !denseTokenOverlap(cp, cn, bp, n) && !denseTokenOverlap(rp, rn, bp, n)
}

// Kept in a separate call so sparse blocks do not carry the descriptor scratch.
func tryDenseTokenBlock(counts *coefficientTokenCounts, records *InterCoefficientTokenRecords, blockType, ctx, skipDC int, q *[16]int16, eob int) bool {
	if !denseTokenDisjoint(counts, records, q) {
		return false
	}
	var bases [16]uint32
	if !denseTokenPrepack(q, &bases) {
		return false
	}
	band, tokenCtx := skipDC, ctx
	skip := false
	for pos := skipDC; pos < eob; pos++ {
		value := bases[tables.DefaultZigZag1D[pos]&15]
		token := int(value & 15)
		counts[blockType&3][band&7][tokenCtx][token]++
		prob := ((blockType*8+band)*3 + tokenCtx) * 11
		value |= uint32(prob) << 4
		if skip {
			value |= 1 << 28
		}
		index := len(records.Records)
		records.Records = records.Records[:index+1]
		records.Records[index] = CoefficientTokenRecord(value)
		if pos+1 < 16 {
			band = int(tables.CoefBandsTable[pos+1])
			tokenCtx = int(tables.PrevTokenClass[token])
			skip = tokenCtx == 0
		}
	}
	if eob < 16 {
		counts[blockType&3][band&7][tokenCtx][tables.DCTEOBToken]++
		records.appendTokenUnchecked(blockType, band, tokenCtx, tables.DCTEOBToken, 0, 0, false)
	}
	return true
}

// Same abs/range/LUT work as the original block walker; a strong component
// reference, independent of the vector implementation. No writes on failure.
func denseTokenPrepackScalar(q *[16]int16, out *[16]uint32) bool {
	if q == nil || out == nil || denseTokenOverlap(unsafe.Pointer(q), 32, unsafe.Pointer(out), 64) {
		return false
	}
	for _, c := range q {
		v := int(c)
		m := v >> intSignShift
		if uint((v^m)-m) > tables.DCTMaxValue {
			return false
		}
	}
	for i, c := range q {
		v := int(c)
		m := v >> intSignShift
		mag := (v ^ m) - m
		out[i] = uint32(coeffAbsTokenLUT[mag]) | uint32(mag)<<15 | uint32(m&1)<<27
	}
	return true
}

// Strong one-pass comparison matching the existing walker: a bad later value
// may leave earlier descriptors written. Timed fixtures are all valid/disjoint.
func denseTokenPrepackScalarStream(q *[16]int16, out *[16]uint32) bool {
	if q == nil || out == nil {
		return false
	}
	for i, c := range q {
		v := int(c)
		mask := v >> intSignShift
		mag := (v ^ mask) - mask
		if uint(mag) > tables.DCTMaxValue {
			return false
		}
		out[i] = uint32(coeffAbsTokenLUT[mag]) | uint32(mag)<<15 | uint32(mask&1)<<27
	}
	return true
}

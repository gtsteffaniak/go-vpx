package encoder

import (
	"github.com/thesyncim/govpx/internal/pixel"
	"reflect"
	"testing"
)

var densePrivateSink uint64
var densePrivateRecordsSink []CoefficientTokenRecord

func BenchmarkDenseTokenPrivatePrepack(b *testing.B) {
	for _, pattern := range []string{"DenseMixed", "DenseSmall", "Gappy"} {
		var q [16]int16
		for i := range q {
			switch pattern {
			case "DenseMixed":
				q[i] = []int16{0, 1, -2, 4, -5, 6, -7, 10, -11, 18, -19, 34, -35, 66, -67, 2048}[i]
			case "DenseSmall":
				q[i] = int16(i%9 - 4)
			case "Gappy":
				if i == 15 {
					q[i] = -2048
				}
			}
		}
		var want [16]uint32
		for i, c := range q {
			want[i], _ = denseOracleBase(c)
		}
		for _, kind := range []string{"ScalarLUTAtomic", "ScalarLUTStream", "NativeCLZ"} {
			b.Run(pattern+"/"+kind, func(b *testing.B) {
				if kind == "NativeCLZ" && (!denseTokenAvailable || !pixel.Enabled) {
					b.Skip("ARM SIMD required")
				}
				var out [16]uint32
				b.ReportAllocs()
				if kind == "NativeCLZ" {
					if !denseTokenPrepack(&q, &out) || out != want {
						b.Fatal("prepack oracle")
					}
					for b.Loop() {
						if !denseTokenPrepack(&q, &out) {
							b.Fatal("declined")
						}
					}
				} else if kind == "ScalarLUTStream" {
					if !denseTokenPrepackScalarStream(&q, &out) || out != want {
						b.Fatal("prepack oracle")
					}
					for b.Loop() {
						if !denseTokenPrepackScalarStream(&q, &out) {
							b.Fatal("declined")
						}
					}
				} else {
					if !denseTokenPrepackScalar(&q, &out) || out != want {
						b.Fatal("prepack oracle")
					}
					for b.Loop() {
						if !denseTokenPrepackScalar(&q, &out) {
							b.Fatal("declined")
						}
					}
				}

				if out != want {
					b.Fatal("after oracle")
				}
				for _, v := range out {
					densePrivateSink += uint64(v)
				}
			})
		}
	}
}

type densePrivateFrame struct {
	coeffs [16]MacroblockCoefficients
	four   bool
}

func densePrivateFixture(name string) densePrivateFrame {
	var f densePrivateFrame
	f.four = name == "Dense16Four"
	values := []int16{0, 1, -2, 4, -5, 6, -7, 10, -11, 18, -19, 34, -35, 66, -67, 2048}
	for mb := range f.coeffs {
		q := &f.coeffs[mb]
		for block := range 25 {
			switch name {
			case "Sparse":
				if block == 0 {
					q.QCoeff[block][1] = int16(mb%4 + 1)
				}
				if block == 1 {
					q.QCoeff[block][0] = -int16(mb%3 + 1)
				}
				if block == 16 {
					q.QCoeff[block][0] = int16(mb%5 + 1)
				}
				if block == 24 {
					q.QCoeff[block][0] = -int16(mb%2 + 1)
				}
			case "Gappy16":
				q.QCoeff[block][15] = -2048
			default:
				for i := range 16 {
					q.QCoeff[block][i] = values[(i+block+mb)%16]
				}
			}
			if name == "Dense8" {
				for pos := 8; pos < 16; pos++ {
					q.QCoeff[block][denseScan[pos]] = 0
				}
			}
		}
		setAllMacroblockEOBs(q, f.four)
	}
	return f
}

func densePrivateFrameRun(f *densePrivateFrame, counts *InterCoefficientTokenCounts, records *InterCoefficientTokenRecords, above *[4]TokenContextPlanes, lefts *[4]TokenContextPlanes) error {
	ResetInterCoefficientTokenCounts(counts)
	records.Reset(4, 16)
	clear(above[:])
	clear(lefts[:])
	for row := range 4 {
		records.MarkRowStart(row)
		for col := range 4 {
			err := AccumulateInterMacroblockTokenCountsAndRecords(counts, records, f.four, &above[col], &lefts[row], &f.coeffs[row*4+col])
			if err != nil {
				return err
			}
		}
		records.MarkRowEnd(row)
	}
	return nil
}

func densePrivateFrameOracle(f *densePrivateFrame, counts *InterCoefficientTokenCounts, records *InterCoefficientTokenRecords, above *[4]TokenContextPlanes, lefts *[4]TokenContextPlanes) error {
	ResetInterCoefficientTokenCounts(counts)
	records.Reset(4, 16)
	clear(above[:])
	clear(lefts[:])
	for row := range 4 {
		records.MarkRowStart(row)
		for col := range 4 {
			err := denseOracleMacro(f.four, &above[col], &lefts[row], &f.coeffs[row*4+col], counts, records)
			if err != nil {
				return err
			}
		}
		records.MarkRowEnd(row)
	}
	return nil
}

func BenchmarkDenseTokenPrivatePublic(b *testing.B) {
	for _, name := range []string{"Dense16", "Dense8", "Dense16Four", "Gappy16", "Sparse"} {
		b.Run(name, func(b *testing.B) {
			f := densePrivateFixture(name)
			var wantCounts, counts InterCoefficientTokenCounts
			var wantRecords, records InterCoefficientTokenRecords
			var wantAbove, above, wantLefts, lefts [4]TokenContextPlanes
			wantRecords.Reset(4, 16)
			records.Reset(4, 16)
			if err := densePrivateFrameOracle(&f, &wantCounts, &wantRecords, &wantAbove, &wantLefts); err != nil {
				b.Fatal(err)
			}
			check := func() {
				if counts != wantCounts || above != wantAbove || lefts != wantLefts || !reflect.DeepEqual(records.Records, wantRecords.Records) || !reflect.DeepEqual(records.RowStartsForMerge(), wantRecords.RowStartsForMerge()) {
					b.Fatal("full frame oracle mismatch")
				}
			}
			if err := densePrivateFrameRun(&f, &counts, &records, &above, &lefts); err != nil {
				b.Fatal(err)
			}
			check()
			b.ReportAllocs()
			for b.Loop() {
				if err := densePrivateFrameRun(&f, &counts, &records, &above, &lefts); err != nil {
					b.Fatal(err)
				}
			}
			check()
			densePrivateSink += uint64(len(records.Records)) + uint64(counts[0][0][0][0])
			densePrivateRecordsSink = records.Records
		})
	}
}

package encoder

import (
	"fmt"
	"github.com/thesyncim/govpx/internal/pixel"
	"github.com/thesyncim/govpx/internal/vp8/common"
	"github.com/thesyncim/govpx/internal/vp8/tables"
	"reflect"
	"testing"
	"unsafe"
)

var denseScan = [16]int{0, 1, 4, 8, 5, 2, 3, 6, 9, 12, 13, 10, 7, 11, 14, 15}
var denseBands = [16]int{0, 1, 2, 3, 6, 4, 5, 6, 6, 6, 6, 6, 6, 6, 6, 7}

func denseOracleBase(c int16) (uint32, bool) {
	v := int(c)
	sign := uint32(0)
	if v < 0 {
		v = -v
		sign = 1
	}
	if v > 2048 {
		return 0, false
	}
	token := v
	switch {
	case v <= 4:
	case v <= 6:
		token = 5
	case v <= 10:
		token = 6
	case v <= 18:
		token = 7
	case v <= 34:
		token = 8
	case v <= 66:
		token = 9
	default:
		token = 10
	}
	return uint32(token) | uint32(v)<<15 | sign<<27, true
}

// Independent classifier, literal scan/band tables, sequential count+record
// mutation. It deliberately reads each qcoeff only when the original does.
func denseOracleBlock(counts *coefficientTokenCounts, records *InterCoefficientTokenRecords, bt, ctx, skip int, q *[16]int16, eob int) error {
	if counts == nil || q == nil || uint(bt) >= 4 || uint(ctx) >= 3 || uint(skip) > 1 {
		return ErrInvalidPacketConfig
	}
	emit := func(band, ctx int, value uint32, skipNode bool) {
		counts[bt][band][ctx][value&15]++
		if records != nil {
			value |= uint32(((bt*8+band)*3+ctx)*11) << 4
			if skipNode {
				value |= 1 << 28
			}
			n := len(records.Records)
			records.Records = records.Records[:n+1]
			records.Records[n] = CoefficientTokenRecord(value)
		}
	}
	if eob <= skip {
		emit(skip, ctx, 11, false)
		return nil
	}
	if eob > 16 {
		return ErrInvalidPacketConfig
	}
	band := skip
	skipNode := false
	for pos := skip; pos < eob; pos++ {
		value, ok := denseOracleBase(q[denseScan[pos]])
		if !ok {
			return ErrInvalidPacketConfig
		}
		emit(band, ctx, value, skipNode)
		if pos+1 < 16 {
			band = denseBands[pos+1]
			token := int(value & 15)
			ctx = token
			if ctx > 2 {
				ctx = 2
			}
			skipNode = ctx == 0
		}
	}
	if eob < 16 {
		emit(band, ctx, 11, false)
	}
	return nil
}
func densePanic(fn func() error) (err error, pan string) {
	defer func() {
		if v := recover(); v != nil {
			pan = fmt.Sprint(v)
		}
	}()
	err = fn()
	return
}
func denseSeedCounts() *coefficientTokenCounts {
	c := new(coefficientTokenCounts)
	for a := range c {
		for b := range c[a] {
			for d := range c[a][b] {
				for e := range c[a][b][d] {
					c[a][b][d][e] = (a*37 + b*11 + d*3 + e) % 13
				}
			}
		}
	}
	return c
}
func denseSeedRecords(capacity int) *InterCoefficientTokenRecords {
	r := new(InterCoefficientTokenRecords)
	r.Records = make([]CoefficientTokenRecord, 0, capacity)
	r.Rows = 1
	r.rowStartsInline[0] = 17
	r.rowStartsInline[1] = 29
	for i := range r.Records[:cap(r.Records)] {
		r.Records[:cap(r.Records)][i] = 0xfedcba98
	}
	return r
}
func denseCompareBlock(t *testing.T, q [16]int16, bt, ctx, skip, eob, capacity int, recordsNil bool) {
	t.Helper()
	a, b := denseSeedCounts(), denseSeedCounts()
	ra, rb := denseSeedRecords(capacity), denseSeedRecords(capacity)
	if recordsNil {
		ra = nil
		rb = nil
	}
	qa, qb := q, q
	ea, pa := densePanic(func() error { return denseOracleBlock(a, ra, bt, ctx, skip, &qa, eob) })
	eb, pb := densePanic(func() error { return countBlockCoefficientTokensAndRecords(b, rb, bt, ctx, skip, &qb, eob) })
	if ea != eb || pa != pb || *a != *b {
		t.Fatalf("state/error mismatch bt%d ctx%d skip%d eob%d cap%d: %v/%q vs %v/%q", bt, ctx, skip, eob, capacity, ea, pa, eb, pb)
	}
	if ra != nil {
		if !reflect.DeepEqual(ra.Records, rb.Records) || !reflect.DeepEqual(ra.Records[:cap(ra.Records)], rb.Records[:cap(rb.Records)]) || ra.rowStartsInline != rb.rowStartsInline {
			t.Fatalf("record mismatch eob%d cap%d", eob, capacity)
		}
	}
}
func TestDenseTokenPrivatePrepack(t *testing.T) {
	if !denseTokenAvailable || !pixel.Enabled {
		t.Skip("ARM SIMD required")
	}
	for n := -32768; n <= 32767; n++ {
		var q [16]int16
		for i := range q {
			q[i] = int16(i * 137)
		}
		q[n&15] = int16(n)
		var want [16]uint32
		valid := true
		for i, c := range q {
			v, ok := denseOracleBase(c)
			want[i] = v
			valid = valid && ok
		}
		var got [16]uint32
		for i := range got {
			got[i] = 0xdeadbeef
		}
		before := got
		ok := denseTokenPrepack(&q, &got)
		if ok != valid || ok && got != want || !ok && got != before {
			t.Fatalf("fullsigned n%d valid%v got%v", n, valid, ok)
		}
	}
	// Exhaust every valid magnitude in each physical lane, both signs.
	for n := -2048; n <= 2048; n++ {
		q := [16]int16{}
		for i := range q {
			q[i] = int16(n)
		}
		var out [16]uint32
		if !denseTokenPrepack(&q, &out) {
			t.Fatal(n)
		}
		v, _ := denseOracleBase(int16(n))
		for _, got := range out {
			if got != v {
				t.Fatalf("class n%d %x !=%x", n, got, v)
			}
		}
	}
	var backing [32]uint32
	for i := range backing {
		backing[i] = 0x12345678
	}
	q := (*[16]int16)(unsafe.Pointer(&backing[0]))
	out := (*[16]uint32)(unsafe.Pointer(&backing[0]))
	before := backing
	if denseTokenPrepack(q, out) || backing != before {
		t.Fatal("overlap mutated")
	}
	if denseTokenPrepack(nil, out) || denseTokenPrepack(q, nil) {
		t.Fatal("nil accepted")
	}
}
func TestDenseTokenPrivateBlock(t *testing.T) {
	values := []int16{0, 1, -2, 4, -5, 6, -7, 10, -11, 18, -19, 34, -35, 66, -67, 2048}
	var q [16]int16
	copy(q[:], values)
	for bt := -1; bt <= 4; bt++ {
		for ctx := -1; ctx <= 3; ctx++ {
			for skip := -1; skip <= 2; skip++ {
				for _, eob := range []int{-1, 0, 1, 2, 7, 8, 9, 15, 16, 17} {
					denseCompareBlock(t, q, bt, ctx, skip, eob, 20, false)
				}
			}
		}
	}
	for _, skip := range []int{0, 1} {
		for _, eob := range []int{0, 1, 7, 8, 9, 15, 16} {
			for _, cap := range []int{0, 1, 7, 8, 15, 16, 20} {
				denseCompareBlock(t, q, 2, 1, skip, eob, cap, false)
			}
			denseCompareBlock(t, q, 2, 1, skip, eob, 0, true)
			for pos := range 16 {
				for _, bad := range []int16{2049, -2049, -32768} {
					badq := q
					badq[denseScan[pos]] = bad
					denseCompareBlock(t, badq, 2, 1, skip, eob, 20, false)
				}
			}
		}
	}
}
func TestDenseTokenPrivateAliasing(t *testing.T) {
	for _, which := range []string{"counts", "records"} {
		a, b := denseSeedCounts(), denseSeedCounts()
		ra, rb := denseSeedRecords(32), denseSeedRecords(32)
		var qa, qb *[16]int16
		if which == "counts" {
			qa = (*[16]int16)(unsafe.Pointer(a))
			qb = (*[16]int16)(unsafe.Pointer(b))
		} else {
			qa = (*[16]int16)(unsafe.Pointer(unsafe.SliceData(ra.Records)))
			qb = (*[16]int16)(unsafe.Pointer(unsafe.SliceData(rb.Records)))
		}
		for i := range qa {
			qa[i] = 1
			qb[i] = 1
		}
		if denseTokenDisjoint(b, rb, qb) {
			t.Fatal("alias accepted", which)
		}
		ea, pa := densePanic(func() error { return denseOracleBlock(a, ra, 0, 0, 0, qa, 16) })
		eb, pb := densePanic(func() error { return countBlockCoefficientTokensAndRecords(b, rb, 0, 0, 0, qb, 16) })
		if ea != eb || pa != pb || *a != *b || !reflect.DeepEqual(ra.Records[:cap(ra.Records)], rb.Records[:cap(rb.Records)]) || len(ra.Records) != len(rb.Records) {
			t.Fatal("temporal alias mismatch", which, ea, eb, pa, pb)
		}
	}
	c, r := denseSeedCounts(), denseSeedRecords(32)
	if denseTokenDisjoint(c, r, (*[16]int16)(unsafe.Pointer(r))) {
		t.Fatal("metadata alias accepted")
	}
}

func denseOracleMacro(is4x4 bool, above *TokenContextPlanes, left *TokenContextPlanes, coeffs *MacroblockCoefficients, counts *coefficientTokenCounts, records *InterCoefficientTokenRecords) error {
	if above == nil || left == nil || coeffs == nil || counts == nil {
		return ErrInvalidPacketConfig
	}
	blockType := 0
	skipDC := 0
	if !is4x4 {
		eob := coeffs.BlockEOB(24, 0)
		ctx := int(above.Y2 + left.Y2)
		if ctx >= tables.PrevCoefContexts {
			return ErrInvalidPacketConfig
		}
		if err := denseOracleBlock(counts, records, 1, ctx, 0, &coeffs.QCoeff[24], eob); err != nil {
			return err
		}
		hasCoeffs := uint8(0)
		if eob > 0 {
			hasCoeffs = 1
		}
		above.Y2 = hasCoeffs
		left.Y2 = hasCoeffs

		blockType = 0
		skipDC = 1
	} else {
		blockType = 3
	}

	for block := range 16 {
		eob := coeffs.BlockEOB(block, skipDC)
		a := block & 3
		l := (block & 0x0c) >> 2
		ctx := int(above.Y1[a] + left.Y1[l])
		if ctx >= tables.PrevCoefContexts {
			return ErrInvalidPacketConfig
		}
		if err := denseOracleBlock(counts, records, blockType, ctx, skipDC, &coeffs.QCoeff[block], eob); err != nil {
			return err
		}
		hasCoeffs := uint8(0)
		if eob > skipDC {
			hasCoeffs = 1
		}
		above.Y1[a] = hasCoeffs
		left.Y1[l] = hasCoeffs
	}

	for block := 16; block < 24; block++ {
		eob := coeffs.BlockEOB(block, 0)
		a, l := common.UVTokenContextIndex(block)
		ctx := int(getTokenUVContext(above, a) + getTokenUVContext(left, l))
		if ctx >= tables.PrevCoefContexts {
			return ErrInvalidPacketConfig
		}
		if err := denseOracleBlock(counts, records, 2, ctx, 0, &coeffs.QCoeff[block], eob); err != nil {
			return err
		}
		hasCoeffs := uint8(0)
		if eob > 0 {
			hasCoeffs = 1
		}
		setTokenUVContext(above, a, hasCoeffs)
		setTokenUVContext(left, l, hasCoeffs)
	}
	return nil
}

func TestDenseTokenPrivateMacro(t *testing.T) {
	for _, four := range []bool{false, true} {
		for _, eob := range []int{0, 1, 7, 8, 15, 16} {
			for _, badBlock := range []int{-1, 0, 7, 16, 24} {
				var q MacroblockCoefficients
				for block := range 25 {
					for i := range 16 {
						v := (block*173 + i*311) % 2049
						if i&1 != 0 {
							v = -v
						}
						q.QCoeff[block][i] = int16(v)
					}
					q.SetBlockEOB(block, eob)
				}
				if badBlock >= 0 {
					q.QCoeff[badBlock][denseScan[5]] = -32768
				}
				ca, cb := denseSeedCounts(), denseSeedCounts()
				ra, rb := denseSeedRecords(400), denseSeedRecords(400)
				aa, ab := TokenContextPlanes{Y1: [4]uint8{0, 1, 0, 1}, U: [2]uint8{1, 0}, V: [2]uint8{0, 1}, Y2: 1}, TokenContextPlanes{}
				ab = aa
				la, lb := TokenContextPlanes{}, TokenContextPlanes{}
				ea, pa := densePanic(func() error { return denseOracleMacro(four, &aa, &la, &q, ca, ra) })
				eb, pb := densePanic(func() error { return AccumulateInterMacroblockTokenCountsAndRecords(cb, rb, four, &ab, &lb, &q) })
				if ea != eb || pa != pb || *ca != *cb || aa != ab || la != lb || !reflect.DeepEqual(ra.Records, rb.Records) || !reflect.DeepEqual(ra.Records[:cap(ra.Records)], rb.Records[:cap(rb.Records)]) {
					t.Fatalf("macro four%v eob%d bad%d", four, eob, badBlock)
				}
			}
		}
	}
}

func TestDenseTokenPrivatePublicFixtures(t *testing.T) {
	for _, name := range []string{"Dense16", "Dense8", "Dense16Four", "Gappy16", "Sparse"} {
		f := densePrivateFixture(name)
		var ca, cb InterCoefficientTokenCounts
		var ra, rb InterCoefficientTokenRecords
		var aa, ab, la, lb [4]TokenContextPlanes
		ra.Reset(4, 16)
		rb.Reset(4, 16)
		for repeat := 0; repeat < 2; repeat++ {
			ea := densePrivateFrameOracle(&f, &ca, &ra, &aa, &la)
			eb := densePrivateFrameRun(&f, &cb, &rb, &ab, &lb)
			if ea != eb || ca != cb || aa != ab || la != lb || !reflect.DeepEqual(ra.Records, rb.Records) || !reflect.DeepEqual(ra.RowStartsForMerge(), rb.RowStartsForMerge()) {
				t.Fatal("fixture", name, repeat)
			}
		}
	}
}
func TestDenseTokenPrivateScalarComponent(t *testing.T) {
	for n := -32768; n <= 32767; n++ {
		var q [16]int16
		for i := range q {
			q[i] = int16(n)
		}
		var out [16]uint32
		for i := range out {
			out[i] = 0xfedcba98
		}
		before := out
		want, valid := denseOracleBase(int16(n))
		ok := denseTokenPrepackScalar(&q, &out)
		if ok != valid || !ok && out != before {
			t.Fatal(n)
		}
		if ok {
			for _, v := range out {
				if v != want {
					t.Fatal(n)
				}
			}
		}
	}
}

func TestDenseTokenPrivateStreamReference(t *testing.T) {
	for n := -2048; n <= 2048; n++ {
		var q [16]int16
		for i := range q {
			q[i] = int16(n)
		}
		var out [16]uint32
		if !denseTokenPrepackScalarStream(&q, &out) {
			t.Fatal(n)
		}
		want, _ := denseOracleBase(int16(n))
		for _, v := range out {
			if v != want {
				t.Fatal(n)
			}
		}
	}
}

#!/usr/bin/python3
"""Explicitly rebuild and rerun the rejected native screen; checkout stays unchanged."""
import argparse
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

parser=argparse.ArgumentParser()
parser.add_argument('--repo',required=True,type=Path)
parser.add_argument('--work',required=True,type=Path,help='New private directory')
parser.add_argument('--go',default='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go')
args=parser.parse_args();package=Path(__file__).resolve().parent
args.work.mkdir(parents=True,exist_ok=False)
head=(package/'parent-head.txt').read_text().strip()
for name in ('parent','candidate'):
    snapshot=args.work/name;snapshot.mkdir()
    with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',head],cwd=args.repo))) as archive:archive.extractall(snapshot)
    if name=='candidate':
        rel='internal/pixel/loopfilter_macro_internal_fused_arm64.go'
        shutil.copyfile(package/'sources/candidate'/rel,snapshot/rel)
env=dict(os.environ,GO=args.go,GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',
         CODEX_AGENT_ID='ci-lf-partial-reproduction',CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects')
wrapper=str(args.repo/'scripts/go.sh');commands=[]
def run(cmd,log,runenv=None):
    commands.append(cmd)
    with log.open('w') as output:
        output.write(repr(cmd)+'\n');output.flush()
        subprocess.run(cmd,cwd=args.repo,env=runenv or env,stdout=output,stderr=subprocess.STDOUT,check=True)
for extra,label in (([],'ordinary'),(['-race','-gcflags=all=-d=checkptr=2'],'race-checkptr')):
    run([wrapper,'-C',str(args.work/'candidate'),'test','-pgo=off']+extra+
        ['./internal/pixel','./internal/vp8/dsp','-run','Test.*(MacroInternal|LoopFilter|Fused|RoundedZero)','-count=1'],
        args.work/(label+'.log'))
for name in ('parent','candidate'):
    run([wrapper,'-C',str(args.work/name),'test','-pgo=off','-c','-o',str(args.work/(name+'.test')),
         './internal/vp8/decoder'],args.work/(name+'-build.log'))
timing_env=dict(env,GOMAXPROCS='1')
for name in ('parent','candidate'):
    run([str(args.work/(name+'.test')),'-test.run=^$',
         '-test.bench=^BenchmarkVP8PickerFilterNative$','-test.benchtime=1x','-test.cpu=1','-test.benchmem'],
        args.work/(name+'-fixture1x.log'),timing_env)
for index,order in enumerate((('parent','candidate'),('candidate','parent'),('candidate','parent'),('parent','candidate')),1):
    for name in order:
        run([str(args.work/(name+'.test')),'-test.run=^$',
             '-test.bench=^BenchmarkVP8PickerFilterNative$','-test.benchtime=150ms','-test.cpu=1','-test.benchmem'],
            args.work/('round%d-%s.log'%(index,name)),timing_env)
(args.work/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')

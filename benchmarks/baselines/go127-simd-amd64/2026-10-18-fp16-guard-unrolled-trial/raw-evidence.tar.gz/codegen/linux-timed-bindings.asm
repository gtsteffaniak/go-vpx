
/private/tmp/govpx-fp16-guard-unrolled-trial/validation/pixel-linux.test:	file format elf64-x86-64

Disassembly of section .text:

000000000059d440 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1>:
  59d440: 4c 8d a4 24 40 fe ff ff      	leaq	-0x1c0(%rsp), %r12
  59d448: 4d 3b 66 10                  	cmpq	0x10(%r14), %r12
  59d44c: 0f 86 8c 0b 00 00            	jbe	0x59dfde <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0xb9e>
  59d452: 55                           	pushq	%rbp
  59d453: 48 89 e5                     	movq	%rsp, %rbp
  59d456: 48 81 ec 38 02 00 00         	subq	$0x238, %rsp            # imm = 0x238
  59d45d: 48 89 84 24 48 02 00 00      	movq	%rax, 0x248(%rsp)
  59d465: 48 89 94 24 88 01 00 00      	movq	%rdx, 0x188(%rsp)
  59d46d: 48 8b 42 08                  	movq	0x8(%rdx), %rax
  59d471: 48 8b 5a 10                  	movq	0x10(%rdx), %rbx
  59d475: 48 8b 4a 18                  	movq	0x18(%rdx), %rcx
  59d479: 48 8b 7a 20                  	movq	0x20(%rdx), %rdi
  59d47d: 48 8b 72 28                  	movq	0x28(%rdx), %rsi
  59d481: 4c 8b 42 30                  	movq	0x30(%rdx), %r8
  59d485: 48 8b 52 38                  	movq	0x38(%rdx), %rdx
  59d489: 48 89 94 24 30 02 00 00      	movq	%rdx, 0x230(%rsp)
  59d491: e8 8a 5e fd ff               	callq	0x573320 <github.com/thesyncim/govpx/internal/pixel.fp16GuardProbeMake>
  59d496: 48 8b 1c 24                  	movq	(%rsp), %rbx
  59d49a: 48 8b 7c 24 08               	movq	0x8(%rsp), %rdi
  59d49f: 48 8d 94 24 e8 00 00 00      	leaq	0xe8(%rsp), %rdx
  59d4a7: 49 89 e1                     	movq	%rsp, %r9
  59d4aa: 45 0f 10 31                  	movups	(%r9), %xmm14
  59d4ae: 44 0f 11 32                  	movups	%xmm14, (%rdx)
  59d4b2: 45 0f 10 71 10               	movups	0x10(%r9), %xmm14
  59d4b7: 44 0f 11 72 10               	movups	%xmm14, 0x10(%rdx)
  59d4bc: 45 0f 10 71 20               	movups	0x20(%r9), %xmm14
  59d4c1: 44 0f 11 72 20               	movups	%xmm14, 0x20(%rdx)
  59d4c6: 45 0f 10 71 30               	movups	0x30(%r9), %xmm14
  59d4cb: 44 0f 11 72 30               	movups	%xmm14, 0x30(%rdx)
  59d4d0: 45 0f 10 71 40               	movups	0x40(%r9), %xmm14
  59d4d5: 44 0f 11 72 40               	movups	%xmm14, 0x40(%rdx)
  59d4da: 45 0f 10 71 50               	movups	0x50(%r9), %xmm14
  59d4df: 44 0f 11 72 50               	movups	%xmm14, 0x50(%rdx)
  59d4e4: 45 0f 10 71 60               	movups	0x60(%r9), %xmm14
  59d4e9: 44 0f 11 72 60               	movups	%xmm14, 0x60(%rdx)
  59d4ee: 45 0f 10 71 70               	movups	0x70(%r9), %xmm14
  59d4f3: 44 0f 11 72 70               	movups	%xmm14, 0x70(%rdx)
  59d4f8: 45 0f 10 b1 80 00 00 00      	movups	0x80(%r9), %xmm14
  59d500: 44 0f 11 b2 80 00 00 00      	movups	%xmm14, 0x80(%rdx)
  59d508: 48 85 db                     	testq	%rbx, %rbx
  59d50b: 0f 84 85 00 00 00            	je	0x59d596 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x156>
  59d511: 48 85 ff                     	testq	%rdi, %rdi
  59d514: 75 0c                        	jne	0x59d522 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0xe2>
  59d516: 48 8d 84 24 c8 00 00 00      	leaq	0xc8(%rsp), %rax
  59d51e: 31 c9                        	xorl	%ecx, %ecx
  59d520: eb 3f                        	jmp	0x59d561 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x121>
  59d522: 48 89 bc 24 d8 00 00 00      	movq	%rdi, 0xd8(%rsp)
  59d52a: 48 89 9c 24 80 01 00 00      	movq	%rbx, 0x180(%rsp)
  59d532: 48 8d 84 24 c8 00 00 00      	leaq	0xc8(%rsp), %rax
  59d53a: 48 89 fb                     	movq	%rdi, %rbx
  59d53d: 31 c9                        	xorl	%ecx, %ecx
  59d53f: 48 8d 35 c2 2c 1c 00         	leaq	0x1c2cc2(%rip), %rsi    # 0x760208 <type:*+0x2b650>
  59d546: e8 35 b3 ee ff               	callq	0x488880 <runtime.growslice>
  59d54b: 48 8b bc 24 d8 00 00 00      	movq	0xd8(%rsp), %rdi
  59d553: 49 89 e1                     	movq	%rsp, %r9
  59d556: 48 89 d9                     	movq	%rbx, %rcx
  59d559: 48 8b 9c 24 80 01 00 00      	movq	0x180(%rsp), %rbx
  59d561: 48 89 8c 24 c8 00 00 00      	movq	%rcx, 0xc8(%rsp)
  59d569: 48 89 84 24 e0 00 00 00      	movq	%rax, 0xe0(%rsp)
  59d571: 48 89 f9                     	movq	%rdi, %rcx
  59d574: e8 27 03 ef ff               	callq	0x48d8a0 <runtime.memmove>
  59d579: 48 8d 94 24 e8 00 00 00      	leaq	0xe8(%rsp), %rdx
  59d581: 49 89 e1                     	movq	%rsp, %r9
  59d584: 48 8b 84 24 c8 00 00 00      	movq	0xc8(%rsp), %rax
  59d58c: 48 8b 8c 24 e0 00 00 00      	movq	0xe0(%rsp), %rcx
  59d594: eb 04                        	jmp	0x59d59a <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x15a>
  59d596: 31 c0                        	xorl	%eax, %eax
  59d598: 31 c9                        	xorl	%ecx, %ecx
  59d59a: 48 89 84 24 c8 00 00 00      	movq	%rax, 0xc8(%rsp)
  59d5a2: 48 89 8c 24 e0 00 00 00      	movq	%rcx, 0xe0(%rsp)
  59d5aa: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
  59d5b2: 48 8b 41 18                  	movq	0x18(%rcx), %rax
  59d5b6: 44 0f 10 32                  	movups	(%rdx), %xmm14
  59d5ba: 45 0f 11 31                  	movups	%xmm14, (%r9)
  59d5be: 44 0f 10 72 10               	movups	0x10(%rdx), %xmm14
  59d5c3: 45 0f 11 71 10               	movups	%xmm14, 0x10(%r9)
  59d5c8: 44 0f 10 72 20               	movups	0x20(%rdx), %xmm14
  59d5cd: 45 0f 11 71 20               	movups	%xmm14, 0x20(%r9)
  59d5d2: 44 0f 10 72 30               	movups	0x30(%rdx), %xmm14
  59d5d7: 45 0f 11 71 30               	movups	%xmm14, 0x30(%r9)
  59d5dc: 44 0f 10 72 40               	movups	0x40(%rdx), %xmm14
  59d5e1: 45 0f 11 71 40               	movups	%xmm14, 0x40(%r9)
  59d5e6: 44 0f 10 72 50               	movups	0x50(%rdx), %xmm14
  59d5eb: 45 0f 11 71 50               	movups	%xmm14, 0x50(%r9)
  59d5f0: 44 0f 10 72 60               	movups	0x60(%rdx), %xmm14
  59d5f5: 45 0f 11 71 60               	movups	%xmm14, 0x60(%r9)
  59d5fa: 44 0f 10 72 70               	movups	0x70(%rdx), %xmm14
  59d5ff: 45 0f 11 71 70               	movups	%xmm14, 0x70(%r9)
  59d604: 44 0f 10 b2 80 00 00 00      	movups	0x80(%rdx), %xmm14
  59d60c: 45 0f 11 b1 80 00 00 00      	movups	%xmm14, 0x80(%r9)
  59d614: e8 87 61 fd ff               	callq	0x5737a0 <github.com/thesyncim/govpx/internal/pixel.fp16GuardProbeOracle>
  59d619: 88 84 24 c6 00 00 00         	movb	%al, 0xc6(%rsp)
  59d620: c6 84 24 c7 00 00 00 00      	movb	$0x0, 0xc7(%rsp)
  59d628: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  59d630: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
  59d638: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  59d640: 48 89 9c 24 d8 00 00 00      	movq	%rbx, 0xd8(%rsp)
  59d648: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  59d650: 48 89 8c 24 d0 00 00 00      	movq	%rcx, 0xd0(%rsp)
  59d658: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  59d660: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  59d668: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  59d670: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  59d678: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  59d680: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  59d688: 48 8b 94 24 48 01 00 00      	movq	0x148(%rsp), %rdx
  59d690: 4c 8b a4 24 50 01 00 00      	movq	0x150(%rsp), %r12
  59d698: 4c 8b ac 24 58 01 00 00      	movq	0x158(%rsp), %r13
  59d6a0: 4c 8b bc 24 60 01 00 00      	movq	0x160(%rsp), %r15
  59d6a8: 48 8b 84 24 68 01 00 00      	movq	0x168(%rsp), %rax
  59d6b0: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
  59d6b8: 48 8b 9c 24 88 01 00 00      	movq	0x188(%rsp), %rbx
  59d6c0: 48 8b 5b 18                  	movq	0x18(%rbx), %rbx
  59d6c4: 48 89 14 24                  	movq	%rdx, (%rsp)
  59d6c8: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  59d6cd: 4c 89 6c 24 10               	movq	%r13, 0x10(%rsp)
  59d6d2: 4c 89 7c 24 18               	movq	%r15, 0x18(%rsp)
  59d6d7: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
  59d6dc: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
  59d6e1: 48 89 5c 24 30               	movq	%rbx, 0x30(%rsp)
  59d6e6: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
  59d6ee: 48 8b 9c 24 d8 00 00 00      	movq	0xd8(%rsp), %rbx
  59d6f6: 48 8b 8c 24 d0 00 00 00      	movq	0xd0(%rsp), %rcx
  59d6fe: 66 90                        	nop
  59d700: e8 7b 52 fd ff               	callq	0x572980 <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe>
  59d705: 0f b6 8c 24 c6 00 00 00      	movzbl	0xc6(%rsp), %ecx
  59d70d: 38 c8                        	cmpb	%cl, %al
  59d70f: 74 0b                        	je	0x59d71c <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x2dc>
  59d711: 41 bc 01 00 00 00            	movl	$0x1, %r12d
  59d717: e9 e4 01 00 00               	jmp	0x59d900 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x4c0>
  59d71c: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  59d724: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
  59d72c: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  59d734: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  59d73c: 48 89 8c 24 d8 00 00 00      	movq	%rcx, 0xd8(%rsp)
  59d744: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  59d74c: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  59d754: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  59d75c: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  59d764: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  59d76c: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  59d774: 48 8b 94 24 48 01 00 00      	movq	0x148(%rsp), %rdx
  59d77c: 4c 8b a4 24 50 01 00 00      	movq	0x150(%rsp), %r12
  59d784: 4c 8b ac 24 58 01 00 00      	movq	0x158(%rsp), %r13
  59d78c: 4c 8b bc 24 60 01 00 00      	movq	0x160(%rsp), %r15
  59d794: 4c 89 bc 24 80 01 00 00      	movq	%r15, 0x180(%rsp)
  59d79c: 48 8b 84 24 68 01 00 00      	movq	0x168(%rsp), %rax
  59d7a4: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
  59d7ac: 4c 8b bc 24 88 01 00 00      	movq	0x188(%rsp), %r15
  59d7b4: 4d 8b 7f 18                  	movq	0x18(%r15), %r15
  59d7b8: 48 89 14 24                  	movq	%rdx, (%rsp)
  59d7bc: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  59d7c1: 4c 89 6c 24 10               	movq	%r13, 0x10(%rsp)
  59d7c6: 48 8b 94 24 80 01 00 00      	movq	0x180(%rsp), %rdx
  59d7ce: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  59d7d3: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
  59d7d8: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
  59d7dd: 4c 89 7c 24 30               	movq	%r15, 0x30(%rsp)
  59d7e2: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
  59d7ea: 48 8b 8c 24 d8 00 00 00      	movq	0xd8(%rsp), %rcx
  59d7f2: e8 c9 52 fd ff               	callq	0x572ac0 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe>
  59d7f7: 0f b6 94 24 c6 00 00 00      	movzbl	0xc6(%rsp), %edx
  59d7ff: 90                           	nop
  59d800: 38 d0                        	cmpb	%dl, %al
  59d802: 74 0d                        	je	0x59d811 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x3d1>
  59d804: 89 d1                        	movl	%edx, %ecx
  59d806: 41 bc 01 00 00 00            	movl	$0x1, %r12d
  59d80c: e9 ef 00 00 00               	jmp	0x59d900 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x4c0>
  59d811: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  59d819: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
  59d821: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  59d829: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  59d831: 48 89 8c 24 d8 00 00 00      	movq	%rcx, 0xd8(%rsp)
  59d839: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  59d841: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  59d849: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  59d851: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  59d859: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  59d861: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  59d869: 48 8b 94 24 48 01 00 00      	movq	0x148(%rsp), %rdx
  59d871: 4c 8b a4 24 50 01 00 00      	movq	0x150(%rsp), %r12
  59d879: 4c 8b ac 24 58 01 00 00      	movq	0x158(%rsp), %r13
  59d881: 4c 8b bc 24 60 01 00 00      	movq	0x160(%rsp), %r15
  59d889: 4c 89 bc 24 80 01 00 00      	movq	%r15, 0x180(%rsp)
  59d891: 48 8b 84 24 68 01 00 00      	movq	0x168(%rsp), %rax
  59d899: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
  59d8a1: 4c 8b bc 24 88 01 00 00      	movq	0x188(%rsp), %r15
  59d8a9: 4d 8b 7f 18                  	movq	0x18(%r15), %r15
  59d8ad: 48 89 14 24                  	movq	%rdx, (%rsp)
  59d8b1: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  59d8b6: 4c 89 6c 24 10               	movq	%r13, 0x10(%rsp)
  59d8bb: 48 8b 94 24 80 01 00 00      	movq	0x180(%rsp), %rdx
  59d8c3: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  59d8c8: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
  59d8cd: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
  59d8d2: 4c 89 7c 24 30               	movq	%r15, 0x30(%rsp)
  59d8d7: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
  59d8df: 48 8b 8c 24 d8 00 00 00      	movq	0xd8(%rsp), %rcx
  59d8e7: e8 f4 52 fd ff               	callq	0x572be0 <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe>
  59d8ec: 0f b6 94 24 c6 00 00 00      	movzbl	0xc6(%rsp), %edx
  59d8f4: 38 d0                        	cmpb	%dl, %al
  59d8f6: 41 0f 95 c4                  	setne	%r12b
  59d8fa: 89 d1                        	movl	%edx, %ecx
  59d8fc: 0f 1f 40 00                  	nopl	(%rax)
  59d900: 45 84 e4                     	testb	%r12b, %r12b
  59d903: 74 40                        	je	0x59d945 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x505>
  59d905: 48 8d 15 7c 28 1c 00         	leaq	0x1c287c(%rip), %rdx    # 0x760188 <type:*+0x2b5d0>
  59d90c: 48 89 94 24 20 02 00 00      	movq	%rdx, 0x220(%rsp)
  59d914: 48 8d 15 85 82 02 00         	leaq	0x28285(%rip), %rdx     # 0x5c5ba0 <internal/sync..dict.indirect[interface {},interface {}]+0x150>
  59d91b: 48 89 94 24 28 02 00 00      	movq	%rdx, 0x228(%rsp)
  59d923: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59d92b: 84 00                        	testb	%al, (%rax)
  59d92d: 48 8d 9c 24 20 02 00 00      	leaq	0x220(%rsp), %rbx
  59d935: b9 01 00 00 00               	movl	$0x1, %ecx
  59d93a: 89 cf                        	movl	%ecx, %edi
  59d93c: 0f 1f 40 00                  	nopl	(%rax)
  59d940: e8 3b b5 f5 ff               	callq	0x4f8e80 <testing.(*common).Fatal>
  59d945: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  59d94d: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
  59d955: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  59d95d: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  59d965: 48 89 8c 24 d8 00 00 00      	movq	%rcx, 0xd8(%rsp)
  59d96d: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  59d975: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  59d97d: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  59d985: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  59d98d: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  59d995: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  59d99d: 48 8b 94 24 48 01 00 00      	movq	0x148(%rsp), %rdx
  59d9a5: 4c 8b a4 24 50 01 00 00      	movq	0x150(%rsp), %r12
  59d9ad: 4c 8b ac 24 58 01 00 00      	movq	0x158(%rsp), %r13
  59d9b5: 4c 8b bc 24 60 01 00 00      	movq	0x160(%rsp), %r15
  59d9bd: 4c 89 bc 24 80 01 00 00      	movq	%r15, 0x180(%rsp)
  59d9c5: 48 8b 84 24 68 01 00 00      	movq	0x168(%rsp), %rax
  59d9cd: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
  59d9d5: 4c 8b bc 24 88 01 00 00      	movq	0x188(%rsp), %r15
  59d9dd: 4d 8b 7f 18                  	movq	0x18(%r15), %r15
  59d9e1: 48 89 14 24                  	movq	%rdx, (%rsp)
  59d9e5: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  59d9ea: 4c 89 6c 24 10               	movq	%r13, 0x10(%rsp)
  59d9ef: 48 8b 94 24 80 01 00 00      	movq	0x180(%rsp), %rdx
  59d9f7: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  59d9fc: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
  59da01: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
  59da06: 4c 89 7c 24 30               	movq	%r15, 0x30(%rsp)
  59da0b: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
  59da13: 48 8b 8c 24 d8 00 00 00      	movq	0xd8(%rsp), %rcx
  59da1b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  59da20: e8 fb 82 fc ff               	callq	0x565d20 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>
  59da25: 0f b6 94 24 c6 00 00 00      	movzbl	0xc6(%rsp), %edx
  59da2d: 38 d0                        	cmpb	%dl, %al
  59da2f: 74 44                        	je	0x59da75 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x635>
  59da31: 48 8d 15 50 27 1c 00         	leaq	0x1c2750(%rip), %rdx    # 0x760188 <type:*+0x2b5d0>
  59da38: 48 89 94 24 20 02 00 00      	movq	%rdx, 0x220(%rsp)
  59da40: 48 8d 15 69 81 02 00         	leaq	0x28169(%rip), %rdx     # 0x5c5bb0 <internal/sync..dict.indirect[interface {},interface {}]+0x160>
  59da47: 48 89 94 24 28 02 00 00      	movq	%rdx, 0x228(%rsp)
  59da4f: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59da57: 84 00                        	testb	%al, (%rax)
  59da59: 48 8d 9c 24 20 02 00 00      	leaq	0x220(%rsp), %rbx
  59da61: b9 01 00 00 00               	movl	$0x1, %ecx
  59da66: 89 cf                        	movl	%ecx, %edi
  59da68: e8 13 b4 f5 ff               	callq	0x4f8e80 <testing.(*common).Fatal>
  59da6d: 0f b6 94 24 c6 00 00 00      	movzbl	0xc6(%rsp), %edx
  59da75: 90                           	nop
  59da76: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59da7e: c6 80 52 02 00 00 01         	movb	$0x1, 0x252(%rax)
  59da85: 4c 8b a4 24 30 02 00 00      	movq	0x230(%rsp), %r12
  59da8d: 4d 8b 6c 24 08               	movq	0x8(%r12), %r13
  59da92: 4d 8b 24 24                  	movq	(%r12), %r12
  59da96: 49 83 fd 06                  	cmpq	$0x6, %r13
  59da9a: 75 32                        	jne	0x59dace <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x68e>
  59da9c: 41 81 3c 24 70 61 72 65      	cmpl	$0x65726170, (%r12)     # imm = 0x65726170
  59daa4: 75 0e                        	jne	0x59dab4 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x674>
  59daa6: 66 41 81 7c 24 04 6e 74      	cmpw	$0x746e, 0x4(%r12)      # imm = 0x746E
  59daae: 0f 84 dc 04 00 00            	je	0x59df90 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0xb50>
  59dab4: 41 81 3c 24 73 69 6e 67      	cmpl	$0x676e6973, (%r12)     # imm = 0x676E6973
  59dabc: 75 2c                        	jne	0x59daea <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x6aa>
  59dabe: 66 41 81 7c 24 04 6c 65      	cmpw	$0x656c, 0x4(%r12)      # imm = 0x656C
  59dac6: 0f 84 84 03 00 00            	je	0x59de50 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0xa10>
  59dacc: eb 1c                        	jmp	0x59daea <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x6aa>
  59dace: 49 83 fd 08                  	cmpq	$0x8, %r13
  59dad2: 75 16                        	jne	0x59daea <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x6aa>
  59dad4: 49 bd 75 6e 72 6f 6c 6c 65 64	movabsq	$0x64656c6c6f726e75, %r13 # imm = 0x64656C6C6F726E75
  59dade: 66 90                        	nop
  59dae0: 4d 39 2c 24                  	cmpq	%r13, (%r12)
  59dae4: 0f 84 2c 02 00 00            	je	0x59dd16 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x8d6>
  59daea: 48 8d 15 97 26 1c 00         	leaq	0x1c2697(%rip), %rdx    # 0x760188 <type:*+0x2b5d0>
  59daf1: 48 89 94 24 20 02 00 00      	movq	%rdx, 0x220(%rsp)
  59daf9: 48 8d 15 c0 80 02 00         	leaq	0x280c0(%rip), %rdx     # 0x5c5bc0 <internal/sync..dict.indirect[interface {},interface {}]+0x170>
  59db00: 48 89 94 24 28 02 00 00      	movq	%rdx, 0x228(%rsp)
  59db08: 48 8d 9c 24 20 02 00 00      	leaq	0x220(%rsp), %rbx
  59db10: b9 01 00 00 00               	movl	$0x1, %ecx
  59db15: 89 cf                        	movl	%ecx, %edi
  59db17: e8 64 b3 f5 ff               	callq	0x4f8e80 <testing.(*common).Fatal>
  59db1c: 0f b6 94 24 c7 00 00 00      	movzbl	0xc7(%rsp), %edx
  59db24: 88 15 25 b5 22 00            	movb	%dl, 0x22b525(%rip)     # 0x7c904f <github.com/thesyncim/govpx/internal/pixel.fp16GuardProbeSink>
  59db2a: 0f b6 b4 24 c6 00 00 00      	movzbl	0xc6(%rsp), %esi
  59db32: 40 38 d6                     	cmpb	%dl, %sil
  59db35: 74 07                        	je	0x59db3e <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x6fe>
  59db37: b8 01 00 00 00               	movl	$0x1, %eax
  59db3c: eb 31                        	jmp	0x59db6f <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x72f>
  59db3e: 48 8b 8c 24 f0 00 00 00      	movq	0xf0(%rsp), %rcx
  59db46: 48 8b 94 24 c8 00 00 00      	movq	0xc8(%rsp), %rdx
  59db4e: 48 39 ca                     	cmpq	%rcx, %rdx
  59db51: 74 04                        	je	0x59db57 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x717>
  59db53: 31 c0                        	xorl	%eax, %eax
  59db55: eb 15                        	jmp	0x59db6c <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x72c>
  59db57: 48 8b 84 24 e8 00 00 00      	movq	0xe8(%rsp), %rax
  59db5f: 48 8b 9c 24 e0 00 00 00      	movq	0xe0(%rsp), %rbx
  59db67: e8 f4 50 e6 ff               	callq	0x402c60 <runtime.memequal>
  59db6c: 83 f0 01                     	xorl	$0x1, %eax
  59db6f: 84 c0                        	testb	%al, %al
  59db71: 74 3a                        	je	0x59dbad <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x76d>
  59db73: 48 8d 15 0e 26 1c 00         	leaq	0x1c260e(%rip), %rdx    # 0x760188 <type:*+0x2b5d0>
  59db7a: 48 89 94 24 20 02 00 00      	movq	%rdx, 0x220(%rsp)
  59db82: 48 8d 15 47 80 02 00         	leaq	0x28047(%rip), %rdx     # 0x5c5bd0 <internal/sync..dict.indirect[interface {},interface {}]+0x180>
  59db89: 48 89 94 24 28 02 00 00      	movq	%rdx, 0x228(%rsp)
  59db91: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59db99: 48 8d 9c 24 20 02 00 00      	leaq	0x220(%rsp), %rbx
  59dba1: b9 01 00 00 00               	movl	$0x1, %ecx
  59dba6: 89 cf                        	movl	%ecx, %edi
  59dba8: e8 d3 b2 f5 ff               	callq	0x4f8e80 <testing.(*common).Fatal>
  59dbad: 48 8d 84 24 90 01 00 00      	leaq	0x190(%rsp), %rax
  59dbb5: 48 8d 8c 24 e8 00 00 00      	leaq	0xe8(%rsp), %rcx
  59dbbd: 44 0f 10 31                  	movups	(%rcx), %xmm14
  59dbc1: 44 0f 11 30                  	movups	%xmm14, (%rax)
  59dbc5: 44 0f 10 71 10               	movups	0x10(%rcx), %xmm14
  59dbca: 44 0f 11 70 10               	movups	%xmm14, 0x10(%rax)
  59dbcf: 44 0f 10 71 20               	movups	0x20(%rcx), %xmm14
  59dbd4: 44 0f 11 70 20               	movups	%xmm14, 0x20(%rax)
  59dbd9: 44 0f 10 71 30               	movups	0x30(%rcx), %xmm14
  59dbde: 44 0f 11 70 30               	movups	%xmm14, 0x30(%rax)
  59dbe3: 44 0f 10 71 40               	movups	0x40(%rcx), %xmm14
  59dbe8: 44 0f 11 70 40               	movups	%xmm14, 0x40(%rax)
  59dbed: 44 0f 10 71 50               	movups	0x50(%rcx), %xmm14
  59dbf2: 44 0f 11 70 50               	movups	%xmm14, 0x50(%rax)
  59dbf7: 44 0f 10 71 60               	movups	0x60(%rcx), %xmm14
  59dbfc: 44 0f 11 70 60               	movups	%xmm14, 0x60(%rax)
  59dc01: 44 0f 10 71 70               	movups	0x70(%rcx), %xmm14
  59dc06: 44 0f 11 70 70               	movups	%xmm14, 0x70(%rax)
  59dc0b: 44 0f 10 b1 80 00 00 00      	movups	0x80(%rcx), %xmm14
  59dc13: 44 0f 11 b0 80 00 00 00      	movups	%xmm14, 0x80(%rax)
  59dc1b: 48 81 c4 38 02 00 00         	addq	$0x238, %rsp            # imm = 0x238
  59dc22: 5d                           	popq	%rbp
  59dc23: c3                           	retq
  59dc24: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  59dc2c: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
  59dc34: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  59dc3c: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  59dc44: 48 89 8c 24 d8 00 00 00      	movq	%rcx, 0xd8(%rsp)
  59dc4c: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  59dc54: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  59dc5c: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  59dc64: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  59dc6c: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  59dc74: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  59dc7c: 48 8b 94 24 48 01 00 00      	movq	0x148(%rsp), %rdx
  59dc84: 4c 8b a4 24 50 01 00 00      	movq	0x150(%rsp), %r12
  59dc8c: 4c 8b ac 24 58 01 00 00      	movq	0x158(%rsp), %r13
  59dc94: 4c 8b bc 24 60 01 00 00      	movq	0x160(%rsp), %r15
  59dc9c: 4c 89 bc 24 80 01 00 00      	movq	%r15, 0x180(%rsp)
  59dca4: 48 8b 84 24 68 01 00 00      	movq	0x168(%rsp), %rax
  59dcac: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
  59dcb4: 4c 8b bc 24 88 01 00 00      	movq	0x188(%rsp), %r15
  59dcbc: 4d 8b 7f 18                  	movq	0x18(%r15), %r15
  59dcc0: 48 89 14 24                  	movq	%rdx, (%rsp)
  59dcc4: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  59dcc9: 4c 89 6c 24 10               	movq	%r13, 0x10(%rsp)
  59dcce: 48 8b 94 24 80 01 00 00      	movq	0x180(%rsp), %rdx
  59dcd6: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  59dcdb: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
  59dce0: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
  59dce5: 4c 89 7c 24 30               	movq	%r15, 0x30(%rsp)
  59dcea: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
  59dcf2: 48 8b 8c 24 d8 00 00 00      	movq	0xd8(%rsp), %rcx
  59dcfa: e8 21 80 fc ff               	callq	0x565d20 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>
  59dcff: 88 84 24 c7 00 00 00         	movb	%al, 0xc7(%rsp)
  59dd06: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59dd0e: 0f b6 94 24 c6 00 00 00      	movzbl	0xc6(%rsp), %edx
  59dd16: 4c 8b a0 c0 02 00 00         	movq	0x2c0(%rax), %r12
  59dd1d: 0f 1f 00                     	nopl	(%rax)
  59dd20: 4c 39 a0 b8 02 00 00         	cmpq	%r12, 0x2b8(%rax)
  59dd27: 76 11                        	jbe	0x59dd3a <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x8fa>
  59dd29: 49 ff c4                     	incq	%r12
  59dd2c: 4c 89 a0 c0 02 00 00         	movq	%r12, 0x2c0(%rax)
  59dd33: b9 01 00 00 00               	movl	$0x1, %ecx
  59dd38: eb 17                        	jmp	0x59dd51 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x911>
  59dd3a: e8 c1 0c f5 ff               	callq	0x4eea00 <testing.(*B).loopSlowPath>
  59dd3f: 0f b6 94 24 c6 00 00 00      	movzbl	0xc6(%rsp), %edx
  59dd47: 89 c1                        	movl	%eax, %ecx
  59dd49: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59dd51: 84 c9                        	testb	%cl, %cl
  59dd53: 0f 85 cb fe ff ff            	jne	0x59dc24 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x7e4>
  59dd59: e9 be fd ff ff               	jmp	0x59db1c <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x6dc>
  59dd5e: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  59dd66: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
  59dd6e: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  59dd76: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  59dd7e: 48 89 8c 24 d8 00 00 00      	movq	%rcx, 0xd8(%rsp)
  59dd86: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  59dd8e: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  59dd96: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  59dd9e: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  59dda6: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  59ddae: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  59ddb6: 48 8b 94 24 48 01 00 00      	movq	0x148(%rsp), %rdx
  59ddbe: 4c 8b a4 24 50 01 00 00      	movq	0x150(%rsp), %r12
  59ddc6: 4c 8b ac 24 58 01 00 00      	movq	0x158(%rsp), %r13
  59ddce: 4c 8b bc 24 60 01 00 00      	movq	0x160(%rsp), %r15
  59ddd6: 4c 89 bc 24 80 01 00 00      	movq	%r15, 0x180(%rsp)
  59ddde: 48 8b 84 24 68 01 00 00      	movq	0x168(%rsp), %rax
  59dde6: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
  59ddee: 4c 8b bc 24 88 01 00 00      	movq	0x188(%rsp), %r15
  59ddf6: 4d 8b 7f 18                  	movq	0x18(%r15), %r15
  59ddfa: 48 89 14 24                  	movq	%rdx, (%rsp)
  59ddfe: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  59de03: 4c 89 6c 24 10               	movq	%r13, 0x10(%rsp)
  59de08: 48 8b 94 24 80 01 00 00      	movq	0x180(%rsp), %rdx
  59de10: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  59de15: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
  59de1a: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
  59de1f: 4c 89 7c 24 30               	movq	%r15, 0x30(%rsp)
  59de24: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
  59de2c: 48 8b 8c 24 d8 00 00 00      	movq	0xd8(%rsp), %rcx
  59de34: e8 87 4c fd ff               	callq	0x572ac0 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe>
  59de39: 88 84 24 c7 00 00 00         	movb	%al, 0xc7(%rsp)
  59de40: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59de48: 0f b6 94 24 c6 00 00 00      	movzbl	0xc6(%rsp), %edx
  59de50: 4c 8b a0 c0 02 00 00         	movq	0x2c0(%rax), %r12
  59de57: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
  59de60: 4c 39 a0 b8 02 00 00         	cmpq	%r12, 0x2b8(%rax)
  59de67: 76 11                        	jbe	0x59de7a <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0xa3a>
  59de69: 49 ff c4                     	incq	%r12
  59de6c: 4c 89 a0 c0 02 00 00         	movq	%r12, 0x2c0(%rax)
  59de73: b9 01 00 00 00               	movl	$0x1, %ecx
  59de78: eb 17                        	jmp	0x59de91 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0xa51>
  59de7a: e8 81 0b f5 ff               	callq	0x4eea00 <testing.(*B).loopSlowPath>
  59de7f: 0f b6 94 24 c6 00 00 00      	movzbl	0xc6(%rsp), %edx
  59de87: 89 c1                        	movl	%eax, %ecx
  59de89: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59de91: 84 c9                        	testb	%cl, %cl
  59de93: 0f 85 c5 fe ff ff            	jne	0x59dd5e <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x91e>
  59de99: e9 7e fc ff ff               	jmp	0x59db1c <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x6dc>
  59de9e: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  59dea6: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
  59deae: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  59deb6: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  59debe: 48 89 8c 24 d8 00 00 00      	movq	%rcx, 0xd8(%rsp)
  59dec6: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  59dece: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  59ded6: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  59dede: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  59dee6: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  59deee: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  59def6: 48 8b 94 24 48 01 00 00      	movq	0x148(%rsp), %rdx
  59defe: 4c 8b a4 24 50 01 00 00      	movq	0x150(%rsp), %r12
  59df06: 4c 8b ac 24 58 01 00 00      	movq	0x158(%rsp), %r13
  59df0e: 4c 8b bc 24 60 01 00 00      	movq	0x160(%rsp), %r15
  59df16: 4c 89 bc 24 80 01 00 00      	movq	%r15, 0x180(%rsp)
  59df1e: 48 8b 84 24 68 01 00 00      	movq	0x168(%rsp), %rax
  59df26: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
  59df2e: 4c 8b bc 24 88 01 00 00      	movq	0x188(%rsp), %r15
  59df36: 4d 8b 7f 18                  	movq	0x18(%r15), %r15
  59df3a: 48 89 14 24                  	movq	%rdx, (%rsp)
  59df3e: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  59df43: 4c 89 6c 24 10               	movq	%r13, 0x10(%rsp)
  59df48: 48 8b 94 24 80 01 00 00      	movq	0x180(%rsp), %rdx
  59df50: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  59df55: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
  59df5a: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
  59df5f: 4c 89 7c 24 30               	movq	%r15, 0x30(%rsp)
  59df64: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
  59df6c: 48 8b 8c 24 d8 00 00 00      	movq	0xd8(%rsp), %rcx
  59df74: e8 07 4a fd ff               	callq	0x572980 <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe>
  59df79: 88 84 24 c7 00 00 00         	movb	%al, 0xc7(%rsp)
  59df80: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59df88: 0f b6 94 24 c6 00 00 00      	movzbl	0xc6(%rsp), %edx
  59df90: 4c 8b a0 c0 02 00 00         	movq	0x2c0(%rax), %r12
  59df97: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
  59dfa0: 4c 39 a0 b8 02 00 00         	cmpq	%r12, 0x2b8(%rax)
  59dfa7: 76 11                        	jbe	0x59dfba <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0xb7a>
  59dfa9: 49 ff c4                     	incq	%r12
  59dfac: 4c 89 a0 c0 02 00 00         	movq	%r12, 0x2c0(%rax)
  59dfb3: b9 01 00 00 00               	movl	$0x1, %ecx
  59dfb8: eb 17                        	jmp	0x59dfd1 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0xb91>
  59dfba: e8 41 0a f5 ff               	callq	0x4eea00 <testing.(*B).loopSlowPath>
  59dfbf: 0f b6 94 24 c6 00 00 00      	movzbl	0xc6(%rsp), %edx
  59dfc7: 89 c1                        	movl	%eax, %ecx
  59dfc9: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59dfd1: 84 c9                        	testb	%cl, %cl
  59dfd3: 0f 85 c5 fe ff ff            	jne	0x59de9e <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0xa5e>
  59dfd9: e9 3e fb ff ff               	jmp	0x59db1c <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x6dc>
  59dfde: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
  59dfe3: e8 38 d8 ee ff               	callq	0x48b820 <runtime.morestack.abi0>
  59dfe8: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
  59dfed: e9 4e f4 ff ff               	jmp	0x59d440 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1>
  59dff2: cc                           	int3
  59dff3: cc                           	int3
  59dff4: cc                           	int3
  59dff5: cc                           	int3
  59dff6: cc                           	int3
  59dff7: cc                           	int3
  59dff8: cc                           	int3
  59dff9: cc                           	int3
  59dffa: cc                           	int3
  59dffb: cc                           	int3
  59dffc: cc                           	int3
  59dffd: cc                           	int3
  59dffe: cc                           	int3
  59dfff: cc                           	int3

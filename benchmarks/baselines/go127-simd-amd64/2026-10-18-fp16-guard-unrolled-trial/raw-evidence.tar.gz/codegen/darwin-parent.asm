
/private/tmp/govpx-fp16-guard-unrolled-trial/validation/pixel-ordinary.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

00000000011653a0 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe>:
 11653a0: 55                           	pushq	%rbp
 11653a1: 48 89 e5                     	movq	%rsp, %rbp
 11653a4: 48 83 ec 50                  	subq	$0x50, %rsp
 11653a8: 48 89 84 24 98 00 00 00      	movq	%rax, 0x98(%rsp)
 11653b0: 48 89 bc 24 b0 00 00 00      	movq	%rdi, 0xb0(%rsp)
 11653b8: 4c 89 8c 24 c8 00 00 00      	movq	%r9, 0xc8(%rsp)
 11653c0: 48 8d 0c 24                  	leaq	(%rsp), %rcx
 11653c4: 44 0f 11 39                  	movups	%xmm15, (%rcx)
 11653c8: 44 0f 11 79 10               	movups	%xmm15, 0x10(%rcx)
 11653cd: 44 0f 11 79 20               	movups	%xmm15, 0x20(%rcx)
 11653d2: 44 0f 11 79 30               	movups	%xmm15, 0x30(%rcx)
 11653d7: 44 0f 11 79 40               	movups	%xmm15, 0x40(%rcx)
 11653dc: 48 89 04 24                  	movq	%rax, (%rsp)
 11653e0: 48 8b 8c 24 90 00 00 00      	movq	0x90(%rsp), %rcx
 11653e8: 48 8d 14 09                  	leaq	(%rcx,%rcx), %rdx
 11653ec: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
 11653f1: 48 89 7c 24 10               	movq	%rdi, 0x10(%rsp)
 11653f6: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
 11653fb: 48 8b 5c 24 60               	movq	0x60(%rsp), %rbx
 1165400: 48 89 5c 24 20               	movq	%rbx, 0x20(%rsp)
 1165405: 48 89 54 24 28               	movq	%rdx, 0x28(%rsp)
 116540a: 4d 85 c9                     	testq	%r9, %r9
 116540d: 74 13                        	je	0x1165422 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0x82>
 116540f: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
 1165414: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
 1165419: b8 04 00 00 00               	movl	$0x4, %eax
 116541e: 66 90                        	nop
 1165420: eb 05                        	jmp	0x1165427 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0x87>
 1165422: b8 03 00 00 00               	movl	$0x3, %eax
 1165427: 48 8b 54 24 78               	movq	0x78(%rsp), %rdx
 116542c: 48 85 d2                     	testq	%rdx, %rdx
 116542f: 74 12                        	je	0x1165443 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xa3>
 1165431: 89 c3                        	movl	%eax, %ebx
 1165433: 48 c1 e3 04                  	shlq	$0x4, %rbx
 1165437: 48 89 14 1c                  	movq	%rdx, (%rsp,%rbx)
 116543b: 48 89 4c 1c 08               	movq	%rcx, 0x8(%rsp,%rbx)
 1165440: 48 ff c0                     	incq	%rax
 1165443: 31 c9                        	xorl	%ecx, %ecx
 1165445: eb 04                        	jmp	0x116544b <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xab>
 1165447: 48 8d 4a 01                  	leaq	0x1(%rdx), %rcx
 116544b: 48 39 c8                     	cmpq	%rcx, %rax
 116544e: 7e 58                        	jle	0x11654a8 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0x108>
 1165450: 48 89 ca                     	movq	%rcx, %rdx
 1165453: 48 c1 e1 04                  	shlq	$0x4, %rcx
 1165457: 31 db                        	xorl	%ebx, %ebx
 1165459: eb 05                        	jmp	0x1165460 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xc0>
 116545b: 48 8d 5f 01                  	leaq	0x1(%rdi), %rbx
 116545f: 90                           	nop
 1165460: 48 39 d3                     	cmpq	%rdx, %rbx
 1165463: 7d e2                        	jge	0x1165447 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xa7>
 1165465: 48 83 fa 05                  	cmpq	$0x5, %rdx
 1165469: 73 50                        	jae	0x11654bb <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0x11b>
 116546b: 48 8b 34 0c                  	movq	(%rsp,%rcx), %rsi
 116546f: 48 89 df                     	movq	%rbx, %rdi
 1165472: 48 c1 e3 04                  	shlq	$0x4, %rbx
 1165476: 4c 8b 04 1c                  	movq	(%rsp,%rbx), %r8
 116547a: 4c 39 c6                     	cmpq	%r8, %rsi
 116547d: 77 17                        	ja	0x1165496 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xf6>
 116547f: 4c 8b 4c 0c 08               	movq	0x8(%rsp,%rcx), %r9
 1165484: 4d 89 c2                     	movq	%r8, %r10
 1165487: 49 29 f0                     	subq	%rsi, %r8
 116548a: 4d 39 c1                     	cmpq	%r8, %r9
 116548d: 77 24                        	ja	0x11654b3 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0x113>
 116548f: 4c 39 d6                     	cmpq	%r10, %rsi
 1165492: 77 05                        	ja	0x1165499 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xf9>
 1165494: eb c5                        	jmp	0x116545b <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xbb>
 1165496: 4d 89 c2                     	movq	%r8, %r10
 1165499: 48 8b 5c 1c 08               	movq	0x8(%rsp,%rbx), %rbx
 116549e: 4c 29 d6                     	subq	%r10, %rsi
 11654a1: 48 39 f3                     	cmpq	%rsi, %rbx
 11654a4: 76 b5                        	jbe	0x116545b <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xbb>
 11654a6: eb 0b                        	jmp	0x11654b3 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0x113>
 11654a8: b8 01 00 00 00               	movl	$0x1, %eax
 11654ad: 48 83 c4 50                  	addq	$0x50, %rsp
 11654b1: 5d                           	popq	%rbp
 11654b2: c3                           	retq
 11654b3: 31 c0                        	xorl	%eax, %eax
 11654b5: 48 83 c4 50                  	addq	$0x50, %rsp
 11654b9: 5d                           	popq	%rbp
 11654ba: c3                           	retq
 11654bb: 0f 1f 44 00 00               	nopl	(%rax,%rax)
 11654c0: e8 5b 42 f2 ff               	callq	0x1089720 <_runtime.panicBounds>
 11654c5: 90                           	nop
 11654c6: cc                           	int3
 11654c7: cc                           	int3
 11654c8: cc                           	int3
 11654c9: cc                           	int3
 11654ca: cc                           	int3
 11654cb: cc                           	int3
 11654cc: cc                           	int3
 11654cd: cc                           	int3
 11654ce: cc                           	int3
 11654cf: cc                           	int3
 11654d0: cc                           	int3
 11654d1: cc                           	int3
 11654d2: cc                           	int3
 11654d3: cc                           	int3
 11654d4: cc                           	int3
 11654d5: cc                           	int3
 11654d6: cc                           	int3
 11654d7: cc                           	int3
 11654d8: cc                           	int3
 11654d9: cc                           	int3
 11654da: cc                           	int3
 11654db: cc                           	int3
 11654dc: cc                           	int3
 11654dd: cc                           	int3
 11654de: cc                           	int3
 11654df: cc                           	int3


/private/tmp/govpx-fp16-guard-unrolled-trial/validation/pixel-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000565d20 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>:
  565d20: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
  565d25: 48 89 7c 24 58               	movq	%rdi, 0x58(%rsp)
  565d2a: 4c 89 4c 24 70               	movq	%r9, 0x70(%rsp)
  565d2f: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
  565d34: 48 89 ca                     	movq	%rcx, %rdx
  565d37: 48 c1 e1 02                  	shlq	$0x2, %rcx
  565d3b: 48 ff c9                     	decq	%rcx
  565d3e: 48 89 fb                     	movq	%rdi, %rbx
  565d41: 48 29 c7                     	subq	%rax, %rdi
  565d44: 48 8d 34 57                  	leaq	(%rdi,%rdx,2), %rsi
  565d48: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
  565d4c: 48 39 ce                     	cmpq	%rcx, %rsi
  565d4f: 72 2b                        	jb	0x565d7c <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x5c>
  565d51: 48 8b 74 24 08               	movq	0x8(%rsp), %rsi
  565d56: 48 89 f7                     	movq	%rsi, %rdi
  565d59: 48 29 c6                     	subq	%rax, %rsi
  565d5c: 48 8d 34 56                  	leaq	(%rsi,%rdx,2), %rsi
  565d60: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
  565d64: 48 39 ce                     	cmpq	%rcx, %rsi
  565d67: 72 13                        	jb	0x565d7c <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x5c>
  565d69: 48 89 fe                     	movq	%rdi, %rsi
  565d6c: 48 29 df                     	subq	%rbx, %rdi
  565d6f: 48 8d 3c 57                  	leaq	(%rdi,%rdx,2), %rdi
  565d73: 48 8d 7f ff                  	leaq	-0x1(%rdi), %rdi
  565d77: 48 39 cf                     	cmpq	%rcx, %rdi
  565d7a: 73 04                        	jae	0x565d80 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x60>
  565d7c: 31 c0                        	xorl	%eax, %eax
  565d7e: c3                           	retq
  565d7f: 90                           	nop
  565d80: 4d 85 c9                     	testq	%r9, %r9
  565d83: 74 3c                        	je	0x565dc1 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa1>
  565d85: 4c 89 cf                     	movq	%r9, %rdi
  565d88: 4d 89 c8                     	movq	%r9, %r8
  565d8b: 49 29 c1                     	subq	%rax, %r9
  565d8e: 4d 8d 0c 51                  	leaq	(%r9,%rdx,2), %r9
  565d92: 4d 8d 49 ff                  	leaq	-0x1(%r9), %r9
  565d96: 49 39 c9                     	cmpq	%rcx, %r9
  565d99: 72 23                        	jb	0x565dbe <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x9e>
  565d9b: 4d 89 c1                     	movq	%r8, %r9
  565d9e: 49 29 d8                     	subq	%rbx, %r8
  565da1: 4d 8d 04 50                  	leaq	(%r8,%rdx,2), %r8
  565da5: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  565da9: 49 39 c8                     	cmpq	%rcx, %r8
  565dac: 72 10                        	jb	0x565dbe <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x9e>
  565dae: 49 29 f1                     	subq	%rsi, %r9
  565db1: 4d 8d 04 51                  	leaq	(%r9,%rdx,2), %r8
  565db5: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  565db9: 49 39 c8                     	cmpq	%rcx, %r8
  565dbc: 73 06                        	jae	0x565dc4 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa4>
  565dbe: 31 c0                        	xorl	%eax, %eax
  565dc0: c3                           	retq
  565dc1: 4c 89 cf                     	movq	%r9, %rdi
  565dc4: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
  565dc9: 48 85 c9                     	testq	%rcx, %rcx
  565dcc: 74 5c                        	je	0x565e2a <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
  565dce: 4c 8d 04 52                  	leaq	(%rdx,%rdx,2), %r8
  565dd2: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  565dd6: 49 89 c9                     	movq	%rcx, %r9
  565dd9: 48 29 c1                     	subq	%rax, %rcx
  565ddc: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
  565de0: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  565de4: 49 39 c8                     	cmpq	%rcx, %r8
  565de7: 77 26                        	ja	0x565e0f <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xef>
  565de9: 4c 89 c9                     	movq	%r9, %rcx
  565dec: 49 29 d9                     	subq	%rbx, %r9
  565def: 49 8d 1c 11                  	leaq	(%r9,%rdx), %rbx
  565df3: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
  565df7: 49 39 d8                     	cmpq	%rbx, %r8
  565dfa: 77 13                        	ja	0x565e0f <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xef>
  565dfc: 48 89 cb                     	movq	%rcx, %rbx
  565dff: 48 29 f1                     	subq	%rsi, %rcx
  565e02: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
  565e06: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  565e0a: 49 39 c8                     	cmpq	%rcx, %r8
  565e0d: 76 03                        	jbe	0x565e12 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xf2>
  565e0f: 31 c0                        	xorl	%eax, %eax
  565e11: c3                           	retq
  565e12: 48 85 ff                     	testq	%rdi, %rdi
  565e15: 74 13                        	je	0x565e2a <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
  565e17: 48 29 fb                     	subq	%rdi, %rbx
  565e1a: 48 8d 0c 13                  	leaq	(%rbx,%rdx), %rcx
  565e1e: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  565e22: 49 39 c8                     	cmpq	%rcx, %r8
  565e25: 76 03                        	jbe	0x565e2a <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
  565e27: 31 c0                        	xorl	%eax, %eax
  565e29: c3                           	retq
  565e2a: b8 01 00 00 00               	movl	$0x1, %eax
  565e2f: c3                           	retq
  565e30: cc                           	int3
  565e31: cc                           	int3
  565e32: cc                           	int3
  565e33: cc                           	int3
  565e34: cc                           	int3
  565e35: cc                           	int3
  565e36: cc                           	int3
  565e37: cc                           	int3
  565e38: cc                           	int3
  565e39: cc                           	int3
  565e3a: cc                           	int3
  565e3b: cc                           	int3
  565e3c: cc                           	int3
  565e3d: cc                           	int3
  565e3e: cc                           	int3
  565e3f: cc                           	int3

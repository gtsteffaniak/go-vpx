
/private/tmp/govpx-fp16-guard-unrolled-trial/validation/pixel-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000572980 <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe>:
  572980: 55                           	pushq	%rbp
  572981: 48 89 e5                     	movq	%rsp, %rbp
  572984: 48 83 ec 50                  	subq	$0x50, %rsp
  572988: 48 89 84 24 98 00 00 00      	movq	%rax, 0x98(%rsp)
  572990: 48 89 bc 24 b0 00 00 00      	movq	%rdi, 0xb0(%rsp)
  572998: 4c 89 8c 24 c8 00 00 00      	movq	%r9, 0xc8(%rsp)
  5729a0: 48 8d 0c 24                  	leaq	(%rsp), %rcx
  5729a4: 44 0f 11 39                  	movups	%xmm15, (%rcx)
  5729a8: 44 0f 11 79 10               	movups	%xmm15, 0x10(%rcx)
  5729ad: 44 0f 11 79 20               	movups	%xmm15, 0x20(%rcx)
  5729b2: 44 0f 11 79 30               	movups	%xmm15, 0x30(%rcx)
  5729b7: 44 0f 11 79 40               	movups	%xmm15, 0x40(%rcx)
  5729bc: 48 89 04 24                  	movq	%rax, (%rsp)
  5729c0: 48 8b 8c 24 90 00 00 00      	movq	0x90(%rsp), %rcx
  5729c8: 48 8d 14 09                  	leaq	(%rcx,%rcx), %rdx
  5729cc: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
  5729d1: 48 89 7c 24 10               	movq	%rdi, 0x10(%rsp)
  5729d6: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  5729db: 48 8b 5c 24 60               	movq	0x60(%rsp), %rbx
  5729e0: 48 89 5c 24 20               	movq	%rbx, 0x20(%rsp)
  5729e5: 48 89 54 24 28               	movq	%rdx, 0x28(%rsp)
  5729ea: 4d 85 c9                     	testq	%r9, %r9
  5729ed: 74 13                        	je	0x572a02 <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0x82>
  5729ef: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
  5729f4: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
  5729f9: b8 04 00 00 00               	movl	$0x4, %eax
  5729fe: 66 90                        	nop
  572a00: eb 05                        	jmp	0x572a07 <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0x87>
  572a02: b8 03 00 00 00               	movl	$0x3, %eax
  572a07: 48 8b 54 24 78               	movq	0x78(%rsp), %rdx
  572a0c: 48 85 d2                     	testq	%rdx, %rdx
  572a0f: 74 12                        	je	0x572a23 <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xa3>
  572a11: 89 c3                        	movl	%eax, %ebx
  572a13: 48 c1 e3 04                  	shlq	$0x4, %rbx
  572a17: 48 89 14 1c                  	movq	%rdx, (%rsp,%rbx)
  572a1b: 48 89 4c 1c 08               	movq	%rcx, 0x8(%rsp,%rbx)
  572a20: 48 ff c0                     	incq	%rax
  572a23: 31 c9                        	xorl	%ecx, %ecx
  572a25: eb 04                        	jmp	0x572a2b <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xab>
  572a27: 48 8d 4a 01                  	leaq	0x1(%rdx), %rcx
  572a2b: 48 39 c8                     	cmpq	%rcx, %rax
  572a2e: 7e 58                        	jle	0x572a88 <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0x108>
  572a30: 48 89 ca                     	movq	%rcx, %rdx
  572a33: 48 c1 e1 04                  	shlq	$0x4, %rcx
  572a37: 31 db                        	xorl	%ebx, %ebx
  572a39: eb 05                        	jmp	0x572a40 <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xc0>
  572a3b: 48 8d 5f 01                  	leaq	0x1(%rdi), %rbx
  572a3f: 90                           	nop
  572a40: 48 39 d3                     	cmpq	%rdx, %rbx
  572a43: 7d e2                        	jge	0x572a27 <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xa7>
  572a45: 48 83 fa 05                  	cmpq	$0x5, %rdx
  572a49: 73 50                        	jae	0x572a9b <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0x11b>
  572a4b: 48 8b 34 0c                  	movq	(%rsp,%rcx), %rsi
  572a4f: 48 89 df                     	movq	%rbx, %rdi
  572a52: 48 c1 e3 04                  	shlq	$0x4, %rbx
  572a56: 4c 8b 04 1c                  	movq	(%rsp,%rbx), %r8
  572a5a: 4c 39 c6                     	cmpq	%r8, %rsi
  572a5d: 77 17                        	ja	0x572a76 <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xf6>
  572a5f: 4c 8b 4c 0c 08               	movq	0x8(%rsp,%rcx), %r9
  572a64: 4d 89 c2                     	movq	%r8, %r10
  572a67: 49 29 f0                     	subq	%rsi, %r8
  572a6a: 4d 39 c1                     	cmpq	%r8, %r9
  572a6d: 77 24                        	ja	0x572a93 <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0x113>
  572a6f: 4c 39 d6                     	cmpq	%r10, %rsi
  572a72: 77 05                        	ja	0x572a79 <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xf9>
  572a74: eb c5                        	jmp	0x572a3b <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xbb>
  572a76: 4d 89 c2                     	movq	%r8, %r10
  572a79: 48 8b 5c 1c 08               	movq	0x8(%rsp,%rbx), %rbx
  572a7e: 4c 29 d6                     	subq	%r10, %rsi
  572a81: 48 39 f3                     	cmpq	%rsi, %rbx
  572a84: 76 b5                        	jbe	0x572a3b <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0xbb>
  572a86: eb 0b                        	jmp	0x572a93 <github.com/thesyncim/govpx/internal/pixel.fp16GuardParentProbe+0x113>
  572a88: b8 01 00 00 00               	movl	$0x1, %eax
  572a8d: 48 83 c4 50                  	addq	$0x50, %rsp
  572a91: 5d                           	popq	%rbp
  572a92: c3                           	retq
  572a93: 31 c0                        	xorl	%eax, %eax
  572a95: 48 83 c4 50                  	addq	$0x50, %rsp
  572a99: 5d                           	popq	%rbp
  572a9a: c3                           	retq
  572a9b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  572aa0: e8 5b aa f1 ff               	callq	0x48d500 <runtime.panicBounds>
  572aa5: 90                           	nop
  572aa6: cc                           	int3
  572aa7: cc                           	int3
  572aa8: cc                           	int3
  572aa9: cc                           	int3
  572aaa: cc                           	int3
  572aab: cc                           	int3
  572aac: cc                           	int3
  572aad: cc                           	int3
  572aae: cc                           	int3
  572aaf: cc                           	int3
  572ab0: cc                           	int3
  572ab1: cc                           	int3
  572ab2: cc                           	int3
  572ab3: cc                           	int3
  572ab4: cc                           	int3
  572ab5: cc                           	int3
  572ab6: cc                           	int3
  572ab7: cc                           	int3
  572ab8: cc                           	int3
  572ab9: cc                           	int3
  572aba: cc                           	int3
  572abb: cc                           	int3
  572abc: cc                           	int3
  572abd: cc                           	int3
  572abe: cc                           	int3
  572abf: cc                           	int3

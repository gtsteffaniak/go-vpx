
/private/tmp/govpx-fp16-guard-unrolled-trial/validation/pixel-ordinary.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

0000000001165600 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe>:
 1165600: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
 1165605: 48 89 7c 24 58               	movq	%rdi, 0x58(%rsp)
 116560a: 4c 89 4c 24 70               	movq	%r9, 0x70(%rsp)
 116560f: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
 1165614: 48 89 ca                     	movq	%rcx, %rdx
 1165617: 48 c1 e1 02                  	shlq	$0x2, %rcx
 116561b: 48 ff c9                     	decq	%rcx
 116561e: 48 89 fb                     	movq	%rdi, %rbx
 1165621: 48 29 c7                     	subq	%rax, %rdi
 1165624: 48 8d 34 57                  	leaq	(%rdi,%rdx,2), %rsi
 1165628: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
 116562c: 48 39 ce                     	cmpq	%rcx, %rsi
 116562f: 72 2b                        	jb	0x116565c <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x5c>
 1165631: 48 8b 74 24 08               	movq	0x8(%rsp), %rsi
 1165636: 48 89 f7                     	movq	%rsi, %rdi
 1165639: 48 29 c6                     	subq	%rax, %rsi
 116563c: 48 8d 34 56                  	leaq	(%rsi,%rdx,2), %rsi
 1165640: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
 1165644: 48 39 ce                     	cmpq	%rcx, %rsi
 1165647: 72 13                        	jb	0x116565c <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x5c>
 1165649: 48 89 fe                     	movq	%rdi, %rsi
 116564c: 48 29 df                     	subq	%rbx, %rdi
 116564f: 48 8d 3c 57                  	leaq	(%rdi,%rdx,2), %rdi
 1165653: 48 8d 7f ff                  	leaq	-0x1(%rdi), %rdi
 1165657: 48 39 cf                     	cmpq	%rcx, %rdi
 116565a: 73 04                        	jae	0x1165660 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x60>
 116565c: 31 c0                        	xorl	%eax, %eax
 116565e: c3                           	retq
 116565f: 90                           	nop
 1165660: 4d 85 c9                     	testq	%r9, %r9
 1165663: 74 3c                        	je	0x11656a1 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xa1>
 1165665: 4c 89 cf                     	movq	%r9, %rdi
 1165668: 4d 89 c8                     	movq	%r9, %r8
 116566b: 49 29 c1                     	subq	%rax, %r9
 116566e: 4d 8d 0c 51                  	leaq	(%r9,%rdx,2), %r9
 1165672: 4d 8d 49 ff                  	leaq	-0x1(%r9), %r9
 1165676: 49 39 c9                     	cmpq	%rcx, %r9
 1165679: 72 23                        	jb	0x116569e <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x9e>
 116567b: 4d 89 c1                     	movq	%r8, %r9
 116567e: 49 29 d8                     	subq	%rbx, %r8
 1165681: 4d 8d 04 50                  	leaq	(%r8,%rdx,2), %r8
 1165685: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
 1165689: 49 39 c8                     	cmpq	%rcx, %r8
 116568c: 72 10                        	jb	0x116569e <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x9e>
 116568e: 49 29 f1                     	subq	%rsi, %r9
 1165691: 4d 8d 04 51                  	leaq	(%r9,%rdx,2), %r8
 1165695: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
 1165699: 49 39 c8                     	cmpq	%rcx, %r8
 116569c: 73 06                        	jae	0x11656a4 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xa4>
 116569e: 31 c0                        	xorl	%eax, %eax
 11656a0: c3                           	retq
 11656a1: 4c 89 cf                     	movq	%r9, %rdi
 11656a4: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
 11656a9: 48 85 c9                     	testq	%rcx, %rcx
 11656ac: 74 5c                        	je	0x116570a <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x10a>
 11656ae: 4c 8d 04 52                  	leaq	(%rdx,%rdx,2), %r8
 11656b2: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
 11656b6: 49 89 c9                     	movq	%rcx, %r9
 11656b9: 48 29 c1                     	subq	%rax, %rcx
 11656bc: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
 11656c0: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
 11656c4: 49 39 c8                     	cmpq	%rcx, %r8
 11656c7: 77 26                        	ja	0x11656ef <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xef>
 11656c9: 4c 89 c9                     	movq	%r9, %rcx
 11656cc: 49 29 d9                     	subq	%rbx, %r9
 11656cf: 49 8d 1c 11                  	leaq	(%r9,%rdx), %rbx
 11656d3: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
 11656d7: 49 39 d8                     	cmpq	%rbx, %r8
 11656da: 77 13                        	ja	0x11656ef <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xef>
 11656dc: 48 89 cb                     	movq	%rcx, %rbx
 11656df: 48 29 f1                     	subq	%rsi, %rcx
 11656e2: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
 11656e6: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
 11656ea: 49 39 c8                     	cmpq	%rcx, %r8
 11656ed: 76 03                        	jbe	0x11656f2 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xf2>
 11656ef: 31 c0                        	xorl	%eax, %eax
 11656f1: c3                           	retq
 11656f2: 48 85 ff                     	testq	%rdi, %rdi
 11656f5: 74 13                        	je	0x116570a <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x10a>
 11656f7: 48 29 fb                     	subq	%rdi, %rbx
 11656fa: 48 8d 0c 13                  	leaq	(%rbx,%rdx), %rcx
 11656fe: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
 1165702: 49 39 c8                     	cmpq	%rcx, %r8
 1165705: 76 03                        	jbe	0x116570a <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x10a>
 1165707: 31 c0                        	xorl	%eax, %eax
 1165709: c3                           	retq
 116570a: b8 01 00 00 00               	movl	$0x1, %eax
 116570f: c3                           	retq
 1165710: cc                           	int3
 1165711: cc                           	int3
 1165712: cc                           	int3
 1165713: cc                           	int3
 1165714: cc                           	int3
 1165715: cc                           	int3
 1165716: cc                           	int3
 1165717: cc                           	int3
 1165718: cc                           	int3
 1165719: cc                           	int3
 116571a: cc                           	int3
 116571b: cc                           	int3
 116571c: cc                           	int3
 116571d: cc                           	int3
 116571e: cc                           	int3
 116571f: cc                           	int3

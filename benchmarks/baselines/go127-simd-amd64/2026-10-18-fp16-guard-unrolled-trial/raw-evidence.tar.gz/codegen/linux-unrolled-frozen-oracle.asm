
/private/tmp/govpx-fp16-guard-unrolled-trial/validation/pixel-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000572be0 <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe>:
  572be0: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
  572be5: 48 89 7c 24 58               	movq	%rdi, 0x58(%rsp)
  572bea: 4c 89 4c 24 70               	movq	%r9, 0x70(%rsp)
  572bef: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
  572bf4: 48 89 ca                     	movq	%rcx, %rdx
  572bf7: 48 c1 e1 02                  	shlq	$0x2, %rcx
  572bfb: 48 ff c9                     	decq	%rcx
  572bfe: 48 89 fb                     	movq	%rdi, %rbx
  572c01: 48 29 c7                     	subq	%rax, %rdi
  572c04: 48 8d 34 57                  	leaq	(%rdi,%rdx,2), %rsi
  572c08: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
  572c0c: 48 39 ce                     	cmpq	%rcx, %rsi
  572c0f: 72 2b                        	jb	0x572c3c <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x5c>
  572c11: 48 8b 74 24 08               	movq	0x8(%rsp), %rsi
  572c16: 48 89 f7                     	movq	%rsi, %rdi
  572c19: 48 29 c6                     	subq	%rax, %rsi
  572c1c: 48 8d 34 56                  	leaq	(%rsi,%rdx,2), %rsi
  572c20: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
  572c24: 48 39 ce                     	cmpq	%rcx, %rsi
  572c27: 72 13                        	jb	0x572c3c <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x5c>
  572c29: 48 89 fe                     	movq	%rdi, %rsi
  572c2c: 48 29 df                     	subq	%rbx, %rdi
  572c2f: 48 8d 3c 57                  	leaq	(%rdi,%rdx,2), %rdi
  572c33: 48 8d 7f ff                  	leaq	-0x1(%rdi), %rdi
  572c37: 48 39 cf                     	cmpq	%rcx, %rdi
  572c3a: 73 04                        	jae	0x572c40 <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x60>
  572c3c: 31 c0                        	xorl	%eax, %eax
  572c3e: c3                           	retq
  572c3f: 90                           	nop
  572c40: 4d 85 c9                     	testq	%r9, %r9
  572c43: 74 3c                        	je	0x572c81 <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xa1>
  572c45: 4c 89 cf                     	movq	%r9, %rdi
  572c48: 4d 89 c8                     	movq	%r9, %r8
  572c4b: 49 29 c1                     	subq	%rax, %r9
  572c4e: 4d 8d 0c 51                  	leaq	(%r9,%rdx,2), %r9
  572c52: 4d 8d 49 ff                  	leaq	-0x1(%r9), %r9
  572c56: 49 39 c9                     	cmpq	%rcx, %r9
  572c59: 72 23                        	jb	0x572c7e <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x9e>
  572c5b: 4d 89 c1                     	movq	%r8, %r9
  572c5e: 49 29 d8                     	subq	%rbx, %r8
  572c61: 4d 8d 04 50                  	leaq	(%r8,%rdx,2), %r8
  572c65: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  572c69: 49 39 c8                     	cmpq	%rcx, %r8
  572c6c: 72 10                        	jb	0x572c7e <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x9e>
  572c6e: 49 29 f1                     	subq	%rsi, %r9
  572c71: 4d 8d 04 51                  	leaq	(%r9,%rdx,2), %r8
  572c75: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  572c79: 49 39 c8                     	cmpq	%rcx, %r8
  572c7c: 73 06                        	jae	0x572c84 <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xa4>
  572c7e: 31 c0                        	xorl	%eax, %eax
  572c80: c3                           	retq
  572c81: 4c 89 cf                     	movq	%r9, %rdi
  572c84: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
  572c89: 48 85 c9                     	testq	%rcx, %rcx
  572c8c: 74 5c                        	je	0x572cea <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x10a>
  572c8e: 4c 8d 04 52                  	leaq	(%rdx,%rdx,2), %r8
  572c92: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  572c96: 49 89 c9                     	movq	%rcx, %r9
  572c99: 48 29 c1                     	subq	%rax, %rcx
  572c9c: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
  572ca0: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  572ca4: 49 39 c8                     	cmpq	%rcx, %r8
  572ca7: 77 26                        	ja	0x572ccf <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xef>
  572ca9: 4c 89 c9                     	movq	%r9, %rcx
  572cac: 49 29 d9                     	subq	%rbx, %r9
  572caf: 49 8d 1c 11                  	leaq	(%r9,%rdx), %rbx
  572cb3: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
  572cb7: 49 39 d8                     	cmpq	%rbx, %r8
  572cba: 77 13                        	ja	0x572ccf <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xef>
  572cbc: 48 89 cb                     	movq	%rcx, %rbx
  572cbf: 48 29 f1                     	subq	%rsi, %rcx
  572cc2: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
  572cc6: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  572cca: 49 39 c8                     	cmpq	%rcx, %r8
  572ccd: 76 03                        	jbe	0x572cd2 <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xf2>
  572ccf: 31 c0                        	xorl	%eax, %eax
  572cd1: c3                           	retq
  572cd2: 48 85 ff                     	testq	%rdi, %rdi
  572cd5: 74 13                        	je	0x572cea <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x10a>
  572cd7: 48 29 fb                     	subq	%rdi, %rbx
  572cda: 48 8d 0c 13                  	leaq	(%rbx,%rdx), %rcx
  572cde: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  572ce2: 49 39 c8                     	cmpq	%rcx, %r8
  572ce5: 76 03                        	jbe	0x572cea <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x10a>
  572ce7: 31 c0                        	xorl	%eax, %eax
  572ce9: c3                           	retq
  572cea: b8 01 00 00 00               	movl	$0x1, %eax
  572cef: c3                           	retq
  572cf0: cc                           	int3
  572cf1: cc                           	int3
  572cf2: cc                           	int3
  572cf3: cc                           	int3
  572cf4: cc                           	int3
  572cf5: cc                           	int3
  572cf6: cc                           	int3
  572cf7: cc                           	int3
  572cf8: cc                           	int3
  572cf9: cc                           	int3
  572cfa: cc                           	int3
  572cfb: cc                           	int3
  572cfc: cc                           	int3
  572cfd: cc                           	int3
  572cfe: cc                           	int3
  572cff: cc                           	int3

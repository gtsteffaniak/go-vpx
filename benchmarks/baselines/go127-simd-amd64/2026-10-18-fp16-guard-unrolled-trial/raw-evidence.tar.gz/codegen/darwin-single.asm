
/private/tmp/govpx-fp16-guard-unrolled-trial/validation/pixel-ordinary.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

00000000011654e0 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe>:
 11654e0: 55                           	pushq	%rbp
 11654e1: 48 89 e5                     	movq	%rsp, %rbp
 11654e4: 48 83 ec 50                  	subq	$0x50, %rsp
 11654e8: 48 89 84 24 98 00 00 00      	movq	%rax, 0x98(%rsp)
 11654f0: 48 89 bc 24 b0 00 00 00      	movq	%rdi, 0xb0(%rsp)
 11654f8: 4c 89 8c 24 c8 00 00 00      	movq	%r9, 0xc8(%rsp)
 1165500: 48 8d 0c 24                  	leaq	(%rsp), %rcx
 1165504: 44 0f 11 39                  	movups	%xmm15, (%rcx)
 1165508: 44 0f 11 79 10               	movups	%xmm15, 0x10(%rcx)
 116550d: 44 0f 11 79 20               	movups	%xmm15, 0x20(%rcx)
 1165512: 44 0f 11 79 30               	movups	%xmm15, 0x30(%rcx)
 1165517: 44 0f 11 79 40               	movups	%xmm15, 0x40(%rcx)
 116551c: 48 89 04 24                  	movq	%rax, (%rsp)
 1165520: 48 8b 8c 24 90 00 00 00      	movq	0x90(%rsp), %rcx
 1165528: 48 8d 14 09                  	leaq	(%rcx,%rcx), %rdx
 116552c: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
 1165531: 48 89 7c 24 10               	movq	%rdi, 0x10(%rsp)
 1165536: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
 116553b: 48 8b 5c 24 60               	movq	0x60(%rsp), %rbx
 1165540: 48 89 5c 24 20               	movq	%rbx, 0x20(%rsp)
 1165545: 48 89 54 24 28               	movq	%rdx, 0x28(%rsp)
 116554a: 4d 85 c9                     	testq	%r9, %r9
 116554d: 74 13                        	je	0x1165562 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x82>
 116554f: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
 1165554: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
 1165559: b8 04 00 00 00               	movl	$0x4, %eax
 116555e: 66 90                        	nop
 1165560: eb 05                        	jmp	0x1165567 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x87>
 1165562: b8 03 00 00 00               	movl	$0x3, %eax
 1165567: 48 8b 54 24 78               	movq	0x78(%rsp), %rdx
 116556c: 48 85 d2                     	testq	%rdx, %rdx
 116556f: 74 12                        	je	0x1165583 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xa3>
 1165571: 89 c3                        	movl	%eax, %ebx
 1165573: 48 c1 e3 04                  	shlq	$0x4, %rbx
 1165577: 48 89 14 1c                  	movq	%rdx, (%rsp,%rbx)
 116557b: 48 89 4c 1c 08               	movq	%rcx, 0x8(%rsp,%rbx)
 1165580: 48 ff c0                     	incq	%rax
 1165583: 31 c9                        	xorl	%ecx, %ecx
 1165585: eb 04                        	jmp	0x116558b <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xab>
 1165587: 48 8d 4a 01                  	leaq	0x1(%rdx), %rcx
 116558b: 48 39 c8                     	cmpq	%rcx, %rax
 116558e: 7e 4b                        	jle	0x11655db <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xfb>
 1165590: 48 89 ca                     	movq	%rcx, %rdx
 1165593: 48 c1 e1 04                  	shlq	$0x4, %rcx
 1165597: 31 db                        	xorl	%ebx, %ebx
 1165599: eb 05                        	jmp	0x11655a0 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xc0>
 116559b: 49 8d 58 01                  	leaq	0x1(%r8), %rbx
 116559f: 90                           	nop
 11655a0: 48 39 d3                     	cmpq	%rdx, %rbx
 11655a3: 7d e2                        	jge	0x1165587 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xa7>
 11655a5: 48 83 fa 05                  	cmpq	$0x5, %rdx
 11655a9: 73 43                        	jae	0x11655ee <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x10e>
 11655ab: 48 8b 74 0c 08               	movq	0x8(%rsp,%rcx), %rsi
 11655b0: 48 8b 3c 0c                  	movq	(%rsp,%rcx), %rdi
 11655b4: 49 89 d8                     	movq	%rbx, %r8
 11655b7: 48 c1 e3 04                  	shlq	$0x4, %rbx
 11655bb: 4c 8b 4c 1c 08               	movq	0x8(%rsp,%rbx), %r9
 11655c0: 48 2b 3c 1c                  	subq	(%rsp,%rbx), %rdi
 11655c4: 48 8d 1c 37                  	leaq	(%rdi,%rsi), %rbx
 11655c8: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
 11655cc: 4a 8d 34 0e                  	leaq	(%rsi,%r9), %rsi
 11655d0: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
 11655d4: 48 39 de                     	cmpq	%rbx, %rsi
 11655d7: 76 c2                        	jbe	0x116559b <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xbb>
 11655d9: eb 0b                        	jmp	0x11655e6 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x106>
 11655db: b8 01 00 00 00               	movl	$0x1, %eax
 11655e0: 48 83 c4 50                  	addq	$0x50, %rsp
 11655e4: 5d                           	popq	%rbp
 11655e5: c3                           	retq
 11655e6: 31 c0                        	xorl	%eax, %eax
 11655e8: 48 83 c4 50                  	addq	$0x50, %rsp
 11655ec: 5d                           	popq	%rbp
 11655ed: c3                           	retq
 11655ee: e8 2d 41 f2 ff               	callq	0x1089720 <_runtime.panicBounds>
 11655f3: 90                           	nop
 11655f4: cc                           	int3
 11655f5: cc                           	int3
 11655f6: cc                           	int3
 11655f7: cc                           	int3
 11655f8: cc                           	int3
 11655f9: cc                           	int3
 11655fa: cc                           	int3
 11655fb: cc                           	int3
 11655fc: cc                           	int3
 11655fd: cc                           	int3
 11655fe: cc                           	int3
 11655ff: cc                           	int3

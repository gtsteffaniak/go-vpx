
/private/tmp/govpx-fp16-guard-unrolled-trial/validation/pixel-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000572ac0 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe>:
  572ac0: 55                           	pushq	%rbp
  572ac1: 48 89 e5                     	movq	%rsp, %rbp
  572ac4: 48 83 ec 50                  	subq	$0x50, %rsp
  572ac8: 48 89 84 24 98 00 00 00      	movq	%rax, 0x98(%rsp)
  572ad0: 48 89 bc 24 b0 00 00 00      	movq	%rdi, 0xb0(%rsp)
  572ad8: 4c 89 8c 24 c8 00 00 00      	movq	%r9, 0xc8(%rsp)
  572ae0: 48 8d 0c 24                  	leaq	(%rsp), %rcx
  572ae4: 44 0f 11 39                  	movups	%xmm15, (%rcx)
  572ae8: 44 0f 11 79 10               	movups	%xmm15, 0x10(%rcx)
  572aed: 44 0f 11 79 20               	movups	%xmm15, 0x20(%rcx)
  572af2: 44 0f 11 79 30               	movups	%xmm15, 0x30(%rcx)
  572af7: 44 0f 11 79 40               	movups	%xmm15, 0x40(%rcx)
  572afc: 48 89 04 24                  	movq	%rax, (%rsp)
  572b00: 48 8b 8c 24 90 00 00 00      	movq	0x90(%rsp), %rcx
  572b08: 48 8d 14 09                  	leaq	(%rcx,%rcx), %rdx
  572b0c: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
  572b11: 48 89 7c 24 10               	movq	%rdi, 0x10(%rsp)
  572b16: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  572b1b: 48 8b 5c 24 60               	movq	0x60(%rsp), %rbx
  572b20: 48 89 5c 24 20               	movq	%rbx, 0x20(%rsp)
  572b25: 48 89 54 24 28               	movq	%rdx, 0x28(%rsp)
  572b2a: 4d 85 c9                     	testq	%r9, %r9
  572b2d: 74 13                        	je	0x572b42 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x82>
  572b2f: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
  572b34: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
  572b39: b8 04 00 00 00               	movl	$0x4, %eax
  572b3e: 66 90                        	nop
  572b40: eb 05                        	jmp	0x572b47 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x87>
  572b42: b8 03 00 00 00               	movl	$0x3, %eax
  572b47: 48 8b 54 24 78               	movq	0x78(%rsp), %rdx
  572b4c: 48 85 d2                     	testq	%rdx, %rdx
  572b4f: 74 12                        	je	0x572b63 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xa3>
  572b51: 89 c3                        	movl	%eax, %ebx
  572b53: 48 c1 e3 04                  	shlq	$0x4, %rbx
  572b57: 48 89 14 1c                  	movq	%rdx, (%rsp,%rbx)
  572b5b: 48 89 4c 1c 08               	movq	%rcx, 0x8(%rsp,%rbx)
  572b60: 48 ff c0                     	incq	%rax
  572b63: 31 c9                        	xorl	%ecx, %ecx
  572b65: eb 04                        	jmp	0x572b6b <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xab>
  572b67: 48 8d 4a 01                  	leaq	0x1(%rdx), %rcx
  572b6b: 48 39 c8                     	cmpq	%rcx, %rax
  572b6e: 7e 4b                        	jle	0x572bbb <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xfb>
  572b70: 48 89 ca                     	movq	%rcx, %rdx
  572b73: 48 c1 e1 04                  	shlq	$0x4, %rcx
  572b77: 31 db                        	xorl	%ebx, %ebx
  572b79: eb 05                        	jmp	0x572b80 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xc0>
  572b7b: 49 8d 58 01                  	leaq	0x1(%r8), %rbx
  572b7f: 90                           	nop
  572b80: 48 39 d3                     	cmpq	%rdx, %rbx
  572b83: 7d e2                        	jge	0x572b67 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xa7>
  572b85: 48 83 fa 05                  	cmpq	$0x5, %rdx
  572b89: 73 43                        	jae	0x572bce <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x10e>
  572b8b: 48 8b 74 0c 08               	movq	0x8(%rsp,%rcx), %rsi
  572b90: 48 8b 3c 0c                  	movq	(%rsp,%rcx), %rdi
  572b94: 49 89 d8                     	movq	%rbx, %r8
  572b97: 48 c1 e3 04                  	shlq	$0x4, %rbx
  572b9b: 4c 8b 4c 1c 08               	movq	0x8(%rsp,%rbx), %r9
  572ba0: 48 2b 3c 1c                  	subq	(%rsp,%rbx), %rdi
  572ba4: 48 8d 1c 37                  	leaq	(%rdi,%rsi), %rbx
  572ba8: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
  572bac: 4a 8d 34 0e                  	leaq	(%rsi,%r9), %rsi
  572bb0: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
  572bb4: 48 39 de                     	cmpq	%rbx, %rsi
  572bb7: 76 c2                        	jbe	0x572b7b <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xbb>
  572bb9: eb 0b                        	jmp	0x572bc6 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x106>
  572bbb: b8 01 00 00 00               	movl	$0x1, %eax
  572bc0: 48 83 c4 50                  	addq	$0x50, %rsp
  572bc4: 5d                           	popq	%rbp
  572bc5: c3                           	retq
  572bc6: 31 c0                        	xorl	%eax, %eax
  572bc8: 48 83 c4 50                  	addq	$0x50, %rsp
  572bcc: 5d                           	popq	%rbp
  572bcd: c3                           	retq
  572bce: e8 2d a9 f1 ff               	callq	0x48d500 <runtime.panicBounds>
  572bd3: 90                           	nop
  572bd4: cc                           	int3
  572bd5: cc                           	int3
  572bd6: cc                           	int3
  572bd7: cc                           	int3
  572bd8: cc                           	int3
  572bd9: cc                           	int3
  572bda: cc                           	int3
  572bdb: cc                           	int3
  572bdc: cc                           	int3
  572bdd: cc                           	int3
  572bde: cc                           	int3
  572bdf: cc                           	int3

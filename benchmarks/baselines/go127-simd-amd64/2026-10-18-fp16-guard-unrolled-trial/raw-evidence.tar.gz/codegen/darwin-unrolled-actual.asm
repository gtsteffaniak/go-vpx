
/private/tmp/govpx-fp16-guard-unrolled-trial/validation/pixel-ordinary.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

0000000001158740 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>:
 1158740: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
 1158745: 48 89 7c 24 58               	movq	%rdi, 0x58(%rsp)
 115874a: 4c 89 4c 24 70               	movq	%r9, 0x70(%rsp)
 115874f: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
 1158754: 48 89 ca                     	movq	%rcx, %rdx
 1158757: 48 c1 e1 02                  	shlq	$0x2, %rcx
 115875b: 48 ff c9                     	decq	%rcx
 115875e: 48 89 fb                     	movq	%rdi, %rbx
 1158761: 48 29 c7                     	subq	%rax, %rdi
 1158764: 48 8d 34 57                  	leaq	(%rdi,%rdx,2), %rsi
 1158768: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
 115876c: 48 39 ce                     	cmpq	%rcx, %rsi
 115876f: 72 2b                        	jb	0x115879c <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x5c>
 1158771: 48 8b 74 24 08               	movq	0x8(%rsp), %rsi
 1158776: 48 89 f7                     	movq	%rsi, %rdi
 1158779: 48 29 c6                     	subq	%rax, %rsi
 115877c: 48 8d 34 56                  	leaq	(%rsi,%rdx,2), %rsi
 1158780: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
 1158784: 48 39 ce                     	cmpq	%rcx, %rsi
 1158787: 72 13                        	jb	0x115879c <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x5c>
 1158789: 48 89 fe                     	movq	%rdi, %rsi
 115878c: 48 29 df                     	subq	%rbx, %rdi
 115878f: 48 8d 3c 57                  	leaq	(%rdi,%rdx,2), %rdi
 1158793: 48 8d 7f ff                  	leaq	-0x1(%rdi), %rdi
 1158797: 48 39 cf                     	cmpq	%rcx, %rdi
 115879a: 73 04                        	jae	0x11587a0 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x60>
 115879c: 31 c0                        	xorl	%eax, %eax
 115879e: c3                           	retq
 115879f: 90                           	nop
 11587a0: 4d 85 c9                     	testq	%r9, %r9
 11587a3: 74 3c                        	je	0x11587e1 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa1>
 11587a5: 4c 89 cf                     	movq	%r9, %rdi
 11587a8: 4d 89 c8                     	movq	%r9, %r8
 11587ab: 49 29 c1                     	subq	%rax, %r9
 11587ae: 4d 8d 0c 51                  	leaq	(%r9,%rdx,2), %r9
 11587b2: 4d 8d 49 ff                  	leaq	-0x1(%r9), %r9
 11587b6: 49 39 c9                     	cmpq	%rcx, %r9
 11587b9: 72 23                        	jb	0x11587de <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x9e>
 11587bb: 4d 89 c1                     	movq	%r8, %r9
 11587be: 49 29 d8                     	subq	%rbx, %r8
 11587c1: 4d 8d 04 50                  	leaq	(%r8,%rdx,2), %r8
 11587c5: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
 11587c9: 49 39 c8                     	cmpq	%rcx, %r8
 11587cc: 72 10                        	jb	0x11587de <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x9e>
 11587ce: 49 29 f1                     	subq	%rsi, %r9
 11587d1: 4d 8d 04 51                  	leaq	(%r9,%rdx,2), %r8
 11587d5: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
 11587d9: 49 39 c8                     	cmpq	%rcx, %r8
 11587dc: 73 06                        	jae	0x11587e4 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa4>
 11587de: 31 c0                        	xorl	%eax, %eax
 11587e0: c3                           	retq
 11587e1: 4c 89 cf                     	movq	%r9, %rdi
 11587e4: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
 11587e9: 48 85 c9                     	testq	%rcx, %rcx
 11587ec: 74 5c                        	je	0x115884a <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
 11587ee: 4c 8d 04 52                  	leaq	(%rdx,%rdx,2), %r8
 11587f2: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
 11587f6: 49 89 c9                     	movq	%rcx, %r9
 11587f9: 48 29 c1                     	subq	%rax, %rcx
 11587fc: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
 1158800: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
 1158804: 49 39 c8                     	cmpq	%rcx, %r8
 1158807: 77 26                        	ja	0x115882f <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xef>
 1158809: 4c 89 c9                     	movq	%r9, %rcx
 115880c: 49 29 d9                     	subq	%rbx, %r9
 115880f: 49 8d 1c 11                  	leaq	(%r9,%rdx), %rbx
 1158813: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
 1158817: 49 39 d8                     	cmpq	%rbx, %r8
 115881a: 77 13                        	ja	0x115882f <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xef>
 115881c: 48 89 cb                     	movq	%rcx, %rbx
 115881f: 48 29 f1                     	subq	%rsi, %rcx
 1158822: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
 1158826: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
 115882a: 49 39 c8                     	cmpq	%rcx, %r8
 115882d: 76 03                        	jbe	0x1158832 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xf2>
 115882f: 31 c0                        	xorl	%eax, %eax
 1158831: c3                           	retq
 1158832: 48 85 ff                     	testq	%rdi, %rdi
 1158835: 74 13                        	je	0x115884a <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
 1158837: 48 29 fb                     	subq	%rdi, %rbx
 115883a: 48 8d 0c 13                  	leaq	(%rbx,%rdx), %rcx
 115883e: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
 1158842: 49 39 c8                     	cmpq	%rcx, %r8
 1158845: 76 03                        	jbe	0x115884a <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
 1158847: 31 c0                        	xorl	%eax, %eax
 1158849: c3                           	retq
 115884a: b8 01 00 00 00               	movl	$0x1, %eax
 115884f: c3                           	retq
 1158850: cc                           	int3
 1158851: cc                           	int3
 1158852: cc                           	int3
 1158853: cc                           	int3
 1158854: cc                           	int3
 1158855: cc                           	int3
 1158856: cc                           	int3
 1158857: cc                           	int3
 1158858: cc                           	int3
 1158859: cc                           	int3
 115885a: cc                           	int3
 115885b: cc                           	int3
 115885c: cc                           	int3
 115885d: cc                           	int3
 115885e: cc                           	int3
 115885f: cc                           	int3

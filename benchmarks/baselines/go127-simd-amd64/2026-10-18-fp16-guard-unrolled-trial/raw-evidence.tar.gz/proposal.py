import pathlib,subprocess,hashlib,json,difflib,shutil,re
w=pathlib.Path('/private/tmp/govpx-fp16-guard-unrolled-trial');out=w/'overlay';(out/'internal/pixel').mkdir(parents=True,exist_ok=True);(out/'scripts').mkdir(exist_ok=True)
for f in ['quantize_fp_amd64.go','fp16_guard_component_native_test.go']:shutil.copyfile(w/f,out/'internal/pixel'/f)
s=(w/'benchmark-fp16-guard-diagnostic.sh').read_text().replace('sha256sum "$binary" internal/pixel/quantize_fp_amd64.go internal/pixel/fp16_guard_component_native_test.go','sha256sum "$binary" internal/pixel/quantize_fp_amd64.go internal/pixel/fp16_guard_component_native_test.go scripts/benchmark-fp16-guard-diagnostic.sh')
(w/'benchmark-fp16-guard-diagnostic.sh').write_text(s);(out/'scripts/benchmark-fp16-guard-diagnostic.sh').write_text(s)
root=pathlib.Path('/Users/thesyncim/GolandProjects/govpx');old=subprocess.check_output(['git','show','46a08f8e6eb03f6ee4549d975384bd6c952a81fa:scripts/benchmark-amd64.sh'],cwd=root,text=True)
oldhook=pathlib.Path('/private/tmp/govpx-fp16-guard-component-ready/overlay/scripts/benchmark-amd64.sh').read_text();hook=oldhook.replace(old,'') if old in oldhook else None
# Preserve the exact isolated hook from the original32 proposal.
start=oldhook.index('# Diagnostic guard component only,');end=oldhook.index('# Keep artifacts compact;',start);hook=oldhook[start:end]
shaadd='\tsha256sum "$root/internal/pixel/fp16_guard_component_native_test.go"\n\tsha256sum "$root/scripts/benchmark-fp16-guard-diagnostic.sh"\n'
anchor='\tsha256sum "$root/internal/pixel/quantize_fp_amd64.go"\n';assert old.count(anchor)==1
new=old.replace(anchor,anchor+shaadd).replace('# Keep artifacts compact;',hook+'# Keep artifacts compact;')
assert new.replace(hook,'').replace(shaadd,'')==old
(out/'scripts/benchmark-amd64.sh').write_text(new)
for p in (out/'scripts').glob('*.sh'):p.chmod(0o755);subprocess.run(['sh','-n',str(p)],check=True)
paths=re.findall(r'sha256sum "\$root/([^\"]+)"',new);oldpaths=re.findall(r'sha256sum "\$root/([^\"]+)"',old);assert len(set(oldpaths))==77;assert len(set(paths))==79
for p in paths:assert (out/p).exists() or (root/p).exists(),p
scope=dict(base='46a08f8e6eb03f6ee4549d975384bd6c952a81fa',status='UNMEASURED reversible nativeCI productiontrial, not accepted optimization',production_delta_only='internal/pixel/quantize_fp_amd64.go guardbody',vector_public_fallback_prefix_exact=True,ARM_live_body_exact=True,benchmark_bindings={'parent':'fp16GuardParentProbe frozen46 actual83','single':'fp16GuardSingleProbe frozen75','unrolled':'fp16WindowsDisjoint ACTUAL trialproduction88'},frozen_unrolled_helper='oracle-only, matchesactual88',source_SHA_paths={'old_unique':77,'new_unique':79,'additions':['internal/pixel/fp16_guard_component_native_test.go','scripts/benchmark-fp16-guard-diagnostic.sh']},old_common_overlays=31,old_cases_pervariant=498,old_threeway_samples=8964,old_preflight_samples=338,old_rawfiles=91,component_names=66,component_timings=396,component_excluded_one_shots=66,proposed_rawfiles=92,extra_current_only_pixel_binary=1,component_log='fp16-guard-component.txt',timeout_minutes=45,no_native_performance_claim=True,original32_and125_packages_untouched=True,private_exhaustive_validation_overlay_not_proposed='quantize_fp16_offset_guard_probe_test.go')
scope['exact_source_sha256']={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()}
(w/'scope.json').write_text(json.dumps(scope,indent=2));(w/'proposal.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/scripts/benchmark-amd64.sh',tofile='b/scripts/benchmark-amd64.sh')));print(json.dumps(scope,indent=2))

import pathlib,subprocess,re,json,hashlib
w=pathlib.Path('/private/tmp/govpx-fp16-guard-unrolled-trial');cg=w/'codegen';cg.mkdir(exist_ok=True);old=pathlib.Path('/private/tmp/govpx-fp16-offset-guard');summary={}
def dis(binary,symbol,arm=False):
 s=subprocess.check_output(['xcrun','llvm-objdump','-d','--disassemble-symbols='+symbol,str(binary)],text=True);ins=[]
 for l in s.splitlines():
  pat=r'^\s*[0-9a-f]+:\s+[0-9a-f]{8}\s+(.+)$' if arm else r'^\s*[0-9a-f]+:\s+(?:[0-9a-f]{2}\s+)+(.+)$'
  m=re.match(pat,l)
  if m and m.group(1)!='int3':
   i=re.sub(r'0x[0-9a-fA-F]+','ADDR',m.group(1));i=re.sub(r'fp16Guard(Parent|Single|Unrolled)Probe','fp16WindowsDisjoint',i);ins.append(i)
 assert ins,symbol
 return s,ins
for os,suffix,prefix in [('darwin','ordinary','_'),('linux','linux','')]:
 summary[os]={}
 for label,helper,prior in [('parent','fp16GuardParentProbe','parent'),('single','fp16GuardSingleProbe','single-compare'),('unrolled-actual','fp16WindowsDisjoint','unrolled'),('unrolled-frozen-oracle','fp16GuardUnrolledProbe','unrolled')]:
  s,now=dis(w/'validation'/f'pixel-{suffix}.test',prefix+'github.com/thesyncim/govpx/internal/pixel.'+helper);(cg/f'{os}-{label}.asm').write_text(s)
  _,earlier=dis(old/'evidence/validation'/f'{prior}-pixel-{suffix}.test',prefix+'github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint');assert now==earlier,(os,label)
  summary[os][label]={'normalized_body_exact':True,'instructions':len(now)}
 s,loops=dis(w/'validation'/f'pixel-{suffix}.test',prefix+'github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1') if os=='linux' else ('',[])
 if s:(cg/'linux-timed-bindings.asm').write_text(s)
# Prefix proves all vector arithmetic/store/validation/fallback code before helper untouched.
f=w/'quantize_fp_amd64.go';parent=(old/'parent/internal/pixel/quantize_fp_amd64.go').read_text();now=f.read_text();assert now[:now.index('func fp16WindowsDisjoint')]==parent[:parent.index('func fp16WindowsDisjoint')]
assert f.read_bytes()==(old/'unrolled/internal/pixel/quantize_fp_amd64.go').read_bytes()
s,a=dis(w/'validation/arm-encoder.test','_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD',True);(cg/'arm-quant.asm').write_text(s);_,b=dis(old/'evidence/validation/parent-arm-encoder.test','_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD',True);assert a==b
summary['arm_live_body_exact']=True;summary['arm_entries']=len(a)
inline=(w/'validation/build-pixel-ordinary.log').read_text();summary['noninline']={}
for h in ['fp16GuardParentProbe','fp16GuardSingleProbe','fp16WindowsDisjoint','fp16GuardUnrolledProbe']:
 ls=[l for l in inline.splitlines() if 'cannot inline '+h+':' in l];assert len(ls)==1;summary['noninline'][h]=ls[0]
fixture=(w/'fp16_guard_component_native_test.go').read_text();summary['production_sha']=hashlib.sha256(f.read_bytes()).hexdigest();summary['fixture_sha']=hashlib.sha256(fixture.encode()).hexdigest();summary['bindings']={'parent':'fp16GuardParentProbe frozen46','single':'fp16GuardSingleProbe frozen single','unrolled':'fp16WindowsDisjoint actual UNMEASURED trial production'};summary['no_native_measurements']=True
(cg/'proof.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))

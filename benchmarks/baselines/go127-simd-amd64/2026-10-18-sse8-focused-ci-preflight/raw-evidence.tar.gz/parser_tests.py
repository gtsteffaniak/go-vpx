from pathlib import Path
import re,json,subprocess,sys,tempfile,shutil,collections
ready=Path('/private/tmp/govpx-sse8-focused-ci-ready');script=(ready/'overlay/scripts/benchmark-sse8-amd64.sh').read_text();blocks=re.findall(r"<<'PY'(?: \|\| status=1)?\n(.*?)\nPY",script,re.S);code=blocks[-1]
results=[]
with tempfile.TemporaryDirectory(prefix='govpx-sse8-parser-',dir='/private/tmp') as temp:
 out=Path(temp); names=[]
 for variant in ['head','base','assembly']:
  source=(ready/'evidence'/(variant+'-rosetta-one-shot-correctness.txt')).read_text()
  (out/(variant+'-one-shot.txt')).write_text(source)
  these=re.findall(r'^(Benchmark\S+)\s+\d+\s',source,re.M)
  assert len(these)==40
  if not names:names=these
  assert set(these)==set(names)
  for rnd in range(1,7):
   ns={'head':20,'base':10,'assembly':15}[variant]
   # Deliberately regressing synthetic measurements: summary must still pass.
   text=''.join(f'{name} 1000 {ns:.3f} ns/op 0 B/op 0 allocs/op\n'for name in names)+'PASS\n'
   (out/f'{variant}-round-{rnd}.txt').write_text(text)
 order_texts=re.findall(r"[1-6]\) order='([^']+)'",script)
 assert len(order_texts)==6
 (out/'orders.txt').write_text(''.join(f'round {i+1}: {order}\n' for i,order in enumerate(order_texts)))
 (out/'commits.json').write_text(json.dumps({'head':'synthetic-parser-head','base':'synthetic-parser-base','assembly':'synthetic-parser-assembly'}))
 def run(name,ok):
  r=subprocess.run([sys.executable,'-c',code,str(out)],text=True,capture_output=True)
  assert (r.returncode==0)==ok,(name,r.returncode,r.stderr)
  results.append({'case':name,'expected_success':ok,'actual_exit':r.returncode})
 run('all720samples+40names+allregressions_kept',True)
 summary=json.loads((out/'summary.json').read_text());assert len(summary['results'])==40;assert all(x['base_over_head']==0.5 and x['pairs_head_slower']==6 for x in summary['results'])
 raw=out/'head-round-1.txt';good=raw.read_text();lines=good.splitlines()
 raw.write_text('\n'.join(lines[1:])+'\n');run('missing_public_case_rejected',False)
 raw.write_text(good+lines[0]+'\n');run('duplicate_case_rejected',False)
 raw.write_text(good.replace('0 B/op 0 allocs/op','4 B/op 1 allocs/op',1));run('nonzero_timed_allocations_rejected',False)
 raw.write_text(good.replace('20.000 ns/op ','',1));run('missing_timed_ns_rejected',False)
 raw.write_text(good.replace('20.000 ns/op','0.000 ns/op',1));run('zero_timed_ns_rejected',False)
 raw.write_text(good.replace('20.000 ns/op','2.000e+1 ns/op',1));run('scientific_ns_format_accepted',True)
 raw.write_text(good.replace('PASS\n',''));run('missing_final_pass_rejected',False)
 raw.write_text(good+'BenchmarkUnexpected 100 1.0 ns/op 0 B/op 0 allocs/op\n');run('unexpected_case_rejected',False)
 raw.write_text(good)
 # Legacy B.N setup allocation at1x is diagnostic, not a timed failure.
 one=out/'assembly-one-shot.txt';good_one=one.read_text();one.write_text(re.sub(r'(BenchmarkSSE8x8\s+1\s+.*?)(0 B/op\s+0 allocs/op)',r'\g<1>2048 B/op 2 allocs/op',good_one));run('legacy_one_shot_setup_allocation_retained',True)
 one.write_text(good_one)
 # Missing1x ns (zero-resolution elapsed time) is valid oracle evidence only.
 # Actual captured Rosetta1x output already includes such lines.
 assert any(re.search(r'BenchmarkSSE8RowsNative/\S+\s+1\s+0 B/op', (ready/'evidence'/(v+'-rosetta-one-shot-correctness.txt')).read_text())for v in ['head','base','assembly'])
 run('actual_one_shot_omitted_ns_accepted',True)
 orders_file=out/'orders.txt';good_orders=orders_file.read_text();orders_file.write_text(good_orders.replace('base head assembly','assembly base head',1));run('duplicated_unbalanced_variant_order_rejected',False);orders_file.write_text(good_orders)
 orders=[['assembly','base','head'],['base','head','assembly'],['head','assembly','base'],['assembly','head','base'],['head','base','assembly'],['base','assembly','head']]
 assert len(set(tuple(x)for x in orders))==6
 for pos in range(3):assert collections.Counter(x[pos]for x in orders)=={'assembly':2,'base':2,'head':2}
 results.append({'case':'all_six_variant_permutations_balanced_each_position','success':True})
(ready/'evidence/parser-validation.json').write_text(json.dumps({'scope':'synthetic parser tests only; no performance measurements or claims','actual_oracle_case_inventory':len(names),'results':results},indent=2)+'\n')
(ready/'evidence/summary-parser.py.txt').write_text(code)
print(json.dumps(results,indent=2))

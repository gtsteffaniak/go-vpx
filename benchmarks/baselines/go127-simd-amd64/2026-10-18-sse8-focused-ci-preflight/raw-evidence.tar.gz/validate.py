from pathlib import Path
import os,subprocess,sys,tarfile,io,json,hashlib,re,collections
ready=Path('/private/tmp/govpx-sse8-focused-ci-ready');root=Path('/Users/thesyncim/GolandProjects/govpx');scratch=Path('/private/tmp/govpx-sse8-focused-validation');scratch.mkdir(exist_ok=True)
commits={'head':'c638b7c76eac857affa0780820e86c211cdd84d3','base':'ab3abd6b335242d5732fa1956a63b7591eaf781b','assembly':'691cd0512c4829d9ee40d483205dd223f9eb028d'}
sh=ready/'overlay/scripts/benchmark-sse8-amd64.sh';source=sh.read_text()
blocks=re.findall(r"<<'PY'(?: \|\| status=1)?\n(.*?)\nPY",source,re.S)
assert len(blocks)==3,len(blocks)
for index,block in enumerate(blocks):compile(block,str(sh)+f':heredoc{index}','exec')
(ready/'evidence/heredoc-python-syntax.txt').write_text('All3 embedded Python programs compile.\n')
for variant,commit in commits.items():
 dest=scratch/variant;dest.mkdir(exist_ok=True)
 archive=subprocess.check_output(['git','archive',commit],cwd=root)
 with tarfile.open(fileobj=io.BytesIO(archive))as tar:
  for member in tar.getmembers():
   if member.name.startswith('/')or'..'in Path(member.name).parts:raise RuntimeError('unsafe archive')
  tar.extractall(dest)
 fixture='internal/vp8/dsp/sse8_rows_native_test.go'
 if variant!='head':
  (dest/fixture).write_bytes((scratch/'head'/fixture).read_bytes())
 assert (dest/fixture).read_bytes()==(scratch/'head'/fixture).read_bytes()
 # Exactly four existing SSE8 B.N diagnostics, all eight pixels wide.
 variance=(dest/'internal/vp8/dsp/variance_test.go').read_text()
 names=set(re.findall(r'^func (BenchmarkSSE8\w*)\(b \*testing.B\)',variance,re.M))
 assert names=={'BenchmarkSSE8x4','BenchmarkSSE8x8','BenchmarkSSE8x16','BenchmarkSSE8x8PtrFast'},names
(ready/'evidence/pins-fixture-and-legacy.json').write_text(json.dumps({'commits':commits,'copied_fixture_only':fixture,'fixture_sha256':hashlib.sha256((scratch/'head'/fixture).read_bytes()).hexdigest(),'legacy_names':sorted(names),'legacy_protocol':'existing B.N; all width8: heights4,8,16,and pointer8x8'},indent=2)+'\n')
env=os.environ.copy();env.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-sse8-focused',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='1',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',GOARCH='amd64',GOAMD64='v1')
results=[]
def build(name,args,osname,variant):
 cmd=[str(root/'scripts/go.sh'),'-C',str(scratch/variant)]+args;e=env.copy();e['GOOS']=osname
 with (ready/'evidence'/(name+'.log')).open('w')as f:r=subprocess.run(cmd,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'GOOS':osname,'GOARCH':'amd64','exit':r.returncode});print(name,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
for variant in commits:
 for osname in ['linux','darwin']:
  build(f'{variant}-{osname}-build',['test','-pgo=off','-c','./internal/vp8/dsp','-o',str(scratch/(variant+'-'+osname+'.test'))],osname,variant)
 # Correctness only. Discard all one-shot ns/op fields for performance purposes.
 cmd=[str(scratch/(variant+'-darwin.test')),'-test.run=^$','-test.bench=^Benchmark(SSE8RowsNative|SSE8x4|SSE8x8|SSE8x16|SSE8x8PtrFast)$','-test.benchtime=1x','-test.cpu=1','-test.benchmem']
 e=env.copy();e.update(ROSETTA_ADVERTISE_AVX='1',GOVPX_REQUIRE_SIMD='1')
 with (ready/'evidence'/(variant+'-rosetta-one-shot-correctness.txt')).open('w')as f:r=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT)
 print(variant,'one-shot oracle',r.returncode,flush=True);assert r.returncode==0
build('head-darwin-pixel-build',['test','-pgo=off','-c','./internal/pixel','-o',str(scratch/'head-pixel-darwin.test')],'darwin','head')
e=env.copy();e.update(ROSETTA_ADVERTISE_AVX='1',GOVPX_REQUIRE_SIMD='1')
with (ready/'evidence/head-rosetta-dispatch.txt').open('w')as f:r=subprocess.run([str(scratch/'head-pixel-darwin.test'),'-test.run=^TestBackendSelected$','-test.count=1','-test.v'],env=e,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0
assert '--- PASS: TestBackendSelected ' in (ready/'evidence/head-rosetta-dispatch.txt').read_text()
(ready/'evidence/build-validation.json').write_text(json.dumps({'scope':'crossbuild+Rosetta1x correctness only; no native or emulated performance claim','commands':results,'binary_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in scratch.glob('*.test')}},indent=2)+'\n')
(ready/'evidence/summary-parser.py.txt').write_text(blocks[-1])
print('BUILD+ORACLE VALIDATION COMPLETE',flush=True)

from pathlib import Path
import tempfile,subprocess,json,hashlib,shlex,sys,os
ready=Path('/private/tmp/govpx-sse8-focused-ci-ready');script=ready/'overlay/scripts/benchmark-sse8-amd64.sh';source=script.read_text()
definition=source[source.index('finish() {'):source.index('\ntrap finish EXIT')]
results=[]
env=os.environ.copy();env['PATH']='/usr/bin:/bin:/usr/sbin:/sbin'
for code in [0,7]:
 with tempfile.TemporaryDirectory(prefix='govpx-sse8-finalizer-',dir='/private/tmp')as tmp:
  root=Path(tmp);output=root/'evidence';output.mkdir();scratch=root/'archives';scratch.mkdir();(scratch/'source').write_text('temporary source archive')
  shell='set -eu\noutput_dir='+shlex.quote(str(output))+'\nscratch='+shlex.quote(str(scratch))+'\nphase=synthetic-finalization-check\n'+definition+'\ntrap finish EXIT\nprintf evidence > "$output_dir/evidence.txt"\nexit '+str(code)+'\n'
  run=subprocess.run(['sh','-c',shell],text=True,capture_output=True,env=env)
  assert run.returncode==code,(run.returncode,run.stderr)
  assert not scratch.exists()
  status=json.loads((output/'status.json').read_text());assert status=={'exit_status':code,'phase':'synthetic-finalization-check'}
  manifest=(output/'SHA256SUMS').read_text().splitlines();assert len(manifest)==2
  for line in manifest:
   digest,path=line.split('  ',1);assert hashlib.sha256((output/path).read_bytes()).hexdigest()==digest
  results.append({'case':'finish_on_exit_'+str(code),'exit_preserved':True,'archive_cleanup':True,'partial_evidence_preserved':True,'manifest_verified':True})
# The actual production script refuses emulated/non-Linux timing before any Go.
with tempfile.TemporaryDirectory(prefix='govpx-sse8-native-guard-',dir='/private/tmp')as tmp:
 output=Path(tmp)/'should-not-exist'
 run=subprocess.run(['sh',str(script),'HEAD','HEAD',str(output)],text=True,capture_output=True,env=env)
 assert run.returncode==1 and 'requires native Linux/amd64' in run.stderr and not output.exists(),(run.returncode,run.stderr)
 results.append({'case':'actual_Darwin_arm64_native_timing_guard','exit':run.returncode,'no_output_or_Go_command':True})
(ready/'evidence/shell-finalization-validation.json').write_text(json.dumps({'scope':'offline shell behavior only; no benchmark timing','results':results},indent=2)+'\n')
print(json.dumps(results,indent=2))

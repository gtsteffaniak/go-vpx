from pathlib import Path
import hashlib,json,re,subprocess,os
D=Path(__file__).parent;R=Path('/Users/thesyncim/GolandProjects/govpx');proof={};env=os.environ.copy();env.update(CODEX_AGENT_ID='govpx-ci49-dispatch-metadata',CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go')
for v in ('parent','current','candidate'):
 src={str(p.relative_to(D/v)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted((D/v).rglob('*.go'))};proof[v]={'all_Go_sha256':src}
a=proof['current']['all_Go_sha256'];b=proof['candidate']['all_Go_sha256'];assert set(a)==set(b);delta=[p for p in a if a[p]!=b[p]];assert delta==['internal/pixel/quantize_fp_amd64.go'];proof['candidate_changed_Go_only']=delta
binary={}
for p in sorted(D.glob('*.test')):
 info=subprocess.check_output([str(R/'scripts/go.sh'),'version','-m',str(p)],cwd=R,env=env).decode();(D/'logs'/(p.name+'.buildinfo.txt')).write_text(info);binary[p.name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'buildinfo':info}
proof['binary_metadata_no_timing']=binary;proof['scope']={'crossbuild_CGO_ENABLED':0,'original_runner_CGO_ENABLED':1,'local_execution':'Rosetta correctness only; actualAVX512false; no fakecaps','regression_cause':'UNPROVEN; framegrowth hypothesis rejected by reconstruction','native_performance_claim':None}
(D/'final-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
cmd=[]
for v in ('parent','current','candidate'):
 for target in ('linux','darwin'):
  cmd.append(f'CODEX_AGENT_ID=govpx-ci49-dispatch-{v}-{target} CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GOEXPERIMENT=simd GOFLAGS=-p=2 GOMAXPROCS=2 GOOS={target} GOARCH=amd64 GOAMD64=v1 CGO_ENABLED=0 GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go scripts/go.sh -C {D/v} test -pgo=off -c -o {D/(v+"-"+target+"-pixel.test")} ./internal/pixel')
cmd.append(f'CODEX_AGENT_ID=govpx-ci49-dispatch-candidate-checkptr CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GOEXPERIMENT=simd GOFLAGS=-p=2 GOMAXPROCS=2 GOOS=darwin GOARCH=amd64 GOAMD64=v1 CGO_ENABLED=0 GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go scripts/go.sh -C {D/"candidate"} test -pgo=off -gcflags=all=-d=checkptr=2 -c -o {D/"candidate-darwin-checkptr-pixel.test"} ./internal/pixel')
for checked in (False,True):
 p=D/('candidate-darwin-'+('checkptr-'if checked else'')+'pixel.test')
 for mode in ('selected','512off','cpuoff'):
  flag='GODEBUG='if mode=='selected'else'GODEBUG=cpu.avx512f=off'if mode=='512off'else'GODEBUG=cpu.avx=off,cpu.avx2=off,cpu.avx512f=off';req='GOVPX_REQUIRE_SIMD=0 GOVPX_REQUIRE_FP32_OFF=1 GOVPX_REQUIRE_FP16_AVX_OFF=1'if mode=='cpuoff'else'GOVPX_REQUIRE_SIMD=1 GOVPX_REQUIRE_FP32_OFF=1'if mode=='512off'else'GOVPX_REQUIRE_SIMD=1';cmd.append(f"ROSETTA_ADVERTISE_AVX=1 {req} GOMAXPROCS=1 {flag} arch -x86_64 {p} -test.run '^Test(FP16|FP32)' -test.count=1 -test.v")
(D/'COMMANDS.txt').write_text('All build commands launched from ROOT '+str(R)+'.\nExact commands (logs separately preserved):\n\n'+'\n'.join(cmd)+'\n\nCodegen: xcrun llvm-objdump --disassemble-symbols=<four Go symbols> <binary>; xcrun llvm-nm --print-size <binary>. Apple LLVM21.0.0.\n')
print(json.dumps({'candidate_delta':delta,'binaries':len(binary),'source_groups':list(proof)[:3],'performance_claim':None},indent=2))


/private/tmp/govpx-ci49-avx2-dispatch-followup/current-linux-pixel.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000564fc0 <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock>:
  564fc0: 4c 8d 64 24 e0               	leaq	-0x20(%rsp), %r12
  564fc5: 4d 3b 66 10                  	cmpq	0x10(%r14), %r12
  564fc9: 0f 86 0e 02 00 00            	jbe	0x5651dd <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x21d>
  564fcf: 55                           	pushq	%rbp
  564fd0: 48 89 e5                     	movq	%rsp, %rbp
  564fd3: 48 81 ec 98 00 00 00         	subq	$0x98, %rsp
  564fda: 48 89 84 24 f0 00 00 00      	movq	%rax, 0xf0(%rsp)
  564fe2: 48 89 bc 24 08 01 00 00      	movq	%rdi, 0x108(%rsp)
  564fea: 4c 89 8c 24 20 01 00 00      	movq	%r9, 0x120(%rsp)
  564ff2: 48 8b 94 24 c0 00 00 00      	movq	0xc0(%rsp), %rdx
  564ffa: 66 0f 1f 44 00 00            	nopw	(%rax,%rax)
  565000: 48 85 d2                     	testq	%rdx, %rdx
  565003: 0f 8e af 01 00 00            	jle	0x5651b8 <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x1f8>
  565009: 4c 8d 62 ff                  	leaq	-0x1(%rdx), %r12
  56500d: 4c 39 e3                     	cmpq	%r12, %rbx
  565010: 0f 86 c1 01 00 00            	jbe	0x5651d7 <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x217>
  565016: 4c 39 e6                     	cmpq	%r12, %rsi
  565019: 0f 86 b3 01 00 00            	jbe	0x5651d2 <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x212>
  56501f: 4c 8b ac 24 b0 00 00 00      	movq	0xb0(%rsp), %r13
  565027: 4d 39 e5                     	cmpq	%r12, %r13
  56502a: 0f 86 9d 01 00 00            	jbe	0x5651cd <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x20d>
  565030: 4d 85 c9                     	testq	%r9, %r9
  565033: 74 09                        	je	0x56503e <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x7e>
  565035: 4d 39 e2                     	cmpq	%r12, %r10
  565038: 0f 86 8a 01 00 00            	jbe	0x5651c8 <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x208>
  56503e: 4c 8b bc 24 d8 00 00 00      	movq	0xd8(%rsp), %r15
  565046: 4d 85 ff                     	testq	%r15, %r15
  565049: 74 12                        	je	0x56505d <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x9d>
  56504b: 4c 8b bc 24 e0 00 00 00      	movq	0xe0(%rsp), %r15
  565053: 4d 39 e7                     	cmpq	%r12, %r15
  565056: 77 0d                        	ja	0x565065 <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0xa5>
  565058: e9 66 01 00 00               	jmp	0x5651c3 <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x203>
  56505d: 4c 8b bc 24 e0 00 00 00      	movq	0xe0(%rsp), %r15
  565065: 80 3d c1 e0 26 00 00         	cmpb	$0x0, 0x26e0c1(%rip)    # 0x7d312d <github.com/thesyncim/govpx/internal/pixel.Enabled>
  56506c: 0f 84 cc 00 00 00            	je	0x56513e <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x17e>
  565072: 66 83 bc 24 c8 00 00 00 00   	cmpw	$0x0, 0xc8(%rsp)
  56507b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  565080: 0f 8c b8 00 00 00            	jl	0x56513e <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x17e>
  565086: 66 83 bc 24 ca 00 00 00 00   	cmpw	$0x0, 0xca(%rsp)
  56508f: 0f 8c a9 00 00 00            	jl	0x56513e <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x17e>
  565095: 66 83 bc 24 cc 00 00 00 00   	cmpw	$0x0, 0xcc(%rsp)
  56509e: 66 90                        	nop
  5650a0: 0f 8c 98 00 00 00            	jl	0x56513e <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x17e>
  5650a6: 66 83 bc 24 ce 00 00 00 00   	cmpw	$0x0, 0xce(%rsp)
  5650af: 0f 8c 89 00 00 00            	jl	0x56513e <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x17e>
  5650b5: 66 83 bc 24 d0 00 00 00 00   	cmpw	$0x0, 0xd0(%rsp)
  5650be: 66 90                        	nop
  5650c0: 7e 7c                        	jle	0x56513e <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x17e>
  5650c2: 66 83 bc 24 d2 00 00 00 00   	cmpw	$0x0, 0xd2(%rsp)
  5650cb: 7e 71                        	jle	0x56513e <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock+0x17e>
  5650cd: 4c 8b a4 24 a8 00 00 00      	movq	0xa8(%rsp), %r12
  5650d5: 4c 89 24 24                  	movq	%r12, (%rsp)
  5650d9: 4c 89 6c 24 08               	movq	%r13, 0x8(%rsp)
  5650de: 4c 8b a4 24 b8 00 00 00      	movq	0xb8(%rsp), %r12
  5650e6: 4c 89 64 24 10               	movq	%r12, 0x10(%rsp)
  5650eb: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  5650f0: 8b 94 24 c8 00 00 00         	movl	0xc8(%rsp), %edx
  5650f7: 89 54 24 20                  	movl	%edx, 0x20(%rsp)
  5650fb: 8b 94 24 cc 00 00 00         	movl	0xcc(%rsp), %edx
  565102: 89 54 24 24                  	movl	%edx, 0x24(%rsp)
  565106: 8b 94 24 d0 00 00 00         	movl	0xd0(%rsp), %edx
  56510d: 89 54 24 28                  	movl	%edx, 0x28(%rsp)
  565111: 48 8b 94 24 d8 00 00 00      	movq	0xd8(%rsp), %rdx
  565119: 48 89 54 24 30               	movq	%rdx, 0x30(%rsp)
  56511e: 4c 89 7c 24 38               	movq	%r15, 0x38(%rsp)
  565123: 48 8b 94 24 e8 00 00 00      	movq	0xe8(%rsp), %rdx
  56512b: 48 89 54 24 40               	movq	%rdx, 0x40(%rsp)
  565130: e8 cb 05 00 00               	callq	0x565700 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD>
  565135: 48 81 c4 98 00 00 00         	addq	$0x98, %rsp
  56513c: 5d                           	popq	%rbp
  56513d: c3                           	retq
  56513e: 4c 8b a4 24 a8 00 00 00      	movq	0xa8(%rsp), %r12
  565146: 4c 89 24 24                  	movq	%r12, (%rsp)
  56514a: 4c 89 6c 24 08               	movq	%r13, 0x8(%rsp)
  56514f: 4c 8b a4 24 b8 00 00 00      	movq	0xb8(%rsp), %r12
  565157: 4c 89 64 24 10               	movq	%r12, 0x10(%rsp)
  56515c: 48 c7 44 24 18 00 00 00 00   	movq	$0x0, 0x18(%rsp)
  565165: 48 89 54 24 20               	movq	%rdx, 0x20(%rsp)
  56516a: 8b 94 24 c8 00 00 00         	movl	0xc8(%rsp), %edx
  565171: 89 54 24 28                  	movl	%edx, 0x28(%rsp)
  565175: 8b 94 24 cc 00 00 00         	movl	0xcc(%rsp), %edx
  56517c: 89 54 24 2c                  	movl	%edx, 0x2c(%rsp)
  565180: 8b 94 24 d0 00 00 00         	movl	0xd0(%rsp), %edx
  565187: 89 54 24 30                  	movl	%edx, 0x30(%rsp)
  56518b: 48 8b 94 24 d8 00 00 00      	movq	0xd8(%rsp), %rdx
  565193: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
  565198: 4c 89 7c 24 40               	movq	%r15, 0x40(%rsp)
  56519d: 48 8b 94 24 e8 00 00 00      	movq	0xe8(%rsp), %rdx
  5651a5: 48 89 54 24 48               	movq	%rdx, 0x48(%rsp)
  5651aa: e8 b1 00 00 00               	callq	0x565260 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockTail>
  5651af: 48 81 c4 98 00 00 00         	addq	$0x98, %rsp
  5651b6: 5d                           	popq	%rbp
  5651b7: c3                           	retq
  5651b8: 31 c0                        	xorl	%eax, %eax
  5651ba: 48 81 c4 98 00 00 00         	addq	$0x98, %rsp
  5651c1: 5d                           	popq	%rbp
  5651c2: c3                           	retq
  5651c3: e8 38 83 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  5651c8: e8 33 83 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  5651cd: e8 2e 83 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  5651d2: e8 29 83 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  5651d7: e8 24 83 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  5651dc: 90                           	nop
  5651dd: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
  5651e2: 48 89 5c 24 58               	movq	%rbx, 0x58(%rsp)
  5651e7: 48 89 4c 24 60               	movq	%rcx, 0x60(%rsp)
  5651ec: 48 89 7c 24 68               	movq	%rdi, 0x68(%rsp)
  5651f1: 48 89 74 24 70               	movq	%rsi, 0x70(%rsp)
  5651f6: 4c 89 44 24 78               	movq	%r8, 0x78(%rsp)
  5651fb: 4c 89 8c 24 80 00 00 00      	movq	%r9, 0x80(%rsp)
  565203: 4c 89 94 24 88 00 00 00      	movq	%r10, 0x88(%rsp)
  56520b: 4c 89 9c 24 90 00 00 00      	movq	%r11, 0x90(%rsp)
  565213: e8 a8 66 f2 ff               	callq	0x48b8c0 <runtime.morestack_noctxt.abi0>
  565218: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
  56521d: 48 8b 5c 24 58               	movq	0x58(%rsp), %rbx
  565222: 48 8b 4c 24 60               	movq	0x60(%rsp), %rcx
  565227: 48 8b 7c 24 68               	movq	0x68(%rsp), %rdi
  56522c: 48 8b 74 24 70               	movq	0x70(%rsp), %rsi
  565231: 4c 8b 44 24 78               	movq	0x78(%rsp), %r8
  565236: 4c 8b 8c 24 80 00 00 00      	movq	0x80(%rsp), %r9
  56523e: 4c 8b 94 24 88 00 00 00      	movq	0x88(%rsp), %r10
  565246: 4c 8b 9c 24 90 00 00 00      	movq	0x90(%rsp), %r11
  56524e: e9 6d fd ff ff               	jmp	0x564fc0 <github.com/thesyncim/govpx/internal/pixel.QuantizeFPBlock>
  565253: cc                           	int3
  565254: cc                           	int3
  565255: cc                           	int3
  565256: cc                           	int3
  565257: cc                           	int3
  565258: cc                           	int3
  565259: cc                           	int3
  56525a: cc                           	int3
  56525b: cc                           	int3
  56525c: cc                           	int3
  56525d: cc                           	int3
  56525e: cc                           	int3
  56525f: cc                           	int3

0000000000565420 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512>:
  565420: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
  565425: 48 89 7c 24 68               	movq	%rdi, 0x68(%rsp)
  56542a: 4c 89 8c 24 80 00 00 00      	movq	%r9, 0x80(%rsp)
  565432: 90                           	nop
  565433: 62 f1 fd 48 ef c0            	vpxorq	%zmm0, %zmm0, %zmm0
  565439: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
  56543e: 66 90                        	nop
  565440: 48 85 c9                     	testq	%rcx, %rcx
  565443: 74 0a                        	je	0x56544f <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x2f>
  565445: 62 f1 fe 48 6f 05 b1 aa 22 00	vmovdqu64	0x22aab1(%rip), %zmm0 # 0x78ff00 <github.com/thesyncim/govpx/internal/pixel.fpClassWordLUT32>
  56544f: 62 f1 f5 48 ef c9            	vpxorq	%zmm1, %zmm1, %zmm1
  565455: 0f b7 54 24 2a               	movzwl	0x2a(%rsp), %edx
  56545a: 0f b7 5c 24 28               	movzwl	0x28(%rsp), %ebx
  56545f: 0f b7 74 24 2e               	movzwl	0x2e(%rsp), %esi
  565464: 44 0f b7 44 24 2c            	movzwl	0x2c(%rsp), %r8d
  56546a: 44 0f b7 54 24 32            	movzwl	0x32(%rsp), %r10d
  565470: 44 0f b7 5c 24 30            	movzwl	0x30(%rsp), %r11d
  565476: 62 f1 fe 48 6f 10            	vmovdqu64	(%rax), %zmm2
  56547c: 62 f2 7d 48 1d da            	vpabsw	%zmm2, %zmm3
  565482: 62 f3 ed 48 3f c9 01         	vpcmpltw	%zmm1, %zmm2, %k1
  565489: 41 bc ff 7f 00 00            	movl	$0x7fff, %r12d          # imm = 0x7FFF
  56548f: c4 c1 f9 6e d4               	vmovq	%r12, %xmm2
  565494: 62 f2 7d 48 79 d2            	vpbroadcastw	%xmm2, %zmm2
  56549a: c5 81 c4 e2 00               	vpinsrw	$0x0, %edx, %xmm15, %xmm4
  56549f: 62 f2 7d 48 79 ec            	vpbroadcastw	%xmm4, %zmm5
  5654a5: c4 e2 7d 79 f4               	vpbroadcastw	%xmm4, %ymm6
  5654aa: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
  5654af: c5 d9 c4 e3 00               	vpinsrw	$0x0, %ebx, %xmm4, %xmm4
  5654b4: c4 e3 4d 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm6, %ymm4
  5654ba: 62 f3 d5 48 3a e4 00         	vinserti64x4	$0x0, %ymm4, %zmm5, %zmm4
  5654c1: 62 f1 5d 48 fd db            	vpaddw	%zmm3, %zmm4, %zmm3
  5654c7: 62 f2 65 48 3a da            	vpminuw	%zmm2, %zmm3, %zmm3
  5654cd: c5 81 c4 e6 00               	vpinsrw	$0x0, %esi, %xmm15, %xmm4
  5654d2: 62 f2 7d 48 79 ec            	vpbroadcastw	%xmm4, %zmm5
  5654d8: c4 e2 7d 79 f4               	vpbroadcastw	%xmm4, %ymm6
  5654dd: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
  5654e2: c4 c1 59 c4 e0 00            	vpinsrw	$0x0, %r8d, %xmm4, %xmm4
  5654e8: c4 e3 4d 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm6, %ymm4
  5654ee: 62 f3 d5 48 3a e4 00         	vinserti64x4	$0x0, %ymm4, %zmm5, %zmm4
  5654f5: c4 c1 01 c4 ea 00            	vpinsrw	$0x0, %r10d, %xmm15, %xmm5
  5654fb: 62 f2 7d 48 79 f5            	vpbroadcastw	%xmm5, %zmm6
  565501: c4 e2 7d 79 fd               	vpbroadcastw	%xmm5, %ymm7
  565506: c4 e2 79 79 ed               	vpbroadcastw	%xmm5, %xmm5
  56550b: c4 c1 51 c4 eb 00            	vpinsrw	$0x0, %r11d, %xmm5, %xmm5
  565511: c4 e3 45 38 ed 00            	vinserti128	$0x0, %xmm5, %ymm7, %ymm5
  565517: 62 f3 cd 48 3a ed 00         	vinserti64x4	$0x0, %ymm5, %zmm6, %zmm5
  56551e: 62 f3 e5 48 3f d5 0d         	vpcmpw	$0xd, %zmm5, %zmm3, %k2
  565525: 62 f1 5d ca e5 db            	vpmulhw	%zmm3, %zmm4, %zmm3 {%k2} {z}
  56552b: 90                           	nop
  56552c: 62 f1 fe 48 7f dc            	vmovdqu64	%zmm3, %zmm4
  565532: 62 f1 75 49 f9 db            	vpsubw	%zmm3, %zmm1, %zmm3 {%k1}
  565538: 4d 85 c9                     	testq	%r9, %r9
  56553b: 74 0b                        	je	0x565548 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x128>
  56553d: 62 d1 fe 48 7f 19            	vmovdqu64	%zmm3, (%r9)
  565543: 48 85 c9                     	testq	%rcx, %rcx
  565546: eb 03                        	jmp	0x56554b <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x12b>
  565548: 48 85 c9                     	testq	%rcx, %rcx
  56554b: 62 f1 55 48 d5 eb            	vpmullw	%zmm3, %zmm5, %zmm5
  565551: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
  565556: 62 f1 fe 48 7f 2a            	vmovdqu64	%zmm5, (%rdx)
  56555c: 62 f1 fe 48 6f 2f            	vmovdqu64	(%rdi), %zmm5
  565562: 62 f3 e5 48 3f c9 04         	vpcmpneqw	%zmm1, %zmm3, %k1
  565569: bb 0b 00 00 00               	movl	$0xb, %ebx
  56556e: c4 e1 f9 6e db               	vmovq	%rbx, %xmm3
  565573: 62 f1 ff c9 7f ed            	vmovdqu16	%zmm5, %zmm5 {%k1} {z}
  565579: 62 f1 75 48 ee ed            	vpmaxsw	%zmm5, %zmm1, %zmm5
  56557f: 62 f2 7d 48 79 db            	vpbroadcastw	%xmm3, %zmm3
  565585: 74 16                        	je	0x56559d <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x17d>
  565587: 62 f1 5d 48 ea e3            	vpminsw	%zmm3, %zmm4, %zmm4
  56558d: 62 f2 dd 48 8d e0            	vpermw	%zmm0, %zmm4, %zmm4
  565593: 62 f2 7e 48 30 e4            	vpmovwb	%zmm4, %ymm4
  565599: c5 fe 7f 21                  	vmovdqu	%ymm4, (%rcx)
  56559d: 0f b7 5c 24 2a               	movzwl	0x2a(%rsp), %ebx
  5655a2: 0f b7 74 24 2e               	movzwl	0x2e(%rsp), %esi
  5655a7: 44 0f b7 44 24 32            	movzwl	0x32(%rsp), %r8d
  5655ad: c4 e1 f9 6e e3               	vmovq	%rbx, %xmm4
  5655b2: c4 e1 f9 6e f6               	vmovq	%rsi, %xmm6
  5655b7: c4 c1 f9 6e f8               	vmovq	%r8, %xmm7
  5655bc: 62 f2 7d 48 79 e4            	vpbroadcastw	%xmm4, %zmm4
  5655c2: 62 f2 7d 48 79 f6            	vpbroadcastw	%xmm6, %zmm6
  5655c8: 62 f2 7d 48 79 ff            	vpbroadcastw	%xmm7, %zmm7
  5655ce: bb 20 00 00 00               	movl	$0x20, %ebx
  5655d3: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
  5655d8: eb 06                        	jmp	0x5655e0 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1c0>
  5655da: 48 83 c3 20                  	addq	$0x20, %rbx
  5655de: 66 90                        	nop
  5655e0: 48 39 de                     	cmpq	%rbx, %rsi
  5655e3: 0f 8e a6 00 00 00            	jle	0x56568f <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x26f>
  5655e9: 4c 8d 04 58                  	leaq	(%rax,%rbx,2), %r8
  5655ed: 62 51 fe 48 6f 00            	vmovdqu64	(%r8), %zmm8
  5655f3: 62 52 7d 48 1d c8            	vpabsw	%zmm8, %zmm9
  5655f9: 62 71 35 48 fd cc            	vpaddw	%zmm4, %zmm9, %zmm9
  5655ff: 62 72 35 48 3a ca            	vpminuw	%zmm2, %zmm9, %zmm9
  565605: 62 f3 b5 48 3f cf 0d         	vpcmpw	$0xd, %zmm7, %zmm9, %k1
  56560c: 62 f3 bd 48 3f d1 01         	vpcmpltw	%zmm1, %zmm8, %k2
  565613: 62 51 4d c9 e5 c1            	vpmulhw	%zmm9, %zmm6, %zmm8 {%k1} {z}
  565619: 62 51 fe 48 7f c1            	vmovdqu64	%zmm8, %zmm9
  56561f: 62 51 75 4a f9 c0            	vpsubw	%zmm8, %zmm1, %zmm8 {%k2}
  565625: 4d 85 c9                     	testq	%r9, %r9
  565628: 74 0f                        	je	0x565639 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x219>
  56562a: 4d 8d 04 59                  	leaq	(%r9,%rbx,2), %r8
  56562e: 62 51 fe 48 7f 00            	vmovdqu64	%zmm8, (%r8)
  565634: 48 85 c9                     	testq	%rcx, %rcx
  565637: eb 03                        	jmp	0x56563c <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x21c>
  565639: 48 85 c9                     	testq	%rcx, %rcx
  56563c: 62 51 45 48 d5 d0            	vpmullw	%zmm8, %zmm7, %zmm10
  565642: 4c 8d 04 5a                  	leaq	(%rdx,%rbx,2), %r8
  565646: 62 51 fe 48 7f 10            	vmovdqu64	%zmm10, (%r8)
  56564c: 4c 8d 04 5f                  	leaq	(%rdi,%rbx,2), %r8
  565650: 62 51 fe 48 6f 10            	vmovdqu64	(%r8), %zmm10
  565656: 62 f3 bd 48 3f c9 04         	vpcmpneqw	%zmm1, %zmm8, %k1
  56565d: 62 51 ff c9 7f d0            	vmovdqu16	%zmm10, %zmm8 {%k1} {z}
  565663: 62 d1 55 48 ee e8            	vpmaxsw	%zmm8, %zmm5, %zmm5
  565669: 0f 84 6b ff ff ff            	je	0x5655da <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1ba>
  56566f: 62 71 35 48 ea c3            	vpminsw	%zmm3, %zmm9, %zmm8
  565675: 62 72 bd 48 8d c0            	vpermw	%zmm0, %zmm8, %zmm8
  56567b: 62 52 7e 48 30 c0            	vpmovwb	%zmm8, %ymm8
  565681: 4c 8d 04 19                  	leaq	(%rcx,%rbx), %r8
  565685: c4 41 7e 7f 00               	vmovdqu	%ymm8, (%r8)
  56568a: e9 4b ff ff ff               	jmp	0x5655da <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1ba>
  56568f: 62 f3 fd 48 3b e8 00         	vextracti64x4	$0x0, %zmm5, %ymm0
  565696: 62 f3 fd 48 3b e9 01         	vextracti64x4	$0x1, %zmm5, %ymm1
  56569d: c5 fd ee c1                  	vpmaxsw	%ymm1, %ymm0, %ymm0
  5656a1: c4 e3 7d 39 c1 00            	vextracti128	$0x0, %ymm0, %xmm1
  5656a7: c4 e3 7d 39 c0 01            	vextracti128	$0x1, %ymm0, %xmm0
  5656ad: c5 f1 ee c0                  	vpmaxsw	%xmm0, %xmm1, %xmm0
  5656b1: c4 e2 79 23 c8               	vpmovsxwd	%xmm0, %xmm1
  5656b6: c5 f9 70 c0 4e               	vpshufd	$0x4e, %xmm0, %xmm0     # xmm0 = xmm0[2,3,0,1]
  5656bb: c4 e2 79 23 c0               	vpmovsxwd	%xmm0, %xmm0
  5656c0: c4 e2 79 3d c1               	vpmaxsd	%xmm1, %xmm0, %xmm0
  5656c5: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     # xmm1 = xmm0[2,3,0,1]
  5656ca: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  5656cf: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     # xmm1 = xmm0[1,0,3,2]
  5656d4: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  5656d9: c4 e3 79 16 c1 00            	vpextrd	$0x0, %xmm0, %ecx
  5656df: 48 63 c1                     	movslq	%ecx, %rax
  5656e2: c5 f8 77                     	vzeroupper
  5656e5: c3                           	retq
  5656e6: cc                           	int3
  5656e7: cc                           	int3
  5656e8: cc                           	int3
  5656e9: cc                           	int3
  5656ea: cc                           	int3
  5656eb: cc                           	int3
  5656ec: cc                           	int3
  5656ed: cc                           	int3
  5656ee: cc                           	int3
  5656ef: cc                           	int3
  5656f0: cc                           	int3
  5656f1: cc                           	int3
  5656f2: cc                           	int3
  5656f3: cc                           	int3
  5656f4: cc                           	int3
  5656f5: cc                           	int3
  5656f6: cc                           	int3
  5656f7: cc                           	int3
  5656f8: cc                           	int3
  5656f9: cc                           	int3
  5656fa: cc                           	int3
  5656fb: cc                           	int3
  5656fc: cc                           	int3
  5656fd: cc                           	int3
  5656fe: cc                           	int3
  5656ff: cc                           	int3

0000000000565700 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD>:
  565700: 4c 8d 64 24 d0               	leaq	-0x30(%rsp), %r12
  565705: 4d 3b 66 10                  	cmpq	0x10(%r14), %r12
  565709: 0f 86 03 09 00 00            	jbe	0x566012 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x912>
  56570f: 55                           	pushq	%rbp
  565710: 48 89 e5                     	movq	%rsp, %rbp
  565713: 48 81 ec a8 00 00 00         	subq	$0xa8, %rsp
  56571a: 48 89 84 24 00 01 00 00      	movq	%rax, 0x100(%rsp)
  565722: 4c 89 8c 24 30 01 00 00      	movq	%r9, 0x130(%rsp)
  56572a: 4c 89 84 24 28 01 00 00      	movq	%r8, 0x128(%rsp)
  565732: 48 89 b4 24 20 01 00 00      	movq	%rsi, 0x120(%rsp)
  56573a: 48 89 bc 24 18 01 00 00      	movq	%rdi, 0x118(%rsp)
  565742: 48 89 9c 24 08 01 00 00      	movq	%rbx, 0x108(%rsp)
  56574a: 48 8b 94 24 d0 00 00 00      	movq	0xd0(%rsp), %rdx
  565752: 4c 8d 62 c0                  	leaq	-0x40(%rdx), %r12
  565756: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
  56575f: 90                           	nop
  565760: 49 81 fc c0 03 00 00         	cmpq	$0x3c0, %r12            # imm = 0x3C0
  565767: 0f 87 09 01 00 00            	ja	0x565876 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x176>
  56576d: 48 f7 c2 0f 00 00 00         	testq	$0xf, %rdx
  565774: 0f 85 f7 00 00 00            	jne	0x565871 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x171>
  56577a: 80 3d ac d9 26 00 00         	cmpb	$0x0, 0x26d9ac(%rip)    # 0x7d312d <github.com/thesyncim/govpx/internal/pixel.Enabled>
  565781: 0f 84 e5 00 00 00            	je	0x56586c <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x16c>
  565787: 80 3d 76 e5 26 00 00         	cmpb	$0x0, 0x26e576(%rip)    # 0x7d3d04 <internal/cpu.X86+0x44>
  56578e: 75 08                        	jne	0x565798 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x98>
  565790: 45 31 e4                     	xorl	%r12d, %r12d
  565793: e9 e8 00 00 00               	jmp	0x565880 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
  565798: 4c 89 94 24 38 01 00 00      	movq	%r10, 0x138(%rsp)
  5657a0: 4c 89 8c 24 30 01 00 00      	movq	%r9, 0x130(%rsp)
  5657a8: 48 89 8c 24 10 01 00 00      	movq	%rcx, 0x110(%rsp)
  5657b0: 48 89 84 24 00 01 00 00      	movq	%rax, 0x100(%rsp)
  5657b8: 4c 89 9c 24 40 01 00 00      	movq	%r11, 0x140(%rsp)
  5657c0: 4c 8b a4 24 b8 00 00 00      	movq	0xb8(%rsp), %r12
  5657c8: 4c 89 24 24                  	movq	%r12, (%rsp)
  5657cc: 4c 8b a4 24 c0 00 00 00      	movq	0xc0(%rsp), %r12
  5657d4: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  5657d9: 4c 8b a4 24 c8 00 00 00      	movq	0xc8(%rsp), %r12
  5657e1: 4c 89 64 24 10               	movq	%r12, 0x10(%rsp)
  5657e6: 4c 8b a4 24 e8 00 00 00      	movq	0xe8(%rsp), %r12
  5657ee: 4c 89 64 24 18               	movq	%r12, 0x18(%rsp)
  5657f3: 4c 8b a4 24 f0 00 00 00      	movq	0xf0(%rsp), %r12
  5657fb: 4c 89 64 24 20               	movq	%r12, 0x20(%rsp)
  565800: 4c 8b a4 24 f8 00 00 00      	movq	0xf8(%rsp), %r12
  565808: 4c 89 64 24 28               	movq	%r12, 0x28(%rsp)
  56580d: 48 89 54 24 30               	movq	%rdx, 0x30(%rsp)
  565812: e8 89 08 00 00               	callq	0x5660a0 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>
  565817: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  56581f: 48 8b 94 24 d0 00 00 00      	movq	0xd0(%rsp), %rdx
  565827: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  56582f: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  565837: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  56583f: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  565847: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  56584f: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  565857: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  56585f: 41 89 c4                     	movl	%eax, %r12d
  565862: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  56586a: eb 14                        	jmp	0x565880 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
  56586c: 45 31 e4                     	xorl	%r12d, %r12d
  56586f: eb 0f                        	jmp	0x565880 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
  565871: 45 31 e4                     	xorl	%r12d, %r12d
  565874: eb 0a                        	jmp	0x565880 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
  565876: 45 31 e4                     	xorl	%r12d, %r12d
  565879: 0f 1f 80 00 00 00 00         	nopl	(%rax)
  565880: 45 84 e4                     	testb	%r12b, %r12b
  565883: 0f 84 68 02 00 00            	je	0x565af1 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x3f1>
  565889: 48 81 fa 00 01 00 00         	cmpq	$0x100, %rdx            # imm = 0x100
  565890: 0f 8c a5 00 00 00            	jl	0x56593b <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x23b>
  565896: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
  56589f: 90                           	nop
  5658a0: 48 f7 c2 1f 00 00 00         	testq	$0x1f, %rdx
  5658a7: 0f 85 8e 00 00 00            	jne	0x56593b <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x23b>
  5658ad: 80 3d 51 e4 26 00 00         	cmpb	$0x0, 0x26e451(%rip)    # 0x7d3d05 <internal/cpu.X86+0x45>
  5658b4: 0f 84 81 00 00 00            	je	0x56593b <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x23b>
  5658ba: 4c 8b a4 24 b8 00 00 00      	movq	0xb8(%rsp), %r12
  5658c2: 4c 89 24 24                  	movq	%r12, (%rsp)
  5658c6: 4c 8b a4 24 c0 00 00 00      	movq	0xc0(%rsp), %r12
  5658ce: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  5658d3: 4c 8b a4 24 c8 00 00 00      	movq	0xc8(%rsp), %r12
  5658db: 4c 89 64 24 10               	movq	%r12, 0x10(%rsp)
  5658e0: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  5658e5: 8b 94 24 d8 00 00 00         	movl	0xd8(%rsp), %edx
  5658ec: 89 54 24 20                  	movl	%edx, 0x20(%rsp)
  5658f0: 8b 94 24 dc 00 00 00         	movl	0xdc(%rsp), %edx
  5658f7: 89 54 24 24                  	movl	%edx, 0x24(%rsp)
  5658fb: 8b 94 24 e0 00 00 00         	movl	0xe0(%rsp), %edx
  565902: 89 54 24 28                  	movl	%edx, 0x28(%rsp)
  565906: 48 8b 94 24 e8 00 00 00      	movq	0xe8(%rsp), %rdx
  56590e: 48 89 54 24 30               	movq	%rdx, 0x30(%rsp)
  565913: 48 8b 94 24 f0 00 00 00      	movq	0xf0(%rsp), %rdx
  56591b: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
  565920: 48 8b 94 24 f8 00 00 00      	movq	0xf8(%rsp), %rdx
  565928: 48 89 54 24 40               	movq	%rdx, 0x40(%rsp)
  56592d: e8 ee fa ff ff               	callq	0x565420 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512>
  565932: 48 81 c4 a8 00 00 00         	addq	$0xa8, %rsp
  565939: 5d                           	popq	%rbp
  56593a: c3                           	retq
  56593b: 90                           	nop
  56593c: 48 8b 8c 24 e8 00 00 00      	movq	0xe8(%rsp), %rcx
  565944: 48 85 c9                     	testq	%rcx, %rcx
  565947: 74 0a                        	je	0x565953 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x253>
  565949: c5 fa 6f 05 0f 90 22 00      	vmovdqu	0x22900f(%rip), %xmm0   # 0x78e960 <github.com/thesyncim/govpx/internal/pixel.fpClassLUT>
  565951: eb 04                        	jmp	0x565957 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x257>
  565953: 41 0f 10 c7                  	movups	%xmm15, %xmm0
  565957: 0f b7 9c 24 da 00 00 00      	movzwl	0xda(%rsp), %ebx
  56595f: 0f b7 b4 24 d8 00 00 00      	movzwl	0xd8(%rsp), %esi
  565967: 44 0f b7 84 24 de 00 00 00   	movzwl	0xde(%rsp), %r8d
  565970: 44 0f b7 94 24 dc 00 00 00   	movzwl	0xdc(%rsp), %r10d
  565979: 44 0f b7 9c 24 e0 00 00 00   	movzwl	0xe0(%rsp), %r11d
  565982: 44 0f b7 a4 24 e2 00 00 00   	movzwl	0xe2(%rsp), %r12d
  56598b: c5 fe 6f 08                  	vmovdqu	(%rax), %ymm1
  56598f: c4 e2 7d 1d d1               	vpabsw	%ymm1, %ymm2
  565994: c5 f5 71 e1 0f               	vpsraw	$0xf, %ymm1, %ymm1
  565999: 41 bd ff 7f 00 00            	movl	$0x7fff, %r13d          # imm = 0x7FFF
  56599f: c4 c1 f9 6e dd               	vmovq	%r13, %xmm3
  5659a4: c4 e2 7d 79 db               	vpbroadcastw	%xmm3, %ymm3
  5659a9: c5 81 c4 e3 00               	vpinsrw	$0x0, %ebx, %xmm15, %xmm4
  5659ae: c4 e2 7d 79 ec               	vpbroadcastw	%xmm4, %ymm5
  5659b3: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
  5659b8: c5 d9 c4 e6 00               	vpinsrw	$0x0, %esi, %xmm4, %xmm4
  5659bd: c4 e3 55 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm5, %ymm4
  5659c3: c5 ed fd d4                  	vpaddw	%ymm4, %ymm2, %ymm2
  5659c7: c4 e2 6d 3a d3               	vpminuw	%ymm3, %ymm2, %ymm2
  5659cc: c4 c1 01 c4 e0 00            	vpinsrw	$0x0, %r8d, %xmm15, %xmm4
  5659d2: c4 e2 7d 79 ec               	vpbroadcastw	%xmm4, %ymm5
  5659d7: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
  5659dc: c4 c1 59 c4 e2 00            	vpinsrw	$0x0, %r10d, %xmm4, %xmm4
  5659e2: c4 e3 55 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm5, %ymm4
  5659e8: c5 ed e5 e4                  	vpmulhw	%ymm4, %ymm2, %ymm4
  5659ec: c4 c1 01 c4 ec 00            	vpinsrw	$0x0, %r12d, %xmm15, %xmm5
  5659f2: c4 e2 7d 79 f5               	vpbroadcastw	%xmm5, %ymm6
  5659f7: c4 e2 79 79 ed               	vpbroadcastw	%xmm5, %xmm5
  5659fc: c4 c1 51 c4 eb 00            	vpinsrw	$0x0, %r11d, %xmm5, %xmm5
  565a02: c4 e3 4d 38 ed 00            	vinserti128	$0x0, %xmm5, %ymm6, %ymm5
  565a08: c5 ed 75 f2                  	vpcmpeqw	%ymm2, %ymm2, %ymm6
  565a0c: c5 d5 65 d2                  	vpcmpgtw	%ymm2, %ymm5, %ymm2
  565a10: c5 ed ef d6                  	vpxor	%ymm6, %ymm2, %ymm2
  565a14: c5 dd db d2                  	vpand	%ymm2, %ymm4, %ymm2
  565a18: c5 f5 ef e2                  	vpxor	%ymm2, %ymm1, %ymm4
  565a1c: 90                           	nop
  565a1d: c5 dd f9 c9                  	vpsubw	%ymm1, %ymm4, %ymm1
  565a21: 4d 85 c9                     	testq	%r9, %r9
  565a24: 74 0a                        	je	0x565a30 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x330>
  565a26: c4 c1 7e 7f 09               	vmovdqu	%ymm1, (%r9)
  565a2b: 48 85 c9                     	testq	%rcx, %rcx
  565a2e: eb 03                        	jmp	0x565a33 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x333>
  565a30: 48 85 c9                     	testq	%rcx, %rcx
  565a33: c5 dd ef e4                  	vpxor	%ymm4, %ymm4, %ymm4
  565a37: c5 d5 d5 e9                  	vpmullw	%ymm1, %ymm5, %ymm5
  565a3b: 48 8b 9c 24 b8 00 00 00      	movq	0xb8(%rsp), %rbx
  565a43: c5 fe 7f 2b                  	vmovdqu	%ymm5, (%rbx)
  565a47: be 0b 00 00 00               	movl	$0xb, %esi
  565a4c: c4 e1 f9 6e ee               	vmovq	%rsi, %xmm5
  565a51: c5 f5 75 f1                  	vpcmpeqw	%ymm1, %ymm1, %ymm6
  565a55: c5 f5 75 cc                  	vpcmpeqw	%ymm4, %ymm1, %ymm1
  565a59: c5 f5 ef ce                  	vpxor	%ymm6, %ymm1, %ymm1
  565a5d: c5 f5 db 0f                  	vpand	(%rdi), %ymm1, %ymm1
  565a61: c5 f5 ee cc                  	vpmaxsw	%ymm4, %ymm1, %ymm1
  565a65: c4 e2 79 79 ed               	vpbroadcastw	%xmm5, %xmm5
  565a6a: 74 43                        	je	0x565aaf <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x3af>
  565a6c: c4 e3 7d 39 d6 00            	vextracti128	$0x0, %ymm2, %xmm6
  565a72: c5 c9 ea f5                  	vpminsw	%xmm5, %xmm6, %xmm6
  565a76: c4 e3 7d 39 d2 01            	vextracti128	$0x1, %ymm2, %xmm2
  565a7c: c5 e9 ea d5                  	vpminsw	%xmm5, %xmm2, %xmm2
  565a80: c5 fa 6f 3d c8 8e 22 00      	vmovdqu	0x228ec8(%rip), %xmm7   # 0x78e950 <github.com/thesyncim/govpx/internal/pixel.packByteIndices>
  565a88: c4 e2 49 00 f7               	vpshufb	%xmm7, %xmm6, %xmm6
  565a8d: c4 e2 69 00 d7               	vpshufb	%xmm7, %xmm2, %xmm2
  565a92: c4 e2 79 00 f6               	vpshufb	%xmm6, %xmm0, %xmm6
  565a97: c4 e3 f9 16 f6 00            	vpextrq	$0x0, %xmm6, %rsi
  565a9d: c4 e2 79 00 d2               	vpshufb	%xmm2, %xmm0, %xmm2
  565aa2: c4 c3 f9 16 d0 00            	vpextrq	$0x0, %xmm2, %r8
  565aa8: 48 89 31                     	movq	%rsi, (%rcx)
  565aab: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
  565aaf: 0f b7 b4 24 da 00 00 00      	movzwl	0xda(%rsp), %esi
  565ab7: 44 0f b7 84 24 de 00 00 00   	movzwl	0xde(%rsp), %r8d
  565ac0: 44 0f b7 94 24 e2 00 00 00   	movzwl	0xe2(%rsp), %r10d
  565ac9: c4 e1 f9 6e d6               	vmovq	%rsi, %xmm2
  565ace: c4 c1 f9 6e f0               	vmovq	%r8, %xmm6
  565ad3: c4 c1 f9 6e fa               	vmovq	%r10, %xmm7
  565ad8: c4 e2 7d 79 d2               	vpbroadcastw	%xmm2, %ymm2
  565add: c4 e2 7d 79 f6               	vpbroadcastw	%xmm6, %ymm6
  565ae2: c4 e2 7d 79 ff               	vpbroadcastw	%xmm7, %ymm7
  565ae7: be 10 00 00 00               	movl	$0x10, %esi
  565aec: e9 f8 03 00 00               	jmp	0x565ee9 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7e9>
  565af1: 44 0f b7 a4 24 da 00 00 00   	movzwl	0xda(%rsp), %r12d
  565afa: 44 0f b7 ac 24 de 00 00 00   	movzwl	0xde(%rsp), %r13d
  565b03: 44 0f b7 bc 24 e2 00 00 00   	movzwl	0xe2(%rsp), %r15d
  565b0c: 0f b7 bc 24 d8 00 00 00      	movzwl	0xd8(%rsp), %edi
  565b14: 44 0f b7 84 24 dc 00 00 00   	movzwl	0xdc(%rsp), %r8d
  565b1d: 0f b7 b4 24 e0 00 00 00      	movzwl	0xe0(%rsp), %esi
  565b25: c4 c1 f9 6e c4               	vmovq	%r12, %xmm0
  565b2a: c4 e2 79 79 c0               	vpbroadcastw	%xmm0, %xmm0
  565b2f: c4 c1 f9 6e cd               	vmovq	%r13, %xmm1
  565b34: c4 e2 79 79 c9               	vpbroadcastw	%xmm1, %xmm1
  565b39: c4 c1 f9 6e d7               	vmovq	%r15, %xmm2
  565b3e: c4 e2 79 79 d2               	vpbroadcastw	%xmm2, %xmm2
  565b43: 41 bc ff 7f 00 00            	movl	$0x7fff, %r12d          # imm = 0x7FFF
  565b49: c4 c1 f9 6e dc               	vmovq	%r12, %xmm3
  565b4e: c5 f9 c4 e7 00               	vpinsrw	$0x0, %edi, %xmm0, %xmm4
  565b53: c4 c1 71 c4 e8 00            	vpinsrw	$0x0, %r8d, %xmm1, %xmm5
  565b59: c5 e9 c4 f6 00               	vpinsrw	$0x0, %esi, %xmm2, %xmm6
  565b5e: 90                           	nop
  565b5f: c5 fa 6f 3d f9 8d 22 00      	vmovdqu	0x228df9(%rip), %xmm7   # 0x78e960 <github.com/thesyncim/govpx/internal/pixel.fpClassLUT>
  565b67: c4 e2 79 79 db               	vpbroadcastw	%xmm3, %xmm3
  565b6c: 45 31 e4                     	xorl	%r12d, %r12d
  565b6f: 45 0f 10 c7                  	movups	%xmm15, %xmm8
  565b73: 4c 8b ac 24 c0 00 00 00      	movq	0xc0(%rsp), %r13
  565b7b: 4c 8b bc 24 c8 00 00 00      	movq	0xc8(%rsp), %r15
  565b83: 48 8b b4 24 b8 00 00 00      	movq	0xb8(%rsp), %rsi
  565b8b: eb 26                        	jmp	0x565bb3 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x4b3>
  565b8d: 49 89 dd                     	movq	%rbx, %r13
  565b90: 4c 8b bc 24 c8 00 00 00      	movq	0xc8(%rsp), %r15
  565b98: 41 0f 10 e2                  	movups	%xmm10, %xmm4
  565b9c: 41 0f 10 eb                  	movups	%xmm11, %xmm5
  565ba0: 49 89 fc                     	movq	%rdi, %r12
  565ba3: 44 0f 10 c6                  	movups	%xmm6, %xmm8
  565ba7: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  565baf: 41 0f 10 f1                  	movups	%xmm9, %xmm6
  565bb3: 49 8d 7c 24 08               	leaq	0x8(%r12), %rdi
  565bb8: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)
  565bc0: 48 39 fa                     	cmpq	%rdi, %rdx
  565bc3: 0f 8c 14 02 00 00            	jl	0x565ddd <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x6dd>
  565bc9: 4d 85 e4                     	testq	%r12, %r12
  565bcc: 75 0e                        	jne	0x565bdc <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x4dc>
  565bce: 44 0f 10 ce                  	movups	%xmm6, %xmm9
  565bd2: 44 0f 10 d4                  	movups	%xmm4, %xmm10
  565bd6: 44 0f 10 dd                  	movups	%xmm5, %xmm11
  565bda: eb 15                        	jmp	0x565bf1 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x4f1>
  565bdc: 44 0f 10 ce                  	movups	%xmm6, %xmm9
  565be0: 44 0f 10 d4                  	movups	%xmm4, %xmm10
  565be4: 44 0f 10 dd                  	movups	%xmm5, %xmm11
  565be8: 0f 10 f2                     	movups	%xmm2, %xmm6
  565beb: 0f 10 e0                     	movups	%xmm0, %xmm4
  565bee: 0f 10 e9                     	movups	%xmm1, %xmm5
  565bf1: 4c 39 e3                     	cmpq	%r12, %rbx
  565bf4: 0f 82 e4 02 00 00            	jb	0x565ede <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7de>
  565bfa: 4c 89 a4 24 a0 00 00 00      	movq	%r12, 0xa0(%rsp)
  565c02: 4f 8d 04 24                  	leaq	(%r12,%r12), %r8
  565c06: 4c 29 e3                     	subq	%r12, %rbx
  565c09: 49 29 cc                     	subq	%rcx, %r12
  565c0c: 49 c1 fc 3f                  	sarq	$0x3f, %r12
  565c10: 4d 21 c4                     	andq	%r8, %r12
  565c13: 49 01 c4                     	addq	%rax, %r12
  565c16: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
  565c1f: 90                           	nop
  565c20: 48 83 fb 08                  	cmpq	$0x8, %rbx
  565c24: 0f 82 af 02 00 00            	jb	0x565ed9 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7d9>
  565c2a: c4 41 7a 6f 24 24            	vmovdqu	(%r12), %xmm12
  565c30: c4 42 79 1d ec               	vpabsw	%xmm12, %xmm13
  565c35: c5 91 fd e4                  	vpaddw	%xmm4, %xmm13, %xmm4
  565c39: c4 e2 59 3a e3               	vpminuw	%xmm3, %xmm4, %xmm4
  565c3e: c5 d9 e5 ed                  	vpmulhw	%xmm5, %xmm4, %xmm5
  565c42: c5 59 75 ec                  	vpcmpeqw	%xmm4, %xmm4, %xmm13
  565c46: c5 c9 65 e4                  	vpcmpgtw	%xmm4, %xmm6, %xmm4
  565c4a: c4 c1 59 ef e5               	vpxor	%xmm13, %xmm4, %xmm4
  565c4f: c5 d1 db e4                  	vpand	%xmm4, %xmm5, %xmm4
  565c53: 41 0f 10 ef                  	movups	%xmm15, %xmm5
  565c57: c5 51 f9 ec                  	vpsubw	%xmm4, %xmm5, %xmm13
  565c5b: c4 41 51 65 e4               	vpcmpgtw	%xmm12, %xmm5, %xmm12
  565c60: 90                           	nop
  565c61: 90                           	nop
  565c62: 90                           	nop
  565c63: c4 43 59 4c e5 c0            	vpblendvb	%xmm12, %xmm13, %xmm4, %xmm12
  565c69: 4d 85 c9                     	testq	%r9, %r9
  565c6c: 74 34                        	je	0x565ca2 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x5a2>
  565c6e: 4c 8b a4 24 a0 00 00 00      	movq	0xa0(%rsp), %r12
  565c76: 4d 39 e2                     	cmpq	%r12, %r10
  565c79: 0f 82 55 02 00 00            	jb	0x565ed4 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7d4>
  565c7f: 4c 89 d3                     	movq	%r10, %rbx
  565c82: 4c 29 e3                     	subq	%r12, %rbx
  565c85: 4d 29 dc                     	subq	%r11, %r12
  565c88: 49 c1 fc 3f                  	sarq	$0x3f, %r12
  565c8c: 4d 21 c4                     	andq	%r8, %r12
  565c8f: 4d 01 cc                     	addq	%r9, %r12
  565c92: 48 83 fb 08                  	cmpq	$0x8, %rbx
  565c96: 0f 82 33 02 00 00            	jb	0x565ecf <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7cf>
  565c9c: c4 41 7a 7f 24 24            	vmovdqu	%xmm12, (%r12)
  565ca2: c5 99 d5 f6                  	vpmullw	%xmm6, %xmm12, %xmm6
  565ca6: 4c 8b a4 24 a0 00 00 00      	movq	0xa0(%rsp), %r12
  565cae: 4d 39 e5                     	cmpq	%r12, %r13
  565cb1: 0f 82 13 02 00 00            	jb	0x565eca <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7ca>
  565cb7: 4c 89 eb                     	movq	%r13, %rbx
  565cba: 4d 29 e5                     	subq	%r12, %r13
  565cbd: 4d 29 fc                     	subq	%r15, %r12
  565cc0: 49 c1 fc 3f                  	sarq	$0x3f, %r12
  565cc4: 4d 21 c4                     	andq	%r8, %r12
  565cc7: 49 01 f4                     	addq	%rsi, %r12
  565cca: 49 83 fd 08                  	cmpq	$0x8, %r13
  565cce: 0f 82 f1 01 00 00            	jb	0x565ec5 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7c5>
  565cd4: c4 c1 7a 7f 34 24            	vmovdqu	%xmm6, (%r12)
  565cda: 4c 8b a4 24 20 01 00 00      	movq	0x120(%rsp), %r12
  565ce2: 4c 8b ac 24 a0 00 00 00      	movq	0xa0(%rsp), %r13
  565cea: 4d 39 ec                     	cmpq	%r13, %r12
  565ced: 0f 82 cb 01 00 00            	jb	0x565ebe <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7be>
  565cf3: 4d 29 ec                     	subq	%r13, %r12
  565cf6: 4c 8b bc 24 28 01 00 00      	movq	0x128(%rsp), %r15
  565cfe: 4d 29 fd                     	subq	%r15, %r13
  565d01: 49 c1 fd 3f                  	sarq	$0x3f, %r13
  565d05: 4d 21 c5                     	andq	%r8, %r13
  565d08: 4d 89 f8                     	movq	%r15, %r8
  565d0b: 4c 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %r15
  565d13: 4d 01 fd                     	addq	%r15, %r13
  565d16: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
  565d1f: 90                           	nop
  565d20: 49 83 fc 08                  	cmpq	$0x8, %r12
  565d24: 0f 82 8f 01 00 00            	jb	0x565eb9 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7b9>
  565d2a: c4 c1 19 75 f4               	vpcmpeqw	%xmm12, %xmm12, %xmm6
  565d2f: c5 19 75 e5                  	vpcmpeqw	%xmm5, %xmm12, %xmm12
  565d33: c5 99 ef f6                  	vpxor	%xmm6, %xmm12, %xmm6
  565d37: c4 c1 49 db 75 00            	vpand	(%r13), %xmm6, %xmm6
  565d3d: c5 b9 ee f6                  	vpmaxsw	%xmm6, %xmm8, %xmm6
  565d41: 4c 8b a4 24 e8 00 00 00      	movq	0xe8(%rsp), %r12
  565d49: 4d 85 e4                     	testq	%r12, %r12
  565d4c: 0f 84 3b fe ff ff            	je	0x565b8d <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x48d>
  565d52: 41 bd 0b 00 00 00            	movl	$0xb, %r13d
  565d58: c4 41 f9 6e c5               	vmovq	%r13, %xmm8
  565d5d: c4 42 79 79 c0               	vpbroadcastw	%xmm8, %xmm8
  565d62: c4 c1 59 ea e0               	vpminsw	%xmm8, %xmm4, %xmm4
  565d67: 4c 8b ac 24 f0 00 00 00      	movq	0xf0(%rsp), %r13
  565d6f: 4c 8b bc 24 a0 00 00 00      	movq	0xa0(%rsp), %r15
  565d77: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
  565d80: 4d 39 fd                     	cmpq	%r15, %r13
  565d83: 0f 82 2b 01 00 00            	jb	0x565eb4 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7b4>
  565d89: 4d 29 fd                     	subq	%r15, %r13
  565d8c: 48 8b 94 24 f8 00 00 00      	movq	0xf8(%rsp), %rdx
  565d94: 49 29 d7                     	subq	%rdx, %r15
  565d97: 49 c1 ff 3f                  	sarq	$0x3f, %r15
  565d9b: c4 e2 59 00 25 ac 8b 22 00   	vpshufb	0x228bac(%rip), %xmm4, %xmm4 # 0x78e950 <github.com/thesyncim/govpx/internal/pixel.packByteIndices>
  565da4: 48 8b 94 24 a0 00 00 00      	movq	0xa0(%rsp), %rdx
  565dac: 4c 21 fa                     	andq	%r15, %rdx
  565daf: c4 e2 41 00 e4               	vpshufb	%xmm4, %xmm7, %xmm4
  565db4: 49 83 fd 07                  	cmpq	$0x7, %r13
  565db8: 0f 86 f1 00 00 00            	jbe	0x565eaf <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7af>
  565dbe: c4 c3 f9 16 e5 00            	vpextrq	$0x0, %xmm4, %r13
  565dc4: 4d 89 2c 14                  	movq	%r13, (%r12,%rdx)
  565dc8: 48 8b 94 24 d0 00 00 00      	movq	0xd0(%rsp), %rdx
  565dd0: 4c 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %r15
  565dd8: e9 b0 fd ff ff               	jmp	0x565b8d <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x48d>
  565ddd: c4 c2 79 23 c0               	vpmovsxwd	%xmm8, %xmm0
  565de2: c4 c1 79 70 c8 4e            	vpshufd	$0x4e, %xmm8, %xmm1     # xmm1 = xmm8[2,3,0,1]
  565de8: c4 e2 79 23 c9               	vpmovsxwd	%xmm1, %xmm1
  565ded: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  565df2: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     # xmm1 = xmm0[2,3,0,1]
  565df7: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  565dfc: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     # xmm1 = xmm0[1,0,3,2]
  565e01: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  565e06: c4 e3 79 16 c7 00            	vpextrd	$0x0, %xmm0, %edi
  565e0c: 48 63 ff                     	movslq	%edi, %rdi
  565e0f: 48 89 bc 24 98 00 00 00      	movq	%rdi, 0x98(%rsp)
  565e17: 48 89 34 24                  	movq	%rsi, (%rsp)
  565e1b: 4c 89 6c 24 08               	movq	%r13, 0x8(%rsp)
  565e20: 4c 89 7c 24 10               	movq	%r15, 0x10(%rsp)
  565e25: 4c 89 64 24 18               	movq	%r12, 0x18(%rsp)
  565e2a: 48 89 54 24 20               	movq	%rdx, 0x20(%rsp)
  565e2f: 8b 94 24 d8 00 00 00         	movl	0xd8(%rsp), %edx
  565e36: 89 54 24 28                  	movl	%edx, 0x28(%rsp)
  565e3a: 8b 94 24 dc 00 00 00         	movl	0xdc(%rsp), %edx
  565e41: 89 54 24 2c                  	movl	%edx, 0x2c(%rsp)
  565e45: 8b 94 24 e0 00 00 00         	movl	0xe0(%rsp), %edx
  565e4c: 89 54 24 30                  	movl	%edx, 0x30(%rsp)
  565e50: 48 8b 94 24 e8 00 00 00      	movq	0xe8(%rsp), %rdx
  565e58: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
  565e5d: 48 8b 94 24 f0 00 00 00      	movq	0xf0(%rsp), %rdx
  565e65: 48 89 54 24 40               	movq	%rdx, 0x40(%rsp)
  565e6a: 48 8b 94 24 f8 00 00 00      	movq	0xf8(%rsp), %rdx
  565e72: 48 89 54 24 48               	movq	%rdx, 0x48(%rsp)
  565e77: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  565e7f: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  565e87: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  565e8f: e8 cc f3 ff ff               	callq	0x565260 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockTail>
  565e94: 48 8b 94 24 98 00 00 00      	movq	0x98(%rsp), %rdx
  565e9c: 48 39 d0                     	cmpq	%rdx, %rax
  565e9f: 48 0f 4f d0                  	cmovgq	%rax, %rdx
  565ea3: 48 89 d0                     	movq	%rdx, %rax
  565ea6: 48 81 c4 a8 00 00 00         	addq	$0xa8, %rsp
  565ead: 5d                           	popq	%rbp
  565eae: c3                           	retq
  565eaf: e8 4c 76 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565eb4: e8 47 76 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565eb9: e8 42 76 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565ebe: 66 90                        	nop
  565ec0: e8 3b 76 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565ec5: e8 36 76 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565eca: e8 31 76 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565ecf: e8 2c 76 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565ed4: e8 27 76 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565ed9: e8 22 76 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565ede: 66 90                        	nop
  565ee0: e8 1b 76 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565ee5: 48 83 c6 10                  	addq	$0x10, %rsi
  565ee9: 48 39 f2                     	cmpq	%rsi, %rdx
  565eec: 0f 8e d3 00 00 00            	jle	0x565fc5 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x8c5>
  565ef2: 4c 8d 04 70                  	leaq	(%rax,%rsi,2), %r8
  565ef6: c4 41 7e 6f 00               	vmovdqu	(%r8), %ymm8
  565efb: c4 42 7d 1d c8               	vpabsw	%ymm8, %ymm9
  565f00: c5 35 fd ca                  	vpaddw	%ymm2, %ymm9, %ymm9
  565f04: c4 62 35 3a cb               	vpminuw	%ymm3, %ymm9, %ymm9
  565f09: c5 35 e5 d6                  	vpmulhw	%ymm6, %ymm9, %ymm10
  565f0d: c4 c1 3d 71 e0 0f            	vpsraw	$0xf, %ymm8, %ymm8
  565f13: c4 41 35 75 d9               	vpcmpeqw	%ymm9, %ymm9, %ymm11
  565f18: c4 41 45 65 c9               	vpcmpgtw	%ymm9, %ymm7, %ymm9
  565f1d: c4 41 35 ef cb               	vpxor	%ymm11, %ymm9, %ymm9
  565f22: c4 41 2d db c9               	vpand	%ymm9, %ymm10, %ymm9
  565f27: c4 41 3d ef d1               	vpxor	%ymm9, %ymm8, %ymm10
  565f2c: c4 41 2d f9 c0               	vpsubw	%ymm8, %ymm10, %ymm8
  565f31: 4d 85 c9                     	testq	%r9, %r9
  565f34: 74 0e                        	je	0x565f44 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x844>
  565f36: 4d 8d 04 71                  	leaq	(%r9,%rsi,2), %r8
  565f3a: c4 41 7e 7f 00               	vmovdqu	%ymm8, (%r8)
  565f3f: 48 85 c9                     	testq	%rcx, %rcx
  565f42: eb 03                        	jmp	0x565f47 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x847>
  565f44: 48 85 c9                     	testq	%rcx, %rcx
  565f47: c4 41 45 d5 d0               	vpmullw	%ymm8, %ymm7, %ymm10
  565f4c: 4c 8d 04 73                  	leaq	(%rbx,%rsi,2), %r8
  565f50: c4 41 7e 7f 10               	vmovdqu	%ymm10, (%r8)
  565f55: 4c 8d 04 77                  	leaq	(%rdi,%rsi,2), %r8
  565f59: c4 41 3d 75 d0               	vpcmpeqw	%ymm8, %ymm8, %ymm10
  565f5e: c5 3d 75 c4                  	vpcmpeqw	%ymm4, %ymm8, %ymm8
  565f62: c4 41 3d ef c2               	vpxor	%ymm10, %ymm8, %ymm8
  565f67: c4 41 3d db 00               	vpand	(%r8), %ymm8, %ymm8
  565f6c: c4 c1 75 ee c8               	vpmaxsw	%ymm8, %ymm1, %ymm1
  565f71: 0f 84 6e ff ff ff            	je	0x565ee5 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7e5>
  565f77: c4 43 7d 39 c8 00            	vextracti128	$0x0, %ymm9, %xmm8
  565f7d: c5 39 ea c5                  	vpminsw	%xmm5, %xmm8, %xmm8
  565f81: c4 43 7d 39 c9 01            	vextracti128	$0x1, %ymm9, %xmm9
  565f87: c5 31 ea cd                  	vpminsw	%xmm5, %xmm9, %xmm9
  565f8b: c5 7a 6f 15 bd 89 22 00      	vmovdqu	0x2289bd(%rip), %xmm10  # 0x78e950 <github.com/thesyncim/govpx/internal/pixel.packByteIndices>
  565f93: c4 42 39 00 c2               	vpshufb	%xmm10, %xmm8, %xmm8
  565f98: c4 42 31 00 ca               	vpshufb	%xmm10, %xmm9, %xmm9
  565f9d: c4 42 79 00 c0               	vpshufb	%xmm8, %xmm0, %xmm8
  565fa2: c4 43 f9 16 c0 00            	vpextrq	$0x0, %xmm8, %r8
  565fa8: c4 42 79 00 c1               	vpshufb	%xmm9, %xmm0, %xmm8
  565fad: c4 43 f9 16 c2 00            	vpextrq	$0x0, %xmm8, %r10
  565fb3: 4c 89 04 31                  	movq	%r8, (%rcx,%rsi)
  565fb7: 4c 89 54 0e 08               	movq	%r10, 0x8(%rsi,%rcx)
  565fbc: 0f 1f 40 00                  	nopl	(%rax)
  565fc0: e9 20 ff ff ff               	jmp	0x565ee5 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7e5>
  565fc5: c4 e3 7d 39 c8 00            	vextracti128	$0x0, %ymm1, %xmm0
  565fcb: c4 e3 7d 39 c9 01            	vextracti128	$0x1, %ymm1, %xmm1
  565fd1: c5 f1 ee c0                  	vpmaxsw	%xmm0, %xmm1, %xmm0
  565fd5: c4 e2 79 23 c8               	vpmovsxwd	%xmm0, %xmm1
  565fda: c5 f9 70 c0 4e               	vpshufd	$0x4e, %xmm0, %xmm0     # xmm0 = xmm0[2,3,0,1]
  565fdf: c4 e2 79 23 c0               	vpmovsxwd	%xmm0, %xmm0
  565fe4: c4 e2 79 3d c1               	vpmaxsd	%xmm1, %xmm0, %xmm0
  565fe9: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     # xmm1 = xmm0[2,3,0,1]
  565fee: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  565ff3: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     # xmm1 = xmm0[1,0,3,2]
  565ff8: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  565ffd: c4 e3 79 16 c1 00            	vpextrd	$0x0, %xmm0, %ecx
  566003: 48 63 c1                     	movslq	%ecx, %rax
  566006: c5 f8 77                     	vzeroupper
  566009: 48 81 c4 a8 00 00 00         	addq	$0xa8, %rsp
  566010: 5d                           	popq	%rbp
  566011: c3                           	retq
  566012: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
  566017: 48 89 5c 24 58               	movq	%rbx, 0x58(%rsp)
  56601c: 48 89 4c 24 60               	movq	%rcx, 0x60(%rsp)
  566021: 48 89 7c 24 68               	movq	%rdi, 0x68(%rsp)
  566026: 48 89 74 24 70               	movq	%rsi, 0x70(%rsp)
  56602b: 4c 89 44 24 78               	movq	%r8, 0x78(%rsp)
  566030: 4c 89 8c 24 80 00 00 00      	movq	%r9, 0x80(%rsp)
  566038: 4c 89 94 24 88 00 00 00      	movq	%r10, 0x88(%rsp)
  566040: 4c 89 9c 24 90 00 00 00      	movq	%r11, 0x90(%rsp)
  566048: e8 73 58 f2 ff               	callq	0x48b8c0 <runtime.morestack_noctxt.abi0>
  56604d: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
  566052: 48 8b 5c 24 58               	movq	0x58(%rsp), %rbx
  566057: 48 8b 4c 24 60               	movq	0x60(%rsp), %rcx
  56605c: 48 8b 7c 24 68               	movq	0x68(%rsp), %rdi
  566061: 48 8b 74 24 70               	movq	0x70(%rsp), %rsi
  566066: 4c 8b 44 24 78               	movq	0x78(%rsp), %r8
  56606b: 4c 8b 8c 24 80 00 00 00      	movq	0x80(%rsp), %r9
  566073: 4c 8b 94 24 88 00 00 00      	movq	0x88(%rsp), %r10
  56607b: 4c 8b 9c 24 90 00 00 00      	movq	0x90(%rsp), %r11
  566083: e9 78 f6 ff ff               	jmp	0x565700 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD>
  566088: cc                           	int3
  566089: cc                           	int3
  56608a: cc                           	int3
  56608b: cc                           	int3
  56608c: cc                           	int3
  56608d: cc                           	int3
  56608e: cc                           	int3
  56608f: cc                           	int3
  566090: cc                           	int3
  566091: cc                           	int3
  566092: cc                           	int3
  566093: cc                           	int3
  566094: cc                           	int3
  566095: cc                           	int3
  566096: cc                           	int3
  566097: cc                           	int3
  566098: cc                           	int3
  566099: cc                           	int3
  56609a: cc                           	int3
  56609b: cc                           	int3
  56609c: cc                           	int3
  56609d: cc                           	int3
  56609e: cc                           	int3
  56609f: cc                           	int3

00000000005660a0 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>:
  5660a0: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
  5660a5: 48 89 7c 24 58               	movq	%rdi, 0x58(%rsp)
  5660aa: 4c 89 4c 24 70               	movq	%r9, 0x70(%rsp)
  5660af: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
  5660b4: 48 89 ca                     	movq	%rcx, %rdx
  5660b7: 48 c1 e1 02                  	shlq	$0x2, %rcx
  5660bb: 48 ff c9                     	decq	%rcx
  5660be: 48 89 fb                     	movq	%rdi, %rbx
  5660c1: 48 29 c7                     	subq	%rax, %rdi
  5660c4: 48 8d 34 57                  	leaq	(%rdi,%rdx,2), %rsi
  5660c8: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
  5660cc: 48 39 ce                     	cmpq	%rcx, %rsi
  5660cf: 72 2b                        	jb	0x5660fc <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x5c>
  5660d1: 48 8b 74 24 08               	movq	0x8(%rsp), %rsi
  5660d6: 48 89 f7                     	movq	%rsi, %rdi
  5660d9: 48 29 c6                     	subq	%rax, %rsi
  5660dc: 48 8d 34 56                  	leaq	(%rsi,%rdx,2), %rsi
  5660e0: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
  5660e4: 48 39 ce                     	cmpq	%rcx, %rsi
  5660e7: 72 13                        	jb	0x5660fc <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x5c>
  5660e9: 48 89 fe                     	movq	%rdi, %rsi
  5660ec: 48 29 df                     	subq	%rbx, %rdi
  5660ef: 48 8d 3c 57                  	leaq	(%rdi,%rdx,2), %rdi
  5660f3: 48 8d 7f ff                  	leaq	-0x1(%rdi), %rdi
  5660f7: 48 39 cf                     	cmpq	%rcx, %rdi
  5660fa: 73 04                        	jae	0x566100 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x60>
  5660fc: 31 c0                        	xorl	%eax, %eax
  5660fe: c3                           	retq
  5660ff: 90                           	nop
  566100: 4d 85 c9                     	testq	%r9, %r9
  566103: 74 3c                        	je	0x566141 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa1>
  566105: 4c 89 cf                     	movq	%r9, %rdi
  566108: 4d 89 c8                     	movq	%r9, %r8
  56610b: 49 29 c1                     	subq	%rax, %r9
  56610e: 4d 8d 0c 51                  	leaq	(%r9,%rdx,2), %r9
  566112: 4d 8d 49 ff                  	leaq	-0x1(%r9), %r9
  566116: 49 39 c9                     	cmpq	%rcx, %r9
  566119: 72 23                        	jb	0x56613e <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x9e>
  56611b: 4d 89 c1                     	movq	%r8, %r9
  56611e: 49 29 d8                     	subq	%rbx, %r8
  566121: 4d 8d 04 50                  	leaq	(%r8,%rdx,2), %r8
  566125: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  566129: 49 39 c8                     	cmpq	%rcx, %r8
  56612c: 72 10                        	jb	0x56613e <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x9e>
  56612e: 49 29 f1                     	subq	%rsi, %r9
  566131: 4d 8d 04 51                  	leaq	(%r9,%rdx,2), %r8
  566135: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  566139: 49 39 c8                     	cmpq	%rcx, %r8
  56613c: 73 06                        	jae	0x566144 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa4>
  56613e: 31 c0                        	xorl	%eax, %eax
  566140: c3                           	retq
  566141: 4c 89 cf                     	movq	%r9, %rdi
  566144: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
  566149: 48 85 c9                     	testq	%rcx, %rcx
  56614c: 74 5c                        	je	0x5661aa <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
  56614e: 4c 8d 04 52                  	leaq	(%rdx,%rdx,2), %r8
  566152: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  566156: 49 89 c9                     	movq	%rcx, %r9
  566159: 48 29 c1                     	subq	%rax, %rcx
  56615c: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
  566160: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  566164: 49 39 c8                     	cmpq	%rcx, %r8
  566167: 77 26                        	ja	0x56618f <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xef>
  566169: 4c 89 c9                     	movq	%r9, %rcx
  56616c: 49 29 d9                     	subq	%rbx, %r9
  56616f: 49 8d 1c 11                  	leaq	(%r9,%rdx), %rbx
  566173: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
  566177: 49 39 d8                     	cmpq	%rbx, %r8
  56617a: 77 13                        	ja	0x56618f <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xef>
  56617c: 48 89 cb                     	movq	%rcx, %rbx
  56617f: 48 29 f1                     	subq	%rsi, %rcx
  566182: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
  566186: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  56618a: 49 39 c8                     	cmpq	%rcx, %r8
  56618d: 76 03                        	jbe	0x566192 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xf2>
  56618f: 31 c0                        	xorl	%eax, %eax
  566191: c3                           	retq
  566192: 48 85 ff                     	testq	%rdi, %rdi
  566195: 74 13                        	je	0x5661aa <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
  566197: 48 29 fb                     	subq	%rdi, %rbx
  56619a: 48 8d 0c 13                  	leaq	(%rbx,%rdx), %rcx
  56619e: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  5661a2: 49 39 c8                     	cmpq	%rcx, %r8
  5661a5: 76 03                        	jbe	0x5661aa <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
  5661a7: 31 c0                        	xorl	%eax, %eax
  5661a9: c3                           	retq
  5661aa: b8 01 00 00 00               	movl	$0x1, %eax
  5661af: c3                           	retq
  5661b0: cc                           	int3
  5661b1: cc                           	int3
  5661b2: cc                           	int3
  5661b3: cc                           	int3
  5661b4: cc                           	int3
  5661b5: cc                           	int3
  5661b6: cc                           	int3
  5661b7: cc                           	int3
  5661b8: cc                           	int3
  5661b9: cc                           	int3
  5661ba: cc                           	int3
  5661bb: cc                           	int3
  5661bc: cc                           	int3
  5661bd: cc                           	int3
  5661be: cc                           	int3
  5661bf: cc                           	int3

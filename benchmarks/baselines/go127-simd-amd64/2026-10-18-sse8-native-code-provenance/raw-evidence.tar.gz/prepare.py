from pathlib import Path
import subprocess,json,difflib,hashlib,ast
w=Path('/private/tmp/govpx-sse8-focused-codegen-proposal');root=Path('/Users/thesyncim/GolandProjects/govpx');overlay=w/'overlay'
old=subprocess.check_output(['git','show','46a08f8e:scripts/benchmark-sse8-amd64.sh'],cwd=root,text=True)
anchor='phase=summary\n';assert old.count(anchor)==1
hook='''# Preserve only relevant native code after every timed process has finished.
# Wrapper functions may be inlined/dead-stripped; keep actual B.Loop caller
# plus current helper or old lowercase/variance assembly symbols instead.
phase=codegen
for variant in head base assembly; do
 python3 "$root/scripts/capture-sse8-codegen.py" "$variant" "$scratch/$variant.test" "$output_dir"
done

'''
arg=' "$root/scripts/capture-sse8-codegen.py"'
sha='sha256sum "$driver_path" "$root/scripts/go.sh" "$root/.github/workflows/sse8-amd64-bench.yml"'
assert old.count(sha)==1;new=old.replace(anchor,hook+anchor).replace(sha,sha+arg)
assert new.replace(hook,'').replace(sha+arg,sha)==old
f=overlay/'scripts/benchmark-sse8-amd64.sh';f.write_text(new);f.chmod(0o755)
wf=subprocess.check_output(['git','show','46a08f8e:.github/workflows/sse8-amd64-bench.yml'],cwd=root,text=True)
step='''      - name: Verify GNU native code capture tools
        run: |
          command -v objdump
          objdump --version | grep '^GNU objdump'

'''
needle='      - name: Compare all 36 public SSE8 cases in six balanced rounds\n';assert wf.count(needle)==1;newwf=wf.replace(needle,step+needle);assert newwf.replace(step,'')==wf
(overlay/'.github/workflows/sse8-amd64-bench.yml').write_text(newwf)
subprocess.run(['sh','-n',str(f)],check=True);ast.parse((overlay/'scripts/capture-sse8-codegen.py').read_text())
(w/'proposal.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/scripts/benchmark-sse8-amd64.sh',tofile='b/scripts/benchmark-sse8-amd64.sh'))+''.join(difflib.unified_diff(wf.splitlines(True),newwf.splitlines(True),fromfile='a/.github/workflows/sse8-amd64-bench.yml',tofile='b/.github/workflows/sse8-amd64-bench.yml')))
scope=dict(old_native_rawfiles=45,new_rawfiles=55,additions=['codegen-tools.txt']+[f'{v}-codegen{suffix}' for v in ['head','base','assembly'] for suffix in ['.txt','.json','-symbols.txt']],timed_statements_unchanged=True,public_cases=36,legacy_diagnostic_cases=4,measured_samples=720,excluded_one_shots=120,variant_order_permutations_unchanged=True,post_timing_only=True,go_nm_fallback='rootwrapper go run cmd/nm only if go tool nm unavailable',decoder='GNU objdump only; missing/nonGNU explicitfailure',no_binary_blobs=True,no_root_changes=True,validation='sh-n+PythonAST/staticpreservation; no GNU native execution locally')
scope['overlay_sha256']={str(p.relative_to(overlay)):hashlib.sha256(p.read_bytes()).hexdigest() for p in overlay.rglob('*') if p.is_file()};(w/'scope.json').write_text(json.dumps(scope,indent=2));print(json.dumps(scope,indent=2))

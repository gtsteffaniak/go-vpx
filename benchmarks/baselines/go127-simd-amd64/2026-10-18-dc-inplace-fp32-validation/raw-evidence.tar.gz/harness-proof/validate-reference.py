from pathlib import Path
import os,subprocess,json,re,hashlib
p=Path('/private/tmp/govpx-pr49-native-harness-proposal');o=p/'overlay';r=Path('/Users/thesyncim/GolandProjects/govpx');out=p/'validation';out.mkdir(exist_ok=True)
references={'previous':Path('/private/tmp/govpx-next-dc-pair-inplace48/base48'),'assembly':Path('/private/tmp/govpx-next-dc-pair-inplace48/old691'),'simd':Path('/private/tmp/govpx-arm49-combined/candidate')}
e=os.environ.copy();e.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci49-ref-oracle',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',CGO_ENABLED='1');e.pop('GOOS',None);e.pop('GOARCH',None)
f='internal/vp8/dsp/dc_pair_inplace_native_bench_test.go';shim='internal/vp8/dsp/dc_pair_inplace_reference_shim_test.go';records=[]
for v,b in references.items():
 mapping={str(b/f):str(o/f)}
 if v!='simd':mapping[str(b/shim)]=str(o/'scripts/benchmark-fixtures/dc_pair_inplace_reference_shim.go.txt')
 ov=out/(v+'-overlay.json');ov.write_text(json.dumps({'Replace':mapping},indent=2));cmd=[str(r/'scripts/go.sh'),'-C',str(b),'test','-pgo=off','-overlay',str(ov),'-run','^$','-bench','^BenchmarkDCPairInPlaceRowsNative$','-benchtime=1x','-count=1','-cpu=1','-benchmem','./internal/vp8/dsp']
 with(out/(v+'-oneshot.log')).open('w')as fstream:subprocess.run(cmd,cwd=r,env=e,stdout=fstream,stderr=subprocess.STDOUT,check=True)
 text=(out/(v+'-oneshot.log')).read_text();rows=[line for line in text.splitlines()if line.startswith('BenchmarkDCPairInPlaceRowsNative/')and'B/op'in line];assert len(rows)==18 and all(re.search(r'\s0 B/op\s+0 allocs/op',line)for line in rows),(v,len(rows))
 records.append({'variant':v,'snapshot':str(b),'argv':cmd,'Go_overlay':str(ov),'excluded_oneshots':18,'all_zeroalloc_fullbacking_oracles':True,'ordinary_Go_test_not_throughput':True});print(v+'18 DC public oneshots PASS0alloc',flush=True)
# Source inventory is resolved from exact prospective production, not the currently frozen root.
paths=json.loads((p/'source-sha-paths.json').read_text());sources={}
for f in paths:
 q=next((q for q in (o/f,references['simd']/f,r/f)if q.exists()),None);assert q,f;sources[f]={'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'read_path':str(q)}
assert len(sources)==116
quant='internal/pixel/quantize_fp_amd64.go';assert sources[quant]['sha256']=='e309d5193e77713e51b6a8174e582973e32d121b52d2d56b2f63e078d134a0e2'
(out/'source-inventory.json').write_text(json.dumps(sources,indent=2)+'\n')
(out/'reference-proof.json').write_text(json.dumps({'records':records,'excluded_total':54,'SDK':'go1.27.2','CGO':1,'platform':'native darwin/arm64 correctness1x only','shared_fixture_sha256':hashlib.sha256((o/f if False else o/'internal/vp8/dsp/dc_pair_inplace_native_bench_test.go').read_bytes()).hexdigest(),'references_unchanged_overlay_only':True,'native_or_translated_throughput_measurements':0},indent=2)+'\n');print('END ALL GO/BUILD/JOBS STOPPED',flush=True)

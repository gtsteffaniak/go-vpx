
/private/tmp/govpx-root49-amd64-validation/internal-pixel.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

0000000001157dc0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512>:
 1157dc0: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
 1157dc5: 48 89 7c 24 68               	movq	%rdi, 0x68(%rsp)
 1157dca: 4c 89 8c 24 80 00 00 00      	movq	%r9, 0x80(%rsp)
 1157dd2: 90                           	nop
 1157dd3: 62 f1 fd 48 ef c0            	vpxorq	%zmm0, %zmm0, %zmm0
 1157dd9: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
 1157dde: 66 90                        	nop
 1157de0: 48 85 c9                     	testq	%rcx, %rcx
 1157de3: 74 0a                        	je	0x1157def <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x2f>
 1157de5: 62 f1 fe 48 6f 05 b1 e0 21 00	vmovdqu64	0x21e0b1(%rip), %zmm0 ## 0x1375ea0 <_github.com/thesyncim/govpx/internal/pixel.fpClassWordLUT32>
 1157def: 62 f1 f5 48 ef c9            	vpxorq	%zmm1, %zmm1, %zmm1
 1157df5: 0f b7 54 24 2a               	movzwl	0x2a(%rsp), %edx
 1157dfa: 0f b7 5c 24 28               	movzwl	0x28(%rsp), %ebx
 1157dff: 0f b7 74 24 2e               	movzwl	0x2e(%rsp), %esi
 1157e04: 44 0f b7 44 24 2c            	movzwl	0x2c(%rsp), %r8d
 1157e0a: 44 0f b7 54 24 32            	movzwl	0x32(%rsp), %r10d
 1157e10: 44 0f b7 5c 24 30            	movzwl	0x30(%rsp), %r11d
 1157e16: 62 f1 fe 48 6f 10            	vmovdqu64	(%rax), %zmm2
 1157e1c: 62 f2 7d 48 1d da            	vpabsw	%zmm2, %zmm3
 1157e22: 62 f3 ed 48 3f c9 01         	vpcmpltw	%zmm1, %zmm2, %k1
 1157e29: 41 bc ff 7f 00 00            	movl	$0x7fff, %r12d          ## imm = 0x7FFF
 1157e2f: c4 c1 f9 6e d4               	vmovq	%r12, %xmm2
 1157e34: 62 f2 7d 48 79 d2            	vpbroadcastw	%xmm2, %zmm2
 1157e3a: c5 81 c4 e2 00               	vpinsrw	$0x0, %edx, %xmm15, %xmm4
 1157e3f: 62 f2 7d 48 79 ec            	vpbroadcastw	%xmm4, %zmm5
 1157e45: c4 e2 7d 79 f4               	vpbroadcastw	%xmm4, %ymm6
 1157e4a: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
 1157e4f: c5 d9 c4 e3 00               	vpinsrw	$0x0, %ebx, %xmm4, %xmm4
 1157e54: c4 e3 4d 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm6, %ymm4
 1157e5a: 62 f3 d5 48 3a e4 00         	vinserti64x4	$0x0, %ymm4, %zmm5, %zmm4
 1157e61: 62 f1 5d 48 fd db            	vpaddw	%zmm3, %zmm4, %zmm3
 1157e67: 62 f2 65 48 3a da            	vpminuw	%zmm2, %zmm3, %zmm3
 1157e6d: c5 81 c4 e6 00               	vpinsrw	$0x0, %esi, %xmm15, %xmm4
 1157e72: 62 f2 7d 48 79 ec            	vpbroadcastw	%xmm4, %zmm5
 1157e78: c4 e2 7d 79 f4               	vpbroadcastw	%xmm4, %ymm6
 1157e7d: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
 1157e82: c4 c1 59 c4 e0 00            	vpinsrw	$0x0, %r8d, %xmm4, %xmm4
 1157e88: c4 e3 4d 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm6, %ymm4
 1157e8e: 62 f3 d5 48 3a e4 00         	vinserti64x4	$0x0, %ymm4, %zmm5, %zmm4
 1157e95: c4 c1 01 c4 ea 00            	vpinsrw	$0x0, %r10d, %xmm15, %xmm5
 1157e9b: 62 f2 7d 48 79 f5            	vpbroadcastw	%xmm5, %zmm6
 1157ea1: c4 e2 7d 79 fd               	vpbroadcastw	%xmm5, %ymm7
 1157ea6: c4 e2 79 79 ed               	vpbroadcastw	%xmm5, %xmm5
 1157eab: c4 c1 51 c4 eb 00            	vpinsrw	$0x0, %r11d, %xmm5, %xmm5
 1157eb1: c4 e3 45 38 ed 00            	vinserti128	$0x0, %xmm5, %ymm7, %ymm5
 1157eb7: 62 f3 cd 48 3a ed 00         	vinserti64x4	$0x0, %ymm5, %zmm6, %zmm5
 1157ebe: 62 f3 e5 48 3f d5 0d         	vpcmpw	$0xd, %zmm5, %zmm3, %k2
 1157ec5: 62 f1 5d ca e5 db            	vpmulhw	%zmm3, %zmm4, %zmm3 {%k2} {z}
 1157ecb: 90                           	nop
 1157ecc: 62 f1 fe 48 7f dc            	vmovdqu64	%zmm3, %zmm4
 1157ed2: 62 f1 75 49 f9 db            	vpsubw	%zmm3, %zmm1, %zmm3 {%k1}
 1157ed8: 4d 85 c9                     	testq	%r9, %r9
 1157edb: 74 0b                        	je	0x1157ee8 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x128>
 1157edd: 62 d1 fe 48 7f 19            	vmovdqu64	%zmm3, (%r9)
 1157ee3: 48 85 c9                     	testq	%rcx, %rcx
 1157ee6: eb 03                        	jmp	0x1157eeb <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x12b>
 1157ee8: 48 85 c9                     	testq	%rcx, %rcx
 1157eeb: 62 f1 55 48 d5 eb            	vpmullw	%zmm3, %zmm5, %zmm5
 1157ef1: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
 1157ef6: 62 f1 fe 48 7f 2a            	vmovdqu64	%zmm5, (%rdx)
 1157efc: 62 f1 fe 48 6f 2f            	vmovdqu64	(%rdi), %zmm5
 1157f02: 62 f3 e5 48 3f c9 04         	vpcmpneqw	%zmm1, %zmm3, %k1
 1157f09: bb 0b 00 00 00               	movl	$0xb, %ebx
 1157f0e: c4 e1 f9 6e db               	vmovq	%rbx, %xmm3
 1157f13: 62 f1 ff c9 7f ed            	vmovdqu16	%zmm5, %zmm5 {%k1} {z}
 1157f19: 62 f1 75 48 ee ed            	vpmaxsw	%zmm5, %zmm1, %zmm5
 1157f1f: 62 f2 7d 48 79 db            	vpbroadcastw	%xmm3, %zmm3
 1157f25: 74 16                        	je	0x1157f3d <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x17d>
 1157f27: 62 f1 5d 48 ea e3            	vpminsw	%zmm3, %zmm4, %zmm4
 1157f2d: 62 f2 dd 48 8d e0            	vpermw	%zmm0, %zmm4, %zmm4
 1157f33: 62 f2 7e 48 30 e4            	vpmovwb	%zmm4, %ymm4
 1157f39: c5 fe 7f 21                  	vmovdqu	%ymm4, (%rcx)
 1157f3d: 0f b7 5c 24 2a               	movzwl	0x2a(%rsp), %ebx
 1157f42: 0f b7 74 24 2e               	movzwl	0x2e(%rsp), %esi
 1157f47: 44 0f b7 44 24 32            	movzwl	0x32(%rsp), %r8d
 1157f4d: c4 e1 f9 6e e3               	vmovq	%rbx, %xmm4
 1157f52: c4 e1 f9 6e f6               	vmovq	%rsi, %xmm6
 1157f57: c4 c1 f9 6e f8               	vmovq	%r8, %xmm7
 1157f5c: 62 f2 7d 48 79 e4            	vpbroadcastw	%xmm4, %zmm4
 1157f62: 62 f2 7d 48 79 f6            	vpbroadcastw	%xmm6, %zmm6
 1157f68: 62 f2 7d 48 79 ff            	vpbroadcastw	%xmm7, %zmm7
 1157f6e: bb 20 00 00 00               	movl	$0x20, %ebx
 1157f73: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
 1157f78: eb 06                        	jmp	0x1157f80 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1c0>
 1157f7a: 48 83 c3 20                  	addq	$0x20, %rbx
 1157f7e: 66 90                        	nop
 1157f80: 48 39 de                     	cmpq	%rbx, %rsi
 1157f83: 0f 8e a6 00 00 00            	jle	0x115802f <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x26f>
 1157f89: 4c 8d 04 58                  	leaq	(%rax,%rbx,2), %r8
 1157f8d: 62 51 fe 48 6f 00            	vmovdqu64	(%r8), %zmm8
 1157f93: 62 52 7d 48 1d c8            	vpabsw	%zmm8, %zmm9
 1157f99: 62 71 35 48 fd cc            	vpaddw	%zmm4, %zmm9, %zmm9
 1157f9f: 62 72 35 48 3a ca            	vpminuw	%zmm2, %zmm9, %zmm9
 1157fa5: 62 f3 b5 48 3f cf 0d         	vpcmpw	$0xd, %zmm7, %zmm9, %k1
 1157fac: 62 f3 bd 48 3f d1 01         	vpcmpltw	%zmm1, %zmm8, %k2
 1157fb3: 62 51 4d c9 e5 c1            	vpmulhw	%zmm9, %zmm6, %zmm8 {%k1} {z}
 1157fb9: 62 51 fe 48 7f c1            	vmovdqu64	%zmm8, %zmm9
 1157fbf: 62 51 75 4a f9 c0            	vpsubw	%zmm8, %zmm1, %zmm8 {%k2}
 1157fc5: 4d 85 c9                     	testq	%r9, %r9
 1157fc8: 74 0f                        	je	0x1157fd9 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x219>
 1157fca: 4d 8d 04 59                  	leaq	(%r9,%rbx,2), %r8
 1157fce: 62 51 fe 48 7f 00            	vmovdqu64	%zmm8, (%r8)
 1157fd4: 48 85 c9                     	testq	%rcx, %rcx
 1157fd7: eb 03                        	jmp	0x1157fdc <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x21c>
 1157fd9: 48 85 c9                     	testq	%rcx, %rcx
 1157fdc: 62 51 45 48 d5 d0            	vpmullw	%zmm8, %zmm7, %zmm10
 1157fe2: 4c 8d 04 5a                  	leaq	(%rdx,%rbx,2), %r8
 1157fe6: 62 51 fe 48 7f 10            	vmovdqu64	%zmm10, (%r8)
 1157fec: 4c 8d 04 5f                  	leaq	(%rdi,%rbx,2), %r8
 1157ff0: 62 51 fe 48 6f 10            	vmovdqu64	(%r8), %zmm10
 1157ff6: 62 f3 bd 48 3f c9 04         	vpcmpneqw	%zmm1, %zmm8, %k1
 1157ffd: 62 51 ff c9 7f d0            	vmovdqu16	%zmm10, %zmm8 {%k1} {z}
 1158003: 62 d1 55 48 ee e8            	vpmaxsw	%zmm8, %zmm5, %zmm5
 1158009: 0f 84 6b ff ff ff            	je	0x1157f7a <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1ba>
 115800f: 62 71 35 48 ea c3            	vpminsw	%zmm3, %zmm9, %zmm8
 1158015: 62 72 bd 48 8d c0            	vpermw	%zmm0, %zmm8, %zmm8
 115801b: 62 52 7e 48 30 c0            	vpmovwb	%zmm8, %ymm8
 1158021: 4c 8d 04 19                  	leaq	(%rcx,%rbx), %r8
 1158025: c4 41 7e 7f 00               	vmovdqu	%ymm8, (%r8)
 115802a: e9 4b ff ff ff               	jmp	0x1157f7a <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1ba>
 115802f: 62 f3 fd 48 3b e8 00         	vextracti64x4	$0x0, %zmm5, %ymm0
 1158036: 62 f3 fd 48 3b e9 01         	vextracti64x4	$0x1, %zmm5, %ymm1
 115803d: c5 fd ee c1                  	vpmaxsw	%ymm1, %ymm0, %ymm0
 1158041: c4 e3 7d 39 c1 00            	vextracti128	$0x0, %ymm0, %xmm1
 1158047: c4 e3 7d 39 c0 01            	vextracti128	$0x1, %ymm0, %xmm0
 115804d: c5 f1 ee c0                  	vpmaxsw	%xmm0, %xmm1, %xmm0
 1158051: c4 e2 79 23 c8               	vpmovsxwd	%xmm0, %xmm1
 1158056: c5 f9 70 c0 4e               	vpshufd	$0x4e, %xmm0, %xmm0     ## xmm0 = xmm0[2,3,0,1]
 115805b: c4 e2 79 23 c0               	vpmovsxwd	%xmm0, %xmm0
 1158060: c4 e2 79 3d c1               	vpmaxsd	%xmm1, %xmm0, %xmm0
 1158065: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     ## xmm1 = xmm0[2,3,0,1]
 115806a: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
 115806f: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     ## xmm1 = xmm0[1,0,3,2]
 1158074: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
 1158079: c4 e3 79 16 c1 00            	vpextrd	$0x0, %xmm0, %ecx
 115807f: 48 63 c1                     	movslq	%ecx, %rax
 1158082: c5 f8 77                     	vzeroupper
 1158085: c3                           	retq
 1158086: cc                           	int3
 1158087: cc                           	int3
 1158088: cc                           	int3
 1158089: cc                           	int3
 115808a: cc                           	int3
 115808b: cc                           	int3
 115808c: cc                           	int3
 115808d: cc                           	int3
 115808e: cc                           	int3
 115808f: cc                           	int3
 1158090: cc                           	int3
 1158091: cc                           	int3
 1158092: cc                           	int3
 1158093: cc                           	int3
 1158094: cc                           	int3
 1158095: cc                           	int3
 1158096: cc                           	int3
 1158097: cc                           	int3
 1158098: cc                           	int3
 1158099: cc                           	int3
 115809a: cc                           	int3
 115809b: cc                           	int3
 115809c: cc                           	int3
 115809d: cc                           	int3
 115809e: cc                           	int3
 115809f: cc                           	int3

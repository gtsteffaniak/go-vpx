from pathlib import Path
import subprocess,re,json
p=Path('/private/tmp/govpx-root49-amd64-validation');proof={}
for os,f in [('darwin','internal-pixel.test'),('linux','internal-pixel-linux.test')]:
 for fn,expected in [('fp16WindowsDisjoint',88),('quantizeFPBlock32AVX512',138)]:
  sym=('_'if os=='darwin'else'')+'github.com/thesyncim/govpx/internal/pixel.'+fn
  text=subprocess.check_output(['xcrun','llvm-objdump','-d','--disassemble-symbols='+sym,str(p/f)],text=True);(p/(os+'-'+fn+'.asm')).write_text(text)
  a=[m[1]for l in text.splitlines()if(m:=re.match(r'^\s*[0-9a-f]+:\s+(?:[0-9a-f]{2}\s+)+(.+)$',l))and m[1]!='int3'];assert len(a)==expected,(fn,os,len(a))
  if fn=='fp16WindowsDisjoint':
   old=Path('/private/tmp/govpx-pr49-fp32-ci-proposal/validation/parent-guard-'+os+'.asm').read_text();old=[m[1]for l in old.splitlines()if(m:=re.match(r'^\s*[0-9a-f]+:\s+(?:[0-9a-f]{2}\s+)+(.+)$',l))and m[1]!='int3'];norm=lambda xs:[re.sub(r'0x[0-9a-f]+','ADDR',x)for x in xs];assert norm(old)==norm(a)
  else:
   assert sum(i.startswith('vzeroupper')for i in a)==1
   assert not any(re.search(r'%(xmm|ymm|zmm)\d+',i)and not i.startswith('v')for i in a)
  proof[os+'-'+fn]={'instructions':len(a),'same_guard88_as_frozen_parent':fn=='fp16WindowsDisjoint','selected512_execution':False}
(p/'codegen-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))

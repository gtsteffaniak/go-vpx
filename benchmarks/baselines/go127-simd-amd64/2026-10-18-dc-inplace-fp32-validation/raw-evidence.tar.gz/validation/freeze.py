from pathlib import Path
import hashlib,json,shutil,subprocess,os,tarfile
r=Path('/Users/thesyncim/GolandProjects/govpx');work=Path('/private/tmp/govpx-root49-amd64-validation');ready=Path('/private/tmp/govpx-root49-amd64-validation-ready');assert not ready.exists();ready.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,d):d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
source=json.loads((work/'source-before.json').read_text());assert source==json.loads((work/'source-after.json').read_text());assert len(source)==116
for rel,want in source.items():assert sha(r/rel)==want,rel;copy(r/rel,ready/'validated-sources'/rel)
# All failed/retained/retried raw logs, commands and source/codegen proofs remain.
for f in work.iterdir():
 if f.is_file()and f.suffix!='.test'and f.name!='HOLD':copy(f,ready/'validation'/f.name)
receipts={str(p):{'sha256':sha(p),'bytes':p.stat().st_size,'omitted_from_publication':True}for p in work.glob('*.test')}
(ready/'binary-omission-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
e=os.environ.copy();e.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci49-freeze',GOTOOLCHAIN='local',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go')
cmd=[str(r/'scripts/go.sh'),'version','-m']+list(receipts)
with(ready/'binary-build-info.txt').open('w')as f:subprocess.run(cmd,cwd=r,env=e,stdout=f,stderr=subprocess.STDOUT,check=True)
(ready/'environment.json').write_text(json.dumps({'repo_cwd':str(r),'Go_wrapper':str(r/'scripts/go.sh'),'GO':e['GO'],'GOTOOLCHAIN':'local','GOEXPERIMENT':'simd','GOFLAGS':'-p=2','GOMAXPROCS_build':2,'GOMAXPROCS_translated_execution':1,'CGO_cross':0,'GOAMD64':'v1 default','Darwin_AMD_execution':'Rosetta correctness only;ROSETTA_ADVERTISE_AVX=1;actualAVX2 true/actualAVX512 false','actual_CPU_off':'GODEBUG=cpu.avx=off,cpu.avx2=off','project_cache_root':'/private/tmp/codex-projects','GOCACHE':'/private/tmp/codex-projects/99feb44aac13f74a/go-build','native_or_emulated_throughput_measurements':0,'source_binding':'all116 current source hashes exactly match validated before/after inventory','buildinfo_argv':cmd},indent=2)+'\n')
proposal=Path('/private/tmp/govpx-pr49-native-harness-proposal')
for name in ['REPORT.md','scope.json','source-sha-paths.json','common-reference-fixtures.json','static-proof.json','proposal.patch','validate-reference.py']:
 copy(proposal/name,ready/'harness-proof'/name)
for f in (proposal/'validation').iterdir():
 if f.is_file()and f.suffix!='.test':copy(f,ready/'harness-proof/reference-compatibility'/f.name)
for name in ['.github/workflows/simd-amd64-bench.yml','scripts/benchmark-amd64.sh','scripts/benchmark-pixel-optional.sh','scripts/benchmark-fp16-guard-diagnostic.sh','scripts/benchmark-fixtures/dc_pair_inplace_reference_shim.go.txt']:
 copy(r/name,ready/'actual-root-harness'/name)
fp=Path('/private/tmp/govpx-pr49-fp32-ci-proposal')
for name in ['guard-repin-proof.json','parent-guard-linux.asm','parent-guard-darwin.asm']:
 copy(fp/'validation'/name,ready/'guard-baseline-proof'/name)
for f in (fp/'validation66').iterdir():
 if f.is_file()and f.suffix!='.test'and not f.name.startswith('synthetic-parser-'):copy(f,ready/'optional66-preintegration-proof'/f.name)
copy(fp/'validation66/static-proof.json',ready/'harness-proof/optional-protocol-static-proof.json')
(ready/'REPORT.md').write_text('''ROOT49 AMD integration validation, official Go1.27.2 / SIMD / PGOoff.

All116 exact prospective source files are included under validated-sources, with matching pre/post root fingerprints. Root source was not modified by this validation or freeze. Five prospective harness/workflow files are separately included for protocol review. No full repository snapshots or executables are included; each omitted executable retains original absolute path, exact SHA256, byte size and Go build metadata. All raw logs, including initial failures and retries, remain.

Six Darwin/amd64 packages compiled and ran under Rosetta with actual AVX2 selection and actual CPU-off settings, ordinary and checkptr2. Linux/amd64 crossbuilds completed for all six. The final12 exact-selector checkptr executions retain every original matching runtime correctness name; VP8encoder had no original matching names so its pair explicitly exercises QuantBatch and LoopFilterLumaSSE. The actual selected512 oracle always explicitly skips: actual SDK AVX512 is false locally. No fake512 capabilities, native AMD execution or performance claim.

Two allocation-only assertions fail under checkptr2 and reproduce identically on exact parent31123: TestInverseWalshAllocatesZero allocs1want0 and TestReconstructInterFrameGridAllocatesZero allocs3want0. Ordinary allocation assertions pass. Assertions and CI tests remain unchanged; only these two allocation assertions are omitted from the final instrumented exact selectors. Both failing current logs and exact parent status/argv proofs are preserved. All other matching correctness tests pass under selected/off checkptr2.

ROOT new66 pixel fixtures pass ordinary/checkptr2 (132 excluded one-shots), with live full-output/input/canary checks and0B/0alloc. ROOT new18 paired-in-place DSP fixtures pass ordinary/checkptr2 (36 excluded one-shots). Separate native ARM one-shot compatibility on current combined, previous48 and actual old691 assembly gives54 full-state zero-allocation cases; references use Go overlays and only the isolated inlined legacy adapter. Earlier optional66 parent/current132 Rosetta one-shots and protocol static/synthetic-parser proofs are retained separately; none are throughput evidence.

Both root Linux/Darwin optimized guards are identical88 instructions to the frozen parent, validating the explicit whole-file SHA repin. Root512 helper remains138 instructions, returns through VZEROUPPER and contains no legacy vector-register writes. Actual512 selected correctness, speed and codec ROI remain pending native CI. Existing main534 three-way/9612 timings and446 excluded preflights, separate396/66 guard diagnostics, and additive66 two-way pixel phase remain separate scopes. The optional phase must explicitly report unavailable if actual512 is false; fallback timings cannot establish512 acceptance.

Noasm/build-selection/shell-syntax gates pass. Local Go-list logs retain sandbox module-stat-cache write warnings (exit0); no source/assembly-selection failure was suppressed. Full ARM suite/PGO/whole measurements are owned separately by the parent and are not claimed by this package.
''')
manifest={str(p.relative_to(ready)):sha(p)for p in sorted(ready.rglob('*'))if p.is_file()};(ready/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=Path(str(ready)+'.tar.gz')
with tarfile.open(archive,'w:gz')as t:t.add(ready,arcname=ready.name)
print(json.dumps({'ready':str(ready),'members_excluding_manifest':len(manifest),'source_files':len(source),'omitted_executables':len(receipts),'manifest_sha256':sha(ready/'MANIFEST.json'),'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'all_jobs_stopped':True},indent=2))

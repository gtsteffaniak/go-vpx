
/private/tmp/govpx-root49-amd64-validation/internal-pixel-linux.test:	file format elf64-x86-64

Disassembly of section .text:

00000000005653a0 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512>:
  5653a0: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
  5653a5: 48 89 7c 24 68               	movq	%rdi, 0x68(%rsp)
  5653aa: 4c 89 8c 24 80 00 00 00      	movq	%r9, 0x80(%rsp)
  5653b2: 90                           	nop
  5653b3: 62 f1 fd 48 ef c0            	vpxorq	%zmm0, %zmm0, %zmm0
  5653b9: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
  5653be: 66 90                        	nop
  5653c0: 48 85 c9                     	testq	%rcx, %rcx
  5653c3: 74 0a                        	je	0x5653cf <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x2f>
  5653c5: 62 f1 fe 48 6f 05 31 9b 22 00	vmovdqu64	0x229b31(%rip), %zmm0 # 0x78ef00 <github.com/thesyncim/govpx/internal/pixel.fpClassWordLUT32>
  5653cf: 62 f1 f5 48 ef c9            	vpxorq	%zmm1, %zmm1, %zmm1
  5653d5: 0f b7 54 24 2a               	movzwl	0x2a(%rsp), %edx
  5653da: 0f b7 5c 24 28               	movzwl	0x28(%rsp), %ebx
  5653df: 0f b7 74 24 2e               	movzwl	0x2e(%rsp), %esi
  5653e4: 44 0f b7 44 24 2c            	movzwl	0x2c(%rsp), %r8d
  5653ea: 44 0f b7 54 24 32            	movzwl	0x32(%rsp), %r10d
  5653f0: 44 0f b7 5c 24 30            	movzwl	0x30(%rsp), %r11d
  5653f6: 62 f1 fe 48 6f 10            	vmovdqu64	(%rax), %zmm2
  5653fc: 62 f2 7d 48 1d da            	vpabsw	%zmm2, %zmm3
  565402: 62 f3 ed 48 3f c9 01         	vpcmpltw	%zmm1, %zmm2, %k1
  565409: 41 bc ff 7f 00 00            	movl	$0x7fff, %r12d          # imm = 0x7FFF
  56540f: c4 c1 f9 6e d4               	vmovq	%r12, %xmm2
  565414: 62 f2 7d 48 79 d2            	vpbroadcastw	%xmm2, %zmm2
  56541a: c5 81 c4 e2 00               	vpinsrw	$0x0, %edx, %xmm15, %xmm4
  56541f: 62 f2 7d 48 79 ec            	vpbroadcastw	%xmm4, %zmm5
  565425: c4 e2 7d 79 f4               	vpbroadcastw	%xmm4, %ymm6
  56542a: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
  56542f: c5 d9 c4 e3 00               	vpinsrw	$0x0, %ebx, %xmm4, %xmm4
  565434: c4 e3 4d 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm6, %ymm4
  56543a: 62 f3 d5 48 3a e4 00         	vinserti64x4	$0x0, %ymm4, %zmm5, %zmm4
  565441: 62 f1 5d 48 fd db            	vpaddw	%zmm3, %zmm4, %zmm3
  565447: 62 f2 65 48 3a da            	vpminuw	%zmm2, %zmm3, %zmm3
  56544d: c5 81 c4 e6 00               	vpinsrw	$0x0, %esi, %xmm15, %xmm4
  565452: 62 f2 7d 48 79 ec            	vpbroadcastw	%xmm4, %zmm5
  565458: c4 e2 7d 79 f4               	vpbroadcastw	%xmm4, %ymm6
  56545d: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
  565462: c4 c1 59 c4 e0 00            	vpinsrw	$0x0, %r8d, %xmm4, %xmm4
  565468: c4 e3 4d 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm6, %ymm4
  56546e: 62 f3 d5 48 3a e4 00         	vinserti64x4	$0x0, %ymm4, %zmm5, %zmm4
  565475: c4 c1 01 c4 ea 00            	vpinsrw	$0x0, %r10d, %xmm15, %xmm5
  56547b: 62 f2 7d 48 79 f5            	vpbroadcastw	%xmm5, %zmm6
  565481: c4 e2 7d 79 fd               	vpbroadcastw	%xmm5, %ymm7
  565486: c4 e2 79 79 ed               	vpbroadcastw	%xmm5, %xmm5
  56548b: c4 c1 51 c4 eb 00            	vpinsrw	$0x0, %r11d, %xmm5, %xmm5
  565491: c4 e3 45 38 ed 00            	vinserti128	$0x0, %xmm5, %ymm7, %ymm5
  565497: 62 f3 cd 48 3a ed 00         	vinserti64x4	$0x0, %ymm5, %zmm6, %zmm5
  56549e: 62 f3 e5 48 3f d5 0d         	vpcmpw	$0xd, %zmm5, %zmm3, %k2
  5654a5: 62 f1 5d ca e5 db            	vpmulhw	%zmm3, %zmm4, %zmm3 {%k2} {z}
  5654ab: 90                           	nop
  5654ac: 62 f1 fe 48 7f dc            	vmovdqu64	%zmm3, %zmm4
  5654b2: 62 f1 75 49 f9 db            	vpsubw	%zmm3, %zmm1, %zmm3 {%k1}
  5654b8: 4d 85 c9                     	testq	%r9, %r9
  5654bb: 74 0b                        	je	0x5654c8 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x128>
  5654bd: 62 d1 fe 48 7f 19            	vmovdqu64	%zmm3, (%r9)
  5654c3: 48 85 c9                     	testq	%rcx, %rcx
  5654c6: eb 03                        	jmp	0x5654cb <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x12b>
  5654c8: 48 85 c9                     	testq	%rcx, %rcx
  5654cb: 62 f1 55 48 d5 eb            	vpmullw	%zmm3, %zmm5, %zmm5
  5654d1: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
  5654d6: 62 f1 fe 48 7f 2a            	vmovdqu64	%zmm5, (%rdx)
  5654dc: 62 f1 fe 48 6f 2f            	vmovdqu64	(%rdi), %zmm5
  5654e2: 62 f3 e5 48 3f c9 04         	vpcmpneqw	%zmm1, %zmm3, %k1
  5654e9: bb 0b 00 00 00               	movl	$0xb, %ebx
  5654ee: c4 e1 f9 6e db               	vmovq	%rbx, %xmm3
  5654f3: 62 f1 ff c9 7f ed            	vmovdqu16	%zmm5, %zmm5 {%k1} {z}
  5654f9: 62 f1 75 48 ee ed            	vpmaxsw	%zmm5, %zmm1, %zmm5
  5654ff: 62 f2 7d 48 79 db            	vpbroadcastw	%xmm3, %zmm3
  565505: 74 16                        	je	0x56551d <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x17d>
  565507: 62 f1 5d 48 ea e3            	vpminsw	%zmm3, %zmm4, %zmm4
  56550d: 62 f2 dd 48 8d e0            	vpermw	%zmm0, %zmm4, %zmm4
  565513: 62 f2 7e 48 30 e4            	vpmovwb	%zmm4, %ymm4
  565519: c5 fe 7f 21                  	vmovdqu	%ymm4, (%rcx)
  56551d: 0f b7 5c 24 2a               	movzwl	0x2a(%rsp), %ebx
  565522: 0f b7 74 24 2e               	movzwl	0x2e(%rsp), %esi
  565527: 44 0f b7 44 24 32            	movzwl	0x32(%rsp), %r8d
  56552d: c4 e1 f9 6e e3               	vmovq	%rbx, %xmm4
  565532: c4 e1 f9 6e f6               	vmovq	%rsi, %xmm6
  565537: c4 c1 f9 6e f8               	vmovq	%r8, %xmm7
  56553c: 62 f2 7d 48 79 e4            	vpbroadcastw	%xmm4, %zmm4
  565542: 62 f2 7d 48 79 f6            	vpbroadcastw	%xmm6, %zmm6
  565548: 62 f2 7d 48 79 ff            	vpbroadcastw	%xmm7, %zmm7
  56554e: bb 20 00 00 00               	movl	$0x20, %ebx
  565553: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
  565558: eb 06                        	jmp	0x565560 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1c0>
  56555a: 48 83 c3 20                  	addq	$0x20, %rbx
  56555e: 66 90                        	nop
  565560: 48 39 de                     	cmpq	%rbx, %rsi
  565563: 0f 8e a6 00 00 00            	jle	0x56560f <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x26f>
  565569: 4c 8d 04 58                  	leaq	(%rax,%rbx,2), %r8
  56556d: 62 51 fe 48 6f 00            	vmovdqu64	(%r8), %zmm8
  565573: 62 52 7d 48 1d c8            	vpabsw	%zmm8, %zmm9
  565579: 62 71 35 48 fd cc            	vpaddw	%zmm4, %zmm9, %zmm9
  56557f: 62 72 35 48 3a ca            	vpminuw	%zmm2, %zmm9, %zmm9
  565585: 62 f3 b5 48 3f cf 0d         	vpcmpw	$0xd, %zmm7, %zmm9, %k1
  56558c: 62 f3 bd 48 3f d1 01         	vpcmpltw	%zmm1, %zmm8, %k2
  565593: 62 51 4d c9 e5 c1            	vpmulhw	%zmm9, %zmm6, %zmm8 {%k1} {z}
  565599: 62 51 fe 48 7f c1            	vmovdqu64	%zmm8, %zmm9
  56559f: 62 51 75 4a f9 c0            	vpsubw	%zmm8, %zmm1, %zmm8 {%k2}
  5655a5: 4d 85 c9                     	testq	%r9, %r9
  5655a8: 74 0f                        	je	0x5655b9 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x219>
  5655aa: 4d 8d 04 59                  	leaq	(%r9,%rbx,2), %r8
  5655ae: 62 51 fe 48 7f 00            	vmovdqu64	%zmm8, (%r8)
  5655b4: 48 85 c9                     	testq	%rcx, %rcx
  5655b7: eb 03                        	jmp	0x5655bc <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x21c>
  5655b9: 48 85 c9                     	testq	%rcx, %rcx
  5655bc: 62 51 45 48 d5 d0            	vpmullw	%zmm8, %zmm7, %zmm10
  5655c2: 4c 8d 04 5a                  	leaq	(%rdx,%rbx,2), %r8
  5655c6: 62 51 fe 48 7f 10            	vmovdqu64	%zmm10, (%r8)
  5655cc: 4c 8d 04 5f                  	leaq	(%rdi,%rbx,2), %r8
  5655d0: 62 51 fe 48 6f 10            	vmovdqu64	(%r8), %zmm10
  5655d6: 62 f3 bd 48 3f c9 04         	vpcmpneqw	%zmm1, %zmm8, %k1
  5655dd: 62 51 ff c9 7f d0            	vmovdqu16	%zmm10, %zmm8 {%k1} {z}
  5655e3: 62 d1 55 48 ee e8            	vpmaxsw	%zmm8, %zmm5, %zmm5
  5655e9: 0f 84 6b ff ff ff            	je	0x56555a <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1ba>
  5655ef: 62 71 35 48 ea c3            	vpminsw	%zmm3, %zmm9, %zmm8
  5655f5: 62 72 bd 48 8d c0            	vpermw	%zmm0, %zmm8, %zmm8
  5655fb: 62 52 7e 48 30 c0            	vpmovwb	%zmm8, %ymm8
  565601: 4c 8d 04 19                  	leaq	(%rcx,%rbx), %r8
  565605: c4 41 7e 7f 00               	vmovdqu	%ymm8, (%r8)
  56560a: e9 4b ff ff ff               	jmp	0x56555a <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1ba>
  56560f: 62 f3 fd 48 3b e8 00         	vextracti64x4	$0x0, %zmm5, %ymm0
  565616: 62 f3 fd 48 3b e9 01         	vextracti64x4	$0x1, %zmm5, %ymm1
  56561d: c5 fd ee c1                  	vpmaxsw	%ymm1, %ymm0, %ymm0
  565621: c4 e3 7d 39 c1 00            	vextracti128	$0x0, %ymm0, %xmm1
  565627: c4 e3 7d 39 c0 01            	vextracti128	$0x1, %ymm0, %xmm0
  56562d: c5 f1 ee c0                  	vpmaxsw	%xmm0, %xmm1, %xmm0
  565631: c4 e2 79 23 c8               	vpmovsxwd	%xmm0, %xmm1
  565636: c5 f9 70 c0 4e               	vpshufd	$0x4e, %xmm0, %xmm0     # xmm0 = xmm0[2,3,0,1]
  56563b: c4 e2 79 23 c0               	vpmovsxwd	%xmm0, %xmm0
  565640: c4 e2 79 3d c1               	vpmaxsd	%xmm1, %xmm0, %xmm0
  565645: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     # xmm1 = xmm0[2,3,0,1]
  56564a: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  56564f: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     # xmm1 = xmm0[1,0,3,2]
  565654: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  565659: c4 e3 79 16 c1 00            	vpextrd	$0x0, %xmm0, %ecx
  56565f: 48 63 c1                     	movslq	%ecx, %rax
  565662: c5 f8 77                     	vzeroupper
  565665: c3                           	retq
  565666: cc                           	int3
  565667: cc                           	int3
  565668: cc                           	int3
  565669: cc                           	int3
  56566a: cc                           	int3
  56566b: cc                           	int3
  56566c: cc                           	int3
  56566d: cc                           	int3
  56566e: cc                           	int3
  56566f: cc                           	int3
  565670: cc                           	int3
  565671: cc                           	int3
  565672: cc                           	int3
  565673: cc                           	int3
  565674: cc                           	int3
  565675: cc                           	int3
  565676: cc                           	int3
  565677: cc                           	int3
  565678: cc                           	int3
  565679: cc                           	int3
  56567a: cc                           	int3
  56567b: cc                           	int3
  56567c: cc                           	int3
  56567d: cc                           	int3
  56567e: cc                           	int3
  56567f: cc                           	int3


/private/tmp/govpx-root49-amd64-validation/internal-pixel-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000566020 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>:
  566020: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
  566025: 48 89 7c 24 58               	movq	%rdi, 0x58(%rsp)
  56602a: 4c 89 4c 24 70               	movq	%r9, 0x70(%rsp)
  56602f: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
  566034: 48 89 ca                     	movq	%rcx, %rdx
  566037: 48 c1 e1 02                  	shlq	$0x2, %rcx
  56603b: 48 ff c9                     	decq	%rcx
  56603e: 48 89 fb                     	movq	%rdi, %rbx
  566041: 48 29 c7                     	subq	%rax, %rdi
  566044: 48 8d 34 57                  	leaq	(%rdi,%rdx,2), %rsi
  566048: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
  56604c: 48 39 ce                     	cmpq	%rcx, %rsi
  56604f: 72 2b                        	jb	0x56607c <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x5c>
  566051: 48 8b 74 24 08               	movq	0x8(%rsp), %rsi
  566056: 48 89 f7                     	movq	%rsi, %rdi
  566059: 48 29 c6                     	subq	%rax, %rsi
  56605c: 48 8d 34 56                  	leaq	(%rsi,%rdx,2), %rsi
  566060: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
  566064: 48 39 ce                     	cmpq	%rcx, %rsi
  566067: 72 13                        	jb	0x56607c <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x5c>
  566069: 48 89 fe                     	movq	%rdi, %rsi
  56606c: 48 29 df                     	subq	%rbx, %rdi
  56606f: 48 8d 3c 57                  	leaq	(%rdi,%rdx,2), %rdi
  566073: 48 8d 7f ff                  	leaq	-0x1(%rdi), %rdi
  566077: 48 39 cf                     	cmpq	%rcx, %rdi
  56607a: 73 04                        	jae	0x566080 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x60>
  56607c: 31 c0                        	xorl	%eax, %eax
  56607e: c3                           	retq
  56607f: 90                           	nop
  566080: 4d 85 c9                     	testq	%r9, %r9
  566083: 74 3c                        	je	0x5660c1 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa1>
  566085: 4c 89 cf                     	movq	%r9, %rdi
  566088: 4d 89 c8                     	movq	%r9, %r8
  56608b: 49 29 c1                     	subq	%rax, %r9
  56608e: 4d 8d 0c 51                  	leaq	(%r9,%rdx,2), %r9
  566092: 4d 8d 49 ff                  	leaq	-0x1(%r9), %r9
  566096: 49 39 c9                     	cmpq	%rcx, %r9
  566099: 72 23                        	jb	0x5660be <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x9e>
  56609b: 4d 89 c1                     	movq	%r8, %r9
  56609e: 49 29 d8                     	subq	%rbx, %r8
  5660a1: 4d 8d 04 50                  	leaq	(%r8,%rdx,2), %r8
  5660a5: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  5660a9: 49 39 c8                     	cmpq	%rcx, %r8
  5660ac: 72 10                        	jb	0x5660be <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x9e>
  5660ae: 49 29 f1                     	subq	%rsi, %r9
  5660b1: 4d 8d 04 51                  	leaq	(%r9,%rdx,2), %r8
  5660b5: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  5660b9: 49 39 c8                     	cmpq	%rcx, %r8
  5660bc: 73 06                        	jae	0x5660c4 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa4>
  5660be: 31 c0                        	xorl	%eax, %eax
  5660c0: c3                           	retq
  5660c1: 4c 89 cf                     	movq	%r9, %rdi
  5660c4: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
  5660c9: 48 85 c9                     	testq	%rcx, %rcx
  5660cc: 74 5c                        	je	0x56612a <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
  5660ce: 4c 8d 04 52                  	leaq	(%rdx,%rdx,2), %r8
  5660d2: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  5660d6: 49 89 c9                     	movq	%rcx, %r9
  5660d9: 48 29 c1                     	subq	%rax, %rcx
  5660dc: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
  5660e0: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  5660e4: 49 39 c8                     	cmpq	%rcx, %r8
  5660e7: 77 26                        	ja	0x56610f <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xef>
  5660e9: 4c 89 c9                     	movq	%r9, %rcx
  5660ec: 49 29 d9                     	subq	%rbx, %r9
  5660ef: 49 8d 1c 11                  	leaq	(%r9,%rdx), %rbx
  5660f3: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
  5660f7: 49 39 d8                     	cmpq	%rbx, %r8
  5660fa: 77 13                        	ja	0x56610f <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xef>
  5660fc: 48 89 cb                     	movq	%rcx, %rbx
  5660ff: 48 29 f1                     	subq	%rsi, %rcx
  566102: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
  566106: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  56610a: 49 39 c8                     	cmpq	%rcx, %r8
  56610d: 76 03                        	jbe	0x566112 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xf2>
  56610f: 31 c0                        	xorl	%eax, %eax
  566111: c3                           	retq
  566112: 48 85 ff                     	testq	%rdi, %rdi
  566115: 74 13                        	je	0x56612a <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
  566117: 48 29 fb                     	subq	%rdi, %rbx
  56611a: 48 8d 0c 13                  	leaq	(%rbx,%rdx), %rcx
  56611e: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  566122: 49 39 c8                     	cmpq	%rcx, %r8
  566125: 76 03                        	jbe	0x56612a <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
  566127: 31 c0                        	xorl	%eax, %eax
  566129: c3                           	retq
  56612a: b8 01 00 00 00               	movl	$0x1, %eax
  56612f: c3                           	retq
  566130: cc                           	int3
  566131: cc                           	int3
  566132: cc                           	int3
  566133: cc                           	int3
  566134: cc                           	int3
  566135: cc                           	int3
  566136: cc                           	int3
  566137: cc                           	int3
  566138: cc                           	int3
  566139: cc                           	int3
  56613a: cc                           	int3
  56613b: cc                           	int3
  56613c: cc                           	int3
  56613d: cc                           	int3
  56613e: cc                           	int3
  56613f: cc                           	int3

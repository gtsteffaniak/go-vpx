from pathlib import Path
import subprocess,os,json,hashlib
p=Path('/private/tmp/govpx-root49-amd64-validation');r=Path('/Users/thesyncim/GolandProjects/govpx');regex='^Test(FP16|FP32|DCPair|DCOnly|AddConstantPair|.*Stats|BackendSelected|QuantizeFP|IDCT|Inverse|Reconstruct)';packages=['internal/pixel','internal/vp8/dsp','internal/vp8/decoder','internal/vp9/dsp','internal/vp9/encoder','internal/vp8/encoder'];excluded={'TestInverseWalshAllocatesZero','TestReconstructInterFrameGridAllocatesZero'};records=[]
for package in packages:
 binary=p/(package.replace('/','-')+'-checkptr2.test')
 package_regex='^Test(QuantBatch|LoopFilterLumaSSE)'if package=='internal/vp8/encoder'else regex
 for off in (False,True):
  e=os.environ.copy();e.update(ROSETTA_ADVERTISE_AVX='1',GOMAXPROCS='1',GOVPX_REQUIRE_SIMD='0'if off else'1',GOVPX_REQUIRE_FP32_OFF='1',GODEBUG='cpu.avx=off,cpu.avx2=off'if off else'')
  if off:e['GOVPX_REQUIRE_FP16_AVX_OFF']='1'
  listed=subprocess.check_output(['arch','-x86_64',str(binary),'-test.list='+package_regex],env=e,text=True);allnames=[n for n in listed.splitlines()if n.startswith('Test')];removed=sorted(set(allnames)&excluded);names=[n for n in allnames if n not in excluded];assert names
  exact='^('+'|'.join(names)+')$';args=['arch','-x86_64',str(binary),'-test.run='+exact,'-test.count=1','-test.v'];tag=package.replace('/','-')+('-off'if off else'-selected')
  with(p/('complete-'+tag+'.log')).open('w')as f:z=subprocess.run(args,cwd=r,env=e,stdout=f,stderr=subprocess.STDOUT)
  assert z.returncode==0,(tag,z.returncode)
  text=(p/('complete-'+tag+'.log')).read_text();assert '--- FAIL:'not in text
  for n in names:assert ('--- PASS: '+n+' 'in text)or('--- SKIP: '+n+' 'in text),(tag,n)
  records.append({'package':package,'actual_AVX_off':off,'argv':args,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'all_original_matching_test_names':allnames,'only_baseline_allocation_omissions':removed,'executed_correctness_names':names,'exit_status':z.returncode,'selected512_execution':False});print(tag+' ALL EXACT CORRECTNESS PASS',flush=True)
assert len(records)==12
(p/'complete-runtime-proof.json').write_text(json.dumps({'records':records,'only_omitted_instrumentation_allocation_assertions':sorted(excluded),'all_other_original_selected_correctness_names_retained':True,'Go_builds_in_followup':0,'native_or_emulated_throughput_measurements':0,'real512_selected_oracle_skipped_as_unavailable':True},indent=2)+'\n')
proof=json.loads((p/'proof.json').read_text());proof['checkptr_scope']='All original matching runtime correctness names completed in12 selected/actual-off exact-selector runs; only two independently parent-reproduced instrumentation allocation assertions omitted.';proof['baseline_allocation_exceptions']=[{'test':'TestInverseWalshAllocatesZero','parent_and_current_checkptr2_allocs':1,'ordinary_parent_and_current_pass':True,'proof':'baseline-checkptr2-allocation-proof.json'},{'test':'TestReconstructInterFrameGridAllocatesZero','parent_and_current_checkptr2_allocs':3,'ordinary_parent_and_current_pass':True,'proof':'baseline-decoder-checkptr2-allocation-proof.json'}];proof['complete_runtime_proof']='complete-runtime-proof.json';(p/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print('END ALL12 TRANSLATED CORRECTNESS PROCESSES STOPPED',flush=True)


/private/tmp/govpx-root49-amd64-validation/internal-pixel.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

0000000001158a40 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>:
 1158a40: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
 1158a45: 48 89 7c 24 58               	movq	%rdi, 0x58(%rsp)
 1158a4a: 4c 89 4c 24 70               	movq	%r9, 0x70(%rsp)
 1158a4f: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
 1158a54: 48 89 ca                     	movq	%rcx, %rdx
 1158a57: 48 c1 e1 02                  	shlq	$0x2, %rcx
 1158a5b: 48 ff c9                     	decq	%rcx
 1158a5e: 48 89 fb                     	movq	%rdi, %rbx
 1158a61: 48 29 c7                     	subq	%rax, %rdi
 1158a64: 48 8d 34 57                  	leaq	(%rdi,%rdx,2), %rsi
 1158a68: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
 1158a6c: 48 39 ce                     	cmpq	%rcx, %rsi
 1158a6f: 72 2b                        	jb	0x1158a9c <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x5c>
 1158a71: 48 8b 74 24 08               	movq	0x8(%rsp), %rsi
 1158a76: 48 89 f7                     	movq	%rsi, %rdi
 1158a79: 48 29 c6                     	subq	%rax, %rsi
 1158a7c: 48 8d 34 56                  	leaq	(%rsi,%rdx,2), %rsi
 1158a80: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
 1158a84: 48 39 ce                     	cmpq	%rcx, %rsi
 1158a87: 72 13                        	jb	0x1158a9c <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x5c>
 1158a89: 48 89 fe                     	movq	%rdi, %rsi
 1158a8c: 48 29 df                     	subq	%rbx, %rdi
 1158a8f: 48 8d 3c 57                  	leaq	(%rdi,%rdx,2), %rdi
 1158a93: 48 8d 7f ff                  	leaq	-0x1(%rdi), %rdi
 1158a97: 48 39 cf                     	cmpq	%rcx, %rdi
 1158a9a: 73 04                        	jae	0x1158aa0 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x60>
 1158a9c: 31 c0                        	xorl	%eax, %eax
 1158a9e: c3                           	retq
 1158a9f: 90                           	nop
 1158aa0: 4d 85 c9                     	testq	%r9, %r9
 1158aa3: 74 3c                        	je	0x1158ae1 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa1>
 1158aa5: 4c 89 cf                     	movq	%r9, %rdi
 1158aa8: 4d 89 c8                     	movq	%r9, %r8
 1158aab: 49 29 c1                     	subq	%rax, %r9
 1158aae: 4d 8d 0c 51                  	leaq	(%r9,%rdx,2), %r9
 1158ab2: 4d 8d 49 ff                  	leaq	-0x1(%r9), %r9
 1158ab6: 49 39 c9                     	cmpq	%rcx, %r9
 1158ab9: 72 23                        	jb	0x1158ade <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x9e>
 1158abb: 4d 89 c1                     	movq	%r8, %r9
 1158abe: 49 29 d8                     	subq	%rbx, %r8
 1158ac1: 4d 8d 04 50                  	leaq	(%r8,%rdx,2), %r8
 1158ac5: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
 1158ac9: 49 39 c8                     	cmpq	%rcx, %r8
 1158acc: 72 10                        	jb	0x1158ade <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x9e>
 1158ace: 49 29 f1                     	subq	%rsi, %r9
 1158ad1: 4d 8d 04 51                  	leaq	(%r9,%rdx,2), %r8
 1158ad5: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
 1158ad9: 49 39 c8                     	cmpq	%rcx, %r8
 1158adc: 73 06                        	jae	0x1158ae4 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa4>
 1158ade: 31 c0                        	xorl	%eax, %eax
 1158ae0: c3                           	retq
 1158ae1: 4c 89 cf                     	movq	%r9, %rdi
 1158ae4: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
 1158ae9: 48 85 c9                     	testq	%rcx, %rcx
 1158aec: 74 5c                        	je	0x1158b4a <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
 1158aee: 4c 8d 04 52                  	leaq	(%rdx,%rdx,2), %r8
 1158af2: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
 1158af6: 49 89 c9                     	movq	%rcx, %r9
 1158af9: 48 29 c1                     	subq	%rax, %rcx
 1158afc: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
 1158b00: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
 1158b04: 49 39 c8                     	cmpq	%rcx, %r8
 1158b07: 77 26                        	ja	0x1158b2f <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xef>
 1158b09: 4c 89 c9                     	movq	%r9, %rcx
 1158b0c: 49 29 d9                     	subq	%rbx, %r9
 1158b0f: 49 8d 1c 11                  	leaq	(%r9,%rdx), %rbx
 1158b13: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
 1158b17: 49 39 d8                     	cmpq	%rbx, %r8
 1158b1a: 77 13                        	ja	0x1158b2f <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xef>
 1158b1c: 48 89 cb                     	movq	%rcx, %rbx
 1158b1f: 48 29 f1                     	subq	%rsi, %rcx
 1158b22: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
 1158b26: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
 1158b2a: 49 39 c8                     	cmpq	%rcx, %r8
 1158b2d: 76 03                        	jbe	0x1158b32 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xf2>
 1158b2f: 31 c0                        	xorl	%eax, %eax
 1158b31: c3                           	retq
 1158b32: 48 85 ff                     	testq	%rdi, %rdi
 1158b35: 74 13                        	je	0x1158b4a <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
 1158b37: 48 29 fb                     	subq	%rdi, %rbx
 1158b3a: 48 8d 0c 13                  	leaq	(%rbx,%rdx), %rcx
 1158b3e: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
 1158b42: 49 39 c8                     	cmpq	%rcx, %r8
 1158b45: 76 03                        	jbe	0x1158b4a <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10a>
 1158b47: 31 c0                        	xorl	%eax, %eax
 1158b49: c3                           	retq
 1158b4a: b8 01 00 00 00               	movl	$0x1, %eax
 1158b4f: c3                           	retq
 1158b50: cc                           	int3
 1158b51: cc                           	int3
 1158b52: cc                           	int3
 1158b53: cc                           	int3
 1158b54: cc                           	int3
 1158b55: cc                           	int3
 1158b56: cc                           	int3
 1158b57: cc                           	int3
 1158b58: cc                           	int3
 1158b59: cc                           	int3
 1158b5a: cc                           	int3
 1158b5b: cc                           	int3
 1158b5c: cc                           	int3
 1158b5d: cc                           	int3
 1158b5e: cc                           	int3
 1158b5f: cc                           	int3

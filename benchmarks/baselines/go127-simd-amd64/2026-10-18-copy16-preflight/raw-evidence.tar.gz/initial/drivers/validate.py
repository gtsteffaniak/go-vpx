from pathlib import Path
import subprocess,os,json,re,hashlib
r=Path('/private/tmp/govpx-amd64-copy16-rows');root=Path('/Users/thesyncim/GolandProjects/govpx');e=os.environ.copy();e.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-amd-copy16',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GOAMD64='v1',CGO_ENABLED='0',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go');records=[]
def run(name,cmd,env=e):
 with(r/'evidence'/(name+'.log')).open('w')as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append({'name':name,'command':cmd,'env':{k:env[k]for k in ['GOOS','GOARCH','GOEXPERIMENT','GODEBUG','GOVPX_REQUIRE_SIMD','GOVPX_REQUIRE_SCALAR','ROSETTA_ADVERTISE_AVX','GO','GOMAXPROCS','GOFLAGS','GOAMD64','CGO_ENABLED','CODEX_AGENT_ID','GOTOOLCHAIN','CODEX_PROJECT_CACHE_ROOT']if k in env},'exit':p.returncode});(r/'evidence/commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0,name
run('cache',[str(root/'scripts/go.sh'),'-C',str(r/'candidate'),'env','GOCACHE'])
for v in ['candidate','parent','old691']:
 for mode in ['ordinary','checkptr2']:
  for package,pkg in [('pixel','./internal/pixel'),('dsp','./internal/vp8/dsp'),('root','.')]:
   if package=='pixel'and v!='candidate':continue
   env=e.copy();env.update(GOOS='darwin',GOARCH='amd64');binary=r/(v+'-'+package+'-'+mode+'.test');args=['test','-pgo=off']+(['-gcflags=all=-d=checkptr=2']if mode=='checkptr2'else[])+['-c',pkg,'-o',str(binary)];run(v+'-'+package+'-'+mode+'-build',[str(root/'scripts/go.sh'),'-C',str(r/v)]+args,env)
   for cpu in ['selected','cpuoff']:
    if cpu=='cpuoff'and v=='old691':continue
    env=e.copy();env.update(GODEBUG=''if cpu=='selected'else'cpu.avx=off,cpu.avx2=off',GOVPX_REQUIRE_SIMD='1'if cpu=='selected'else'0',GOVPX_REQUIRE_SCALAR='0'if cpu=='selected'else'1',ROSETTA_ADVERTISE_AVX='1')
    regex='^TestCopy16' if package!='pixel'else'^Test(Copy16AMDProbe|BackendSelected)'
    run(v+'-'+package+'-'+mode+'-'+cpu,['arch','-x86_64',str(binary),'-test.run='+regex,'-test.count=1','-test.v'],env)
    if package!='pixel':run(v+'-'+package+'-'+mode+'-'+cpu+'-oneshot',['arch','-x86_64',str(binary),'-test.run=^$','-test.bench=^BenchmarkCopy16RowsNative$','-test.benchtime=1x','-test.cpu=1','-test.count=1','-test.benchmem'],env)
for package,pkg in [('pixel','./internal/pixel'),('dsp','./internal/vp8/dsp'),('root','.')]:
 env=e.copy();env.update(GOOS='linux',GOARCH='amd64');run('candidate-'+package+'-linux-build',[str(root/'scripts/go.sh'),'-C',str(r/'candidate'),'test','-pgo=off','-c',pkg,'-o',str(r/('candidate-'+package+'-linux.test'))],env)
for v in ['parent','candidate']:
 for package,pkg in [('dsp','./internal/vp8/dsp'),('root','.')]:
  env=e.copy();env.update(GOOS='darwin',GOARCH='arm64');run(v+'-'+package+'-arm-build',[str(root/'scripts/go.sh'),'-C',str(r/v),'test','-pgo=off','-c',pkg,'-o',str(r/(v+'-'+package+'-arm.test'))],env)
for mode in ['purego','nosimd']:
 for package,pkg in [('pixel','./internal/pixel'),('dsp','./internal/vp8/dsp'),('root','.')]:
  env=e.copy();env.update(GOOS='darwin',GOARCH='amd64');args=['test','-pgo=off']+(['-tags=purego']if mode=='purego'else[])+['-c',pkg,'-o',str(r/('candidate-'+package+'-'+mode+'.test'))]
  if mode=='nosimd':env['GOEXPERIMENT']=''
  run('candidate-'+package+'-'+mode+'-build',[str(root/'scripts/go.sh'),'-C',str(r/'candidate')]+args,env)
  env=e.copy();env.update(GOVPX_REQUIRE_SIMD='0',GOVPX_REQUIRE_SCALAR='1',ROSETTA_ADVERTISE_AVX='1');regex='^TestCopy16'if package!='pixel'else'^Test(Copy16AMDProbe|BackendSelected)';run('candidate-'+package+'-'+mode+'-run',['arch','-x86_64',str(r/('candidate-'+package+'-'+mode+'.test')),'-test.run='+regex,'-test.count=1','-test.v'],env)
  if package!='pixel':run('candidate-'+package+'-'+mode+'-oneshot',['arch','-x86_64',str(r/('candidate-'+package+'-'+mode+'.test')),'-test.run=^$','-test.bench=^BenchmarkCopy16RowsNative$','-test.benchtime=1x','-test.cpu=1','-test.benchmem'],env)
print('ALL COPY16 CORRECTNESS/BUILDS COMPLETE; NO PERFORMANCE MEASUREMENTS',flush=True)

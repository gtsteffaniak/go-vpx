from pathlib import Path
import subprocess,tarfile,io,shutil,json,hashlib
root=Path('/Users/thesyncim/GolandProjects/govpx');r=Path('/private/tmp/govpx-amd64-copy16-rows');r.mkdir();(r/'drivers').mkdir();(r/'evidence').mkdir();head='ac259fce071f3ac5fc45603c6bd7e7926bdfcf73';old='691cd0512c4829d9ee40d483205dd223f9eb028d'
for v,sha in [('parent',head),('candidate',head),('old691',old)]:
 (r/v).mkdir()
 with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',sha],cwd=root)))as t:t.extractall(r/v)
arm=r/'candidate/internal/pixel/copy16_rows_arm64.go';amd=r/'candidate/internal/pixel/copy16_rows_amd64.go';amd.write_bytes(arm.read_bytes().replace(b'goexperiment.simd && arm64 && !purego',b'goexperiment.simd && amd64 && !purego',1));stub=r/'candidate/internal/pixel/copy16_rows_other.go';stub.write_bytes(stub.read_bytes().replace(b'!goexperiment.simd || !arm64 || purego',b'!goexperiment.simd || (!arm64 && !amd64) || purego'))
fixtures=['copy16_rows_native_test.go','internal/vp8/dsp/copy16_rows_native_test.go']
for f in fixtures:(r/'old691'/f).write_bytes((r/'parent'/f).read_bytes())
proof={}
for f in fixtures:
 hs={v:hashlib.sha256((r/v/f).read_bytes()).hexdigest()for v in ['parent','candidate','old691']};assert len(set(hs.values()))==1;proof[f]=hs
prod=[]
for p in (r/'candidate').rglob('*.go'):
 if p.name.endswith('_test.go'):continue
 f=str(p.relative_to(r/'candidate'));a=r/'parent'/f
 if not a.exists()or a.read_bytes()!=p.read_bytes():prod.append({'path':f,'parent_sha256':hashlib.sha256(a.read_bytes()).hexdigest()if a.exists()else None,'candidate_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
assert len(prod)==2
assert arm.read_bytes()==(r/'parent/internal/pixel/copy16_rows_arm64.go').read_bytes()
(r/'evidence/snapshot-proof.json').write_text(json.dumps({'head':head,'base':'2ca5bab1110426401e4f9dbfd6fa0da8f568c717','head_tree':subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=root,text=True).strip(),'old_reference':old,'fixture_hashes':proof,'production_delta':prod,'ARM_source_unchanged_sha256':hashlib.sha256(arm.read_bytes()).hexdigest()},indent=2)+'\n')

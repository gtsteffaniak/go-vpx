from pathlib import Path
import shutil,json,hashlib,subprocess
initial=Path('/private/tmp/govpx-amd64-copy16-rows');r=Path('/private/tmp/govpx-amd64-copy16-carry');r.mkdir();(r/'drivers').mkdir();(r/'evidence').mkdir()
for v in ['parent','candidate','old691']:shutil.copytree(initial/v,r/v)
p=r/'candidate/internal/pixel/copy16_rows_amd64.go';s=p.read_text();a=s.index('\tfor row :=');b=s.index('\treturn true',a);s=s[:a]+'''\tfor remaining := 16; ; {
\t\tv := archsimd.LoadUint8x16Array((*[16]byte)(sp))
\t\tv.StoreArray((*[16]byte)(dp))
\t\tremaining--
\t\tif remaining == 0 {
\t\t\tbreak
\t\t}
\t\tsp = unsafe.Add(sp, ss)
\t\tdp = unsafe.Add(dp, ds)
\t}
'''+s[b:];p.write_text(s);subprocess.run(['/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/gofmt','-w',str(p)],check=True)
ledger={'fixed_head':'ac259fce071f3ac5fc45603c6bd7e7926bdfcf73','variants':[{'name':'initial-indexed','source':str(initial/'candidate/internal/pixel/copy16_rows_amd64.go'),'sha256':hashlib.sha256((initial/'candidate/internal/pixel/copy16_rows_amd64.go').read_bytes()).hexdigest(),'evidence':str(initial/'evidence'),'status':'82correctness/buildcommandsPASS+LLVM11instructionloop;noPerformanceClaim'},{'name':'pointer-carry','source':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'status':'oneauthorizedcandidate;breakbeforefinalincrement;unvalidated'}]};(r/'evidence/variant-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
s=(initial/'drivers/validate.py').read_text().replace('/private/tmp/govpx-amd64-copy16-rows','/private/tmp/govpx-amd64-copy16-carry').replace('govpx-ci-amd-copy16','govpx-ci-amd-copy16-carry')
# Frozen parent/old correctness is already proven; rerun complete candidate proof,
# build current parent/old public binaries for later comparison without rerunning oracles.
s=s.replace("for v in ['candidate','parent','old691']:","for v in ['candidate']:")
(r/'drivers/validate.py').write_text(s)
s=(initial/'drivers/codegen.py').read_text().replace('/private/tmp/govpx-amd64-copy16-rows','/private/tmp/govpx-amd64-copy16-carry')
# Candidate-only validation still builds ARM parent binaries; use exact-frozen AMD parent binaries.
s=s.replace("binary=r/(v+'-'+package+('-arm'if arch=='arm64'else'-linux'if platform=='linux'else'-ordinary')+'.test');","binary=(Path('/private/tmp/govpx-amd64-copy16-rows')if arch=='amd64'and v=='parent'else r)/(v+'-'+package+('-arm'if arch=='arm64'else'-linux'if platform=='linux'else'-ordinary')+'.test');")
# Pointer-carry loop has a forward break plus unconditional backedge; still only one conditional.
s=s.replace("assert sum(bool(re.match('j',x))for x in loop['instructions'])==1","assert sum(bool(re.match(r'j(?!mp)',x))for x in loop['instructions'])==1")
(r/'drivers/codegen.py').write_text(s)

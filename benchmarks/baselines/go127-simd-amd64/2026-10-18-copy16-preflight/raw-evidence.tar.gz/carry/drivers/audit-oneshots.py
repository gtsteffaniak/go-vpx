from pathlib import Path
import json,re
# Rosetta1x may print no ns/op when timer resolution rounds to zero.
# These logs are strictly correctness/allocation controls; never use timings.
for name in ['govpx-amd64-copy16-rows','govpx-amd64-copy16-carry']:
 r=Path('/private/tmp')/name;records=[]
 for p in sorted((r/'evidence').glob('*oneshot.log')):
  s=p.read_text();rows=re.findall(r'^(Benchmark\S+)\s+(\d+)\s+(?:[\d.eE+\-]+ ns/op\s+)?(\d+) B/op\s+(\d+) allocs/op',s,re.M);assert len(rows)==8,(p,len(rows));assert re.search(r'^PASS$',s,re.M),p
  for case,it,b,a in rows:assert int(it)==1 and b==a=='0',(p,case,it,b,a)
  records.append({'log':p.name,'cases':[x[0]for x in rows],'all_iterations_one':True,'all_zero_alloc':True,'timing_scope':'Rosetta1x correctness only; nanosecond values excluded from summaries; no performance claim'})
 (r/'evidence/oneshot-audit.json').write_text(json.dumps(records,indent=2)+'\n');cmds=json.loads((r/'evidence/commands.json').read_text());assert all(x['exit']==0for x in cmds);print(name,'commands',len(cmds),'one-shotlogs',len(records),'samples',8*len(records),'allPASSzeroalloc')

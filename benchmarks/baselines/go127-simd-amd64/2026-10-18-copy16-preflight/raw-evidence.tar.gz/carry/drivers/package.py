from pathlib import Path
import hashlib,json,shutil,subprocess,re,tarfile
root=Path('/Users/thesyncim/GolandProjects/govpx');initial=Path('/private/tmp/govpx-amd64-copy16-rows');carry=Path('/private/tmp/govpx-amd64-copy16-carry');out=Path('/private/tmp/govpx-amd64-copy16-carry-ready');out.mkdir();head='ac259fce071f3ac5fc45603c6bd7e7926bdfcf73';old='691cd0512c4829d9ee40d483205dd223f9eb028d'
# Capture old actual Go-copy control: its fixed-width row copy is compiler SIMD,
# unlike handwritten assembly elsewhere in that historical codec revision.
for package in ['dsp','root']:
 ns='github.com/thesyncim/govpx'+('/internal/vp8/dsp.'if package=='dsp'else'.');cmd=['xcrun','llvm-objdump','--disassemble','--demangle','--disassemble-symbols=_'+ns+'copy16Public',str(initial/('old691-'+package+'-ordinary.test'))];run=subprocess.run(cmd,capture_output=True,text=True);assert run.returncode==0;(carry/'evidence'/('old691-'+package+'-copy16-llvm.txt')).write_text(run.stdout+run.stderr);assert 'movups'in run.stdout and 'memmove'not in run.stdout
# Full snapshots/binaries remain privately retained at their measured paths.
# Publish all raw logs/source/proofs while retaining exact binary hashes/paths.
binaries=[]
for label,base in [('initial',initial),('carry',carry)]:
 for d in ['drivers','evidence']:shutil.copytree(base/d,out/label/d)
 for p in sorted(base.glob('*.test')):binaries.append({'variant':label,'private_source_path':str(p),'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
for p in [Path('/private/tmp/govpx-amd64-copy16-prepare.py'),Path('/private/tmp/govpx-amd64-copy16-tests.py'),Path('/private/tmp/govpx-amd64-copy16-carry-prepare.py')]:shutil.copy2(p,out/p.name)
base_trees={}
for v,sha in [('parent',head),('old691',old)]:
 data=subprocess.check_output(['git','ls-tree','-r','--full-tree',sha],cwd=root,text=True);blobs={}
 for line in data.splitlines():
  meta,name=line.split('\t',1);mode,kind,h=meta.split();blobs[name]=h
 checked=[]
 for p in(initial/v).rglob('*.go'):
  if p.name.endswith('_test.go'):continue
  name=str(p.relative_to(initial/v));b=p.read_bytes();h=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert blobs[name]==h,(v,name)
  checked.append({'path':name,'git_blob':h,'sha256':hashlib.sha256(b).hexdigest()})
 base_trees[v]={'git_commit':sha,'production_go_all_exact':True,'files':checked}
(out/'Git-source-proofs.json').write_text(json.dumps(base_trees,indent=2)+'\n')
prod=['internal/pixel/copy16_rows_amd64.go','internal/pixel/copy16_rows_other.go'];tests=['internal/pixel/copy16_amd64_probe_test.go','copy16_frozen_probe_test.go','internal/vp8/dsp/copy16_frozen_probe_test.go'];fixtures=['copy16_rows_native_test.go','internal/vp8/dsp/copy16_rows_native_test.go'];context=['internal/pixel/copy16_rows_arm64.go','internal/pixel/enabled_amd64.go','internal/vp8/dsp/recon.go','vp8_encoder_denoiser.go','vp8_encoder_inter_references.go']
for label,base in [('initial',initial),('carry',carry)]:
 changes=[]
 for p in(base/'candidate').rglob('*.go'):
  if p.name.endswith('_test.go'):continue
  name=str(p.relative_to(base/'candidate'));a=base/'parent'/name
  if not a.exists()or a.read_bytes()!=p.read_bytes():changes.append(name)
 assert sorted(changes)==sorted(prod),(label,changes)
 for v in ['parent','candidate','old691']:
  for f in prod+tests+fixtures+context:
   p=base/v/f
   if not p.exists():continue
   q=out/'source'/label/v/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for f in prod+tests:
 q=out/'overlay'/f;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(carry/'candidate'/f,q)
ledger=json.loads((carry/'evidence/variant-ledger.json').read_text());ledger['variants'][0].update(status='correctness-and-codegen-pass; superseded-by-carry-codegen-only; no-native-measurement',validation_commands=82,helper_inline_cost=76,steady_loop_instructions=11)
ledger['variants'][1].update(status='UNMEASURED-selected-native-candidate;correctness-and-codegen-pass',validation_commands=50,helper_inline_cost=80,steady_loop_instructions=6,ARM_codegen_identity=True,outer_call_caveat='Copy16x16 cost122 and rootcopyY cost114 exceed80; one outer public call remains vs frozenparent')
(out/'VARIANT-LEDGER.json').write_text(json.dumps(ledger,indent=2)+'\n');(out/'BINARY-MANIFEST.json').write_text(json.dumps(binaries,indent=2)+'\n')
(out/'REPORT.md').write_text('''# Unmeasured x64 Copy16 pointer-carry candidate

Base: exact fixed PR45 head ac259fce071f3ac5fc45603c6bd7e7926bdfcf73, tree0a05edcd43baf282272f04937cf911b8a8205f8c. Reference691cd0512c4829d9ee40d483205dd223f9eb028d. This component's historical baseline is Go fixed-width row copy compiled by the same officialGo1.27.2; it is NOT handwritten assembly. No root/Git/README/dependency changes. No native or emulated performance claim; all Rosetta1x timings are excluded from summaries.

Selected PRIVATE candidate: carry/candidate in original workspace `/private/tmp/govpx-amd64-copy16-carry`. overlay/ has exactly2 production files plus3 additional oracle test files. Existing16 public B.Loop fixture cases (8root+8DSP) are unchanged and identical across current/strong45/oldGo. Original snapshots and all executable binaries remain retained at exact private paths in BINARY-MANIFEST.json (SHA256+size). This ready package omits only executable copies/full redundant Git snapshots; all raw logs, optimized LLVM, source overlays/context, independent oracle tests, commands, initial variant evidence, and Git production proofs are retained.

Contract: Enabled guard, unsigned nonnegative strides<2^30, both complete visible windows `15*stride+16<=len` before any unsafe data read/store. For64bitamd64, bounded strides make every offset representable. Guard failure returnsfalse without writes, original row-copy fallback preserves capacity reslicing/partial panics. Each exact16-byte row load immediately precedes that row's exact store, preserving in-row memmove and cross-row propagation. No multi-row preload or alias-noop shortcut. Pointer-carry decrements remaining and breaks before advancing after final row, never forming pointers beyond last visible row. Compiler rotation starts first iteration at the load and finalDECzero falls through toreturn before anyADD. ARM helper source is byte-identical; otherstubtag only excludes newly supportedAMD.

Variant1 indexed:82validation/build commandsPASS. Linux/Darwin root+DSP fastloop11instructions: twoIMUL, address formation, exactVEX128load/store, loop index control. Helper inlines at compiler cost76; publicDSP cost118/rootcopyY110 exceed80, so outer public call is added versus prior inline fallback. Baseline already has MOVUPS16Bload/store and no memmove call; this optimizes repeated bounds/alias/address work, not copywidth.

Variant2 pointer-carry (only authorized follow-up):50candidate validation/build commandsPASS plus4diagnostic inline builds coveringbothvariants. Same complete guards and row semantics. Linux/Darwin root+DSP steadyloop6instructions:2pointerADD,2VMOVDQU128,DEC,JNE; zeroIMUL, perrowbounds/aliasbranches, calls, legacyXMMmoves, YMMops, orvectorspills. Helper inlines at cost80 EXACTLY compiler budget; do not add checks assuming inlining persists. ExpandedDSP.Copy16x16 cost122/rootcopyY114 remainnoninline, so same extra outercall caveat. Four platform/caller exactloop proofs and full LLVM retained. ARM source plus6 actual callers/public fixture closures normalizedIDENTICAL to fixed45.

Correctness: ordinary and checkptr2 Rosetta tests with actual selectedAVX backend (Enabled asserted) and `GODEBUG=cpu.avx=off,cpu.avx2=off` (Enabledfalse asserted), every16×16alignment, source/destination/cross-row overlaps,0strides andsubrowstrides, completefullbacking/canaries, shortvisiblelength withsparecapacity andclippedcapacity, negative/2^30/MaxInt/MinInt bounds, nils. Root+DSP strict frozen original copy loop compares exact panic diagnostics and every backingbyte afterpartial mutations. Parent+old same public oracles pass. Purego and noSIMD candidate runs pass. All288 Rosetta1x fixture samples (192initial/control+96carry) have all8names/log, oneiteration, complete independent output/input/canaryPASS andzeroallocations; timer-resolution-zero fields are ignored because this is correctness-only.

Native plan only, not executed: compare selectedcarry against strongestfixed45 and oldGo on same AMD64 runner. Existing16 actualroot+DSP public B.Loop cases coverdisjoint16/16,32/37,1312/1320,17/31; these representative nonalias cases must establish≥1.5x before accepting a speed claim. Keep0/0,1/7 andtwoexactalias-noop cases ascontrols, never use noops asacceptancebasis. Preserve sixbalanced3way orders/raws/CPUmetadata/PGOoff/zeroalloc/sourceSHA and every slowercontrol. Full existing finalcodec/C/native workflows remain required. No root integration until parent authorizes after PR45 merge/perf gates.
''')
items=[{'path':str(p.relative_to(out)),'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(out.rglob('*'))if p.is_file()];(out/'MANIFEST.json').write_text(json.dumps(items,indent=2)+'\n');tgz=Path(str(out)+'.tar.gz')
with tarfile.open(tgz,'w:gz')as tf:tf.add(out,arcname=out.name)
print(json.dumps({'ready':str(out),'files':len(items),'bytes':sum(x['size']for x in items),'retained_binaries':len(binaries),'manifest_sha256':hashlib.sha256((out/'MANIFEST.json').read_bytes()).hexdigest(),'archive':str(tgz),'archive_bytes':tgz.stat().st_size,'archive_sha256':hashlib.sha256(tgz.read_bytes()).hexdigest()},indent=2))

from pathlib import Path
import subprocess,os,json,re
r=Path('/private/tmp/govpx-amd64-copy16-carry');initial=Path('/private/tmp/govpx-amd64-copy16-rows');root=Path('/Users/thesyncim/GolandProjects/govpx');e=os.environ.copy();e.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-amd-copy16-inline',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GOAMD64='v1',CGO_ENABLED='0',GOOS='darwin',GOARCH='amd64',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go');records=[];proof={}
for v,base in [('initial',initial),('pointer-carry',r)]:
 for package,pkg,pattern in [('dsp','./internal/vp8/dsp','github.com/thesyncim/govpx/internal/vp8/dsp'),('root','.','github.com/thesyncim/govpx')]:
  cmd=[str(root/'scripts/go.sh'),'-C',str(base/'candidate'),'test','-pgo=off','-gcflags=github.com/thesyncim/govpx/internal/pixel=-m=2','-gcflags='+pattern+'=-m=2','-c',pkg,'-o',str(r/(v+'-'+package+'-inline.test'))]
  log=r/'evidence'/(v+'-'+package+'-inline.log')
  with log.open('w')as f:run=subprocess.run(cmd,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
  assert run.returncode==0;records.append({'variant':v,'package':package,'command':cmd,'exit':run.returncode});lines=[x for x in log.read_text().splitlines()if('inline Copy16Rows'in x or 'inline Copy16x16'in x or 'inline copyMacroblockY'in x or 'inlining call to pixel.Copy16Rows'in x)];proof[v+':'+package]=lines;print(v,package,*lines,sep='\n',flush=True)
(r/'evidence/inline-proof.json').write_text(json.dumps(proof,indent=2)+'\n');(r/'evidence/inline-commands.json').write_text(json.dumps(records,indent=2)+'\n')

from pathlib import Path
import subprocess,re,json,hashlib
r=Path('/private/tmp/govpx-amd64-copy16-carry');module='github.com/thesyncim/govpx';syms={'dsp':['internal/vp8/dsp.Copy16x16','internal/vp8/dsp.copy16Public','internal/vp8/dsp.BenchmarkCopy16RowsNative.func1'],'root':['copyMacroblockY','copy16Public','BenchmarkCopy16RowsNative.func1']};blocks={};records=[];summaries={}
for arch in ['amd64','arm64']:
 for v in ['parent','candidate']:
  for package in ['dsp','root']:
   platforms=['darwin','linux']if arch=='amd64'and v=='candidate'else['darwin']
   for platform in platforms:
    binary=(Path('/private/tmp/govpx-amd64-copy16-rows')if arch=='amd64'and v=='parent'else r)/(v+'-'+package+('-arm'if arch=='arm64'else'-linux'if platform=='linux'else'-ordinary')+'.test');prefix='_'if platform=='darwin'else'';ns=module+('/'if package=='dsp'else'.');names=[ns+s for s in syms[package]];cmd=['xcrun','llvm-objdump','--disassemble','--demangle','--disassemble-symbols='+','.join(prefix+n for n in names),str(binary)];run=subprocess.run(cmd,capture_output=True,text=True);assert run.returncode==0;key=f'{arch}-{platform}-{v}-{package}';(r/'evidence'/(key+'-llvm.txt')).write_text(run.stdout+run.stderr);records.append({'name':key,'command':cmd,'exit':run.returncode});pat=r'^[0-9a-f]+ <'+prefix+re.escape(module)+('/'if package=='dsp'else r'\.');parts=re.split(pat+r'([^>]+)>:\n',run.stdout,flags=re.M);blocks[key]={};summaries[key]={}
    for i in range(1,len(parts),2):
     name,body=parts[i:i+2];rex=r'^\s*([0-9a-f]+):\s+(?:[0-9a-f]{2}\s+)+(.+)$'if arch=='amd64'else r'^([0-9a-f]+):\s+[0-9a-f]+\s+([^\n]+)';ins=re.findall(rex,body,re.M);norm=[re.sub(r'0x[0-9a-fA-F]+','ADDR',x)for a,x in ins];blocks[key][name]=norm
     loops=[]
     for addr,text in ins:
      dest=re.match(r'j\w*\s+0x([0-9a-f]+)',text)
      if dest and int(dest.group(1),16)<int(addr,16):
       start=int(dest.group(1),16);end=int(addr,16);rows=[x for a,x in ins if start<=int(a,16)<=end];loops.append({'start':hex(start),'end':hex(end),'instructions':rows,'count':len(rows),'calls':[x for x in rows if re.match('call',x)],'vector_moves':[x for x in rows if 'movdqu'in x or 'movups'in x],'YMM':[x for x in rows if '%ymm'in x],'vector_stack_stores':[x for x in rows if re.search(r'%[xyz]mm\d+,.*\(%r(?:sp|bp)\)',x)]})
     summaries[key][name]={'instructions':len(ins),'calls':[x for x in norm if re.match(r'(call|bl\s)',x)],'backward_loops':loops}
proof={}
for package in ['dsp','root']:
 a=blocks[f'arm64-darwin-parent-{package}'];b=blocks[f'arm64-darwin-candidate-{package}'];assert set(a)==set(b),(package,set(a),set(b));assert len(a)==3,(package,len(a))
 for name in a:
  assert a[name]==b[name],(package,name,[(x,y)for x,y in zip(a[name],b[name])if x!=y][:5]);proof['ARM:'+package+':'+name]={'identical':True,'instructions':len(a[name]),'normalized_sha256':hashlib.sha256('\n'.join(a[name]).encode()).hexdigest()}
for platform in ['darwin','linux']:
 for package in ['dsp','root']:
  key=f'amd64-{platform}-candidate-{package}';target=syms[package][0];loops=summaries[key][target]['backward_loops'];fast=[x for x in loops if len(x['vector_moves'])==2 and all('vmovdqu'in y for y in x['vector_moves'])];assert len(fast)==1,(key,loops);loop=fast[0];assert loop['calls']==[]and loop['YMM']==[]and loop['vector_stack_stores']==[]
  assert all(not re.search(r'\b(?:movups|movaps|movdqu|movdqa)\b',x)for x in loop['instructions']);assert sum(bool(re.match(r'j(?!mp)',x))for x in loop['instructions'])==1
  proof[key+':fast-loop']={'count':loop['count'],'exact_VEX128_load_store':True,'no_calls_YMM_spills_legacy_or_perrow_bounds_alias_checks':True,'instructions':loop['instructions']}
(r/'evidence/codegen-proof.json').write_text(json.dumps(proof,indent=2)+'\n');(r/'evidence/codegen-summary.json').write_text(json.dumps(summaries,indent=2)+'\n');(r/'evidence/codegen-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(proof,indent=2))

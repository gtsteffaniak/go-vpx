
/private/tmp/govpx-fp16-offset-guard/evidence/validation/parent-pixel-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000565d20 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>:
  565d20: 55                           	pushq	%rbp
  565d21: 48 89 e5                     	movq	%rsp, %rbp
  565d24: 48 83 ec 50                  	subq	$0x50, %rsp
  565d28: 48 89 84 24 98 00 00 00      	movq	%rax, 0x98(%rsp)
  565d30: 48 89 bc 24 b0 00 00 00      	movq	%rdi, 0xb0(%rsp)
  565d38: 4c 89 8c 24 c8 00 00 00      	movq	%r9, 0xc8(%rsp)
  565d40: 48 8d 0c 24                  	leaq	(%rsp), %rcx
  565d44: 44 0f 11 39                  	movups	%xmm15, (%rcx)
  565d48: 44 0f 11 79 10               	movups	%xmm15, 0x10(%rcx)
  565d4d: 44 0f 11 79 20               	movups	%xmm15, 0x20(%rcx)
  565d52: 44 0f 11 79 30               	movups	%xmm15, 0x30(%rcx)
  565d57: 44 0f 11 79 40               	movups	%xmm15, 0x40(%rcx)
  565d5c: 48 89 04 24                  	movq	%rax, (%rsp)
  565d60: 48 8b 8c 24 90 00 00 00      	movq	0x90(%rsp), %rcx
  565d68: 48 8d 14 09                  	leaq	(%rcx,%rcx), %rdx
  565d6c: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
  565d71: 48 89 7c 24 10               	movq	%rdi, 0x10(%rsp)
  565d76: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  565d7b: 48 8b 5c 24 60               	movq	0x60(%rsp), %rbx
  565d80: 48 89 5c 24 20               	movq	%rbx, 0x20(%rsp)
  565d85: 48 89 54 24 28               	movq	%rdx, 0x28(%rsp)
  565d8a: 4d 85 c9                     	testq	%r9, %r9
  565d8d: 74 13                        	je	0x565da2 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x82>
  565d8f: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
  565d94: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
  565d99: b8 04 00 00 00               	movl	$0x4, %eax
  565d9e: 66 90                        	nop
  565da0: eb 05                        	jmp	0x565da7 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x87>
  565da2: b8 03 00 00 00               	movl	$0x3, %eax
  565da7: 48 8b 54 24 78               	movq	0x78(%rsp), %rdx
  565dac: 48 85 d2                     	testq	%rdx, %rdx
  565daf: 74 12                        	je	0x565dc3 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa3>
  565db1: 89 c3                        	movl	%eax, %ebx
  565db3: 48 c1 e3 04                  	shlq	$0x4, %rbx
  565db7: 48 89 14 1c                  	movq	%rdx, (%rsp,%rbx)
  565dbb: 48 89 4c 1c 08               	movq	%rcx, 0x8(%rsp,%rbx)
  565dc0: 48 ff c0                     	incq	%rax
  565dc3: 31 c9                        	xorl	%ecx, %ecx
  565dc5: eb 04                        	jmp	0x565dcb <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xab>
  565dc7: 48 8d 4a 01                  	leaq	0x1(%rdx), %rcx
  565dcb: 48 39 c8                     	cmpq	%rcx, %rax
  565dce: 7e 58                        	jle	0x565e28 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x108>
  565dd0: 48 89 ca                     	movq	%rcx, %rdx
  565dd3: 48 c1 e1 04                  	shlq	$0x4, %rcx
  565dd7: 31 db                        	xorl	%ebx, %ebx
  565dd9: eb 05                        	jmp	0x565de0 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xc0>
  565ddb: 48 8d 5f 01                  	leaq	0x1(%rdi), %rbx
  565ddf: 90                           	nop
  565de0: 48 39 d3                     	cmpq	%rdx, %rbx
  565de3: 7d e2                        	jge	0x565dc7 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa7>
  565de5: 48 83 fa 05                  	cmpq	$0x5, %rdx
  565de9: 73 50                        	jae	0x565e3b <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x11b>
  565deb: 48 8b 34 0c                  	movq	(%rsp,%rcx), %rsi
  565def: 48 89 df                     	movq	%rbx, %rdi
  565df2: 48 c1 e3 04                  	shlq	$0x4, %rbx
  565df6: 4c 8b 04 1c                  	movq	(%rsp,%rbx), %r8
  565dfa: 4c 39 c6                     	cmpq	%r8, %rsi
  565dfd: 77 17                        	ja	0x565e16 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xf6>
  565dff: 4c 8b 4c 0c 08               	movq	0x8(%rsp,%rcx), %r9
  565e04: 4d 89 c2                     	movq	%r8, %r10
  565e07: 49 29 f0                     	subq	%rsi, %r8
  565e0a: 4d 39 c1                     	cmpq	%r8, %r9
  565e0d: 77 24                        	ja	0x565e33 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x113>
  565e0f: 4c 39 d6                     	cmpq	%r10, %rsi
  565e12: 77 05                        	ja	0x565e19 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xf9>
  565e14: eb c5                        	jmp	0x565ddb <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xbb>
  565e16: 4d 89 c2                     	movq	%r8, %r10
  565e19: 48 8b 5c 1c 08               	movq	0x8(%rsp,%rbx), %rbx
  565e1e: 4c 29 d6                     	subq	%r10, %rsi
  565e21: 48 39 f3                     	cmpq	%rsi, %rbx
  565e24: 76 b5                        	jbe	0x565ddb <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xbb>
  565e26: eb 0b                        	jmp	0x565e33 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x113>
  565e28: b8 01 00 00 00               	movl	$0x1, %eax
  565e2d: 48 83 c4 50                  	addq	$0x50, %rsp
  565e31: 5d                           	popq	%rbp
  565e32: c3                           	retq
  565e33: 31 c0                        	xorl	%eax, %eax
  565e35: 48 83 c4 50                  	addq	$0x50, %rsp
  565e39: 5d                           	popq	%rbp
  565e3a: c3                           	retq
  565e3b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  565e40: e8 bb 76 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565e45: 90                           	nop
  565e46: cc                           	int3
  565e47: cc                           	int3
  565e48: cc                           	int3
  565e49: cc                           	int3
  565e4a: cc                           	int3
  565e4b: cc                           	int3
  565e4c: cc                           	int3
  565e4d: cc                           	int3
  565e4e: cc                           	int3
  565e4f: cc                           	int3
  565e50: cc                           	int3
  565e51: cc                           	int3
  565e52: cc                           	int3
  565e53: cc                           	int3
  565e54: cc                           	int3
  565e55: cc                           	int3
  565e56: cc                           	int3
  565e57: cc                           	int3
  565e58: cc                           	int3
  565e59: cc                           	int3
  565e5a: cc                           	int3
  565e5b: cc                           	int3
  565e5c: cc                           	int3
  565e5d: cc                           	int3
  565e5e: cc                           	int3
  565e5f: cc                           	int3

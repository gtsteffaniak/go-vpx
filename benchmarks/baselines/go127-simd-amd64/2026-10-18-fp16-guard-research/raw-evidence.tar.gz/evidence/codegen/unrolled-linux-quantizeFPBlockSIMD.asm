
/private/tmp/govpx-fp16-offset-guard/evidence/validation/unrolled-pixel-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000565420 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD>:
  565420: 4c 8d 64 24 d0               	leaq	-0x30(%rsp), %r12
  565425: 4d 3b 66 10                  	cmpq	0x10(%r14), %r12
  565429: 0f 86 56 08 00 00            	jbe	0x565c85 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x865>
  56542f: 55                           	pushq	%rbp
  565430: 48 89 e5                     	movq	%rsp, %rbp
  565433: 48 81 ec a8 00 00 00         	subq	$0xa8, %rsp
  56543a: 48 89 84 24 00 01 00 00      	movq	%rax, 0x100(%rsp)
  565442: 4c 89 8c 24 30 01 00 00      	movq	%r9, 0x130(%rsp)
  56544a: 4c 89 84 24 28 01 00 00      	movq	%r8, 0x128(%rsp)
  565452: 48 89 b4 24 20 01 00 00      	movq	%rsi, 0x120(%rsp)
  56545a: 48 89 bc 24 18 01 00 00      	movq	%rdi, 0x118(%rsp)
  565462: 48 89 9c 24 08 01 00 00      	movq	%rbx, 0x108(%rsp)
  56546a: 48 8b 94 24 d0 00 00 00      	movq	0xd0(%rsp), %rdx
  565472: 4c 8d 62 c0                  	leaq	-0x40(%rdx), %r12
  565476: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
  56547f: 90                           	nop
  565480: 49 81 fc c0 03 00 00         	cmpq	$0x3c0, %r12            # imm = 0x3C0
  565487: 0f 87 09 01 00 00            	ja	0x565596 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x176>
  56548d: 48 f7 c2 0f 00 00 00         	testq	$0xf, %rdx
  565494: 0f 85 f7 00 00 00            	jne	0x565591 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x171>
  56549a: 80 3d 2c fb 25 00 00         	cmpb	$0x0, 0x25fb2c(%rip)    # 0x7c4fcd <github.com/thesyncim/govpx/internal/pixel.Enabled>
  5654a1: 0f 84 e5 00 00 00            	je	0x56558c <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x16c>
  5654a7: 80 3d f6 06 26 00 00         	cmpb	$0x0, 0x2606f6(%rip)    # 0x7c5ba4 <internal/cpu.X86+0x44>
  5654ae: 75 08                        	jne	0x5654b8 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x98>
  5654b0: 45 31 e4                     	xorl	%r12d, %r12d
  5654b3: e9 e8 00 00 00               	jmp	0x5655a0 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
  5654b8: 4c 89 94 24 38 01 00 00      	movq	%r10, 0x138(%rsp)
  5654c0: 4c 89 8c 24 30 01 00 00      	movq	%r9, 0x130(%rsp)
  5654c8: 48 89 8c 24 10 01 00 00      	movq	%rcx, 0x110(%rsp)
  5654d0: 48 89 84 24 00 01 00 00      	movq	%rax, 0x100(%rsp)
  5654d8: 4c 89 9c 24 40 01 00 00      	movq	%r11, 0x140(%rsp)
  5654e0: 4c 8b a4 24 b8 00 00 00      	movq	0xb8(%rsp), %r12
  5654e8: 4c 89 24 24                  	movq	%r12, (%rsp)
  5654ec: 4c 8b a4 24 c0 00 00 00      	movq	0xc0(%rsp), %r12
  5654f4: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  5654f9: 4c 8b a4 24 c8 00 00 00      	movq	0xc8(%rsp), %r12
  565501: 4c 89 64 24 10               	movq	%r12, 0x10(%rsp)
  565506: 4c 8b a4 24 e8 00 00 00      	movq	0xe8(%rsp), %r12
  56550e: 4c 89 64 24 18               	movq	%r12, 0x18(%rsp)
  565513: 4c 8b a4 24 f0 00 00 00      	movq	0xf0(%rsp), %r12
  56551b: 4c 89 64 24 20               	movq	%r12, 0x20(%rsp)
  565520: 4c 8b a4 24 f8 00 00 00      	movq	0xf8(%rsp), %r12
  565528: 4c 89 64 24 28               	movq	%r12, 0x28(%rsp)
  56552d: 48 89 54 24 30               	movq	%rdx, 0x30(%rsp)
  565532: e8 e9 07 00 00               	callq	0x565d20 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>
  565537: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  56553f: 48 8b 94 24 d0 00 00 00      	movq	0xd0(%rsp), %rdx
  565547: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  56554f: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  565557: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  56555f: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  565567: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  56556f: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  565577: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  56557f: 41 89 c4                     	movl	%eax, %r12d
  565582: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  56558a: eb 14                        	jmp	0x5655a0 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
  56558c: 45 31 e4                     	xorl	%r12d, %r12d
  56558f: eb 0f                        	jmp	0x5655a0 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
  565591: 45 31 e4                     	xorl	%r12d, %r12d
  565594: eb 0a                        	jmp	0x5655a0 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
  565596: 45 31 e4                     	xorl	%r12d, %r12d
  565599: 0f 1f 80 00 00 00 00         	nopl	(%rax)
  5655a0: 45 84 e4                     	testb	%r12b, %r12b
  5655a3: 0f 84 bc 01 00 00            	je	0x565765 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x345>
  5655a9: 90                           	nop
  5655aa: 48 8b 8c 24 e8 00 00 00      	movq	0xe8(%rsp), %rcx
  5655b2: 48 85 c9                     	testq	%rcx, %rcx
  5655b5: 74 0b                        	je	0x5655c2 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x1a2>
  5655b7: c5 fa 6f 05 a1 b3 21 00      	vmovdqu	0x21b3a1(%rip), %xmm0   # 0x780960 <github.com/thesyncim/govpx/internal/pixel.fpClassLUT>
  5655bf: 90                           	nop
  5655c0: eb 04                        	jmp	0x5655c6 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x1a6>
  5655c2: 41 0f 10 c7                  	movups	%xmm15, %xmm0
  5655c6: 0f b7 9c 24 da 00 00 00      	movzwl	0xda(%rsp), %ebx
  5655ce: 0f b7 b4 24 d8 00 00 00      	movzwl	0xd8(%rsp), %esi
  5655d6: 44 0f b7 84 24 de 00 00 00   	movzwl	0xde(%rsp), %r8d
  5655df: 44 0f b7 94 24 dc 00 00 00   	movzwl	0xdc(%rsp), %r10d
  5655e8: 44 0f b7 9c 24 e0 00 00 00   	movzwl	0xe0(%rsp), %r11d
  5655f1: 44 0f b7 a4 24 e2 00 00 00   	movzwl	0xe2(%rsp), %r12d
  5655fa: c5 fe 6f 08                  	vmovdqu	(%rax), %ymm1
  5655fe: c4 e2 7d 1d d1               	vpabsw	%ymm1, %ymm2
  565603: c5 f5 71 e1 0f               	vpsraw	$0xf, %ymm1, %ymm1
  565608: 41 bd ff 7f 00 00            	movl	$0x7fff, %r13d          # imm = 0x7FFF
  56560e: c4 c1 f9 6e dd               	vmovq	%r13, %xmm3
  565613: c4 e2 7d 79 db               	vpbroadcastw	%xmm3, %ymm3
  565618: c5 81 c4 e3 00               	vpinsrw	$0x0, %ebx, %xmm15, %xmm4
  56561d: c4 e2 7d 79 ec               	vpbroadcastw	%xmm4, %ymm5
  565622: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
  565627: c5 d9 c4 e6 00               	vpinsrw	$0x0, %esi, %xmm4, %xmm4
  56562c: c4 e3 55 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm5, %ymm4
  565632: c5 ed fd d4                  	vpaddw	%ymm4, %ymm2, %ymm2
  565636: c4 e2 6d 3a d3               	vpminuw	%ymm3, %ymm2, %ymm2
  56563b: c4 c1 01 c4 e0 00            	vpinsrw	$0x0, %r8d, %xmm15, %xmm4
  565641: c4 e2 7d 79 ec               	vpbroadcastw	%xmm4, %ymm5
  565646: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
  56564b: c4 c1 59 c4 e2 00            	vpinsrw	$0x0, %r10d, %xmm4, %xmm4
  565651: c4 e3 55 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm5, %ymm4
  565657: c5 ed e5 e4                  	vpmulhw	%ymm4, %ymm2, %ymm4
  56565b: c4 c1 01 c4 ec 00            	vpinsrw	$0x0, %r12d, %xmm15, %xmm5
  565661: c4 e2 7d 79 f5               	vpbroadcastw	%xmm5, %ymm6
  565666: c4 e2 79 79 ed               	vpbroadcastw	%xmm5, %xmm5
  56566b: c4 c1 51 c4 eb 00            	vpinsrw	$0x0, %r11d, %xmm5, %xmm5
  565671: c4 e3 4d 38 ed 00            	vinserti128	$0x0, %xmm5, %ymm6, %ymm5
  565677: c5 ed 75 f2                  	vpcmpeqw	%ymm2, %ymm2, %ymm6
  56567b: c5 d5 65 d2                  	vpcmpgtw	%ymm2, %ymm5, %ymm2
  56567f: c5 ed ef d6                  	vpxor	%ymm6, %ymm2, %ymm2
  565683: c5 ed db d4                  	vpand	%ymm4, %ymm2, %ymm2
  565687: c5 f5 ef e2                  	vpxor	%ymm2, %ymm1, %ymm4
  56568b: 90                           	nop
  56568c: c5 dd f9 c9                  	vpsubw	%ymm1, %ymm4, %ymm1
  565690: 4d 85 c9                     	testq	%r9, %r9
  565693: 74 0a                        	je	0x56569f <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x27f>
  565695: c4 c1 7e 7f 09               	vmovdqu	%ymm1, (%r9)
  56569a: 48 85 c9                     	testq	%rcx, %rcx
  56569d: eb 03                        	jmp	0x5656a2 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x282>
  56569f: 48 85 c9                     	testq	%rcx, %rcx
  5656a2: c5 dd ef e4                  	vpxor	%ymm4, %ymm4, %ymm4
  5656a6: c5 d5 d5 e9                  	vpmullw	%ymm1, %ymm5, %ymm5
  5656aa: 48 8b 9c 24 b8 00 00 00      	movq	0xb8(%rsp), %rbx
  5656b2: c5 fe 7f 2b                  	vmovdqu	%ymm5, (%rbx)
  5656b6: be 0b 00 00 00               	movl	$0xb, %esi
  5656bb: c4 e1 f9 6e ee               	vmovq	%rsi, %xmm5
  5656c0: c5 f5 75 f1                  	vpcmpeqw	%ymm1, %ymm1, %ymm6
  5656c4: c5 f5 75 cc                  	vpcmpeqw	%ymm4, %ymm1, %ymm1
  5656c8: c5 f5 ef ce                  	vpxor	%ymm6, %ymm1, %ymm1
  5656cc: c5 f5 db 0f                  	vpand	(%rdi), %ymm1, %ymm1
  5656d0: c5 f5 ee cc                  	vpmaxsw	%ymm4, %ymm1, %ymm1
  5656d4: c4 e2 79 79 ed               	vpbroadcastw	%xmm5, %xmm5
  5656d9: 74 43                        	je	0x56571e <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2fe>
  5656db: c4 e3 7d 39 d6 00            	vextracti128	$0x0, %ymm2, %xmm6
  5656e1: c5 c9 ea f5                  	vpminsw	%xmm5, %xmm6, %xmm6
  5656e5: c4 e3 7d 39 d2 01            	vextracti128	$0x1, %ymm2, %xmm2
  5656eb: c5 e9 ea d5                  	vpminsw	%xmm5, %xmm2, %xmm2
  5656ef: c5 fa 6f 3d 59 b2 21 00      	vmovdqu	0x21b259(%rip), %xmm7   # 0x780950 <github.com/thesyncim/govpx/internal/pixel.packByteIndices>
  5656f7: c4 e2 49 00 f7               	vpshufb	%xmm7, %xmm6, %xmm6
  5656fc: c4 e2 69 00 d7               	vpshufb	%xmm7, %xmm2, %xmm2
  565701: c4 e2 79 00 f6               	vpshufb	%xmm6, %xmm0, %xmm6
  565706: c4 e3 f9 16 f6 00            	vpextrq	$0x0, %xmm6, %rsi
  56570c: c4 e2 79 00 d2               	vpshufb	%xmm2, %xmm0, %xmm2
  565711: c4 c3 f9 16 d0 00            	vpextrq	$0x0, %xmm2, %r8
  565717: 48 89 31                     	movq	%rsi, (%rcx)
  56571a: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
  56571e: 0f b7 b4 24 da 00 00 00      	movzwl	0xda(%rsp), %esi
  565726: 44 0f b7 84 24 de 00 00 00   	movzwl	0xde(%rsp), %r8d
  56572f: 44 0f b7 94 24 e2 00 00 00   	movzwl	0xe2(%rsp), %r10d
  565738: c4 e1 f9 6e d6               	vmovq	%rsi, %xmm2
  56573d: c4 c1 f9 6e f0               	vmovq	%r8, %xmm6
  565742: c4 c1 f9 6e fa               	vmovq	%r10, %xmm7
  565747: c4 e2 7d 79 d2               	vpbroadcastw	%xmm2, %ymm2
  56574c: c4 e2 7d 79 f6               	vpbroadcastw	%xmm6, %ymm6
  565751: c4 e2 7d 79 ff               	vpbroadcastw	%xmm7, %ymm7
  565756: be 10 00 00 00               	movl	$0x10, %esi
  56575b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  565760: e9 fb 03 00 00               	jmp	0x565b60 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x740>
  565765: 44 0f b7 a4 24 da 00 00 00   	movzwl	0xda(%rsp), %r12d
  56576e: 44 0f b7 ac 24 de 00 00 00   	movzwl	0xde(%rsp), %r13d
  565777: 44 0f b7 bc 24 e2 00 00 00   	movzwl	0xe2(%rsp), %r15d
  565780: 0f b7 bc 24 d8 00 00 00      	movzwl	0xd8(%rsp), %edi
  565788: 44 0f b7 84 24 dc 00 00 00   	movzwl	0xdc(%rsp), %r8d
  565791: 0f b7 b4 24 e0 00 00 00      	movzwl	0xe0(%rsp), %esi
  565799: c4 c1 f9 6e c4               	vmovq	%r12, %xmm0
  56579e: c4 e2 79 79 c0               	vpbroadcastw	%xmm0, %xmm0
  5657a3: c4 c1 f9 6e cd               	vmovq	%r13, %xmm1
  5657a8: c4 e2 79 79 c9               	vpbroadcastw	%xmm1, %xmm1
  5657ad: c4 c1 f9 6e d7               	vmovq	%r15, %xmm2
  5657b2: c4 e2 79 79 d2               	vpbroadcastw	%xmm2, %xmm2
  5657b7: 41 bc ff 7f 00 00            	movl	$0x7fff, %r12d          # imm = 0x7FFF
  5657bd: c4 c1 f9 6e dc               	vmovq	%r12, %xmm3
  5657c2: c5 f9 c4 e7 00               	vpinsrw	$0x0, %edi, %xmm0, %xmm4
  5657c7: c4 c1 71 c4 e8 00            	vpinsrw	$0x0, %r8d, %xmm1, %xmm5
  5657cd: c5 e9 c4 f6 00               	vpinsrw	$0x0, %esi, %xmm2, %xmm6
  5657d2: 90                           	nop
  5657d3: c5 fa 6f 3d 85 b1 21 00      	vmovdqu	0x21b185(%rip), %xmm7   # 0x780960 <github.com/thesyncim/govpx/internal/pixel.fpClassLUT>
  5657db: c4 e2 79 79 db               	vpbroadcastw	%xmm3, %xmm3
  5657e0: 45 31 e4                     	xorl	%r12d, %r12d
  5657e3: 45 0f 10 c7                  	movups	%xmm15, %xmm8
  5657e7: 4c 8b ac 24 c0 00 00 00      	movq	0xc0(%rsp), %r13
  5657ef: 4c 8b bc 24 c8 00 00 00      	movq	0xc8(%rsp), %r15
  5657f7: 48 8b b4 24 b8 00 00 00      	movq	0xb8(%rsp), %rsi
  5657ff: 90                           	nop
  565800: eb 26                        	jmp	0x565828 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x408>
  565802: 49 89 dd                     	movq	%rbx, %r13
  565805: 4c 8b bc 24 c8 00 00 00      	movq	0xc8(%rsp), %r15
  56580d: 41 0f 10 e2                  	movups	%xmm10, %xmm4
  565811: 41 0f 10 eb                  	movups	%xmm11, %xmm5
  565815: 49 89 fc                     	movq	%rdi, %r12
  565818: 44 0f 10 c6                  	movups	%xmm6, %xmm8
  56581c: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  565824: 41 0f 10 f1                  	movups	%xmm9, %xmm6
  565828: 49 8d 7c 24 08               	leaq	0x8(%r12), %rdi
  56582d: 48 39 fa                     	cmpq	%rdi, %rdx
  565830: 0f 8c 13 02 00 00            	jl	0x565a49 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x629>
  565836: 4d 85 e4                     	testq	%r12, %r12
  565839: 75 0e                        	jne	0x565849 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x429>
  56583b: 44 0f 10 ce                  	movups	%xmm6, %xmm9
  56583f: 44 0f 10 d4                  	movups	%xmm4, %xmm10
  565843: 44 0f 10 dd                  	movups	%xmm5, %xmm11
  565847: eb 17                        	jmp	0x565860 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x440>
  565849: 44 0f 10 ce                  	movups	%xmm6, %xmm9
  56584d: 44 0f 10 d4                  	movups	%xmm4, %xmm10
  565851: 44 0f 10 dd                  	movups	%xmm5, %xmm11
  565855: 0f 10 f2                     	movups	%xmm2, %xmm6
  565858: 0f 10 e0                     	movups	%xmm0, %xmm4
  56585b: 0f 10 e9                     	movups	%xmm1, %xmm5
  56585e: 66 90                        	nop
  565860: 4c 39 e3                     	cmpq	%r12, %rbx
  565863: 0f 82 e6 02 00 00            	jb	0x565b4f <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x72f>
  565869: 4c 89 a4 24 a0 00 00 00      	movq	%r12, 0xa0(%rsp)
  565871: 4f 8d 04 24                  	leaq	(%r12,%r12), %r8
  565875: 4c 29 e3                     	subq	%r12, %rbx
  565878: 49 29 cc                     	subq	%rcx, %r12
  56587b: 49 c1 fc 3f                  	sarq	$0x3f, %r12
  56587f: 4d 21 c4                     	andq	%r8, %r12
  565882: 49 01 c4                     	addq	%rax, %r12
  565885: 48 83 fb 08                  	cmpq	$0x8, %rbx
  565889: 0f 82 bb 02 00 00            	jb	0x565b4a <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x72a>
  56588f: c4 41 7a 6f 24 24            	vmovdqu	(%r12), %xmm12
  565895: c4 42 79 1d ec               	vpabsw	%xmm12, %xmm13
  56589a: c5 91 fd e4                  	vpaddw	%xmm4, %xmm13, %xmm4
  56589e: c4 e2 59 3a e3               	vpminuw	%xmm3, %xmm4, %xmm4
  5658a3: c5 d9 e5 ed                  	vpmulhw	%xmm5, %xmm4, %xmm5
  5658a7: c5 59 75 ec                  	vpcmpeqw	%xmm4, %xmm4, %xmm13
  5658ab: c5 c9 65 e4                  	vpcmpgtw	%xmm4, %xmm6, %xmm4
  5658af: c4 c1 59 ef e5               	vpxor	%xmm13, %xmm4, %xmm4
  5658b4: c5 d1 db e4                  	vpand	%xmm4, %xmm5, %xmm4
  5658b8: 41 0f 10 ef                  	movups	%xmm15, %xmm5
  5658bc: c5 51 f9 ec                  	vpsubw	%xmm4, %xmm5, %xmm13
  5658c0: c4 41 51 65 e4               	vpcmpgtw	%xmm12, %xmm5, %xmm12
  5658c5: 90                           	nop
  5658c6: 90                           	nop
  5658c7: 90                           	nop
  5658c8: c4 43 59 4c e5 c0            	vpblendvb	%xmm12, %xmm13, %xmm4, %xmm12
  5658ce: 4d 85 c9                     	testq	%r9, %r9
  5658d1: 74 3d                        	je	0x565910 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x4f0>
  5658d3: 4c 8b a4 24 a0 00 00 00      	movq	0xa0(%rsp), %r12
  5658db: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  5658e0: 4d 39 e2                     	cmpq	%r12, %r10
  5658e3: 0f 82 5c 02 00 00            	jb	0x565b45 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x725>
  5658e9: 4c 89 d3                     	movq	%r10, %rbx
  5658ec: 4c 29 e3                     	subq	%r12, %rbx
  5658ef: 4d 29 dc                     	subq	%r11, %r12
  5658f2: 49 c1 fc 3f                  	sarq	$0x3f, %r12
  5658f6: 4d 21 c4                     	andq	%r8, %r12
  5658f9: 4d 01 cc                     	addq	%r9, %r12
  5658fc: 0f 1f 40 00                  	nopl	(%rax)
  565900: 48 83 fb 08                  	cmpq	$0x8, %rbx
  565904: 0f 82 35 02 00 00            	jb	0x565b3f <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x71f>
  56590a: c4 41 7a 7f 24 24            	vmovdqu	%xmm12, (%r12)
  565910: c5 99 d5 f6                  	vpmullw	%xmm6, %xmm12, %xmm6
  565914: 4c 8b a4 24 a0 00 00 00      	movq	0xa0(%rsp), %r12
  56591c: 0f 1f 40 00                  	nopl	(%rax)
  565920: 4d 39 e5                     	cmpq	%r12, %r13
  565923: 0f 82 11 02 00 00            	jb	0x565b3a <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x71a>
  565929: 4c 89 eb                     	movq	%r13, %rbx
  56592c: 4d 29 e5                     	subq	%r12, %r13
  56592f: 4d 29 fc                     	subq	%r15, %r12
  565932: 49 c1 fc 3f                  	sarq	$0x3f, %r12
  565936: 4d 21 c4                     	andq	%r8, %r12
  565939: 49 01 f4                     	addq	%rsi, %r12
  56593c: 0f 1f 40 00                  	nopl	(%rax)
  565940: 49 83 fd 08                  	cmpq	$0x8, %r13
  565944: 0f 82 eb 01 00 00            	jb	0x565b35 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x715>
  56594a: c4 c1 7a 7f 34 24            	vmovdqu	%xmm6, (%r12)
  565950: 4c 8b a4 24 20 01 00 00      	movq	0x120(%rsp), %r12
  565958: 4c 8b ac 24 a0 00 00 00      	movq	0xa0(%rsp), %r13
  565960: 4d 39 ec                     	cmpq	%r13, %r12
  565963: 0f 82 c7 01 00 00            	jb	0x565b30 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x710>
  565969: 4d 29 ec                     	subq	%r13, %r12
  56596c: 4c 8b bc 24 28 01 00 00      	movq	0x128(%rsp), %r15
  565974: 4d 29 fd                     	subq	%r15, %r13
  565977: 49 c1 fd 3f                  	sarq	$0x3f, %r13
  56597b: 4d 21 c5                     	andq	%r8, %r13
  56597e: 4d 89 f8                     	movq	%r15, %r8
  565981: 4c 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %r15
  565989: 4d 01 fd                     	addq	%r15, %r13
  56598c: 49 83 fc 08                  	cmpq	$0x8, %r12
  565990: 0f 82 95 01 00 00            	jb	0x565b2b <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x70b>
  565996: c4 c1 19 75 f4               	vpcmpeqw	%xmm12, %xmm12, %xmm6
  56599b: c5 19 75 e5                  	vpcmpeqw	%xmm5, %xmm12, %xmm12
  56599f: c5 99 ef f6                  	vpxor	%xmm6, %xmm12, %xmm6
  5659a3: c4 c1 49 db 75 00            	vpand	(%r13), %xmm6, %xmm6
  5659a9: c5 b9 ee f6                  	vpmaxsw	%xmm6, %xmm8, %xmm6
  5659ad: 4c 8b a4 24 e8 00 00 00      	movq	0xe8(%rsp), %r12
  5659b5: 4d 85 e4                     	testq	%r12, %r12
  5659b8: 0f 84 44 fe ff ff            	je	0x565802 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x3e2>
  5659be: 41 bd 0b 00 00 00            	movl	$0xb, %r13d
  5659c4: c4 41 f9 6e c5               	vmovq	%r13, %xmm8
  5659c9: c4 42 79 79 c0               	vpbroadcastw	%xmm8, %xmm8
  5659ce: c4 c1 59 ea e0               	vpminsw	%xmm8, %xmm4, %xmm4
  5659d3: 4c 8b ac 24 f0 00 00 00      	movq	0xf0(%rsp), %r13
  5659db: 4c 8b bc 24 a0 00 00 00      	movq	0xa0(%rsp), %r15
  5659e3: 4d 39 fd                     	cmpq	%r15, %r13
  5659e6: 0f 82 3a 01 00 00            	jb	0x565b26 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x706>
  5659ec: 4d 29 fd                     	subq	%r15, %r13
  5659ef: 48 8b 94 24 f8 00 00 00      	movq	0xf8(%rsp), %rdx
  5659f7: 49 29 d7                     	subq	%rdx, %r15
  5659fa: 49 c1 ff 3f                  	sarq	$0x3f, %r15
  5659fe: c4 e2 59 00 25 49 af 21 00   	vpshufb	0x21af49(%rip), %xmm4, %xmm4 # 0x780950 <github.com/thesyncim/govpx/internal/pixel.packByteIndices>
  565a07: 48 8b 94 24 a0 00 00 00      	movq	0xa0(%rsp), %rdx
  565a0f: 4c 21 fa                     	andq	%r15, %rdx
  565a12: c4 e2 41 00 e4               	vpshufb	%xmm4, %xmm7, %xmm4
  565a17: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
  565a20: 49 83 fd 07                  	cmpq	$0x7, %r13
  565a24: 0f 86 f7 00 00 00            	jbe	0x565b21 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x701>
  565a2a: c4 c3 f9 16 e5 00            	vpextrq	$0x0, %xmm4, %r13
  565a30: 4d 89 2c 14                  	movq	%r13, (%r12,%rdx)
  565a34: 48 8b 94 24 d0 00 00 00      	movq	0xd0(%rsp), %rdx
  565a3c: 4c 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %r15
  565a44: e9 b9 fd ff ff               	jmp	0x565802 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x3e2>
  565a49: c4 c2 79 23 c0               	vpmovsxwd	%xmm8, %xmm0
  565a4e: c4 c1 79 70 c8 4e            	vpshufd	$0x4e, %xmm8, %xmm1     # xmm1 = xmm8[2,3,0,1]
  565a54: c4 e2 79 23 c9               	vpmovsxwd	%xmm1, %xmm1
  565a59: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  565a5e: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     # xmm1 = xmm0[2,3,0,1]
  565a63: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  565a68: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     # xmm1 = xmm0[1,0,3,2]
  565a6d: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  565a72: c4 e3 79 16 c7 00            	vpextrd	$0x0, %xmm0, %edi
  565a78: 48 63 ff                     	movslq	%edi, %rdi
  565a7b: 48 89 bc 24 98 00 00 00      	movq	%rdi, 0x98(%rsp)
  565a83: 48 89 34 24                  	movq	%rsi, (%rsp)
  565a87: 4c 89 6c 24 08               	movq	%r13, 0x8(%rsp)
  565a8c: 4c 89 7c 24 10               	movq	%r15, 0x10(%rsp)
  565a91: 4c 89 64 24 18               	movq	%r12, 0x18(%rsp)
  565a96: 48 89 54 24 20               	movq	%rdx, 0x20(%rsp)
  565a9b: 8b 94 24 d8 00 00 00         	movl	0xd8(%rsp), %edx
  565aa2: 89 54 24 28                  	movl	%edx, 0x28(%rsp)
  565aa6: 8b 94 24 dc 00 00 00         	movl	0xdc(%rsp), %edx
  565aad: 89 54 24 2c                  	movl	%edx, 0x2c(%rsp)
  565ab1: 8b 94 24 e0 00 00 00         	movl	0xe0(%rsp), %edx
  565ab8: 89 54 24 30                  	movl	%edx, 0x30(%rsp)
  565abc: 48 8b 94 24 e8 00 00 00      	movq	0xe8(%rsp), %rdx
  565ac4: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
  565ac9: 48 8b 94 24 f0 00 00 00      	movq	0xf0(%rsp), %rdx
  565ad1: 48 89 54 24 40               	movq	%rdx, 0x40(%rsp)
  565ad6: 48 8b 94 24 f8 00 00 00      	movq	0xf8(%rsp), %rdx
  565ade: 48 89 54 24 48               	movq	%rdx, 0x48(%rsp)
  565ae3: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  565aeb: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  565af3: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  565afb: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  565b00: e8 5b f7 ff ff               	callq	0x565260 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockTail>
  565b05: 48 8b 94 24 98 00 00 00      	movq	0x98(%rsp), %rdx
  565b0d: 48 39 d0                     	cmpq	%rdx, %rax
  565b10: 48 0f 4f d0                  	cmovgq	%rax, %rdx
  565b14: 48 89 d0                     	movq	%rdx, %rax
  565b17: 48 81 c4 a8 00 00 00         	addq	$0xa8, %rsp
  565b1e: 5d                           	popq	%rbp
  565b1f: 90                           	nop
  565b20: c3                           	retq
  565b21: e8 da 79 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565b26: e8 d5 79 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565b2b: e8 d0 79 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565b30: e8 cb 79 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565b35: e8 c6 79 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565b3a: e8 c1 79 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565b3f: 90                           	nop
  565b40: e8 bb 79 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565b45: e8 b6 79 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565b4a: e8 b1 79 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565b4f: e8 ac 79 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565b54: 48 83 c6 10                  	addq	$0x10, %rsi
  565b58: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)
  565b60: 48 39 f2                     	cmpq	%rsi, %rdx
  565b63: 0f 8e cf 00 00 00            	jle	0x565c38 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x818>
  565b69: 4c 8d 04 70                  	leaq	(%rax,%rsi,2), %r8
  565b6d: c4 41 7e 6f 00               	vmovdqu	(%r8), %ymm8
  565b72: c4 42 7d 1d c8               	vpabsw	%ymm8, %ymm9
  565b77: c5 35 fd ca                  	vpaddw	%ymm2, %ymm9, %ymm9
  565b7b: c4 62 35 3a cb               	vpminuw	%ymm3, %ymm9, %ymm9
  565b80: c5 35 e5 d6                  	vpmulhw	%ymm6, %ymm9, %ymm10
  565b84: c4 c1 3d 71 e0 0f            	vpsraw	$0xf, %ymm8, %ymm8
  565b8a: c4 41 35 75 d9               	vpcmpeqw	%ymm9, %ymm9, %ymm11
  565b8f: c4 41 45 65 c9               	vpcmpgtw	%ymm9, %ymm7, %ymm9
  565b94: c4 41 35 ef cb               	vpxor	%ymm11, %ymm9, %ymm9
  565b99: c4 41 35 db ca               	vpand	%ymm10, %ymm9, %ymm9
  565b9e: c4 41 3d ef d1               	vpxor	%ymm9, %ymm8, %ymm10
  565ba3: c4 41 2d f9 c0               	vpsubw	%ymm8, %ymm10, %ymm8
  565ba8: 4d 85 c9                     	testq	%r9, %r9
  565bab: 74 0e                        	je	0x565bbb <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x79b>
  565bad: 4d 8d 04 71                  	leaq	(%r9,%rsi,2), %r8
  565bb1: c4 41 7e 7f 00               	vmovdqu	%ymm8, (%r8)
  565bb6: 48 85 c9                     	testq	%rcx, %rcx
  565bb9: eb 03                        	jmp	0x565bbe <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x79e>
  565bbb: 48 85 c9                     	testq	%rcx, %rcx
  565bbe: c4 41 45 d5 d0               	vpmullw	%ymm8, %ymm7, %ymm10
  565bc3: 4c 8d 04 73                  	leaq	(%rbx,%rsi,2), %r8
  565bc7: c4 41 7e 7f 10               	vmovdqu	%ymm10, (%r8)
  565bcc: 4c 8d 04 77                  	leaq	(%rdi,%rsi,2), %r8
  565bd0: c4 41 3d 75 d0               	vpcmpeqw	%ymm8, %ymm8, %ymm10
  565bd5: c5 3d 75 c4                  	vpcmpeqw	%ymm4, %ymm8, %ymm8
  565bd9: c4 41 3d ef c2               	vpxor	%ymm10, %ymm8, %ymm8
  565bde: c4 41 3d db 00               	vpand	(%r8), %ymm8, %ymm8
  565be3: c4 c1 75 ee c8               	vpmaxsw	%ymm8, %ymm1, %ymm1
  565be8: 0f 84 66 ff ff ff            	je	0x565b54 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x734>
  565bee: c4 43 7d 39 c8 00            	vextracti128	$0x0, %ymm9, %xmm8
  565bf4: c5 39 ea c5                  	vpminsw	%xmm5, %xmm8, %xmm8
  565bf8: c4 43 7d 39 c9 01            	vextracti128	$0x1, %ymm9, %xmm9
  565bfe: c5 31 ea cd                  	vpminsw	%xmm5, %xmm9, %xmm9
  565c02: c5 7a 6f 15 46 ad 21 00      	vmovdqu	0x21ad46(%rip), %xmm10  # 0x780950 <github.com/thesyncim/govpx/internal/pixel.packByteIndices>
  565c0a: c4 42 39 00 c2               	vpshufb	%xmm10, %xmm8, %xmm8
  565c0f: c4 42 31 00 ca               	vpshufb	%xmm10, %xmm9, %xmm9
  565c14: c4 42 79 00 c0               	vpshufb	%xmm8, %xmm0, %xmm8
  565c19: c4 43 f9 16 c0 00            	vpextrq	$0x0, %xmm8, %r8
  565c1f: c4 42 79 00 c1               	vpshufb	%xmm9, %xmm0, %xmm8
  565c24: c4 43 f9 16 c2 00            	vpextrq	$0x0, %xmm8, %r10
  565c2a: 4c 89 04 31                  	movq	%r8, (%rcx,%rsi)
  565c2e: 4c 89 54 0e 08               	movq	%r10, 0x8(%rsi,%rcx)
  565c33: e9 1c ff ff ff               	jmp	0x565b54 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x734>
  565c38: c4 e3 7d 39 c8 00            	vextracti128	$0x0, %ymm1, %xmm0
  565c3e: c4 e3 7d 39 c9 01            	vextracti128	$0x1, %ymm1, %xmm1
  565c44: c5 f1 ee c0                  	vpmaxsw	%xmm0, %xmm1, %xmm0
  565c48: c4 e2 79 23 c8               	vpmovsxwd	%xmm0, %xmm1
  565c4d: c5 f9 70 c0 4e               	vpshufd	$0x4e, %xmm0, %xmm0     # xmm0 = xmm0[2,3,0,1]
  565c52: c4 e2 79 23 c0               	vpmovsxwd	%xmm0, %xmm0
  565c57: c4 e2 79 3d c1               	vpmaxsd	%xmm1, %xmm0, %xmm0
  565c5c: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     # xmm1 = xmm0[2,3,0,1]
  565c61: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  565c66: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     # xmm1 = xmm0[1,0,3,2]
  565c6b: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  565c70: c4 e3 79 16 c1 00            	vpextrd	$0x0, %xmm0, %ecx
  565c76: 48 63 c1                     	movslq	%ecx, %rax
  565c79: c5 f8 77                     	vzeroupper
  565c7c: 48 81 c4 a8 00 00 00         	addq	$0xa8, %rsp
  565c83: 5d                           	popq	%rbp
  565c84: c3                           	retq
  565c85: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
  565c8a: 48 89 5c 24 58               	movq	%rbx, 0x58(%rsp)
  565c8f: 48 89 4c 24 60               	movq	%rcx, 0x60(%rsp)
  565c94: 48 89 7c 24 68               	movq	%rdi, 0x68(%rsp)
  565c99: 48 89 74 24 70               	movq	%rsi, 0x70(%rsp)
  565c9e: 4c 89 44 24 78               	movq	%r8, 0x78(%rsp)
  565ca3: 4c 89 8c 24 80 00 00 00      	movq	%r9, 0x80(%rsp)
  565cab: 4c 89 94 24 88 00 00 00      	movq	%r10, 0x88(%rsp)
  565cb3: 4c 89 9c 24 90 00 00 00      	movq	%r11, 0x90(%rsp)
  565cbb: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  565cc0: e8 fb 5b f2 ff               	callq	0x48b8c0 <runtime.morestack_noctxt.abi0>
  565cc5: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
  565cca: 48 8b 5c 24 58               	movq	0x58(%rsp), %rbx
  565ccf: 48 8b 4c 24 60               	movq	0x60(%rsp), %rcx
  565cd4: 48 8b 7c 24 68               	movq	0x68(%rsp), %rdi
  565cd9: 48 8b 74 24 70               	movq	0x70(%rsp), %rsi
  565cde: 4c 8b 44 24 78               	movq	0x78(%rsp), %r8
  565ce3: 4c 8b 8c 24 80 00 00 00      	movq	0x80(%rsp), %r9
  565ceb: 4c 8b 94 24 88 00 00 00      	movq	0x88(%rsp), %r10
  565cf3: 4c 8b 9c 24 90 00 00 00      	movq	0x90(%rsp), %r11
  565cfb: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  565d00: e9 1b f7 ff ff               	jmp	0x565420 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD>
  565d05: cc                           	int3
  565d06: cc                           	int3
  565d07: cc                           	int3
  565d08: cc                           	int3
  565d09: cc                           	int3
  565d0a: cc                           	int3
  565d0b: cc                           	int3
  565d0c: cc                           	int3
  565d0d: cc                           	int3
  565d0e: cc                           	int3
  565d0f: cc                           	int3
  565d10: cc                           	int3
  565d11: cc                           	int3
  565d12: cc                           	int3
  565d13: cc                           	int3
  565d14: cc                           	int3
  565d15: cc                           	int3
  565d16: cc                           	int3
  565d17: cc                           	int3
  565d18: cc                           	int3
  565d19: cc                           	int3
  565d1a: cc                           	int3
  565d1b: cc                           	int3
  565d1c: cc                           	int3
  565d1d: cc                           	int3
  565d1e: cc                           	int3
  565d1f: cc                           	int3

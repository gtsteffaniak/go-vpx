
/private/tmp/govpx-fp16-offset-guard/evidence/validation/single-compare-pixel-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000565d20 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>:
  565d20: 55                           	pushq	%rbp
  565d21: 48 89 e5                     	movq	%rsp, %rbp
  565d24: 48 83 ec 50                  	subq	$0x50, %rsp
  565d28: 48 89 84 24 98 00 00 00      	movq	%rax, 0x98(%rsp)
  565d30: 48 89 bc 24 b0 00 00 00      	movq	%rdi, 0xb0(%rsp)
  565d38: 4c 89 8c 24 c8 00 00 00      	movq	%r9, 0xc8(%rsp)
  565d40: 48 8d 0c 24                  	leaq	(%rsp), %rcx
  565d44: 44 0f 11 39                  	movups	%xmm15, (%rcx)
  565d48: 44 0f 11 79 10               	movups	%xmm15, 0x10(%rcx)
  565d4d: 44 0f 11 79 20               	movups	%xmm15, 0x20(%rcx)
  565d52: 44 0f 11 79 30               	movups	%xmm15, 0x30(%rcx)
  565d57: 44 0f 11 79 40               	movups	%xmm15, 0x40(%rcx)
  565d5c: 48 89 04 24                  	movq	%rax, (%rsp)
  565d60: 48 8b 8c 24 90 00 00 00      	movq	0x90(%rsp), %rcx
  565d68: 48 8d 14 09                  	leaq	(%rcx,%rcx), %rdx
  565d6c: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
  565d71: 48 89 7c 24 10               	movq	%rdi, 0x10(%rsp)
  565d76: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  565d7b: 48 8b 5c 24 60               	movq	0x60(%rsp), %rbx
  565d80: 48 89 5c 24 20               	movq	%rbx, 0x20(%rsp)
  565d85: 48 89 54 24 28               	movq	%rdx, 0x28(%rsp)
  565d8a: 4d 85 c9                     	testq	%r9, %r9
  565d8d: 74 13                        	je	0x565da2 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x82>
  565d8f: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
  565d94: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
  565d99: b8 04 00 00 00               	movl	$0x4, %eax
  565d9e: 66 90                        	nop
  565da0: eb 05                        	jmp	0x565da7 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x87>
  565da2: b8 03 00 00 00               	movl	$0x3, %eax
  565da7: 48 8b 54 24 78               	movq	0x78(%rsp), %rdx
  565dac: 48 85 d2                     	testq	%rdx, %rdx
  565daf: 74 12                        	je	0x565dc3 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa3>
  565db1: 89 c3                        	movl	%eax, %ebx
  565db3: 48 c1 e3 04                  	shlq	$0x4, %rbx
  565db7: 48 89 14 1c                  	movq	%rdx, (%rsp,%rbx)
  565dbb: 48 89 4c 1c 08               	movq	%rcx, 0x8(%rsp,%rbx)
  565dc0: 48 ff c0                     	incq	%rax
  565dc3: 31 c9                        	xorl	%ecx, %ecx
  565dc5: eb 04                        	jmp	0x565dcb <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xab>
  565dc7: 48 8d 4a 01                  	leaq	0x1(%rdx), %rcx
  565dcb: 48 39 c8                     	cmpq	%rcx, %rax
  565dce: 7e 4b                        	jle	0x565e1b <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xfb>
  565dd0: 48 89 ca                     	movq	%rcx, %rdx
  565dd3: 48 c1 e1 04                  	shlq	$0x4, %rcx
  565dd7: 31 db                        	xorl	%ebx, %ebx
  565dd9: eb 05                        	jmp	0x565de0 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xc0>
  565ddb: 49 8d 58 01                  	leaq	0x1(%r8), %rbx
  565ddf: 90                           	nop
  565de0: 48 39 d3                     	cmpq	%rdx, %rbx
  565de3: 7d e2                        	jge	0x565dc7 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa7>
  565de5: 48 83 fa 05                  	cmpq	$0x5, %rdx
  565de9: 73 43                        	jae	0x565e2e <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10e>
  565deb: 48 8b 74 0c 08               	movq	0x8(%rsp,%rcx), %rsi
  565df0: 48 8b 3c 0c                  	movq	(%rsp,%rcx), %rdi
  565df4: 49 89 d8                     	movq	%rbx, %r8
  565df7: 48 c1 e3 04                  	shlq	$0x4, %rbx
  565dfb: 4c 8b 4c 1c 08               	movq	0x8(%rsp,%rbx), %r9
  565e00: 48 2b 3c 1c                  	subq	(%rsp,%rbx), %rdi
  565e04: 48 8d 1c 37                  	leaq	(%rdi,%rsi), %rbx
  565e08: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
  565e0c: 4a 8d 34 0e                  	leaq	(%rsi,%r9), %rsi
  565e10: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
  565e14: 48 39 de                     	cmpq	%rbx, %rsi
  565e17: 76 c2                        	jbe	0x565ddb <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xbb>
  565e19: eb 0b                        	jmp	0x565e26 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x106>
  565e1b: b8 01 00 00 00               	movl	$0x1, %eax
  565e20: 48 83 c4 50                  	addq	$0x50, %rsp
  565e24: 5d                           	popq	%rbp
  565e25: c3                           	retq
  565e26: 31 c0                        	xorl	%eax, %eax
  565e28: 48 83 c4 50                  	addq	$0x50, %rsp
  565e2c: 5d                           	popq	%rbp
  565e2d: c3                           	retq
  565e2e: e8 cd 76 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  565e33: 90                           	nop
  565e34: cc                           	int3
  565e35: cc                           	int3
  565e36: cc                           	int3
  565e37: cc                           	int3
  565e38: cc                           	int3
  565e39: cc                           	int3
  565e3a: cc                           	int3
  565e3b: cc                           	int3
  565e3c: cc                           	int3
  565e3d: cc                           	int3
  565e3e: cc                           	int3
  565e3f: cc                           	int3

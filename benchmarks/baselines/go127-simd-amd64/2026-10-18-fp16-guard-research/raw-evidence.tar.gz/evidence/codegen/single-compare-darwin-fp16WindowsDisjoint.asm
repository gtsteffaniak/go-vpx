
/private/tmp/govpx-fp16-offset-guard/evidence/validation/single-compare-pixel-ordinary.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

0000000001158740 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>:
 1158740: 55                           	pushq	%rbp
 1158741: 48 89 e5                     	movq	%rsp, %rbp
 1158744: 48 83 ec 50                  	subq	$0x50, %rsp
 1158748: 48 89 84 24 98 00 00 00      	movq	%rax, 0x98(%rsp)
 1158750: 48 89 bc 24 b0 00 00 00      	movq	%rdi, 0xb0(%rsp)
 1158758: 4c 89 8c 24 c8 00 00 00      	movq	%r9, 0xc8(%rsp)
 1158760: 48 8d 0c 24                  	leaq	(%rsp), %rcx
 1158764: 44 0f 11 39                  	movups	%xmm15, (%rcx)
 1158768: 44 0f 11 79 10               	movups	%xmm15, 0x10(%rcx)
 115876d: 44 0f 11 79 20               	movups	%xmm15, 0x20(%rcx)
 1158772: 44 0f 11 79 30               	movups	%xmm15, 0x30(%rcx)
 1158777: 44 0f 11 79 40               	movups	%xmm15, 0x40(%rcx)
 115877c: 48 89 04 24                  	movq	%rax, (%rsp)
 1158780: 48 8b 8c 24 90 00 00 00      	movq	0x90(%rsp), %rcx
 1158788: 48 8d 14 09                  	leaq	(%rcx,%rcx), %rdx
 115878c: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
 1158791: 48 89 7c 24 10               	movq	%rdi, 0x10(%rsp)
 1158796: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
 115879b: 48 8b 5c 24 60               	movq	0x60(%rsp), %rbx
 11587a0: 48 89 5c 24 20               	movq	%rbx, 0x20(%rsp)
 11587a5: 48 89 54 24 28               	movq	%rdx, 0x28(%rsp)
 11587aa: 4d 85 c9                     	testq	%r9, %r9
 11587ad: 74 13                        	je	0x11587c2 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x82>
 11587af: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
 11587b4: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
 11587b9: b8 04 00 00 00               	movl	$0x4, %eax
 11587be: 66 90                        	nop
 11587c0: eb 05                        	jmp	0x11587c7 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x87>
 11587c2: b8 03 00 00 00               	movl	$0x3, %eax
 11587c7: 48 8b 54 24 78               	movq	0x78(%rsp), %rdx
 11587cc: 48 85 d2                     	testq	%rdx, %rdx
 11587cf: 74 12                        	je	0x11587e3 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa3>
 11587d1: 89 c3                        	movl	%eax, %ebx
 11587d3: 48 c1 e3 04                  	shlq	$0x4, %rbx
 11587d7: 48 89 14 1c                  	movq	%rdx, (%rsp,%rbx)
 11587db: 48 89 4c 1c 08               	movq	%rcx, 0x8(%rsp,%rbx)
 11587e0: 48 ff c0                     	incq	%rax
 11587e3: 31 c9                        	xorl	%ecx, %ecx
 11587e5: eb 04                        	jmp	0x11587eb <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xab>
 11587e7: 48 8d 4a 01                  	leaq	0x1(%rdx), %rcx
 11587eb: 48 39 c8                     	cmpq	%rcx, %rax
 11587ee: 7e 4b                        	jle	0x115883b <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xfb>
 11587f0: 48 89 ca                     	movq	%rcx, %rdx
 11587f3: 48 c1 e1 04                  	shlq	$0x4, %rcx
 11587f7: 31 db                        	xorl	%ebx, %ebx
 11587f9: eb 05                        	jmp	0x1158800 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xc0>
 11587fb: 49 8d 58 01                  	leaq	0x1(%r8), %rbx
 11587ff: 90                           	nop
 1158800: 48 39 d3                     	cmpq	%rdx, %rbx
 1158803: 7d e2                        	jge	0x11587e7 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xa7>
 1158805: 48 83 fa 05                  	cmpq	$0x5, %rdx
 1158809: 73 43                        	jae	0x115884e <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x10e>
 115880b: 48 8b 74 0c 08               	movq	0x8(%rsp,%rcx), %rsi
 1158810: 48 8b 3c 0c                  	movq	(%rsp,%rcx), %rdi
 1158814: 49 89 d8                     	movq	%rbx, %r8
 1158817: 48 c1 e3 04                  	shlq	$0x4, %rbx
 115881b: 4c 8b 4c 1c 08               	movq	0x8(%rsp,%rbx), %r9
 1158820: 48 2b 3c 1c                  	subq	(%rsp,%rbx), %rdi
 1158824: 48 8d 1c 37                  	leaq	(%rdi,%rsi), %rbx
 1158828: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
 115882c: 4a 8d 34 0e                  	leaq	(%rsi,%r9), %rsi
 1158830: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
 1158834: 48 39 de                     	cmpq	%rbx, %rsi
 1158837: 76 c2                        	jbe	0x11587fb <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0xbb>
 1158839: eb 0b                        	jmp	0x1158846 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint+0x106>
 115883b: b8 01 00 00 00               	movl	$0x1, %eax
 1158840: 48 83 c4 50                  	addq	$0x50, %rsp
 1158844: 5d                           	popq	%rbp
 1158845: c3                           	retq
 1158846: 31 c0                        	xorl	%eax, %eax
 1158848: 48 83 c4 50                  	addq	$0x50, %rsp
 115884c: 5d                           	popq	%rbp
 115884d: c3                           	retq
 115884e: e8 cd 0e f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 1158853: 90                           	nop
 1158854: cc                           	int3
 1158855: cc                           	int3
 1158856: cc                           	int3
 1158857: cc                           	int3
 1158858: cc                           	int3
 1158859: cc                           	int3
 115885a: cc                           	int3
 115885b: cc                           	int3
 115885c: cc                           	int3
 115885d: cc                           	int3
 115885e: cc                           	int3
 115885f: cc                           	int3

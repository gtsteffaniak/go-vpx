
/private/tmp/govpx-fp16-offset-guard/evidence/validation/parent-arm-encoder.test:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001001ba540 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD>:
1001ba540: f9400b90    	ldr	x16, [x28, #0x10]
1001ba544: d100c3f1    	sub	x17, sp, #0x30
1001ba548: eb10023f    	cmp	x17, x16
1001ba54c: 54001649    	b.ls	0x1001ba814 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2d4>
1001ba550: f8150ffe    	str	x30, [sp, #-0xb0]!
1001ba554: f81f83fd    	stur	x29, [sp, #-0x8]
1001ba558: d10023fd    	sub	x29, sp, #0x8
1001ba55c: f90067e0    	str	x0, [sp, #0xc8]
1001ba560: f90073e3    	str	x3, [sp, #0xe0]
1001ba564: f9007fe6    	str	x6, [sp, #0xf8]
1001ba568: f9008be9    	str	x9, [sp, #0x110]
1001ba56c: f9009bed    	str	x13, [sp, #0x130]
1001ba570: 798177f0    	ldrsh	x16, [sp, #0xba]
1001ba574: 79817ff1    	ldrsh	x17, [sp, #0xbe]
1001ba578: 798187f3    	ldrsh	x19, [sp, #0xc2]
1001ba57c: 798173f4    	ldrsh	x20, [sp, #0xb8]
1001ba580: 79817bf5    	ldrsh	x21, [sp, #0xbc]
1001ba584: 798183f6    	ldrsh	x22, [sp, #0xc0]
1001ba588: 4f00e400    	movi.16b	v0, #0x0
1001ba58c: 4ea01c01    	mov.16b	v1, v0
1001ba590: 4e021e00    	mov.h	v0[0], w16
1001ba594: 4e020400    	dup.8h	v0, v0[0]
1001ba598: 4ea11c22    	mov.16b	v2, v1
1001ba59c: 4e021e21    	mov.h	v1[0], w17
1001ba5a0: 4e020421    	dup.8h	v1, v1[0]
1001ba5a4: 4ea21c43    	mov.16b	v3, v2
1001ba5a8: 4e021e62    	mov.h	v2[0], w19
1001ba5ac: 4e020442    	dup.8h	v2, v2[0]
1001ba5b0: 4f00e404    	movi.16b	v4, #0x0
1001ba5b4: d28ffff0    	mov	x16, #0x7fff            ; =32767
1001ba5b8: 4e021e04    	mov.h	v4[0], w16
1001ba5bc: 4ea01c05    	mov.16b	v5, v0
1001ba5c0: 4e021e80    	mov.h	v0[0], w20
1001ba5c4: 4ea11c26    	mov.16b	v6, v1
1001ba5c8: 4e021ea1    	mov.h	v1[0], w21
1001ba5cc: 4ea21c47    	mov.16b	v7, v2
1001ba5d0: 4e021ec2    	mov.h	v2[0], w22
1001ba5d4: d503201f    	nop
1001ba5d8: d0001e5b    	adrp	x27, 0x100584000 <_go:buildinfo>
1001ba5dc: 9131037b    	add	x27, x27, #0xc40
1001ba5e0: 3dc00368    	ldr	q8, [x27]
1001ba5e4: 4e020484    	dup.8h	v4, v4[0]
1001ba5e8: aa1f03f0    	mov	x16, xzr
1001ba5ec: 4ea31c69    	mov.16b	v9, v3
1001ba5f0: 14000007    	b	0x1001ba60c <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0xcc>
1001ba5f4: 4eac1d80    	mov.16b	v0, v12
1001ba5f8: 4ea21c49    	mov.16b	v9, v2
1001ba5fc: aa1103f0    	mov	x16, x17
1001ba600: 4ea11c23    	mov.16b	v3, v1
1001ba604: 4eab1d61    	mov.16b	v1, v11
1001ba608: 4eaa1d42    	mov.16b	v2, v10
1001ba60c: 91002211    	add	x17, x16, #0x8
1001ba610: eb11019f    	cmp	x12, x17
1001ba614: 54000acb    	b.lt	0x1001ba76c <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x22c>
1001ba618: b50000b0    	cbnz	x16, 0x1001ba62c <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0xec>
1001ba61c: 4ea21c4a    	mov.16b	v10, v2
1001ba620: 4ea11c2b    	mov.16b	v11, v1
1001ba624: 4ea01c0c    	mov.16b	v12, v0
1001ba628: 14000007    	b	0x1001ba644 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x104>
1001ba62c: 4ea21c4a    	mov.16b	v10, v2
1001ba630: 4ea11c2b    	mov.16b	v11, v1
1001ba634: 4ea01c0c    	mov.16b	v12, v0
1001ba638: 4ea71ce2    	mov.16b	v2, v7
1001ba63c: 4ea61cc1    	mov.16b	v1, v6
1001ba640: 4ea51ca0    	mov.16b	v0, v5
1001ba644: eb10003f    	cmp	x1, x16
1001ba648: 54000e03    	b.lo	0x1001ba808 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2c8>
1001ba64c: cb020213    	sub	x19, x16, x2
1001ba650: 8a93fe13    	and	x19, x16, x19, asr #63
1001ba654: cb100034    	sub	x20, x1, x16
1001ba658: 8b130413    	add	x19, x0, x19, lsl #1
1001ba65c: f100229f    	cmp	x20, #0x8
1001ba660: 54000d03    	b.lo	0x1001ba800 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2c0>
1001ba664: 3dc0026d    	ldr	q13, [x19]
1001ba668: 4e60b9ae    	abs.8h	v14, v13
1001ba66c: 4e6085c0    	add.8h	v0, v14, v0
1001ba670: 6e646c00    	umin.8h	v0, v0, v4
1001ba674: 4e623c0e    	cmge.8h	v14, v0, v2
1001ba678: 0e61c00f    	smull.4s	v15, v0, v1
1001ba67c: 4e61c000    	smull2.4s	v0, v0, v1
1001ba680: 4e4059e0    	uzp2.8h	v0, v15, v0
1001ba684: 4e201dc0    	and.16b	v0, v14, v0
1001ba688: 6e608521    	sub.8h	v1, v9, v0
1001ba68c: 4e6d352d    	cmgt.8h	v13, v9, v13
1001ba690: 6eed1c01    	bif.16b	v1, v0, v13
1001ba694: b4000146    	cbz	x6, 0x1001ba6bc <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x17c>
1001ba698: eb1000ff    	cmp	x7, x16
1001ba69c: 54000ae3    	b.lo	0x1001ba7f8 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2b8>
1001ba6a0: cb1000f3    	sub	x19, x7, x16
1001ba6a4: cb080214    	sub	x20, x16, x8
1001ba6a8: 8a94fe14    	and	x20, x16, x20, asr #63
1001ba6ac: 8b1404d4    	add	x20, x6, x20, lsl #1
1001ba6b0: f100227f    	cmp	x19, #0x8
1001ba6b4: 540009e3    	b.lo	0x1001ba7f0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2b0>
1001ba6b8: 3d800281    	str	q1, [x20]
1001ba6bc: 4e629c22    	mul.8h	v2, v1, v2
1001ba6c0: eb10015f    	cmp	x10, x16
1001ba6c4: 54000923    	b.lo	0x1001ba7e8 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2a8>
1001ba6c8: cb100153    	sub	x19, x10, x16
1001ba6cc: cb0b0214    	sub	x20, x16, x11
1001ba6d0: 8a94fe14    	and	x20, x16, x20, asr #63
1001ba6d4: 8b140534    	add	x20, x9, x20, lsl #1
1001ba6d8: f100227f    	cmp	x19, #0x8
1001ba6dc: 54000823    	b.lo	0x1001ba7e0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2a0>
1001ba6e0: 3d800282    	str	q2, [x20]
1001ba6e4: eb10009f    	cmp	x4, x16
1001ba6e8: 54000783    	b.lo	0x1001ba7d8 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x298>
1001ba6ec: cb100093    	sub	x19, x4, x16
1001ba6f0: cb050214    	sub	x20, x16, x5
1001ba6f4: 8a94fe14    	and	x20, x16, x20, asr #63
1001ba6f8: 8b140474    	add	x20, x3, x20, lsl #1
1001ba6fc: f100227f    	cmp	x19, #0x8
1001ba700: 54000683    	b.lo	0x1001ba7d0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x290>
1001ba704: 3dc00282    	ldr	q2, [x20]
1001ba708: 6e698c21    	cmeq.8h	v1, v1, v9
1001ba70c: 6e205821    	mvn.16b	v1, v1
1001ba710: 4e221c21    	and.16b	v1, v1, v2
1001ba714: 4e616461    	smax.8h	v1, v3, v1
1001ba718: b400024d    	cbz	x13, 0x1001ba760 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x220>
1001ba71c: d2800173    	mov	x19, #0xb               ; =11
1001ba720: 4ea91d22    	mov.16b	v2, v9
1001ba724: 4e021e69    	mov.h	v9[0], w19
1001ba728: 4e020523    	dup.8h	v3, v9[0]
1001ba72c: 4e636c00    	smin.8h	v0, v0, v3
1001ba730: eb1001df    	cmp	x14, x16
1001ba734: 540004a3    	b.lo	0x1001ba7c8 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x288>
1001ba738: cb1001d4    	sub	x20, x14, x16
1001ba73c: cb0f0215    	sub	x21, x16, x15
1001ba740: 2e212800    	sqxtun.8b	v0, v0
1001ba744: 8a95fe10    	and	x16, x16, x21, asr #63
1001ba748: 4e000100    	tbl.16b	v0, { v8 }, v0
1001ba74c: f1001e9f    	cmp	x20, #0x7
1001ba750: 54000389    	b.ls	0x1001ba7c0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x280>
1001ba754: 4e083c14    	mov.d	x20, v0[0]
1001ba758: f83069b4    	str	x20, [x13, x16]
1001ba75c: 17ffffa6    	b	0x1001ba5f4 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0xb4>
1001ba760: d2800173    	mov	x19, #0xb               ; =11
1001ba764: 4ea91d22    	mov.16b	v2, v9
1001ba768: 17ffffa3    	b	0x1001ba5f4 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0xb4>
1001ba76c: b940bbf1    	ldr	w17, [sp, #0xb8]
1001ba770: 4e70a860    	smaxv.8h	h0, v3
1001ba774: 0e023c13    	umov.h	w19, v0[0]
1001ba778: 93403e73    	sxth	x19, w19
1001ba77c: f90053f3    	str	x19, [sp, #0xa0]
1001ba780: b9000bf1    	str	w17, [sp, #0x8]
1001ba784: b940bff1    	ldr	w17, [sp, #0xbc]
1001ba788: b9000ff1    	str	w17, [sp, #0xc]
1001ba78c: b940c3f1    	ldr	w17, [sp, #0xc0]
1001ba790: b90013f1    	str	w17, [sp, #0x10]
1001ba794: a901bbed    	stp	x13, x14, [sp, #0x18]
1001ba798: f90017ef    	str	x15, [sp, #0x28]
1001ba79c: aa0c03ed    	mov	x13, x12
1001ba7a0: aa1003ec    	mov	x12, x16
1001ba7a4: 97fffef7    	bl	0x1001ba380 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockTail>
1001ba7a8: f94053ee    	ldr	x14, [sp, #0xa0]
1001ba7ac: eb0e001f    	cmp	x0, x14
1001ba7b0: 9a8ec000    	csel	x0, x0, x14, gt
1001ba7b4: f85f83fd    	ldur	x29, [sp, #-0x8]
1001ba7b8: f84b07fe    	ldr	x30, [sp], #0xb0
1001ba7bc: d65f03c0    	ret
1001ba7c0: aa1403e0    	mov	x0, x20
1001ba7c4: 97fb303b    	bl	0x1000868b0 <_runtime.panicBounds>
1001ba7c8: aa1003e0    	mov	x0, x16
1001ba7cc: 97fb3039    	bl	0x1000868b0 <_runtime.panicBounds>
1001ba7d0: aa1303e0    	mov	x0, x19
1001ba7d4: 97fb3037    	bl	0x1000868b0 <_runtime.panicBounds>
1001ba7d8: aa1003e0    	mov	x0, x16
1001ba7dc: 97fb3035    	bl	0x1000868b0 <_runtime.panicBounds>
1001ba7e0: aa1303e0    	mov	x0, x19
1001ba7e4: 97fb3033    	bl	0x1000868b0 <_runtime.panicBounds>
1001ba7e8: aa1003e0    	mov	x0, x16
1001ba7ec: 97fb3031    	bl	0x1000868b0 <_runtime.panicBounds>
1001ba7f0: aa1303e0    	mov	x0, x19
1001ba7f4: 97fb302f    	bl	0x1000868b0 <_runtime.panicBounds>
1001ba7f8: aa1003e0    	mov	x0, x16
1001ba7fc: 97fb302d    	bl	0x1000868b0 <_runtime.panicBounds>
1001ba800: aa1403e0    	mov	x0, x20
1001ba804: 97fb302b    	bl	0x1000868b0 <_runtime.panicBounds>
1001ba808: aa1003e0    	mov	x0, x16
1001ba80c: 97fb3029    	bl	0x1000868b0 <_runtime.panicBounds>
1001ba810: d503201f    	nop
1001ba814: a90187e0    	stp	x0, x1, [sp, #0x18]
1001ba818: a9028fe2    	stp	x2, x3, [sp, #0x28]
1001ba81c: a90397e4    	stp	x4, x5, [sp, #0x38]
1001ba820: a9049fe6    	stp	x6, x7, [sp, #0x48]
1001ba824: a905a7e8    	stp	x8, x9, [sp, #0x58]
1001ba828: a906afea    	stp	x10, x11, [sp, #0x68]
1001ba82c: a907b7ec    	stp	x12, x13, [sp, #0x78]
1001ba830: a908bfee    	stp	x14, x15, [sp, #0x88]
1001ba834: aa1e03e3    	mov	x3, x30
1001ba838: 97fb27da    	bl	0x1000847a0 <_runtime.morestack_noctxt.abi0>
1001ba83c: a94187e0    	ldp	x0, x1, [sp, #0x18]
1001ba840: a9428fe2    	ldp	x2, x3, [sp, #0x28]
1001ba844: a94397e4    	ldp	x4, x5, [sp, #0x38]
1001ba848: a9449fe6    	ldp	x6, x7, [sp, #0x48]
1001ba84c: a945a7e8    	ldp	x8, x9, [sp, #0x58]
1001ba850: a946afea    	ldp	x10, x11, [sp, #0x68]
1001ba854: a947b7ec    	ldp	x12, x13, [sp, #0x78]
1001ba858: a948bfee    	ldp	x14, x15, [sp, #0x88]
1001ba85c: 17ffff39    	b	0x1001ba540 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD>


/private/tmp/govpx-fp16-offset-guard/evidence/validation/unrolled-pixel-ordinary.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

0000000001157e40 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD>:
 1157e40: 4c 8d 64 24 d0               	leaq	-0x30(%rsp), %r12
 1157e45: 4d 3b 66 10                  	cmpq	0x10(%r14), %r12
 1157e49: 0f 86 56 08 00 00            	jbe	0x11586a5 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x865>
 1157e4f: 55                           	pushq	%rbp
 1157e50: 48 89 e5                     	movq	%rsp, %rbp
 1157e53: 48 81 ec a8 00 00 00         	subq	$0xa8, %rsp
 1157e5a: 48 89 84 24 00 01 00 00      	movq	%rax, 0x100(%rsp)
 1157e62: 4c 89 8c 24 30 01 00 00      	movq	%r9, 0x130(%rsp)
 1157e6a: 4c 89 84 24 28 01 00 00      	movq	%r8, 0x128(%rsp)
 1157e72: 48 89 b4 24 20 01 00 00      	movq	%rsi, 0x120(%rsp)
 1157e7a: 48 89 bc 24 18 01 00 00      	movq	%rdi, 0x118(%rsp)
 1157e82: 48 89 9c 24 08 01 00 00      	movq	%rbx, 0x108(%rsp)
 1157e8a: 48 8b 94 24 d0 00 00 00      	movq	0xd0(%rsp), %rdx
 1157e92: 4c 8d 62 c0                  	leaq	-0x40(%rdx), %r12
 1157e96: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
 1157e9f: 90                           	nop
 1157ea0: 49 81 fc c0 03 00 00         	cmpq	$0x3c0, %r12            ## imm = 0x3C0
 1157ea7: 0f 87 09 01 00 00            	ja	0x1157fb6 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x176>
 1157ead: 48 f7 c2 0f 00 00 00         	testq	$0xf, %rdx
 1157eb4: 0f 85 f7 00 00 00            	jne	0x1157fb1 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x171>
 1157eba: 80 3d ac 27 25 00 00         	cmpb	$0x0, 0x2527ac(%rip)    ## 0x13aa66d <_github.com/thesyncim/govpx/internal/pixel.Enabled>
 1157ec1: 0f 84 e5 00 00 00            	je	0x1157fac <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x16c>
 1157ec7: 80 3d 16 33 25 00 00         	cmpb	$0x0, 0x253316(%rip)    ## 0x13ab1e4 <_internal/cpu.X86+0x44>
 1157ece: 75 08                        	jne	0x1157ed8 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x98>
 1157ed0: 45 31 e4                     	xorl	%r12d, %r12d
 1157ed3: e9 e8 00 00 00               	jmp	0x1157fc0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
 1157ed8: 4c 89 94 24 38 01 00 00      	movq	%r10, 0x138(%rsp)
 1157ee0: 4c 89 8c 24 30 01 00 00      	movq	%r9, 0x130(%rsp)
 1157ee8: 48 89 8c 24 10 01 00 00      	movq	%rcx, 0x110(%rsp)
 1157ef0: 48 89 84 24 00 01 00 00      	movq	%rax, 0x100(%rsp)
 1157ef8: 4c 89 9c 24 40 01 00 00      	movq	%r11, 0x140(%rsp)
 1157f00: 4c 8b a4 24 b8 00 00 00      	movq	0xb8(%rsp), %r12
 1157f08: 4c 89 24 24                  	movq	%r12, (%rsp)
 1157f0c: 4c 8b a4 24 c0 00 00 00      	movq	0xc0(%rsp), %r12
 1157f14: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
 1157f19: 4c 8b a4 24 c8 00 00 00      	movq	0xc8(%rsp), %r12
 1157f21: 4c 89 64 24 10               	movq	%r12, 0x10(%rsp)
 1157f26: 4c 8b a4 24 e8 00 00 00      	movq	0xe8(%rsp), %r12
 1157f2e: 4c 89 64 24 18               	movq	%r12, 0x18(%rsp)
 1157f33: 4c 8b a4 24 f0 00 00 00      	movq	0xf0(%rsp), %r12
 1157f3b: 4c 89 64 24 20               	movq	%r12, 0x20(%rsp)
 1157f40: 4c 8b a4 24 f8 00 00 00      	movq	0xf8(%rsp), %r12
 1157f48: 4c 89 64 24 28               	movq	%r12, 0x28(%rsp)
 1157f4d: 48 89 54 24 30               	movq	%rdx, 0x30(%rsp)
 1157f52: e8 e9 07 00 00               	callq	0x1158740 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>
 1157f57: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
 1157f5f: 48 8b 94 24 d0 00 00 00      	movq	0xd0(%rsp), %rdx
 1157f67: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
 1157f6f: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
 1157f77: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
 1157f7f: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
 1157f87: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
 1157f8f: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
 1157f97: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
 1157f9f: 41 89 c4                     	movl	%eax, %r12d
 1157fa2: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
 1157faa: eb 14                        	jmp	0x1157fc0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
 1157fac: 45 31 e4                     	xorl	%r12d, %r12d
 1157faf: eb 0f                        	jmp	0x1157fc0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
 1157fb1: 45 31 e4                     	xorl	%r12d, %r12d
 1157fb4: eb 0a                        	jmp	0x1157fc0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
 1157fb6: 45 31 e4                     	xorl	%r12d, %r12d
 1157fb9: 0f 1f 80 00 00 00 00         	nopl	(%rax)
 1157fc0: 45 84 e4                     	testb	%r12b, %r12b
 1157fc3: 0f 84 bc 01 00 00            	je	0x1158185 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x345>
 1157fc9: 90                           	nop
 1157fca: 48 8b 8c 24 e8 00 00 00      	movq	0xe8(%rsp), %rcx
 1157fd2: 48 85 c9                     	testq	%rcx, %rcx
 1157fd5: 74 0b                        	je	0x1157fe2 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x1a2>
 1157fd7: c5 fa 6f 05 b1 e9 20 00      	vmovdqu	0x20e9b1(%rip), %xmm0   ## 0x1366990 <_github.com/thesyncim/govpx/internal/pixel.fpClassLUT>
 1157fdf: 90                           	nop
 1157fe0: eb 04                        	jmp	0x1157fe6 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x1a6>
 1157fe2: 41 0f 10 c7                  	movups	%xmm15, %xmm0
 1157fe6: 0f b7 9c 24 da 00 00 00      	movzwl	0xda(%rsp), %ebx
 1157fee: 0f b7 b4 24 d8 00 00 00      	movzwl	0xd8(%rsp), %esi
 1157ff6: 44 0f b7 84 24 de 00 00 00   	movzwl	0xde(%rsp), %r8d
 1157fff: 44 0f b7 94 24 dc 00 00 00   	movzwl	0xdc(%rsp), %r10d
 1158008: 44 0f b7 9c 24 e0 00 00 00   	movzwl	0xe0(%rsp), %r11d
 1158011: 44 0f b7 a4 24 e2 00 00 00   	movzwl	0xe2(%rsp), %r12d
 115801a: c5 fe 6f 08                  	vmovdqu	(%rax), %ymm1
 115801e: c4 e2 7d 1d d1               	vpabsw	%ymm1, %ymm2
 1158023: c5 f5 71 e1 0f               	vpsraw	$0xf, %ymm1, %ymm1
 1158028: 41 bd ff 7f 00 00            	movl	$0x7fff, %r13d          ## imm = 0x7FFF
 115802e: c4 c1 f9 6e dd               	vmovq	%r13, %xmm3
 1158033: c4 e2 7d 79 db               	vpbroadcastw	%xmm3, %ymm3
 1158038: c5 81 c4 e3 00               	vpinsrw	$0x0, %ebx, %xmm15, %xmm4
 115803d: c4 e2 7d 79 ec               	vpbroadcastw	%xmm4, %ymm5
 1158042: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
 1158047: c5 d9 c4 e6 00               	vpinsrw	$0x0, %esi, %xmm4, %xmm4
 115804c: c4 e3 55 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm5, %ymm4
 1158052: c5 ed fd d4                  	vpaddw	%ymm4, %ymm2, %ymm2
 1158056: c4 e2 6d 3a d3               	vpminuw	%ymm3, %ymm2, %ymm2
 115805b: c4 c1 01 c4 e0 00            	vpinsrw	$0x0, %r8d, %xmm15, %xmm4
 1158061: c4 e2 7d 79 ec               	vpbroadcastw	%xmm4, %ymm5
 1158066: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
 115806b: c4 c1 59 c4 e2 00            	vpinsrw	$0x0, %r10d, %xmm4, %xmm4
 1158071: c4 e3 55 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm5, %ymm4
 1158077: c5 ed e5 e4                  	vpmulhw	%ymm4, %ymm2, %ymm4
 115807b: c4 c1 01 c4 ec 00            	vpinsrw	$0x0, %r12d, %xmm15, %xmm5
 1158081: c4 e2 7d 79 f5               	vpbroadcastw	%xmm5, %ymm6
 1158086: c4 e2 79 79 ed               	vpbroadcastw	%xmm5, %xmm5
 115808b: c4 c1 51 c4 eb 00            	vpinsrw	$0x0, %r11d, %xmm5, %xmm5
 1158091: c4 e3 4d 38 ed 00            	vinserti128	$0x0, %xmm5, %ymm6, %ymm5
 1158097: c5 ed 75 f2                  	vpcmpeqw	%ymm2, %ymm2, %ymm6
 115809b: c5 d5 65 d2                  	vpcmpgtw	%ymm2, %ymm5, %ymm2
 115809f: c5 ed ef d6                  	vpxor	%ymm6, %ymm2, %ymm2
 11580a3: c5 ed db d4                  	vpand	%ymm4, %ymm2, %ymm2
 11580a7: c5 f5 ef e2                  	vpxor	%ymm2, %ymm1, %ymm4
 11580ab: 90                           	nop
 11580ac: c5 dd f9 c9                  	vpsubw	%ymm1, %ymm4, %ymm1
 11580b0: 4d 85 c9                     	testq	%r9, %r9
 11580b3: 74 0a                        	je	0x11580bf <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x27f>
 11580b5: c4 c1 7e 7f 09               	vmovdqu	%ymm1, (%r9)
 11580ba: 48 85 c9                     	testq	%rcx, %rcx
 11580bd: eb 03                        	jmp	0x11580c2 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x282>
 11580bf: 48 85 c9                     	testq	%rcx, %rcx
 11580c2: c5 dd ef e4                  	vpxor	%ymm4, %ymm4, %ymm4
 11580c6: c5 d5 d5 e9                  	vpmullw	%ymm1, %ymm5, %ymm5
 11580ca: 48 8b 9c 24 b8 00 00 00      	movq	0xb8(%rsp), %rbx
 11580d2: c5 fe 7f 2b                  	vmovdqu	%ymm5, (%rbx)
 11580d6: be 0b 00 00 00               	movl	$0xb, %esi
 11580db: c4 e1 f9 6e ee               	vmovq	%rsi, %xmm5
 11580e0: c5 f5 75 f1                  	vpcmpeqw	%ymm1, %ymm1, %ymm6
 11580e4: c5 f5 75 cc                  	vpcmpeqw	%ymm4, %ymm1, %ymm1
 11580e8: c5 f5 ef ce                  	vpxor	%ymm6, %ymm1, %ymm1
 11580ec: c5 f5 db 0f                  	vpand	(%rdi), %ymm1, %ymm1
 11580f0: c5 f5 ee cc                  	vpmaxsw	%ymm4, %ymm1, %ymm1
 11580f4: c4 e2 79 79 ed               	vpbroadcastw	%xmm5, %xmm5
 11580f9: 74 43                        	je	0x115813e <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2fe>
 11580fb: c4 e3 7d 39 d6 00            	vextracti128	$0x0, %ymm2, %xmm6
 1158101: c5 c9 ea f5                  	vpminsw	%xmm5, %xmm6, %xmm6
 1158105: c4 e3 7d 39 d2 01            	vextracti128	$0x1, %ymm2, %xmm2
 115810b: c5 e9 ea d5                  	vpminsw	%xmm5, %xmm2, %xmm2
 115810f: c5 fa 6f 3d 69 e8 20 00      	vmovdqu	0x20e869(%rip), %xmm7   ## 0x1366980 <_github.com/thesyncim/govpx/internal/pixel.packByteIndices>
 1158117: c4 e2 49 00 f7               	vpshufb	%xmm7, %xmm6, %xmm6
 115811c: c4 e2 69 00 d7               	vpshufb	%xmm7, %xmm2, %xmm2
 1158121: c4 e2 79 00 f6               	vpshufb	%xmm6, %xmm0, %xmm6
 1158126: c4 e3 f9 16 f6 00            	vpextrq	$0x0, %xmm6, %rsi
 115812c: c4 e2 79 00 d2               	vpshufb	%xmm2, %xmm0, %xmm2
 1158131: c4 c3 f9 16 d0 00            	vpextrq	$0x0, %xmm2, %r8
 1158137: 48 89 31                     	movq	%rsi, (%rcx)
 115813a: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
 115813e: 0f b7 b4 24 da 00 00 00      	movzwl	0xda(%rsp), %esi
 1158146: 44 0f b7 84 24 de 00 00 00   	movzwl	0xde(%rsp), %r8d
 115814f: 44 0f b7 94 24 e2 00 00 00   	movzwl	0xe2(%rsp), %r10d
 1158158: c4 e1 f9 6e d6               	vmovq	%rsi, %xmm2
 115815d: c4 c1 f9 6e f0               	vmovq	%r8, %xmm6
 1158162: c4 c1 f9 6e fa               	vmovq	%r10, %xmm7
 1158167: c4 e2 7d 79 d2               	vpbroadcastw	%xmm2, %ymm2
 115816c: c4 e2 7d 79 f6               	vpbroadcastw	%xmm6, %ymm6
 1158171: c4 e2 7d 79 ff               	vpbroadcastw	%xmm7, %ymm7
 1158176: be 10 00 00 00               	movl	$0x10, %esi
 115817b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
 1158180: e9 fb 03 00 00               	jmp	0x1158580 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x740>
 1158185: 44 0f b7 a4 24 da 00 00 00   	movzwl	0xda(%rsp), %r12d
 115818e: 44 0f b7 ac 24 de 00 00 00   	movzwl	0xde(%rsp), %r13d
 1158197: 44 0f b7 bc 24 e2 00 00 00   	movzwl	0xe2(%rsp), %r15d
 11581a0: 0f b7 bc 24 d8 00 00 00      	movzwl	0xd8(%rsp), %edi
 11581a8: 44 0f b7 84 24 dc 00 00 00   	movzwl	0xdc(%rsp), %r8d
 11581b1: 0f b7 b4 24 e0 00 00 00      	movzwl	0xe0(%rsp), %esi
 11581b9: c4 c1 f9 6e c4               	vmovq	%r12, %xmm0
 11581be: c4 e2 79 79 c0               	vpbroadcastw	%xmm0, %xmm0
 11581c3: c4 c1 f9 6e cd               	vmovq	%r13, %xmm1
 11581c8: c4 e2 79 79 c9               	vpbroadcastw	%xmm1, %xmm1
 11581cd: c4 c1 f9 6e d7               	vmovq	%r15, %xmm2
 11581d2: c4 e2 79 79 d2               	vpbroadcastw	%xmm2, %xmm2
 11581d7: 41 bc ff 7f 00 00            	movl	$0x7fff, %r12d          ## imm = 0x7FFF
 11581dd: c4 c1 f9 6e dc               	vmovq	%r12, %xmm3
 11581e2: c5 f9 c4 e7 00               	vpinsrw	$0x0, %edi, %xmm0, %xmm4
 11581e7: c4 c1 71 c4 e8 00            	vpinsrw	$0x0, %r8d, %xmm1, %xmm5
 11581ed: c5 e9 c4 f6 00               	vpinsrw	$0x0, %esi, %xmm2, %xmm6
 11581f2: 90                           	nop
 11581f3: c5 fa 6f 3d 95 e7 20 00      	vmovdqu	0x20e795(%rip), %xmm7   ## 0x1366990 <_github.com/thesyncim/govpx/internal/pixel.fpClassLUT>
 11581fb: c4 e2 79 79 db               	vpbroadcastw	%xmm3, %xmm3
 1158200: 45 31 e4                     	xorl	%r12d, %r12d
 1158203: 45 0f 10 c7                  	movups	%xmm15, %xmm8
 1158207: 4c 8b ac 24 c0 00 00 00      	movq	0xc0(%rsp), %r13
 115820f: 4c 8b bc 24 c8 00 00 00      	movq	0xc8(%rsp), %r15
 1158217: 48 8b b4 24 b8 00 00 00      	movq	0xb8(%rsp), %rsi
 115821f: 90                           	nop
 1158220: eb 26                        	jmp	0x1158248 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x408>
 1158222: 49 89 dd                     	movq	%rbx, %r13
 1158225: 4c 8b bc 24 c8 00 00 00      	movq	0xc8(%rsp), %r15
 115822d: 41 0f 10 e2                  	movups	%xmm10, %xmm4
 1158231: 41 0f 10 eb                  	movups	%xmm11, %xmm5
 1158235: 49 89 fc                     	movq	%rdi, %r12
 1158238: 44 0f 10 c6                  	movups	%xmm6, %xmm8
 115823c: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
 1158244: 41 0f 10 f1                  	movups	%xmm9, %xmm6
 1158248: 49 8d 7c 24 08               	leaq	0x8(%r12), %rdi
 115824d: 48 39 fa                     	cmpq	%rdi, %rdx
 1158250: 0f 8c 13 02 00 00            	jl	0x1158469 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x629>
 1158256: 4d 85 e4                     	testq	%r12, %r12
 1158259: 75 0e                        	jne	0x1158269 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x429>
 115825b: 44 0f 10 ce                  	movups	%xmm6, %xmm9
 115825f: 44 0f 10 d4                  	movups	%xmm4, %xmm10
 1158263: 44 0f 10 dd                  	movups	%xmm5, %xmm11
 1158267: eb 17                        	jmp	0x1158280 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x440>
 1158269: 44 0f 10 ce                  	movups	%xmm6, %xmm9
 115826d: 44 0f 10 d4                  	movups	%xmm4, %xmm10
 1158271: 44 0f 10 dd                  	movups	%xmm5, %xmm11
 1158275: 0f 10 f2                     	movups	%xmm2, %xmm6
 1158278: 0f 10 e0                     	movups	%xmm0, %xmm4
 115827b: 0f 10 e9                     	movups	%xmm1, %xmm5
 115827e: 66 90                        	nop
 1158280: 4c 39 e3                     	cmpq	%r12, %rbx
 1158283: 0f 82 e6 02 00 00            	jb	0x115856f <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x72f>
 1158289: 4c 89 a4 24 a0 00 00 00      	movq	%r12, 0xa0(%rsp)
 1158291: 4f 8d 04 24                  	leaq	(%r12,%r12), %r8
 1158295: 4c 29 e3                     	subq	%r12, %rbx
 1158298: 49 29 cc                     	subq	%rcx, %r12
 115829b: 49 c1 fc 3f                  	sarq	$0x3f, %r12
 115829f: 4d 21 c4                     	andq	%r8, %r12
 11582a2: 49 01 c4                     	addq	%rax, %r12
 11582a5: 48 83 fb 08                  	cmpq	$0x8, %rbx
 11582a9: 0f 82 bb 02 00 00            	jb	0x115856a <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x72a>
 11582af: c4 41 7a 6f 24 24            	vmovdqu	(%r12), %xmm12
 11582b5: c4 42 79 1d ec               	vpabsw	%xmm12, %xmm13
 11582ba: c5 91 fd e4                  	vpaddw	%xmm4, %xmm13, %xmm4
 11582be: c4 e2 59 3a e3               	vpminuw	%xmm3, %xmm4, %xmm4
 11582c3: c5 d9 e5 ed                  	vpmulhw	%xmm5, %xmm4, %xmm5
 11582c7: c5 59 75 ec                  	vpcmpeqw	%xmm4, %xmm4, %xmm13
 11582cb: c5 c9 65 e4                  	vpcmpgtw	%xmm4, %xmm6, %xmm4
 11582cf: c4 c1 59 ef e5               	vpxor	%xmm13, %xmm4, %xmm4
 11582d4: c5 d1 db e4                  	vpand	%xmm4, %xmm5, %xmm4
 11582d8: 41 0f 10 ef                  	movups	%xmm15, %xmm5
 11582dc: c5 51 f9 ec                  	vpsubw	%xmm4, %xmm5, %xmm13
 11582e0: c4 41 51 65 e4               	vpcmpgtw	%xmm12, %xmm5, %xmm12
 11582e5: 90                           	nop
 11582e6: 90                           	nop
 11582e7: 90                           	nop
 11582e8: c4 43 59 4c e5 c0            	vpblendvb	%xmm12, %xmm13, %xmm4, %xmm12
 11582ee: 4d 85 c9                     	testq	%r9, %r9
 11582f1: 74 3d                        	je	0x1158330 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x4f0>
 11582f3: 4c 8b a4 24 a0 00 00 00      	movq	0xa0(%rsp), %r12
 11582fb: 0f 1f 44 00 00               	nopl	(%rax,%rax)
 1158300: 4d 39 e2                     	cmpq	%r12, %r10
 1158303: 0f 82 5c 02 00 00            	jb	0x1158565 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x725>
 1158309: 4c 89 d3                     	movq	%r10, %rbx
 115830c: 4c 29 e3                     	subq	%r12, %rbx
 115830f: 4d 29 dc                     	subq	%r11, %r12
 1158312: 49 c1 fc 3f                  	sarq	$0x3f, %r12
 1158316: 4d 21 c4                     	andq	%r8, %r12
 1158319: 4d 01 cc                     	addq	%r9, %r12
 115831c: 0f 1f 40 00                  	nopl	(%rax)
 1158320: 48 83 fb 08                  	cmpq	$0x8, %rbx
 1158324: 0f 82 35 02 00 00            	jb	0x115855f <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x71f>
 115832a: c4 41 7a 7f 24 24            	vmovdqu	%xmm12, (%r12)
 1158330: c5 99 d5 f6                  	vpmullw	%xmm6, %xmm12, %xmm6
 1158334: 4c 8b a4 24 a0 00 00 00      	movq	0xa0(%rsp), %r12
 115833c: 0f 1f 40 00                  	nopl	(%rax)
 1158340: 4d 39 e5                     	cmpq	%r12, %r13
 1158343: 0f 82 11 02 00 00            	jb	0x115855a <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x71a>
 1158349: 4c 89 eb                     	movq	%r13, %rbx
 115834c: 4d 29 e5                     	subq	%r12, %r13
 115834f: 4d 29 fc                     	subq	%r15, %r12
 1158352: 49 c1 fc 3f                  	sarq	$0x3f, %r12
 1158356: 4d 21 c4                     	andq	%r8, %r12
 1158359: 49 01 f4                     	addq	%rsi, %r12
 115835c: 0f 1f 40 00                  	nopl	(%rax)
 1158360: 49 83 fd 08                  	cmpq	$0x8, %r13
 1158364: 0f 82 eb 01 00 00            	jb	0x1158555 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x715>
 115836a: c4 c1 7a 7f 34 24            	vmovdqu	%xmm6, (%r12)
 1158370: 4c 8b a4 24 20 01 00 00      	movq	0x120(%rsp), %r12
 1158378: 4c 8b ac 24 a0 00 00 00      	movq	0xa0(%rsp), %r13
 1158380: 4d 39 ec                     	cmpq	%r13, %r12
 1158383: 0f 82 c7 01 00 00            	jb	0x1158550 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x710>
 1158389: 4d 29 ec                     	subq	%r13, %r12
 115838c: 4c 8b bc 24 28 01 00 00      	movq	0x128(%rsp), %r15
 1158394: 4d 29 fd                     	subq	%r15, %r13
 1158397: 49 c1 fd 3f                  	sarq	$0x3f, %r13
 115839b: 4d 21 c5                     	andq	%r8, %r13
 115839e: 4d 89 f8                     	movq	%r15, %r8
 11583a1: 4c 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %r15
 11583a9: 4d 01 fd                     	addq	%r15, %r13
 11583ac: 49 83 fc 08                  	cmpq	$0x8, %r12
 11583b0: 0f 82 95 01 00 00            	jb	0x115854b <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x70b>
 11583b6: c4 c1 19 75 f4               	vpcmpeqw	%xmm12, %xmm12, %xmm6
 11583bb: c5 19 75 e5                  	vpcmpeqw	%xmm5, %xmm12, %xmm12
 11583bf: c5 99 ef f6                  	vpxor	%xmm6, %xmm12, %xmm6
 11583c3: c4 c1 49 db 75 00            	vpand	(%r13), %xmm6, %xmm6
 11583c9: c5 b9 ee f6                  	vpmaxsw	%xmm6, %xmm8, %xmm6
 11583cd: 4c 8b a4 24 e8 00 00 00      	movq	0xe8(%rsp), %r12
 11583d5: 4d 85 e4                     	testq	%r12, %r12
 11583d8: 0f 84 44 fe ff ff            	je	0x1158222 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x3e2>
 11583de: 41 bd 0b 00 00 00            	movl	$0xb, %r13d
 11583e4: c4 41 f9 6e c5               	vmovq	%r13, %xmm8
 11583e9: c4 42 79 79 c0               	vpbroadcastw	%xmm8, %xmm8
 11583ee: c4 c1 59 ea e0               	vpminsw	%xmm8, %xmm4, %xmm4
 11583f3: 4c 8b ac 24 f0 00 00 00      	movq	0xf0(%rsp), %r13
 11583fb: 4c 8b bc 24 a0 00 00 00      	movq	0xa0(%rsp), %r15
 1158403: 4d 39 fd                     	cmpq	%r15, %r13
 1158406: 0f 82 3a 01 00 00            	jb	0x1158546 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x706>
 115840c: 4d 29 fd                     	subq	%r15, %r13
 115840f: 48 8b 94 24 f8 00 00 00      	movq	0xf8(%rsp), %rdx
 1158417: 49 29 d7                     	subq	%rdx, %r15
 115841a: 49 c1 ff 3f                  	sarq	$0x3f, %r15
 115841e: c4 e2 59 00 25 59 e5 20 00   	vpshufb	0x20e559(%rip), %xmm4, %xmm4 ## 0x1366980 <_github.com/thesyncim/govpx/internal/pixel.packByteIndices>
 1158427: 48 8b 94 24 a0 00 00 00      	movq	0xa0(%rsp), %rdx
 115842f: 4c 21 fa                     	andq	%r15, %rdx
 1158432: c4 e2 41 00 e4               	vpshufb	%xmm4, %xmm7, %xmm4
 1158437: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
 1158440: 49 83 fd 07                  	cmpq	$0x7, %r13
 1158444: 0f 86 f7 00 00 00            	jbe	0x1158541 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x701>
 115844a: c4 c3 f9 16 e5 00            	vpextrq	$0x0, %xmm4, %r13
 1158450: 4d 89 2c 14                  	movq	%r13, (%r12,%rdx)
 1158454: 48 8b 94 24 d0 00 00 00      	movq	0xd0(%rsp), %rdx
 115845c: 4c 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %r15
 1158464: e9 b9 fd ff ff               	jmp	0x1158222 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x3e2>
 1158469: c4 c2 79 23 c0               	vpmovsxwd	%xmm8, %xmm0
 115846e: c4 c1 79 70 c8 4e            	vpshufd	$0x4e, %xmm8, %xmm1     ## xmm1 = xmm8[2,3,0,1]
 1158474: c4 e2 79 23 c9               	vpmovsxwd	%xmm1, %xmm1
 1158479: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
 115847e: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     ## xmm1 = xmm0[2,3,0,1]
 1158483: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
 1158488: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     ## xmm1 = xmm0[1,0,3,2]
 115848d: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
 1158492: c4 e3 79 16 c7 00            	vpextrd	$0x0, %xmm0, %edi
 1158498: 48 63 ff                     	movslq	%edi, %rdi
 115849b: 48 89 bc 24 98 00 00 00      	movq	%rdi, 0x98(%rsp)
 11584a3: 48 89 34 24                  	movq	%rsi, (%rsp)
 11584a7: 4c 89 6c 24 08               	movq	%r13, 0x8(%rsp)
 11584ac: 4c 89 7c 24 10               	movq	%r15, 0x10(%rsp)
 11584b1: 4c 89 64 24 18               	movq	%r12, 0x18(%rsp)
 11584b6: 48 89 54 24 20               	movq	%rdx, 0x20(%rsp)
 11584bb: 8b 94 24 d8 00 00 00         	movl	0xd8(%rsp), %edx
 11584c2: 89 54 24 28                  	movl	%edx, 0x28(%rsp)
 11584c6: 8b 94 24 dc 00 00 00         	movl	0xdc(%rsp), %edx
 11584cd: 89 54 24 2c                  	movl	%edx, 0x2c(%rsp)
 11584d1: 8b 94 24 e0 00 00 00         	movl	0xe0(%rsp), %edx
 11584d8: 89 54 24 30                  	movl	%edx, 0x30(%rsp)
 11584dc: 48 8b 94 24 e8 00 00 00      	movq	0xe8(%rsp), %rdx
 11584e4: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
 11584e9: 48 8b 94 24 f0 00 00 00      	movq	0xf0(%rsp), %rdx
 11584f1: 48 89 54 24 40               	movq	%rdx, 0x40(%rsp)
 11584f6: 48 8b 94 24 f8 00 00 00      	movq	0xf8(%rsp), %rdx
 11584fe: 48 89 54 24 48               	movq	%rdx, 0x48(%rsp)
 1158503: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
 115850b: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
 1158513: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
 115851b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
 1158520: e8 5b f7 ff ff               	callq	0x1157c80 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockTail>
 1158525: 48 8b 94 24 98 00 00 00      	movq	0x98(%rsp), %rdx
 115852d: 48 39 d0                     	cmpq	%rdx, %rax
 1158530: 48 0f 4f d0                  	cmovgq	%rax, %rdx
 1158534: 48 89 d0                     	movq	%rdx, %rax
 1158537: 48 81 c4 a8 00 00 00         	addq	$0xa8, %rsp
 115853e: 5d                           	popq	%rbp
 115853f: 90                           	nop
 1158540: c3                           	retq
 1158541: e8 da 11 f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 1158546: e8 d5 11 f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 115854b: e8 d0 11 f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 1158550: e8 cb 11 f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 1158555: e8 c6 11 f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 115855a: e8 c1 11 f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 115855f: 90                           	nop
 1158560: e8 bb 11 f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 1158565: e8 b6 11 f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 115856a: e8 b1 11 f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 115856f: e8 ac 11 f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 1158574: 48 83 c6 10                  	addq	$0x10, %rsi
 1158578: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)
 1158580: 48 39 f2                     	cmpq	%rsi, %rdx
 1158583: 0f 8e cf 00 00 00            	jle	0x1158658 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x818>
 1158589: 4c 8d 04 70                  	leaq	(%rax,%rsi,2), %r8
 115858d: c4 41 7e 6f 00               	vmovdqu	(%r8), %ymm8
 1158592: c4 42 7d 1d c8               	vpabsw	%ymm8, %ymm9
 1158597: c5 35 fd ca                  	vpaddw	%ymm2, %ymm9, %ymm9
 115859b: c4 62 35 3a cb               	vpminuw	%ymm3, %ymm9, %ymm9
 11585a0: c5 35 e5 d6                  	vpmulhw	%ymm6, %ymm9, %ymm10
 11585a4: c4 c1 3d 71 e0 0f            	vpsraw	$0xf, %ymm8, %ymm8
 11585aa: c4 41 35 75 d9               	vpcmpeqw	%ymm9, %ymm9, %ymm11
 11585af: c4 41 45 65 c9               	vpcmpgtw	%ymm9, %ymm7, %ymm9
 11585b4: c4 41 35 ef cb               	vpxor	%ymm11, %ymm9, %ymm9
 11585b9: c4 41 35 db ca               	vpand	%ymm10, %ymm9, %ymm9
 11585be: c4 41 3d ef d1               	vpxor	%ymm9, %ymm8, %ymm10
 11585c3: c4 41 2d f9 c0               	vpsubw	%ymm8, %ymm10, %ymm8
 11585c8: 4d 85 c9                     	testq	%r9, %r9
 11585cb: 74 0e                        	je	0x11585db <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x79b>
 11585cd: 4d 8d 04 71                  	leaq	(%r9,%rsi,2), %r8
 11585d1: c4 41 7e 7f 00               	vmovdqu	%ymm8, (%r8)
 11585d6: 48 85 c9                     	testq	%rcx, %rcx
 11585d9: eb 03                        	jmp	0x11585de <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x79e>
 11585db: 48 85 c9                     	testq	%rcx, %rcx
 11585de: c4 41 45 d5 d0               	vpmullw	%ymm8, %ymm7, %ymm10
 11585e3: 4c 8d 04 73                  	leaq	(%rbx,%rsi,2), %r8
 11585e7: c4 41 7e 7f 10               	vmovdqu	%ymm10, (%r8)
 11585ec: 4c 8d 04 77                  	leaq	(%rdi,%rsi,2), %r8
 11585f0: c4 41 3d 75 d0               	vpcmpeqw	%ymm8, %ymm8, %ymm10
 11585f5: c5 3d 75 c4                  	vpcmpeqw	%ymm4, %ymm8, %ymm8
 11585f9: c4 41 3d ef c2               	vpxor	%ymm10, %ymm8, %ymm8
 11585fe: c4 41 3d db 00               	vpand	(%r8), %ymm8, %ymm8
 1158603: c4 c1 75 ee c8               	vpmaxsw	%ymm8, %ymm1, %ymm1
 1158608: 0f 84 66 ff ff ff            	je	0x1158574 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x734>
 115860e: c4 43 7d 39 c8 00            	vextracti128	$0x0, %ymm9, %xmm8
 1158614: c5 39 ea c5                  	vpminsw	%xmm5, %xmm8, %xmm8
 1158618: c4 43 7d 39 c9 01            	vextracti128	$0x1, %ymm9, %xmm9
 115861e: c5 31 ea cd                  	vpminsw	%xmm5, %xmm9, %xmm9
 1158622: c5 7a 6f 15 56 e3 20 00      	vmovdqu	0x20e356(%rip), %xmm10  ## 0x1366980 <_github.com/thesyncim/govpx/internal/pixel.packByteIndices>
 115862a: c4 42 39 00 c2               	vpshufb	%xmm10, %xmm8, %xmm8
 115862f: c4 42 31 00 ca               	vpshufb	%xmm10, %xmm9, %xmm9
 1158634: c4 42 79 00 c0               	vpshufb	%xmm8, %xmm0, %xmm8
 1158639: c4 43 f9 16 c0 00            	vpextrq	$0x0, %xmm8, %r8
 115863f: c4 42 79 00 c1               	vpshufb	%xmm9, %xmm0, %xmm8
 1158644: c4 43 f9 16 c2 00            	vpextrq	$0x0, %xmm8, %r10
 115864a: 4c 89 04 31                  	movq	%r8, (%rcx,%rsi)
 115864e: 4c 89 54 0e 08               	movq	%r10, 0x8(%rsi,%rcx)
 1158653: e9 1c ff ff ff               	jmp	0x1158574 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x734>
 1158658: c4 e3 7d 39 c8 00            	vextracti128	$0x0, %ymm1, %xmm0
 115865e: c4 e3 7d 39 c9 01            	vextracti128	$0x1, %ymm1, %xmm1
 1158664: c5 f1 ee c0                  	vpmaxsw	%xmm0, %xmm1, %xmm0
 1158668: c4 e2 79 23 c8               	vpmovsxwd	%xmm0, %xmm1
 115866d: c5 f9 70 c0 4e               	vpshufd	$0x4e, %xmm0, %xmm0     ## xmm0 = xmm0[2,3,0,1]
 1158672: c4 e2 79 23 c0               	vpmovsxwd	%xmm0, %xmm0
 1158677: c4 e2 79 3d c1               	vpmaxsd	%xmm1, %xmm0, %xmm0
 115867c: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     ## xmm1 = xmm0[2,3,0,1]
 1158681: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
 1158686: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     ## xmm1 = xmm0[1,0,3,2]
 115868b: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
 1158690: c4 e3 79 16 c1 00            	vpextrd	$0x0, %xmm0, %ecx
 1158696: 48 63 c1                     	movslq	%ecx, %rax
 1158699: c5 f8 77                     	vzeroupper
 115869c: 48 81 c4 a8 00 00 00         	addq	$0xa8, %rsp
 11586a3: 5d                           	popq	%rbp
 11586a4: c3                           	retq
 11586a5: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
 11586aa: 48 89 5c 24 58               	movq	%rbx, 0x58(%rsp)
 11586af: 48 89 4c 24 60               	movq	%rcx, 0x60(%rsp)
 11586b4: 48 89 7c 24 68               	movq	%rdi, 0x68(%rsp)
 11586b9: 48 89 74 24 70               	movq	%rsi, 0x70(%rsp)
 11586be: 4c 89 44 24 78               	movq	%r8, 0x78(%rsp)
 11586c3: 4c 89 8c 24 80 00 00 00      	movq	%r9, 0x80(%rsp)
 11586cb: 4c 89 94 24 88 00 00 00      	movq	%r10, 0x88(%rsp)
 11586d3: 4c 89 9c 24 90 00 00 00      	movq	%r11, 0x90(%rsp)
 11586db: 0f 1f 44 00 00               	nopl	(%rax,%rax)
 11586e0: e8 db f3 f2 ff               	callq	0x1087ac0 <_runtime.morestack_noctxt.abi0>
 11586e5: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
 11586ea: 48 8b 5c 24 58               	movq	0x58(%rsp), %rbx
 11586ef: 48 8b 4c 24 60               	movq	0x60(%rsp), %rcx
 11586f4: 48 8b 7c 24 68               	movq	0x68(%rsp), %rdi
 11586f9: 48 8b 74 24 70               	movq	0x70(%rsp), %rsi
 11586fe: 4c 8b 44 24 78               	movq	0x78(%rsp), %r8
 1158703: 4c 8b 8c 24 80 00 00 00      	movq	0x80(%rsp), %r9
 115870b: 4c 8b 94 24 88 00 00 00      	movq	0x88(%rsp), %r10
 1158713: 4c 8b 9c 24 90 00 00 00      	movq	0x90(%rsp), %r11
 115871b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
 1158720: e9 1b f7 ff ff               	jmp	0x1157e40 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD>
 1158725: cc                           	int3
 1158726: cc                           	int3
 1158727: cc                           	int3
 1158728: cc                           	int3
 1158729: cc                           	int3
 115872a: cc                           	int3
 115872b: cc                           	int3
 115872c: cc                           	int3
 115872d: cc                           	int3
 115872e: cc                           	int3
 115872f: cc                           	int3
 1158730: cc                           	int3
 1158731: cc                           	int3
 1158732: cc                           	int3
 1158733: cc                           	int3
 1158734: cc                           	int3
 1158735: cc                           	int3
 1158736: cc                           	int3
 1158737: cc                           	int3
 1158738: cc                           	int3
 1158739: cc                           	int3
 115873a: cc                           	int3
 115873b: cc                           	int3
 115873c: cc                           	int3
 115873d: cc                           	int3
 115873e: cc                           	int3
 115873f: cc                           	int3

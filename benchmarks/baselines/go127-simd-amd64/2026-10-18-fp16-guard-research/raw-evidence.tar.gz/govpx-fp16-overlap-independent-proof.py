from pathlib import Path
import json
counts={}
for bits in [3,4,5]:
 m=1<<bits;spans=[(p,n,set(range(p,p+n)))for p in range(m)for n in range(1,m-p+1)];total=0
 for a,la,aa in spans:
  for b,lb,bb in spans:
   if la+lb>m:continue
   overlap=bool(aa&bb);got=((a-b+la-1)&(m-1))<la+lb-1
   assert got==overlap,(bits,a,la,b,lb,got,overlap);total+=1
 counts[bits]=total
edges=0
for bits in [32,64]:
 m=1<<bits
 for la in [1,64,128,256,512,1024,2048]:
  for lb in [1,64,128,256,512,1024,2048]:
   for a in [0,1,la,4096,m-la,m-la-1]:
    if not 0<=a<=m-la:continue
    bs={0,1,4096,m-lb,m-lb-1,a,a-la,a-la+1,a-la-1,a+lb,a+lb-1,a+lb+1,a+la,a-lb}
    for b in bs:
     if not 0<=b<=m-lb:continue
     want=max(a,b)<min(a+la,b+lb);got=((a-b+la-1)&(m-1))<la+lb-1;assert got==want,(bits,a,la,b,lb);edges+=1
out={'independent_oracle':'explicit occupied-byte setintersection for small rings; mathematical max(start)<min(end) on wide boundary cases','conditions':'positive lengths; individually nonwrapping valid numeric windows; lengthsum<=2^bits','small_ring_cases':counts,'32_and_64bit_boundary_cases':edges,'proof':'Let z=a-b+LA-1,T=LA+LB-1. Overlap iff0<=z<T. AafterB gives T<=z<M; AbeforeB gives T-M<=z<0, so moduloM lies[T,M). Samepointer givesLA-1<T; eitheradjacency givesT orM-1.','nil_scope':'Address0 included mathematically, nofakepointerdereference. Optionalnil q/classes muststillomit their spans; requirednil publicvalidation remainsbeforehelper.','length_order':'LA belongs to addressa in a-b+LA-1; classes lengthn differs fromint16 length2n.','zero_lengths':'Not valid for thisidentity; existingn64..1024 eligibility mustremainbeforeguard.'}
p=Path('/private/tmp/govpx-fp16-overlap-independent-proof.json');p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

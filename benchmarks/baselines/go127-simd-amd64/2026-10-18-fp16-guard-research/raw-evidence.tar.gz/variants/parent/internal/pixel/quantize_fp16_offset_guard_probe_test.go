//go:build goexperiment.simd && amd64 && !purego

package pixel

import (
	"bytes"
	"testing"
	"unsafe"
)

func fp16FrozenGuardProbe(coeff, iscan, qcoeff, dqcoeff []int16, classes []byte, n int) bool {
	type span struct{ p, bytes uintptr }
	spans := [5]span{
		{uintptr(unsafe.Pointer(unsafe.SliceData(coeff))), uintptr(n) * 2},
		{uintptr(unsafe.Pointer(unsafe.SliceData(iscan))), uintptr(n) * 2},
		{uintptr(unsafe.Pointer(unsafe.SliceData(dqcoeff))), uintptr(n) * 2},
	}
	count := 3
	if qcoeff != nil {
		spans[count] = span{uintptr(unsafe.Pointer(unsafe.SliceData(qcoeff))), uintptr(n) * 2}
		count++
	}
	if classes != nil {
		spans[count] = span{uintptr(unsafe.Pointer(unsafe.SliceData(classes))), uintptr(n)}
		count++
	}
	for i := 0; i < count; i++ {
		for j := 0; j < i; j++ {
			a, b := spans[i], spans[j]
			if a.p <= b.p && b.p-a.p < a.bytes || b.p < a.p && a.p-b.p < b.bytes {
				return false
			}
		}
	}
	return true
}

func TestFP16OffsetGuardAllPairs(t *testing.T) {
	for n := 64; n <= 1024; n += 16 {
		base := 4*n + 128
		defaults := [5]int{base, base + 4*n, base + 8*n, base + 12*n, base + 16*n}
		sizes := [5]int{2 * n, 2 * n, 2 * n, 2 * n, n}
		back := make([]byte, base+24*n+4096)
		for a := 0; a < 5; a++ {
			for b := a + 1; b < 5; b++ {
				for _, delta := range []int{0, 1, -1, 2, -2, sizes[a] - 1, -sizes[b] + 1, sizes[a], -sizes[b], sizes[a] + 1, -sizes[b] - 1} {
					off := defaults
					off[b] = off[a] + delta
					c, i, q, d, cl := fp16Views(back, off, n)
					for options := 0; options < 4; options++ {
						qq, cc := q, cl
						if options&1 != 0 {
							qq = nil
						}
						if options&2 != 0 {
							cc = nil
						}
						got, want := fp16WindowsDisjoint(c, i, qq, d, cc, n), fp16FrozenGuardProbe(c, i, qq, d, cc, n)
						if got != want {
							t.Fatalf("n%d pair%d/%d delta%d optional%d guard%v/%v", n, a, b, delta, options, got, want)
						}
					}
				}
			}
		}
	}
}
func TestFP16OffsetGuardNilAndEmpty(t *testing.T) {
	const n = 64
	c, i, q, d, cl := make([]int16, n), make([]int16, n), make([]int16, n), make([]int16, n), make([]byte, n)
	for mask := 0; mask < 32; mask++ {
		a, b, qo, dqo, l := c, i, q, d, cl
		if mask&1 != 0 {
			a = nil
		}
		if mask&2 != 0 {
			b = nil
		}
		if mask&4 != 0 {
			qo = nil
		}
		if mask&8 != 0 {
			dqo = nil
		}
		if mask&16 != 0 {
			l = nil
		}
		if fp16WindowsDisjoint(a, b, qo, dqo, l, n) != fp16FrozenGuardProbe(a, b, qo, dqo, l, n) {
			t.Fatalf("nil mask%d", mask)
		}
	}
	for empty := 0; empty < 5; empty++ {
		a, b, qo, dqo, l := c, i, q, d, cl
		switch empty {
		case 0:
			a = a[:0]
		case 1:
			b = b[:0]
		case 2:
			qo = qo[:0]
		case 3:
			dqo = dqo[:0]
		case 4:
			l = l[:0]
		}
		if fp16WindowsDisjoint(a, b, qo, dqo, l, n) != fp16FrozenGuardProbe(a, b, qo, dqo, l, n) {
			t.Fatalf("empty%d", empty)
		}
	}
}
func TestFP16OffsetPublicAllPairs(t *testing.T) {
	for _, n := range []int{64, 256, 1024} {
		base := 4*n + 128
		defaults := [5]int{base, base + 4*n, base + 8*n, base + 12*n, base + 16*n}
		sizes := [5]int{2 * n, 2 * n, 2 * n, 2 * n, n}
		for a := 0; a < 5; a++ {
			for b := a + 1; b < 5; b++ {
				for _, delta := range []int{0, 1, -1, 2, -2, sizes[a] - 1, -sizes[b] + 1, sizes[a], -sizes[b], sizes[a] + 1, -sizes[b] - 1} {
					for options := 0; options < 4; options++ {
						got := make([]byte, base+24*n+4096)
						for i := range got {
							got[i] = byte(i*37 + i/7 + 11)
						}
						want := bytes.Clone(got)
						off := defaults
						off[b] = off[a] + delta
						c, i, q, d, cl := fp16Views(got, off, n)
						wc, wi, wq, wd, wcl := fp16Views(want, off, n)
						if options&1 != 0 {
							q = nil
							wq = nil
						}
						if options&2 != 0 {
							cl = nil
							wcl = nil
						}
						r, qt, deq := [2]int16{9, 29}, [2]int16{12345, 30000}, [2]int16{23, 41}
						ge, gp := fp16Capture(func() int { return QuantizeFPBlock(c, i, q, d, n, r, qt, deq, cl) })
						we, wp := fp16Capture(func() int { return fp16OriginalPublic(wc, wi, wq, wd, n, r, qt, deq, wcl) })
						if ge != we || gp != wp || !bytes.Equal(got, want) {
							t.Fatalf("n%d pair%d/%d delta%d opts%d EOB%d/%d panic%q/%q", n, a, b, delta, options, ge, we, gp, wp)
						}
					}
				}
			}
		}
	}
}
func TestFP16OffsetPublicNilAndLengths(t *testing.T) {
	for _, n := range []int{-1, 0, 1, 63, 64, 80, 1024, 1025} {
		size := max(n, 1)
		for window := 0; window < 5; window++ {
			for mode := 0; mode < 4; mode++ {
				makeViews := func() ([]byte, []int16, []int16, []int16, []int16, []byte) {
					back := make([]byte, 14*size+4096)
					for i := range back {
						back[i] = byte(i*37 + i/7 + 11)
					}
					off := [5]int{128, 128 + 2*size, 128 + 4*size, 128 + 6*size, 128 + 8*size}
					c, i, q, d, cl := fp16Views(back, off, size)
					shrink := func(v []int16) []int16 {
						switch mode {
						case 0:
							return nil
						case 1:
							return v[:0]
						case 2:
							return v[:size-1]
						default:
							return v[: size-1 : size-1]
						}
					}
					switch window {
					case 0:
						c = shrink(c)
					case 1:
						i = shrink(i)
					case 2:
						q = shrink(q)
					case 3:
						d = shrink(d)
					case 4:
						switch mode {
						case 0:
							cl = nil
						case 1:
							cl = cl[:0]
						case 2:
							cl = cl[:size-1]
						default:
							cl = cl[: size-1 : size-1]
						}
					}
					return back, c, i, q, d, cl
				}
				got, c, i, q, d, cl := makeViews()
				want, wc, wi, wq, wd, wcl := makeViews()
				r, qt, deq := [2]int16{9, 29}, [2]int16{12345, 30000}, [2]int16{23, 41}
				ge, gp := fp16Capture(func() int { return QuantizeFPBlock(c, i, q, d, n, r, qt, deq, cl) })
				we, wp := fp16Capture(func() int { return fp16OriginalPublic(wc, wi, wq, wd, n, r, qt, deq, wcl) })
				if ge != we || gp != wp || !bytes.Equal(got, want) {
					t.Fatalf("n%d window%d mode%d EOB%d/%d panic%q/%q", n, window, mode, ge, we, gp, wp)
				}
			}
		}
	}
}

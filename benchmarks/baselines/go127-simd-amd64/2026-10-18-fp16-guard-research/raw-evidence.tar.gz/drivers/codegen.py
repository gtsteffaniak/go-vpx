import pathlib,subprocess,re,json
base=pathlib.Path('/private/tmp/govpx-fp16-offset-guard/evidence');out=base/'codegen';out.mkdir(exist_ok=True)
summary={}
for v in ['parent','single-compare','unrolled']:
 summary[v]={}
 for platform,suffix,sym in [('darwin','ordinary','_'),('linux','linux','')]:
  binary=base/'validation'/f'{v}-pixel-{suffix}.test'
  args=['xcrun','llvm-objdump','-d','--disassemble-symbols='+sym+'github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint',str(binary)]
  text=subprocess.check_output(args,text=True);(out/f'{v}-{platform}-guard.asm').write_text(text)
  inst=[m.group(1) for l in text.splitlines() if (m:=re.match(r'^\s*[0-9a-f]+:\s+(?:[0-9a-f]{2}\s+)+(.+)$',l))]
  summary[v][platform]={'instructions_including_padding':len(inst),'instructions_excluding_int3_padding':len([i for i in inst if i!='int3']),'call_instructions':[i for i in inst if re.match(r'call',i)],'conditional_jumps':len([i for i in inst if re.match(r'j(?!mp)',i)]),'frame_adjustments':[i for i in inst if re.match(r'(sub|add)q\s+\$.*%rsp',i)]}
(out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))

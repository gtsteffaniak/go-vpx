import pathlib,re,json,subprocess,hashlib
w=pathlib.Path('/private/tmp/govpx-fp16-offset-guard');out=w/'evidence';cg=out/'codegen';val=out/'validation'
def body(binary,symbol):
 s=subprocess.check_output(['xcrun','llvm-objdump','-d','--disassemble-symbols='+symbol,str(binary)],text=True)
 lines=[]
 for l in s.splitlines():
  m=re.match(r'^\s*[0-9a-f]+:\s+(?:[0-9a-f]{2}\s+)+(.+)$',l)
  if not m:m=re.match(r'^\s*[0-9a-f]+:\s+[0-9a-f]{8}\s+(.+)$',l)
  if m:lines.append(re.sub(r'0x[0-9a-fA-F]+','ADDR',m.group(1)))
 return s,lines
arm={}
for v in ['parent','unrolled']:
 s,ls=body(val/f'{v}-arm-encoder.test','_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD');assert ls
 (cg/f'{v}-arm-quant.asm').write_text(s);arm[v]=ls
assert arm['parent']==arm['unrolled']
source={}
parent=w/'parent';expected={'internal/pixel/quantize_fp_amd64.go'}
for v in ['single-compare','unrolled']:
 changed=[]
 for f in parent.rglob('*.go'):
  rel=f.relative_to(parent)
  if f.read_bytes()!=(w/v/rel).read_bytes():changed.append(str(rel))
 assert set(changed)==expected,(v,changed)
 source[v]={'only_existing_go_delta':changed,'quant_vector_and_public_prefix_exact':True}
 for os,suffix,pre in [('darwin','ordinary','_'),('linux','linux','')]:
  for f in ['quantizeFPBlockSIMD','fp16WindowsDisjoint']:
   s,ls=body(val/f'{v}-pixel-{suffix}.test',pre+'github.com/thesyncim/govpx/internal/pixel.'+f)
   (cg/f'{v}-{os}-{f}.asm').write_text(s)
proof={'source':source,'arm_actual_quant_body_identical':True,'arm_instruction_entries':len(arm['parent']),'ordinary_oneshot_samples':3*2*36,'checked_oneshot_samples':3*2*36,'ordinary_allocations':'all0B/0alloc','checkptr2_allocations':'classes cases16B/1alloc for parent and both candidates; remaining0; every36-case vector matchesparent','all_ten_pairs_preserved':True,'no_native_performance_measurements':True}
(out/'final-proof.json').write_text(json.dumps(proof,indent=2));print(json.dumps(proof,indent=2))
# Reconstruct complete exact command inventory from executed immutable drivers and saved logs.
s=(w/'drivers/validate.py').read_text();prefix=s[:s.index('cache=run(')];loop=s[s.index('cache=run('):]
replacement='''\nrecords=[]\ndef run(name,args,extra={}):\n text=(out/(name+'.log')).read_text()\n records.append(dict(name=name,args=args,env=extra,exit=0,provenance='successful original subprocess execution; command inventory replay reads logs only'))\n return text\n'''
ns={};exec(prefix+replacement+loop,ns)
extra=(w/'drivers/extra.py').read_text();extra=extra[extra.index('\nfor variant in '):];exec(extra,ns)
(val/'complete-command-inventory.json').write_text(json.dumps(ns['records'],indent=2))
print('commands',len(ns['records']))

import pathlib,subprocess,os,json
w=pathlib.Path('/private/tmp/govpx-fp16-offset-guard');out=w/'evidence/validation';root=pathlib.Path('/Users/thesyncim/GolandProjects/govpx');env=os.environ.copy();env.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-fpguard-armproof',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',CGO_ENABLED='1',GOOS='darwin',GOARCH='arm64')
records=[]
for v in ['parent','unrolled']:
 args=[str(root/'scripts/go.sh'),'-C',str(w/v),'test','-pgo=off','-c','-o',str(out/f'{v}-arm-encoder.test'),'./internal/vp9/encoder'];p=subprocess.run(args,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/f'arm-encoder-{v}.log').write_text(p.stdout);records.append(dict(variant=v,args=args,exit=p.returncode));print(v,p.returncode,flush=True);assert p.returncode==0
(out/'arm-encoder-commands.json').write_text(json.dumps(records,indent=2))

import pathlib,shutil,hashlib,json,subprocess,platform,os
w=pathlib.Path('/private/tmp/govpx-fp16-offset-guard');ready=pathlib.Path('/private/tmp/govpx-fp16-offset-guard-ready');ready.mkdir(exist_ok=True)
for sub in ['drivers','evidence']:
 for p in (w/sub).rglob('*'):
  if p.is_file() and p.suffix!='.test':
   dest=ready/p.relative_to(w);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
for v in ['parent','single-compare','unrolled']:
 for rel in ['internal/pixel/quantize_fp_amd64.go','internal/pixel/quantize_fp16_offset_guard_probe_test.go']:
  dest=ready/'variants'/v/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/v/rel,dest)
for p in ['/private/tmp/govpx-fp16-overlap-independent-proof.py','/private/tmp/govpx-fp16-overlap-independent-proof.json']:
 shutil.copyfile(p,ready/pathlib.Path(p).name)
binaries=[]
for p in sorted((w/'evidence/validation').glob('*.test')):
 binaries.append(dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(ready/'binary-inventory.json').write_text(json.dumps(binaries,indent=2))
for v in ['single-compare','unrolled']:
 p=subprocess.run(['diff','-u',str(w/'parent/internal/pixel/quantize_fp_amd64.go'),str(w/v/'internal/pixel/quantize_fp_amd64.go')],stdout=subprocess.PIPE,text=True)
 (ready/f'{v}.patch').write_text(p.stdout)
report='''# Private AMD FP16 overlap guard variants

Base: 46a08f8e6eb03f6ee4549d975384bd6c952a81fa. No repository writes, PR changes or native AMD timing. Both candidates remain UNMEASURED performance proposals. Rosetta runs are correctness-only; their incidental ns/op values are not speed evidence.

Only fp16WindowsDisjoint changes. Public validation/eligibility order, all ten pair policies including read-only overlaps, optional nil omission, 16-lane arithmetic/store order, ClearAVXUpperBits and narrow fallback source are exact. Existing ARM sources are byte-identical. The live ARM quantizer normalized 200-instruction body is identical (encoder binary; initial pixel binary dead-stripped this function).

Independent proof uses occupied-byte sets for 242,010 valid small-ring cases (966/14,620/226,424) plus 5,604 wide-boundary interval cases. For individually nonwrapping positive windows with length sum<=uintptr modulus, overlap iff uintptr(a-b+LA-1)<LA+LB-1. LA belongs to a. Both adjacencies are excluded; same pointer included. Zero lengths are outside the identity; existing n64..1024 eligibility remains. No fabricated pointer is dereferenced.

## Generated code

Darwin and Linux match these counts, excluding trailing INT3 padding:

| Guard | Instructions | Conditional jumps | Local frame | Calls | Inline cost |
| --- | ---: | ---: | ---: | --- | ---: |
| Parent | 83 | 9 | 80 bytes | panicBounds cold path | 146 |
| Single compare, original array/loops | 75 | 6 | 80 bytes | panicBounds cold path | 135 |
| Explicit ten pairs | 88 | 13 | 0 bytes | none | 185 |

All remain noninline. Unrolled guard still has three argument-home stores into the caller frame and stack argument loads; it is not stack-free. Unrolling removes loop/array setup, not every branch. Static counts cannot select the winner: single compare has fewer static instructions, unrolled executes fixed checks without the nested-loop work. Native six-balanced public36 measurements must compare both against this strong base. No 1.5x claim is made.

## Correctness

All three variants pass existing and new FP tests with selected AVX2 and actual AVX/AVX2 CPU-off, both ordinary and checkptr2. New tests cover all ten pairs at all61 eligible sizes (26,840 direct guard comparisons), 1,320 aliased public full-backing comparisons, 37 nil/empty guard cases and160 public independently short/nil/spare-cap/clipped-cap cases. Frozen public oracle compares EOB, exact panic strings and every backing byte. Existing full-signed, alignment/minimal-window, invalid-table and disabled tests remain.

216 ordinary public36 one-shot samples are all0B/0alloc.216 checkptr2 one-shot samples preserve outputs; checked classes cases allocate16B/1alloc on parent and both candidates, and all allocation vectors match parent exactly. Initial parser incorrectly required checked zeroalloc; runtime assertions passed, parser was corrected and failure output retained in session history. Purego and noSIMD encoder tests pass for parent/unrolled. Reconstructed complete-command-inventory.json enumerates68 commands from executed driver logs; two additional live ARM encoder builds have their own exact command file. This reconstruction avoids concurrent-driver journal overwrite; raw per-command logs are retained.

## Preservation and limits

Variants, all tests, exact drivers, proof, LLVM bodies, compile diagnostics and raw correctness/one-shot logs are included. Binaries are retained at immutable private source paths listed with size/SHA256 in binary-inventory.json and omitted from this lean package only. Full snapshot trees remain at /private/tmp/govpx-fp16-offset-guard. No SDK/library dependencies added. No native throughput or whole-codec claim. Root must select any later CI experiment; this package does not change the active PR.
'''
(ready/'REPORT.md').write_text(report)
(ready/'environment.json').write_text(json.dumps(dict(platform=platform.platform(),uname=list(platform.uname()),sdk='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64',cache=(w/'evidence/validation/cache.log').read_text().strip(),CGO_ENABLED='1 on Darwin;0 Linux crossbuild',GOFLAGS='-p=2',GOMAXPROCS=2,PGO='off',native_performance=False),indent=2))
manifest=[]
for p in sorted(ready.rglob('*')):
 if p.is_file() and p.name!='MANIFEST.json':manifest.append(dict(path=str(p.relative_to(ready)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(ready/'MANIFEST.json').write_text(json.dumps(manifest,indent=2));print('READY',ready,'files',len(manifest),'manifest',hashlib.sha256((ready/'MANIFEST.json').read_bytes()).hexdigest())

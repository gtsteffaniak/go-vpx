exec(open('/private/tmp/govpx-fp16-offset-guard/drivers/validate.py').read().split("for variant in ['parent'")[0])
for variant in ['parent','single-compare','unrolled']:
 run('inline-'+variant,[str(root/'scripts/go.sh'),'-C',str(work/variant),'test','-pgo=off','-c','-o',str(out/f'{variant}-inline.test'),'-gcflags=github.com/thesyncim/govpx/internal/pixel=-m=2','./internal/pixel'],dict(GOOS='darwin',GOARCH='amd64',GOAMD64='v1'))
for variant in ['parent','unrolled']:
 run('arm-'+variant,[str(root/'scripts/go.sh'),'-C',str(work/variant),'test','-pgo=off','-c','-o',str(out/f'{variant}-arm.test'),'./internal/pixel'],dict(GOOS='darwin',GOARCH='arm64'))
 for mode,extra in [('purego',dict(GOOS='darwin',GOARCH='amd64',GOAMD64='v1')),('nosimd',dict(GOOS='darwin',GOARCH='amd64',GOAMD64='v1',GOEXPERIMENT=''))]:
  binary=out/f'{variant}-{mode}.test';args=[str(root/'scripts/go.sh'),'-C',str(work/variant),'test','-pgo=off','-c','-o',str(binary)]
  if mode=='purego':args+=['-tags=purego']
  args+=['./internal/vp9/encoder'];run('build-'+variant+'-'+mode,args,extra)
  run('run-'+variant+'-'+mode,['arch','-x86_64',str(binary),'-test.run=^TestQuantizeFP','-test.count=1','-test.v'],dict(ROSETTA_ADVERTISE_AVX='1'))
print('EXTRA PASS')

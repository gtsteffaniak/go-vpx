import os, subprocess, json, time, pathlib, re
root=pathlib.Path('/Users/thesyncim/GolandProjects/govpx')
work=pathlib.Path('/private/tmp/govpx-fp16-offset-guard')
out=work/'evidence'/'validation';out.mkdir(exist_ok=True)
env=os.environ.copy();env.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-fpguard',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',CGO_ENABLED='1')
results=json.loads((out/'commands.json').read_text())
previous={r['name']:r for r in results}
def run(name,args,extra={}):
 
 if name in previous and previous[name]['exit']==0:
  print('saved',name,flush=True);return (out/(name+'.log')).read_text()
 e=env.copy();e.update(extra);t=time.time();p=subprocess.run(args,cwd=root,env=e,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/(name+'.log')).write_text(p.stdout);results.append(dict(name=name,args=args,env=extra,exit=p.returncode,seconds=time.time()-t));(out/'commands.json').write_text(json.dumps(results,indent=2));print(name,p.returncode,flush=True)
 if p.returncode:print(p.stdout[-6000:],flush=True);raise SystemExit(p.returncode)
 return p.stdout
cache=run('cache',[str(root/'scripts/go.sh'),'env','GOCACHE']);assert '.codex/worktrees' not in cache
for variant in ['parent','single-compare','unrolled']:
 for checked in [False,True]:
  mode='checkptr2' if checked else 'ordinary'
  for pkg,selector in [('pixel','^TestFP16'),('encoder','^TestQuantizeFP')]:
   path='internal/pixel' if pkg=='pixel' else 'internal/vp9/encoder'
   binary=out/f'{variant}-{pkg}-{mode}.test'
   args=[str(root/'scripts/go.sh'),'-C',str(work/variant),'test','-pgo=off','-c','-o',str(binary)]
   if checked:args+=['-gcflags=all=-d=checkptr=2']
   args+=['./'+path]
   run(f'build-{variant}-{pkg}-{mode}',args,dict(GOOS='darwin',GOARCH='amd64',GOAMD64='v1'))
   for off in [False,True]:
    cpu='avxoff' if off else 'selected'
    runtime=dict(ROSETTA_ADVERTISE_AVX='1',GOVPX_REQUIRE_SIMD='0' if off else '1',GOVPX_REQUIRE_FP16_AVX_OFF='1' if off else '0',GODEBUG='cpu.avx=off,cpu.avx2=off' if off else '')
    run(f'run-{variant}-{pkg}-{mode}-{cpu}',['arch','-x86_64',str(binary),'-test.run='+selector,'-test.v','-test.count=1'],runtime)
    if pkg=='encoder':
     text=run(f'oracle36-{variant}-{mode}-{cpu}',['arch','-x86_64',str(binary),'-test.run=^$','-test.bench=^BenchmarkVP9FP16Native$','-test.benchtime=1x','-test.cpu=1','-test.benchmem'],runtime)
     lines=[s for s in text.splitlines() if s.startswith('BenchmarkVP9FP16Native/')];assert len(lines)==36,(variant,len(lines));
     if not checked: assert all(re.search(r'\b0 B/op\s+0 allocs/op',s) for s in lines),lines
     allocs=[list(map(int,re.search(r'(\d+) B/op\s+(\d+) allocs/op',s).groups())) for s in lines]
     (out/f'allocs-{variant}-{mode}-{cpu}.json').write_text(json.dumps(allocs))
     if variant!='parent': assert allocs==json.loads((out/f'allocs-parent-{mode}-{cpu}.json').read_text())
 for pkg in ['pixel','encoder']:
  path='internal/pixel' if pkg=='pixel' else 'internal/vp9/encoder'
  run(f'build-linux-{variant}-{pkg}',[str(root/'scripts/go.sh'),'-C',str(work/variant),'test','-pgo=off','-c','-o',str(out/f'{variant}-{pkg}-linux.test'),'./'+path],dict(GOOS='linux',GOARCH='amd64',GOAMD64='v1',CGO_ENABLED='0'))
print('ALL PASS',flush=True)

import pathlib,subprocess,json,hashlib,shutil
w=pathlib.Path('/private/tmp/govpx-fp16-offset-guard');dst=w/'unrolled'
dst.mkdir(exist_ok=True)
p1=subprocess.Popen(['git','archive','46a08f8e6eb03f6ee4549d975384bd6c952a81fa'],stdout=subprocess.PIPE)
subprocess.run(['tar','-x','-C',str(dst)],stdin=p1.stdout,check=True);p1.stdout.close();assert p1.wait()==0
f=dst/'internal/pixel/quantize_fp_amd64.go';text=f.read_text();prefix=text[:text.index('func fp16WindowsDisjoint')]
body='''func fp16WindowsDisjoint(coeff, iscan, qcoeff, dqcoeff []int16, classes []byte, n int) bool {
 c := uintptr(unsafe.Pointer(unsafe.SliceData(coeff)))
 i := uintptr(unsafe.Pointer(unsafe.SliceData(iscan)))
 d := uintptr(unsafe.Pointer(unsafe.SliceData(dqcoeff)))
 bytes := uintptr(n)*2
 sameLimit := bytes+bytes-1
 if i-c+bytes-1 < sameLimit || d-c+bytes-1 < sameLimit || d-i+bytes-1 < sameLimit {
  return false
 }
 if qcoeff != nil {
  q := uintptr(unsafe.Pointer(unsafe.SliceData(qcoeff)))
  if q-c+bytes-1 < sameLimit || q-i+bytes-1 < sameLimit || q-d+bytes-1 < sameLimit {
   return false
  }
 }
 if classes != nil {
  cl := uintptr(unsafe.Pointer(unsafe.SliceData(classes)))
  classBytes := uintptr(n)
  classLimit := classBytes+bytes-1
  if cl-c+classBytes-1 < classLimit || cl-i+classBytes-1 < classLimit || cl-d+classBytes-1 < classLimit {
   return false
  }
  if qcoeff != nil && cl-uintptr(unsafe.Pointer(unsafe.SliceData(qcoeff)))+classBytes-1 < classLimit {
   return false
  }
 }
 return true
}
'''
f.write_text(prefix+body)
subprocess.run(['/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/gofmt','-w',str(f)],check=True)
assert f.read_text().startswith(prefix)
shutil.copyfile(w/'parent/internal/pixel/quantize_fp16_offset_guard_probe_test.go',dst/'internal/pixel/quantize_fp16_offset_guard_probe_test.go')
ledger={}
for v in ['parent','single-compare','unrolled']:
 p=w/v/'internal/pixel/quantize_fp_amd64.go';ledger[v]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'prefix_same':p.read_text()[:p.read_text().index('func fp16WindowsDisjoint')]==prefix}
(w/'evidence/variant-ledger.json').write_text(json.dumps(ledger,indent=2))

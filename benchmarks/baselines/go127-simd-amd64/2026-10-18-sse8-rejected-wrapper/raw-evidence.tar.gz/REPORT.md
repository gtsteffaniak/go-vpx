# PR42: rejected native AVX2 SSE8 candidate

Exact head `c638b7c76eac857affa0780820e86c211cdd84d3`; measured parent `ab3abd6b335242d5732fa1956a63b7591eaf781b`, tree-equivalent to merged main `cf3117194f0590fa0af35951a32e8fadb6da9ab3`. All three checks pass correctness, but **the candidate fails native performance acceptance**. HOLD MERGE pending root review. No source or PR metadata has been changed by this audit.

Native AMD EPYC 7763 64-Core Processor; go version go1.27.2 linux/amd64; PGO off, GOMAXPROCS=1. AVX2 is enabled; pointer and wide helpers execute in ordinary and race/checkptr tests. Inherited AVX512 is unavailable and its two dedicated tests correctly skip. No AVX512 timing claim is made. Separate C job also reports EPYC7763; measurements across jobs are not causally combined.

## All 36 live public SSE8 fixtures

Every current median is slower than the strongest available parent baseline. Thirty-five of 36 cases are slower in all six pairs. No case reaches 1.5× parent in any acceptance sense. The minimum paired parent/current speedup is 0.643478×. Fixtures use the same independent scalar oracle, immutable inputs and observable sink before/after testing.B.Loop in all three variants.

| Fixture | Time vs parent | Pairs slower | Parent/current | Old ASM/current |
|---|---:|---:|---:|---:|
| pointer8x8/pitch1312-1320/pattern0 | +6.925540% | 6/6 | 0.935230× | 0.749270× |
| pointer8x8/pitch1312-1320/pattern1 | +6.802721% | 6/6 | 0.936306× | 0.748558× |
| pointer8x8/pitch1312-1320/pattern2 | +6.882753% | 6/6 | 0.935605× | 0.748783× |
| pointer8x8/pitch32-37/pattern0 | +6.880000% | 6/6 | 0.935629× | 0.748353× |
| pointer8x8/pitch32-37/pattern1 | +6.968362% | 6/6 | 0.934856× | 0.748446× |
| pointer8x8/pitch32-37/pattern2 | +7.091346% | 6/6 | 0.933782× | 0.747587× |
| pointer8x8/pitch8-8/pattern0 | +6.530449% | 6/6 | 0.938699× | 0.752200× |
| pointer8x8/pitch8-8/pattern1 | +6.485188% | 6/6 | 0.939098× | 0.751842× |
| pointer8x8/pitch8-8/pattern2 | +6.402561% | 6/6 | 0.939827× | 0.750846× |
| slice8x16/pitch1312-1320/pattern0 | +41.382114% | 6/6 | 0.707303× | 38.412881× |
| slice8x16/pitch1312-1320/pattern1 | +41.316716% | 6/6 | 0.707630× | 38.439417× |
| slice8x16/pitch1312-1320/pattern2 | +41.366224% | 6/6 | 0.707383× | 34.314477× |
| slice8x16/pitch32-37/pattern0 | +42.345277% | 6/6 | 0.702517× | 38.176964× |
| slice8x16/pitch32-37/pattern1 | +42.229455% | 6/6 | 0.703089× | 38.176964× |
| slice8x16/pitch32-37/pattern2 | +42.021132% | 6/6 | 0.704121× | 34.093857× |
| slice8x16/pitch8-8/pattern0 | +42.272234% | 6/6 | 0.702878× | 38.193253× |
| slice8x16/pitch8-8/pattern1 | +42.299349% | 6/6 | 0.702744× | 38.185976× |
| slice8x16/pitch8-8/pattern2 | +42.562432% | 6/6 | 0.701447× | 34.087966× |
| slice8x4/pitch1312-1320/pattern0 | +7.059563% | 5/6 | 0.934059× | 1.267553× |
| slice8x4/pitch1312-1320/pattern1 | +7.133059% | 6/6 | 0.933419× | 1.266539× |
| slice8x4/pitch1312-1320/pattern2 | +7.092644% | 6/6 | 0.933771× | 1.266944× |
| slice8x4/pitch32-37/pattern0 | +7.170631% | 6/6 | 0.933091× | 1.266140× |
| slice8x4/pitch32-37/pattern1 | +7.211896% | 6/6 | 0.932732× | 1.265337× |
| slice8x4/pitch32-37/pattern2 | +7.193093% | 6/6 | 0.932896× | 1.265803× |
| slice8x4/pitch8-8/pattern0 | +7.243392% | 6/6 | 0.932458× | 1.267606× |
| slice8x4/pitch8-8/pattern1 | +7.179604% | 6/6 | 0.933013× | 1.265600× |
| slice8x4/pitch8-8/pattern2 | +7.183711% | 6/6 | 0.932978× | 1.266275× |
| slice8x8/pitch1312-1320/pattern0 | +36.988612% | 6/6 | 0.729988× | 0.865148× |
| slice8x8/pitch1312-1320/pattern1 | +37.030789% | 6/6 | 0.729763× | 0.865189× |
| slice8x8/pitch1312-1320/pattern2 | +36.888702% | 6/6 | 0.730520× | 0.866338× |
| slice8x8/pitch32-37/pattern0 | +36.999579% | 6/6 | 0.729929× | 0.864657× |
| slice8x8/pitch32-37/pattern1 | +36.846543% | 6/6 | 0.730746× | 0.866913× |
| slice8x8/pitch32-37/pattern2 | +36.957438% | 6/6 | 0.730154× | 0.865231× |
| slice8x8/pitch8-8/pattern0 | +38.364250% | 6/6 | 0.722730× | 0.855576× |
| slice8x8/pitch8-8/pattern1 | +38.438819% | 6/6 | 0.722341× | 0.856446× |
| slice8x8/pitch8-8/pattern2 | +38.312236% | 6/6 | 0.723002× | 0.857230× |

Old-reference SSE8 fixtures use actual hand-written kernels: SSE2 variance8xN for4/8-row slices and pointer8x8, AVX2 variance8x16 for16-row slices. Strong parent performance remains the acceptance comparison. Old-build8x16 timing anomalies and mixed old-build ratios do not rescue the parent regressions and do not establish their cause.

## Legacy B.N fixture

BenchmarkSSE8x8 retains its original B.N protocol: old 11.860000ns, parent 9.996000ns, current 15.015000ns; current is +50.210084% slower than parent in all six pairs and +26.602024% slower than old assembly. It is separate from the 36 live B.Loop fixtures.

## Whole-codec results

| Case | Time vs parent | Pairs faster | Time vs old build |
|---|---:|---:|---:|
| VP9 320x180 | +0.952967% | 2/6 | -40.376444% |
| VP8 720p | -1.245368% | 4/6 | -21.613035% |
| VP9 720p | +2.415705% | 1/6 | -49.133922% |

VP8 may execute the changed code, but its mixed whole result does not override the consistent component regressions. VP9 is unchanged control work. These timings do not establish a universal assembly win or any ARM improvement.

## Correctness and allocations

All 338 cases × six samples × three variants have zero bytes/allocations. All 32 source hashes match exact-head Git blobs. Native logs contain 131 top-level PASS executions plus six retained panic probes (137 passing targeted checks), 282 PASS lines including subtests. All three new exact-window, fallback-panic and wide-dispatch tests pass both ordinary and race/checkptr. AVX2 dispatch logs are true/true/true; pointer logs true/true. There are no failures or unexpected skips.

All 22 semantic fields agree in three public and two profile datasets; every allocation sample matches. Rates remain VP8 0, VP9 320 .616667, VP9 720 1.25, VP9 profile .625. No allocation outlier or timing sample was removed.

All 188 median regressions and 62 all-six-slower cases are retained in audit.json, including all 37 changed SSE median regressions (36 are slower in all six pairs) and every unchanged control. All-six-slower details:

| Case | Time vs parent |
|---|---:|
| DCOnlyPairInPlace | +1.658090% |
| GatherPackedPredictionNative/w8/pitch1312/extremefalse | +2.641836% |
| GatherPackedPredictionNative/w8/pitch1312/extremetrue | +2.640693% |
| GatherPackedPredictionNative/w8/pitch32/extremefalse | +2.772964% |
| GatherPackedPredictionNative/w8/pitch32/extremetrue | +2.640693% |
| GatherPointerNative/w8/pitch1312/extremefalse | +2.506482% |
| GatherPointerNative/w8/pitch1312/extremetrue | +2.596279% |
| GatherPointerNative/w8/pitch32/extremefalse | +2.509736% |
| GatherPointerNative/w8/pitch32/extremetrue | +2.639550% |
| LoopFilterVerticalEdgesY | +0.685760% |
| ResidualGatherNative/8x8 | +3.023362% |
| SADLimitNative/pitch32/extremetrue/near | +0.123102% |
| SADLimitSliceNative/pitch1312/extremetrue/wide | +0.273865% |
| SSE8RowsNative/pointer8x8/pitch1312-1320/pattern0 | +6.925540% |
| SSE8RowsNative/pointer8x8/pitch1312-1320/pattern1 | +6.802721% |
| SSE8RowsNative/pointer8x8/pitch1312-1320/pattern2 | +6.882753% |
| SSE8RowsNative/pointer8x8/pitch32-37/pattern0 | +6.880000% |
| SSE8RowsNative/pointer8x8/pitch32-37/pattern1 | +6.968362% |
| SSE8RowsNative/pointer8x8/pitch32-37/pattern2 | +7.091346% |
| SSE8RowsNative/pointer8x8/pitch8-8/pattern0 | +6.530449% |
| SSE8RowsNative/pointer8x8/pitch8-8/pattern1 | +6.485188% |
| SSE8RowsNative/pointer8x8/pitch8-8/pattern2 | +6.402561% |
| SSE8RowsNative/slice8x16/pitch1312-1320/pattern0 | +41.382114% |
| SSE8RowsNative/slice8x16/pitch1312-1320/pattern1 | +41.316716% |
| SSE8RowsNative/slice8x16/pitch1312-1320/pattern2 | +41.366224% |
| SSE8RowsNative/slice8x16/pitch32-37/pattern0 | +42.345277% |
| SSE8RowsNative/slice8x16/pitch32-37/pattern1 | +42.229455% |
| SSE8RowsNative/slice8x16/pitch32-37/pattern2 | +42.021132% |
| SSE8RowsNative/slice8x16/pitch8-8/pattern0 | +42.272234% |
| SSE8RowsNative/slice8x16/pitch8-8/pattern1 | +42.299349% |
| SSE8RowsNative/slice8x16/pitch8-8/pattern2 | +42.562432% |
| SSE8RowsNative/slice8x4/pitch1312-1320/pattern1 | +7.133059% |
| SSE8RowsNative/slice8x4/pitch1312-1320/pattern2 | +7.092644% |
| SSE8RowsNative/slice8x4/pitch32-37/pattern0 | +7.170631% |
| SSE8RowsNative/slice8x4/pitch32-37/pattern1 | +7.211896% |
| SSE8RowsNative/slice8x4/pitch32-37/pattern2 | +7.193093% |
| SSE8RowsNative/slice8x4/pitch8-8/pattern0 | +7.243392% |
| SSE8RowsNative/slice8x4/pitch8-8/pattern1 | +7.179604% |
| SSE8RowsNative/slice8x4/pitch8-8/pattern2 | +7.183711% |
| SSE8RowsNative/slice8x8/pitch1312-1320/pattern0 | +36.988612% |
| SSE8RowsNative/slice8x8/pitch1312-1320/pattern1 | +37.030789% |
| SSE8RowsNative/slice8x8/pitch1312-1320/pattern2 | +36.888702% |
| SSE8RowsNative/slice8x8/pitch32-37/pattern0 | +36.999579% |
| SSE8RowsNative/slice8x8/pitch32-37/pattern1 | +36.846543% |
| SSE8RowsNative/slice8x8/pitch32-37/pattern2 | +36.957438% |
| SSE8RowsNative/slice8x8/pitch8-8/pattern0 | +38.364250% |
| SSE8RowsNative/slice8x8/pitch8-8/pattern1 | +38.438819% |
| SSE8RowsNative/slice8x8/pitch8-8/pattern2 | +38.312236% |
| SSE8x8 | +50.210084% |
| SixTapPhases/16x16/0,4 | +0.378918% |
| SixTapPhases/4x4/2,4 | +1.176948% |
| SixTapPhases/4x4/3,5 | +4.101650% |
| SixTapPhases/8x8/0,4 | +0.497001% |
| SplitSubpelPhases/16x8 | +1.597147% |
| SplitSubpelPhases/8x4 | +2.458846% |
| SplitSubpelPhases/8x8 | +0.879223% |
| UVRoundedZeroNative/pitch32/verticaltrue/kind6/flat | +0.224791% |
| UVRoundedZeroNative/pitch672/verticalfalse/kind4/flat | +0.192308% |
| UVRoundedZeroNative/pitch672/verticalfalse/kind4/ramp | +0.208333% |
| UVRoundedZeroNative/pitch672/verticaltrue/kind6/ramp | +0.369656% |
| Variance16x16Native | +12.243187% |
| SubtractRowsNative/4x4/paddedfalse/pattern0 | +0.206879% |

## Code-generation scope correction

No legacy XMM-register WRITES in the SIMD arithmetic loops. Two legacy MOVQ XMM15-to-stack stores remain in defer prologues before YMM dataflow. Earlier whole-body no-legacy-vector wording was too broad; regex omitted MOVQ stores. Codegen alone does not establish timing or cause old151ns anomaly.

The earlier whole-body no-legacy-vector wording was too broad because its regex omitted MOVQ stores. Both original correction files, including the complete disassembly and scope note, are embedded as recoverable UTF8 bytes with SHA256 values in audit.json. Re-encoding each string as UTF8 reproduces the exact hashed file bytes. Code generation alone establishes no timing cause.

## Optimized libvpx

| Case | Go/libvpx time | Scope |
|---|---:|---|
| vp9-320p | 2.923605× | Unequal measured quality/output work |
| vp9-720p | 3.002475× | Unequal measured quality/output work |
| vp8-720p-adaptive | 1.779814× | Unequal measured quality/output work |
| vp8-720p-fixed | 2.353120× | Matched measured PSNR/SSIM/payload/counts |

Libvpx is faster. Fixed measured-quality/payload/count equality does not prove bitstream identity; adaptive and VP9 remain unequal workloads. Every quality-pass output statistic matches timed output in this job. Pinned libvpx v1.16.0/1024874c5919305883187e2953de8fcb4c3d7fa6 uses verified assembly/SSE2/AVX2/runtime detection and vpxenc-stats timers. No cross-host attribution.

## Preservation

All 86 native and 74 C files are preserved byte for byte. Raw member hashes and outer hashes are verified. audit.json includes exact source hashes, all selected fixture/pair metrics, every median/all-six regression, complete semantic/allocation controls, CPU/runtime dispatch, short independent profile summaries and baseline-equivalence proof. All 48 unrelated old-reference AMD subtraction fixtures use scalar fallback; their harness assembly labels are not assembly claims. No root checkout/index/branch/README or Go jobs were changed/run by the audit.

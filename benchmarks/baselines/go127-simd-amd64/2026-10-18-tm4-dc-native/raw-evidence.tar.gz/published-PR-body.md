ARM 4×4 true-motion now forms one saturated byte tile with exact four-byte reference loads and one packed store or four ordered row stores. Disjointness guards retain alias, malformed-window and panic/partial-write behavior. DC reconstruction forwards to one native owner, removing two intermediate 96-byte call frames while preserving rounding, byte arithmetic and sequential fallback. Loop-filter dispatch proves each axis window before calling the existing fused worker. Disabled scalar contracts remain covered. No README, dependency or handwritten-assembly changes.

Combined native ARM evidence uses Apple M4 Max, official Go 1.27.2, CGO=1, SIMD, PGO off and GOMAXPROCS=1 against merged #47 and pinned old assembly. Six balanced three-way rounds retain 990 kernel samples and 165 excluded one-shot oracles, all zero-allocation:

| Public kernel | Speedup vs #47 | Comparison with old assembly |
|---|---:|---|
| TM4, nine fixtures | 2.539–2.622×; all 54 pairs ≥2.500× | Every pair faster; medians 1.090–1.122× |
| DC pair, eighteen fixtures | 1.215–1.333×; all 108 pairs faster | Old assembly remains faster in every pair |
| Loop-filter picker, ten fixtures | 0.993–1.086×; mixed | 36 pairs faster, 24 slower |

TM4 meets the mandatory ≥1.5× retention rule independently of whole-codec results. Smaller DC/filter gains remain separately scoped. In-place DC includes the same 32-byte reset in every variant. TM8/16 controls preserve slower results: 19/54 and 15/54 pairs faster, median ratios 0.979–1.004× and 0.978–1.003×. Source identity does not dismiss regressions.

Whole VP8 720p/300 inputs takes 7.173943 ms/input versus #47’s 7.312296: **1.892% less time, all six pairs faster**. Old assembly takes 6.707730 ms/input: **the remaining ARM gap is 6.950%, every pair slower**. All 22 semantic fields and zero allocations match across 18 runs. These combined measurements are direct; isolated ratios and separate windows are not multiplied or pooled. Matching statistics do not establish bitstream identity.

The completed full native x64 stability job uses **EPYC 7763**. All 516 AMD fixtures are controls for these ARM production changes:

| Workload | Candidate time vs parent | Faster parent pairs | Candidate time vs old assembly |
|---|---:|---:|---:|
| VP8 720p | −0.007775% | 3/6 | −22.143232%, all six faster |
| VP9 320p | −0.239655% | 4/6 | −42.031959%, all six faster |
| VP9 720p | −0.206954% | 3/6 | −53.582362%, all six faster |

All 9,288 three-way kernel samples allocate zero. All 22 public/profile semantic fields and every allocation vector match on this run. **244 control medians are slower and nine cases are slower in every pair**; all samples remain preserved. The separate guard diagnostic’s twelve disjoint cases measure 1.804–2.445× versus the frozen #46 helper, but the actual guard is unchanged from #47: this inherited result receives no new AMD causal credit. Prior checkpoint regressions, CPU scope and allocation exceptions remain archived.

The separate focused SSE8 runner is **EPYC 9V45**. Parent/candidate median ratios span 0.991905–1.030084×; seven of 36 medians are slower, none slower in all six pairs. Minimum paired ratio 0.799643× is retained. All 720 measured samples/120 excluded oracles remain available. These controls are not attributed to ARM changes or dismissed as noise.

Pristine optimized libvpx v1.16.0 is pinned to `1024874c5919305883187e2953de8fcb4c3d7fa6`:

| Separate C runner | Fixed VP8 Go/C time | Adaptive VP8 Go/C time | VP9 320p / 720p Go/C time |
|---|---:|---:|---:|
| EPYC 7763 | 2.167001× | 1.671928× | 2.833466× / 2.684831× |
| Apple M4 Max | 2.045833× | 1.535885× | 2.434797× / 2.540570× |

Ratios above one mean libvpx is faster. Fixed CPU-used −8 with quantizer bounds is not fixed quantization. Fixed VP8 on both runners and adaptive VP8 on this ARM run match measured output and separately decoded PSNR/SSIM with 58 quality frames. Quality is measured **only in separate passes**; every timed output matches its side’s quality-pass output statistics. X64 adaptive VP8 and both VP9 comparisons retain unequal output/quality work. No bitstream identity or cross-job causal claim follows; even matching CPU model names do not pool separate jobs.

All 1,937 compiled ARM Go files bind to runtime commit `d05c3908`, retained unchanged by evidence-only head `31123a9e`. Validation includes the full suite, ARM race/checkptr2, PGO/build-selection/pre-commit gates and selected/AVX-off amd64 correctness checks. Rosetta is correctness-only. Native evidence verifies 103 source hashes, 32 shared fixtures, 392 excluded oracles and the separate 66 guard cases/396 timings/66 excluded oracles. Independent audits and explicit performance approval retain every control/regression. Later private DC-pointer, Stats, SIMD and AVX512 prototypes are not in this frozen PR. Raw evidence remains under benchmarks/baselines, outside README files.

Checks: [Exhaustive test](https://github.com/thesyncim/govpx/actions/runs/39110226565/job/117624571208), [benchmark](https://github.com/thesyncim/govpx/actions/runs/39110226579/job/117624571557), [sse8](https://github.com/thesyncim/govpx/actions/runs/39110226671/job/117624571812), [libvpx-reference](https://github.com/thesyncim/govpx/actions/runs/39110226579/job/117624571286).

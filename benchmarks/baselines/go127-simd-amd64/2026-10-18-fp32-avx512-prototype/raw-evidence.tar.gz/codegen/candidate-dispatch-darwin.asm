
/private/tmp/govpx-fp32-avx512-48/validation/candidate-darwin.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

0000000001158120 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD>:
 1158120: 4c 8d 64 24 d0               	leaq	-0x30(%rsp), %r12
 1158125: 4d 3b 66 10                  	cmpq	0x10(%r14), %r12
 1158129: 0f 86 03 09 00 00            	jbe	0x1158a32 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x912>
 115812f: 55                           	pushq	%rbp
 1158130: 48 89 e5                     	movq	%rsp, %rbp
 1158133: 48 81 ec a8 00 00 00         	subq	$0xa8, %rsp
 115813a: 48 89 84 24 00 01 00 00      	movq	%rax, 0x100(%rsp)
 1158142: 4c 89 8c 24 30 01 00 00      	movq	%r9, 0x130(%rsp)
 115814a: 4c 89 84 24 28 01 00 00      	movq	%r8, 0x128(%rsp)
 1158152: 48 89 b4 24 20 01 00 00      	movq	%rsi, 0x120(%rsp)
 115815a: 48 89 bc 24 18 01 00 00      	movq	%rdi, 0x118(%rsp)
 1158162: 48 89 9c 24 08 01 00 00      	movq	%rbx, 0x108(%rsp)
 115816a: 48 8b 94 24 d0 00 00 00      	movq	0xd0(%rsp), %rdx
 1158172: 4c 8d 62 c0                  	leaq	-0x40(%rdx), %r12
 1158176: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
 115817f: 90                           	nop
 1158180: 49 81 fc c0 03 00 00         	cmpq	$0x3c0, %r12            ## imm = 0x3C0
 1158187: 0f 87 09 01 00 00            	ja	0x1158296 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x176>
 115818d: 48 f7 c2 0f 00 00 00         	testq	$0xf, %rdx
 1158194: 0f 85 f7 00 00 00            	jne	0x1158291 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x171>
 115819a: 80 3d ac d5 25 00 00         	cmpb	$0x0, 0x25d5ac(%rip)    ## 0x13b574d <_github.com/thesyncim/govpx/internal/pixel.Enabled>
 11581a1: 0f 84 e5 00 00 00            	je	0x115828c <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x16c>
 11581a7: 80 3d 16 e1 25 00 00         	cmpb	$0x0, 0x25e116(%rip)    ## 0x13b62c4 <_internal/cpu.X86+0x44>
 11581ae: 75 08                        	jne	0x11581b8 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x98>
 11581b0: 45 31 e4                     	xorl	%r12d, %r12d
 11581b3: e9 e8 00 00 00               	jmp	0x11582a0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
 11581b8: 4c 89 94 24 38 01 00 00      	movq	%r10, 0x138(%rsp)
 11581c0: 4c 89 8c 24 30 01 00 00      	movq	%r9, 0x130(%rsp)
 11581c8: 48 89 8c 24 10 01 00 00      	movq	%rcx, 0x110(%rsp)
 11581d0: 48 89 84 24 00 01 00 00      	movq	%rax, 0x100(%rsp)
 11581d8: 4c 89 9c 24 40 01 00 00      	movq	%r11, 0x140(%rsp)
 11581e0: 4c 8b a4 24 b8 00 00 00      	movq	0xb8(%rsp), %r12
 11581e8: 4c 89 24 24                  	movq	%r12, (%rsp)
 11581ec: 4c 8b a4 24 c0 00 00 00      	movq	0xc0(%rsp), %r12
 11581f4: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
 11581f9: 4c 8b a4 24 c8 00 00 00      	movq	0xc8(%rsp), %r12
 1158201: 4c 89 64 24 10               	movq	%r12, 0x10(%rsp)
 1158206: 4c 8b a4 24 e8 00 00 00      	movq	0xe8(%rsp), %r12
 115820e: 4c 89 64 24 18               	movq	%r12, 0x18(%rsp)
 1158213: 4c 8b a4 24 f0 00 00 00      	movq	0xf0(%rsp), %r12
 115821b: 4c 89 64 24 20               	movq	%r12, 0x20(%rsp)
 1158220: 4c 8b a4 24 f8 00 00 00      	movq	0xf8(%rsp), %r12
 1158228: 4c 89 64 24 28               	movq	%r12, 0x28(%rsp)
 115822d: 48 89 54 24 30               	movq	%rdx, 0x30(%rsp)
 1158232: e8 89 08 00 00               	callq	0x1158ac0 <_github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>
 1158237: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
 115823f: 48 8b 94 24 d0 00 00 00      	movq	0xd0(%rsp), %rdx
 1158247: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
 115824f: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
 1158257: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
 115825f: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
 1158267: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
 115826f: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
 1158277: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
 115827f: 41 89 c4                     	movl	%eax, %r12d
 1158282: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
 115828a: eb 14                        	jmp	0x11582a0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
 115828c: 45 31 e4                     	xorl	%r12d, %r12d
 115828f: eb 0f                        	jmp	0x11582a0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
 1158291: 45 31 e4                     	xorl	%r12d, %r12d
 1158294: eb 0a                        	jmp	0x11582a0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x180>
 1158296: 45 31 e4                     	xorl	%r12d, %r12d
 1158299: 0f 1f 80 00 00 00 00         	nopl	(%rax)
 11582a0: 45 84 e4                     	testb	%r12b, %r12b
 11582a3: 0f 84 68 02 00 00            	je	0x1158511 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x3f1>
 11582a9: 48 81 fa 00 01 00 00         	cmpq	$0x100, %rdx            ## imm = 0x100
 11582b0: 0f 8c a5 00 00 00            	jl	0x115835b <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x23b>
 11582b6: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
 11582bf: 90                           	nop
 11582c0: 48 f7 c2 1f 00 00 00         	testq	$0x1f, %rdx
 11582c7: 0f 85 8e 00 00 00            	jne	0x115835b <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x23b>
 11582cd: 80 3d f1 df 25 00 00         	cmpb	$0x0, 0x25dff1(%rip)    ## 0x13b62c5 <_internal/cpu.X86+0x45>
 11582d4: 0f 84 81 00 00 00            	je	0x115835b <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x23b>
 11582da: 4c 8b a4 24 b8 00 00 00      	movq	0xb8(%rsp), %r12
 11582e2: 4c 89 24 24                  	movq	%r12, (%rsp)
 11582e6: 4c 8b a4 24 c0 00 00 00      	movq	0xc0(%rsp), %r12
 11582ee: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
 11582f3: 4c 8b a4 24 c8 00 00 00      	movq	0xc8(%rsp), %r12
 11582fb: 4c 89 64 24 10               	movq	%r12, 0x10(%rsp)
 1158300: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
 1158305: 8b 94 24 d8 00 00 00         	movl	0xd8(%rsp), %edx
 115830c: 89 54 24 20                  	movl	%edx, 0x20(%rsp)
 1158310: 8b 94 24 dc 00 00 00         	movl	0xdc(%rsp), %edx
 1158317: 89 54 24 24                  	movl	%edx, 0x24(%rsp)
 115831b: 8b 94 24 e0 00 00 00         	movl	0xe0(%rsp), %edx
 1158322: 89 54 24 28                  	movl	%edx, 0x28(%rsp)
 1158326: 48 8b 94 24 e8 00 00 00      	movq	0xe8(%rsp), %rdx
 115832e: 48 89 54 24 30               	movq	%rdx, 0x30(%rsp)
 1158333: 48 8b 94 24 f0 00 00 00      	movq	0xf0(%rsp), %rdx
 115833b: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
 1158340: 48 8b 94 24 f8 00 00 00      	movq	0xf8(%rsp), %rdx
 1158348: 48 89 54 24 40               	movq	%rdx, 0x40(%rsp)
 115834d: e8 ee fa ff ff               	callq	0x1157e40 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512>
 1158352: 48 81 c4 a8 00 00 00         	addq	$0xa8, %rsp
 1158359: 5d                           	popq	%rbp
 115835a: c3                           	retq
 115835b: 90                           	nop
 115835c: 48 8b 8c 24 e8 00 00 00      	movq	0xe8(%rsp), %rcx
 1158364: 48 85 c9                     	testq	%rcx, %rcx
 1158367: 74 0a                        	je	0x1158373 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x253>
 1158369: c5 fa 6f 05 bf 95 21 00      	vmovdqu	0x2195bf(%rip), %xmm0   ## 0x1371930 <_github.com/thesyncim/govpx/internal/pixel.fpClassLUT>
 1158371: eb 04                        	jmp	0x1158377 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x257>
 1158373: 41 0f 10 c7                  	movups	%xmm15, %xmm0
 1158377: 0f b7 9c 24 da 00 00 00      	movzwl	0xda(%rsp), %ebx
 115837f: 0f b7 b4 24 d8 00 00 00      	movzwl	0xd8(%rsp), %esi
 1158387: 44 0f b7 84 24 de 00 00 00   	movzwl	0xde(%rsp), %r8d
 1158390: 44 0f b7 94 24 dc 00 00 00   	movzwl	0xdc(%rsp), %r10d
 1158399: 44 0f b7 9c 24 e0 00 00 00   	movzwl	0xe0(%rsp), %r11d
 11583a2: 44 0f b7 a4 24 e2 00 00 00   	movzwl	0xe2(%rsp), %r12d
 11583ab: c5 fe 6f 08                  	vmovdqu	(%rax), %ymm1
 11583af: c4 e2 7d 1d d1               	vpabsw	%ymm1, %ymm2
 11583b4: c5 f5 71 e1 0f               	vpsraw	$0xf, %ymm1, %ymm1
 11583b9: 41 bd ff 7f 00 00            	movl	$0x7fff, %r13d          ## imm = 0x7FFF
 11583bf: c4 c1 f9 6e dd               	vmovq	%r13, %xmm3
 11583c4: c4 e2 7d 79 db               	vpbroadcastw	%xmm3, %ymm3
 11583c9: c5 81 c4 e3 00               	vpinsrw	$0x0, %ebx, %xmm15, %xmm4
 11583ce: c4 e2 7d 79 ec               	vpbroadcastw	%xmm4, %ymm5
 11583d3: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
 11583d8: c5 d9 c4 e6 00               	vpinsrw	$0x0, %esi, %xmm4, %xmm4
 11583dd: c4 e3 55 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm5, %ymm4
 11583e3: c5 ed fd d4                  	vpaddw	%ymm4, %ymm2, %ymm2
 11583e7: c4 e2 6d 3a d3               	vpminuw	%ymm3, %ymm2, %ymm2
 11583ec: c4 c1 01 c4 e0 00            	vpinsrw	$0x0, %r8d, %xmm15, %xmm4
 11583f2: c4 e2 7d 79 ec               	vpbroadcastw	%xmm4, %ymm5
 11583f7: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
 11583fc: c4 c1 59 c4 e2 00            	vpinsrw	$0x0, %r10d, %xmm4, %xmm4
 1158402: c4 e3 55 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm5, %ymm4
 1158408: c5 ed e5 e4                  	vpmulhw	%ymm4, %ymm2, %ymm4
 115840c: c4 c1 01 c4 ec 00            	vpinsrw	$0x0, %r12d, %xmm15, %xmm5
 1158412: c4 e2 7d 79 f5               	vpbroadcastw	%xmm5, %ymm6
 1158417: c4 e2 79 79 ed               	vpbroadcastw	%xmm5, %xmm5
 115841c: c4 c1 51 c4 eb 00            	vpinsrw	$0x0, %r11d, %xmm5, %xmm5
 1158422: c4 e3 4d 38 ed 00            	vinserti128	$0x0, %xmm5, %ymm6, %ymm5
 1158428: c5 ed 75 f2                  	vpcmpeqw	%ymm2, %ymm2, %ymm6
 115842c: c5 d5 65 d2                  	vpcmpgtw	%ymm2, %ymm5, %ymm2
 1158430: c5 ed ef d6                  	vpxor	%ymm6, %ymm2, %ymm2
 1158434: c5 dd db d2                  	vpand	%ymm2, %ymm4, %ymm2
 1158438: c5 f5 ef e2                  	vpxor	%ymm2, %ymm1, %ymm4
 115843c: 90                           	nop
 115843d: c5 dd f9 c9                  	vpsubw	%ymm1, %ymm4, %ymm1
 1158441: 4d 85 c9                     	testq	%r9, %r9
 1158444: 74 0a                        	je	0x1158450 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x330>
 1158446: c4 c1 7e 7f 09               	vmovdqu	%ymm1, (%r9)
 115844b: 48 85 c9                     	testq	%rcx, %rcx
 115844e: eb 03                        	jmp	0x1158453 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x333>
 1158450: 48 85 c9                     	testq	%rcx, %rcx
 1158453: c5 dd ef e4                  	vpxor	%ymm4, %ymm4, %ymm4
 1158457: c5 d5 d5 e9                  	vpmullw	%ymm1, %ymm5, %ymm5
 115845b: 48 8b 9c 24 b8 00 00 00      	movq	0xb8(%rsp), %rbx
 1158463: c5 fe 7f 2b                  	vmovdqu	%ymm5, (%rbx)
 1158467: be 0b 00 00 00               	movl	$0xb, %esi
 115846c: c4 e1 f9 6e ee               	vmovq	%rsi, %xmm5
 1158471: c5 f5 75 f1                  	vpcmpeqw	%ymm1, %ymm1, %ymm6
 1158475: c5 f5 75 cc                  	vpcmpeqw	%ymm4, %ymm1, %ymm1
 1158479: c5 f5 ef ce                  	vpxor	%ymm6, %ymm1, %ymm1
 115847d: c5 f5 db 0f                  	vpand	(%rdi), %ymm1, %ymm1
 1158481: c5 f5 ee cc                  	vpmaxsw	%ymm4, %ymm1, %ymm1
 1158485: c4 e2 79 79 ed               	vpbroadcastw	%xmm5, %xmm5
 115848a: 74 43                        	je	0x11584cf <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x3af>
 115848c: c4 e3 7d 39 d6 00            	vextracti128	$0x0, %ymm2, %xmm6
 1158492: c5 c9 ea f5                  	vpminsw	%xmm5, %xmm6, %xmm6
 1158496: c4 e3 7d 39 d2 01            	vextracti128	$0x1, %ymm2, %xmm2
 115849c: c5 e9 ea d5                  	vpminsw	%xmm5, %xmm2, %xmm2
 11584a0: c5 fa 6f 3d 78 94 21 00      	vmovdqu	0x219478(%rip), %xmm7   ## 0x1371920 <_github.com/thesyncim/govpx/internal/pixel.packByteIndices>
 11584a8: c4 e2 49 00 f7               	vpshufb	%xmm7, %xmm6, %xmm6
 11584ad: c4 e2 69 00 d7               	vpshufb	%xmm7, %xmm2, %xmm2
 11584b2: c4 e2 79 00 f6               	vpshufb	%xmm6, %xmm0, %xmm6
 11584b7: c4 e3 f9 16 f6 00            	vpextrq	$0x0, %xmm6, %rsi
 11584bd: c4 e2 79 00 d2               	vpshufb	%xmm2, %xmm0, %xmm2
 11584c2: c4 c3 f9 16 d0 00            	vpextrq	$0x0, %xmm2, %r8
 11584c8: 48 89 31                     	movq	%rsi, (%rcx)
 11584cb: 4c 89 41 08                  	movq	%r8, 0x8(%rcx)
 11584cf: 0f b7 b4 24 da 00 00 00      	movzwl	0xda(%rsp), %esi
 11584d7: 44 0f b7 84 24 de 00 00 00   	movzwl	0xde(%rsp), %r8d
 11584e0: 44 0f b7 94 24 e2 00 00 00   	movzwl	0xe2(%rsp), %r10d
 11584e9: c4 e1 f9 6e d6               	vmovq	%rsi, %xmm2
 11584ee: c4 c1 f9 6e f0               	vmovq	%r8, %xmm6
 11584f3: c4 c1 f9 6e fa               	vmovq	%r10, %xmm7
 11584f8: c4 e2 7d 79 d2               	vpbroadcastw	%xmm2, %ymm2
 11584fd: c4 e2 7d 79 f6               	vpbroadcastw	%xmm6, %ymm6
 1158502: c4 e2 7d 79 ff               	vpbroadcastw	%xmm7, %ymm7
 1158507: be 10 00 00 00               	movl	$0x10, %esi
 115850c: e9 f8 03 00 00               	jmp	0x1158909 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7e9>
 1158511: 44 0f b7 a4 24 da 00 00 00   	movzwl	0xda(%rsp), %r12d
 115851a: 44 0f b7 ac 24 de 00 00 00   	movzwl	0xde(%rsp), %r13d
 1158523: 44 0f b7 bc 24 e2 00 00 00   	movzwl	0xe2(%rsp), %r15d
 115852c: 0f b7 bc 24 d8 00 00 00      	movzwl	0xd8(%rsp), %edi
 1158534: 44 0f b7 84 24 dc 00 00 00   	movzwl	0xdc(%rsp), %r8d
 115853d: 0f b7 b4 24 e0 00 00 00      	movzwl	0xe0(%rsp), %esi
 1158545: c4 c1 f9 6e c4               	vmovq	%r12, %xmm0
 115854a: c4 e2 79 79 c0               	vpbroadcastw	%xmm0, %xmm0
 115854f: c4 c1 f9 6e cd               	vmovq	%r13, %xmm1
 1158554: c4 e2 79 79 c9               	vpbroadcastw	%xmm1, %xmm1
 1158559: c4 c1 f9 6e d7               	vmovq	%r15, %xmm2
 115855e: c4 e2 79 79 d2               	vpbroadcastw	%xmm2, %xmm2
 1158563: 41 bc ff 7f 00 00            	movl	$0x7fff, %r12d          ## imm = 0x7FFF
 1158569: c4 c1 f9 6e dc               	vmovq	%r12, %xmm3
 115856e: c5 f9 c4 e7 00               	vpinsrw	$0x0, %edi, %xmm0, %xmm4
 1158573: c4 c1 71 c4 e8 00            	vpinsrw	$0x0, %r8d, %xmm1, %xmm5
 1158579: c5 e9 c4 f6 00               	vpinsrw	$0x0, %esi, %xmm2, %xmm6
 115857e: 90                           	nop
 115857f: c5 fa 6f 3d a9 93 21 00      	vmovdqu	0x2193a9(%rip), %xmm7   ## 0x1371930 <_github.com/thesyncim/govpx/internal/pixel.fpClassLUT>
 1158587: c4 e2 79 79 db               	vpbroadcastw	%xmm3, %xmm3
 115858c: 45 31 e4                     	xorl	%r12d, %r12d
 115858f: 45 0f 10 c7                  	movups	%xmm15, %xmm8
 1158593: 4c 8b ac 24 c0 00 00 00      	movq	0xc0(%rsp), %r13
 115859b: 4c 8b bc 24 c8 00 00 00      	movq	0xc8(%rsp), %r15
 11585a3: 48 8b b4 24 b8 00 00 00      	movq	0xb8(%rsp), %rsi
 11585ab: eb 26                        	jmp	0x11585d3 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x4b3>
 11585ad: 49 89 dd                     	movq	%rbx, %r13
 11585b0: 4c 8b bc 24 c8 00 00 00      	movq	0xc8(%rsp), %r15
 11585b8: 41 0f 10 e2                  	movups	%xmm10, %xmm4
 11585bc: 41 0f 10 eb                  	movups	%xmm11, %xmm5
 11585c0: 49 89 fc                     	movq	%rdi, %r12
 11585c3: 44 0f 10 c6                  	movups	%xmm6, %xmm8
 11585c7: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
 11585cf: 41 0f 10 f1                  	movups	%xmm9, %xmm6
 11585d3: 49 8d 7c 24 08               	leaq	0x8(%r12), %rdi
 11585d8: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)
 11585e0: 48 39 fa                     	cmpq	%rdi, %rdx
 11585e3: 0f 8c 14 02 00 00            	jl	0x11587fd <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x6dd>
 11585e9: 4d 85 e4                     	testq	%r12, %r12
 11585ec: 75 0e                        	jne	0x11585fc <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x4dc>
 11585ee: 44 0f 10 ce                  	movups	%xmm6, %xmm9
 11585f2: 44 0f 10 d4                  	movups	%xmm4, %xmm10
 11585f6: 44 0f 10 dd                  	movups	%xmm5, %xmm11
 11585fa: eb 15                        	jmp	0x1158611 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x4f1>
 11585fc: 44 0f 10 ce                  	movups	%xmm6, %xmm9
 1158600: 44 0f 10 d4                  	movups	%xmm4, %xmm10
 1158604: 44 0f 10 dd                  	movups	%xmm5, %xmm11
 1158608: 0f 10 f2                     	movups	%xmm2, %xmm6
 115860b: 0f 10 e0                     	movups	%xmm0, %xmm4
 115860e: 0f 10 e9                     	movups	%xmm1, %xmm5
 1158611: 4c 39 e3                     	cmpq	%r12, %rbx
 1158614: 0f 82 e4 02 00 00            	jb	0x11588fe <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7de>
 115861a: 4c 89 a4 24 a0 00 00 00      	movq	%r12, 0xa0(%rsp)
 1158622: 4f 8d 04 24                  	leaq	(%r12,%r12), %r8
 1158626: 4c 29 e3                     	subq	%r12, %rbx
 1158629: 49 29 cc                     	subq	%rcx, %r12
 115862c: 49 c1 fc 3f                  	sarq	$0x3f, %r12
 1158630: 4d 21 c4                     	andq	%r8, %r12
 1158633: 49 01 c4                     	addq	%rax, %r12
 1158636: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
 115863f: 90                           	nop
 1158640: 48 83 fb 08                  	cmpq	$0x8, %rbx
 1158644: 0f 82 af 02 00 00            	jb	0x11588f9 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7d9>
 115864a: c4 41 7a 6f 24 24            	vmovdqu	(%r12), %xmm12
 1158650: c4 42 79 1d ec               	vpabsw	%xmm12, %xmm13
 1158655: c5 91 fd e4                  	vpaddw	%xmm4, %xmm13, %xmm4
 1158659: c4 e2 59 3a e3               	vpminuw	%xmm3, %xmm4, %xmm4
 115865e: c5 d9 e5 ed                  	vpmulhw	%xmm5, %xmm4, %xmm5
 1158662: c5 59 75 ec                  	vpcmpeqw	%xmm4, %xmm4, %xmm13
 1158666: c5 c9 65 e4                  	vpcmpgtw	%xmm4, %xmm6, %xmm4
 115866a: c4 c1 59 ef e5               	vpxor	%xmm13, %xmm4, %xmm4
 115866f: c5 d1 db e4                  	vpand	%xmm4, %xmm5, %xmm4
 1158673: 41 0f 10 ef                  	movups	%xmm15, %xmm5
 1158677: c5 51 f9 ec                  	vpsubw	%xmm4, %xmm5, %xmm13
 115867b: c4 41 51 65 e4               	vpcmpgtw	%xmm12, %xmm5, %xmm12
 1158680: 90                           	nop
 1158681: 90                           	nop
 1158682: 90                           	nop
 1158683: c4 43 59 4c e5 c0            	vpblendvb	%xmm12, %xmm13, %xmm4, %xmm12
 1158689: 4d 85 c9                     	testq	%r9, %r9
 115868c: 74 34                        	je	0x11586c2 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x5a2>
 115868e: 4c 8b a4 24 a0 00 00 00      	movq	0xa0(%rsp), %r12
 1158696: 4d 39 e2                     	cmpq	%r12, %r10
 1158699: 0f 82 55 02 00 00            	jb	0x11588f4 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7d4>
 115869f: 4c 89 d3                     	movq	%r10, %rbx
 11586a2: 4c 29 e3                     	subq	%r12, %rbx
 11586a5: 4d 29 dc                     	subq	%r11, %r12
 11586a8: 49 c1 fc 3f                  	sarq	$0x3f, %r12
 11586ac: 4d 21 c4                     	andq	%r8, %r12
 11586af: 4d 01 cc                     	addq	%r9, %r12
 11586b2: 48 83 fb 08                  	cmpq	$0x8, %rbx
 11586b6: 0f 82 33 02 00 00            	jb	0x11588ef <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7cf>
 11586bc: c4 41 7a 7f 24 24            	vmovdqu	%xmm12, (%r12)
 11586c2: c5 99 d5 f6                  	vpmullw	%xmm6, %xmm12, %xmm6
 11586c6: 4c 8b a4 24 a0 00 00 00      	movq	0xa0(%rsp), %r12
 11586ce: 4d 39 e5                     	cmpq	%r12, %r13
 11586d1: 0f 82 13 02 00 00            	jb	0x11588ea <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7ca>
 11586d7: 4c 89 eb                     	movq	%r13, %rbx
 11586da: 4d 29 e5                     	subq	%r12, %r13
 11586dd: 4d 29 fc                     	subq	%r15, %r12
 11586e0: 49 c1 fc 3f                  	sarq	$0x3f, %r12
 11586e4: 4d 21 c4                     	andq	%r8, %r12
 11586e7: 49 01 f4                     	addq	%rsi, %r12
 11586ea: 49 83 fd 08                  	cmpq	$0x8, %r13
 11586ee: 0f 82 f1 01 00 00            	jb	0x11588e5 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7c5>
 11586f4: c4 c1 7a 7f 34 24            	vmovdqu	%xmm6, (%r12)
 11586fa: 4c 8b a4 24 20 01 00 00      	movq	0x120(%rsp), %r12
 1158702: 4c 8b ac 24 a0 00 00 00      	movq	0xa0(%rsp), %r13
 115870a: 4d 39 ec                     	cmpq	%r13, %r12
 115870d: 0f 82 cb 01 00 00            	jb	0x11588de <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7be>
 1158713: 4d 29 ec                     	subq	%r13, %r12
 1158716: 4c 8b bc 24 28 01 00 00      	movq	0x128(%rsp), %r15
 115871e: 4d 29 fd                     	subq	%r15, %r13
 1158721: 49 c1 fd 3f                  	sarq	$0x3f, %r13
 1158725: 4d 21 c5                     	andq	%r8, %r13
 1158728: 4d 89 f8                     	movq	%r15, %r8
 115872b: 4c 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %r15
 1158733: 4d 01 fd                     	addq	%r15, %r13
 1158736: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
 115873f: 90                           	nop
 1158740: 49 83 fc 08                  	cmpq	$0x8, %r12
 1158744: 0f 82 8f 01 00 00            	jb	0x11588d9 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7b9>
 115874a: c4 c1 19 75 f4               	vpcmpeqw	%xmm12, %xmm12, %xmm6
 115874f: c5 19 75 e5                  	vpcmpeqw	%xmm5, %xmm12, %xmm12
 1158753: c5 99 ef f6                  	vpxor	%xmm6, %xmm12, %xmm6
 1158757: c4 c1 49 db 75 00            	vpand	(%r13), %xmm6, %xmm6
 115875d: c5 b9 ee f6                  	vpmaxsw	%xmm6, %xmm8, %xmm6
 1158761: 4c 8b a4 24 e8 00 00 00      	movq	0xe8(%rsp), %r12
 1158769: 4d 85 e4                     	testq	%r12, %r12
 115876c: 0f 84 3b fe ff ff            	je	0x11585ad <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x48d>
 1158772: 41 bd 0b 00 00 00            	movl	$0xb, %r13d
 1158778: c4 41 f9 6e c5               	vmovq	%r13, %xmm8
 115877d: c4 42 79 79 c0               	vpbroadcastw	%xmm8, %xmm8
 1158782: c4 c1 59 ea e0               	vpminsw	%xmm8, %xmm4, %xmm4
 1158787: 4c 8b ac 24 f0 00 00 00      	movq	0xf0(%rsp), %r13
 115878f: 4c 8b bc 24 a0 00 00 00      	movq	0xa0(%rsp), %r15
 1158797: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
 11587a0: 4d 39 fd                     	cmpq	%r15, %r13
 11587a3: 0f 82 2b 01 00 00            	jb	0x11588d4 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7b4>
 11587a9: 4d 29 fd                     	subq	%r15, %r13
 11587ac: 48 8b 94 24 f8 00 00 00      	movq	0xf8(%rsp), %rdx
 11587b4: 49 29 d7                     	subq	%rdx, %r15
 11587b7: 49 c1 ff 3f                  	sarq	$0x3f, %r15
 11587bb: c4 e2 59 00 25 5c 91 21 00   	vpshufb	0x21915c(%rip), %xmm4, %xmm4 ## 0x1371920 <_github.com/thesyncim/govpx/internal/pixel.packByteIndices>
 11587c4: 48 8b 94 24 a0 00 00 00      	movq	0xa0(%rsp), %rdx
 11587cc: 4c 21 fa                     	andq	%r15, %rdx
 11587cf: c4 e2 41 00 e4               	vpshufb	%xmm4, %xmm7, %xmm4
 11587d4: 49 83 fd 07                  	cmpq	$0x7, %r13
 11587d8: 0f 86 f1 00 00 00            	jbe	0x11588cf <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7af>
 11587de: c4 c3 f9 16 e5 00            	vpextrq	$0x0, %xmm4, %r13
 11587e4: 4d 89 2c 14                  	movq	%r13, (%r12,%rdx)
 11587e8: 48 8b 94 24 d0 00 00 00      	movq	0xd0(%rsp), %rdx
 11587f0: 4c 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %r15
 11587f8: e9 b0 fd ff ff               	jmp	0x11585ad <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x48d>
 11587fd: c4 c2 79 23 c0               	vpmovsxwd	%xmm8, %xmm0
 1158802: c4 c1 79 70 c8 4e            	vpshufd	$0x4e, %xmm8, %xmm1     ## xmm1 = xmm8[2,3,0,1]
 1158808: c4 e2 79 23 c9               	vpmovsxwd	%xmm1, %xmm1
 115880d: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
 1158812: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     ## xmm1 = xmm0[2,3,0,1]
 1158817: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
 115881c: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     ## xmm1 = xmm0[1,0,3,2]
 1158821: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
 1158826: c4 e3 79 16 c7 00            	vpextrd	$0x0, %xmm0, %edi
 115882c: 48 63 ff                     	movslq	%edi, %rdi
 115882f: 48 89 bc 24 98 00 00 00      	movq	%rdi, 0x98(%rsp)
 1158837: 48 89 34 24                  	movq	%rsi, (%rsp)
 115883b: 4c 89 6c 24 08               	movq	%r13, 0x8(%rsp)
 1158840: 4c 89 7c 24 10               	movq	%r15, 0x10(%rsp)
 1158845: 4c 89 64 24 18               	movq	%r12, 0x18(%rsp)
 115884a: 48 89 54 24 20               	movq	%rdx, 0x20(%rsp)
 115884f: 8b 94 24 d8 00 00 00         	movl	0xd8(%rsp), %edx
 1158856: 89 54 24 28                  	movl	%edx, 0x28(%rsp)
 115885a: 8b 94 24 dc 00 00 00         	movl	0xdc(%rsp), %edx
 1158861: 89 54 24 2c                  	movl	%edx, 0x2c(%rsp)
 1158865: 8b 94 24 e0 00 00 00         	movl	0xe0(%rsp), %edx
 115886c: 89 54 24 30                  	movl	%edx, 0x30(%rsp)
 1158870: 48 8b 94 24 e8 00 00 00      	movq	0xe8(%rsp), %rdx
 1158878: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
 115887d: 48 8b 94 24 f0 00 00 00      	movq	0xf0(%rsp), %rdx
 1158885: 48 89 54 24 40               	movq	%rdx, 0x40(%rsp)
 115888a: 48 8b 94 24 f8 00 00 00      	movq	0xf8(%rsp), %rdx
 1158892: 48 89 54 24 48               	movq	%rdx, 0x48(%rsp)
 1158897: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
 115889f: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
 11588a7: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
 11588af: e8 cc f3 ff ff               	callq	0x1157c80 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockTail>
 11588b4: 48 8b 94 24 98 00 00 00      	movq	0x98(%rsp), %rdx
 11588bc: 48 39 d0                     	cmpq	%rdx, %rax
 11588bf: 48 0f 4f d0                  	cmovgq	%rax, %rdx
 11588c3: 48 89 d0                     	movq	%rdx, %rax
 11588c6: 48 81 c4 a8 00 00 00         	addq	$0xa8, %rsp
 11588cd: 5d                           	popq	%rbp
 11588ce: c3                           	retq
 11588cf: e8 4c 0e f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 11588d4: e8 47 0e f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 11588d9: e8 42 0e f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 11588de: 66 90                        	nop
 11588e0: e8 3b 0e f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 11588e5: e8 36 0e f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 11588ea: e8 31 0e f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 11588ef: e8 2c 0e f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 11588f4: e8 27 0e f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 11588f9: e8 22 0e f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 11588fe: 66 90                        	nop
 1158900: e8 1b 0e f3 ff               	callq	0x1089720 <_runtime.panicBounds>
 1158905: 48 83 c6 10                  	addq	$0x10, %rsi
 1158909: 48 39 f2                     	cmpq	%rsi, %rdx
 115890c: 0f 8e d3 00 00 00            	jle	0x11589e5 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x8c5>
 1158912: 4c 8d 04 70                  	leaq	(%rax,%rsi,2), %r8
 1158916: c4 41 7e 6f 00               	vmovdqu	(%r8), %ymm8
 115891b: c4 42 7d 1d c8               	vpabsw	%ymm8, %ymm9
 1158920: c5 35 fd ca                  	vpaddw	%ymm2, %ymm9, %ymm9
 1158924: c4 62 35 3a cb               	vpminuw	%ymm3, %ymm9, %ymm9
 1158929: c5 35 e5 d6                  	vpmulhw	%ymm6, %ymm9, %ymm10
 115892d: c4 c1 3d 71 e0 0f            	vpsraw	$0xf, %ymm8, %ymm8
 1158933: c4 41 35 75 d9               	vpcmpeqw	%ymm9, %ymm9, %ymm11
 1158938: c4 41 45 65 c9               	vpcmpgtw	%ymm9, %ymm7, %ymm9
 115893d: c4 41 35 ef cb               	vpxor	%ymm11, %ymm9, %ymm9
 1158942: c4 41 2d db c9               	vpand	%ymm9, %ymm10, %ymm9
 1158947: c4 41 3d ef d1               	vpxor	%ymm9, %ymm8, %ymm10
 115894c: c4 41 2d f9 c0               	vpsubw	%ymm8, %ymm10, %ymm8
 1158951: 4d 85 c9                     	testq	%r9, %r9
 1158954: 74 0e                        	je	0x1158964 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x844>
 1158956: 4d 8d 04 71                  	leaq	(%r9,%rsi,2), %r8
 115895a: c4 41 7e 7f 00               	vmovdqu	%ymm8, (%r8)
 115895f: 48 85 c9                     	testq	%rcx, %rcx
 1158962: eb 03                        	jmp	0x1158967 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x847>
 1158964: 48 85 c9                     	testq	%rcx, %rcx
 1158967: c4 41 45 d5 d0               	vpmullw	%ymm8, %ymm7, %ymm10
 115896c: 4c 8d 04 73                  	leaq	(%rbx,%rsi,2), %r8
 1158970: c4 41 7e 7f 10               	vmovdqu	%ymm10, (%r8)
 1158975: 4c 8d 04 77                  	leaq	(%rdi,%rsi,2), %r8
 1158979: c4 41 3d 75 d0               	vpcmpeqw	%ymm8, %ymm8, %ymm10
 115897e: c5 3d 75 c4                  	vpcmpeqw	%ymm4, %ymm8, %ymm8
 1158982: c4 41 3d ef c2               	vpxor	%ymm10, %ymm8, %ymm8
 1158987: c4 41 3d db 00               	vpand	(%r8), %ymm8, %ymm8
 115898c: c4 c1 75 ee c8               	vpmaxsw	%ymm8, %ymm1, %ymm1
 1158991: 0f 84 6e ff ff ff            	je	0x1158905 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7e5>
 1158997: c4 43 7d 39 c8 00            	vextracti128	$0x0, %ymm9, %xmm8
 115899d: c5 39 ea c5                  	vpminsw	%xmm5, %xmm8, %xmm8
 11589a1: c4 43 7d 39 c9 01            	vextracti128	$0x1, %ymm9, %xmm9
 11589a7: c5 31 ea cd                  	vpminsw	%xmm5, %xmm9, %xmm9
 11589ab: c5 7a 6f 15 6d 8f 21 00      	vmovdqu	0x218f6d(%rip), %xmm10  ## 0x1371920 <_github.com/thesyncim/govpx/internal/pixel.packByteIndices>
 11589b3: c4 42 39 00 c2               	vpshufb	%xmm10, %xmm8, %xmm8
 11589b8: c4 42 31 00 ca               	vpshufb	%xmm10, %xmm9, %xmm9
 11589bd: c4 42 79 00 c0               	vpshufb	%xmm8, %xmm0, %xmm8
 11589c2: c4 43 f9 16 c0 00            	vpextrq	$0x0, %xmm8, %r8
 11589c8: c4 42 79 00 c1               	vpshufb	%xmm9, %xmm0, %xmm8
 11589cd: c4 43 f9 16 c2 00            	vpextrq	$0x0, %xmm8, %r10
 11589d3: 4c 89 04 31                  	movq	%r8, (%rcx,%rsi)
 11589d7: 4c 89 54 0e 08               	movq	%r10, 0x8(%rsi,%rcx)
 11589dc: 0f 1f 40 00                  	nopl	(%rax)
 11589e0: e9 20 ff ff ff               	jmp	0x1158905 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x7e5>
 11589e5: c4 e3 7d 39 c8 00            	vextracti128	$0x0, %ymm1, %xmm0
 11589eb: c4 e3 7d 39 c9 01            	vextracti128	$0x1, %ymm1, %xmm1
 11589f1: c5 f1 ee c0                  	vpmaxsw	%xmm0, %xmm1, %xmm0
 11589f5: c4 e2 79 23 c8               	vpmovsxwd	%xmm0, %xmm1
 11589fa: c5 f9 70 c0 4e               	vpshufd	$0x4e, %xmm0, %xmm0     ## xmm0 = xmm0[2,3,0,1]
 11589ff: c4 e2 79 23 c0               	vpmovsxwd	%xmm0, %xmm0
 1158a04: c4 e2 79 3d c1               	vpmaxsd	%xmm1, %xmm0, %xmm0
 1158a09: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     ## xmm1 = xmm0[2,3,0,1]
 1158a0e: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
 1158a13: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     ## xmm1 = xmm0[1,0,3,2]
 1158a18: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
 1158a1d: c4 e3 79 16 c1 00            	vpextrd	$0x0, %xmm0, %ecx
 1158a23: 48 63 c1                     	movslq	%ecx, %rax
 1158a26: c5 f8 77                     	vzeroupper
 1158a29: 48 81 c4 a8 00 00 00         	addq	$0xa8, %rsp
 1158a30: 5d                           	popq	%rbp
 1158a31: c3                           	retq
 1158a32: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
 1158a37: 48 89 5c 24 58               	movq	%rbx, 0x58(%rsp)
 1158a3c: 48 89 4c 24 60               	movq	%rcx, 0x60(%rsp)
 1158a41: 48 89 7c 24 68               	movq	%rdi, 0x68(%rsp)
 1158a46: 48 89 74 24 70               	movq	%rsi, 0x70(%rsp)
 1158a4b: 4c 89 44 24 78               	movq	%r8, 0x78(%rsp)
 1158a50: 4c 89 8c 24 80 00 00 00      	movq	%r9, 0x80(%rsp)
 1158a58: 4c 89 94 24 88 00 00 00      	movq	%r10, 0x88(%rsp)
 1158a60: 4c 89 9c 24 90 00 00 00      	movq	%r11, 0x90(%rsp)
 1158a68: e8 53 f0 f2 ff               	callq	0x1087ac0 <_runtime.morestack_noctxt.abi0>
 1158a6d: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
 1158a72: 48 8b 5c 24 58               	movq	0x58(%rsp), %rbx
 1158a77: 48 8b 4c 24 60               	movq	0x60(%rsp), %rcx
 1158a7c: 48 8b 7c 24 68               	movq	0x68(%rsp), %rdi
 1158a81: 48 8b 74 24 70               	movq	0x70(%rsp), %rsi
 1158a86: 4c 8b 44 24 78               	movq	0x78(%rsp), %r8
 1158a8b: 4c 8b 8c 24 80 00 00 00      	movq	0x80(%rsp), %r9
 1158a93: 4c 8b 94 24 88 00 00 00      	movq	0x88(%rsp), %r10
 1158a9b: 4c 8b 9c 24 90 00 00 00      	movq	0x90(%rsp), %r11
 1158aa3: e9 78 f6 ff ff               	jmp	0x1158120 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD>
 1158aa8: cc                           	int3
 1158aa9: cc                           	int3
 1158aaa: cc                           	int3
 1158aab: cc                           	int3
 1158aac: cc                           	int3
 1158aad: cc                           	int3
 1158aae: cc                           	int3
 1158aaf: cc                           	int3
 1158ab0: cc                           	int3
 1158ab1: cc                           	int3
 1158ab2: cc                           	int3
 1158ab3: cc                           	int3
 1158ab4: cc                           	int3
 1158ab5: cc                           	int3
 1158ab6: cc                           	int3
 1158ab7: cc                           	int3
 1158ab8: cc                           	int3
 1158ab9: cc                           	int3
 1158aba: cc                           	int3
 1158abb: cc                           	int3
 1158abc: cc                           	int3
 1158abd: cc                           	int3
 1158abe: cc                           	int3
 1158abf: cc                           	int3

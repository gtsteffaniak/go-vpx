
/private/tmp/govpx-fp32-avx512-48/validation/candidate-darwin.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

0000000001157e40 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512>:
 1157e40: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
 1157e45: 48 89 7c 24 68               	movq	%rdi, 0x68(%rsp)
 1157e4a: 4c 89 8c 24 80 00 00 00      	movq	%r9, 0x80(%rsp)
 1157e52: 90                           	nop
 1157e53: 62 f1 fd 48 ef c0            	vpxorq	%zmm0, %zmm0, %zmm0
 1157e59: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
 1157e5e: 66 90                        	nop
 1157e60: 48 85 c9                     	testq	%rcx, %rcx
 1157e63: 74 0a                        	je	0x1157e6f <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x2f>
 1157e65: 62 f1 fe 48 6f 05 31 b0 21 00	vmovdqu64	0x21b031(%rip), %zmm0 ## 0x1372ea0 <_github.com/thesyncim/govpx/internal/pixel.fpClassWordLUT32>
 1157e6f: 62 f1 f5 48 ef c9            	vpxorq	%zmm1, %zmm1, %zmm1
 1157e75: 0f b7 54 24 2a               	movzwl	0x2a(%rsp), %edx
 1157e7a: 0f b7 5c 24 28               	movzwl	0x28(%rsp), %ebx
 1157e7f: 0f b7 74 24 2e               	movzwl	0x2e(%rsp), %esi
 1157e84: 44 0f b7 44 24 2c            	movzwl	0x2c(%rsp), %r8d
 1157e8a: 44 0f b7 54 24 32            	movzwl	0x32(%rsp), %r10d
 1157e90: 44 0f b7 5c 24 30            	movzwl	0x30(%rsp), %r11d
 1157e96: 62 f1 fe 48 6f 10            	vmovdqu64	(%rax), %zmm2
 1157e9c: 62 f2 7d 48 1d da            	vpabsw	%zmm2, %zmm3
 1157ea2: 62 f3 ed 48 3f c9 01         	vpcmpltw	%zmm1, %zmm2, %k1
 1157ea9: 41 bc ff 7f 00 00            	movl	$0x7fff, %r12d          ## imm = 0x7FFF
 1157eaf: c4 c1 f9 6e d4               	vmovq	%r12, %xmm2
 1157eb4: 62 f2 7d 48 79 d2            	vpbroadcastw	%xmm2, %zmm2
 1157eba: c5 81 c4 e2 00               	vpinsrw	$0x0, %edx, %xmm15, %xmm4
 1157ebf: 62 f2 7d 48 79 ec            	vpbroadcastw	%xmm4, %zmm5
 1157ec5: c4 e2 7d 79 f4               	vpbroadcastw	%xmm4, %ymm6
 1157eca: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
 1157ecf: c5 d9 c4 e3 00               	vpinsrw	$0x0, %ebx, %xmm4, %xmm4
 1157ed4: c4 e3 4d 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm6, %ymm4
 1157eda: 62 f3 d5 48 3a e4 00         	vinserti64x4	$0x0, %ymm4, %zmm5, %zmm4
 1157ee1: 62 f1 5d 48 fd db            	vpaddw	%zmm3, %zmm4, %zmm3
 1157ee7: 62 f2 65 48 3a da            	vpminuw	%zmm2, %zmm3, %zmm3
 1157eed: c5 81 c4 e6 00               	vpinsrw	$0x0, %esi, %xmm15, %xmm4
 1157ef2: 62 f2 7d 48 79 ec            	vpbroadcastw	%xmm4, %zmm5
 1157ef8: c4 e2 7d 79 f4               	vpbroadcastw	%xmm4, %ymm6
 1157efd: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
 1157f02: c4 c1 59 c4 e0 00            	vpinsrw	$0x0, %r8d, %xmm4, %xmm4
 1157f08: c4 e3 4d 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm6, %ymm4
 1157f0e: 62 f3 d5 48 3a e4 00         	vinserti64x4	$0x0, %ymm4, %zmm5, %zmm4
 1157f15: c4 c1 01 c4 ea 00            	vpinsrw	$0x0, %r10d, %xmm15, %xmm5
 1157f1b: 62 f2 7d 48 79 f5            	vpbroadcastw	%xmm5, %zmm6
 1157f21: c4 e2 7d 79 fd               	vpbroadcastw	%xmm5, %ymm7
 1157f26: c4 e2 79 79 ed               	vpbroadcastw	%xmm5, %xmm5
 1157f2b: c4 c1 51 c4 eb 00            	vpinsrw	$0x0, %r11d, %xmm5, %xmm5
 1157f31: c4 e3 45 38 ed 00            	vinserti128	$0x0, %xmm5, %ymm7, %ymm5
 1157f37: 62 f3 cd 48 3a ed 00         	vinserti64x4	$0x0, %ymm5, %zmm6, %zmm5
 1157f3e: 62 f3 e5 48 3f d5 0d         	vpcmpw	$0xd, %zmm5, %zmm3, %k2
 1157f45: 62 f1 5d ca e5 db            	vpmulhw	%zmm3, %zmm4, %zmm3 {%k2} {z}
 1157f4b: 90                           	nop
 1157f4c: 62 f1 fe 48 7f dc            	vmovdqu64	%zmm3, %zmm4
 1157f52: 62 f1 75 49 f9 db            	vpsubw	%zmm3, %zmm1, %zmm3 {%k1}
 1157f58: 4d 85 c9                     	testq	%r9, %r9
 1157f5b: 74 0b                        	je	0x1157f68 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x128>
 1157f5d: 62 d1 fe 48 7f 19            	vmovdqu64	%zmm3, (%r9)
 1157f63: 48 85 c9                     	testq	%rcx, %rcx
 1157f66: eb 03                        	jmp	0x1157f6b <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x12b>
 1157f68: 48 85 c9                     	testq	%rcx, %rcx
 1157f6b: 62 f1 55 48 d5 eb            	vpmullw	%zmm3, %zmm5, %zmm5
 1157f71: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
 1157f76: 62 f1 fe 48 7f 2a            	vmovdqu64	%zmm5, (%rdx)
 1157f7c: 62 f1 fe 48 6f 2f            	vmovdqu64	(%rdi), %zmm5
 1157f82: 62 f3 e5 48 3f c9 04         	vpcmpneqw	%zmm1, %zmm3, %k1
 1157f89: bb 0b 00 00 00               	movl	$0xb, %ebx
 1157f8e: c4 e1 f9 6e db               	vmovq	%rbx, %xmm3
 1157f93: 62 f1 ff c9 7f ed            	vmovdqu16	%zmm5, %zmm5 {%k1} {z}
 1157f99: 62 f1 75 48 ee ed            	vpmaxsw	%zmm5, %zmm1, %zmm5
 1157f9f: 62 f2 7d 48 79 db            	vpbroadcastw	%xmm3, %zmm3
 1157fa5: 74 16                        	je	0x1157fbd <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x17d>
 1157fa7: 62 f1 5d 48 ea e3            	vpminsw	%zmm3, %zmm4, %zmm4
 1157fad: 62 f2 dd 48 8d e0            	vpermw	%zmm0, %zmm4, %zmm4
 1157fb3: 62 f2 7e 48 30 e4            	vpmovwb	%zmm4, %ymm4
 1157fb9: c5 fe 7f 21                  	vmovdqu	%ymm4, (%rcx)
 1157fbd: 0f b7 5c 24 2a               	movzwl	0x2a(%rsp), %ebx
 1157fc2: 0f b7 74 24 2e               	movzwl	0x2e(%rsp), %esi
 1157fc7: 44 0f b7 44 24 32            	movzwl	0x32(%rsp), %r8d
 1157fcd: c4 e1 f9 6e e3               	vmovq	%rbx, %xmm4
 1157fd2: c4 e1 f9 6e f6               	vmovq	%rsi, %xmm6
 1157fd7: c4 c1 f9 6e f8               	vmovq	%r8, %xmm7
 1157fdc: 62 f2 7d 48 79 e4            	vpbroadcastw	%xmm4, %zmm4
 1157fe2: 62 f2 7d 48 79 f6            	vpbroadcastw	%xmm6, %zmm6
 1157fe8: 62 f2 7d 48 79 ff            	vpbroadcastw	%xmm7, %zmm7
 1157fee: bb 20 00 00 00               	movl	$0x20, %ebx
 1157ff3: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
 1157ff8: eb 06                        	jmp	0x1158000 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1c0>
 1157ffa: 48 83 c3 20                  	addq	$0x20, %rbx
 1157ffe: 66 90                        	nop
 1158000: 48 39 de                     	cmpq	%rbx, %rsi
 1158003: 0f 8e a6 00 00 00            	jle	0x11580af <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x26f>
 1158009: 4c 8d 04 58                  	leaq	(%rax,%rbx,2), %r8
 115800d: 62 51 fe 48 6f 00            	vmovdqu64	(%r8), %zmm8
 1158013: 62 52 7d 48 1d c8            	vpabsw	%zmm8, %zmm9
 1158019: 62 71 35 48 fd cc            	vpaddw	%zmm4, %zmm9, %zmm9
 115801f: 62 72 35 48 3a ca            	vpminuw	%zmm2, %zmm9, %zmm9
 1158025: 62 f3 b5 48 3f cf 0d         	vpcmpw	$0xd, %zmm7, %zmm9, %k1
 115802c: 62 f3 bd 48 3f d1 01         	vpcmpltw	%zmm1, %zmm8, %k2
 1158033: 62 51 4d c9 e5 c1            	vpmulhw	%zmm9, %zmm6, %zmm8 {%k1} {z}
 1158039: 62 51 fe 48 7f c1            	vmovdqu64	%zmm8, %zmm9
 115803f: 62 51 75 4a f9 c0            	vpsubw	%zmm8, %zmm1, %zmm8 {%k2}
 1158045: 4d 85 c9                     	testq	%r9, %r9
 1158048: 74 0f                        	je	0x1158059 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x219>
 115804a: 4d 8d 04 59                  	leaq	(%r9,%rbx,2), %r8
 115804e: 62 51 fe 48 7f 00            	vmovdqu64	%zmm8, (%r8)
 1158054: 48 85 c9                     	testq	%rcx, %rcx
 1158057: eb 03                        	jmp	0x115805c <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x21c>
 1158059: 48 85 c9                     	testq	%rcx, %rcx
 115805c: 62 51 45 48 d5 d0            	vpmullw	%zmm8, %zmm7, %zmm10
 1158062: 4c 8d 04 5a                  	leaq	(%rdx,%rbx,2), %r8
 1158066: 62 51 fe 48 7f 10            	vmovdqu64	%zmm10, (%r8)
 115806c: 4c 8d 04 5f                  	leaq	(%rdi,%rbx,2), %r8
 1158070: 62 51 fe 48 6f 10            	vmovdqu64	(%r8), %zmm10
 1158076: 62 f3 bd 48 3f c9 04         	vpcmpneqw	%zmm1, %zmm8, %k1
 115807d: 62 51 ff c9 7f d0            	vmovdqu16	%zmm10, %zmm8 {%k1} {z}
 1158083: 62 d1 55 48 ee e8            	vpmaxsw	%zmm8, %zmm5, %zmm5
 1158089: 0f 84 6b ff ff ff            	je	0x1157ffa <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1ba>
 115808f: 62 71 35 48 ea c3            	vpminsw	%zmm3, %zmm9, %zmm8
 1158095: 62 72 bd 48 8d c0            	vpermw	%zmm0, %zmm8, %zmm8
 115809b: 62 52 7e 48 30 c0            	vpmovwb	%zmm8, %ymm8
 11580a1: 4c 8d 04 19                  	leaq	(%rcx,%rbx), %r8
 11580a5: c4 41 7e 7f 00               	vmovdqu	%ymm8, (%r8)
 11580aa: e9 4b ff ff ff               	jmp	0x1157ffa <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1ba>
 11580af: 62 f3 fd 48 3b e8 00         	vextracti64x4	$0x0, %zmm5, %ymm0
 11580b6: 62 f3 fd 48 3b e9 01         	vextracti64x4	$0x1, %zmm5, %ymm1
 11580bd: c5 fd ee c1                  	vpmaxsw	%ymm1, %ymm0, %ymm0
 11580c1: c4 e3 7d 39 c1 00            	vextracti128	$0x0, %ymm0, %xmm1
 11580c7: c4 e3 7d 39 c0 01            	vextracti128	$0x1, %ymm0, %xmm0
 11580cd: c5 f1 ee c0                  	vpmaxsw	%xmm0, %xmm1, %xmm0
 11580d1: c4 e2 79 23 c8               	vpmovsxwd	%xmm0, %xmm1
 11580d6: c5 f9 70 c0 4e               	vpshufd	$0x4e, %xmm0, %xmm0     ## xmm0 = xmm0[2,3,0,1]
 11580db: c4 e2 79 23 c0               	vpmovsxwd	%xmm0, %xmm0
 11580e0: c4 e2 79 3d c1               	vpmaxsd	%xmm1, %xmm0, %xmm0
 11580e5: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     ## xmm1 = xmm0[2,3,0,1]
 11580ea: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
 11580ef: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     ## xmm1 = xmm0[1,0,3,2]
 11580f4: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
 11580f9: c4 e3 79 16 c1 00            	vpextrd	$0x0, %xmm0, %ecx
 11580ff: 48 63 c1                     	movslq	%ecx, %rax
 1158102: c5 f8 77                     	vzeroupper
 1158105: c3                           	retq
 1158106: cc                           	int3
 1158107: cc                           	int3
 1158108: cc                           	int3
 1158109: cc                           	int3
 115810a: cc                           	int3
 115810b: cc                           	int3
 115810c: cc                           	int3
 115810d: cc                           	int3
 115810e: cc                           	int3
 115810f: cc                           	int3
 1158110: cc                           	int3
 1158111: cc                           	int3
 1158112: cc                           	int3
 1158113: cc                           	int3
 1158114: cc                           	int3
 1158115: cc                           	int3
 1158116: cc                           	int3
 1158117: cc                           	int3
 1158118: cc                           	int3
 1158119: cc                           	int3
 115811a: cc                           	int3
 115811b: cc                           	int3
 115811c: cc                           	int3
 115811d: cc                           	int3
 115811e: cc                           	int3
 115811f: cc                           	int3

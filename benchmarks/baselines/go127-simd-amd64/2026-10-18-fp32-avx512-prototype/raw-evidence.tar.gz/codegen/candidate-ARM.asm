
/private/tmp/govpx-fp32-avx512-48/validation/candidate-arm.test:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001001387f0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD>:
1001387f0: f9400b90    	ldr	x16, [x28, #0x10]
1001387f4: d100c3f1    	sub	x17, sp, #0x30
1001387f8: eb10023f    	cmp	x17, x16
1001387fc: 54001649    	b.ls	0x100138ac4 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2d4>
100138800: f8150ffe    	str	x30, [sp, #-0xb0]!
100138804: f81f83fd    	stur	x29, [sp, #-0x8]
100138808: d10023fd    	sub	x29, sp, #0x8
10013880c: f90067e0    	str	x0, [sp, #0xc8]
100138810: f90073e3    	str	x3, [sp, #0xe0]
100138814: f9007fe6    	str	x6, [sp, #0xf8]
100138818: f9008be9    	str	x9, [sp, #0x110]
10013881c: f9009bed    	str	x13, [sp, #0x130]
100138820: 798177f0    	ldrsh	x16, [sp, #0xba]
100138824: 79817ff1    	ldrsh	x17, [sp, #0xbe]
100138828: 798187f3    	ldrsh	x19, [sp, #0xc2]
10013882c: 798173f4    	ldrsh	x20, [sp, #0xb8]
100138830: 79817bf5    	ldrsh	x21, [sp, #0xbc]
100138834: 798183f6    	ldrsh	x22, [sp, #0xc0]
100138838: 4f00e400    	movi.16b	v0, #0x0
10013883c: 4ea01c01    	mov.16b	v1, v0
100138840: 4e021e00    	mov.h	v0[0], w16
100138844: 4e020400    	dup.8h	v0, v0[0]
100138848: 4ea11c22    	mov.16b	v2, v1
10013884c: 4e021e21    	mov.h	v1[0], w17
100138850: 4e020421    	dup.8h	v1, v1[0]
100138854: 4ea21c43    	mov.16b	v3, v2
100138858: 4e021e62    	mov.h	v2[0], w19
10013885c: 4e020442    	dup.8h	v2, v2[0]
100138860: 4f00e404    	movi.16b	v4, #0x0
100138864: d28ffff0    	mov	x16, #0x7fff            ; =32767
100138868: 4e021e04    	mov.h	v4[0], w16
10013886c: 4ea01c05    	mov.16b	v5, v0
100138870: 4e021e80    	mov.h	v0[0], w20
100138874: 4ea11c26    	mov.16b	v6, v1
100138878: 4e021ea1    	mov.h	v1[0], w21
10013887c: 4ea21c47    	mov.16b	v7, v2
100138880: 4e021ec2    	mov.h	v2[0], w22
100138884: d503201f    	nop
100138888: 90000f3b    	adrp	x27, 0x10031c000 <_go:buildinfo>
10013888c: 9125837b    	add	x27, x27, #0x960
100138890: 3dc00368    	ldr	q8, [x27]
100138894: 4e020484    	dup.8h	v4, v4[0]
100138898: aa1f03f0    	mov	x16, xzr
10013889c: 4ea31c69    	mov.16b	v9, v3
1001388a0: 14000007    	b	0x1001388bc <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0xcc>
1001388a4: 4eac1d80    	mov.16b	v0, v12
1001388a8: 4ea21c49    	mov.16b	v9, v2
1001388ac: aa1103f0    	mov	x16, x17
1001388b0: 4ea11c23    	mov.16b	v3, v1
1001388b4: 4eab1d61    	mov.16b	v1, v11
1001388b8: 4eaa1d42    	mov.16b	v2, v10
1001388bc: 91002211    	add	x17, x16, #0x8
1001388c0: eb11019f    	cmp	x12, x17
1001388c4: 54000acb    	b.lt	0x100138a1c <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x22c>
1001388c8: b50000b0    	cbnz	x16, 0x1001388dc <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0xec>
1001388cc: 4ea21c4a    	mov.16b	v10, v2
1001388d0: 4ea11c2b    	mov.16b	v11, v1
1001388d4: 4ea01c0c    	mov.16b	v12, v0
1001388d8: 14000007    	b	0x1001388f4 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x104>
1001388dc: 4ea21c4a    	mov.16b	v10, v2
1001388e0: 4ea11c2b    	mov.16b	v11, v1
1001388e4: 4ea01c0c    	mov.16b	v12, v0
1001388e8: 4ea71ce2    	mov.16b	v2, v7
1001388ec: 4ea61cc1    	mov.16b	v1, v6
1001388f0: 4ea51ca0    	mov.16b	v0, v5
1001388f4: eb10003f    	cmp	x1, x16
1001388f8: 54000e03    	b.lo	0x100138ab8 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2c8>
1001388fc: cb020213    	sub	x19, x16, x2
100138900: 8a93fe13    	and	x19, x16, x19, asr #63
100138904: cb100034    	sub	x20, x1, x16
100138908: 8b130413    	add	x19, x0, x19, lsl #1
10013890c: f100229f    	cmp	x20, #0x8
100138910: 54000d03    	b.lo	0x100138ab0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2c0>
100138914: 3dc0026d    	ldr	q13, [x19]
100138918: 4e60b9ae    	abs.8h	v14, v13
10013891c: 4e6085c0    	add.8h	v0, v14, v0
100138920: 6e646c00    	umin.8h	v0, v0, v4
100138924: 4e623c0e    	cmge.8h	v14, v0, v2
100138928: 0e61c00f    	smull.4s	v15, v0, v1
10013892c: 4e61c000    	smull2.4s	v0, v0, v1
100138930: 4e4059e0    	uzp2.8h	v0, v15, v0
100138934: 4e201dc0    	and.16b	v0, v14, v0
100138938: 6e608521    	sub.8h	v1, v9, v0
10013893c: 4e6d352d    	cmgt.8h	v13, v9, v13
100138940: 6eed1c01    	bif.16b	v1, v0, v13
100138944: b4000146    	cbz	x6, 0x10013896c <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x17c>
100138948: eb1000ff    	cmp	x7, x16
10013894c: 54000ae3    	b.lo	0x100138aa8 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2b8>
100138950: cb1000f3    	sub	x19, x7, x16
100138954: cb080214    	sub	x20, x16, x8
100138958: 8a94fe14    	and	x20, x16, x20, asr #63
10013895c: 8b1404d4    	add	x20, x6, x20, lsl #1
100138960: f100227f    	cmp	x19, #0x8
100138964: 540009e3    	b.lo	0x100138aa0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2b0>
100138968: 3d800281    	str	q1, [x20]
10013896c: 4e629c22    	mul.8h	v2, v1, v2
100138970: eb10015f    	cmp	x10, x16
100138974: 54000923    	b.lo	0x100138a98 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2a8>
100138978: cb100153    	sub	x19, x10, x16
10013897c: cb0b0214    	sub	x20, x16, x11
100138980: 8a94fe14    	and	x20, x16, x20, asr #63
100138984: 8b140534    	add	x20, x9, x20, lsl #1
100138988: f100227f    	cmp	x19, #0x8
10013898c: 54000823    	b.lo	0x100138a90 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x2a0>
100138990: 3d800282    	str	q2, [x20]
100138994: eb10009f    	cmp	x4, x16
100138998: 54000783    	b.lo	0x100138a88 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x298>
10013899c: cb100093    	sub	x19, x4, x16
1001389a0: cb050214    	sub	x20, x16, x5
1001389a4: 8a94fe14    	and	x20, x16, x20, asr #63
1001389a8: 8b140474    	add	x20, x3, x20, lsl #1
1001389ac: f100227f    	cmp	x19, #0x8
1001389b0: 54000683    	b.lo	0x100138a80 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x290>
1001389b4: 3dc00282    	ldr	q2, [x20]
1001389b8: 6e698c21    	cmeq.8h	v1, v1, v9
1001389bc: 6e205821    	mvn.16b	v1, v1
1001389c0: 4e221c21    	and.16b	v1, v1, v2
1001389c4: 4e616461    	smax.8h	v1, v3, v1
1001389c8: b400024d    	cbz	x13, 0x100138a10 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x220>
1001389cc: d2800173    	mov	x19, #0xb               ; =11
1001389d0: 4ea91d22    	mov.16b	v2, v9
1001389d4: 4e021e69    	mov.h	v9[0], w19
1001389d8: 4e020523    	dup.8h	v3, v9[0]
1001389dc: 4e636c00    	smin.8h	v0, v0, v3
1001389e0: eb1001df    	cmp	x14, x16
1001389e4: 540004a3    	b.lo	0x100138a78 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x288>
1001389e8: cb1001d4    	sub	x20, x14, x16
1001389ec: cb0f0215    	sub	x21, x16, x15
1001389f0: 2e212800    	sqxtun.8b	v0, v0
1001389f4: 8a95fe10    	and	x16, x16, x21, asr #63
1001389f8: 4e000100    	tbl.16b	v0, { v8 }, v0
1001389fc: f1001e9f    	cmp	x20, #0x7
100138a00: 54000389    	b.ls	0x100138a70 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0x280>
100138a04: 4e083c14    	mov.d	x20, v0[0]
100138a08: f83069b4    	str	x20, [x13, x16]
100138a0c: 17ffffa6    	b	0x1001388a4 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0xb4>
100138a10: d2800173    	mov	x19, #0xb               ; =11
100138a14: 4ea91d22    	mov.16b	v2, v9
100138a18: 17ffffa3    	b	0x1001388a4 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD+0xb4>
100138a1c: b940bbf1    	ldr	w17, [sp, #0xb8]
100138a20: 4e70a860    	smaxv.8h	h0, v3
100138a24: 0e023c13    	umov.h	w19, v0[0]
100138a28: 93403e73    	sxth	x19, w19
100138a2c: f90053f3    	str	x19, [sp, #0xa0]
100138a30: b9000bf1    	str	w17, [sp, #0x8]
100138a34: b940bff1    	ldr	w17, [sp, #0xbc]
100138a38: b9000ff1    	str	w17, [sp, #0xc]
100138a3c: b940c3f1    	ldr	w17, [sp, #0xc0]
100138a40: b90013f1    	str	w17, [sp, #0x10]
100138a44: a901bbed    	stp	x13, x14, [sp, #0x18]
100138a48: f90017ef    	str	x15, [sp, #0x28]
100138a4c: aa0c03ed    	mov	x13, x12
100138a50: aa1003ec    	mov	x12, x16
100138a54: 97fffef7    	bl	0x100138630 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockTail>
100138a58: f94053ee    	ldr	x14, [sp, #0xa0]
100138a5c: eb0e001f    	cmp	x0, x14
100138a60: 9a8ec000    	csel	x0, x0, x14, gt
100138a64: f85f83fd    	ldur	x29, [sp, #-0x8]
100138a68: f84b07fe    	ldr	x30, [sp], #0xb0
100138a6c: d65f03c0    	ret
100138a70: aa1403e0    	mov	x0, x20
100138a74: 97fd2bbf    	bl	0x100083970 <_runtime.panicBounds>
100138a78: aa1003e0    	mov	x0, x16
100138a7c: 97fd2bbd    	bl	0x100083970 <_runtime.panicBounds>
100138a80: aa1303e0    	mov	x0, x19
100138a84: 97fd2bbb    	bl	0x100083970 <_runtime.panicBounds>
100138a88: aa1003e0    	mov	x0, x16
100138a8c: 97fd2bb9    	bl	0x100083970 <_runtime.panicBounds>
100138a90: aa1303e0    	mov	x0, x19
100138a94: 97fd2bb7    	bl	0x100083970 <_runtime.panicBounds>
100138a98: aa1003e0    	mov	x0, x16
100138a9c: 97fd2bb5    	bl	0x100083970 <_runtime.panicBounds>
100138aa0: aa1303e0    	mov	x0, x19
100138aa4: 97fd2bb3    	bl	0x100083970 <_runtime.panicBounds>
100138aa8: aa1003e0    	mov	x0, x16
100138aac: 97fd2bb1    	bl	0x100083970 <_runtime.panicBounds>
100138ab0: aa1403e0    	mov	x0, x20
100138ab4: 97fd2baf    	bl	0x100083970 <_runtime.panicBounds>
100138ab8: aa1003e0    	mov	x0, x16
100138abc: 97fd2bad    	bl	0x100083970 <_runtime.panicBounds>
100138ac0: d503201f    	nop
100138ac4: a90187e0    	stp	x0, x1, [sp, #0x18]
100138ac8: a9028fe2    	stp	x2, x3, [sp, #0x28]
100138acc: a90397e4    	stp	x4, x5, [sp, #0x38]
100138ad0: a9049fe6    	stp	x6, x7, [sp, #0x48]
100138ad4: a905a7e8    	stp	x8, x9, [sp, #0x58]
100138ad8: a906afea    	stp	x10, x11, [sp, #0x68]
100138adc: a907b7ec    	stp	x12, x13, [sp, #0x78]
100138ae0: a908bfee    	stp	x14, x15, [sp, #0x88]
100138ae4: aa1e03e3    	mov	x3, x30
100138ae8: 97fd235e    	bl	0x100081860 <_runtime.morestack_noctxt.abi0>
100138aec: a94187e0    	ldp	x0, x1, [sp, #0x18]
100138af0: a9428fe2    	ldp	x2, x3, [sp, #0x28]
100138af4: a94397e4    	ldp	x4, x5, [sp, #0x38]
100138af8: a9449fe6    	ldp	x6, x7, [sp, #0x48]
100138afc: a945a7e8    	ldp	x8, x9, [sp, #0x58]
100138b00: a946afea    	ldp	x10, x11, [sp, #0x68]
100138b04: a947b7ec    	ldp	x12, x13, [sp, #0x78]
100138b08: a948bfee    	ldp	x14, x15, [sp, #0x88]
100138b0c: 17ffff39    	b	0x1001387f0 <_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD>

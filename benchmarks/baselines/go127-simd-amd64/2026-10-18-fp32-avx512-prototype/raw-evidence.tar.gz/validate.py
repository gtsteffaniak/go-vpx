from pathlib import Path
import os,subprocess,json,hashlib
b=Path('/private/tmp/govpx-fp32-avx512-48');out=b/'validation';out.mkdir(exist_ok=True);root=Path('/Users/thesyncim/GolandProjects/govpx');env=os.environ.copy();env.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-fp32',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',GOOS='darwin',GOARCH='amd64',CGO_ENABLED='0');records=[]
def go(name,v,args,extra=None):
 e=env.copy();e.update(extra or {});cmd=[str(root/'scripts/go.sh'),'-C',str(b/v)]+args;records.append(dict(name=name,argv=cmd,extra=extra));(out/'commands.json').write_text(json.dumps(records,indent=2))
 with(out/(name+'.log')).open('w')as f:r=subprocess.run(cmd,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,name
 print(name+'PASS',flush=True)
def run(name,binary,args,extra):
 e=env.copy();e.update(ROSETTA_ADVERTISE_AVX='1',GOVPX_REQUIRE_SIMD='1',GOMAXPROCS='1',GODEBUG='');e.update(extra);cmd=['arch','-x86_64',str(binary)]+args;records.append(dict(name=name,argv=cmd,extra=extra));(out/'commands.json').write_text(json.dumps(records,indent=2))
 with(out/(name+'.log')).open('w')as f:r=subprocess.run(cmd,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,name
 if args[0].startswith('-test.run=^Test(FP16|FP32)'):
  log=(out/(name+'.log')).read_text()
  for required in ['TestFP32EligibleExactWindows','TestFP32EligibleAliasedDeclines','TestFP32EligiblePanicWindows']:
   assert '--- PASS: '+required+' ' in log,(name,required)
 print(name+'PASS',flush=True)
regex='^Test(FP16|FP32)'
for checked in [False,True]:
 binary=out/('pixel-checked.test'if checked else'pixel.test');flags=['-gcflags=all=-d=checkptr=2']if checked else[]
 go('build-pixel-'+str(checked),'candidate',['test','-c','-pgo=off']+flags+['-o',str(binary),'./internal/pixel'])
 run('selected-'+str(checked),binary,['-test.run='+regex,'-test.v'],{'GOVPX_REQUIRE_FP32_OFF':'1'})
 run('avx512-off-avx2-'+str(checked),binary,['-test.run='+regex,'-test.v'],{'GOVPX_REQUIRE_FP32_OFF':'1','GODEBUG':'cpu.avx512f=off'})
 run('all-avx-off-'+str(checked),binary,['-test.run='+regex,'-test.v'],{'GOVPX_REQUIRE_SIMD':'0','GOVPX_REQUIRE_FP16_AVX_OFF':'1','GOVPX_REQUIRE_FP32_OFF':'1','GODEBUG':'cpu.avx=off,cpu.avx2=off'})
for v in ['parent','candidate']:
 for target in ['linux','darwin']:
  go(v+'-'+target+'-codegen',v,['test','-pgo=off','-c','-o',str(out/(v+'-'+target+'.test')),'./internal/pixel'],{'GOOS':target})
 go(v+'-ARM-codegen',v,['test','-pgo=off','-c','-o',str(out/(v+'-arm.test')),'./internal/pixel'],{'GOARCH':'arm64','CGO_ENABLED':'1'})
for tags,exp in [('purego','simd'),('','')]:
 go('fallback-build-'+(tags or'nosimd'),'candidate',['test','-pgo=off','-c']+(['-tags='+tags]if tags else[])+['-o',str(out/((tags or'nosimd')+'.test')),'./internal/pixel'],{'GOEXPERIMENT':exp})
# Existing public encoder fixtures also compile and run selected/off with fresh source.
go('public-build','candidate',['test','-c','-pgo=off','-o',str(out/'encoder.test'),'./internal/vp9/encoder'])
for off in [False,True]:
 run('public36-oneshot-'+str(off),out/'encoder.test',['-test.run=^$','-test.bench=^BenchmarkVP9FP16Native$','-test.benchtime=1x','-test.count=1','-test.cpu=1','-test.benchmem'],{'GODEBUG':'cpu.avx=off,cpu.avx2=off'if off else'','GOVPX_REQUIRE_SIMD':'0'if off else'1'})
(out/'binary-receipts.json').write_text(json.dumps({str(p):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size}for p in sorted(out.glob('*.test'))},indent=2));print('ALL PASS; no512selectedexecuted, nativeCIrequired',flush=True)

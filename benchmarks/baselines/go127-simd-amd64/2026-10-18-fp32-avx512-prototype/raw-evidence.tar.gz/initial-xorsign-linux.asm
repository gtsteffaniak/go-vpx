
/private/tmp/govpx-fp32-avx512-48/candidate-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000565420 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512>:
  565420: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
  565425: 48 89 7c 24 68               	movq	%rdi, 0x68(%rsp)
  56542a: 4c 89 8c 24 80 00 00 00      	movq	%r9, 0x80(%rsp)
  565432: 90                           	nop
  565433: 62 f1 fd 48 ef c0            	vpxorq	%zmm0, %zmm0, %zmm0
  565439: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
  56543e: 66 90                        	nop
  565440: 48 85 c9                     	testq	%rcx, %rcx
  565443: 74 0a                        	je	0x56544f <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x2f>
  565445: 62 f1 fe 48 6f 05 b1 3a 22 00	vmovdqu64	0x223ab1(%rip), %zmm0 # 0x788f00 <github.com/thesyncim/govpx/internal/pixel.fpClassWordLUT32>
  56544f: 0f b7 54 24 2a               	movzwl	0x2a(%rsp), %edx
  565454: 0f b7 5c 24 28               	movzwl	0x28(%rsp), %ebx
  565459: 0f b7 74 24 2e               	movzwl	0x2e(%rsp), %esi
  56545e: 44 0f b7 44 24 2c            	movzwl	0x2c(%rsp), %r8d
  565464: 44 0f b7 54 24 32            	movzwl	0x32(%rsp), %r10d
  56546a: 44 0f b7 5c 24 30            	movzwl	0x30(%rsp), %r11d
  565470: 62 f1 fe 48 6f 08            	vmovdqu64	(%rax), %zmm1
  565476: 62 f2 7d 48 1d d1            	vpabsw	%zmm1, %zmm2
  56547c: 62 f1 75 48 71 e1 0f         	vpsraw	$0xf, %zmm1, %zmm1
  565483: 41 bc ff 7f 00 00            	movl	$0x7fff, %r12d          # imm = 0x7FFF
  565489: c4 c1 f9 6e dc               	vmovq	%r12, %xmm3
  56548e: 62 f2 7d 48 79 db            	vpbroadcastw	%xmm3, %zmm3
  565494: c5 81 c4 e2 00               	vpinsrw	$0x0, %edx, %xmm15, %xmm4
  565499: 62 f2 7d 48 79 ec            	vpbroadcastw	%xmm4, %zmm5
  56549f: c4 e2 7d 79 f4               	vpbroadcastw	%xmm4, %ymm6
  5654a4: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
  5654a9: c5 d9 c4 e3 00               	vpinsrw	$0x0, %ebx, %xmm4, %xmm4
  5654ae: c4 e3 4d 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm6, %ymm4
  5654b4: 62 f3 d5 48 3a e4 00         	vinserti64x4	$0x0, %ymm4, %zmm5, %zmm4
  5654bb: 62 f1 5d 48 fd d2            	vpaddw	%zmm2, %zmm4, %zmm2
  5654c1: 62 f2 6d 48 3a d3            	vpminuw	%zmm3, %zmm2, %zmm2
  5654c7: c5 81 c4 e6 00               	vpinsrw	$0x0, %esi, %xmm15, %xmm4
  5654cc: 62 f2 7d 48 79 ec            	vpbroadcastw	%xmm4, %zmm5
  5654d2: c4 e2 7d 79 f4               	vpbroadcastw	%xmm4, %ymm6
  5654d7: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
  5654dc: c4 c1 59 c4 e0 00            	vpinsrw	$0x0, %r8d, %xmm4, %xmm4
  5654e2: c4 e3 4d 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm6, %ymm4
  5654e8: 62 f3 d5 48 3a e4 00         	vinserti64x4	$0x0, %ymm4, %zmm5, %zmm4
  5654ef: 62 f1 5d 48 e5 ea            	vpmulhw	%zmm2, %zmm4, %zmm5
  5654f5: c4 c1 01 c4 f2 00            	vpinsrw	$0x0, %r10d, %xmm15, %xmm6
  5654fb: 62 f2 7d 48 79 fe            	vpbroadcastw	%xmm6, %zmm7
  565501: c4 62 7d 79 c6               	vpbroadcastw	%xmm6, %ymm8
  565506: c4 e2 79 79 f6               	vpbroadcastw	%xmm6, %xmm6
  56550b: c4 c1 49 c4 f3 00            	vpinsrw	$0x0, %r11d, %xmm6, %xmm6
  565511: c4 e3 3d 38 f6 00            	vinserti128	$0x0, %xmm6, %ymm8, %ymm6
  565517: 62 f3 c5 48 3a f6 00         	vinserti64x4	$0x0, %ymm6, %zmm7, %zmm6
  56551e: 62 f3 ed 48 3f ce 0d         	vpcmpw	$0xd, %zmm6, %zmm2, %k1
  565525: 62 f2 fe 48 28 f9            	vpmovm2w	%k1, %zmm7
  56552b: 62 d1 fe 48 7f c8            	vmovdqu64	%zmm1, %zmm8
  565531: 62 f3 45 48 25 cd 78         	vpternlogd	$0x78, %zmm5, %zmm7, %zmm1 # zmm1 = zmm1 ^ (zmm7 & zmm5)
  565538: 90                           	nop
  565539: 62 d1 75 48 f9 c8            	vpsubw	%zmm8, %zmm1, %zmm1
  56553f: 62 f1 5d c9 e5 d2            	vpmulhw	%zmm2, %zmm4, %zmm2 {%k1} {z}
  565545: 4d 85 c9                     	testq	%r9, %r9
  565548: 74 0b                        	je	0x565555 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x135>
  56554a: 62 d1 fe 48 7f 09            	vmovdqu64	%zmm1, (%r9)
  565550: 48 85 c9                     	testq	%rcx, %rcx
  565553: eb 03                        	jmp	0x565558 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x138>
  565555: 48 85 c9                     	testq	%rcx, %rcx
  565558: 62 f1 dd 48 ef e4            	vpxorq	%zmm4, %zmm4, %zmm4
  56555e: 62 f1 4d 48 d5 e9            	vpmullw	%zmm1, %zmm6, %zmm5
  565564: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
  565569: 62 f1 fe 48 7f 2a            	vmovdqu64	%zmm5, (%rdx)
  56556f: 62 f1 fe 48 6f 2f            	vmovdqu64	(%rdi), %zmm5
  565575: 62 f3 f5 48 3f cc 04         	vpcmpneqw	%zmm4, %zmm1, %k1
  56557c: bb 0b 00 00 00               	movl	$0xb, %ebx
  565581: c4 e1 f9 6e cb               	vmovq	%rbx, %xmm1
  565586: 62 f1 ff c9 7f ed            	vmovdqu16	%zmm5, %zmm5 {%k1} {z}
  56558c: 62 f1 5d 48 ee ed            	vpmaxsw	%zmm5, %zmm4, %zmm5
  565592: 62 f2 7d 48 79 c9            	vpbroadcastw	%xmm1, %zmm1
  565598: 74 16                        	je	0x5655b0 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x190>
  56559a: 62 f1 6d 48 ea d1            	vpminsw	%zmm1, %zmm2, %zmm2
  5655a0: 62 f2 ed 48 8d d0            	vpermw	%zmm0, %zmm2, %zmm2
  5655a6: 62 f2 7e 48 30 d2            	vpmovwb	%zmm2, %ymm2
  5655ac: c5 fe 7f 11                  	vmovdqu	%ymm2, (%rcx)
  5655b0: 0f b7 5c 24 2a               	movzwl	0x2a(%rsp), %ebx
  5655b5: 0f b7 74 24 2e               	movzwl	0x2e(%rsp), %esi
  5655ba: 44 0f b7 44 24 32            	movzwl	0x32(%rsp), %r8d
  5655c0: c4 e1 f9 6e d3               	vmovq	%rbx, %xmm2
  5655c5: c4 e1 f9 6e f6               	vmovq	%rsi, %xmm6
  5655ca: c4 c1 f9 6e f8               	vmovq	%r8, %xmm7
  5655cf: 62 f2 7d 48 79 d2            	vpbroadcastw	%xmm2, %zmm2
  5655d5: 62 f2 7d 48 79 f6            	vpbroadcastw	%xmm6, %zmm6
  5655db: 62 f2 7d 48 79 ff            	vpbroadcastw	%xmm7, %zmm7
  5655e1: bb 20 00 00 00               	movl	$0x20, %ebx
  5655e6: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
  5655eb: eb 04                        	jmp	0x5655f1 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1d1>
  5655ed: 48 83 c3 20                  	addq	$0x20, %rbx
  5655f1: 48 39 de                     	cmpq	%rbx, %rsi
  5655f4: 0f 8e b9 00 00 00            	jle	0x5656b3 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x293>
  5655fa: 4c 8d 04 58                  	leaq	(%rax,%rbx,2), %r8
  5655fe: 62 51 fe 48 6f 00            	vmovdqu64	(%r8), %zmm8
  565604: 62 52 7d 48 1d c8            	vpabsw	%zmm8, %zmm9
  56560a: 62 71 35 48 fd ca            	vpaddw	%zmm2, %zmm9, %zmm9
  565610: 62 72 35 48 3a cb            	vpminuw	%zmm3, %zmm9, %zmm9
  565616: 62 51 4d 48 e5 d1            	vpmulhw	%zmm9, %zmm6, %zmm10
  56561c: 62 f3 b5 48 3f cf 0d         	vpcmpw	$0xd, %zmm7, %zmm9, %k1
  565623: 62 72 fe 48 28 d9            	vpmovm2w	%k1, %zmm11
  565629: 62 d1 3d 48 71 e0 0f         	vpsraw	$0xf, %zmm8, %zmm8
  565630: 62 51 fe 48 7f c4            	vmovdqu64	%zmm8, %zmm12
  565636: 62 53 25 48 25 c2 78         	vpternlogd	$0x78, %zmm10, %zmm11, %zmm8 # zmm8 = zmm8 ^ (zmm11 & zmm10)
  56563d: 62 51 3d 48 f9 c4            	vpsubw	%zmm12, %zmm8, %zmm8
  565643: 62 51 4d c9 e5 c9            	vpmulhw	%zmm9, %zmm6, %zmm9 {%k1} {z}
  565649: 4d 85 c9                     	testq	%r9, %r9
  56564c: 74 0f                        	je	0x56565d <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x23d>
  56564e: 4d 8d 04 59                  	leaq	(%r9,%rbx,2), %r8
  565652: 62 51 fe 48 7f 00            	vmovdqu64	%zmm8, (%r8)
  565658: 48 85 c9                     	testq	%rcx, %rcx
  56565b: eb 03                        	jmp	0x565660 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x240>
  56565d: 48 85 c9                     	testq	%rcx, %rcx
  565660: 62 51 45 48 d5 d0            	vpmullw	%zmm8, %zmm7, %zmm10
  565666: 4c 8d 04 5a                  	leaq	(%rdx,%rbx,2), %r8
  56566a: 62 51 fe 48 7f 10            	vmovdqu64	%zmm10, (%r8)
  565670: 4c 8d 04 5f                  	leaq	(%rdi,%rbx,2), %r8
  565674: 62 51 fe 48 6f 10            	vmovdqu64	(%r8), %zmm10
  56567a: 62 f3 bd 48 3f cc 04         	vpcmpneqw	%zmm4, %zmm8, %k1
  565681: 62 51 ff c9 7f d0            	vmovdqu16	%zmm10, %zmm8 {%k1} {z}
  565687: 62 d1 55 48 ee e8            	vpmaxsw	%zmm8, %zmm5, %zmm5
  56568d: 0f 84 5a ff ff ff            	je	0x5655ed <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1cd>
  565693: 62 71 35 48 ea c1            	vpminsw	%zmm1, %zmm9, %zmm8
  565699: 62 72 bd 48 8d c0            	vpermw	%zmm0, %zmm8, %zmm8
  56569f: 62 52 7e 48 30 c0            	vpmovwb	%zmm8, %ymm8
  5656a5: 4c 8d 04 19                  	leaq	(%rcx,%rbx), %r8
  5656a9: c4 41 7e 7f 00               	vmovdqu	%ymm8, (%r8)
  5656ae: e9 3a ff ff ff               	jmp	0x5655ed <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1cd>
  5656b3: 62 f3 fd 48 3b e8 00         	vextracti64x4	$0x0, %zmm5, %ymm0
  5656ba: 62 f3 fd 48 3b e9 01         	vextracti64x4	$0x1, %zmm5, %ymm1
  5656c1: c5 fd ee c1                  	vpmaxsw	%ymm1, %ymm0, %ymm0
  5656c5: c4 e3 7d 39 c1 00            	vextracti128	$0x0, %ymm0, %xmm1
  5656cb: c4 e3 7d 39 c0 01            	vextracti128	$0x1, %ymm0, %xmm0
  5656d1: c5 f1 ee c0                  	vpmaxsw	%xmm0, %xmm1, %xmm0
  5656d5: c4 e2 79 23 c8               	vpmovsxwd	%xmm0, %xmm1
  5656da: c5 f9 70 c0 4e               	vpshufd	$0x4e, %xmm0, %xmm0     # xmm0 = xmm0[2,3,0,1]
  5656df: c4 e2 79 23 c0               	vpmovsxwd	%xmm0, %xmm0
  5656e4: c4 e2 79 3d c1               	vpmaxsd	%xmm1, %xmm0, %xmm0
  5656e9: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     # xmm1 = xmm0[2,3,0,1]
  5656ee: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  5656f3: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     # xmm1 = xmm0[1,0,3,2]
  5656f8: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  5656fd: c4 e3 79 16 c1 00            	vpextrd	$0x0, %xmm0, %ecx
  565703: 48 63 c1                     	movslq	%ecx, %rax
  565706: c5 f8 77                     	vzeroupper
  565709: c3                           	retq
  56570a: cc                           	int3
  56570b: cc                           	int3
  56570c: cc                           	int3
  56570d: cc                           	int3
  56570e: cc                           	int3
  56570f: cc                           	int3
  565710: cc                           	int3
  565711: cc                           	int3
  565712: cc                           	int3
  565713: cc                           	int3
  565714: cc                           	int3
  565715: cc                           	int3
  565716: cc                           	int3
  565717: cc                           	int3
  565718: cc                           	int3
  565719: cc                           	int3
  56571a: cc                           	int3
  56571b: cc                           	int3
  56571c: cc                           	int3
  56571d: cc                           	int3
  56571e: cc                           	int3
  56571f: cc                           	int3

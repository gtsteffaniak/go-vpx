
/private/tmp/govpx-fp32-avx512-48/candidate-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000565420 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512>:
  565420: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
  565425: 48 89 7c 24 68               	movq	%rdi, 0x68(%rsp)
  56542a: 4c 89 8c 24 80 00 00 00      	movq	%r9, 0x80(%rsp)
  565432: 90                           	nop
  565433: 62 f1 fd 48 ef c0            	vpxorq	%zmm0, %zmm0, %zmm0
  565439: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
  56543e: 66 90                        	nop
  565440: 48 85 c9                     	testq	%rcx, %rcx
  565443: 74 0a                        	je	0x56544f <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x2f>
  565445: 62 f1 fe 48 6f 05 b1 3a 22 00	vmovdqu64	0x223ab1(%rip), %zmm0 # 0x788f00 <github.com/thesyncim/govpx/internal/pixel.fpClassWordLUT32>
  56544f: 62 f1 f5 48 ef c9            	vpxorq	%zmm1, %zmm1, %zmm1
  565455: 0f b7 54 24 2a               	movzwl	0x2a(%rsp), %edx
  56545a: 0f b7 5c 24 28               	movzwl	0x28(%rsp), %ebx
  56545f: 0f b7 74 24 2e               	movzwl	0x2e(%rsp), %esi
  565464: 44 0f b7 44 24 2c            	movzwl	0x2c(%rsp), %r8d
  56546a: 44 0f b7 54 24 32            	movzwl	0x32(%rsp), %r10d
  565470: 44 0f b7 5c 24 30            	movzwl	0x30(%rsp), %r11d
  565476: 62 f1 fe 48 6f 10            	vmovdqu64	(%rax), %zmm2
  56547c: 62 f2 7d 48 1d da            	vpabsw	%zmm2, %zmm3
  565482: 62 f3 ed 48 3f c9 01         	vpcmpltw	%zmm1, %zmm2, %k1
  565489: 41 bc ff 7f 00 00            	movl	$0x7fff, %r12d          # imm = 0x7FFF
  56548f: c4 c1 f9 6e d4               	vmovq	%r12, %xmm2
  565494: 62 f2 7d 48 79 d2            	vpbroadcastw	%xmm2, %zmm2
  56549a: c5 81 c4 e2 00               	vpinsrw	$0x0, %edx, %xmm15, %xmm4
  56549f: 62 f2 7d 48 79 ec            	vpbroadcastw	%xmm4, %zmm5
  5654a5: c4 e2 7d 79 f4               	vpbroadcastw	%xmm4, %ymm6
  5654aa: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
  5654af: c5 d9 c4 e3 00               	vpinsrw	$0x0, %ebx, %xmm4, %xmm4
  5654b4: c4 e3 4d 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm6, %ymm4
  5654ba: 62 f3 d5 48 3a e4 00         	vinserti64x4	$0x0, %ymm4, %zmm5, %zmm4
  5654c1: 62 f1 5d 48 fd db            	vpaddw	%zmm3, %zmm4, %zmm3
  5654c7: 62 f2 65 48 3a da            	vpminuw	%zmm2, %zmm3, %zmm3
  5654cd: c5 81 c4 e6 00               	vpinsrw	$0x0, %esi, %xmm15, %xmm4
  5654d2: 62 f2 7d 48 79 ec            	vpbroadcastw	%xmm4, %zmm5
  5654d8: c4 e2 7d 79 f4               	vpbroadcastw	%xmm4, %ymm6
  5654dd: c4 e2 79 79 e4               	vpbroadcastw	%xmm4, %xmm4
  5654e2: c4 c1 59 c4 e0 00            	vpinsrw	$0x0, %r8d, %xmm4, %xmm4
  5654e8: c4 e3 4d 38 e4 00            	vinserti128	$0x0, %xmm4, %ymm6, %ymm4
  5654ee: 62 f3 d5 48 3a e4 00         	vinserti64x4	$0x0, %ymm4, %zmm5, %zmm4
  5654f5: c4 c1 01 c4 ea 00            	vpinsrw	$0x0, %r10d, %xmm15, %xmm5
  5654fb: 62 f2 7d 48 79 f5            	vpbroadcastw	%xmm5, %zmm6
  565501: c4 e2 7d 79 fd               	vpbroadcastw	%xmm5, %ymm7
  565506: c4 e2 79 79 ed               	vpbroadcastw	%xmm5, %xmm5
  56550b: c4 c1 51 c4 eb 00            	vpinsrw	$0x0, %r11d, %xmm5, %xmm5
  565511: c4 e3 45 38 ed 00            	vinserti128	$0x0, %xmm5, %ymm7, %ymm5
  565517: 62 f3 cd 48 3a ed 00         	vinserti64x4	$0x0, %ymm5, %zmm6, %zmm5
  56551e: 62 f3 e5 48 3f d5 0d         	vpcmpw	$0xd, %zmm5, %zmm3, %k2
  565525: 62 f1 5d ca e5 db            	vpmulhw	%zmm3, %zmm4, %zmm3 {%k2} {z}
  56552b: 90                           	nop
  56552c: 62 f1 fe 48 7f dc            	vmovdqu64	%zmm3, %zmm4
  565532: 62 f1 75 49 f9 db            	vpsubw	%zmm3, %zmm1, %zmm3 {%k1}
  565538: 4d 85 c9                     	testq	%r9, %r9
  56553b: 74 0b                        	je	0x565548 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x128>
  56553d: 62 d1 fe 48 7f 19            	vmovdqu64	%zmm3, (%r9)
  565543: 48 85 c9                     	testq	%rcx, %rcx
  565546: eb 03                        	jmp	0x56554b <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x12b>
  565548: 48 85 c9                     	testq	%rcx, %rcx
  56554b: 62 f1 55 48 d5 eb            	vpmullw	%zmm3, %zmm5, %zmm5
  565551: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
  565556: 62 f1 fe 48 7f 2a            	vmovdqu64	%zmm5, (%rdx)
  56555c: 62 f1 fe 48 6f 2f            	vmovdqu64	(%rdi), %zmm5
  565562: 62 f3 e5 48 3f c9 04         	vpcmpneqw	%zmm1, %zmm3, %k1
  565569: bb 0b 00 00 00               	movl	$0xb, %ebx
  56556e: c4 e1 f9 6e db               	vmovq	%rbx, %xmm3
  565573: 62 f1 ff c9 7f ed            	vmovdqu16	%zmm5, %zmm5 {%k1} {z}
  565579: 62 f1 75 48 ee ed            	vpmaxsw	%zmm5, %zmm1, %zmm5
  56557f: 62 f2 7d 48 79 db            	vpbroadcastw	%xmm3, %zmm3
  565585: 74 16                        	je	0x56559d <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x17d>
  565587: 62 f1 5d 48 ea e3            	vpminsw	%zmm3, %zmm4, %zmm4
  56558d: 62 f2 dd 48 8d e0            	vpermw	%zmm0, %zmm4, %zmm4
  565593: 62 f2 7e 48 30 e4            	vpmovwb	%zmm4, %ymm4
  565599: c5 fe 7f 21                  	vmovdqu	%ymm4, (%rcx)
  56559d: 0f b7 5c 24 2a               	movzwl	0x2a(%rsp), %ebx
  5655a2: 0f b7 74 24 2e               	movzwl	0x2e(%rsp), %esi
  5655a7: 44 0f b7 44 24 32            	movzwl	0x32(%rsp), %r8d
  5655ad: c4 e1 f9 6e e3               	vmovq	%rbx, %xmm4
  5655b2: c4 e1 f9 6e f6               	vmovq	%rsi, %xmm6
  5655b7: c4 c1 f9 6e f8               	vmovq	%r8, %xmm7
  5655bc: 62 f2 7d 48 79 e4            	vpbroadcastw	%xmm4, %zmm4
  5655c2: 62 f2 7d 48 79 f6            	vpbroadcastw	%xmm6, %zmm6
  5655c8: 62 f2 7d 48 79 ff            	vpbroadcastw	%xmm7, %zmm7
  5655ce: bb 20 00 00 00               	movl	$0x20, %ebx
  5655d3: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
  5655d8: eb 06                        	jmp	0x5655e0 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1c0>
  5655da: 48 83 c3 20                  	addq	$0x20, %rbx
  5655de: 66 90                        	nop
  5655e0: 48 39 de                     	cmpq	%rbx, %rsi
  5655e3: 0f 8e a6 00 00 00            	jle	0x56568f <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x26f>
  5655e9: 4c 8d 04 58                  	leaq	(%rax,%rbx,2), %r8
  5655ed: 62 51 fe 48 6f 00            	vmovdqu64	(%r8), %zmm8
  5655f3: 62 52 7d 48 1d c8            	vpabsw	%zmm8, %zmm9
  5655f9: 62 71 35 48 fd cc            	vpaddw	%zmm4, %zmm9, %zmm9
  5655ff: 62 72 35 48 3a ca            	vpminuw	%zmm2, %zmm9, %zmm9
  565605: 62 f3 b5 48 3f cf 0d         	vpcmpw	$0xd, %zmm7, %zmm9, %k1
  56560c: 62 f3 bd 48 3f d1 01         	vpcmpltw	%zmm1, %zmm8, %k2
  565613: 62 51 4d c9 e5 c1            	vpmulhw	%zmm9, %zmm6, %zmm8 {%k1} {z}
  565619: 62 51 fe 48 7f c1            	vmovdqu64	%zmm8, %zmm9
  56561f: 62 51 75 4a f9 c0            	vpsubw	%zmm8, %zmm1, %zmm8 {%k2}
  565625: 4d 85 c9                     	testq	%r9, %r9
  565628: 74 0f                        	je	0x565639 <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x219>
  56562a: 4d 8d 04 59                  	leaq	(%r9,%rbx,2), %r8
  56562e: 62 51 fe 48 7f 00            	vmovdqu64	%zmm8, (%r8)
  565634: 48 85 c9                     	testq	%rcx, %rcx
  565637: eb 03                        	jmp	0x56563c <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x21c>
  565639: 48 85 c9                     	testq	%rcx, %rcx
  56563c: 62 51 45 48 d5 d0            	vpmullw	%zmm8, %zmm7, %zmm10
  565642: 4c 8d 04 5a                  	leaq	(%rdx,%rbx,2), %r8
  565646: 62 51 fe 48 7f 10            	vmovdqu64	%zmm10, (%r8)
  56564c: 4c 8d 04 5f                  	leaq	(%rdi,%rbx,2), %r8
  565650: 62 51 fe 48 6f 10            	vmovdqu64	(%r8), %zmm10
  565656: 62 f3 bd 48 3f c9 04         	vpcmpneqw	%zmm1, %zmm8, %k1
  56565d: 62 51 ff c9 7f d0            	vmovdqu16	%zmm10, %zmm8 {%k1} {z}
  565663: 62 d1 55 48 ee e8            	vpmaxsw	%zmm8, %zmm5, %zmm5
  565669: 0f 84 6b ff ff ff            	je	0x5655da <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1ba>
  56566f: 62 71 35 48 ea c3            	vpminsw	%zmm3, %zmm9, %zmm8
  565675: 62 72 bd 48 8d c0            	vpermw	%zmm0, %zmm8, %zmm8
  56567b: 62 52 7e 48 30 c0            	vpmovwb	%zmm8, %ymm8
  565681: 4c 8d 04 19                  	leaq	(%rcx,%rbx), %r8
  565685: c4 41 7e 7f 00               	vmovdqu	%ymm8, (%r8)
  56568a: e9 4b ff ff ff               	jmp	0x5655da <github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512+0x1ba>
  56568f: 62 f3 fd 48 3b e8 00         	vextracti64x4	$0x0, %zmm5, %ymm0
  565696: 62 f3 fd 48 3b e9 01         	vextracti64x4	$0x1, %zmm5, %ymm1
  56569d: c5 fd ee c1                  	vpmaxsw	%ymm1, %ymm0, %ymm0
  5656a1: c4 e3 7d 39 c1 00            	vextracti128	$0x0, %ymm0, %xmm1
  5656a7: c4 e3 7d 39 c0 01            	vextracti128	$0x1, %ymm0, %xmm0
  5656ad: c5 f1 ee c0                  	vpmaxsw	%xmm0, %xmm1, %xmm0
  5656b1: c4 e2 79 23 c8               	vpmovsxwd	%xmm0, %xmm1
  5656b6: c5 f9 70 c0 4e               	vpshufd	$0x4e, %xmm0, %xmm0     # xmm0 = xmm0[2,3,0,1]
  5656bb: c4 e2 79 23 c0               	vpmovsxwd	%xmm0, %xmm0
  5656c0: c4 e2 79 3d c1               	vpmaxsd	%xmm1, %xmm0, %xmm0
  5656c5: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     # xmm1 = xmm0[2,3,0,1]
  5656ca: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  5656cf: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     # xmm1 = xmm0[1,0,3,2]
  5656d4: c4 e2 71 3d c0               	vpmaxsd	%xmm0, %xmm1, %xmm0
  5656d9: c4 e3 79 16 c1 00            	vpextrd	$0x0, %xmm0, %ecx
  5656df: 48 63 c1                     	movslq	%ecx, %rax
  5656e2: c5 f8 77                     	vzeroupper
  5656e5: c3                           	retq
  5656e6: cc                           	int3
  5656e7: cc                           	int3
  5656e8: cc                           	int3
  5656e9: cc                           	int3
  5656ea: cc                           	int3
  5656eb: cc                           	int3
  5656ec: cc                           	int3
  5656ed: cc                           	int3
  5656ee: cc                           	int3
  5656ef: cc                           	int3
  5656f0: cc                           	int3
  5656f1: cc                           	int3
  5656f2: cc                           	int3
  5656f3: cc                           	int3
  5656f4: cc                           	int3
  5656f5: cc                           	int3
  5656f6: cc                           	int3
  5656f7: cc                           	int3
  5656f8: cc                           	int3
  5656f9: cc                           	int3
  5656fa: cc                           	int3
  5656fb: cc                           	int3
  5656fc: cc                           	int3
  5656fd: cc                           	int3
  5656fe: cc                           	int3
  5656ff: cc                           	int3

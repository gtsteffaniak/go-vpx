from pathlib import Path
import hashlib,json,shutil,re,subprocess
b=Path('/private/tmp/govpx-fp32-avx512-48');out=Path('/private/tmp/govpx-fp32-avx512-48-ready');assert not out.exists();out.mkdir()
rels=['internal/pixel/quantize_fp_amd64.go','internal/pixel/quantize_fp32_avx512_amd64.go','internal/pixel/quantize_fp32_avx512_amd64_test.go','internal/pixel/quantize_fp32_bounds_amd64_test.go']
for rel in rels:
 p=out/'overlay'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(b/'candidate'/rel,p)
for rel in ['internal/pixel/quantize_fp_amd64.go','internal/pixel/quantize_fp16_amd64_test.go','internal/pixel/quantize_fp_simd.go','internal/pixel/quantize_fp.go','internal/pixel/helpers_amd64.go','go.mod']:
 p=out/'parent-source'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(b/'parent'/rel,p)
for folder in ['validation','validation-before-bounds','codegen']:
 for p in (b/folder).rglob('*'):
  if p.is_file() and not p.name.endswith('.test'):
   q=out/folder/p.relative_to(b/folder);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for p in b.iterdir():
 if p.is_file() and p.suffix not in ['.test'] and p.name not in ['candidate-linux.test','candidate-darwin.test']:
  shutil.copy2(p,out/p.name)
for rel in rels[:3]:
 q=b/'initial-xorsign'/rel
 if q.exists():p=out/'initial-xorsign-source'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,p)
# Exact excluded-OS filename retained as trial metadata; same test bytes renamed.
p=out/'trials/quantize_fp32_windows_amd64_test.go.txt';p.parent.mkdir(exist_ok=True);shutil.copy2(b/'candidate/internal/pixel/quantize_fp32_bounds_amd64_test.go',p)
omit=[]
for p in b.rglob('*.test'):omit.append({'private_path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size})
(out/'binary-omissions.json').write_text(json.dumps(omit,indent=2))
root='/Users/thesyncim/GolandProjects/govpx';head='31123a9ecb7fa3b90afdb293beb06dadb2a6f857';changed=[]
for p in (b/'candidate').rglob('*.go'):
 rel=p.relative_to(b/'candidate');old=b/'parent'/rel
 if not old.exists()or p.read_bytes()!=old.read_bytes():changed.append(str(rel))
assert sorted(changed)==sorted(rels),changed
source={'base_git':head,'production_delta':rels[:2],'test_delta':rels[2:],'shared_ARM_liveness_test_only':'internal/pixel/fp32_arm_live_test.go (identicalparent/candidate,notintegrationoverlay)','files':{r:hashlib.sha256((b/'candidate'/r).read_bytes()).hexdigest()for r in rels},'no_root_edits':True,'no_selected512_execution':True,'no_native_or_emulated_throughput_measurement':True}
(out/'source-proof.json').write_text(json.dumps(source,indent=2))
(out/'REPORT.md').write_text('''Private AVX512BW32-lane FP quantization candidate; correctness/codegen prototype ONLY.

Exactbase31123a9ecb7fa3b90afdb293beb06dadb2a6f857 (PR48fixed). Root/PR/Git untouched. Overlay2production+2current-onlytestfiles. Actual512kernel has NEVER executed here; no fakeCPUcaps, no native/emulated throughput claim. All public1x times are correctness-only, excluded from ROI evidence.

The new branch is inside original16-lane disjoint/Enabled/AVX2 guard, n>=256 divisible32 (existingupper1024); originalpubliclength/table validation andall10overlapdeclines remain unchanged. Other16/8lane source is exact after removingnew3-line dispatch. Nilq/classes, malformedtable/len and aliasfallback order stay original. Newhelperunexported, onlyrealSDKAVX512guarded call. SDKAVX512()bundlesF+CD+BW+DQ+VL plusOSXSAVE/XCR0 support; noVBMIrequired.

Math: Abs(-32768)unsigned32768+round<=65535;clip32767 then signedMulHigh withnonnegativequant<=32767 gives0..16383. Dequantlow16wrap/sign/EOBsignedmax matchoriginal. First32packet ownsDC-onlylane0 via nestedSetLo;laterAC-only. Classes usewordLUT VPERMW onMin11 indices thenVPMOVWB exact32Bstore, class0..5, noVBMI. No new unsafegeometry; each64Bload/store is inside alreadyvalidated2*n bytewindow and32Bclassesinside n.

Initial Xor/Subsign compiler foldsTERNLOG andduplicatesMulHigh. Exactequivalent zero.Sub(mag).IfElse(c<0,mag) preserves initialsource/LLVM and lowers to one maskedVPMULHW per32packet. FinalDarwin/Linuxhelper138staticinstructions/36hot, noCALL/localframe/hotstack/vectorlegacywrite, finalVZEROUPPER. Threeargument-home stores exist beforeloop, disclosed inproof. Dispatcher448→473staticinstructions, frame168Bunchanged; extrahelperABIcall is realgluecost. Do not comparehelper138 vswholeparentdispatcher448 as a speedup. ARM actual200-instruction quantizer remains identical usingonesharedlivenesstest solelyto preventdeadstripping. InitialARMproofattempt foundnosymbol because noARMtestcalledquantizer; sharedlivenessfixedthat, no productionchange.

Fallback correctness: officialGo1.27.2 SIMD,CGO0,DarwinAMD64crossbuildviaROOTwrapperuniqueagent/p2/tmpcache;selectedRosettaAVX2/AVX512false,explicitAVX512foff retainingAVX2,andallAVXoff,ordinary+checkptr2 allFP16/FP32 PASS. All72public36fixtureselected/offoneshots outputoracles0alloc. Linux/Darwinoptimizedcrossbuilds,purego/nosimd builds PASS. Native512selectedoracletest explicitlySKIPs becauseactualfeaturefalse. Source/LLVMproof and fallbacktests do NOTvalidate selected512 arithmetic; nativeCIrequired.

Addedeligible-size tests:512disjoint n256 configurationscoveractualaddresses0..63 onall5views, exactvisiblecaps/fullbackingcanaries, optionalq/classes;40declinecases all10pairsexactandpartialbyteoverlap (includingreadonlypairs) atn256, frozen8lanefullstate/panic oracle;30shortvisible/spare/clippedcap publicpanic/backing configs atn256. ExplicitPASS-nameassertions in everyselected/off/checkptrlog confirmexecution. Existingn256all65536signedcoefficienttest will exercise512onlyonrealnative512. One filename mistake initially used*_windows_amd64_test.go, soGo excludedit asGOOSwindows. Renamed*_bounds_amd64_test.go andreranallcheckswithrequiredtestnames; pre-bounds logs/sourcefilename preserved, no earlier claim substitutedforfinalcoverage.

Alloriginalsources/logs/codegen/proofs andbinarySHA/size/privatepaths retained. This leanpackage omitsONLY executablebinarypayloads, whichremainprivate. No nativeperformance acceptance or PRintegrationauthorizedbythispackage. Rootindependentreview/nativeCIselected512oracles+publicROI are required next.
''')
(out/'NATIVE_CI_PLAN.md').write_text('''KeepGOAMD64=v1/Go1.27.2/SIMD/PGOoff/GOMAX1. Selected512evidence requires a REALnativeLinuxAMD64CPU witharchsimd.X86.AVX512()==true; neverRosetta/fakecaps. Dedicatedselectedlane setsGOVPX_REQUIRE_FP32_NATIVE=1 andruns ^Test(FP16|FP32) ordinary+race/checkptr2; featuretest MUSTfailif512unavailable ratherthanclaimselectedproof. Ifgeneralbenchmarkrunnerlacks512, labelallitsmeasurementsfallbackcontrols andrequireaseparateactual512run; donotmanufacturefeatureflags orflakyacceptancethresholds.

Then identicalpublicencoder36FP16fixtures/independentoracles, noClasses+fusedclasses+qnil, n64controls andn256targets, sixbalancedhead/parent/oldnativeorders. KeepnewdispatchABIcost inactualpublictiming; no privatehelper-onlyacceptancebasis. Allregressions/allocations/drop/counts/EOB/classes retained separately. AlsoGODEBUGcpu.avx512f=off mustproveoldAVX2fallback andcpu.avx/off+avx2off mustproveoriginalscalar/narrowfallback. Add4overlaypaths tofutureexactsourceprovenance (existingquantize_fp_amd64 alreadytracked, so3newSHApaths beforeotherconcurrentchanges); noAMDchanges48rootnow.

Preserve actualGNUhelper+callertrace withmeasured executableSHA, ensureZMMopcode/nohotspills/legacywrites/VZERO fence. Verifyactual32selectedbeforemeasuring. ArchitecturequantGo source200ARMmachinebodymuststayidentical. Native512correctness/performancepending; currentcrossbuild/fallbackchecks cannotcloseit.\n''')
rows=[]
for p in sorted(out.rglob('*')):
 if p.is_file():rows.append({'path':str(p.relative_to(out)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size})
(out/'MANIFEST.json').write_text(json.dumps(rows,indent=2));print(json.dumps({'ready':str(out),'files':len(rows),'manifest_sha256':hashlib.sha256((out/'MANIFEST.json').read_bytes()).hexdigest()},indent=2))

from pathlib import Path
import re,subprocess,json,hashlib
b=Path('/private/tmp/govpx-fp32-avx512-48');out=b/'codegen';out.mkdir(exist_ok=True)
def dis(binary,symbol,tag,arm=False):
 t=subprocess.check_output(['xcrun','llvm-objdump','-d','--disassemble-symbols='+symbol,str(binary)],text=True);(out/(tag+'.asm')).write_text(t)
 pat=r'^\s*([0-9a-f]+):\s+[0-9a-f]{8}\s+(.+)$'if arm else r'^\s*([0-9a-f]+):\s+(?:[0-9a-f]{2}\s+)+(.+)$'
 a=[(int(m[1],16),m[2])for l in t.splitlines()if(m:=re.match(pat,l))and m[2]not in('int3','udf #0x0')];assert a,tag;return a
r={}
for os in ['linux','darwin']:
 prefix='_'if os=='darwin'else'';a=dis(b/'validation'/('candidate-'+os+'.test'),prefix+'github.com/thesyncim/govpx/internal/pixel.quantizeFPBlock32AVX512','fp32-'+os)
 backs=[(pc,int(m[1],16))for pc,i in a if(m:=re.match(r'(?:j[a-z]+)\s+0x([0-9a-f]+)',i))and int(m[1],16)<pc];start=min(x[1]for x in backs);end=max(x[0]for x in backs);hot=[(p,i)for p,i in a if start<=p<=end]
 assert not any(i.startswith('call')or'%rsp'in i or'%rbp'in i for p,i in hot)
 legacy=[i for p,i in a if re.search(r'%(?:xmm|ymm|zmm)\d+',i)and not i.startswith('v')];assert not legacy,legacy
 assert any('vpmulhw'in i and'%zmm'in i for p,i in hot)and any('vpermw'in i for p,i in hot)and any('vpmovwb'in i for p,i in hot)
 assert sum(i.startswith('vpmulhw')for p,i in hot)==1
 assert sum(i.startswith('vzeroupper')for p,i in a)==1 and a[-1][1]=='retq'
 r[os]={'meaningful_instructions':len(a),'hot_static_instructions':len(hot),'hot_vpmulhw':1,'hot_stack_refs':[],'all_legacy_vector_moves':legacy,'hot_calls':[],'local_frame_allocations':[i for p,i in a if re.match(r'subq.*%rsp',i)],'argument_home_stores':[i for p,i in a if re.search(r'movq.*%rsp',i)][:3],'hot_loop':hot,'return_fence':True}
 for v in ['parent','candidate']:
  a=dis(b/'validation'/(v+'-'+os+'.test'),prefix+'github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD',v+'-dispatch-'+os)
  z=[i for p,i in a if '%zmm'in i or re.search(r'%k[0-7]',i)];assert not z,(v,z)
  r[v+'-dispatch-'+os]={'meaningful_instructions':len(a),'frame_allocations':[i for p,i in a if re.match(r'subq.*%rsp',i)],'calls':[i for p,i in a if i.startswith('call')],'no512_in_dispatch_body':True}
# Actual ARM quantizer body invariant, not merely build tags.
arm=[]
for v in ['parent','candidate']:
 a=dis(b/'validation'/(v+'-arm.test'),'_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD',v+'-ARM',True);arm.append([re.sub(r'0x[0-9a-fA-F]+','ADDR',i)for p,i in a])
assert arm[0]==arm[1];r['ARM']={'actual_function_identical':True,'instructions':len(arm[0])}
old=(b/'parent/internal/pixel/quantize_fp_amd64.go').read_text();new=(b/'candidate/internal/pixel/quantize_fp_amd64.go').read_text();branch='\t\tif n >= 256 && n&31 == 0 && archsimd.X86.AVX512() {\n\t\t\treturn quantizeFPBlock32AVX512(coeff, iscan, qcoeff, dqcoeff, n, r, q, d, classes)\n\t\t}\n';assert new.replace(branch,'')==old
r['source']={'existing_16_and_8_lane_sources_exact_after_removing_new_dispatch':True,'existing_guard_and_panic_sequence_unchanged':True,'new_branch_inside_complete_disjoint_guard':True,'ARM_source_and_actual_machine_body_unchanged':True,'new_helper_sha256':hashlib.sha256((b/'candidate/internal/pixel/quantize_fp32_avx512_amd64.go').read_bytes()).hexdigest(),'no_native512_correctness_or_performance_claim':True}
(out/'proof.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:{n:v for n,v in x.items()if n not in['hot_loop','calls','argument_home_stores']}for k,x in r.items()},indent=2))

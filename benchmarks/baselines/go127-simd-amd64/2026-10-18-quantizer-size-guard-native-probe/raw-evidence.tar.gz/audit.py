from pathlib import Path
import collections, hashlib, itertools, json, re, statistics, subprocess

D=Path(__file__).parent; R=D/'raw'; ROOT='/Users/thesyncim/GolandProjects/govpx'
H='e2fffb9f649b4a757c285671899eddf624e3013a'; B='5c5cf3977052368746325c4033a1909e7eacd26a'
Q='internal/pixel/quantize_fp_amd64.go'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,input=None):return subprocess.check_output(['git','--no-optional-locks',*args],cwd=ROOT,input=input)
def load(p):return json.loads((R/p).read_text())
def close(a,b):assert abs(a-b)<=1e-10*max(1,abs(a),abs(b)),(a,b)
raw={str(p.relative_to(R)):sha(p.read_bytes()) for p in sorted(R.rglob('*')) if p.is_file()}
manifest=load('MANIFEST.json');assert {p:s for p,s in raw.items()if p!='MANIFEST.json'}==manifest
assert load('status.json')['complete'] and load('status.json')['phase']=='complete'
commands=load('commands.json');assert all(x['exit_code']==0 for x in commands)
assert all((R/x['output']).is_file() and (R/(x['output']+'.stderr')).is_file()for x in commands)
assert all(not (R/(x['output']+'.stderr')).read_bytes()for x in commands if x['output'].startswith(('timed/','preflight/','counts/')))
binding=load('binding.json');assert binding['commits']=={'parent':B,'current':H}
assert binding['PGO']=='off' and binding['CGO_ENABLED']==1 and binding['GOMAXPROCS']==1
assert binding['driver_sha256']==sha(git('show',H+':scripts/benchmark-fp-guard-amd64.py'))
assert (R/'goversion.txt').read_text().strip()=='go1.27.2' and '.codex/worktrees'not in(R/'gocache.txt').read_text()
assert (R/'objdump-version.txt').read_text().startswith('GNU objdump')
assert 'Linux'in(R/'uname.txt').read_text() and 'x86_64'in(R/'uname.txt').read_text()
cpu=re.search(r'^Model name:\s+(.+)$',(R/'lscpu.txt').read_text(),re.M)[1]
all_git={};compiled={}
for v,c in [('parent',B),('current',H)]:
    paths=[p for p in git('ls-tree','-r','--name-only',c).decode().splitlines()if p.endswith('.go')]
    blobs=git('cat-file','--batch',input=''.join(c+':'+p+'\n'for p in paths).encode());off=0;expected={}
    for p in paths:
        e=blobs.index(b'\n',off);head=blobs[off:e].decode().split();assert head[1]=='blob';n=int(head[2]);expected[p]=sha(blobs[e+1:e+1+n]);off=e+n+2
    assert off==len(blobs) and expected==binding['variants'][v]['all_go_sha256']
    all_git[v]=expected;compiled[v]=binding['variants'][v]['compiled_production_go_sha256']
    assert all(expected[p]==s for p,s in compiled[v].items())
    for p in [Q,'internal/pixel/quantize_fp32_avx512_amd64.go','internal/pixel/fp32_optional_native_test.go','internal/vp9/encoder/quant_fp16_native_test.go']:
        assert (R/'sources'/v/(p+'.txt')).read_bytes()==git('show',c+':'+p)
assert compiled['parent'].keys()==compiled['current'].keys()
assert [p for p in compiled['parent']if compiled['parent'][p]!=compiled['current'][p]]==[Q]
parent=git('show',B+':'+Q);current=git('show',H+':'+Q)
assert parent.replace(b'if archsimd.X86.AVX512() && n >= 256 && n&31 == 0 {',b'if n >= 256 && n&31 == 0 && archsimd.X86.AVX512() {')==current
features=binding['actual_SDK_features'];assert features['AVX2'] and features['Enabled']
state={}
for v in ('parent','current'):
    for mode in ['host','selected-raceFalse','selected-raceTrue','512-off','avx-off']:
        t=(R/f'correctness/{v}-{mode}.txt').read_text();assert '\nPASS\n'in t or re.search(r'^ok\s',t,re.M)
        passes=re.findall(r'^--- PASS: (\S+)',t,re.M);skips=re.findall(r'^--- SKIP: (\S+)',t,re.M)
        state[v+'-'+mode]={'passes':passes,'skips':skips}
        if mode=='host':assert f"FP32PublicHost AVX512={str(features['AVX512']).lower()} AVX2=true Enabled=true"in t
        if mode=='avx-off':
            command=next(x for x in commands if x['output']==f'correctness/{v}-{mode}.txt')
            assert command['environment_overrides']['GODEBUG']=='cpu.avx=off,cpu.avx2=off,cpu.avx512f=off'
def names(kind):
    if kind=='pixel':return {f'BenchmarkFP32PublicOptionalNative/n{n}/qnil{q}/classes{c}/{p}/{a}'for n,q,c,p,a in itertools.product((64,256),('false','true'),('false','true'),('zero','sparse','dense'),('aligned64','offset2-classes1'))}
    return {f'BenchmarkVP9FP16Native/n{n}/{c}/{p}/{a}'for n,c,p,a in itertools.product((16,64,256),('no-classes','classes'),('zero','sparse','dense'),('aligned32','offset2-classes1'))}
def bench(path,kind):
    out={}
    for l in (R/path).read_text().splitlines():
        if l.startswith('Benchmark'):
            m=re.fullmatch(r'(Benchmark\S+)\s+(\d+)\s+([\d.eE+\-]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op\s*',l);assert m,l
            n,it,ns,byt,alloc=m.groups();assert n not in out and int(it)>0 and float(ns)>0 and int(byt)==int(alloc)==0;out[n]=float(ns)
    assert set(out)==names(kind);return out
timed={};preflights=0
for v in ('parent','current'):
    for kind in ('pixel','encoder'):preflights+=len(bench(f'preflight/{v}-{kind}.txt',kind))
assert preflights==168
orders=[['parent','current'],['current','parent']]*3
for i in (0,1):assert collections.Counter(row[i]for row in orders)=={'parent':3,'current':3}
expected_order=[f'timed/r{r}-{v}-{kind}.txt'for r,order in enumerate(orders,1)for v in order for kind in ('pixel','encoder')]
actual_order=[x['output']for x in commands if x['output'].startswith('timed/')and x['output'].endswith('.txt')];assert actual_order==expected_order
for r in range(1,7):
    for v in ('parent','current'):
        for kind in ('pixel','encoder'):timed[r,v,kind]=bench(f'timed/r{r}-{v}-{kind}.txt',kind)
components={}
for kind in ('pixel','encoder'):
    for n in sorted(names(kind)):
        ns={v:[timed[r,v,kind][n]for r in range(1,7)]for v in ('parent','current')};ratios=[a/b for a,b in zip(ns['parent'],ns['current'])]
        components[n]={'raw_ns':ns,'speedup':statistics.median(ns['parent'])/statistics.median(ns['current']),'paired_speedups':ratios,'slower_pairs':sum(x<1 for x in ratios),'zero_allocations':True}
assert sum(len(x)for x in timed.values())==1008
summary=load('summary.json');assert summary['components']==components and summary['orders']==orders and summary['component_rows']==1008 and summary['excluded_preflight_rows']==168
ignore={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'}
semantic=lambda x:{k:v for k,v in x.items()if k not in ignore}
whole={v:[load(f'timed/r{r}-{v}-whole.json')for r in range(1,7)]for v in ('parent','current')}
reference=semantic(whole['parent'][0]);assert len(reference)==22 and all(semantic(x)==reference for xs in whole.values()for x in xs)
ns={v:[x['ns_per_frame']for x in xs]for v,xs in whole.items()};delta=100*(statistics.median(ns['current'])/statistics.median(ns['parent'])-1);close(delta,summary['whole']['median_time_change_pct'])
assert ns==summary['whole']['ns_per_frame'] and {v:[x['allocs_per_frame']for x in xs]for v,xs in whole.items()}==summary['whole']['allocations_per_frame']
timing_end=max(x['end_utc']for x in commands if x['output'].startswith('timed/'))
assert all(x['start_utc']>=timing_end for x in commands if x['output'].startswith(('profiles/','codegen/','counts/')))
profile_alloc={};codegen={}
for v in ('parent','current'):
    profile_alloc[v]=[]
    for n in range(1,25):
        x=load(f'profiles/{v}-{n}.json');assert semantic(x)==reference;profile_alloc[v].append(x['allocs_per_frame']);assert (R/f'profiles/{v}-{n}.pgo').stat().st_size>0
    assert (R/f'profiles/{v}-merged.pgo').stat().st_size>0
    for kind in ('pixel','encoder','whole'):
        info=(R/f'codegen/{v}-{kind}-buildinfo.txt').read_text();assert all(x in info for x in ('go1.27.2','GOOS=linux','GOARCH=amd64','CGO_ENABLED=1','GOEXPERIMENT=simd'))
        owners=load(f'codegen/{v}-{kind}-owners.json');nm=(R/f'codegen/{v}-{kind}-symbols.txt').read_text();mapped={m[3]:(int(m[1],16),int(m[2]))for l in nm.splitlines()if(m:=re.fullmatch(r'\s*([0-9a-fA-F]+)\s+(\d+)\s+[Tt]\s+(\S+)\s*',l))}
        for owner in owners:
            symbol=owner['symbol'];assert mapped[symbol]==(owner['address'],owner['size']);asm=(R/f'codegen/{v}-{kind}-{symbol.rsplit("/",1)[-1]}.asm.txt').read_text();assert 'elf64-x86-64'in asm
            instructions=[int(m[1],16)for l in asm.splitlines()if(m:=re.match(r'^\s*([0-9a-f]+):\s+[0-9a-f]{2}\s',l))]
            assert instructions and instructions[0]==owner['address'] and all(owner['address']<=a<owner['address']+owner['size']for a in instructions)
        codegen[v+'-'+kind]=owners
counts={v:load(f'counts/{v}.json')for v in ('parent','current')};assert counts['parent']==counts['current']
for v in ('parent','current'):
    assert semantic(load(f'counts/{v}-excluded-output.json'))==reference
    cb=load(f'counts/{v}-binding.json');assert cb['throughput_excluded'];assert len(cb['binary_sha256'])==64
    before=all_git[v];after=cb['all_go_sha256'];assert set(after)-set(before)=={'internal/pixel/fp_guard_trace_diagnostic_amd64.go'}
    changed={p for p in before if before[p]!=after[p]};assert changed=={Q,'cmd/govpx-bench/main.go'}
    for p in changed|{'internal/pixel/fp_guard_trace_diagnostic_amd64.go'}:assert sha((R/'counts'/v/(p+'.txt')).read_bytes())==after[p]
avoided=sum(n for k,n in counts['current']['eligible_avx2'].items()if int(k)<256 or int(k)%32)
assert avoided==load('counts/interpretation.json')['AVX512_queries_avoided_by_size_rejection']
proof={'PASS':True,'head':H,'base':B,'native_run':39133345380,'raw_files':len(raw),'CPU':cpu,'actual_SDK_features':features,'compiled_production_sources':{v:len(x)for v,x in compiled.items()},'only_compiled_delta':Q,'components':1008,'preflights':168,'component_median_range':[min(x['speedup']for x in components.values()),max(x['speedup']for x in components.values())],'component_median_losses':{n:x for n,x in components.items()if x['speedup']<1},'whole':summary['whole'],'profiles_per_variant':24,'profile_allocation_samples':profile_alloc,'all_22_semantic_fields_equal':True,'dispatch_queries_avoided':avoided,'state_tests':state,'codegen':codegen,'scope':'Real native AVX2 guard diagnostic. Selected512 unavailable if feature false. Near-flat throughput does not establish historical regression cause. Every loss and allocation sample preserved.'}
(D/'raw-files-SHA256.json').write_text(json.dumps(raw,indent=2)+'\n');(D/'strict-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:proof[k]for k in ['PASS','head','raw_files','CPU','actual_SDK_features','components','preflights','component_median_range','dispatch_queries_avoided']},indent=2))

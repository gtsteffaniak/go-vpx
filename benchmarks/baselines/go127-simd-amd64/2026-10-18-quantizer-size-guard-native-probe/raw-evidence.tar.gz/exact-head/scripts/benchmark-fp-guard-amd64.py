#!/usr/bin/env python3
"""Native two-reference FP guard comparison; no speed threshold is a CI gate."""
from pathlib import Path
import argparse
import datetime
import hashlib
import io
import itertools
import json
import os
import platform
import re
import shutil
import statistics
import subprocess
import tarfile
import tempfile


OLD_GUARD = "if archsimd.X86.AVX512() && n >= 256 && n&31 == 0 {"
NEW_GUARD = "if n >= 256 && n&31 == 0 && archsimd.X86.AVX512() {"
QUANT = "internal/pixel/quantize_fp_amd64.go"
FIXTURES = ("internal/pixel/fp32_optional_native_test.go",
            "internal/vp9/encoder/quant_fp16_native_test.go")
IGNORED = {"ns_per_frame", "encode_fps", "macroblocks_per_second",
           "latency_ns", "allocs_per_frame"}
TRACE_SOURCE = '''//go:build goexperiment.simd && amd64 && !purego

package pixel

import (
    "encoding/json"
    "os"
    "sync/atomic"
)

// Diagnostic only. This file is injected after every uninstrumented timer.
var fpGuardTraceCounts [3][1026]atomic.Uint64

func fpGuardTraceCount(kind, n int) {
    if n < 0 || n > 1024 { n = 1025 }
    fpGuardTraceCounts[kind][n].Add(1)
}

func FPGuardTraceWrite() {
    result := make(map[string]map[int]uint64)
    for kind, name := range []string{"entry", "eligible_avx2", "selected_avx512"} {
        result[name] = make(map[int]uint64)
        for n := range fpGuardTraceCounts[kind] {
            if count := fpGuardTraceCounts[kind][n].Load(); count != 0 {
                result[name][n] = count
            }
        }
    }
    data, err := json.MarshalIndent(result, "", "  ")
    if err != nil { panic(err) }
    if err = os.WriteFile(os.Getenv("GOVPX_FP_GUARD_TRACE"), append(data, '\\n'), 0600); err != nil { panic(err) }
}
'''


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def expected_names(kind):
    if kind == "pixel":
        return {f"BenchmarkFP32PublicOptionalNative/n{n}/qnil{q}/classes{c}/{p}/{a}"
                for n, q, c, p, a in itertools.product(
                    (64, 256), ("false", "true"), ("false", "true"),
                    ("zero", "sparse", "dense"), ("aligned64", "offset2-classes1"))}
    return {f"BenchmarkVP9FP16Native/n{n}/{c}/{p}/{a}"
            for n, c, p, a in itertools.product(
                (16, 64, 256), ("no-classes", "classes"),
                ("zero", "sparse", "dense"), ("aligned32", "offset2-classes1"))}


def parse_bench(text, kind):
    result = {}
    for line in text.splitlines():
        if not line.startswith("Benchmark"):
            continue
        m = re.fullmatch(r"(Benchmark\S+)\s+\d+\s+([\d.eE+\-]+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op\s*", line)
        assert m, ("unparsed benchmark", line)
        name, ns, byte_count, allocs = m.groups()
        assert name not in result and float(ns) > 0
        assert int(byte_count) == 0 and int(allocs) == 0, line
        result[name] = float(ns)
    assert set(result) == expected_names(kind), (kind, sorted(set(result) ^ expected_names(kind)))
    return result


def semantic(record):
    answer = {k: v for k, v in record.items() if k not in IGNORED}
    assert len(answer) == 22, sorted(answer)
    return answer


def instrument(source):
    path = source / QUANT
    text = path.read_text()
    marker = "classes []byte) int {\n"
    assert text.count(marker) == 1
    text = text.replace(marker, marker + "\tfpGuardTraceCount(0, n)\n", 1)
    marker = "&& fp16WindowsDisjoint(coeff, iscan, qcoeff, dqcoeff, classes, n) {\n"
    assert text.count(marker) == 1
    text = text.replace(marker, marker + "\t\tfpGuardTraceCount(1, n)\n", 1)
    marker = "\t\t\treturn quantizeFPBlock32AVX512("
    assert text.count(marker) == 1
    text = text.replace(marker, "\t\t\tfpGuardTraceCount(2, n)\n" + marker, 1)
    path.write_text(text)
    (source / "internal/pixel/fp_guard_trace_diagnostic_amd64.go").write_text(TRACE_SOURCE)
    main = source / "cmd/govpx-bench/main.go"
    text = main.read_text()
    marker = 'import "github.com/thesyncim/govpx/cmd/govpx-bench/benchcmd"'
    assert text.count(marker) == 1 and text.count("\tbenchcmd.Main()") == 1
    text = text.replace(marker, 'import ("github.com/thesyncim/govpx/cmd/govpx-bench/benchcmd"; "github.com/thesyncim/govpx/internal/pixel")')
    main.write_text(text.replace("\tbenchcmd.Main()", "\tbenchcmd.Main()\n\tpixel.FPGuardTraceWrite()"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("head_ref")
    parser.add_argument("base_ref")
    parser.add_argument("output_dir")
    parser.add_argument("--profile-passes", type=int, default=24)
    args = parser.parse_args()
    assert platform.system() == "Linux" and platform.machine() == "x86_64", "native Linux/x64 required; Rosetta is correctness-only"
    assert os.environ.get("GOVPX_NATIVE_FP_GUARD_BENCH") == "1", "explicit native timing opt-in required"
    assert 1 <= args.profile_passes <= 48
    root = Path(subprocess.check_output(["git", "rev-parse", "--show-toplevel"], text=True).strip())
    out = Path(args.output_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    assert not list(out.iterdir()), "output must be empty; preserve earlier evidence"
    wrapper = str(root / "scripts/go.sh")
    env = os.environ.copy()
    env.update(GOTOOLCHAIN="local", GOEXPERIMENT="simd", GOOS="linux", GOARCH="amd64",
               GOAMD64="v1", GOMAXPROCS="1", CGO_ENABLED="1", GOFLAGS="-p=2", GODEBUG="",
               GOVPX_REQUIRE_SIMD="1", GOVPX_REQUIRE_FP32_NATIVE="0", GOVPX_REQUIRE_FP32_OFF="0")
    commands = []
    phase = "environment"

    def run(argv, filename, extra=None, raw=False):
        target = out / filename
        target.parent.mkdir(parents=True, exist_ok=True)
        rec = {"argv": [str(x) for x in argv], "start_utc": now(), "output": filename,
               "environment_overrides": extra or {}}
        with target.open("wb") as stdout, target.with_suffix(target.suffix + ".stderr").open("wb") as stderr:
            proc = subprocess.run(rec["argv"], cwd=root, env=env | (extra or {}), stdout=stdout, stderr=stderr)
        rec.update(end_utc=now(), exit_code=proc.returncode)
        commands.append(rec)
        (out / "commands.json").write_text(json.dumps(commands, indent=2) + "\n")
        assert proc.returncode == 0, (argv, target)
        return target.read_bytes() if raw else target.read_text()

    def go(source, argv, filename, extra=None):
        return run([wrapper, "-C", source, *argv], filename, extra)

    try:
        run(["uname", "-a"], "uname.txt")
        run(["lscpu"], "lscpu.txt")
        version = run([wrapper, "env", "GOVERSION"], "goversion.txt").strip()
        assert version == "go1.27.2", version
        cache = run([wrapper, "env", "GOCACHE"], "gocache.txt").strip()
        assert ".codex/worktrees" not in cache
        assert run(["objdump", "--version"], "objdump-version.txt").startswith("GNU objdump")
        commits = {v: run(["git", "rev-parse", "--verify", "--end-of-options", ref + "^{commit}"], v + "-commit.txt").strip()
                   for v, ref in (("parent", args.base_ref), ("current", args.head_ref))}
        assert all(re.fullmatch(r"[0-9a-f]{40}", x) for x in commits.values())
        with tempfile.TemporaryDirectory(prefix="govpx-fp-guard-") as temporary:
            scratch = Path(temporary)
            sources = {v: scratch / v for v in commits}
            for v, source in sources.items():
                source.mkdir()
                archive = subprocess.check_output(["git", "archive", commits[v]], cwd=root)
                with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
                    assert all(not Path(m.name).is_absolute() and ".." not in Path(m.name).parts for m in tar.getmembers())
                    tar.extractall(source)
            old, new = (sources[v] / QUANT for v in ("parent", "current"))
            assert old.read_text().count(OLD_GUARD) == 1
            assert old.read_text().replace(OLD_GUARD, NEW_GUARD) == new.read_text(), "quantizer changes exceed the isolated guard reorder"
            for fixture in FIXTURES:
                assert (sources["parent"] / fixture).read_bytes() == (sources["current"] / fixture).read_bytes()
            bindings = {"commits": commits, "PGO": "off", "CGO_ENABLED": 1, "GOMAXPROCS": 1,
                        "driver_sha256": sha(__file__), "variants": {}}
            bins = {}
            phase = "build-and-correctness"
            for v, source in sources.items():
                bins[v] = {kind: scratch / (v + "-" + kind) for kind in ("pixel", "encoder", "whole")}
                for kind, package in (("pixel", "./internal/pixel"), ("encoder", "./internal/vp9/encoder")):
                    go(source, ["test", "-pgo=off", "-c", "-o", bins[v][kind], package], f"build/{v}-{kind}.txt")
                go(source, ["build", "-pgo=off", "-o", bins[v]["whole"], "./cmd/govpx-bench"], f"build/{v}-whole.txt")
                # The exact files selected for the Linux production build must differ only at the guard.
                listing = go(source, ["list", "-deps", "-json", "./cmd/govpx-bench"], f"build/{v}-deps.json")
                decoder = json.JSONDecoder(); used = {}; rest = listing
                while rest.strip():
                    obj, count = decoder.raw_decode(rest.lstrip()); rest = rest.lstrip()[count:]
                    if obj.get("Module", {}).get("Path") != "github.com/thesyncim/govpx": continue
                    for name in obj.get("GoFiles", []) + obj.get("CgoFiles", []):
                        f = Path(obj["Dir"]) / name
                        used[str(f.relative_to(source))] = sha(f)
                all_go = {str(f.relative_to(source)): sha(f) for f in sorted(source.rglob("*.go"))}
                bindings["variants"][v] = {"all_go_sha256": all_go, "compiled_production_go_sha256": used,
                    "binaries": {k: {"path": str(f), "sha256": sha(f)} for k, f in bins[v].items()}}
                for rel in (QUANT, "internal/pixel/quantize_fp32_avx512_amd64.go", *FIXTURES):
                    dest = out / "sources" / v / (rel + ".txt"); dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source / rel, dest)
            a, b = (bindings["variants"][v]["compiled_production_go_sha256"] for v in ("parent", "current"))
            assert a.keys() == b.keys() and [k for k in a if a[k] != b[k]] == [QUANT], "other compiled production source changed"
            probes = {}
            for v in sources:
                text = run([bins[v]["pixel"], "-test.run=^Test(FP32PublicHost|FP32ActualFeature|FP16Selected)$", "-test.count=1", "-test.v"], f"correctness/{v}-host.txt")
                match = re.search(r"FP32PublicHost AVX512=(true|false) AVX2=(true|false) Enabled=(true|false)", text)
                assert match and match.group(2, 3) == ("true", "true"), "actual AVX2 SIMD required"
                probes[v] = match.groups()
            assert probes["parent"] == probes["current"]
            wide = probes["current"][0] == "true"
            bindings["actual_SDK_features"] = {"AVX512": wide, "AVX2": True, "Enabled": True}
            bindings["selected_AVX512_validation"] = "required" if wide else "unavailable; actual AVX2 path only"
            (out / "binding.json").write_text(json.dumps(bindings, indent=2) + "\n")
            for v, source in sources.items():
                selected = {"GOVPX_REQUIRE_FP32_NATIVE": "1" if wide else "0"}
                for race in (False, True):
                    flags = ["-race", "-gcflags=all=-d=checkptr=2"] if race else []
                    go(source, ["test", "-pgo=off", *flags, "./internal/pixel", "./internal/vp9/encoder", "-run=^Test(FP16|FP32|QuantizeFP)", "-count=1", "-v"], f"correctness/{v}-selected-race{race}.txt", selected)
                for mode, extra in (("512-off", {"GODEBUG": "cpu.avx512f=off", "GOVPX_REQUIRE_FP32_OFF": "1"}),
                                    ("avx-off", {"GODEBUG": "cpu.avx=off,cpu.avx2=off,cpu.avx512f=off", "GOVPX_REQUIRE_SIMD": "0", "GOVPX_REQUIRE_FP16_AVX_OFF": "1", "GOVPX_REQUIRE_FP32_OFF": "1"})):
                    run([bins[v]["pixel"], "-test.run=^Test(FP16|FP32)", "-test.count=1", "-test.v"], f"correctness/{v}-{mode}.txt", extra)
                for kind, bench in (("pixel", "BenchmarkFP32PublicOptionalNative"), ("encoder", "BenchmarkVP9FP16Native")):
                    text = run([bins[v][kind], "-test.run=^$", "-test.bench=^" + bench + "$", "-test.benchtime=1x", "-test.cpu=1", "-test.count=1", "-test.benchmem"], f"preflight/{v}-{kind}.txt")
                    parse_bench(text, kind)
            phase = "native-timing"
            components = {}; whole = {v: [] for v in sources}
            whole_args = ["-codec=vp9", "-width=320", "-height=180", "-frames=120", "-fps=30", "-bitrate=500", "-mode=realtime", "-cpu-used=8", "-threads=1", "-encode-only", "-auto-libvpx=false", "-format=json"]
            orders = [["parent", "current"], ["current", "parent"]] * 3
            for number, order in enumerate(orders, 1):
                for v in order:
                    for kind, bench in (("pixel", "BenchmarkFP32PublicOptionalNative"), ("encoder", "BenchmarkVP9FP16Native")):
                        text = run([bins[v][kind], "-test.run=^$", "-test.bench=^" + bench + "$", "-test.benchtime=100ms", "-test.cpu=1", "-test.count=1", "-test.benchmem"], f"timed/r{number}-{v}-{kind}.txt")
                        components[number, v, kind] = parse_bench(text, kind)
                    whole[v].append(json.loads(run([bins[v]["whole"], *whole_args], f"timed/r{number}-{v}-whole.json")))
                print("native pair", number, "PASS", now(), flush=True)
            reference = semantic(whole["parent"][0])
            assert all(semantic(x) == reference for xs in whole.values() for x in xs)
            summary = {"orders": orders, "component_rows": 1008, "excluded_preflight_rows": 168,
                       "actual_SDK_features": bindings["actual_SDK_features"], "components": {}, "whole": {}}
            for kind in ("pixel", "encoder"):
                for name in sorted(expected_names(kind)):
                    ns = {v: [components[i, v, kind][name] for i in range(1, 7)] for v in sources}
                    ratios = [x / y for x, y in zip(ns["parent"], ns["current"])]
                    summary["components"][name] = {"raw_ns": ns, "speedup": statistics.median(ns["parent"]) / statistics.median(ns["current"]),
                        "paired_speedups": ratios, "slower_pairs": sum(x < 1 for x in ratios), "zero_allocations": True}
            ns = {v: [x["ns_per_frame"] for x in xs] for v, xs in whole.items()}
            summary["whole"] = {"ns_per_frame": ns, "median_time_change_pct": 100 * (statistics.median(ns["current"]) / statistics.median(ns["parent"]) - 1),
                "paired_time_change_pct": [100 * (x / y - 1) for x, y in zip(ns["current"], ns["parent"])],
                "semantic_fields": reference, "allocations_per_frame": {v: [x["allocs_per_frame"] for x in xs] for v, xs in whole.items()}}
            (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
            print("END all uninstrumented timing", now(), flush=True)
            phase = "diagnostic-profiles-and-codegen"
            profiles = {v: [] for v in sources}
            for number in range(1, args.profile_passes + 1):
                for v in orders[(number - 1) % 2]:
                    profile = out / f"profiles/{v}-{number}.pgo"; profile.parent.mkdir(exist_ok=True)
                    output = json.loads(run([bins[v]["whole"], *whole_args, "-cpuprofile=" + str(profile)], f"profiles/{v}-{number}.json"))
                    assert semantic(output) == reference
                    profiles[v].append(profile)
            for v in sources:
                merged = out / f"profiles/{v}-merged.pgo"
                run([wrapper, "tool", "pprof", "-proto", bins[v]["whole"], *profiles[v]], str(merged.relative_to(out)), raw=True)
                for label, flags in (("top", ["-top", "-nodecount=0"]), ("cumulative", ["-top", "-cum", "-nodecount=0"]), ("raw", ["-raw"]), ("quantize-lines", ["-list=quantizeFPBlockSIMD"])):
                    run([wrapper, "tool", "pprof", *flags, bins[v]["whole"], merged], f"profiles/{v}-{label}.txt")
                for kind in ("pixel", "encoder", "whole"):
                    nm = run([wrapper, "tool", "nm", "-size", "-sort=address", bins[v][kind]], f"codegen/{v}-{kind}-symbols.txt")
                    run([wrapper, "version", "-m", bins[v][kind]], f"codegen/{v}-{kind}-buildinfo.txt")
                    owners = []
                    for line in nm.splitlines():
                        m = re.fullmatch(r"\s*([0-9a-fA-F]+)\s+(\d+)\s+[Tt]\s+(\S+)\s*", line)
                        if m and re.search(r"\.(QuantizeFPBlock|quantizeFPBlockSIMD|quantizeFPBlock32AVX512|fp16WindowsDisjoint|BenchmarkFP32PublicOptionalNative(?:\.func1)?|BenchmarkVP9FP16Native(?:\.func1)?)$", m[3]):
                            owners.append({"symbol": m[3], "address": int(m[1], 16), "size": int(m[2])})
                            run(["objdump", "-d", "--disassemble=" + m[3], bins[v][kind]], f"codegen/{v}-{kind}-{m[3].rsplit('/', 1)[-1]}.asm.txt")
                    assert any(x["symbol"].endswith(".quantizeFPBlockSIMD") for x in owners)
                    (out / f"codegen/{v}-{kind}-owners.json").write_text(json.dumps(owners, indent=2) + "\n")
            phase = "excluded-dispatch-counts"
            counts = {}
            for v, source in sources.items():
                instrument(source)
                trace = scratch / (v + "-trace")
                go(source, ["build", "-pgo=off", "-o", trace, "./cmd/govpx-bench"], f"counts/{v}-build.txt")
                count_path = out / f"counts/{v}.json"
                output = json.loads(run([trace, *whole_args], f"counts/{v}-excluded-output.json", {"GOVPX_FP_GUARD_TRACE": str(count_path)}))
                assert semantic(output) == reference
                counts[v] = json.loads(count_path.read_text())
                assert sum(counts[v]["eligible_avx2"].values()) > 0
                for rel in (QUANT, "internal/pixel/fp_guard_trace_diagnostic_amd64.go", "cmd/govpx-bench/main.go"):
                    dest = out / "counts" / v / (rel + ".txt"); dest.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(source / rel, dest)
                (out / f"counts/{v}-binding.json").write_text(json.dumps({"binary_sha256": sha(trace), "all_go_sha256": {str(f.relative_to(source)): sha(f) for f in sorted(source.rglob("*.go"))}, "throughput_excluded": True}, indent=2) + "\n")
            assert counts["parent"] == counts["current"], "dispatch semantics differ"
            skipped = sum(count for n, count in counts["current"]["eligible_avx2"].items() if int(n) < 256 or int(n) % 32)
            (out / "counts/interpretation.json").write_text(json.dumps({"AVX512_queries_avoided_by_size_rejection": skipped,
                "counting_workload": "same 320x180/120 inputs/500kbps/CPU8/one-thread workload", "throughput_excluded": True,
                "limit": "Counts and profiles do not by themselves establish the historical +2.264% cause."}, indent=2) + "\n")
            phase = "complete"
            print("PASS exact isolated guard comparison; all slower controls retained", now(), flush=True)
    finally:
        (out / "status.json").write_text(json.dumps({"phase": phase, "complete": phase == "complete", "time": now()}, indent=2) + "\n")
        manifest = {str(f.relative_to(out)): sha(f) for f in sorted(out.rglob("*")) if f.is_file() and f.name != "MANIFEST.json"}
        (out / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()

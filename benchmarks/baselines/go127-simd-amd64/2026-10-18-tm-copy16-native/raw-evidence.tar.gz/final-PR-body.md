ARM true-motion prediction now uses saturating byte SIMD and reuses disjoint reference packets across rows. Aliased inputs retain sequential reads/stores; incomplete or unsupported windows retain the original fallback and partial-panic state. The amd64 Copy16 helper carries row pointers through its loop. No dependencies or README changes.

Native ARM evidence (Apple M4 Max, Go 1.27.2, GOMAXPROCS=1, PGO off, uniform CGO):

- First byte-row implementation versus #45: TM8 2.105–2.170×, TM16 4.669–4.734×; all 108 target pairs exceed 1.5×.
- Final left-packet implementation versus the frozen first winner: TM8 another 1.653–1.676×, all 54 pairs above 1.607×; TM16 1.423–1.481×. Separate windows; gains are not multiplied.
- VP8 720p whole-codec: +0.321% time versus its parent, mixed pairs; +9.527% versus old assembly. The ARM codec gap remains open. All 22 semantic fields match and allocations are zero; matching statistics do not establish bitstream identity.

Native x64 evidence on exact `46a08f8e` (Intel Xeon Platinum 8573C, same Go/GOMAXPROCS/PGO settings):

- Ordinary disjoint Copy16 pitch16, pitch1312/1320 and pitch17/31: root caller 1.707–1.775× versus parent; DSP caller 2.283–2.411×. All 36 paired gains exceed 1.670×. All 16 Copy16 cases are retained. Seven of eight cases improve for each caller; the identical-buffer, zero-stride control regresses in every pair: root 0.510× and DSP 0.442× parent throughput. A semantic no-op repair is reserved for the next native-tested revision. Old Copy16 is compiler-generated Go, not handwritten assembly.
- Whole VP8 720p −0.041%, VP9 320p +0.142%, VP9 720p +0.664% time versus parent, with mixed pairs. Against same-run old assembly: −28.415%, −44.321%, −54.870%; every pair is faster. No new whole-codec win is claimed.
- All 498 kernel cases × six rounds × three variants (8,964 samples) allocate zero. All 22 public semantic fields and every public/profile allocation sample match. All 482 non-Copy16 controls remain in the evidence, including 319 slower medians and 41 cases slower in every pair; unchanged source does not establish a cause.

Separate focused SSE8 runner (EPYC 7763): all nine pointer-case medians regress 3.47–6.53% versus parent; four regress in every pair. Overall 15/36 public medians improve, 20 regress and one ties; 34/36 beat old assembly. These regressions are retained, with no cross-runner causal attribution.

Separate optimized-libvpx v1.16.0 runner (EPYC 9V74): fixed-speed VP8 Go/C time ratio 2.283× with matching measured payload, frame/drop counts and decoded quality across timed/quality passes. CPU-used −8 with quantizer bounds is not fixed quantization. Adaptive VP8 and VP9 have unequal quality/output work and remain diagnostic comparisons. Timers use codec-internal statistics; no timed bitstream identity claim.

Validation: all four CI checks pass, full Go suite, ARM race/checkptr, SIMD/scalar/purego build selections, no handwritten assembly, refreshed PGO/pre-commit, frozen arithmetic/alias/canary/panic-state oracles and common fixtures on all three pinned references. Translated amd64 selected/AVX-off checks establish correctness only. Native artifacts verify 77 source hashes, 31 common fixture overlays and 338 excluded one-shot oracles. Raw logs, controls, allocation evidence and prior checkpoint results are preserved outside README files. Correctness-verified kernel wins are retained independently of overall performance.

Checks: [exhaustive](https://github.com/thesyncim/govpx/actions/runs/39101922513), [focused SSE8](https://github.com/thesyncim/govpx/actions/runs/39101922516), [native and optimized libvpx](https://github.com/thesyncim/govpx/actions/runs/39101922555).

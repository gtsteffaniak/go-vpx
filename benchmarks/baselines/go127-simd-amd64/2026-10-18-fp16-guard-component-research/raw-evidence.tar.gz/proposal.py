import pathlib,subprocess,difflib,json,hashlib
w=pathlib.Path('/private/tmp/govpx-fp16-guard-component');root=pathlib.Path('/Users/thesyncim/GolandProjects/govpx');overlay=w/'overlay';p=overlay/'internal/pixel';p.mkdir(parents=True,exist_ok=True);(p/'fp16_guard_component_native_test.go').write_bytes((w/'fp16_guard_component_native_test.go').read_bytes());p=overlay/'scripts';p.mkdir(exist_ok=True);(p/'benchmark-fp16-guard-diagnostic.sh').write_bytes((w/'benchmark-fp16-guard-diagnostic.sh').read_bytes());(p/'benchmark-fp16-guard-diagnostic.sh').chmod(0o755)
old=subprocess.check_output(['git','show','46a08f8e6eb03f6ee4549d975384bd6c952a81fa:scripts/benchmark-amd64.sh'],cwd=root,text=True)
hook='''# Diagnostic guard component only, after all unchanged codec timing/profile work.
# One current-only binary; frozen helper candidates stay test-only. References,
# common overlays and production guard selection remain unchanged.
scripts/go.sh test -pgo=off -c -o "$output_dir/simd-fp16-guard.test" ./internal/pixel
scripts/benchmark-fp16-guard-diagnostic.sh "$output_dir/simd-fp16-guard.test" "$output_dir/fp16-guard-component.txt"

'''
anchor='# Keep artifacts compact; raw text/JSON and environment details are sufficient\n'
assert old.count(anchor)==1
new=old.replace(anchor,hook+anchor);assert new.replace(hook,'')==old
(p/'benchmark-amd64.sh').write_text(new)
(w/'proposal.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/scripts/benchmark-amd64.sh',tofile='b/scripts/benchmark-amd64.sh')))
for f in [p/'benchmark-amd64.sh',p/'benchmark-fp16-guard-diagnostic.sh']:subprocess.run(['sh','-n',str(f)],check=True)
source=(w/'fp16_guard_component_native_test.go').read_text();scope=dict(base='46a08f8e6eb03f6ee4549d975384bd6c952a81fa',private_only=True,production_changes=0,old_full_statements_exact_after_removing_hook=True,old_cases_per_variant=498,old_threeway_six_samples=8964,common_overlays=31,extra_current_only_test_overlay=1,extra_script=1,extra_current_only_test_binary=1,extra_raw_files=['fp16-guard-component.txt'],old_raw_files=91,proposed_raw_files=92,component_case_geometries=22,component_guards=3,component_names=66,component_excluded_one_shots=66,component_six_balanced_samples=396,disjoint_cases=12,overlap_decline_controls=10,performance_claim='none; native Linux-only future diagnostic',new_fixture_sha256=hashlib.sha256(source.encode()).hexdigest(),native_timeout_minutes=45,timeout_note='No timeout increase proposed; approximately45seconds additional timed work plus a cached pixel compile, no speedthreshold.')
(w/'scope.json').write_text(json.dumps(scope,indent=2));print(json.dumps(scope,indent=2))

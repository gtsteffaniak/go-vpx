
/private/tmp/govpx-fp16-guard-component/validation/linux.test:	file format elf64-x86-64

Disassembly of section .text:

000000000059acc0 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1>:
  59acc0: 4c 8d a4 24 40 fe ff ff      	leaq	-0x1c0(%rsp), %r12
  59acc8: 4d 3b 66 10                  	cmpq	0x10(%r14), %r12
  59accc: 0f 86 5b 0a 00 00            	jbe	0x59b72d <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0xa6d>
  59acd2: 55                           	pushq	%rbp
  59acd3: 48 89 e5                     	movq	%rsp, %rbp
  59acd6: 48 81 ec 38 02 00 00         	subq	$0x238, %rsp            # imm = 0x238
  59acdd: 48 89 84 24 48 02 00 00      	movq	%rax, 0x248(%rsp)
  59ace5: 48 89 94 24 88 01 00 00      	movq	%rdx, 0x188(%rsp)
  59aced: 48 8b 42 08                  	movq	0x8(%rdx), %rax
  59acf1: 48 8b 5a 10                  	movq	0x10(%rdx), %rbx
  59acf5: 48 8b 4a 18                  	movq	0x18(%rdx), %rcx
  59acf9: 48 8b 7a 20                  	movq	0x20(%rdx), %rdi
  59acfd: 48 8b 72 28                  	movq	0x28(%rdx), %rsi
  59ad01: 4c 8b 42 30                  	movq	0x30(%rdx), %r8
  59ad05: 48 8b 52 38                  	movq	0x38(%rdx), %rdx
  59ad09: 48 89 94 24 30 02 00 00      	movq	%rdx, 0x230(%rsp)
  59ad11: e8 ea 84 fd ff               	callq	0x573200 <github.com/thesyncim/govpx/internal/pixel.fp16GuardProbeMake>
  59ad16: 48 8b 1c 24                  	movq	(%rsp), %rbx
  59ad1a: 48 8b 7c 24 08               	movq	0x8(%rsp), %rdi
  59ad1f: 48 8d 94 24 e8 00 00 00      	leaq	0xe8(%rsp), %rdx
  59ad27: 49 89 e1                     	movq	%rsp, %r9
  59ad2a: 45 0f 10 31                  	movups	(%r9), %xmm14
  59ad2e: 44 0f 11 32                  	movups	%xmm14, (%rdx)
  59ad32: 45 0f 10 71 10               	movups	0x10(%r9), %xmm14
  59ad37: 44 0f 11 72 10               	movups	%xmm14, 0x10(%rdx)
  59ad3c: 45 0f 10 71 20               	movups	0x20(%r9), %xmm14
  59ad41: 44 0f 11 72 20               	movups	%xmm14, 0x20(%rdx)
  59ad46: 45 0f 10 71 30               	movups	0x30(%r9), %xmm14
  59ad4b: 44 0f 11 72 30               	movups	%xmm14, 0x30(%rdx)
  59ad50: 45 0f 10 71 40               	movups	0x40(%r9), %xmm14
  59ad55: 44 0f 11 72 40               	movups	%xmm14, 0x40(%rdx)
  59ad5a: 45 0f 10 71 50               	movups	0x50(%r9), %xmm14
  59ad5f: 44 0f 11 72 50               	movups	%xmm14, 0x50(%rdx)
  59ad64: 45 0f 10 71 60               	movups	0x60(%r9), %xmm14
  59ad69: 44 0f 11 72 60               	movups	%xmm14, 0x60(%rdx)
  59ad6e: 45 0f 10 71 70               	movups	0x70(%r9), %xmm14
  59ad73: 44 0f 11 72 70               	movups	%xmm14, 0x70(%rdx)
  59ad78: 45 0f 10 b1 80 00 00 00      	movups	0x80(%r9), %xmm14
  59ad80: 44 0f 11 b2 80 00 00 00      	movups	%xmm14, 0x80(%rdx)
  59ad88: 48 85 db                     	testq	%rbx, %rbx
  59ad8b: 0f 84 85 00 00 00            	je	0x59ae16 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x156>
  59ad91: 48 85 ff                     	testq	%rdi, %rdi
  59ad94: 75 0c                        	jne	0x59ada2 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0xe2>
  59ad96: 48 8d 84 24 c8 00 00 00      	leaq	0xc8(%rsp), %rax
  59ad9e: 31 c9                        	xorl	%ecx, %ecx
  59ada0: eb 3f                        	jmp	0x59ade1 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x121>
  59ada2: 48 89 9c 24 80 01 00 00      	movq	%rbx, 0x180(%rsp)
  59adaa: 48 89 bc 24 d8 00 00 00      	movq	%rdi, 0xd8(%rsp)
  59adb2: 48 8d 84 24 c8 00 00 00      	leaq	0xc8(%rsp), %rax
  59adba: 48 89 fb                     	movq	%rdi, %rbx
  59adbd: 31 c9                        	xorl	%ecx, %ecx
  59adbf: 48 8d 35 12 12 1c 00         	leaq	0x1c1212(%rip), %rsi    # 0x75bfd8 <type:*+0x2b650>
  59adc6: e8 b5 da ee ff               	callq	0x488880 <runtime.growslice>
  59adcb: 48 8b bc 24 d8 00 00 00      	movq	0xd8(%rsp), %rdi
  59add3: 49 89 e1                     	movq	%rsp, %r9
  59add6: 48 89 d9                     	movq	%rbx, %rcx
  59add9: 48 8b 9c 24 80 01 00 00      	movq	0x180(%rsp), %rbx
  59ade1: 48 89 8c 24 c8 00 00 00      	movq	%rcx, 0xc8(%rsp)
  59ade9: 48 89 84 24 e0 00 00 00      	movq	%rax, 0xe0(%rsp)
  59adf1: 48 89 f9                     	movq	%rdi, %rcx
  59adf4: e8 a7 2a ef ff               	callq	0x48d8a0 <runtime.memmove>
  59adf9: 48 8d 94 24 e8 00 00 00      	leaq	0xe8(%rsp), %rdx
  59ae01: 49 89 e1                     	movq	%rsp, %r9
  59ae04: 48 8b 84 24 c8 00 00 00      	movq	0xc8(%rsp), %rax
  59ae0c: 48 8b 8c 24 e0 00 00 00      	movq	0xe0(%rsp), %rcx
  59ae14: eb 04                        	jmp	0x59ae1a <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x15a>
  59ae16: 31 c0                        	xorl	%eax, %eax
  59ae18: 31 c9                        	xorl	%ecx, %ecx
  59ae1a: 48 89 84 24 c8 00 00 00      	movq	%rax, 0xc8(%rsp)
  59ae22: 48 89 8c 24 e0 00 00 00      	movq	%rcx, 0xe0(%rsp)
  59ae2a: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
  59ae32: 48 8b 41 18                  	movq	0x18(%rcx), %rax
  59ae36: 44 0f 10 32                  	movups	(%rdx), %xmm14
  59ae3a: 45 0f 11 31                  	movups	%xmm14, (%r9)
  59ae3e: 44 0f 10 72 10               	movups	0x10(%rdx), %xmm14
  59ae43: 45 0f 11 71 10               	movups	%xmm14, 0x10(%r9)
  59ae48: 44 0f 10 72 20               	movups	0x20(%rdx), %xmm14
  59ae4d: 45 0f 11 71 20               	movups	%xmm14, 0x20(%r9)
  59ae52: 44 0f 10 72 30               	movups	0x30(%rdx), %xmm14
  59ae57: 45 0f 11 71 30               	movups	%xmm14, 0x30(%r9)
  59ae5c: 44 0f 10 72 40               	movups	0x40(%rdx), %xmm14
  59ae61: 45 0f 11 71 40               	movups	%xmm14, 0x40(%r9)
  59ae66: 44 0f 10 72 50               	movups	0x50(%rdx), %xmm14
  59ae6b: 45 0f 11 71 50               	movups	%xmm14, 0x50(%r9)
  59ae70: 44 0f 10 72 60               	movups	0x60(%rdx), %xmm14
  59ae75: 45 0f 11 71 60               	movups	%xmm14, 0x60(%r9)
  59ae7a: 44 0f 10 72 70               	movups	0x70(%rdx), %xmm14
  59ae7f: 45 0f 11 71 70               	movups	%xmm14, 0x70(%r9)
  59ae84: 44 0f 10 b2 80 00 00 00      	movups	0x80(%rdx), %xmm14
  59ae8c: 45 0f 11 b1 80 00 00 00      	movups	%xmm14, 0x80(%r9)
  59ae94: e8 e7 87 fd ff               	callq	0x573680 <github.com/thesyncim/govpx/internal/pixel.fp16GuardProbeOracle>
  59ae99: 88 84 24 c6 00 00 00         	movb	%al, 0xc6(%rsp)
  59aea0: c6 84 24 c7 00 00 00 00      	movb	$0x0, 0xc7(%rsp)
  59aea8: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  59aeb0: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
  59aeb8: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  59aec0: 48 89 9c 24 d8 00 00 00      	movq	%rbx, 0xd8(%rsp)
  59aec8: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  59aed0: 48 89 8c 24 d0 00 00 00      	movq	%rcx, 0xd0(%rsp)
  59aed8: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  59aee0: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  59aee8: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  59aef0: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  59aef8: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  59af00: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  59af08: 48 8b 94 24 48 01 00 00      	movq	0x148(%rsp), %rdx
  59af10: 4c 8b a4 24 50 01 00 00      	movq	0x150(%rsp), %r12
  59af18: 4c 8b ac 24 58 01 00 00      	movq	0x158(%rsp), %r13
  59af20: 4c 8b bc 24 60 01 00 00      	movq	0x160(%rsp), %r15
  59af28: 48 8b 84 24 68 01 00 00      	movq	0x168(%rsp), %rax
  59af30: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
  59af38: 48 8b 9c 24 88 01 00 00      	movq	0x188(%rsp), %rbx
  59af40: 48 8b 5b 18                  	movq	0x18(%rbx), %rbx
  59af44: 48 89 14 24                  	movq	%rdx, (%rsp)
  59af48: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  59af4d: 4c 89 6c 24 10               	movq	%r13, 0x10(%rsp)
  59af52: 4c 89 7c 24 18               	movq	%r15, 0x18(%rsp)
  59af57: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
  59af5c: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
  59af61: 48 89 5c 24 30               	movq	%rbx, 0x30(%rsp)
  59af66: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
  59af6e: 48 8b 9c 24 d8 00 00 00      	movq	0xd8(%rsp), %rbx
  59af76: 48 8b 8c 24 d0 00 00 00      	movq	0xd0(%rsp), %rcx
  59af7e: 66 90                        	nop
  59af80: e8 9b ad fc ff               	callq	0x565d20 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>
  59af85: 0f b6 8c 24 c6 00 00 00      	movzbl	0xc6(%rsp), %ecx
  59af8d: 38 c8                        	cmpb	%cl, %al
  59af8f: 74 0b                        	je	0x59af9c <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x2dc>
  59af91: 41 bc 01 00 00 00            	movl	$0x1, %r12d
  59af97: e9 e4 01 00 00               	jmp	0x59b180 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x4c0>
  59af9c: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  59afa4: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
  59afac: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  59afb4: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  59afbc: 48 89 8c 24 d8 00 00 00      	movq	%rcx, 0xd8(%rsp)
  59afc4: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  59afcc: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  59afd4: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  59afdc: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  59afe4: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  59afec: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  59aff4: 48 8b 94 24 48 01 00 00      	movq	0x148(%rsp), %rdx
  59affc: 4c 8b a4 24 50 01 00 00      	movq	0x150(%rsp), %r12
  59b004: 4c 8b ac 24 58 01 00 00      	movq	0x158(%rsp), %r13
  59b00c: 4c 8b bc 24 60 01 00 00      	movq	0x160(%rsp), %r15
  59b014: 4c 89 bc 24 80 01 00 00      	movq	%r15, 0x180(%rsp)
  59b01c: 48 8b 84 24 68 01 00 00      	movq	0x168(%rsp), %rax
  59b024: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
  59b02c: 4c 8b bc 24 88 01 00 00      	movq	0x188(%rsp), %r15
  59b034: 4d 8b 7f 18                  	movq	0x18(%r15), %r15
  59b038: 48 89 14 24                  	movq	%rdx, (%rsp)
  59b03c: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  59b041: 4c 89 6c 24 10               	movq	%r13, 0x10(%rsp)
  59b046: 48 8b 94 24 80 01 00 00      	movq	0x180(%rsp), %rdx
  59b04e: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  59b053: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
  59b058: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
  59b05d: 4c 89 7c 24 30               	movq	%r15, 0x30(%rsp)
  59b062: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
  59b06a: 48 8b 8c 24 d8 00 00 00      	movq	0xd8(%rsp), %rcx
  59b072: e8 29 79 fd ff               	callq	0x5729a0 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe>
  59b077: 0f b6 94 24 c6 00 00 00      	movzbl	0xc6(%rsp), %edx
  59b07f: 90                           	nop
  59b080: 38 d0                        	cmpb	%dl, %al
  59b082: 74 0d                        	je	0x59b091 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x3d1>
  59b084: 89 d1                        	movl	%edx, %ecx
  59b086: 41 bc 01 00 00 00            	movl	$0x1, %r12d
  59b08c: e9 ef 00 00 00               	jmp	0x59b180 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x4c0>
  59b091: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  59b099: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
  59b0a1: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  59b0a9: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  59b0b1: 48 89 8c 24 d8 00 00 00      	movq	%rcx, 0xd8(%rsp)
  59b0b9: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  59b0c1: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  59b0c9: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  59b0d1: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  59b0d9: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  59b0e1: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  59b0e9: 48 8b 94 24 48 01 00 00      	movq	0x148(%rsp), %rdx
  59b0f1: 4c 8b a4 24 50 01 00 00      	movq	0x150(%rsp), %r12
  59b0f9: 4c 8b ac 24 58 01 00 00      	movq	0x158(%rsp), %r13
  59b101: 4c 8b bc 24 60 01 00 00      	movq	0x160(%rsp), %r15
  59b109: 4c 89 bc 24 80 01 00 00      	movq	%r15, 0x180(%rsp)
  59b111: 48 8b 84 24 68 01 00 00      	movq	0x168(%rsp), %rax
  59b119: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
  59b121: 4c 8b bc 24 88 01 00 00      	movq	0x188(%rsp), %r15
  59b129: 4d 8b 7f 18                  	movq	0x18(%r15), %r15
  59b12d: 48 89 14 24                  	movq	%rdx, (%rsp)
  59b131: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  59b136: 4c 89 6c 24 10               	movq	%r13, 0x10(%rsp)
  59b13b: 48 8b 94 24 80 01 00 00      	movq	0x180(%rsp), %rdx
  59b143: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  59b148: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
  59b14d: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
  59b152: 4c 89 7c 24 30               	movq	%r15, 0x30(%rsp)
  59b157: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
  59b15f: 48 8b 8c 24 d8 00 00 00      	movq	0xd8(%rsp), %rcx
  59b167: e8 54 79 fd ff               	callq	0x572ac0 <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe>
  59b16c: 0f b6 94 24 c6 00 00 00      	movzbl	0xc6(%rsp), %edx
  59b174: 38 d0                        	cmpb	%dl, %al
  59b176: 41 0f 95 c4                  	setne	%r12b
  59b17a: 89 d1                        	movl	%edx, %ecx
  59b17c: 0f 1f 40 00                  	nopl	(%rax)
  59b180: 45 84 e4                     	testb	%r12b, %r12b
  59b183: 74 48                        	je	0x59b1cd <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x50d>
  59b185: 48 8d 15 cc 0d 1c 00         	leaq	0x1c0dcc(%rip), %rdx    # 0x75bf58 <type:*+0x2b5d0>
  59b18c: 48 89 94 24 20 02 00 00      	movq	%rdx, 0x220(%rsp)
  59b194: 48 8d 15 95 78 02 00         	leaq	0x27895(%rip), %rdx     # 0x5c2a30 <internal/sync..dict.indirect[interface {},interface {}]+0x140>
  59b19b: 48 89 94 24 28 02 00 00      	movq	%rdx, 0x228(%rsp)
  59b1a3: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59b1ab: 84 00                        	testb	%al, (%rax)
  59b1ad: 48 8d 9c 24 20 02 00 00      	leaq	0x220(%rsp), %rbx
  59b1b5: b9 01 00 00 00               	movl	$0x1, %ecx
  59b1ba: 89 cf                        	movl	%ecx, %edi
  59b1bc: 0f 1f 40 00                  	nopl	(%rax)
  59b1c0: e8 bb dc f5 ff               	callq	0x4f8e80 <testing.(*common).Fatal>
  59b1c5: 0f b6 8c 24 c6 00 00 00      	movzbl	0xc6(%rsp), %ecx
  59b1cd: 90                           	nop
  59b1ce: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59b1d6: c6 80 52 02 00 00 01         	movb	$0x1, 0x252(%rax)
  59b1dd: 48 8b 94 24 30 02 00 00      	movq	0x230(%rsp), %rdx
  59b1e5: 4c 8b 62 08                  	movq	0x8(%rdx), %r12
  59b1e9: 48 8b 12                     	movq	(%rdx), %rdx
  59b1ec: 49 83 fc 06                  	cmpq	$0x6, %r12
  59b1f0: 75 2e                        	jne	0x59b220 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x560>
  59b1f2: 81 3a 70 61 72 65            	cmpl	$0x65726170, (%rdx)     # imm = 0x65726170
  59b1f8: 75 0c                        	jne	0x59b206 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x546>
  59b1fa: 66 81 7a 04 6e 74            	cmpw	$0x746e, 0x4(%rdx)      # imm = 0x746E
  59b200: 0f 84 d9 04 00 00            	je	0x59b6df <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0xa1f>
  59b206: 81 3a 73 69 6e 67            	cmpl	$0x676e6973, (%rdx)     # imm = 0x676E6973
  59b20c: 75 2b                        	jne	0x59b239 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x579>
  59b20e: 66 81 7a 04 6c 65            	cmpw	$0x656c, 0x4(%rdx)      # imm = 0x656C
  59b214: 0f 84 85 03 00 00            	je	0x59b59f <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x8df>
  59b21a: eb 1d                        	jmp	0x59b239 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x579>
  59b21c: 0f 1f 40 00                  	nopl	(%rax)
  59b220: 49 83 fc 08                  	cmpq	$0x8, %r12
  59b224: 75 13                        	jne	0x59b239 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x579>
  59b226: 49 bc 75 6e 72 6f 6c 6c 65 64	movabsq	$0x64656c6c6f726e75, %r12 # imm = 0x64656C6C6F726E75
  59b230: 4c 39 22                     	cmpq	%r12, (%rdx)
  59b233: 0f 84 2f 02 00 00            	je	0x59b468 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x7a8>
  59b239: 48 8d 15 18 0d 1c 00         	leaq	0x1c0d18(%rip), %rdx    # 0x75bf58 <type:*+0x2b5d0>
  59b240: 48 89 94 24 20 02 00 00      	movq	%rdx, 0x220(%rsp)
  59b248: 48 8d 15 f1 77 02 00         	leaq	0x277f1(%rip), %rdx     # 0x5c2a40 <internal/sync..dict.indirect[interface {},interface {}]+0x150>
  59b24f: 48 89 94 24 28 02 00 00      	movq	%rdx, 0x228(%rsp)
  59b257: 48 8d 9c 24 20 02 00 00      	leaq	0x220(%rsp), %rbx
  59b25f: b9 01 00 00 00               	movl	$0x1, %ecx
  59b264: 89 cf                        	movl	%ecx, %edi
  59b266: e8 15 dc f5 ff               	callq	0x4f8e80 <testing.(*common).Fatal>
  59b26b: 0f b6 94 24 c7 00 00 00      	movzbl	0xc7(%rsp), %edx
  59b273: 88 15 76 9d 22 00            	movb	%dl, 0x229d76(%rip)     # 0x7c4fef <github.com/thesyncim/govpx/internal/pixel.fp16GuardProbeSink>
  59b279: 0f b6 b4 24 c6 00 00 00      	movzbl	0xc6(%rsp), %esi
  59b281: 40 38 d6                     	cmpb	%dl, %sil
  59b284: 74 07                        	je	0x59b28d <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x5cd>
  59b286: b8 01 00 00 00               	movl	$0x1, %eax
  59b28b: eb 34                        	jmp	0x59b2c1 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x601>
  59b28d: 48 8b 8c 24 f0 00 00 00      	movq	0xf0(%rsp), %rcx
  59b295: 48 8b 94 24 c8 00 00 00      	movq	0xc8(%rsp), %rdx
  59b29d: 0f 1f 00                     	nopl	(%rax)
  59b2a0: 48 39 ca                     	cmpq	%rcx, %rdx
  59b2a3: 74 04                        	je	0x59b2a9 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x5e9>
  59b2a5: 31 c0                        	xorl	%eax, %eax
  59b2a7: eb 15                        	jmp	0x59b2be <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x5fe>
  59b2a9: 48 8b 84 24 e8 00 00 00      	movq	0xe8(%rsp), %rax
  59b2b1: 48 8b 9c 24 e0 00 00 00      	movq	0xe0(%rsp), %rbx
  59b2b9: e8 a2 79 e6 ff               	callq	0x402c60 <runtime.memequal>
  59b2be: 83 f0 01                     	xorl	$0x1, %eax
  59b2c1: 84 c0                        	testb	%al, %al
  59b2c3: 74 3a                        	je	0x59b2ff <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x63f>
  59b2c5: 48 8d 15 8c 0c 1c 00         	leaq	0x1c0c8c(%rip), %rdx    # 0x75bf58 <type:*+0x2b5d0>
  59b2cc: 48 89 94 24 20 02 00 00      	movq	%rdx, 0x220(%rsp)
  59b2d4: 48 8d 15 75 77 02 00         	leaq	0x27775(%rip), %rdx     # 0x5c2a50 <internal/sync..dict.indirect[interface {},interface {}]+0x160>
  59b2db: 48 89 94 24 28 02 00 00      	movq	%rdx, 0x228(%rsp)
  59b2e3: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59b2eb: 48 8d 9c 24 20 02 00 00      	leaq	0x220(%rsp), %rbx
  59b2f3: b9 01 00 00 00               	movl	$0x1, %ecx
  59b2f8: 89 cf                        	movl	%ecx, %edi
  59b2fa: e8 81 db f5 ff               	callq	0x4f8e80 <testing.(*common).Fatal>
  59b2ff: 48 8d 84 24 90 01 00 00      	leaq	0x190(%rsp), %rax
  59b307: 48 8d 8c 24 e8 00 00 00      	leaq	0xe8(%rsp), %rcx
  59b30f: 44 0f 10 31                  	movups	(%rcx), %xmm14
  59b313: 44 0f 11 30                  	movups	%xmm14, (%rax)
  59b317: 44 0f 10 71 10               	movups	0x10(%rcx), %xmm14
  59b31c: 44 0f 11 70 10               	movups	%xmm14, 0x10(%rax)
  59b321: 44 0f 10 71 20               	movups	0x20(%rcx), %xmm14
  59b326: 44 0f 11 70 20               	movups	%xmm14, 0x20(%rax)
  59b32b: 44 0f 10 71 30               	movups	0x30(%rcx), %xmm14
  59b330: 44 0f 11 70 30               	movups	%xmm14, 0x30(%rax)
  59b335: 44 0f 10 71 40               	movups	0x40(%rcx), %xmm14
  59b33a: 44 0f 11 70 40               	movups	%xmm14, 0x40(%rax)
  59b33f: 44 0f 10 71 50               	movups	0x50(%rcx), %xmm14
  59b344: 44 0f 11 70 50               	movups	%xmm14, 0x50(%rax)
  59b349: 44 0f 10 71 60               	movups	0x60(%rcx), %xmm14
  59b34e: 44 0f 11 70 60               	movups	%xmm14, 0x60(%rax)
  59b353: 44 0f 10 71 70               	movups	0x70(%rcx), %xmm14
  59b358: 44 0f 11 70 70               	movups	%xmm14, 0x70(%rax)
  59b35d: 44 0f 10 b1 80 00 00 00      	movups	0x80(%rcx), %xmm14
  59b365: 44 0f 11 b0 80 00 00 00      	movups	%xmm14, 0x80(%rax)
  59b36d: 48 81 c4 38 02 00 00         	addq	$0x238, %rsp            # imm = 0x238
  59b374: 5d                           	popq	%rbp
  59b375: c3                           	retq
  59b376: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  59b37e: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
  59b386: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  59b38e: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  59b396: 48 89 8c 24 d8 00 00 00      	movq	%rcx, 0xd8(%rsp)
  59b39e: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  59b3a6: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  59b3ae: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  59b3b6: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  59b3be: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  59b3c6: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  59b3ce: 48 8b 94 24 48 01 00 00      	movq	0x148(%rsp), %rdx
  59b3d6: 4c 8b a4 24 50 01 00 00      	movq	0x150(%rsp), %r12
  59b3de: 4c 8b ac 24 58 01 00 00      	movq	0x158(%rsp), %r13
  59b3e6: 4c 8b bc 24 60 01 00 00      	movq	0x160(%rsp), %r15
  59b3ee: 4c 89 bc 24 80 01 00 00      	movq	%r15, 0x180(%rsp)
  59b3f6: 48 8b 84 24 68 01 00 00      	movq	0x168(%rsp), %rax
  59b3fe: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
  59b406: 4c 8b bc 24 88 01 00 00      	movq	0x188(%rsp), %r15
  59b40e: 4d 8b 7f 18                  	movq	0x18(%r15), %r15
  59b412: 48 89 14 24                  	movq	%rdx, (%rsp)
  59b416: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  59b41b: 4c 89 6c 24 10               	movq	%r13, 0x10(%rsp)
  59b420: 48 8b 94 24 80 01 00 00      	movq	0x180(%rsp), %rdx
  59b428: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  59b42d: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
  59b432: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
  59b437: 4c 89 7c 24 30               	movq	%r15, 0x30(%rsp)
  59b43c: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
  59b444: 48 8b 8c 24 d8 00 00 00      	movq	0xd8(%rsp), %rcx
  59b44c: e8 6f 76 fd ff               	callq	0x572ac0 <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe>
  59b451: 88 84 24 c7 00 00 00         	movb	%al, 0xc7(%rsp)
  59b458: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59b460: 0f b6 8c 24 c6 00 00 00      	movzbl	0xc6(%rsp), %ecx
  59b468: 48 8b 90 c0 02 00 00         	movq	0x2c0(%rax), %rdx
  59b46f: 48 39 90 b8 02 00 00         	cmpq	%rdx, 0x2b8(%rax)
  59b476: 76 11                        	jbe	0x59b489 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x7c9>
  59b478: 48 ff c2                     	incq	%rdx
  59b47b: 48 89 90 c0 02 00 00         	movq	%rdx, 0x2c0(%rax)
  59b482: ba 01 00 00 00               	movl	$0x1, %edx
  59b487: eb 17                        	jmp	0x59b4a0 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x7e0>
  59b489: e8 72 35 f5 ff               	callq	0x4eea00 <testing.(*B).loopSlowPath>
  59b48e: 0f b6 8c 24 c6 00 00 00      	movzbl	0xc6(%rsp), %ecx
  59b496: 89 c2                        	movl	%eax, %edx
  59b498: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59b4a0: 84 d2                        	testb	%dl, %dl
  59b4a2: 0f 85 ce fe ff ff            	jne	0x59b376 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x6b6>
  59b4a8: e9 be fd ff ff               	jmp	0x59b26b <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x5ab>
  59b4ad: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  59b4b5: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
  59b4bd: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  59b4c5: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  59b4cd: 48 89 8c 24 d8 00 00 00      	movq	%rcx, 0xd8(%rsp)
  59b4d5: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  59b4dd: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  59b4e5: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  59b4ed: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  59b4f5: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  59b4fd: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  59b505: 48 8b 94 24 48 01 00 00      	movq	0x148(%rsp), %rdx
  59b50d: 4c 8b a4 24 50 01 00 00      	movq	0x150(%rsp), %r12
  59b515: 4c 8b ac 24 58 01 00 00      	movq	0x158(%rsp), %r13
  59b51d: 4c 8b bc 24 60 01 00 00      	movq	0x160(%rsp), %r15
  59b525: 4c 89 bc 24 80 01 00 00      	movq	%r15, 0x180(%rsp)
  59b52d: 48 8b 84 24 68 01 00 00      	movq	0x168(%rsp), %rax
  59b535: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
  59b53d: 4c 8b bc 24 88 01 00 00      	movq	0x188(%rsp), %r15
  59b545: 4d 8b 7f 18                  	movq	0x18(%r15), %r15
  59b549: 48 89 14 24                  	movq	%rdx, (%rsp)
  59b54d: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  59b552: 4c 89 6c 24 10               	movq	%r13, 0x10(%rsp)
  59b557: 48 8b 94 24 80 01 00 00      	movq	0x180(%rsp), %rdx
  59b55f: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  59b564: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
  59b569: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
  59b56e: 4c 89 7c 24 30               	movq	%r15, 0x30(%rsp)
  59b573: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
  59b57b: 48 8b 8c 24 d8 00 00 00      	movq	0xd8(%rsp), %rcx
  59b583: e8 18 74 fd ff               	callq	0x5729a0 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe>
  59b588: 88 84 24 c7 00 00 00         	movb	%al, 0xc7(%rsp)
  59b58f: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59b597: 0f b6 8c 24 c6 00 00 00      	movzbl	0xc6(%rsp), %ecx
  59b59f: 48 8b 90 c0 02 00 00         	movq	0x2c0(%rax), %rdx
  59b5a6: 48 39 90 b8 02 00 00         	cmpq	%rdx, 0x2b8(%rax)
  59b5ad: 76 13                        	jbe	0x59b5c2 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x902>
  59b5af: 48 ff c2                     	incq	%rdx
  59b5b2: 48 89 90 c0 02 00 00         	movq	%rdx, 0x2c0(%rax)
  59b5b9: ba 01 00 00 00               	movl	$0x1, %edx
  59b5be: 66 90                        	nop
  59b5c0: eb 1e                        	jmp	0x59b5e0 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x920>
  59b5c2: e8 39 34 f5 ff               	callq	0x4eea00 <testing.(*B).loopSlowPath>
  59b5c7: 0f b6 8c 24 c6 00 00 00      	movzbl	0xc6(%rsp), %ecx
  59b5cf: 89 c2                        	movl	%eax, %edx
  59b5d1: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59b5d9: 0f 1f 80 00 00 00 00         	nopl	(%rax)
  59b5e0: 84 d2                        	testb	%dl, %dl
  59b5e2: 0f 85 c5 fe ff ff            	jne	0x59b4ad <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x7ed>
  59b5e8: e9 7e fc ff ff               	jmp	0x59b26b <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x5ab>
  59b5ed: 48 8b 84 24 00 01 00 00      	movq	0x100(%rsp), %rax
  59b5f5: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
  59b5fd: 48 8b 9c 24 08 01 00 00      	movq	0x108(%rsp), %rbx
  59b605: 48 8b 8c 24 10 01 00 00      	movq	0x110(%rsp), %rcx
  59b60d: 48 89 8c 24 d8 00 00 00      	movq	%rcx, 0xd8(%rsp)
  59b615: 48 8b bc 24 18 01 00 00      	movq	0x118(%rsp), %rdi
  59b61d: 48 8b b4 24 20 01 00 00      	movq	0x120(%rsp), %rsi
  59b625: 4c 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %r8
  59b62d: 4c 8b 8c 24 30 01 00 00      	movq	0x130(%rsp), %r9
  59b635: 4c 8b 94 24 38 01 00 00      	movq	0x138(%rsp), %r10
  59b63d: 4c 8b 9c 24 40 01 00 00      	movq	0x140(%rsp), %r11
  59b645: 48 8b 94 24 48 01 00 00      	movq	0x148(%rsp), %rdx
  59b64d: 4c 8b a4 24 50 01 00 00      	movq	0x150(%rsp), %r12
  59b655: 4c 8b ac 24 58 01 00 00      	movq	0x158(%rsp), %r13
  59b65d: 4c 8b bc 24 60 01 00 00      	movq	0x160(%rsp), %r15
  59b665: 4c 89 bc 24 80 01 00 00      	movq	%r15, 0x180(%rsp)
  59b66d: 48 8b 84 24 68 01 00 00      	movq	0x168(%rsp), %rax
  59b675: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
  59b67d: 4c 8b bc 24 88 01 00 00      	movq	0x188(%rsp), %r15
  59b685: 4d 8b 7f 18                  	movq	0x18(%r15), %r15
  59b689: 48 89 14 24                  	movq	%rdx, (%rsp)
  59b68d: 4c 89 64 24 08               	movq	%r12, 0x8(%rsp)
  59b692: 4c 89 6c 24 10               	movq	%r13, 0x10(%rsp)
  59b697: 48 8b 94 24 80 01 00 00      	movq	0x180(%rsp), %rdx
  59b69f: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  59b6a4: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
  59b6a9: 48 89 4c 24 28               	movq	%rcx, 0x28(%rsp)
  59b6ae: 4c 89 7c 24 30               	movq	%r15, 0x30(%rsp)
  59b6b3: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
  59b6bb: 48 8b 8c 24 d8 00 00 00      	movq	0xd8(%rsp), %rcx
  59b6c3: e8 58 a6 fc ff               	callq	0x565d20 <github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint>
  59b6c8: 88 84 24 c7 00 00 00         	movb	%al, 0xc7(%rsp)
  59b6cf: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59b6d7: 0f b6 8c 24 c6 00 00 00      	movzbl	0xc6(%rsp), %ecx
  59b6df: 48 8b 90 c0 02 00 00         	movq	0x2c0(%rax), %rdx
  59b6e6: 48 39 90 b8 02 00 00         	cmpq	%rdx, 0x2b8(%rax)
  59b6ed: 76 13                        	jbe	0x59b702 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0xa42>
  59b6ef: 48 ff c2                     	incq	%rdx
  59b6f2: 48 89 90 c0 02 00 00         	movq	%rdx, 0x2c0(%rax)
  59b6f9: ba 01 00 00 00               	movl	$0x1, %edx
  59b6fe: 66 90                        	nop
  59b700: eb 1e                        	jmp	0x59b720 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0xa60>
  59b702: e8 f9 32 f5 ff               	callq	0x4eea00 <testing.(*B).loopSlowPath>
  59b707: 0f b6 8c 24 c6 00 00 00      	movzbl	0xc6(%rsp), %ecx
  59b70f: 89 c2                        	movl	%eax, %edx
  59b711: 48 8b 84 24 48 02 00 00      	movq	0x248(%rsp), %rax
  59b719: 0f 1f 80 00 00 00 00         	nopl	(%rax)
  59b720: 84 d2                        	testb	%dl, %dl
  59b722: 0f 85 c5 fe ff ff            	jne	0x59b5ed <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x92d>
  59b728: e9 3e fb ff ff               	jmp	0x59b26b <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1+0x5ab>
  59b72d: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
  59b732: e8 e9 00 ef ff               	callq	0x48b820 <runtime.morestack.abi0>
  59b737: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
  59b73c: 0f 1f 40 00                  	nopl	(%rax)
  59b740: e9 7b f5 ff ff               	jmp	0x59acc0 <github.com/thesyncim/govpx/internal/pixel.BenchmarkFP16GuardComponent.func1>
  59b745: cc                           	int3
  59b746: cc                           	int3
  59b747: cc                           	int3
  59b748: cc                           	int3
  59b749: cc                           	int3
  59b74a: cc                           	int3
  59b74b: cc                           	int3
  59b74c: cc                           	int3
  59b74d: cc                           	int3
  59b74e: cc                           	int3
  59b74f: cc                           	int3
  59b750: cc                           	int3
  59b751: cc                           	int3
  59b752: cc                           	int3
  59b753: cc                           	int3
  59b754: cc                           	int3
  59b755: cc                           	int3
  59b756: cc                           	int3
  59b757: cc                           	int3
  59b758: cc                           	int3
  59b759: cc                           	int3
  59b75a: cc                           	int3
  59b75b: cc                           	int3
  59b75c: cc                           	int3
  59b75d: cc                           	int3
  59b75e: cc                           	int3
  59b75f: cc                           	int3

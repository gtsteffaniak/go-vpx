
/private/tmp/govpx-fp16-guard-component/validation/ordinary.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

00000000011653c0 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe>:
 11653c0: 55                           	pushq	%rbp
 11653c1: 48 89 e5                     	movq	%rsp, %rbp
 11653c4: 48 83 ec 50                  	subq	$0x50, %rsp
 11653c8: 48 89 84 24 98 00 00 00      	movq	%rax, 0x98(%rsp)
 11653d0: 48 89 bc 24 b0 00 00 00      	movq	%rdi, 0xb0(%rsp)
 11653d8: 4c 89 8c 24 c8 00 00 00      	movq	%r9, 0xc8(%rsp)
 11653e0: 48 8d 0c 24                  	leaq	(%rsp), %rcx
 11653e4: 44 0f 11 39                  	movups	%xmm15, (%rcx)
 11653e8: 44 0f 11 79 10               	movups	%xmm15, 0x10(%rcx)
 11653ed: 44 0f 11 79 20               	movups	%xmm15, 0x20(%rcx)
 11653f2: 44 0f 11 79 30               	movups	%xmm15, 0x30(%rcx)
 11653f7: 44 0f 11 79 40               	movups	%xmm15, 0x40(%rcx)
 11653fc: 48 89 04 24                  	movq	%rax, (%rsp)
 1165400: 48 8b 8c 24 90 00 00 00      	movq	0x90(%rsp), %rcx
 1165408: 48 8d 14 09                  	leaq	(%rcx,%rcx), %rdx
 116540c: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
 1165411: 48 89 7c 24 10               	movq	%rdi, 0x10(%rsp)
 1165416: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
 116541b: 48 8b 5c 24 60               	movq	0x60(%rsp), %rbx
 1165420: 48 89 5c 24 20               	movq	%rbx, 0x20(%rsp)
 1165425: 48 89 54 24 28               	movq	%rdx, 0x28(%rsp)
 116542a: 4d 85 c9                     	testq	%r9, %r9
 116542d: 74 13                        	je	0x1165442 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x82>
 116542f: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
 1165434: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
 1165439: b8 04 00 00 00               	movl	$0x4, %eax
 116543e: 66 90                        	nop
 1165440: eb 05                        	jmp	0x1165447 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x87>
 1165442: b8 03 00 00 00               	movl	$0x3, %eax
 1165447: 48 8b 54 24 78               	movq	0x78(%rsp), %rdx
 116544c: 48 85 d2                     	testq	%rdx, %rdx
 116544f: 74 12                        	je	0x1165463 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xa3>
 1165451: 89 c3                        	movl	%eax, %ebx
 1165453: 48 c1 e3 04                  	shlq	$0x4, %rbx
 1165457: 48 89 14 1c                  	movq	%rdx, (%rsp,%rbx)
 116545b: 48 89 4c 1c 08               	movq	%rcx, 0x8(%rsp,%rbx)
 1165460: 48 ff c0                     	incq	%rax
 1165463: 31 c9                        	xorl	%ecx, %ecx
 1165465: eb 04                        	jmp	0x116546b <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xab>
 1165467: 48 8d 4a 01                  	leaq	0x1(%rdx), %rcx
 116546b: 48 39 c8                     	cmpq	%rcx, %rax
 116546e: 7e 4b                        	jle	0x11654bb <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xfb>
 1165470: 48 89 ca                     	movq	%rcx, %rdx
 1165473: 48 c1 e1 04                  	shlq	$0x4, %rcx
 1165477: 31 db                        	xorl	%ebx, %ebx
 1165479: eb 05                        	jmp	0x1165480 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xc0>
 116547b: 49 8d 58 01                  	leaq	0x1(%r8), %rbx
 116547f: 90                           	nop
 1165480: 48 39 d3                     	cmpq	%rdx, %rbx
 1165483: 7d e2                        	jge	0x1165467 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xa7>
 1165485: 48 83 fa 05                  	cmpq	$0x5, %rdx
 1165489: 73 43                        	jae	0x11654ce <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x10e>
 116548b: 48 8b 74 0c 08               	movq	0x8(%rsp,%rcx), %rsi
 1165490: 48 8b 3c 0c                  	movq	(%rsp,%rcx), %rdi
 1165494: 49 89 d8                     	movq	%rbx, %r8
 1165497: 48 c1 e3 04                  	shlq	$0x4, %rbx
 116549b: 4c 8b 4c 1c 08               	movq	0x8(%rsp,%rbx), %r9
 11654a0: 48 2b 3c 1c                  	subq	(%rsp,%rbx), %rdi
 11654a4: 48 8d 1c 37                  	leaq	(%rdi,%rsi), %rbx
 11654a8: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
 11654ac: 4a 8d 34 0e                  	leaq	(%rsi,%r9), %rsi
 11654b0: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
 11654b4: 48 39 de                     	cmpq	%rbx, %rsi
 11654b7: 76 c2                        	jbe	0x116547b <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xbb>
 11654b9: eb 0b                        	jmp	0x11654c6 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x106>
 11654bb: b8 01 00 00 00               	movl	$0x1, %eax
 11654c0: 48 83 c4 50                  	addq	$0x50, %rsp
 11654c4: 5d                           	popq	%rbp
 11654c5: c3                           	retq
 11654c6: 31 c0                        	xorl	%eax, %eax
 11654c8: 48 83 c4 50                  	addq	$0x50, %rsp
 11654cc: 5d                           	popq	%rbp
 11654cd: c3                           	retq
 11654ce: e8 4d 42 f2 ff               	callq	0x1089720 <_runtime.panicBounds>
 11654d3: 90                           	nop
 11654d4: cc                           	int3
 11654d5: cc                           	int3
 11654d6: cc                           	int3
 11654d7: cc                           	int3
 11654d8: cc                           	int3
 11654d9: cc                           	int3
 11654da: cc                           	int3
 11654db: cc                           	int3
 11654dc: cc                           	int3
 11654dd: cc                           	int3
 11654de: cc                           	int3
 11654df: cc                           	int3


/private/tmp/govpx-fp16-guard-component/validation/ordinary.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

00000000011654e0 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe>:
 11654e0: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
 11654e5: 48 89 7c 24 58               	movq	%rdi, 0x58(%rsp)
 11654ea: 4c 89 4c 24 70               	movq	%r9, 0x70(%rsp)
 11654ef: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
 11654f4: 48 89 ca                     	movq	%rcx, %rdx
 11654f7: 48 c1 e1 02                  	shlq	$0x2, %rcx
 11654fb: 48 ff c9                     	decq	%rcx
 11654fe: 48 89 fb                     	movq	%rdi, %rbx
 1165501: 48 29 c7                     	subq	%rax, %rdi
 1165504: 48 8d 34 57                  	leaq	(%rdi,%rdx,2), %rsi
 1165508: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
 116550c: 48 39 ce                     	cmpq	%rcx, %rsi
 116550f: 72 2b                        	jb	0x116553c <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x5c>
 1165511: 48 8b 74 24 08               	movq	0x8(%rsp), %rsi
 1165516: 48 89 f7                     	movq	%rsi, %rdi
 1165519: 48 29 c6                     	subq	%rax, %rsi
 116551c: 48 8d 34 56                  	leaq	(%rsi,%rdx,2), %rsi
 1165520: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
 1165524: 48 39 ce                     	cmpq	%rcx, %rsi
 1165527: 72 13                        	jb	0x116553c <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x5c>
 1165529: 48 89 fe                     	movq	%rdi, %rsi
 116552c: 48 29 df                     	subq	%rbx, %rdi
 116552f: 48 8d 3c 57                  	leaq	(%rdi,%rdx,2), %rdi
 1165533: 48 8d 7f ff                  	leaq	-0x1(%rdi), %rdi
 1165537: 48 39 cf                     	cmpq	%rcx, %rdi
 116553a: 73 04                        	jae	0x1165540 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x60>
 116553c: 31 c0                        	xorl	%eax, %eax
 116553e: c3                           	retq
 116553f: 90                           	nop
 1165540: 4d 85 c9                     	testq	%r9, %r9
 1165543: 74 3c                        	je	0x1165581 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xa1>
 1165545: 4c 89 cf                     	movq	%r9, %rdi
 1165548: 4d 89 c8                     	movq	%r9, %r8
 116554b: 49 29 c1                     	subq	%rax, %r9
 116554e: 4d 8d 0c 51                  	leaq	(%r9,%rdx,2), %r9
 1165552: 4d 8d 49 ff                  	leaq	-0x1(%r9), %r9
 1165556: 49 39 c9                     	cmpq	%rcx, %r9
 1165559: 72 23                        	jb	0x116557e <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x9e>
 116555b: 4d 89 c1                     	movq	%r8, %r9
 116555e: 49 29 d8                     	subq	%rbx, %r8
 1165561: 4d 8d 04 50                  	leaq	(%r8,%rdx,2), %r8
 1165565: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
 1165569: 49 39 c8                     	cmpq	%rcx, %r8
 116556c: 72 10                        	jb	0x116557e <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x9e>
 116556e: 49 29 f1                     	subq	%rsi, %r9
 1165571: 4d 8d 04 51                  	leaq	(%r9,%rdx,2), %r8
 1165575: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
 1165579: 49 39 c8                     	cmpq	%rcx, %r8
 116557c: 73 06                        	jae	0x1165584 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xa4>
 116557e: 31 c0                        	xorl	%eax, %eax
 1165580: c3                           	retq
 1165581: 4c 89 cf                     	movq	%r9, %rdi
 1165584: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
 1165589: 48 85 c9                     	testq	%rcx, %rcx
 116558c: 74 5c                        	je	0x11655ea <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x10a>
 116558e: 4c 8d 04 52                  	leaq	(%rdx,%rdx,2), %r8
 1165592: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
 1165596: 49 89 c9                     	movq	%rcx, %r9
 1165599: 48 29 c1                     	subq	%rax, %rcx
 116559c: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
 11655a0: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
 11655a4: 49 39 c8                     	cmpq	%rcx, %r8
 11655a7: 77 26                        	ja	0x11655cf <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xef>
 11655a9: 4c 89 c9                     	movq	%r9, %rcx
 11655ac: 49 29 d9                     	subq	%rbx, %r9
 11655af: 49 8d 1c 11                  	leaq	(%r9,%rdx), %rbx
 11655b3: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
 11655b7: 49 39 d8                     	cmpq	%rbx, %r8
 11655ba: 77 13                        	ja	0x11655cf <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xef>
 11655bc: 48 89 cb                     	movq	%rcx, %rbx
 11655bf: 48 29 f1                     	subq	%rsi, %rcx
 11655c2: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
 11655c6: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
 11655ca: 49 39 c8                     	cmpq	%rcx, %r8
 11655cd: 76 03                        	jbe	0x11655d2 <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xf2>
 11655cf: 31 c0                        	xorl	%eax, %eax
 11655d1: c3                           	retq
 11655d2: 48 85 ff                     	testq	%rdi, %rdi
 11655d5: 74 13                        	je	0x11655ea <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x10a>
 11655d7: 48 29 fb                     	subq	%rdi, %rbx
 11655da: 48 8d 0c 13                  	leaq	(%rbx,%rdx), %rcx
 11655de: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
 11655e2: 49 39 c8                     	cmpq	%rcx, %r8
 11655e5: 76 03                        	jbe	0x11655ea <_github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x10a>
 11655e7: 31 c0                        	xorl	%eax, %eax
 11655e9: c3                           	retq
 11655ea: b8 01 00 00 00               	movl	$0x1, %eax
 11655ef: c3                           	retq
 11655f0: cc                           	int3
 11655f1: cc                           	int3
 11655f2: cc                           	int3
 11655f3: cc                           	int3
 11655f4: cc                           	int3
 11655f5: cc                           	int3
 11655f6: cc                           	int3
 11655f7: cc                           	int3
 11655f8: cc                           	int3
 11655f9: cc                           	int3
 11655fa: cc                           	int3
 11655fb: cc                           	int3
 11655fc: cc                           	int3
 11655fd: cc                           	int3
 11655fe: cc                           	int3
 11655ff: cc                           	int3

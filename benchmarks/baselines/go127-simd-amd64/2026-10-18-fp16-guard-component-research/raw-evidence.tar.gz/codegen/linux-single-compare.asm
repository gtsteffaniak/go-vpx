
/private/tmp/govpx-fp16-guard-component/validation/linux.test:	file format elf64-x86-64

Disassembly of section .text:

00000000005729a0 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe>:
  5729a0: 55                           	pushq	%rbp
  5729a1: 48 89 e5                     	movq	%rsp, %rbp
  5729a4: 48 83 ec 50                  	subq	$0x50, %rsp
  5729a8: 48 89 84 24 98 00 00 00      	movq	%rax, 0x98(%rsp)
  5729b0: 48 89 bc 24 b0 00 00 00      	movq	%rdi, 0xb0(%rsp)
  5729b8: 4c 89 8c 24 c8 00 00 00      	movq	%r9, 0xc8(%rsp)
  5729c0: 48 8d 0c 24                  	leaq	(%rsp), %rcx
  5729c4: 44 0f 11 39                  	movups	%xmm15, (%rcx)
  5729c8: 44 0f 11 79 10               	movups	%xmm15, 0x10(%rcx)
  5729cd: 44 0f 11 79 20               	movups	%xmm15, 0x20(%rcx)
  5729d2: 44 0f 11 79 30               	movups	%xmm15, 0x30(%rcx)
  5729d7: 44 0f 11 79 40               	movups	%xmm15, 0x40(%rcx)
  5729dc: 48 89 04 24                  	movq	%rax, (%rsp)
  5729e0: 48 8b 8c 24 90 00 00 00      	movq	0x90(%rsp), %rcx
  5729e8: 48 8d 14 09                  	leaq	(%rcx,%rcx), %rdx
  5729ec: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
  5729f1: 48 89 7c 24 10               	movq	%rdi, 0x10(%rsp)
  5729f6: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  5729fb: 48 8b 5c 24 60               	movq	0x60(%rsp), %rbx
  572a00: 48 89 5c 24 20               	movq	%rbx, 0x20(%rsp)
  572a05: 48 89 54 24 28               	movq	%rdx, 0x28(%rsp)
  572a0a: 4d 85 c9                     	testq	%r9, %r9
  572a0d: 74 13                        	je	0x572a22 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x82>
  572a0f: 4c 89 4c 24 30               	movq	%r9, 0x30(%rsp)
  572a14: 48 89 54 24 38               	movq	%rdx, 0x38(%rsp)
  572a19: b8 04 00 00 00               	movl	$0x4, %eax
  572a1e: 66 90                        	nop
  572a20: eb 05                        	jmp	0x572a27 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x87>
  572a22: b8 03 00 00 00               	movl	$0x3, %eax
  572a27: 48 8b 54 24 78               	movq	0x78(%rsp), %rdx
  572a2c: 48 85 d2                     	testq	%rdx, %rdx
  572a2f: 74 12                        	je	0x572a43 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xa3>
  572a31: 89 c3                        	movl	%eax, %ebx
  572a33: 48 c1 e3 04                  	shlq	$0x4, %rbx
  572a37: 48 89 14 1c                  	movq	%rdx, (%rsp,%rbx)
  572a3b: 48 89 4c 1c 08               	movq	%rcx, 0x8(%rsp,%rbx)
  572a40: 48 ff c0                     	incq	%rax
  572a43: 31 c9                        	xorl	%ecx, %ecx
  572a45: eb 04                        	jmp	0x572a4b <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xab>
  572a47: 48 8d 4a 01                  	leaq	0x1(%rdx), %rcx
  572a4b: 48 39 c8                     	cmpq	%rcx, %rax
  572a4e: 7e 4b                        	jle	0x572a9b <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xfb>
  572a50: 48 89 ca                     	movq	%rcx, %rdx
  572a53: 48 c1 e1 04                  	shlq	$0x4, %rcx
  572a57: 31 db                        	xorl	%ebx, %ebx
  572a59: eb 05                        	jmp	0x572a60 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xc0>
  572a5b: 49 8d 58 01                  	leaq	0x1(%r8), %rbx
  572a5f: 90                           	nop
  572a60: 48 39 d3                     	cmpq	%rdx, %rbx
  572a63: 7d e2                        	jge	0x572a47 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xa7>
  572a65: 48 83 fa 05                  	cmpq	$0x5, %rdx
  572a69: 73 43                        	jae	0x572aae <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x10e>
  572a6b: 48 8b 74 0c 08               	movq	0x8(%rsp,%rcx), %rsi
  572a70: 48 8b 3c 0c                  	movq	(%rsp,%rcx), %rdi
  572a74: 49 89 d8                     	movq	%rbx, %r8
  572a77: 48 c1 e3 04                  	shlq	$0x4, %rbx
  572a7b: 4c 8b 4c 1c 08               	movq	0x8(%rsp,%rbx), %r9
  572a80: 48 2b 3c 1c                  	subq	(%rsp,%rbx), %rdi
  572a84: 48 8d 1c 37                  	leaq	(%rdi,%rsi), %rbx
  572a88: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
  572a8c: 4a 8d 34 0e                  	leaq	(%rsi,%r9), %rsi
  572a90: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
  572a94: 48 39 de                     	cmpq	%rbx, %rsi
  572a97: 76 c2                        	jbe	0x572a5b <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0xbb>
  572a99: eb 0b                        	jmp	0x572aa6 <github.com/thesyncim/govpx/internal/pixel.fp16GuardSingleProbe+0x106>
  572a9b: b8 01 00 00 00               	movl	$0x1, %eax
  572aa0: 48 83 c4 50                  	addq	$0x50, %rsp
  572aa4: 5d                           	popq	%rbp
  572aa5: c3                           	retq
  572aa6: 31 c0                        	xorl	%eax, %eax
  572aa8: 48 83 c4 50                  	addq	$0x50, %rsp
  572aac: 5d                           	popq	%rbp
  572aad: c3                           	retq
  572aae: e8 4d aa f1 ff               	callq	0x48d500 <runtime.panicBounds>
  572ab3: 90                           	nop
  572ab4: cc                           	int3
  572ab5: cc                           	int3
  572ab6: cc                           	int3
  572ab7: cc                           	int3
  572ab8: cc                           	int3
  572ab9: cc                           	int3
  572aba: cc                           	int3
  572abb: cc                           	int3
  572abc: cc                           	int3
  572abd: cc                           	int3
  572abe: cc                           	int3
  572abf: cc                           	int3

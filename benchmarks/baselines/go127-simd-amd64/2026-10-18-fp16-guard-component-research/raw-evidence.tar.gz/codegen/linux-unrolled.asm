
/private/tmp/govpx-fp16-guard-component/validation/linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000572ac0 <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe>:
  572ac0: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
  572ac5: 48 89 7c 24 58               	movq	%rdi, 0x58(%rsp)
  572aca: 4c 89 4c 24 70               	movq	%r9, 0x70(%rsp)
  572acf: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
  572ad4: 48 89 ca                     	movq	%rcx, %rdx
  572ad7: 48 c1 e1 02                  	shlq	$0x2, %rcx
  572adb: 48 ff c9                     	decq	%rcx
  572ade: 48 89 fb                     	movq	%rdi, %rbx
  572ae1: 48 29 c7                     	subq	%rax, %rdi
  572ae4: 48 8d 34 57                  	leaq	(%rdi,%rdx,2), %rsi
  572ae8: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
  572aec: 48 39 ce                     	cmpq	%rcx, %rsi
  572aef: 72 2b                        	jb	0x572b1c <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x5c>
  572af1: 48 8b 74 24 08               	movq	0x8(%rsp), %rsi
  572af6: 48 89 f7                     	movq	%rsi, %rdi
  572af9: 48 29 c6                     	subq	%rax, %rsi
  572afc: 48 8d 34 56                  	leaq	(%rsi,%rdx,2), %rsi
  572b00: 48 8d 76 ff                  	leaq	-0x1(%rsi), %rsi
  572b04: 48 39 ce                     	cmpq	%rcx, %rsi
  572b07: 72 13                        	jb	0x572b1c <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x5c>
  572b09: 48 89 fe                     	movq	%rdi, %rsi
  572b0c: 48 29 df                     	subq	%rbx, %rdi
  572b0f: 48 8d 3c 57                  	leaq	(%rdi,%rdx,2), %rdi
  572b13: 48 8d 7f ff                  	leaq	-0x1(%rdi), %rdi
  572b17: 48 39 cf                     	cmpq	%rcx, %rdi
  572b1a: 73 04                        	jae	0x572b20 <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x60>
  572b1c: 31 c0                        	xorl	%eax, %eax
  572b1e: c3                           	retq
  572b1f: 90                           	nop
  572b20: 4d 85 c9                     	testq	%r9, %r9
  572b23: 74 3c                        	je	0x572b61 <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xa1>
  572b25: 4c 89 cf                     	movq	%r9, %rdi
  572b28: 4d 89 c8                     	movq	%r9, %r8
  572b2b: 49 29 c1                     	subq	%rax, %r9
  572b2e: 4d 8d 0c 51                  	leaq	(%r9,%rdx,2), %r9
  572b32: 4d 8d 49 ff                  	leaq	-0x1(%r9), %r9
  572b36: 49 39 c9                     	cmpq	%rcx, %r9
  572b39: 72 23                        	jb	0x572b5e <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x9e>
  572b3b: 4d 89 c1                     	movq	%r8, %r9
  572b3e: 49 29 d8                     	subq	%rbx, %r8
  572b41: 4d 8d 04 50                  	leaq	(%r8,%rdx,2), %r8
  572b45: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  572b49: 49 39 c8                     	cmpq	%rcx, %r8
  572b4c: 72 10                        	jb	0x572b5e <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x9e>
  572b4e: 49 29 f1                     	subq	%rsi, %r9
  572b51: 4d 8d 04 51                  	leaq	(%r9,%rdx,2), %r8
  572b55: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  572b59: 49 39 c8                     	cmpq	%rcx, %r8
  572b5c: 73 06                        	jae	0x572b64 <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xa4>
  572b5e: 31 c0                        	xorl	%eax, %eax
  572b60: c3                           	retq
  572b61: 4c 89 cf                     	movq	%r9, %rdi
  572b64: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
  572b69: 48 85 c9                     	testq	%rcx, %rcx
  572b6c: 74 5c                        	je	0x572bca <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x10a>
  572b6e: 4c 8d 04 52                  	leaq	(%rdx,%rdx,2), %r8
  572b72: 4d 8d 40 ff                  	leaq	-0x1(%r8), %r8
  572b76: 49 89 c9                     	movq	%rcx, %r9
  572b79: 48 29 c1                     	subq	%rax, %rcx
  572b7c: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
  572b80: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  572b84: 49 39 c8                     	cmpq	%rcx, %r8
  572b87: 77 26                        	ja	0x572baf <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xef>
  572b89: 4c 89 c9                     	movq	%r9, %rcx
  572b8c: 49 29 d9                     	subq	%rbx, %r9
  572b8f: 49 8d 1c 11                  	leaq	(%r9,%rdx), %rbx
  572b93: 48 8d 5b ff                  	leaq	-0x1(%rbx), %rbx
  572b97: 49 39 d8                     	cmpq	%rbx, %r8
  572b9a: 77 13                        	ja	0x572baf <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xef>
  572b9c: 48 89 cb                     	movq	%rcx, %rbx
  572b9f: 48 29 f1                     	subq	%rsi, %rcx
  572ba2: 48 8d 0c 11                  	leaq	(%rcx,%rdx), %rcx
  572ba6: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  572baa: 49 39 c8                     	cmpq	%rcx, %r8
  572bad: 76 03                        	jbe	0x572bb2 <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0xf2>
  572baf: 31 c0                        	xorl	%eax, %eax
  572bb1: c3                           	retq
  572bb2: 48 85 ff                     	testq	%rdi, %rdi
  572bb5: 74 13                        	je	0x572bca <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x10a>
  572bb7: 48 29 fb                     	subq	%rdi, %rbx
  572bba: 48 8d 0c 13                  	leaq	(%rbx,%rdx), %rcx
  572bbe: 48 8d 49 ff                  	leaq	-0x1(%rcx), %rcx
  572bc2: 49 39 c8                     	cmpq	%rcx, %r8
  572bc5: 76 03                        	jbe	0x572bca <github.com/thesyncim/govpx/internal/pixel.fp16GuardUnrolledProbe+0x10a>
  572bc7: 31 c0                        	xorl	%eax, %eax
  572bc9: c3                           	retq
  572bca: b8 01 00 00 00               	movl	$0x1, %eax
  572bcf: c3                           	retq
  572bd0: cc                           	int3
  572bd1: cc                           	int3
  572bd2: cc                           	int3
  572bd3: cc                           	int3
  572bd4: cc                           	int3
  572bd5: cc                           	int3
  572bd6: cc                           	int3
  572bd7: cc                           	int3
  572bd8: cc                           	int3
  572bd9: cc                           	int3
  572bda: cc                           	int3
  572bdb: cc                           	int3
  572bdc: cc                           	int3
  572bdd: cc                           	int3
  572bde: cc                           	int3
  572bdf: cc                           	int3

import pathlib,subprocess,re,json,hashlib
w=pathlib.Path('/private/tmp/govpx-fp16-guard-component');cg=w/'codegen';cg.mkdir(exist_ok=True)
old=pathlib.Path('/private/tmp/govpx-fp16-offset-guard');summary={}
def dis(binary,symbol):
 s=subprocess.check_output(['xcrun','llvm-objdump','-d','--disassemble-symbols='+symbol,str(binary)],text=True)
 ins=[]
 for l in s.splitlines():
  m=re.match(r'^\s*[0-9a-f]+:\s+(?:[0-9a-f]{2}\s+)+(.+)$',l)
  if m and m.group(1)!='int3':
   # Normalize addresses and the renamed helper label itself, including jump target comments.
   inst=re.sub(r'0x[0-9a-fA-F]+','ADDR',m.group(1))
   inst=re.sub(r'fp16Guard(Single|Unrolled)Probe','fp16WindowsDisjoint',inst)
   ins.append(inst)
 assert ins,symbol
 return s,ins
for os,suffix,prefix in [('darwin','ordinary','_'),('linux','linux','')]:
 summary[os]={}
 for variant,helper in [('parent','fp16WindowsDisjoint'),('single-compare','fp16GuardSingleProbe'),('unrolled','fp16GuardUnrolledProbe')]:
  s,now=dis(w/'validation'/f'{suffix}.test',prefix+'github.com/thesyncim/govpx/internal/pixel.'+helper)
  (cg/f'{os}-{variant}.asm').write_text(s)
  s,prior=dis(old/'evidence/validation'/f'{variant}-pixel-{suffix}.test',prefix+'github.com/thesyncim/govpx/internal/pixel.fp16WindowsDisjoint')
  assert now==prior,(os,variant,[(a,b) for a,b in zip(now,prior) if a!=b])
  summary[os][variant]={'normalized_generated_body_identical_to_production_prototype':True,'meaningful_instructions':len(now)}
text=(w/'fp16_guard_component_native_test.go').read_text()
for variant,name in [('single-compare','fp16GuardSingleProbe'),('unrolled','fp16GuardUnrolledProbe')]:
 p=(old/variant/'internal/pixel/quantize_fp_amd64.go').read_text();body=p[p.index('func fp16WindowsDisjoint'):].replace('func fp16WindowsDisjoint(', 'func '+name+'(',1).strip()
 assert body in text,variant
inline=(w/'validation/build-ordinary.log').read_text()
for name in ['fp16WindowsDisjoint','fp16GuardSingleProbe','fp16GuardUnrolledProbe']:
 ls=[l for l in inline.splitlines() if 'cannot inline '+name+':' in l];assert len(ls)==1,ls
 summary[name]={'inline_diagnostic':ls[0]}
summary['fixture_sha256']=hashlib.sha256(text.encode()).hexdigest()
summary['cases']=22;summary['guards']=3;summary['names']=66;summary['sixroundsamples']=396
(cg/'proof.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))

import pathlib,os,subprocess,json
w=pathlib.Path('/private/tmp/govpx-fp16-guard-component');root=pathlib.Path('/Users/thesyncim/GolandProjects/govpx');snap=w/'snapshot';snap.mkdir(exist_ok=True);out=w/'validation';out.mkdir(exist_ok=True)
p=subprocess.Popen(['git','archive','46a08f8e6eb03f6ee4549d975384bd6c952a81fa'],cwd=root,stdout=subprocess.PIPE);subprocess.run(['tar','-x','-C',str(snap)],stdin=p.stdout,check=True);p.stdout.close();assert p.wait()==0
fixture=w/'fp16_guard_component_native_test.go';subprocess.run(['/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/gofmt','-w',str(fixture)],check=True);(snap/'internal/pixel'/fixture.name).write_bytes(fixture.read_bytes())
env=os.environ.copy();env.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-fpguard-component',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',CGO_ENABLED='1',GOARCH='amd64',GOOS='darwin',GOAMD64='v1')
records=[]
def run(name,args,extra={}):
 e=env.copy();e.update(extra);p=subprocess.run(args,cwd=root,env=e,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/(name+'.log')).write_text(p.stdout);records.append(dict(name=name,args=args,env=extra,exit=p.returncode));(out/'commands.json').write_text(json.dumps(records,indent=2));print(name,p.returncode,flush=True)
 if p.returncode:print(p.stdout[-6000:]);raise SystemExit(p.returncode)
 return p.stdout
run('cache',[str(root/'scripts/go.sh'),'env','GOCACHE'])
for mode in ['ordinary','checkptr2','linux']:
 binary=out/f'{mode}.test';args=[str(root/'scripts/go.sh'),'-C',str(snap),'test','-pgo=off','-c','-o',str(binary)]
 if mode=='checkptr2':args+=['-gcflags=all=-d=checkptr=2']
 else:args+=['-gcflags=github.com/thesyncim/govpx/internal/pixel=-m=2']
 args+=['./internal/pixel'];run('build-'+mode,args,dict(GOOS='linux',CGO_ENABLED='0') if mode=='linux' else {})
 if mode=='linux':continue
 for off in [False,True]:
  extra=dict(ROSETTA_ADVERTISE_AVX='1',GOVPX_REQUIRE_SIMD='0' if off else '1',GOVPX_REQUIRE_FP16_AVX_OFF='1' if off else '0',GODEBUG='cpu.avx=off,cpu.avx2=off' if off else '')
  run('oracle-'+mode+('-off' if off else '-selected'),['arch','-x86_64',str(binary),'-test.run=^TestFP16','-test.v','-test.count=1'],extra)
 # The timer must skip entirely on Darwin even if its opt-in variable is set.
 text=run('native-only-skip-'+mode,['arch','-x86_64',str(binary),'-test.run=^$','-test.bench=^BenchmarkFP16GuardComponent$','-test.benchtime=1x','-test.v'],dict(ROSETTA_ADVERTISE_AVX='1',GOVPX_REQUIRE_NATIVE_GUARD='1'))
 assert 'native Linux x64 diagnostic only' in text
print('VALIDATION PASS')

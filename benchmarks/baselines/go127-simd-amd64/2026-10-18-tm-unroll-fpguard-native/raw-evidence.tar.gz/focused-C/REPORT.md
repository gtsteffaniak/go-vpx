# PR47 focused SSE8 and optimized-C native evidence

Exacthead b6209532fbc30cf9567e0cdc78a21d61a60fe900; parent2df3eaf5fb547db07bd970cd65bf504ecb287590; pinnedold691cd0512c4829d9ee40d483205dd223f9eb028d. Focusedrun39105370539 andreferencejob39105370448 SUCCESS. Fullnative/ExhaustiveCI stillpendingatfreeze; thispackage nevergrantsmergeapproval. RootPERFREADY required.

Focused EPYC7763, officialGo1.27.2,PGOoff,GOMAX1: all9publicpointermedians1.2707–1.3364xparent,all54pairsfaster(min1.1245x),1.3533–1.3856xoldASM. ThisisrobustbutNOT a1.5xclaim. All720measuredsamples0B/0alloc;120one-shots excluded. Source/Git/manifest/oraclechecksPASS. NativeGNUactualcurrent/basehotloops28/37 instructions,nohotspills/legacyvectorops; exactmeasuredbinarySHA tied tofilteredGoNM/size/addressmap andactualBLoopcaller. Oldlowercase/varianceassemblycaptured. Optionalinlinedwrapperabsence recordedhonestly.

Controls retained: slice8x4all9 faster1.0311–1.0342x; slice8x8nearflat3/9medianregressions; slice8x16all9medians/all54pairsslower,.9723–.9811xparent (~1.9–2.85%moretime). Sourceidentity is notused to dismiss thesecontrolchanges. No cross-jobCPU pooling orwhole-codecclaim.

Optimized-C runner EPYC9V74: fixedCPU-used(-8)VP8Go/C TIMEratio2.1221x (C faster). Both58qualityframes,PSNR/SSIM,outputpayload/counts matchtheirpairedtimings; thisis measuredoutput/qualityequivalence, notbitstreamidentity. AdaptiveVP8ratio1.5679x,VP9small2.6533x,large2.3928x useunequalquality/outputwork andarenot equivalent-qualityspeedclaims. All24Cencodetimers usevpxenc-stats; optimizedSSE2/AVX2macros/objectinventoryverified.74rawfiles retainallquality,timing,commands andconfigdata.

Package contains every55focused and74Crawfile,includingnativeGNUtraces andtools; completeaudits+exactscripts included. Nativeprogrambinarieswereexcludedbythe originalworkflow buttheirSHA recorded. Parentmustpublishallremainingfullnative/whole/controls andindependentlyreviewbeforemerge. No files inREADME wereedited; no repo/Gitwrites bythisagent.

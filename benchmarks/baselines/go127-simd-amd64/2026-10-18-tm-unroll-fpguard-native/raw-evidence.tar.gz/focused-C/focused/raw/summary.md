# Native amd64 SSE8 focused results

Six balanced rounds; all 36 public B.Loop cases and four legacy B.N diagnostics.
Every sample is retained; timing ratios do not determine job success. No whole-codec claim.

Head `b6209532fbc30cf9567e0cdc78a21d61a60fe900`; base `2df3eaf5fb547db07bd970cd65bf504ecb287590`; old assembly `691cd0512c4829d9ee40d483205dd223f9eb028d`.

## B.Loop public

| Fixture | Head ns | Base ns | Old ASM ns | Base/head | Head time change | Pairs slower |
|---|---:|---:|---:|---:|---:|---:|
| pointer8x8/pitch1312-1320/pattern0 | 7.2870 | 9.6160 | 9.9980 | 1.3196× | -24.22% | 0/6 |
| pointer8x8/pitch1312-1320/pattern1 | 7.3095 | 9.5440 | 10.0025 | 1.3057× | -23.41% | 0/6 |
| pointer8x8/pitch1312-1320/pattern2 | 7.3115 | 9.5335 | 10.0050 | 1.3039× | -23.31% | 0/6 |
| pointer8x8/pitch32-37/pattern0 | 7.2380 | 9.5420 | 9.9955 | 1.3183× | -24.15% | 0/6 |
| pointer8x8/pitch32-37/pattern1 | 7.2145 | 9.5740 | 9.9965 | 1.3270× | -24.64% | 0/6 |
| pointer8x8/pitch32-37/pattern2 | 7.2155 | 9.6430 | 9.9920 | 1.3364× | -25.17% | 0/6 |
| pointer8x8/pitch8-8/pattern0 | 7.3550 | 9.5755 | 10.0000 | 1.3019× | -23.19% | 0/6 |
| pointer8x8/pitch8-8/pattern1 | 7.3830 | 9.5985 | 9.9995 | 1.3001× | -23.08% | 0/6 |
| pointer8x8/pitch8-8/pattern2 | 7.3815 | 9.3795 | 9.9895 | 1.2707× | -21.30% | 0/6 |
| slice8x16/pitch1312-1320/pattern0 | 16.5350 | 16.1100 | 1002.5000 | 0.9743× | +2.64% | 6/6 |
| slice8x16/pitch1312-1320/pattern1 | 16.5100 | 16.1450 | 1003.0000 | 0.9779× | +2.26% | 6/6 |
| slice8x16/pitch1312-1320/pattern2 | 16.5400 | 16.1350 | 894.3500 | 0.9755× | +2.51% | 6/6 |
| slice8x16/pitch32-37/pattern0 | 16.4400 | 15.9850 | 1001.5000 | 0.9723× | +2.85% | 6/6 |
| slice8x16/pitch32-37/pattern1 | 16.4350 | 15.9950 | 1002.0000 | 0.9732× | +2.75% | 6/6 |
| slice8x16/pitch32-37/pattern2 | 16.4350 | 16.0000 | 894.3500 | 0.9735× | +2.72% | 6/6 |
| slice8x16/pitch8-8/pattern0 | 16.4400 | 16.1250 | 1002.0000 | 0.9808× | +1.95% | 6/6 |
| slice8x16/pitch8-8/pattern1 | 16.4650 | 16.1450 | 1002.5000 | 0.9806× | +1.98% | 6/6 |
| slice8x16/pitch8-8/pattern2 | 16.4450 | 16.1350 | 896.4000 | 0.9811× | +1.92% | 6/6 |
| slice8x4/pitch1312-1320/pattern0 | 9.0580 | 9.3675 | 12.4950 | 1.0342× | -3.30% | 0/6 |
| slice8x4/pitch1312-1320/pattern1 | 9.0600 | 9.3580 | 12.4800 | 1.0329× | -3.18% | 0/6 |
| slice8x4/pitch1312-1320/pattern2 | 9.0595 | 9.3600 | 12.4900 | 1.0332× | -3.21% | 0/6 |
| slice8x4/pitch32-37/pattern0 | 9.0650 | 9.3570 | 12.4900 | 1.0322× | -3.12% | 0/6 |
| slice8x4/pitch32-37/pattern1 | 9.0545 | 9.3625 | 12.4950 | 1.0340× | -3.29% | 0/6 |
| slice8x4/pitch32-37/pattern2 | 9.0695 | 9.3520 | 12.4750 | 1.0311× | -3.02% | 0/6 |
| slice8x4/pitch8-8/pattern0 | 9.1220 | 9.4145 | 12.5800 | 1.0321× | -3.11% | 0/6 |
| slice8x4/pitch8-8/pattern1 | 9.0625 | 9.3650 | 12.5200 | 1.0334× | -3.23% | 0/6 |
| slice8x4/pitch8-8/pattern2 | 9.0685 | 9.3760 | 12.4900 | 1.0339× | -3.28% | 0/6 |
| slice8x8/pitch1312-1320/pattern0 | 10.9350 | 10.9350 | 14.6750 | 1.0000× | +0.00% | 3/6 |
| slice8x8/pitch1312-1320/pattern1 | 10.9400 | 10.9400 | 14.6700 | 1.0000× | -0.00% | 4/6 |
| slice8x8/pitch1312-1320/pattern2 | 10.9350 | 10.9550 | 14.7000 | 1.0018× | -0.18% | 3/6 |
| slice8x8/pitch32-37/pattern0 | 10.9400 | 10.9150 | 14.7100 | 0.9977× | +0.23% | 4/6 |
| slice8x8/pitch32-37/pattern1 | 10.9350 | 10.9400 | 14.6900 | 1.0005× | -0.05% | 2/6 |
| slice8x8/pitch32-37/pattern2 | 10.9200 | 10.9350 | 14.7000 | 1.0014× | -0.14% | 1/6 |
| slice8x8/pitch8-8/pattern0 | 10.9300 | 10.9200 | 14.6900 | 0.9991× | +0.09% | 4/6 |
| slice8x8/pitch8-8/pattern1 | 10.9450 | 10.9250 | 14.7000 | 0.9982× | +0.18% | 3/6 |
| slice8x8/pitch8-8/pattern2 | 10.9300 | 10.9300 | 14.6900 | 1.0000× | +0.00% | 2/6 |

## B.N legacy diagnostic

| Fixture | Head ns | Base ns | Old ASM ns | Base/head | Head time change | Pairs slower |
|---|---:|---:|---:|---:|---:|---:|
| SSE8x16 | 14.9300 | 14.6900 | 890.6000 | 0.9839× | +1.63% | 6/6 |
| SSE8x4 | 7.1855 | 6.8770 | 9.9825 | 0.9571× | +4.49% | 6/6 |
| SSE8x8 | 9.0600 | 9.0565 | 12.1800 | 0.9996× | +0.04% | 4/6 |
| SSE8x8PtrFast | 7.4275 | 9.1940 | 9.3830 | 1.2378× | -19.21% | 0/6 |


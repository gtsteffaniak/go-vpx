# Source-only preparation. No download/build; execute after native artifact release.
from pathlib import Path
import hashlib,json,re,sys
R=Path(sys.argv[1]);assert len([p for p in R.iterdir() if p.is_file()])==55
sha=lambda b:hashlib.sha256(b).hexdigest()
assert (R/'codegen-tools.txt').read_text().startswith('GNU objdump') and 'go version go1.27.2 linux/amd64' in (R/'codegen-tools.txt').read_text()
summary={}
for variant in ['head','base','assembly']:
 meta=json.loads((R/f'{variant}-codegen.json').read_text());code=(R/f'{variant}-codegen.txt').read_text();symbols=(R/f'{variant}-codegen-symbols.txt').read_text()
 assert meta['variant']==variant and meta['post_timing_only'] and meta['no_performance_threshold']
 assert sha(code.encode())==meta['codegen_sha256'] and sha(symbols.encode())==meta['filtered_nm_sha256']
 assert meta['measured_executable_sha256']==(R/f'{variant}-binary-sha256.txt').read_text().split()[0]
 assert symbols.splitlines()==[e['nm_line'] for e in meta['symbols']]
 blocks={}
 for part in code.split('\n# selected symbol ')[1:]:
  name,text=part.split('\n',1);blocks[name]=text
 assert set(blocks)=={e['name'] for e in meta['symbols']}
 for entry in meta['symbols']:assert sha(blocks[entry['name']].encode())==entry['gnu_disassembly_sha256']
 names=set(blocks);assert any(n.startswith('github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1') for n in names)
 if variant=='assembly':assert any('varianceBlock8xNSSE2' in n for n in names)
 for name,status in meta['optional_wrapper_status'].items():assert (status=='emitted')==(name in names)
 data={'symbols':meta['symbols'],'optional_wrappers':meta['optional_wrapper_status'],'binarySHA':meta['measured_executable_sha256']}
 if variant!='assembly':
  kernel=blocks['github.com/thesyncim/govpx/internal/pixel.SSE8Ptr'];inst=[]
  for line in kernel.splitlines():
   m=re.match(r'^\s*([0-9a-f]+):\s+(?:[0-9a-f]{2}\s+)+(.+)$',line)
   if m and m[2]!='int3':inst.append((int(m[1],16),m[2]))
  back=[(pc,int(m[1],16)) for pc,i in inst if (m:=re.match(r'j(?!mp)\w+\s+(?:0x)?([0-9a-f]+)',i)) and int(m[1],16)<pc]
  assert len(back)==1,back
  end,start=back[0];hot=[(pc,i) for pc,i in inst if start<=pc<=end]
  assert not any(i.startswith('call') or '%rsp' in i or '%rbp' in i for pc,i in hot)
  assert not any(('%xmm' in i or '%ymm' in i) and not i.startswith('v') for pc,i in hot)
  data['actual_native_hotloop']=hot;data['actual_native_hotloop_instruction_count']=len(hot)
  data['actual_native_pointer_entry']=next(e for e in meta['symbols'] if e['name'].endswith('/pixel.SSE8Ptr'))
 summary[variant]=data
print(json.dumps({'actual_native_traces_verified':True,'current_base_loopcounts':{v:summary[v].get('actual_native_hotloop_instruction_count') for v in ['head','base']},'variants':summary},indent=2))

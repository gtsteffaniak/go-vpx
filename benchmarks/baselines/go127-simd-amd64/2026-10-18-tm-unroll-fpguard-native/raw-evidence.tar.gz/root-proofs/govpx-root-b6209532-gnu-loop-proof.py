from pathlib import Path
import re,json,hashlib
p=Path('/private/tmp/govpx-sse8-focused-b6209532-artifact');out={}
for v,expected in [('head',28),('base',37)]:
 text=(p/(v+'-codegen.txt')).read_text();body=dict(x.split('\n',1)for x in text.split('\n# selected symbol ')[1:])['github.com/thesyncim/govpx/internal/pixel.SSE8Ptr'];rows=[]
 for line in body.splitlines():
  fields=line.split('\t')
  if len(fields)<3:continue
  m=re.match(r'\s*([0-9a-f]+):$',fields[0]);instruction=fields[-1].strip()
  if m and instruction:rows.append((int(m[1],16),instruction))
 loops=[]
 for addr,ins in rows:
  m=re.match(r'(j\w+)\s+([0-9a-f]+) ',ins)
  if m and m[1]!='jmp' and int(m[2],16)<addr:
   lo=int(m[2],16);loop=[(a,s)for a,s in rows if lo<=a<=addr]
   if any('vpmaddwd' in s for a,s in loop):loops.append(loop)
 assert len(loops)==1
 loop=loops[0];assert len(loop)==expected,(v,len(loop))
 assert not any(re.search(r'\(%(?:r|e)?(?:sp|bp)\)',s)or s.startswith('call')for a,s in loop)
 out[v]={'body_sha256':hashlib.sha256(body.encode()).hexdigest(),'loop_instruction_count':len(loop),'loop_start':hex(loop[0][0]),'back_edge':hex(loop[-1][0]),'no_loop_calls_or_stack_access':True,'instructions':[{'address':hex(a),'instruction':s}for a,s in loop]}
proof=Path('/private/tmp/govpx-root-b6209532-focused-proof.json');d=json.loads(proof.read_text());d['native_GNU_measured_binary_provenance_verified']=True;d['native_GNU_hot_loop_independent_proof']=out;proof.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(out,indent=2))

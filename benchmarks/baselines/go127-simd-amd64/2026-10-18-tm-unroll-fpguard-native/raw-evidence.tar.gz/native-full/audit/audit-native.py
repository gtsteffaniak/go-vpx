from pathlib import Path
import hashlib,json,re,statistics,subprocess
B=Path('/private/tmp');R=B/'govpx-amd64-b6209532-artifact';ROOT='/Users/thesyncim/GolandProjects/govpx';H='b6209532fbc30cf9567e0cdc78a21d61a60fe900';BASE='2df3eaf5fb547db07bd970cd65bf504ecb287590';ASM='691cd0512c4829d9ee40d483205dd223f9eb028d'
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def git(*args,input=None):return subprocess.check_output(['git','--no-optional-locks',*args],cwd=ROOT,input=input)
raw={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(R.rglob('*')) if p.is_file()};assert len(raw)==92 and all('/' not in n for n in raw);write(B/'govpx-ci-b6209532-files.json',raw)
env=(R/'environment.txt').read_text();assert env.splitlines()[:3]==['assembly commit: '+ASM,'previous SIMD commit: '+BASE,'SIMD commit: '+H];assert 'go version go1.27.2 linux/amd64' in env;cpu=next(x.split(':',1)[1].strip() for x in env.splitlines() if x.startswith('Model name:'))
script=git('show',H+':scripts/benchmark-amd64.sh').decode();paths=re.findall(r'sha256sum "\$root/([^\"]+)"',script);assert len(paths)==len(set(paths))==86
q=''.join(H+':'+p+'\n' for p in paths).encode();blob=git('cat-file','--batch',input=q);off=0;expected={}
for path in paths:
 end=blob.index(b'\n',off);hdr=blob[off:end].decode().split();assert hdr[1]=='blob';size=int(hdr[2]);data=blob[end+1:end+1+size];expected[path]=hashlib.sha256(data).hexdigest();off=end+size+2
assert off==len(blob);recorded={}
for line in env.splitlines():
 m=re.match(r'([0-9a-f]{64})  (.+)$',line)
 if m:
  matches=[p for p in expected if m[2].endswith('/'+p)]
  if matches:recorded[max(matches,key=len)]=m[1]
assert recorded==expected
copies=re.findall(r'cp "\$root/([^\"]+)" "\$source_dir/([^\"]+)"',script);assert len(copies)==31 and all(a==b and a.endswith('_test.go') for a,b in copies)
for suffix,helper in [('summary','govpx-analyze-amd64-three.py'),('parity','govpx-amd64-complete-parity.py')]:
 data=subprocess.check_output(['/usr/bin/python3',str(B/helper),str(R)]);(B/f'govpx-b6209532-native-{suffix}.json').write_bytes(data)
s=json.loads((B/'govpx-b6209532-native-summary.json').read_text());parity=json.loads((B/'govpx-b6209532-native-parity.json').read_text());kernels=s['kernels'];assert len(kernels)==498
assert all(all(len(v[a+'_samples'])==6 and v[a+'_allocation_samples']==[[0.,0.]] for a in ['assembly','previous','simd']) for v in kernels.values())
prior=json.loads((B/'govpx-root-ac259fce-full-proof.json').read_text())['all463_kernel_results'];assert set(prior)<=set(kernels)
rootcopy={k:v for k,v in kernels.items() if k.startswith('github.com/thesyncim/govpx/BenchmarkCopy16RowsNative/')};dspcopy={k:v for k,v in kernels.items() if k.startswith('github.com/thesyncim/govpx/internal/vp8/dsp/BenchmarkCopy16RowsNative/')};tm={k:v for k,v in kernels.items() if '/BenchmarkTMPredictRowsNative/' in k};assert len(rootcopy)==len(dspcopy)==8 and len(tm)==27;assert set(kernels)-set(prior)==set(rootcopy)|set(tm)
orders=[line.split(': ',1)[1].split() for line in (R/'orders.txt').read_text().splitlines()];assert len(orders)==len(set(map(tuple,orders)))==6;assert all(sorted(x[i] for x in orders)==['assembly','assembly','previous','previous','simd','simd'] for i in range(3))
assert all(v['all_semantic_fields_equal'] and len(v['semantic_fields'])==22 for v in parity.values())
validation={}
for p in sorted(R.glob('*validation*.txt')):
 t=p.read_text();validation[p.name]={'pass':re.findall(r'^--- PASS: (\S+)',t,re.M),'allpass':re.findall(r'^\s*--- PASS: (\S+)',t,re.M),'skip':re.findall(r'^\s*--- SKIP: (\S+)',t,re.M),'fail':re.findall(r'^\s*--- FAIL: (\S+)',t,re.M)};assert not validation[p.name]['fail']
joined='\n'.join((R/n).read_text() for n in validation);top=[name for v in validation.values() for name in v['pass']];skips=[name for v in validation.values() for name in v['skip']]
prior_validation_root=B/'govpx-amd64-ac259fce-artifact'
prior_top=[n for p in prior_validation_root.glob('*validation*.txt') for n in re.findall(r'^--- PASS: (\S+)',p.read_text(),re.M)]
prior_PASS_requirements={n:prior_top.count(n) for n in set(prior_top) if n!='TestSSEPlane16AVX512'}
assert all(top.count(n)>=count for n,count in prior_PASS_requirements.items())
allowed={'TestDenseTokenPrivatePrepack','TestSSEPlane16AVX512','TestSADWideAVX2Selected','TestTMPredictBytesArithmetic'};assert all(x in allowed for x in skips)
counts={name:top.count(name) for name in ['TestCopy16AMDProbeRowsAndAliases','TestCopy16AMDProbeEveryAlignment','TestCopy16AMDProbeBoundsAndDisabled','TestCopy16FrozenPartialPanic','TestCopy16RowsPublicState','TestTMPredictRowsNativeState','TestFP16Selected']}
assert all(counts[x]==4 for x in ['TestCopy16AMDProbeRowsAndAliases','TestCopy16AMDProbeEveryAlignment','TestCopy16AMDProbeBoundsAndDisabled']);assert counts['TestCopy16FrozenPartialPanic']==8 and counts['TestCopy16RowsPublicState']==4 and counts['TestTMPredictRowsNativeState']==7 and counts['TestFP16Selected']==4
plane_features=re.findall(r'AVX2=(true|false) AVX512=(true|false)',joined);assert len(plane_features)==2 and len(set(plane_features))==1
assert (top.count('TestSSEPlane16AVX512')==2 and skips.count('TestSSEPlane16AVX512')==0) if plane_features[0][1]=='true' else (top.count('TestSSEPlane16AVX512')==0 and skips.count('TestSSEPlane16AVX512')==2)
fpfeatures=re.findall(r'Enabled=(true|false) AVX2=(true|false)',(R/'fp16-validation.txt').read_text());assert len(fpfeatures)==4 and fpfeatures.count(('true','true'))==2 and fpfeatures.count(('false','false'))==2
assert skips.count('TestTMPredictBytesArithmetic')==4 and skips.count('TestDenseTokenPrivatePrepack')==2 and skips.count('TestSADWideAVX2Selected')==2
onepat=re.compile(r'^(Benchmark\S+)\s+(\d+)\s+(?:([0-9.eE+-]+) ns/op\s+)?(?:[0-9.eE+-]+ MB/s\s+)?(\d+) B/op\s+(\d+) allocs/op$',re.M)
ones={}
for filename in validation:
 rows=[{'case':case,'iterations':int(it),'ns_not_used_as_performance':float(ns) if ns else None,'bytes':int(b),'allocs':int(a)} for case,it,ns,b,a in onepat.findall((R/filename).read_text())]
 if rows:assert all(x['iterations']==1 and x['bytes']==x['allocs']==0 for x in rows);ones[filename]=rows
fpfiles=[n for n in ones if 'fp16' in n];assert len(fpfiles)==4 and all(len(ones[n])==36 for n in fpfiles)
quantones=ones['quant-batch-validation.txt'];assert len(quantones)==194
assert sum(x['case'].startswith('BenchmarkTMPredictRowsNative/') for x in quantones)==81;assert sum(x['case'].startswith('BenchmarkIntraDCFill') for x in quantones)==81;assert sum(x['case'].startswith('BenchmarkCopy16RowsNative/') for x in quantones)==32;assert sum(len(v) for v in ones.values())==338
targets={k:v for k,v in kernels.items() if '/BenchmarkSSE8RowsNative/pointer8x8/' in k or any(t in k for t in ('/BenchmarkVP9FP16Native/n64/','/BenchmarkVP9FP16Native/n256/','/BenchmarkVP9FusedFPClassesNative/8x8/','/BenchmarkVP9FusedFPClassesNative/16x16/')) or k.endswith('/BenchmarkVP9FPNoClassesNative')}
assert len(targets)==40
controls={k:v for k,v in kernels.items() if k not in targets}
assert len(controls)==458
def metrics(v):
 return {'median_ns':{a:v[a+'_ns'] for a in ['assembly','previous','simd']},'parent_speedup':v['parent_throughput_ratio'],'old_reference_speedup':v['throughput_ratio'],'parent_time_change_percent':v['parent_time_delta_percent'],'old_time_change_percent':v['time_delta_percent'],'paired_parent_speedups':[1/(1+x/100) for x in v['parent_paired_percent']],'paired_old_speedups':[1/(1+x/100) for x in v['paired_percent']],'all_raw_samples':{a:v[a+'_samples'] for a in ['assembly','previous','simd']}}
def group(rows):
 vs=[metrics(v) for v in rows.values()];return {'count':len(vs),'parent_median_range':[min(v['parent_speedup'] for v in vs),max(v['parent_speedup'] for v in vs)],'minimum_paired_parent':min(x for v in vs for x in v['paired_parent_speedups']),'all6_faster_than_parent':sum(min(v['paired_parent_speedups'])>1 for v in vs),'all6_atleast1_5':sum(min(v['paired_parent_speedups'])>=1.5 for v in vs),'old_reference_median_range':[min(v['old_reference_speedup'] for v in vs),max(v['old_reference_speedup'] for v in vs)],'minimum_paired_old':min(x for v in vs for x in v['paired_old_speedups'])}
public={name:{'samples':{a:v[a+'_samples'] for a in ['assembly','previous','simd']},'parent_time_percent':v['parent_time_delta_percent'],'old_time_percent':v['time_delta_percent'],'parent_paired_time_percent':v['parent_paired_percent'],'old_paired_time_percent':v['paired_percent']} for name,v in s['encoders'].items()}
alloc=[]
for name,v in parity.items():
 values=[(a,i+1,x) for a,samples in v['allocation_samples'].items() for i,x in enumerate(samples if isinstance(samples,list) else [samples])];mode=statistics.mode(x[2] for x in values);alloc.append({'dataset':name,'mode':mode,'all_samples_equal':all(x[2]==mode for x in values),'exceptions':[{'variant':a,'round':i,'allocations_per_input':x} for a,i,x in values if x!=mode]})
out={'pr':47,'head_sha':H,'base_sha':BASE,'old_reference_sha':ASM,'cpu':cpu,'environment':env,'raw_file_count':92,'raw_sha256':raw,'recorded_86_exact_Git_source_hashes':recorded,'reference_31_common_fixtures':[x for x,y in copies],'kernel_cases':498,'kernel_samples':8964,'all_kernel_bytes_allocations_zero':True,'balanced_orders':orders,'root_Copy16_unchanged_controls':{k:metrics(v) for k,v in rootcopy.items()},'DSP_Copy16_unchanged_controls':{k:metrics(v) for k,v in dspcopy.items()},'root_Copy16_summary':group(rootcopy),'DSP_Copy16_summary':group(dspcopy),'TM27_AMD_controls':{k:metrics(v) for k,v in tm.items()},'all498_kernel_results':kernels,'all40_trials':targets,'all458_controls':controls,'control_median_slower':sum(v['parent_time_delta_percent']>0 for v in controls.values()),'control_all6_slower':sum(all(x>0 for x in v['parent_paired_percent']) for v in controls.values()),'all_median_regressions':{k:v for k,v in kernels.items() if v['parent_time_delta_percent']>0},'all6_slower_cases':{k:v for k,v in kernels.items() if all(x>0 for x in v['parent_paired_percent'])},'public':public,'all22_semantic_and_allocation_data':parity,'allocation_exceptions':alloc,'current_parent_allocation_samples_exact':{k:v['allocation_samples']['simd']==v['allocation_samples']['previous'] for k,v in parity.items()},'validation':validation,'all_previous_validation_PASS_requirements_retained':prior_PASS_requirements,'required_current_PASS_counts':counts,'expected_skip_events':skips,'four_FP_active_off_probes':fpfeatures,'plane_AVX512_ordinary_race_features':plane_features,'all338_excluded_one_shots':ones,'scope':['Copy16 root/DSP are unchanged-source controls in47; exact-self46regressions remain tracked. Guard+SSE8pointer are currentAMD trials.','NewTM helper is ARM-only; all27TM x64 measurements are controls.','Classify actualguard-eligibleFP and9SSE8pointercases as trials; sourceidentity alone never excuses control regressions.','WholeVP8 is candidate; VP9 controls. All22semanticfields/profile+eachallocation sample separate.','No crossCPU pooling; CI green alone never grants mergeapproval. HOLDuntilrootPERFREADY andpublishedfinalbody.']}
write(B/'govpx-b6209532-native-compact.json',out)
print(json.dumps({'cpu':cpu,'root_Copy16':out['root_Copy16_summary'],'DSP_Copy16':out['DSP_Copy16_summary'],'control_medians_slower':out['control_median_slower'],'control_all6_slower':out['control_all6_slower'],'allocations':alloc,'public':public,'audit':str(B/'govpx-b6209532-native-compact.json')},indent=2))

PR47 exactb6209532,base2df3eaf5,old691cd051. All4 CIchecks passed. Nativefullrun39105370448completed07:26:08UTC. AMD EPYC9V74. This package preserves all92rawfiles plus independent/source/rootproofs; earlier focusedEPYC7763/C9V74 packages remain separate and no crossCPU pooling is permitted.

Independent audit verifies92rawSHA/86exactGitSHAs/31sharedtestoverlays/498cases×18=8964samples, everykernel0alloc;338excludedone-shots+66componentexcluded;396guardcomponenttimings;all22semanticfields/frame/output counts retained;complete validation.40AMDtrialtargets/458controls;240controlmedians/42all6pairs slower retained. No sourceidentity excuse or thresholds weakened.

Actualproductionunrolled guard vs frozen46guard:12validdisjoint cases1.8531–2.6413x, all72pairedratios≥1.84462.10overlapdeclinecases diagnostic only, no acceptance claim. Benchmarkbindings parent=frozen46,single=frozen75,unrolled=actual47production checkedagainstfrozenprototype; all462timed/excludedrows0alloc. Nativecomponentparser initially retained benchmarkpadding spaces in its casekey; rstrip correction fixes parsing only, unchanged rawmeasurements retained.

Public31eligibleFPmedians1.104–1.204xparent withone slowern256denseoffset pair.9pointerSSE8medians1.1888–1.1909xparent,all54pairsfaster. Whole VP9320−0.755836%parent/−44.943077%old;VP9720−1.220876%parent/−55.654945%old;VP8720+0.648664%parent although4/6pairsfaster,+1.919956%old andall6pairs slowerold. No blanketcodecwin claim.

Allocations are not all equal: parentVP9720firstsample76/60vs75/60current andotherparent;oldVP9profile76/120vs75/120current,parent. Allcurrent/parent semantic fields match;eachallocation sample preserved in parityJSON. VP8alltimed/profile0alloc. Rawprofiles retained. Focusedresults/Coptimizedbaseline live in separate /private/tmp/govpx-pr47-focused-C-ready manifest a88f0ecd...; no memory of summary replaces raw evidence.

No production/source/PR mutation or merge performed by this agent. Root owns finalPERFREADY/body/merge decisions. This artifact records evidence, not an automatic merge authorization.

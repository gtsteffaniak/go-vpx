//go:build goexperiment.simd && amd64 && !purego

package pixel

import (
	"simd/archsimd"
	"unsafe"
)

// The public dispatcher proves the complete bilinear window and bounded
// positive geometry before these exact read-only loads.
func subpelStatsAxisHorizontal16(src []byte, ss int, ref []byte, rs, w, h int, f [2]int16) (int, uint32) {
	sp, rp := unsafe.Pointer(unsafe.SliceData(src)), unsafe.Pointer(unsafe.SliceData(ref))
	defer archsimd.ClearAVXUpperBits()
	f0, f1, round, ones := archsimd.BroadcastInt16x16(f[0]), archsimd.BroadcastInt16x16(f[1]), archsimd.BroadcastInt16x16(64), archsimd.BroadcastInt16x16(1)
	var sum, sse archsimd.Int32x8
	for x := 0; x < w; x += 16 {
		so, ro := x, x
		for range h {
			a := archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(sp, so)))
			b := archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(sp, so+1)))
			r := archsimd.LoadUint8x16Array((*[16]byte)(unsafe.Add(rp, ro)))
			v := a.ExtendToUint16().BitsToInt16().Mul(f0).Add(b.ExtendToUint16().BitsToInt16().Mul(f1)).Add(round).ShiftAllRight(7)
			d := v.Sub(r.ExtendToUint16().BitsToInt16())
			sum = sum.Add(d.DotProductPairs(ones))
			sse = sse.Add(d.DotProductPairs(d))
			so += ss
			ro += rs
		}
	}
	return int(sum32(sum.GetLo().Add(sum.GetHi()))), uint32(sum32(sse.GetLo().Add(sse.GetHi())))
}

// Keep the validated two-stage kernel on amd64. The one-axis vertical
// carrier regressed short blocks on native Intel; ARM uses its own kernel.
func subpelStatsAxisVertical16(src []byte, ss int, ref []byte, rs, w, h int, f [2]int16) (int, uint32) {
	return subpelStats16(src, ss, ref, rs, w, h, [2]int16{128, 0}, f)
}

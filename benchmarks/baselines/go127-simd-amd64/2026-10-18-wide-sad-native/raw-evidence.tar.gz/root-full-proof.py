import pathlib,hashlib,json,re,subprocess,statistics
p=pathlib.Path('/private/tmp/govpx-amd64-46b89f5a-artifact');head='46b89f5ab4c6c469755323a61c77fe3a766b4081'
env=(p/'environment.txt').read_text(); assert env.splitlines()[:3]==['assembly commit: 691cd0512c4829d9ee40d483205dd223f9eb028d','previous SIMD commit: bba909597f1a68e4ceeb94dcca0229c765f10d84','SIMD commit: '+head]
shas={}
for line in env.splitlines():
 m=re.match(r'([0-9a-f]{64})  .*/govpx/govpx/(.+)',line)
 if m:
  want=hashlib.sha256(subprocess.check_output(['git','show',head+':'+m[2]])).hexdigest();assert m[1]==want,m[2];shas[m[2]]=want
assert len(shas)==48
ks={}
for v in ['assembly','previous','simd']:
 d={};pkg=''
 for line in (p/(v+'-kernels.txt')).read_text().splitlines():
  if line.startswith('pkg: '):pkg=line[5:]
  m=re.match(r'(Benchmark\S+)\s+\d+\s+(\S+)\s+ns/op.*?\s+(\S+)\s+B/op\s+(\S+)\s+allocs/op',line)
  if m:
   assert float(m[3])==float(m[4])==0;d.setdefault(pkg+'/'+m[1],[]).append(float(m[2]))
 assert len(d)==412;assert all(len(a)==6 for a in d.values());ks[v]=d
assert ks['assembly'].keys()==ks['previous'].keys()==ks['simd'].keys()
orders=[line.split(': ',1)[1].split() for line in (p/'orders.txt').read_text().splitlines()]
assert len(orders)==6 and len(set(map(tuple,orders)))==6
for col in range(3): assert sorted(row[col] for row in orders)==['assembly','assembly','previous','previous','simd','simd']
for name in ['dispatch.txt','previous-dispatch.txt']:
 assert '--- PASS: TestBackendSelected ' in (p/name).read_text()
all_kernels={}
for key in ks['simd']:
 med={v:statistics.median(ks[v][key]) for v in ks}
 all_kernels[key]={'median_ns':med,'parent_speedup':med['previous']/med['simd'],'old_speedup':med['assembly']/med['simd'],'all6_parent_paired_speedups':[a/b for a,b in zip(ks['previous'][key],ks['simd'][key])]}
ratios={}
for key in ks['simd']:
 if 'BenchmarkSSE8RowsNative/' in key:
  pairs=[a/b for a,b in zip(ks['previous'][key],ks['simd'][key])]
  ratios[key]={'median_speedup':statistics.median(ks['previous'][key])/statistics.median(ks['simd'][key]),'paired_speedups':pairs}
assert len(ratios)==36
ignored={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'};public={};allocation_outliers=[];parent_allocation_outliers=[]
for label,pat in [('VP9320','{v}-encoder-{i}.json'),('VP8720','{v}-vp8-720p-encoder-{i}.json'),('VP9720','{v}-vp9-720p-encoder-{i}.json')]:
 rows={v:[json.loads((p/pat.format(v=v,i=i)).read_text()) for i in range(1,7)] for v in ks}
 assert all(r['allocs_per_frame']==rows['simd'][0]['allocs_per_frame'] for r in rows['simd'])
 for i,r in enumerate(rows['previous'],1):
  if r['allocs_per_frame']!=rows['simd'][0]['allocs_per_frame']:
   assert label=='VP9720' and i==6 and r['allocs_per_frame']==76/60 and rows['simd'][0]['allocs_per_frame']==75/60,(label,i,r['allocs_per_frame'])
   parent_allocation_outliers.append({'case':label,'variant':'previous','round':i,'allocations_per_input':r['allocs_per_frame'],'all6_current_and_old_allocations_per_input':rows['simd'][0]['allocs_per_frame']})
 for i,r in enumerate(rows['assembly'],1):
  if r['allocs_per_frame']!=rows['simd'][0]['allocs_per_frame']:
   allocation_outliers.append({'case':label,'variant':'assembly','round':i,'allocations_per_input':r['allocs_per_frame'],'current_parent_allocations_per_input':rows['simd'][0]['allocs_per_frame']})
 rr=[r for a in rows.values() for r in a];fields=set(rr[0])-ignored;assert len(fields)==22;assert all({k:r[k] for k in fields}=={k:rr[0][k] for k in fields} for r in rr)
 med={v:statistics.median(r['ns_per_frame'] for r in a) for v,a in rows.items()}
 pairs={v:[100*(a['ns_per_frame']/b['ns_per_frame']-1) for a,b in zip(rows['simd'],rows[v])] for v in ['previous','assembly']}
 public[label]={'median_ns':med,'all6_paired_time_differences_percent':pairs,'vs_parent_percent':100*(med['simd']/med['previous']-1),'vs_old_binary_percent':100*(med['simd']/med['assembly']-1),'allocations':{v:[r['allocs_per_frame'] for r in a] for v,a in rows.items()}}
for codec in ['vp8','vp9']:
 rows=[json.loads((p/(v+'-'+codec+'-720p-profile.json')).read_text()) for v in ks];fields=set(rows[0])-ignored;assert len(fields)==22;assert all({k:r[k] for k in fields}=={k:rows[0][k] for k in fields} for r in rows);assert all(r['allocs_per_frame']==rows[0]['allocs_per_frame'] for r in rows)
manifest=json.loads(pathlib.Path('/private/tmp/govpx-amd64-46b89f5a-files.json').read_text());assert len(manifest)==86
for f,h in manifest.items():assert hashlib.sha256((p/f).read_bytes()).hexdigest()==h,f
c=pathlib.Path('/private/tmp/govpx-libvpx-amd64-46b89f5a-artifact');cm=json.loads(pathlib.Path('/private/tmp/govpx-libvpx-amd64-46b89f5a-files.json').read_text());assert len(cm)==74
for f,h in cm.items():assert hashlib.sha256((c/f).read_bytes()).hexdigest()==h,f
log=(p/'quant-batch-validation.txt').read_text()
assert log.count('--- PASS: TestCopy16RowsPublicState ')==4
assert log.count('--- PASS: TestCopy8RowsPublicState ')==4
assert log.count('--- SKIP: TestDenseTokenPrivatePrepack ')==2
assert '--- FAIL' not in log
for name in ['TestSSE8PtrExactWindows','TestSSE8PtrFallbackPanics','TestSSE8RowsWideDispatch','TestSSE8EntryDisabledScalar','TestDenseTokenPrivateScalarComponent','TestDenseTokenPrivateStreamReference','TestDenseTokenPrepackAvailability']:
 assert log.count('--- PASS: '+name+' ')==2,name
# PR42 inherits AVX512 unchanged, and its runtime
# state must be reported honestly rather than inferred from the preceding host.
active=log.count('AVX2=true AVX512=true;')==2
if active:assert log.count('--- PASS: TestSSEPlane16AVX512 ')==2
else:assert log.count('--- SKIP: TestSSEPlane16AVX512 ')==2
assert subprocess.check_output(['git','show',head+':internal/pixel/sse_plane_amd64.go'])==subprocess.check_output(['git','show','ab3abd6b335242d5732fa1956a63b7591eaf781b:internal/pixel/sse_plane_amd64.go'])
for path in ['internal/pixel/sse8_rows_wide_amd64.go','internal/pixel/sse8_ptr_amd64.go']:
 assert subprocess.check_output(['git','show',head+':'+path])==subprocess.check_output(['git','show','bba909597f1a68e4ceeb94dcca0229c765f10d84:'+path])
# Original-reference allocation variation is retained explicitly, never silently discarded.

wide={};narrow={}
for key in ks['simd']:
 if 'BenchmarkVP9WideSADNative/' in key:
  med={v:statistics.median(ks[v][key]) for v in ks}
  pairs=[a/b for a,b in zip(ks['previous'][key],ks['simd'][key])]
  oldpairs=[a/b for a,b in zip(ks['assembly'][key],ks['simd'][key])]
  item={'median_ns':med,'parent_speedup':med['previous']/med['simd'],'old_assembly_speedup':med['assembly']/med['simd'],'all6_parent_paired_speedups':pairs,'all6_old_paired_speedups':oldpairs}
  shape=key.split('BenchmarkVP9WideSADNative/',1)[1].split('/',1)[0]
  (wide if shape.startswith(('32x','64x')) else narrow)[key]=item
assert len(wide)==45 and len(narrow)==9
for name in ['TestSADWideAVX2Rows','TestSADWideAVX2FallbackAndBounds','TestSADWideAVX2NilInputs','TestSADWideAVX2Disabled']:
 assert log.count('--- PASS: '+name+' ')==4,name
assert log.count('--- PASS: TestSADWideAVX2Selected ')==2
assert log.count('--- SKIP: TestSADWideAVX2Selected ')==2
assert log.count('Enabled=false actual AVX2=false')==2
out={'head':head,'native_files_verified':len(manifest),'c_files_verified':len(cm),'git_source_shas_verified':shas,'kernel_cases':412,'balanced_all6_variant_orders_verified':True,'all412_kernel_results':all_kernels,'samples_per_variant':6,'all_kernel_allocations_zero':True,'sse8_all36':ratios,'sse8_medians_at_least_1_5':sum(r['median_speedup']>=1.5 for r in ratios.values()),'sse8_all6_pairs_at_least_1_5':sum(min(r['paired_speedups'])>=1.5 for r in ratios.values()),'avx512_active_this_host':active,'inherited_avx512_source_unchanged':True,'all22_public_and_profile_semantics_equal':True,'all_current_parent_public_allocation_samples_equal':not parent_allocation_outliers,'all_profile_allocation_samples_equal':True,'all_three_variant_public_allocation_samples_equal':not(allocation_outliers or parent_allocation_outliers),'parent_reference_allocation_outliers':parent_allocation_outliers,'old_reference_allocation_outliers':allocation_outliers,'public':public,'wide_sad_all45':wide,'narrow_sad_controls_all9':narrow,'native_wide_sad_dispatch_and_off_gates_verified':True}
pathlib.Path('/private/tmp/govpx-root-46b89f5a-full-proof.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['git_source_shas_verified','sse8_all36','wide_sad_all45','narrow_sad_controls_all9','all412_kernel_results']},indent=2))

from pathlib import Path
import ast,hashlib,importlib.util,json,re,subprocess,tempfile,unittest,types,sys
from unittest.mock import patch
p=Path('/private/tmp/govpx-stats-native-capture-proposal');projectroot=Path('/Users/thesyncim/GolandProjects/govpx');auditdir=Path('/private/tmp/govpx-ci51-harness-proof');f=projectroot/'scripts/capture-stats-codegen.py';ast.parse(f.read_text());spec=importlib.util.spec_from_file_location('capture',f);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
files=['scripts/benchmark-pixel-optional.sh','scripts/benchmark-sse8-amd64.sh','scripts/benchmark-amd64.sh'];static={}
for fn in files:
 old=(p/'original'/fn).read_text();new=(projectroot/fn).read_text();r=subprocess.run(['sh','-n',str(projectroot/fn)],capture_output=True,text=True);assert r.returncode==0
 before=re.findall(r"<<'PY'[^\n]*\n(.*?)\nPY",old,re.S);after=re.findall(r"<<'PY'[^\n]*\n(.*?)\nPY",new,re.S);assert before==after
 for block in after:ast.parse(block)
 static[fn]={'shell_syntax_pass':True,'all_existing_embedded_Python_byte_identical':True,'embedded_blocks':len(after)}
old=(p/'original/scripts/benchmark-pixel-optional.sh').read_text();new=(projectroot/'scripts/benchmark-pixel-optional.sh').read_text();assert new.split('\n# Native code/layout capture')[0].replace('parent_source_dir=${7:-}\n','')==old
static['shared_optional_all_prior_text_exact_except_new_unused_metadata_argument']=True
# Actual smoke command output below is a deliberately synthetic metadata schema fixture, NOT native code/timing.
class TestCapture(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.d=Path(self.tmp.name);self.bin=self.d/'pixel.test';self.bin.write_bytes(b'synthetic metadata test binary; never executed');self.src=self.d/'source';self.common=self.d/'common'
  for d in [self.src,self.common]:
   (d/'internal/pixel').mkdir(parents=True)
   for name in m.FIXTURES:(d/'internal/pixel'/name).write_text('package pixel\n// common metadata schema fixture\n')
  self.log=self.d/'protocol.txt';self.text=m.digest(self.bin)+'  '+str(self.bin)+'\n    FP32PublicHost AVX512=false AVX2=true Enabled=true\n'+''.join('# round %d order %s\n'%(r,'parent current'if r%2else'current parent')for r in range(1,7))+'optional pixel inventory PASS:132 excluded one-shots\n';self.log.write_text(self.text)
 def tearDown(self):self.tmp.cleanup()
 def test_native_symbols_and_alignment(self):
  z=m.symbols('  558940 153 T '+m.PREFIX+'Stats\n  5a43e0 123 T '+m.PREFIX+'BenchmarkStatsReductionNative.func1\n');self.assertEqual(z[m.PREFIX+'Stats']['address_mod64'],0);self.assertEqual(z[m.PREFIX+'BenchmarkStatsReductionNative.func1']['address_mod64'],32);self.assertEqual(z[m.PREFIX+'Stats']['address_hex'],'0x558940')
 def test_protocol_binds_exact_binary_feature_and_orders(self):self.assertEqual(len(m.bind_protocol(self.text,self.bin)['orders']),6)
 def test_binary_mutation_rejected(self):
  self.bin.write_bytes(b'mutated')
  with self.assertRaises(AssertionError):m.bind_protocol(self.text,self.bin)
 def test_missing_feature_rejected(self):
  with self.assertRaises(AssertionError):m.bind_protocol(self.text.replace('FP32PublicHost AVX512=false AVX2=true Enabled=true',''),self.bin)
 def test_missing_order_rejected(self):
  with self.assertRaises(AssertionError):m.bind_protocol(self.text.replace('# round 6 order current parent\n',''),self.bin)
 def test_parser_not_finished_rejected(self):
  with self.assertRaises(AssertionError):m.bind_protocol(self.text.replace('optional pixel inventory PASS:','parser failed:'),self.bin)
 def test_duplicate_symbol_rejected(self):
  s='558940 153 T '+m.PREFIX+'Stats\n'
  with self.assertRaises(AssertionError):m.symbols(s+s)
 def argv(self,out):return ['capture','--variant','current','--binary',str(self.bin),'--output-dir',str(out),'--source-dir',str(self.src),'--common-source-dir',str(self.common),'--source-commit','a'*40,'--head-commit','a'*40,'--base-commit','b'*40,'--protocol-log',str(self.log),'--go-wrapper','go-wrapper-schema-fixture']
 def test_full_metadata_schema_with_explicit_tool_stubs(self):
  def fake(argv,**kw):
   if argv[:2]==['objdump','--version']:txt='GNU objdump schema-unit fixture ONLY\n'
   elif argv[0]=='objdump':txt='0000558940 <'+m.PREFIX+'Stats>:\n 558940: 90 nop\n'
   elif 'nm'in argv:txt='558940 153 T '+m.PREFIX+'Stats\n5a43e0 123 T '+m.PREFIX+'BenchmarkStatsReductionNative.func1\n'
   else:txt='go1.27.2 schema fixture buildinfo; NOT actual binary\n'
   return types.SimpleNamespace(returncode=0,stdout=txt)
  out=self.d/'capture'
  with patch.object(sys,'argv',self.argv(out)),patch.object(m.platform,'system',return_value='Linux'),patch.object(m.platform,'machine',return_value='x86_64'),patch.object(m.subprocess,'run',side_effect=fake):m.main()
  z=json.loads((out/'metadata.json').read_text());self.assertEqual(z['binary_sha256'],m.digest(self.bin));self.assertEqual(len(z['identical_common_fixture_SHA256']),2);self.assertEqual(z['protocol_SHA256'],m.digest(self.log));self.assertEqual(z['live_symbols'][m.PREFIX+'Stats']['address_hex'],'0x558940')
 def test_non_native_host_rejected(self):
  with patch.object(sys,'argv',self.argv(self.d/'badhost')),patch.object(m.platform,'system',return_value='Darwin'):
   with self.assertRaises(AssertionError):m.main()
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(TestCapture));assert result.wasSuccessful()
proof={'scope':'Static/schema verification of authorized ROOT four-file edits; no native execution, benchmark run or CI dispatch. CLI smoke uses explicitly synthetic tool stubs only. Actual GNU Linux tool execution is a future CI gate.','base_commit':'10caaa67ed53f8c3c1248f20070e5a4117245852','static':static,'schema_tests':result.testsRun,'all_pass':True,'files':{str(f.relative_to(projectroot)):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size}for f in [projectroot/n for n in files]+[projectroot/'scripts/capture-stats-codegen.py']}};(auditdir/'capture-schema-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))

from pathlib import Path
import os,subprocess,json,hashlib,re
b=Path('/private/tmp/govpx-pr48-native-harness-proposal');e=b/'validation';e.mkdir(exist_ok=True);root=Path('/Users/thesyncim/GolandProjects/govpx');snap=Path('/private/tmp/govpx-next-dc-pair-native');fixture='internal/vp8/dsp/dc_pair_native_bench_test.go';fixturebytes=(b/'overlay'/fixture).read_bytes();overlay_source=b/'overlay'/fixture
sourcepaths=json.loads((b/'source-sha-paths.json').read_text());common=json.loads((b/'common-overlays.json').read_text());assert len(sourcepaths)==len(set(sourcepaths))==103 and len(common)==len(set(common))==32
scope=json.loads((b/'scope.json').read_text());dcpaths=['internal/pixel/dc_pair_native_arm64.go','internal/pixel/dc_pair_native_fallback.go','internal/pixel/dc_pair_native_other.go','internal/pixel/dc_pair_simd.go','internal/vp8/dsp/idct.go','internal/vp8/dsp/dc_pair_native_state_test.go','internal/vp8/dsp/dc_pair_native_disabled_amd64_test.go',fixture]
source=[]
for p in sourcepaths:
 origin=overlay_source if p==fixture else snap/'candidate'/p if p in dcpaths else root/p
 assert origin.is_file(),str(origin);source.append(dict(path=p,origin=str(origin),sha256=hashlib.sha256(origin.read_bytes()).hexdigest()))
for p in common:assert (overlay_source if p==fixture else root/p).is_file(),p
(e/'103-source-receipts.json').write_text(json.dumps(source,indent=2))
subprocess.run(['sh','-n',str(b/'overlay/scripts/benchmark-amd64.sh')],check=True)
env=os.environ.copy();env.update(CODEX_AGENT_ID='govpx-ci-pr48',CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',GOTOOLCHAIN='local',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GOARCH='amd64',GOOS='darwin',CGO_ENABLED='0');records=[];names=None
for v in ['candidate','parent','old691']:
 path=snap/v;ov=e/(v+'-overlay.json');ov.write_text(json.dumps({'Replace':{str(path/fixture):str(overlay_source)}},indent=2));binary=e/(v+'-dsp.test');cmd=[str(root/'scripts/go.sh'),'-C',str(path),'test','-overlay',str(ov),'-pgo=off','-c','-o',str(binary),'./internal/vp8/dsp'];rec=dict(variant=v,build_argv=cmd,source_snapshot=str(path),overlay_json=str(ov),fixture_sha256=hashlib.sha256(fixturebytes).hexdigest())
 with (e/(v+'-build.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,v+'build';rec['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest();rec['binary_size']=binary.stat().st_size
 runenv=env.copy();runenv.update(GOMAXPROCS='1',ROSETTA_ADVERTISE_AVX='1',GOVPX_REQUIRE_SIMD='1',GODEBUG='');cmd=['arch','-x86_64',str(binary),'-test.run=^$','-test.bench=^BenchmarkDCPairRowsNative$','-test.benchtime=1x','-test.count=1','-test.cpu=1','-test.benchmem'];rec['oracle_argv']=cmd
 if (e/(v+'-oneshot.log')).is_file() and (e/(v+'-oneshot.log')).read_text().rstrip().endswith('PASS'):
  r=subprocess.CompletedProcess(cmd,0);rec['reused_existing_PASS_oracle_log']=True
 else:
  with (e/(v+'-oneshot.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env=runenv,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,v+'oracle';text=(e/(v+'-oneshot.log')).read_text();rows=re.findall(r'^(BenchmarkDCPairRowsNative/\S+)\s+1\s+(?:[\d.]+ ns/op\s+)?0 B/op\s+0 allocs/op$',text,re.M);assert len(rows)==18 and len(set(rows))==18,(v,len(rows))
 if names is None:names=set(rows)
 assert set(rows)==names;rec.update(cases=rows,all18_oracles_zeroalloc=True,performance_measurement=False);records.append(rec)
 (e/'commands.json').write_text(json.dumps({'environment':{k:env[k]for k in ['CODEX_AGENT_ID','CODEX_PROJECT_CACHE_ROOT','GOTOOLCHAIN','GO','GOEXPERIMENT','GOFLAGS','GOMAXPROCS','GOARCH','GOOS','CGO_ENABLED']},'oneshot_environment':{'GOMAXPROCS':1,'ROSETTA_ADVERTISE_AVX':1,'GOVPX_REQUIRE_SIMD':1,'GODEBUG':''},'records':records},indent=2));print(v+' translatedAMD18oracles PASS0alloc; no speedclaim',flush=True)
# Native CI names are package qualified; preserve every exact old498 name.
raw=Path('/private/tmp/govpx-amd64-b6209532-artifact/assembly-kernels.txt');pkg='';old=set()
for line in raw.read_text().splitlines():
 if line.startswith('pkg: '):pkg=line[5:]
 m=re.match(r'^(Benchmark\S+)\s+\d+\s+',line)
 if m:old.add(pkg+'/'+m[1])
assert len(old)==498,len(old)
new={'github.com/thesyncim/govpx/internal/vp8/dsp/'+n for n in names};assert not old&new and len(old|new)==516
(e/'timed-name-inventory.json').write_text(json.dumps({'old498':sorted(old),'new18':sorted(new),'combined516':sorted(old|new),'samples_516x18':9288,'all_old_names_retained':True},indent=2))
(e/'PASS.json').write_text(json.dumps({'shell_syntax':'PASS','source_paths':103,'common_overlays':32,'old_cases_preserved':498,'new_cases':18,'total_cases':516,'timed_samples':9288,'translated_AMD_oneshots':54,'all_oracles_pass_zeroalloc':True,'excluded_total':392,'guard_excluded_separate':66,'guard_timed_separate':396,'raw_files_unchanged':92,'root_source_mutations':False,'frozen_reference_mutations':False,'native_performance_claim':False},indent=2));print('END ALL GO/BUILD/ORACLE JOBS STOPPED',flush=True)

from pathlib import Path
import json,hashlib,shutil,re,subprocess,difflib
p=Path('/private/tmp/govpx-next-wide-sad-avx2');c=p/'candidate';root=Path('/Users/thesyncim/GolandProjects/govpx');out=Path('/private/tmp/govpx-wide-sad-avx2-ready');out.mkdir(exist_ok=True)
head='768f2fc2aba7bbd82981494473cbadc026a95570'
paths=['internal/pixel/sad_amd64.go','internal/pixel/sad_wide_amd64_test.go','internal/vp9/dsp/sad_wide_native_test.go','scripts/benchmark-amd64.sh']
patch=[];hashes={}
for rel in paths:
 f=c/rel;q=out/'overlay'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,q)
 r=subprocess.run(['git','show',head+':'+rel],cwd=root,capture_output=True);old=r.stdout if r.returncode==0 else b''
 if old:
  q=out/'parent'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(old)
 hashes[rel]=dict(parent=hashlib.sha256(old).hexdigest() if old else None,candidate=hashlib.sha256(f.read_bytes()).hexdigest())
 patch+=difflib.unified_diff(old.decode().splitlines(True),f.read_text().splitlines(True),fromfile='a/'+rel if old else '/dev/null',tofile='b/'+rel)
(out/'candidate.patch').write_text(''.join(patch));(out/'source-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
for f in p.iterdir():
 if f.is_file() and f.suffix in ['.log','.json','.py','.txt']:
  q=out/'evidence'/f.name;q.parent.mkdir(exist_ok=True);shutil.copyfile(f,q)
for name in ['first-reduction-counterexample','pre-narrow-order-counterexample']:shutil.copytree(p/name,out/'evidence'/name,dirs_exist_ok=True)
# Full benchmark regex retains every old included name and adds exactly this alternative.
oldScript=(out/'parent/scripts/benchmark-amd64.sh').read_text();newScript=(c/'scripts/benchmark-amd64.sh').read_text()
oldRE=re.search(r"^benchmarks='([^']+)'",oldScript,re.M)[1];newRE=re.search(r"^benchmarks='([^']+)'",newScript,re.M)[1]
assert oldRE==newRE.replace('WideSADNative|','',1)
logs=['rosetta-ordinary-public54','rosetta-checkptr2-public54','rosetta-actual-avx-off-public54','rosetta-parent768-public54','rosetta-old691-public54','rosetta-purego-public54','rosetta-nosimd-public54'];oracle={}
for name in logs:
 rows=[]
 for line in (p/(name+'.log')).read_text().splitlines():
  m=re.match(r'(BenchmarkVP9WideSADNative/\S+)\s+\d+\s+[\d.]+ ns/op\s+(\d+) B/op\s+(\d+) allocs/op',line)
  if m:rows.append(m.groups())
 assert len(rows)==54,(name,len(rows));assert all(int(b)==int(a)==0 for n,b,a in rows)
 oracle[name]={'cases':54,'zero_bytes_and_allocations':True,'result_oracle_and_full_input_canaries':'pass'}
# Parse actual final ordinary codegen. Whole-function calls belong to original
# scalar/narrow/bounds fallback; hot wide loop is the final contiguous block.
codegen={}
for name in ['linux-SAD','darwin-SAD']:
 text=(p/(name+'-llvm.txt')).read_text();lines=[]
 for line in text.splitlines():
  m=re.match(r'\s*([0-9a-f]+):\s+(\S+)\s*(.*)',line)
  if m:lines.append((int(m[1],16),m[2],m[3],line))
 vzero=[i for i,r in enumerate(lines) if r[1]=='vzeroupper'];assert len(vzero)==1
 vi=vzero[0];start=next(i for i,r in enumerate(lines) if r[1]=='vpsadbw')
 hot=lines[start:vi+1];assert not any(r[1].startswith('call') for r in hot)
 vectorstack=[r[3] for r in lines if re.search(r'%(?:[xyz]mm)\d+',r[2]) and '%rsp' in r[2]];assert not vectorstack,vectorstack
 legacy=[r[3] for r in lines if re.search(r'%(?:[xyz]mm)\d+',r[2]) and not r[1].startswith('v')];assert not legacy,legacy
 assert lines[vi-1][1]=='movslq' and '%rax' in lines[vi-1][2]
 post=[]
 for r in lines[vi+1:]:
  post.append(r[1]);assert not re.search(r'%(?:[xyz]mm)\d+',r[2])
  if r[1].startswith('ret'):break
 codegen[name]={'whole_function_instruction_count':len(lines),'wide_loop_VPSADBW_256_sites':sum(r[1]=='vpsadbw' for r in hot),'wide_loop_calls':0,'vector_stack_operations':0,'legacy_vector_operations':0,'VZEROUPPER':1,'result_in_rax_before_fence':True,'post_fence_ops_until_return':post}
summary={'status':'correctness/codegen ready; native x64 performance pending','parent_sha':head,'old_assembly_sha':'691cd0512c4829d9ee40d483205dd223f9eb028d','production_delta':['internal/pixel/sad_amd64.go'],'overlay_paths':paths,'new_public_cases':54,'wide_cases':45,'narrow_controls':9,'full_matrix_before_Fill_additions':400,'old_full_regex_preserved_exactly':True,'one_shot_oracles':oracle,'codegen':codegen,'race_scope':'native selected/CPU-off race+checkptr gates prepared in full CI script; local Rosetta checkptr2 ordinary only','performance_claim':None}
(out/'audit.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'binary-sha256.json').write_text(json.dumps({f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.glob('*.test')},indent=2)+'\n')
print(json.dumps(summary,indent=2))

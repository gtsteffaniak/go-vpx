import re,json,collections
from pathlib import Path
P=Path('/private/tmp/govpx-next-wide-sad-avx2')
def parse(path):
 out={}
 for line in path.read_text().splitlines():
  m=re.match(r'\s*([0-9a-f]+):\s+(\S+)\s*(.*)',line)
  if m:out[int(m[1],16)]=(m[2],m[3],line)
 return out

def trace(code,h,ss=37,rs=43):
 addrs=list(code);nxt={a:b for a,b in zip(addrs,addrs[1:])};pc=next(a for a in addrs if 'Enabled>' in code[a][2])
 regs=dict(rax=0x100000,rbx=(h-1)*ss+8,rcx=(h-1)*ss+8,rdi=ss,rsi=0x200000,r8=(h-1)*rs+8,r9=(h-1)*rs+8,r10=rs,r11=8,rsp=0x100000000,rbp=0,r14=0)
 mem={regs['rsp']+o:v for o,v in [(0x70,h),(0x78,regs['rax']),(0x90,ss),(0x98,regs['rsi']),(0xb0,rs)]};calls=[];seq=[];flags={}
 def reg(r):
  r=r.lstrip('%');return {'eax':'rax','ebx':'rbx','ecx':'rcx','edx':'rdx','esi':'rsi','edi':'rdi'}.get(r,r[:-1] if re.match(r'r\d+d$',r) else r)
 def address(x):
  m=re.fullmatch(r'([^()]*)\((%\w+)(?:,(%\w+)(?:,([1248]))?)?\)',x);assert m,x
  d,base,index,scale=m.groups();return (int(d,0) if d else 0)+regs[reg(base)]+(regs[reg(index)]*int(scale or 1) if index else 0)
 def value(x):
  x=x.strip()
  if x.startswith('$'):return int(x[1:],0)
  if x.startswith('%'):return regs[reg(x)]
  if '(%rip)' in x:return 1
  return mem[address(x)]
 def store(x,v):
  x=x.strip()
  if x.startswith('%'):regs[reg(x)]=v
  else:mem[address(x)]=v
 def split(x):return re.split(r',\s*(?![^()]*\))',x)
 for _ in range(300):
  op,args,line=code[pc];newpc=nxt.get(pc);args=args.split('#')[0].strip()
  if op.startswith('nop'):pc=newpc;continue
  seq.append((op,args))
  if op=='retq':break
  if op in ('movq','movl'):a,b=split(args);store(b,value(a))
  elif op=='leaq':a,b=split(args);store(b,address(a))
  elif op in ('imulq','addq','subq'):a,b=split(args);x,y=value(a),value(b);store(b,y*x if op=='imulq' else y+x if op=='addq' else y-x)
  elif op in ('cmpq','cmpb','testq'):
   a,b=split(args);x,y=value(a),value(b);v=y-x if op.startswith('cmp') else x&y;flags=dict(eq=v==0,lt=v<0,le=v<=0,be=(y%(1<<64))<=(x%(1<<64)),a=(y%(1<<64))>(x%(1<<64)))
  elif op.startswith('j'):
   dest=int(args.split()[0],0)
   take={'je':flags.get('eq'),'jne':not flags.get('eq'),'jl':flags.get('lt'),'jle':flags.get('le'),'jbe':flags.get('be'),'ja':flags.get('a'),'jmp':True}[op]
   if take:newpc=dest
  elif op=='callq':
   assert 'sad8x8Ptr>' in args,args
   calls.append([regs[x] for x in ['rax','rbx','rcx','rdi']]);rsp=regs['rsp'];rbp=regs['rbp'];regs={x:-999 for x in regs};regs.update(rsp=rsp,rbp=rbp,rax=17+2*(len(calls)-1))
  elif op=='popq':pass
  else:raise ValueError((op,args))
  pc=newpc
 else:raise ValueError('trace did not return')
 return dict(instructions_without_alignment_nops=len(seq),opcode_counts=dict(collections.Counter(op for op,args in seq)),helper_call_args=calls,return_value=regs['rax'],normalized_instructions=[op+' '+re.sub(r'0x[0-9a-f]+ <[^>]+>','TARGET',a) for op,a in seq])

out={}
for name,file in [('parent','parent768-linux-SAD-llvm.txt'),('candidate','linux-SAD-llvm.txt')]:out[name]={str(h):trace(parse(P/file),h) for h in [8,16]}
proof={'scope':'Static execution of ordinary Linux AMD64 valid width8 paths, Enabled=true, h8/16, strides37/43 and exact spans. Calls are recorded and modeled with distinct scalar returns; this is codegen analysis, not native execution or timing.','literal_instruction_identity':False,'differences':'Enabled branch orientation/layout, endpoint GPR choices and ADD/LEA selection differ; no new wide-geometry/AVX2 guard executes on valid narrow paths.','paths':out}
for h in ['8','16']:
 a,b=out['parent'][h],out['candidate'][h];assert a['helper_call_args']==b['helper_call_args'];assert a['return_value']==b['return_value'];print(h,a['instructions_without_alignment_nops'],b['instructions_without_alignment_nops'],a['helper_call_args'])
(P/'narrow-path-proof.json').write_text(json.dumps(proof,indent=2)+'\n')

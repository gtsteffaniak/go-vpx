from pathlib import Path
import os,subprocess,json,time
p=Path('/private/tmp/govpx-next-wide-sad-avx2');c=p/'candidate';root=Path('/Users/thesyncim/GolandProjects/govpx');records=[]
env=os.environ.copy();env.update(CODEX_AGENT_ID='ci-wide-sad-avx2',CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',GOTOOLCHAIN='local',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',GOMAXPROCS='2',GOFLAGS='-p=2',GOAMD64='v1')
wrapper=str(root/'scripts/go.sh')
def run(name,args,extra={}):
 e=env.copy();e.update(extra);start=time.time()
 with open(p/(name+'.log'),'w') as f:r=subprocess.run(args,cwd=root,env=e,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(name=name,argv=args,environment_overrides=extra,start=start,end=time.time(),exit=r.returncode));(p/'validation-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True)
 assert r.returncode==0,name
run('gocache',[wrapper,'env','GOCACHE'])
for mode,flags in [('ordinary',[]),('checkptr2',['-gcflags=all=-d=checkptr=2'])]:
 for pkg,label in [('./internal/pixel','pixel'),('./internal/vp9/dsp','dsp')]:
  dest=p/(mode+'-'+label+'-darwin.test')
  run('build-'+mode+'-'+label,[wrapper,'-C',str(c),'test','-pgo=off']+flags+['-c','-o',str(dest),pkg],{'GOOS':'darwin','GOARCH':'amd64','CGO_ENABLED':'0'})
  rx='Test.*SAD|Test.*Sad'
  run('rosetta-'+mode+'-'+label,['arch','-x86_64',str(dest),'-test.run='+rx,'-test.count=1','-test.v'],{'ROSETTA_ADVERTISE_AVX':'1','GOVPX_REQUIRE_SIMD':'1'})
  if label=='dsp':run('rosetta-'+mode+'-public54',['arch','-x86_64',str(dest),'-test.run=^$','-test.bench=^BenchmarkVP9WideSADNative$','-test.benchtime=1x','-test.count=1'],{'ROSETTA_ADVERTISE_AVX':'1','GOVPX_REQUIRE_SIMD':'1'})
run('rosetta-actual-avx-off',['arch','-x86_64',str(p/'ordinary-pixel-darwin.test'),'-test.run=TestSADWideAVX2','-test.count=1','-test.v'],{'ROSETTA_ADVERTISE_AVX':'1','GODEBUG':'cpu.avx=off,cpu.avx2=off','GOVPX_REQUIRE_SIMD':'0','GOVPX_REQUIRE_SAD_AVX2_OFF':'1'})
run('rosetta-actual-avx-off-public54',['arch','-x86_64',str(p/'ordinary-dsp-darwin.test'),'-test.run=^$','-test.bench=^BenchmarkVP9WideSADNative$','-test.benchtime=1x','-test.count=1'],{'ROSETTA_ADVERTISE_AVX':'1','GODEBUG':'cpu.avx=off,cpu.avx2=off','GOVPX_REQUIRE_SIMD':'0','GOVPX_REQUIRE_SAD_AVX2_OFF':'1'})
run('build-linux-pixel',[wrapper,'-C',str(c),'test','-pgo=off','-c','-o',str(p/'ordinary-pixel-linux.test'),'./internal/pixel'],{'GOOS':'linux','GOARCH':'amd64','CGO_ENABLED':'0'})
print('VALIDATION STOPPED',flush=True)

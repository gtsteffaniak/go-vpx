from pathlib import Path
import subprocess,hashlib,json,re,difflib,shutil
root=Path('/Users/thesyncim/GolandProjects/govpx');snap=Path('/private/tmp/govpx-sse8-insert-pack-candidate');out=Path('/private/tmp/govpx-sse8-insert-pack-ready');out.mkdir(exist_ok=False)
base='c638b7c76eac857affa0780820e86c211cdd84d3'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tracked=subprocess.check_output(['git','ls-tree','-r',base],cwd=root,text=True).splitlines()
changed=[];deleted=[];allhashes=[];patch=[]
for line in tracked:
 meta,f=line.split('\t',1)
 if not f.endswith('.go') and f not in ['go.mod','go.sum']:continue
 p=snap/f
 if not p.is_file():deleted.append(f);continue
 data=p.read_bytes();allhashes.append(sha(p)+'  '+f)
 blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 if blob != meta.split()[2]:changed.append(f)
new=['internal/pixel/sse8_rows_arm64.go','internal/pixel/sse8_entry_fallback_amd64_test.go']
for f in new:allhashes.append(sha(snap/f)+'  '+f)
for f in changed+deleted+new:
 old=b'' if f in new else subprocess.check_output(['git','show',base+':'+f],cwd=root)
 data=b'' if f in deleted else (snap/f).read_bytes()
 if old:
  p=out/'parent'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(old)
 if data:
  p=out/'candidate'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 patch.extend(difflib.unified_diff(old.decode().splitlines(True),data.decode().splitlines(True),fromfile='/dev/null' if f in new else 'a/'+f,tofile='/dev/null' if f in deleted else 'b/'+f))
(out/'candidate.patch').write_text(''.join(patch))
(out/'all-go-module-source-sha256.txt').write_text('\n'.join(sorted(allhashes))+'\n')
arm=(snap/'internal/pixel/sse8_rows_arm64.go').read_text();common=subprocess.check_output(['git','show','ab3abd6b:internal/pixel/sse_simd.go'],cwd=root,text=True)
assert arm[arm.index('// SSE8 packs'):]==common[common.index('// SSE8 packs'):]
amd=(snap/'internal/pixel/sse8_rows_wide_amd64.go').read_text();a=amd.index('\t\tif h >= 8 {');depth=0;b=None
for i in range(a,len(amd)):
 if amd[i]=='{':depth+=1
 elif amd[i]=='}':
  depth-=1
  if depth==0:b=i+2;break
stripped=amd[:a]+amd[b:]
pre=subprocess.check_output(['git','show','ab3abd6b:internal/pixel/sse_simd.go'],cwd=root,text=True)
assert stripped[stripped.index('// SSE8 packs'):]==pre[pre.index('// SSE8 packs'):]
# Pair packing is verified separately by the exact incremental diff.
for f,n in [('sse8_ptr_amd64.go',4),('sse8_rows_wide_amd64.go',2)]:
 prior=Path('/private/tmp/govpx-sse8-inline-entry-candidate/internal/pixel')/f
 pat=r'archsimd\.BroadcastUint64x4\((\*\(\*uint64\)\(unsafe\.Add\([^\n]*?\)\))\)\.InterleaveLoGrouped\(archsimd\.BroadcastUint64x4\((\*\(\*uint64\)\(unsafe\.Add\([^\n]*?\)\))\)\)\.GetLo\(\)\.ReshapeToUint8s\(\)\.ExtendToUint16\(\)\.BitsToInt16\(\)'
 expected,count=re.subn(pat,lambda m:'(archsimd.Uint64x2{}).SetElem(0, '+m[1]+').SetElem(1, '+m[2]+').ReshapeToUint8s().ExtendToUint16().BitsToInt16()',prior.read_text())
 assert count==n and expected==(snap/'internal/pixel'/f).read_text()
for n in ['pixel-checkptr-build.log','pixel-selected.log','pixel-cpuoff.log','dsp-checkptr-build.log','dsp-selected.log','dsp-cpuoff.log','linux-build.log','darwin-build.log','arm-tests.log','purego-tests.log','nosimd-tests.log','linux-build-final.log','arm-build.log','arm-parent-build.log']:
 p=out/'validation'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2('/private/tmp/govpx-sse8-insert-pack-'+n,p)
for n in ['linux','darwin']:
 p=out/'codegen'/(n+'.txt');p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2('/private/tmp/govpx-sse8-insert-pack-'+n+'-llvm.txt',p)
shutil.copy2('/private/tmp/govpx-sse8-direct-fence-ready/sdk-intrinsics-snippet.txt',out/'sdk-intrinsics-snippet.txt')

def codegen(p):
 parts=re.split(r'(?m)^([0-9a-f]+) <([^>]+)>:\n',p.read_text());d={}
 for i in range(1,len(parts),3):
  sym,body=parts[i+1:i+3];ins=[]
  for l in body.splitlines():
   m=re.match(r'\s*([0-9a-f]+):\s+(?:[0-9a-f]{2}\s+)+\s*(\S+)(.*)',l)
   if m:ins.append((int(m[1],16),m[2],m[3].strip()))
  starts=[pc for pc,m,a in ins if '%ymm' in a]
  start=min(starts);by_pc={x[0]:x for x in ins};positions={x[0]:j for j,x in enumerate(ins)}
  todo=[start];seen=set()
  while todo:
   pc=todo.pop()
   if pc in seen or pc not in by_pc:continue
   seen.add(pc);_,m,a=by_pc[pc];j=positions[pc]
   if m.startswith('ret') or m.startswith('call'):continue
   target=re.match(r'0x([0-9a-f]+)',a)
   if m.startswith('j') and target:todo.append(int(target[1],16))
   if not m.startswith('jmp') and j+1<len(ins):todo.append(ins[j+1][0])
  live=[by_pc[pc] for pc in sorted(seen)]
  legacy=lambda xs:[[hex(pc),m,a] for pc,m,a in xs if ('%xmm' in a or '%ymm' in a) and not m.startswith('v')]
  d[sym]={'total_decoded_instructions_including_all_branches_and_alignment':len(ins),'calls':[[hex(pc),a] for pc,m,a in ins if m.startswith('call')],'all_legacy_vectors':legacy(ins),'wide_reachable_instruction_count':len(live),'wide_reachable_calls':[[hex(pc),a] for pc,m,a in live if m.startswith('call')],'wide_reachable_legacy_vectors':legacy(live),'wide_reachable_vzeroupper':sum(m=='vzeroupper' for pc,m,a in live),'vector_stack_traffic':[[hex(pc),m,a] for pc,m,a in ins if '%rsp' in a and ('%xmm' in a or '%ymm' in a)],'fence_return_regions':[ins[max(0,j-3):j+4] for j,(pc,m,a) in enumerate(ins) if m=='vzeroupper']}
  assert not d[sym]['wide_reachable_calls'] and not d[sym]['wide_reachable_legacy_vectors'] and d[sym]['wide_reachable_vzeroupper']==1
 return d
checks={}
for n in ['dsp-selected.log','dsp-cpuoff.log']:
 t=(out/'validation'/n).read_text();rows=[l for l in t.splitlines() if re.match(r'^BenchmarkSSE8RowsNative/.*\s+1\s+',l)]
 checks[n]={'case_count':len(rows),'pass':t.rstrip().endswith('PASS'),'all_one_shot_allocation_readings_zero':all(re.search(r'\b0 B/op\s+0 allocs/op$',l) for l in rows)}
 assert len(rows)==36 and checks[n]['pass'] and checks[n]['all_one_shot_allocation_readings_zero']
proof={'base':base,'scope':'Private SetElem pair packing plus direct-fence/inline-entry/ARM-stub cleanup; no native or emulated performance claim','modified':changed,'deleted':deleted,'new':new,'arm_SSE8_body_verbatim_from_ab3':True,'AMD_narrow_and_fallback_body_exact_ab3_after_removing_wide_block':True,'only_SIX_two_row_pack_expressions_differ_from_inline_entry_variant':True,'unused_source_scope':'Removed unreferenced AMD zero helper plus both ARM false availability/zero stubs. ARM entry body is exact pre42 ab3.','codegen':{n:codegen(out/'codegen'/(n+'.txt')) for n in ['linux','darwin']},'public_one_shot_checks':checks,'source_hashes':{f:sha(snap/f) for f in changed+new},'binary_hashes':{f:sha(Path('/private/tmp/'+f)) for f in ['govpx-sse8-insert-pack-linux.test','govpx-sse8-insert-pack-darwin.test','govpx-sse8-insert-pack-pixel-checkptr.test','govpx-sse8-insert-pack-dsp-checkptr.test','govpx-sse8-insert-pack-arm.test','govpx-sse8-insert-pack-arm-parent.test']}}
proof['arm_codegen_cleanup']=json.loads(Path('/private/tmp/govpx-sse8-insert-pack-arm-normalized-proof.json').read_text())
(out/'audit.json').write_text(json.dumps(proof,indent=2)+'\n')
for n in ['arm','arm-parent']:
 shutil.copy2('/private/tmp/govpx-sse8-insert-pack-'+n+'-llvm.txt',out/'codegen'/(n+'.txt'))
shutil.copy2('/private/tmp/govpx-sse8-insert-pack-arm-normalized-proof.json',out/'codegen'/'arm-normalized-proof.json')
(out/'REPORT.md').write_text('''# Final private AMD SSE8 SetElem packing variant

Exact base c638b7c76eac857affa0780820e86c211cdd84d3. Go 1.27.2, GOEXPERIMENT=simd, GOAMD64=v1, PGO off. The prior 35-member inline-entry package remains frozen and unchanged. This is a separate variant; no root source/index/README edits and no native or emulated performance claim. Native CI must establish speed and regressions.

The direct-return pointer and inline-wide slice entry retain the reviewed geometry, arithmetic, panic order, scalar CPU-off fallback and fence placement. Exactly six full two-row packing expressions change from four-lane broadcasts/interleave/extract to two Uint64x2 SetElem inserts, then full-byte-to-uint16 widening to YMM. Row0/row1 remain the low/high 64-bit halves, unaligned exact eight-byte reads remain unchanged, and all 16 unsigned input lanes widen before signed subtraction. The maximum squared-error sums fit int32. The odd slice tail is unchanged. The narrow and unusual-geometry body is exact ab3 after removing the inserted wide block.

ARM cleanup uses the exact original ab3 SSE8 body and deletes both dead availability/zero stubs plus the unused AMD zero-global helper. Native ordinary ARM source and codegen proof confirms its complete 228-instruction body is identical after normalizing branch target PCs; SHA256 e07cd7a5367223534e175e33810d74457daba6052fa9c3829cba6a754936b319. No ARM optimization is replaced.

Optimized Linux and Darwin each have 141 decoded pointer instructions (prior inline-entry 149) and 339 full slice-entry instructions (prior 373), including all cold/fallback/padding paths. Pointer full-row pairs lose all eight broadcasts and four extracts; only the two reduction extracts remain. All wide-reachable CFGs have zero legacy vector instructions, zero hot calls and zero vector stack traffic, with one inline VZEROUPPER after EAX extraction. Narrow/unusual slice branches retain their original four legacy XMM initialization moves and cannot be reached from the wide loop. Counts diagnose code generation, not performance.

Checkptr=2 required-SIMD pixel exact rows, all 65,536 byte pairs, aliases, bounds/fallback and pointer diagnostic tests pass. Actual AVX/AVX2-off pixel tests also pass. All 36 public DSP scalar/canary one-shot fixtures and TestVarianceBlocks pass selected and CPU-off, with zero one-shot B/op and allocs/op readings. Native ARM, purego and nosimd focused tests pass. Rosetta timings are not performance evidence.

The preexisting trusted pointer contract requires complete valid windows. Explicit fences cover valid normal SIMD returns; exceptional cleanup after a nonnil invalid/dangling/undersized pointer is outside this contract, as documented in the direct-fence assessment. Scalar/geometry fallback remains before wide SIMD.

The first private build caught BSD patch leaving a deleted source as an empty file. The failed setup log is retained, the empty file was removed, and all final builds/checks passed. The reproducer uses patch -E, which removes deleted files. Source/binary hashes, all raw logs, both optimized targets, exact parent/final sources, full patch and ARM codegen proof are preserved. No additional variants or timings were run.
''')
(out/'reproduce.sh').write_text('''#!/bin/sh
set -eu
root=${GOVPX_ROOT:-/Users/thesyncim/GolandProjects/govpx}
package=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
work=$(mktemp -d /private/tmp/govpx-sse8-entry-repro.XXXXXX)
git -C "$root" archive c638b7c76eac857affa0780820e86c211cdd84d3 | tar -x -C "$work"
(cd "$work" && patch -E -p1 < "$package/candidate.patch")
export CODEX_AGENT_ID=ci-sse8-entry-repro CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GOMAXPROCS=2 GOFLAGS=-p=2
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go GOOS=darwin GOARCH=amd64 GOAMD64=v1
cd "$root"
./scripts/go.sh -C "$work" test -pgo=off -gcflags=all=-d=checkptr=2 -c -o "$work/pixel.test" ./internal/pixel
./scripts/go.sh -C "$work" test -pgo=off -gcflags=all=-d=checkptr=2 -c -o "$work/dsp.test" ./internal/vp8/dsp
ROSETTA_ADVERTISE_AVX=1 GOVPX_REQUIRE_SIMD=1 arch -x86_64 "$work/pixel.test" -test.run 'Test(SSE8|SquaredError)' -test.v
ROSETTA_ADVERTISE_AVX=1 GODEBUG=cpu.avx=off,cpu.avx2=off arch -x86_64 "$work/pixel.test" -test.run 'Test(SSE8|SquaredError)' -test.v
ROSETTA_ADVERTISE_AVX=1 GOVPX_REQUIRE_SIMD=1 arch -x86_64 "$work/dsp.test" -test.run 'Test(SquaredError|SSE8)' -test.bench '^BenchmarkSSE8RowsNative$' -test.benchtime=1x -test.count=1 -test.cpu=1
ROSETTA_ADVERTISE_AVX=1 GODEBUG=cpu.avx=off,cpu.avx2=off arch -x86_64 "$work/dsp.test" -test.run 'Test(SquaredError|SSE8)' -test.bench '^BenchmarkSSE8RowsNative$' -test.benchtime=1x -test.count=1 -test.cpu=1
''')
shutil.copy2('/private/tmp/govpx-package-sse8-insert-pack.py',out/'package-evidence.py')
manifest=[sha(p)+'  '+str(p.relative_to(out)) for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'SHA256SUMS']
(out/'SHA256SUMS').write_text('\n'.join(manifest)+'\n')
print(json.dumps({'out':str(out),'members':len(manifest),'manifest_sha256':sha(out/'SHA256SUMS'),'modified':changed,'deleted':deleted,'new':new},indent=2))

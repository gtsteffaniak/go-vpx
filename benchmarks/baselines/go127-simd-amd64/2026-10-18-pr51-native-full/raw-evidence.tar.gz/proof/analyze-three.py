#!/usr/bin/env python3
import json
import pathlib
import re
import statistics
import sys

root = pathlib.Path(sys.argv[1])
variants = ["assembly"]
if (root / "previous-kernels.txt").exists():
    variants.append("previous")
variants.append("simd")
summary = {"artifact": str(root), "variants": variants, "kernels": {}, "encoders": {}}

def compare(entry):
    if "assembly_ns" in entry and "simd_ns" in entry:
        entry["time_delta_percent"] = 100 * (entry["simd_ns"] / entry["assembly_ns"] - 1)
        entry["throughput_ratio"] = entry["assembly_ns"] / entry["simd_ns"]
        entry["paired_percent"] = [100 * (b / a - 1) for a, b in zip(entry["assembly_samples"], entry["simd_samples"])]
    if "previous_ns" in entry and "simd_ns" in entry:
        entry["parent_time_delta_percent"] = 100 * (entry["simd_ns"] / entry["previous_ns"] - 1)
        entry["parent_throughput_ratio"] = entry["previous_ns"] / entry["simd_ns"]
        entry["parent_paired_percent"] = [100 * (b / a - 1) for a, b in zip(entry["previous_samples"], entry["simd_samples"])]

kernels = {}
for variant in variants:
    package = ""
    entries = {}
    for line in (root / (variant + "-kernels.txt")).read_text().splitlines():
        if line.startswith("pkg: "):
            package = line[5:]
        match = re.match(r"^(Benchmark\S+)\s+\d+\s+([\d.]+)\s+ns/op.*?([\d.]+)\s+B/op\s+([\d.]+)\s+allocs/op", line)
        if match:
            key = package + "/" + match[1]
            entries.setdefault(key, []).append(tuple(map(float, match.groups()[1:])))
    kernels[variant] = entries
keys = set().union(*(entries.keys() for entries in kernels.values()))
for key in sorted(keys):
    entry = {}
    for variant in variants:
        if key in kernels[variant]:
            samples = kernels[variant][key]
            entry[variant + "_ns"] = statistics.median(x[0] for x in samples)
            entry[variant + "_samples"] = [x[0] for x in samples]
            entry[variant + "_allocation_samples"] = sorted(set(x[1:] for x in samples))
    compare(entry)
    summary["kernels"][key] = entry

fields = ["output_bytes", "encoded_frames", "dropped_frames", "allocs_per_frame", "quantizers", "quantizer_histogram", "keyframe_bytes", "avg_interframe_bytes"]
for label, pattern in (("VP9 320x180", "{variant}-encoder-{round}.json"), ("VP8 720p", "{variant}-vp8-720p-encoder-{round}.json"), ("VP9 720p", "{variant}-vp9-720p-encoder-{round}.json")):
    entry = {}
    data = {}
    for variant in variants:
        data[variant] = [json.loads((root / pattern.format(variant=variant, round=i)).read_text()) for i in range(1, 7)]
        times = [row["ns_per_frame"] for row in data[variant]]
        entry[variant + "_ns"] = statistics.median(times)
        entry[variant + "_samples"] = times
        entry[variant + "_allocation_samples"] = [row["allocs_per_frame"] for row in data[variant]]
    compare(entry)
    rows = [row for variant in variants for row in data[variant]]
    entry["parity"] = {field: {"equal": all(row.get(field) == rows[0].get(field) for row in rows), "value": rows[0].get(field)} for field in fields}
    if "previous" in variants:
        pair = data["previous"] + data["simd"]
        entry["parent_parity"] = {field: {"equal": all(row.get(field) == pair[0].get(field) for row in pair), "value": pair[0].get(field)} for field in fields}
    summary["encoders"][label] = entry
json.dump(summary, sys.stdout, indent=2)
print()

#!/usr/bin/env python3
import json,pathlib,sys
root=pathlib.Path(sys.argv[1]);variants=['assembly','previous','simd']
timing={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'}
out={}
for label,pat in [('VP9 320x180','{v}-encoder-{i}.json'),('VP8 720p','{v}-vp8-720p-encoder-{i}.json'),('VP9 720p','{v}-vp9-720p-encoder-{i}.json')]:
 rows={v:[json.loads((root/pat.format(v=v,i=i)).read_text()) for i in range(1,7)] for v in variants}
 allrows=[r for v in variants for r in rows[v]]
 keys=sorted(set.union(*(set(r) for r in allrows))-timing)
 base=allrows[0]
 fields={k:all(r.get(k)==base.get(k) for r in allrows) for k in keys}
 out[label]={'semantic_fields':fields,'all_semantic_fields_equal':all(fields.values()),'allocation_samples':{v:[r['allocs_per_frame'] for r in rows[v]] for v in variants}}
for codec in ['vp8','vp9']:
 rows={v:json.loads((root/(v+'-'+codec+'-720p-profile.json')).read_text()) for v in variants}
 allrows=list(rows.values());keys=sorted(set.union(*(set(r) for r in allrows))-timing);base=allrows[0]
 fields={k:all(r.get(k)==base.get(k) for r in allrows) for k in keys}
 out[codec.upper()+' 720p profile']={'semantic_fields':fields,'all_semantic_fields_equal':all(fields.values()),'allocation_samples':{v:r['allocs_per_frame'] for v,r in rows.items()}}
print(json.dumps(out,indent=2))

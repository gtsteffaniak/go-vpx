from pathlib import Path
import subprocess,json,re,hashlib,sys,ast
R=Path(sys.argv[1]);H=sys.argv[2];B=sys.argv[3];ROOT='/Users/thesyncim/GolandProjects/govpx';D=R/'pixel-optional-stats-codegen';sha=lambda b:hashlib.sha256(b).hexdigest();log=(R/'pixel-optional.txt').read_text()
def git(*args,input=None):return subprocess.check_output(['git','--no-optional-locks',*args],input=input,cwd=ROOT)
source=git('show',H+':scripts/capture-stats-codegen.py');tree=ast.parse(source);constants={}
for node in tree.body:
 if isinstance(node,ast.Assign)and len(node.targets)==1 and isinstance(node.targets[0],ast.Name)and node.targets[0].id in ('OWNERS','PREFIX','FIXTURES'):constants[node.targets[0].id]=ast.literal_eval(node.value)
PREFIX=constants['PREFIX'];owners={PREFIX+n for n in constants['OWNERS']};fixtures=constants['FIXTURES'];assert len(owners)==12 and len(fixtures)==2
feature=re.findall(r'FP32PublicHost AVX512=(true|false) AVX2=(true|false) Enabled=(true|false)',log);orders=re.findall(r'^# round (\d+) order (parent current|current parent)$',log,re.M);assert len(feature)==3 and orders==[(str(r),'parent current'if r%2 else'current parent')for r in range(1,7)];assert 'optional pixel inventory PASS:'in log
expected_source={}
for commit in (H,B):
 paths=git('ls-tree','-r','--name-only',commit,'--','internal/pixel').decode().splitlines();paths=[p for p in paths if p.endswith('.go')and'/'not in p[len('internal/pixel/'):]];blob=git('cat-file','--batch',input=''.join(commit+':'+p+'\n'for p in paths).encode());off=0;data={}
 for p in paths:
  e=blob.index(b'\n',off);hdr=blob[off:e].decode().split();assert hdr[1]=='blob';n=int(hdr[2]);data[p]=sha(blob[e+1:e+1+n]);off=e+1+n+1
 assert off==len(blob);expected_source[commit]=data
for f in fixtures:expected_source[B]['internal/pixel/'+f]=sha(git('show',H+':internal/pixel/'+f))
assert {p.name for p in D.iterdir()}=={'parent','current'}
out={'scope':'Actual native executable bytes/layout captured after optional timing; binary blobs omitted by CI, source and protocol receipts independently checked','capture_helper_sha256':sha(source),'nested_files_total':0,'variants':{}}
for variant,commit in (('parent',B),('current',H)):
 p=D/variant;m=json.loads((p/'metadata.json').read_text());assert m['variant']==variant and m['source_commit']==commit and m['head_commit']==H and m['base_commit']==B
 assert m['capture_helper_SHA256']==sha(source)and m['protocol_SHA256']==sha((R/'pixel-optional.txt').read_bytes());assert Path(m['protocol_log']).name=='pixel-optional.txt'
 assert m['actual_source_SHA256']==expected_source[commit]
 fixture_sha={'internal/pixel/'+f:expected_source[H]['internal/pixel/'+f]for f in fixtures};assert m['identical_common_fixture_SHA256']==fixture_sha
 receipts=[x[0]for x in re.findall(r'^([0-9a-f]{64})\s+(.+)$',log,re.M)if x[1]==m['binary']];assert receipts and set(receipts)=={m['binary_sha256']};assert m['binary_size']>0
 assert m['ISA_and_orders']['actual_feature_probes']==[list(x)for x in feature]and m['ISA_and_orders']['orders']==[list(x)for x in orders]
 version=(p/'objdump-version.txt').read_text();assert version.startswith('GNU objdump');info=(p/'binary-buildinfo.txt').read_text();assert 'go1.27.2'in info and'GOOS=linux'in info and'GOARCH=amd64'in info and'GOEXPERIMENT=simd'in info
 symbols=json.loads((p/'symbols.json').read_text());assert symbols==m['live_symbols'];assert PREFIX+'BenchmarkStatsReductionNative.func1'in symbols and set(symbols)<=owners
 assert set(m['absent_may_be_inlined'])==owners-set(symbols)
 independent={}
 for line in(p/'symbols-all.txt').read_text().splitlines():
  match=re.fullmatch(r'\s*([0-9a-fA-F]+)\s+(\d+)\s+([Tt])\s+(\S+)\s*',line)
  if match and match[4]in owners:
   address=int(match[1],16);size=int(match[2]);assert size>0;independent[match[4]]={'address_hex':hex(address),'size_bytes':size,'address_mod16':address%16,'address_mod32':address%32,'address_mod64':address%64,'kind':match[3]}
 assert independent==symbols
 commands=json.loads((p/'commands.json').read_text());assert len(commands)==3+len(symbols);assert all(c['exit_code']==0 for c in commands)
 assert commands[0]['argv']==['objdump','--version']and commands[0]['output']=='objdump-version.txt'
 assert commands[1]['argv'][1:]==['version','-m',m['binary']]and commands[1]['output']=='binary-buildinfo.txt'
 assert commands[2]['argv'][1:]==['tool','nm','-size','-sort','address',m['binary']]and commands[2]['output']=='symbols-all.txt'
 code={}
 for c in commands[3:]:
  a=c['argv'];assert a[0:2]==['objdump','-d']and a[-1]==m['binary']and a[2].startswith('--disassemble=');name=a[2].split('=',1)[1];assert name in symbols;short=name[len(PREFIX):];assert c['output']==short+'.asm.txt'
  text=(p/c['output']).read_text();assert '<'+name+'>:'in text;addresses=[int(x,16)for x in re.findall(r'^\s*([0-9a-fA-F]+):\s+(?:[0-9a-fA-F]{2}\s+)+',text,re.M)];assert addresses and addresses[0]==int(symbols[name]['address_hex'],16)
  start=int(symbols[name]['address_hex'],16);assert all(start<=x<start+symbols[name]['size_bytes']for x in addresses),(variant,name)
  code[name]={'symbol':symbols[name],'raw_asm_sha256':sha((p/c['output']).read_bytes()),'displayed_byte_lines':len(addresses)}
 assert set(code)==set(symbols);assert not(p/'capture.log').read_text()
 expected_files={'objdump-version.txt','binary-buildinfo.txt','symbols-all.txt','symbols.json','commands.json','metadata.json','capture.log'}|{n[len(PREFIX):]+'.asm.txt'for n in symbols};actual={x.name for x in p.iterdir()if x.is_file()};assert actual==expected_files,(variant,actual^expected_files)
 out['nested_files_total']+=len(actual);out['variants'][variant]={'source_commit':commit,'source_Go_files':len(expected_source[commit]),'source_SHA256':expected_source[commit],'binary_SHA256':m['binary_sha256'],'binary_size':m['binary_size'],'actual_features':feature,'code':code,'absent_may_be_inlined':m['absent_may_be_inlined'],'files':len(actual),'GNU_objdump_version':version.splitlines()[0],'CGO_buildinfo':re.findall(r'CGO_ENABLED=\d',info),'source_and_protocol_binding_PASS':True}
assert out['nested_files_total']==14+sum(len(v['code'])for v in out['variants'].values());print(json.dumps(out))

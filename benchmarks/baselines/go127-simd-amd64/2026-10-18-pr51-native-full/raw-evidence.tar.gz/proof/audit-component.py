# Source-only preparation; execute only after native artifact download/host release.
from pathlib import Path
import collections,json,re,statistics,sys,hashlib
R=Path(sys.argv[1]);text=(R/'fp16-guard-component.txt').read_text();assert 'native Linux' not in text or 'diagnostic only' in text
pattern=re.compile(r'^(BenchmarkFP16GuardComponent/([^/]+)/(.+))\s+(\d+)\s+(?:([0-9.eE+\-]+) ns/op\s+)?(\d+) B/op\s+(\d+) allocs/op$')
rows=[];phase='preflight';roundno=0;active=None;orders=[]
for line in text.splitlines():
 m=re.match(r'# round (\d+) order (.+)',line)
 if m:orders.append(m[2].split());phase='timed';continue
 m=re.match(r'# round (\d+) guard (parent|single|unrolled)',line)
 if m:roundno=int(m[1]);active=m[2];continue
 if not line.startswith('BenchmarkFP16GuardComponent/'):continue
 m=pattern.match(line);assert m,line
 name,guard,case,it,ns,b,a=m.groups();name=name.rstrip();case=case.rstrip();assert int(it)>0 and int(b)==int(a)==0
 if phase=='timed':assert active==guard and ns and float(ns)>0
 rows.append(dict(name=name,guard=guard,case=case,phase=phase,round=roundno,ns=float(ns) if ns else None,bytes=int(b),allocs=int(a)))
assert len(rows)==462 and sum(r['phase']=='timed' for r in rows)==396 and sum(r['phase']=='preflight' for r in rows)==66
assert len(orders)==len(set(map(tuple,orders)))==6
for i in range(3):assert collections.Counter(o[i] for o in orders)=={'parent':2,'single':2,'unrolled':2}
cases={r['case'] for r in rows};assert len(cases)==22 and sum(c.startswith('disjoint/') for c in cases)==12
out={}
for case in sorted(cases):
 samples={g:[r for r in rows if r['case']==case and r['guard']==g and r['phase']=='timed'] for g in ['parent','single','unrolled']}
 for rs in samples.values():assert sorted(r['round'] for r in rs)==list(range(1,7))
 med={g:statistics.median(r['ns'] for r in rs) for g,rs in samples.items()}
 out[case]={'samples':samples,'median_ns':med,'parent_over_actual_unrolled':med['parent']/med['unrolled'],'parent_over_single':med['parent']/med['single'],'parent_actual_paired_ratios':[p['ns']/u['ns'] for p,u in zip(samples['parent'],samples['unrolled'])],'component_diagnostic_only':True,'decline_not_acceptance_denominator':case.startswith('decline/')}
assert '--- PASS: TestFP16GuardComponentOracle ' in text
print(json.dumps({'bindings':{'parent':'frozen46 guard','single':'frozen singlecompare','unrolled':'ACTUAL47production'},'orders':orders,'all462_zeroalloc':True,'66_excluded':True,'396_timed':True,'results':out},indent=2))

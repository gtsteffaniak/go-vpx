#!/bin/sh
set -eu
root=${GOVPX_ROOT:-/Users/thesyncim/GolandProjects/govpx}
package=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
work=$(mktemp -d /private/tmp/govpx-sse8-entry-repro.XXXXXX)
git -C "$root" archive c638b7c76eac857affa0780820e86c211cdd84d3 | tar -x -C "$work"
(cd "$work" && patch -p1 < "$package/candidate.patch")
export CODEX_AGENT_ID=ci-sse8-entry-repro CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GOMAXPROCS=2 GOFLAGS=-p=2
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go GOOS=darwin GOARCH=amd64 GOAMD64=v1
cd "$root"
./scripts/go.sh -C "$work" test -pgo=off -gcflags=all=-d=checkptr=2 -c -o "$work/pixel.test" ./internal/pixel
./scripts/go.sh -C "$work" test -pgo=off -gcflags=all=-d=checkptr=2 -c -o "$work/dsp.test" ./internal/vp8/dsp
ROSETTA_ADVERTISE_AVX=1 GOVPX_REQUIRE_SIMD=1 arch -x86_64 "$work/pixel.test" -test.run 'Test(SSE8|SquaredError)' -test.v
ROSETTA_ADVERTISE_AVX=1 GODEBUG=cpu.avx=off,cpu.avx2=off arch -x86_64 "$work/pixel.test" -test.run 'Test(SSE8|SquaredError)' -test.v
ROSETTA_ADVERTISE_AVX=1 GOVPX_REQUIRE_SIMD=1 arch -x86_64 "$work/dsp.test" -test.run 'Test(SquaredError|SSE8)' -test.bench '^BenchmarkSSE8RowsNative$' -test.benchtime=1x -test.count=1 -test.cpu=1
ROSETTA_ADVERTISE_AVX=1 GODEBUG=cpu.avx=off,cpu.avx2=off arch -x86_64 "$work/dsp.test" -test.run 'Test(SquaredError|SSE8)' -test.bench '^BenchmarkSSE8RowsNative$' -test.benchtime=1x -test.count=1 -test.cpu=1

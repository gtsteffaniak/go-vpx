from pathlib import Path
import subprocess,hashlib,json,re,difflib,shutil
root=Path('/Users/thesyncim/GolandProjects/govpx');snap=Path('/private/tmp/govpx-sse8-inline-entry-candidate');out=Path('/private/tmp/govpx-sse8-inline-entry-ready');out.mkdir(exist_ok=True)
base='c638b7c76eac857affa0780820e86c211cdd84d3'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tracked=subprocess.check_output(['git','ls-tree','-r',base],cwd=root,text=True).splitlines()
changed=[];deleted=[];allhashes=[];patch=[]
for line in tracked:
 meta,f=line.split('\t',1)
 if not f.endswith('.go') and f not in ['go.mod','go.sum']:continue
 p=snap/f
 if not p.is_file():deleted.append(f);continue
 data=p.read_bytes();allhashes.append(sha(p)+'  '+f)
 blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 if blob != meta.split()[2]:changed.append(f)
new=['internal/pixel/sse8_rows_arm64.go','internal/pixel/sse8_entry_fallback_amd64_test.go']
for f in new:allhashes.append(sha(snap/f)+'  '+f)
for f in changed+deleted+new:
 old=b'' if f in new else subprocess.check_output(['git','show',base+':'+f],cwd=root)
 data=b'' if f in deleted else (snap/f).read_bytes()
 if old:
  p=out/'parent'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(old)
 if data:
  p=out/'candidate'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 patch.extend(difflib.unified_diff(old.decode().splitlines(True),data.decode().splitlines(True),fromfile='/dev/null' if f in new else 'a/'+f,tofile='/dev/null' if f in deleted else 'b/'+f))
(out/'candidate.patch').write_text(''.join(patch))
(out/'all-go-module-source-sha256.txt').write_text('\n'.join(sorted(allhashes))+'\n')
arm=(snap/'internal/pixel/sse8_rows_arm64.go').read_text();common=subprocess.check_output(['git','show',base+':internal/pixel/sse_simd.go'],cwd=root,text=True)
assert arm[arm.index('// SSE8 packs'):]==common[common.index('// SSE8 packs'):]
amd=(snap/'internal/pixel/sse8_rows_wide_amd64.go').read_text();a=amd.index('\t\tif h >= 8 {');depth=0;b=None
for i in range(a,len(amd)):
 if amd[i]=='{':depth+=1
 elif amd[i]=='}':
  depth-=1
  if depth==0:b=i+2;break
stripped=amd[:a]+amd[b:]
pre=subprocess.check_output(['git','show','ab3abd6b:internal/pixel/sse_simd.go'],cwd=root,text=True)
assert stripped[stripped.index('// SSE8 packs'):]==pre[pre.index('// SSE8 packs'):]
assert (snap/'internal/pixel/sse8_ptr_amd64.go').read_bytes()==Path('/private/tmp/govpx-sse8-direct-fence-candidate/internal/pixel/sse8_ptr_amd64.go').read_bytes()
for n in ['pixel-checkptr-build.log','pixel-selected.log','pixel-cpuoff.log','dsp-checkptr-build.log','dsp-selected.log','dsp-cpuoff.log','linux-build.log','darwin-build.log','arm-tests.log','purego-tests.log','nosimd-tests.log','purego-dsp-public.log','nosimd-dsp-public.log','dsp-public-selected.log','dsp-public-cpuoff.log']:
 p=out/'validation'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2('/private/tmp/govpx-sse8-inline-entry-'+n,p)
for n in ['linux','darwin']:
 p=out/'codegen'/(n+'.txt');p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2('/private/tmp/govpx-sse8-inline-entry-'+n+'-llvm.txt',p)
shutil.copy2('/private/tmp/govpx-sse8-direct-fence-ready/sdk-intrinsics-snippet.txt',out/'sdk-intrinsics-snippet.txt')

def codegen(p):
 parts=re.split(r'(?m)^([0-9a-f]+) <([^>]+)>:\n',p.read_text());d={}
 for i in range(1,len(parts),3):
  sym,body=parts[i+1:i+3];ins=[]
  for l in body.splitlines():
   m=re.match(r'\s*([0-9a-f]+):\s+(?:[0-9a-f]{2}\s+)+\s*(\S+)(.*)',l)
   if m:ins.append((int(m[1],16),m[2],m[3].strip()))
  starts=[pc for pc,m,a in ins if '%ymm' in a]
  start=min(starts);by_pc={x[0]:x for x in ins};positions={x[0]:j for j,x in enumerate(ins)}
  todo=[start];seen=set()
  while todo:
   pc=todo.pop()
   if pc in seen or pc not in by_pc:continue
   seen.add(pc);_,m,a=by_pc[pc];j=positions[pc]
   if m.startswith('ret') or m.startswith('call'):continue
   target=re.match(r'0x([0-9a-f]+)',a)
   if m.startswith('j') and target:todo.append(int(target[1],16))
   if not m.startswith('jmp') and j+1<len(ins):todo.append(ins[j+1][0])
  live=[by_pc[pc] for pc in sorted(seen)]
  legacy=lambda xs:[[hex(pc),m,a] for pc,m,a in xs if ('%xmm' in a or '%ymm' in a) and not m.startswith('v')]
  d[sym]={'total_decoded_instructions_including_all_branches_and_alignment':len(ins),'calls':[[hex(pc),a] for pc,m,a in ins if m.startswith('call')],'all_legacy_vectors':legacy(ins),'wide_reachable_instruction_count':len(live),'wide_reachable_calls':[[hex(pc),a] for pc,m,a in live if m.startswith('call')],'wide_reachable_legacy_vectors':legacy(live),'wide_reachable_vzeroupper':sum(m=='vzeroupper' for pc,m,a in live),'vector_stack_traffic':[[hex(pc),m,a] for pc,m,a in ins if '%rsp' in a and ('%xmm' in a or '%ymm' in a)],'fence_return_regions':[ins[max(0,j-3):j+4] for j,(pc,m,a) in enumerate(ins) if m=='vzeroupper']}
  assert not d[sym]['wide_reachable_calls'] and not d[sym]['wide_reachable_legacy_vectors'] and d[sym]['wide_reachable_vzeroupper']==1
 return d
checks={}
for n in ['dsp-selected.log','dsp-cpuoff.log']:
 t=(out/'validation'/n).read_text();rows=[l for l in t.splitlines() if re.match(r'^BenchmarkSSE8RowsNative/.*\s+1\s+',l)]
 checks[n]={'case_count':len(rows),'pass':t.rstrip().endswith('PASS'),'all_one_shot_allocation_readings_zero':all(re.search(r'\b0 B/op\s+0 allocs/op$',l) for l in rows)}
 assert len(rows)==36 and checks[n]['pass'] and checks[n]['all_one_shot_allocation_readings_zero']
proof={'base':base,'scope':'Private structure/correctness proof; no native or emulated performance claim','modified':changed,'deleted':deleted,'new':new,'arm_SSE8_body_verbatim_from_c638':True,'AMD_narrow_and_fallback_body_exact_ab3_after_removing_wide_block':True,'pointer_identical_to_reviewed_direct_fence_variant':True,'unused_source_scope':'Removed unreferenced AMD zero-accumulator globals/helper. ARM compile-time-false compatibility stubs unchanged so relocated ARM body stays verbatim.','codegen':{n:codegen(out/'codegen'/(n+'.txt')) for n in ['linux','darwin']},'public_one_shot_checks':checks,'source_hashes':{f:sha(snap/f) for f in changed+new},'binary_hashes':{f:sha(Path('/private/tmp/'+f)) for f in ['govpx-sse8-inline-entry-linux.test','govpx-sse8-inline-entry-darwin.test','govpx-sse8-inline-entry-pixel-checkptr.test','govpx-sse8-inline-entry-dsp-checkptr.test']}}
(out/'audit.json').write_text(json.dumps(proof,indent=2)+'\n')
(out/'REPORT.md').write_text('''# Private AMD SSE8 entry repair

Exact base c638b7c76eac857affa0780820e86c211cdd84d3 (PR42 remains unchanged by this work). Go 1.27.2, GOEXPERIMENT=simd, GOAMD64=v1, PGO off. No performance claim: Rosetta runs and one-shot public fixtures establish correctness only. Native CI must measure whether this repairs the EPYC regressions.

## Source changes

The shared file retains ssePacket. The ARM SSE8 function moves verbatim into an ARM-only file; ARM compile-time-false stubs remain unchanged. The AMD entry now contains the 256-bit pair-row loop directly, after the original complete-window endpoints. It reduces into a scalar, executes inline ClearAVXUpperBits, and returns. There is no SSE8-to-wide-helper call. The narrow h<8 path and unusual-geometry fallback restore exact pre42 ab3 arithmetic and ordinary zero initialization, removing the new global-zero loads. The now-unreferenced AMD zero-global/helper file is deleted. The pointer source is identical to the previously reviewed direct-fence variant. The wide dispatch test now checks the public entry; a new test checks disabled-backend scalar/alias/canary behavior, including odd/boundary heights and unused extreme strides.

Bounds, read-only alias behavior, numeric range, input immutability, endpoint panic order and original CPU-off scalar behavior are preserved. Both bounded slice endpoints execute before wide arithmetic. An internal valid fast path has no remaining language-level panic site. The trusted pointer contract remains complete, valid 8x8 windows; removing defer does not promise cleanup on exceptional unwinding after invalid nonnil memory is supplied. Unsupported CPU/nil/unusual pointer geometry retains the original fallback before any YMM arithmetic.

## Correctness

Selected AVX2 and actual AVX/AVX2-off AMD pixel tests pass under checkptr=2. Coverage includes all byte pairs, exact/minimal windows, zero/overlapping/unequal strides, mutually aliased read-only inputs, bounds/fallback/invalid-pointer diagnostics and backend-disabled scalar checks. All 36 identical public DSP one-shot scalar/canary fixtures pass under checkptr=2 both selected and CPU-off, with zero allocation readings. Fresh native ARM focused tests, purego and nosimd pixel/DSP checks also pass. Complete raw outputs are retained. No benchmark latency from these runs is used as performance evidence.

## Optimized code

Linux and Darwin SSE8 each decode to 373 instructions across all branches, scalar fallback, cold panic sites and alignment padding; pointer remains 149. Wide-reachable CFGs contain zero helper/callee calls, zero legacy vector operations, zero vector stack traffic and exactly one VZEROUPPER after GPR result extraction. The only calls anywhere in the slice function are cold runtime.panicBounds. Four restored legacy XMM zero moves belong exclusively to h<8/unusual branches, are bypassed by the wide path, and match the pre42 initialization design. The slice entry has a 16-byte stack frame and no stack-growth/callee call; pointer's cold fallback and stack-growth calls remain. Instruction counts and CFG diagnostics are not native speed measurements.

## Transplant and reproduction

Apply candidate.patch to the exact base; candidate/ pins changed/new files and parent/ pins previous versions including the deleted AMD zero source. audit.json records source/binary hashes, source identity assertions, both target CFGs and public oracle counts. all-go-module-source-sha256.txt covers the private snapshot. reproduce.sh creates a private snapshot from the exact base, applies the patch and invokes the root project wrapper for correctness and codegen. No root files, branch/index or README was changed by this experiment.
''')
(out/'reproduce.sh').write_text('''#!/bin/sh
set -eu
root=${GOVPX_ROOT:-/Users/thesyncim/GolandProjects/govpx}
package=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
work=$(mktemp -d /private/tmp/govpx-sse8-entry-repro.XXXXXX)
git -C "$root" archive c638b7c76eac857affa0780820e86c211cdd84d3 | tar -x -C "$work"
(cd "$work" && patch -p1 < "$package/candidate.patch")
export CODEX_AGENT_ID=ci-sse8-entry-repro CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GOMAXPROCS=2 GOFLAGS=-p=2
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go GOOS=darwin GOARCH=amd64 GOAMD64=v1
cd "$root"
./scripts/go.sh -C "$work" test -pgo=off -gcflags=all=-d=checkptr=2 -c -o "$work/pixel.test" ./internal/pixel
./scripts/go.sh -C "$work" test -pgo=off -gcflags=all=-d=checkptr=2 -c -o "$work/dsp.test" ./internal/vp8/dsp
ROSETTA_ADVERTISE_AVX=1 GOVPX_REQUIRE_SIMD=1 arch -x86_64 "$work/pixel.test" -test.run 'Test(SSE8|SquaredError)' -test.v
ROSETTA_ADVERTISE_AVX=1 GODEBUG=cpu.avx=off,cpu.avx2=off arch -x86_64 "$work/pixel.test" -test.run 'Test(SSE8|SquaredError)' -test.v
ROSETTA_ADVERTISE_AVX=1 GOVPX_REQUIRE_SIMD=1 arch -x86_64 "$work/dsp.test" -test.run 'Test(SquaredError|SSE8)' -test.bench '^BenchmarkSSE8RowsNative$' -test.benchtime=1x -test.count=1 -test.cpu=1
ROSETTA_ADVERTISE_AVX=1 GODEBUG=cpu.avx=off,cpu.avx2=off arch -x86_64 "$work/dsp.test" -test.run 'Test(SquaredError|SSE8)' -test.bench '^BenchmarkSSE8RowsNative$' -test.benchtime=1x -test.count=1 -test.cpu=1
''')
shutil.copy2('/private/tmp/govpx-package-sse8-inline-entry.py',out/'package-evidence.py')
manifest=[sha(p)+'  '+str(p.relative_to(out)) for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'SHA256SUMS']
(out/'SHA256SUMS').write_text('\n'.join(manifest)+'\n')
print(json.dumps({'out':str(out),'members':len(manifest),'manifest_sha256':sha(out/'SHA256SUMS'),'modified':changed,'deleted':deleted,'new':new},indent=2))

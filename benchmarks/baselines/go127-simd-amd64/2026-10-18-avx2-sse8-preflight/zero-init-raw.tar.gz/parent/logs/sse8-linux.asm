
/private/tmp/govpx-sse8-zero-accumulators-research/parent-logs/pixel-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000566ce0 <github.com/thesyncim/govpx/internal/pixel.SSE8>:
  566ce0: 55                           	push	rbp
  566ce1: 48 89 e5                     	mov	rbp, rsp
  566ce4: 48 83 ec 10                  	sub	rsp, 0x10
  566ce8: 48 89 44 24 20               	mov	qword ptr [rsp + 0x20], rax
  566ced: 48 89 74 24 40               	mov	qword ptr [rsp + 0x40], rsi
  566cf2: 80 3d 54 cf 23 00 00         	cmp	byte ptr [rip + 0x23cf54], 0x0 # 0x7a3c4d <github.com/thesyncim/govpx/internal/pixel.Enabled>
  566cf9: 74 6f                        	je	0x566d6a <github.com/thesyncim/govpx/internal/pixel.SSE8+0x8a>
  566cfb: 49 8d 53 ff                  	lea	rdx, [r11 - 0x1]
  566cff: 90                           	nop
  566d00: 48 83 fa 3f                  	cmp	rdx, 0x3f
  566d04: 77 48                        	ja	0x566d4e <github.com/thesyncim/govpx/internal/pixel.SSE8+0x6e>
  566d06: 49 89 fc                     	mov	r12, rdi
  566d09: 4c 09 d7                     	or	rdi, r10
  566d0c: 48 c1 ef 1e                  	shr	rdi, 0x1e
  566d10: 48 85 ff                     	test	rdi, rdi
  566d13: 75 3c                        	jne	0x566d51 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x71>
  566d15: 4c 89 e1                     	mov	rcx, r12
  566d18: 4c 0f af e2                  	imul	r12, rdx
  566d1c: 49 8d 7c 24 07               	lea	rdi, [r12 + 0x7]
  566d21: 48 39 fb                     	cmp	rbx, rdi
  566d24: 0f 86 db 03 00 00            	jbe	0x567105 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x425>
  566d2a: 49 0f af d2                  	imul	rdx, r10
  566d2e: 48 83 c2 07                  	add	rdx, 0x7
  566d32: 49 39 d0                     	cmp	r8, rdx
  566d35: 0f 86 c1 03 00 00            	jbe	0x5670fc <github.com/thesyncim/govpx/internal/pixel.SSE8+0x41c>
  566d3b: 31 d2                        	xor	edx, edx
  566d3d: 31 db                        	xor	ebx, ebx
  566d3f: 41 0f 10 c7                  	movups	xmm0, xmm15
  566d43: 31 ff                        	xor	edi, edi
  566d45: 41 0f 10 cf                  	movups	xmm1, xmm15
  566d49: e9 44 03 00 00               	jmp	0x567092 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x3b2>
  566d4e: 49 89 fc                     	mov	r12, rdi
  566d51: 4c 89 5c 24 60               	mov	qword ptr [rsp + 0x60], r11
  566d56: 48 89 4c 24 30               	mov	qword ptr [rsp + 0x30], rcx
  566d5b: 31 d2                        	xor	edx, edx
  566d5d: 41 0f 10 c7                  	movups	xmm0, xmm15
  566d61: 41 0f 10 cf                  	movups	xmm1, xmm15
  566d65: e9 ce 00 00 00               	jmp	0x566e38 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x158>
  566d6a: 4c 89 54 24 58               	mov	qword ptr [rsp + 0x58], r10
  566d6f: 31 c9                        	xor	ecx, ecx
  566d71: 31 d2                        	xor	edx, edx
  566d73: eb 05                        	jmp	0x566d7a <github.com/thesyncim/govpx/internal/pixel.SSE8+0x9a>
  566d75: 49 8d 54 24 01               	lea	rdx, [r12 + 0x1]
  566d7a: 49 39 d3                     	cmp	r11, rdx
  566d7d: 7e 4b                        	jle	0x566dca <github.com/thesyncim/govpx/internal/pixel.SSE8+0xea>
  566d7f: 49 89 d1                     	mov	r9, rdx
  566d82: 48 0f af d7                  	imul	rdx, rdi
  566d86: 4d 89 cc                     	mov	r12, r9
  566d89: 4d 0f af ca                  	imul	r9, r10
  566d8d: 45 31 ed                     	xor	r13d, r13d
  566d90: eb 17                        	jmp	0x566da9 <github.com/thesyncim/govpx/internal/pixel.SSE8+0xc9>
  566d92: 46 0f b6 14 16               	movzx	r10d, byte ptr [rsi + r10]
  566d97: 4d 29 d7                     	sub	r15, r10
  566d9a: 4d 0f af ff                  	imul	r15, r15
  566d9e: 44 01 f9                     	add	ecx, r15d
  566da1: 49 ff c5                     	inc	r13
  566da4: 4c 8b 54 24 58               	mov	r10, qword ptr [rsp + 0x58]
  566da9: 49 83 fd 08                  	cmp	r13, 0x8
  566dad: 7d c6                        	jge	0x566d75 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x95>
  566daf: 4d 8d 7c 15 00               	lea	r15, [r13 + rdx]
  566db4: 4c 39 fb                     	cmp	rbx, r15
  566db7: 76 1e                        	jbe	0x566dd7 <github.com/thesyncim/govpx/internal/pixel.SSE8+0xf7>
  566db9: 4f 8d 54 0d 00               	lea	r10, [r13 + r9]
  566dbe: 46 0f b6 3c 38               	movzx	r15d, byte ptr [rax + r15]
  566dc3: 4d 39 d0                     	cmp	r8, r10
  566dc6: 77 ca                        	ja	0x566d92 <github.com/thesyncim/govpx/internal/pixel.SSE8+0xb2>
  566dc8: eb 08                        	jmp	0x566dd2 <github.com/thesyncim/govpx/internal/pixel.SSE8+0xf2>
  566dca: 89 c8                        	mov	eax, ecx
  566dcc: 48 83 c4 10                  	add	rsp, 0x10
  566dd0: 5d                           	pop	rbp
  566dd1: c3                           	ret
  566dd2: e8 29 67 f2 ff               	call	0x48d500 <runtime.panicBounds>
  566dd7: e8 24 67 f2 ff               	call	0x48d500 <runtime.panicBounds>
  566ddc: c4 e1 f9 6e 1b               	vmovq	xmm3, qword ptr [rbx]
  566de1: 4e 8b 2c 2e                  	mov	r13, qword ptr [rsi + r13]
  566de5: c4 e2 79 59 db               	vpbroadcastq	xmm3, xmm3
  566dea: c4 c3 e1 22 dd 01            	vpinsrq	xmm3, xmm3, r13, 0x1
  566df0: c4 e2 79 30 e2               	vpmovzxbw	xmm4, xmm2      # xmm4 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero
  566df5: c4 e2 79 30 eb               	vpmovzxbw	xmm5, xmm3      # xmm5 = xmm3[0],zero,xmm3[1],zero,xmm3[2],zero,xmm3[3],zero,xmm3[4],zero,xmm3[5],zero,xmm3[6],zero,xmm3[7],zero
  566dfa: c5 d9 f9 e5                  	vpsubw	xmm4, xmm4, xmm5
  566dfe: c5 d9 f5 e4                  	vpmaddwd	xmm4, xmm4, xmm4
  566e02: c5 f9 70 d2 4e               	vpshufd	xmm2, xmm2, 0x4e        # xmm2 = xmm2[2,3,0,1]
  566e07: c4 e2 79 30 d2               	vpmovzxbw	xmm2, xmm2      # xmm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero
  566e0c: c5 f9 70 db 4e               	vpshufd	xmm3, xmm3, 0x4e        # xmm3 = xmm3[2,3,0,1]
  566e11: c4 e2 79 30 db               	vpmovzxbw	xmm3, xmm3      # xmm3 = xmm3[0],zero,xmm3[1],zero,xmm3[2],zero,xmm3[3],zero,xmm3[4],zero,xmm3[5],zero,xmm3[6],zero,xmm3[7],zero
  566e16: c5 e9 f9 d3                  	vpsubw	xmm2, xmm2, xmm3
  566e1a: c5 e9 f5 d2                  	vpmaddwd	xmm2, xmm2, xmm2
  566e1e: c5 d9 fe c0                  	vpaddd	xmm0, xmm4, xmm0
  566e22: c5 f1 fe ca                  	vpaddd	xmm1, xmm1, xmm2
  566e26: 90                           	nop
  566e27: 90                           	nop
  566e28: 48 8b 4c 24 30               	mov	rcx, qword ptr [rsp + 0x30]
  566e2d: 4c 89 db                     	mov	rbx, r11
  566e30: 4c 8b 5c 24 60               	mov	r11, qword ptr [rsp + 0x60]
  566e35: 48 89 fa                     	mov	rdx, rdi
  566e38: 48 8d 7a 02                  	lea	rdi, [rdx + 0x2]
  566e3c: 0f 1f 40 00                  	nop	dword ptr [rax]
  566e40: 49 39 fb                     	cmp	r11, rdi
  566e43: 0f 8c d7 00 00 00            	jl	0x566f20 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x240>
  566e49: 49 89 d5                     	mov	r13, rdx
  566e4c: 49 0f af d4                  	imul	rdx, r12
  566e50: 48 39 d3                     	cmp	rbx, rdx
  566e53: 0f 82 cc 01 00 00            	jb	0x567025 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x345>
  566e59: 48 89 14 24                  	mov	qword ptr [rsp], rdx
  566e5d: 49 89 df                     	mov	r15, rbx
  566e60: 48 29 d3                     	sub	rbx, rdx
  566e63: 48 29 ca                     	sub	rdx, rcx
  566e66: 48 c1 fa 3f                  	sar	rdx, 0x3f
  566e6a: 4c 8b 1c 24                  	mov	r11, qword ptr [rsp]
  566e6e: 4c 21 da                     	and	rdx, r11
  566e71: 48 01 c2                     	add	rdx, rax
  566e74: 48 83 fb 07                  	cmp	rbx, 0x7
  566e78: 0f 86 a0 01 00 00            	jbe	0x56701e <github.com/thesyncim/govpx/internal/pixel.SSE8+0x33e>
  566e7e: 4b 8d 1c 1c                  	lea	rbx, [r12 + r11]
  566e82: 49 39 df                     	cmp	r15, rbx
  566e85: 0f 82 8e 01 00 00            	jb	0x567019 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x339>
  566e8b: 48 89 5c 24 08               	mov	qword ptr [rsp + 0x8], rbx
  566e90: 4d 89 fb                     	mov	r11, r15
  566e93: 49 29 df                     	sub	r15, rbx
  566e96: 48 29 cb                     	sub	rbx, rcx
  566e99: 48 c1 fb 3f                  	sar	rbx, 0x3f
  566e9d: 48 8b 4c 24 08               	mov	rcx, qword ptr [rsp + 0x8]
  566ea2: 48 21 d9                     	and	rcx, rbx
  566ea5: 49 83 ff 07                  	cmp	r15, 0x7
  566ea9: 0f 86 65 01 00 00            	jbe	0x567014 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x334>
  566eaf: 4d 0f af ea                  	imul	r13, r10
  566eb3: c4 e1 f9 6e 12               	vmovq	xmm2, qword ptr [rdx]
  566eb8: 48 8b 0c 08                  	mov	rcx, qword ptr [rax + rcx]
  566ebc: c4 e2 79 59 d2               	vpbroadcastq	xmm2, xmm2
  566ec1: c4 e3 e9 22 d1 01            	vpinsrq	xmm2, xmm2, rcx, 0x1
  566ec7: 4d 39 e8                     	cmp	r8, r13
  566eca: 0f 82 3f 01 00 00            	jb	0x56700f <github.com/thesyncim/govpx/internal/pixel.SSE8+0x32f>
  566ed0: 4c 89 c1                     	mov	rcx, r8
  566ed3: 4d 29 e8                     	sub	r8, r13
  566ed6: 4c 89 ea                     	mov	rdx, r13
  566ed9: 4d 29 cd                     	sub	r13, r9
  566edc: 49 c1 fd 3f                  	sar	r13, 0x3f
  566ee0: 49 21 d5                     	and	r13, rdx
  566ee3: 4a 8d 1c 2e                  	lea	rbx, [rsi + r13]
  566ee7: 49 83 f8 07                  	cmp	r8, 0x7
  566eeb: 0f 86 19 01 00 00            	jbe	0x56700a <github.com/thesyncim/govpx/internal/pixel.SSE8+0x32a>
  566ef1: 4c 01 d2                     	add	rdx, r10
  566ef4: 48 39 d1                     	cmp	rcx, rdx
  566ef7: 0f 82 08 01 00 00            	jb	0x567005 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x325>
  566efd: 49 89 c8                     	mov	r8, rcx
  566f00: 48 29 d1                     	sub	rcx, rdx
  566f03: 49 89 d5                     	mov	r13, rdx
  566f06: 4c 29 ca                     	sub	rdx, r9
  566f09: 48 c1 fa 3f                  	sar	rdx, 0x3f
  566f0d: 49 21 d5                     	and	r13, rdx
  566f10: 48 83 f9 07                  	cmp	rcx, 0x7
  566f14: 0f 87 c2 fe ff ff            	ja	0x566ddc <github.com/thesyncim/govpx/internal/pixel.SSE8+0xfc>
  566f1a: e9 df 00 00 00               	jmp	0x566ffe <github.com/thesyncim/govpx/internal/pixel.SSE8+0x31e>
  566f1f: 90                           	nop
  566f20: 49 39 d3                     	cmp	r11, rdx
  566f23: 0f 8e 9f 00 00 00            	jle	0x566fc8 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x2e8>
  566f29: 4c 0f af e2                  	imul	r12, rdx
  566f2d: 4c 39 e3                     	cmp	rbx, r12
  566f30: 0f 82 c3 00 00 00            	jb	0x566ff9 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x319>
  566f36: 4c 29 e3                     	sub	rbx, r12
  566f39: 4c 89 e7                     	mov	rdi, r12
  566f3c: 49 29 cc                     	sub	r12, rcx
  566f3f: 49 c1 fc 3f                  	sar	r12, 0x3f
  566f43: 4c 21 e7                     	and	rdi, r12
  566f46: 48 8d 0c 38                  	lea	rcx, [rax + rdi]
  566f4a: 90                           	nop
  566f4b: 48 83 fb 07                  	cmp	rbx, 0x7
  566f4f: 0f 86 9f 00 00 00            	jbe	0x566ff4 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x314>
  566f55: 49 0f af d2                  	imul	rdx, r10
  566f59: 0f 1f 80 00 00 00 00         	nop	dword ptr [rax]
  566f60: 49 39 d0                     	cmp	r8, rdx
  566f63: 0f 82 86 00 00 00            	jb	0x566fef <github.com/thesyncim/govpx/internal/pixel.SSE8+0x30f>
  566f69: 49 29 d0                     	sub	r8, rdx
  566f6c: 48 89 d3                     	mov	rbx, rdx
  566f6f: 4c 29 ca                     	sub	rdx, r9
  566f72: 48 c1 fa 3f                  	sar	rdx, 0x3f
  566f76: 48 21 d3                     	and	rbx, rdx
  566f79: 48 8d 14 1e                  	lea	rdx, [rsi + rbx]
  566f7d: 90                           	nop
  566f7e: 66 90                        	nop
  566f80: 49 83 f8 07                  	cmp	r8, 0x7
  566f84: 76 64                        	jbe	0x566fea <github.com/thesyncim/govpx/internal/pixel.SSE8+0x30a>
  566f86: c4 e1 f9 6e 11               	vmovq	xmm2, qword ptr [rcx]
  566f8b: c4 e1 f9 6e 1a               	vmovq	xmm3, qword ptr [rdx]
  566f90: c4 e2 79 30 e2               	vpmovzxbw	xmm4, xmm2      # xmm4 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero
  566f95: c4 e2 79 30 eb               	vpmovzxbw	xmm5, xmm3      # xmm5 = xmm3[0],zero,xmm3[1],zero,xmm3[2],zero,xmm3[3],zero,xmm3[4],zero,xmm3[5],zero,xmm3[6],zero,xmm3[7],zero
  566f9a: c5 d9 f9 e5                  	vpsubw	xmm4, xmm4, xmm5
  566f9e: c5 d9 f5 e4                  	vpmaddwd	xmm4, xmm4, xmm4
  566fa2: c5 f9 70 d2 4e               	vpshufd	xmm2, xmm2, 0x4e        # xmm2 = xmm2[2,3,0,1]
  566fa7: c4 e2 79 30 d2               	vpmovzxbw	xmm2, xmm2      # xmm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero
  566fac: c5 f9 70 db 4e               	vpshufd	xmm3, xmm3, 0x4e        # xmm3 = xmm3[2,3,0,1]
  566fb1: c4 e2 79 30 db               	vpmovzxbw	xmm3, xmm3      # xmm3 = xmm3[0],zero,xmm3[1],zero,xmm3[2],zero,xmm3[3],zero,xmm3[4],zero,xmm3[5],zero,xmm3[6],zero,xmm3[7],zero
  566fb6: c5 e9 f9 d3                  	vpsubw	xmm2, xmm2, xmm3
  566fba: c5 e9 f5 d2                  	vpmaddwd	xmm2, xmm2, xmm2
  566fbe: c5 d9 fe c0                  	vpaddd	xmm0, xmm4, xmm0
  566fc2: c5 f1 fe ca                  	vpaddd	xmm1, xmm1, xmm2
  566fc6: 90                           	nop
  566fc7: 90                           	nop
  566fc8: c5 f9 fe c1                  	vpaddd	xmm0, xmm0, xmm1
  566fcc: c5 f9 70 c8 4e               	vpshufd	xmm1, xmm0, 0x4e        # xmm1 = xmm0[2,3,0,1]
  566fd1: c5 f9 fe c1                  	vpaddd	xmm0, xmm0, xmm1
  566fd5: c5 f9 70 c8 b1               	vpshufd	xmm1, xmm0, 0xb1        # xmm1 = xmm0[1,0,3,2]
  566fda: c5 f9 fe c1                  	vpaddd	xmm0, xmm0, xmm1
  566fde: c4 e3 79 16 c0 00            	vpextrd	eax, xmm0, 0x0
  566fe4: 48 83 c4 10                  	add	rsp, 0x10
  566fe8: 5d                           	pop	rbp
  566fe9: c3                           	ret
  566fea: e8 11 65 f2 ff               	call	0x48d500 <runtime.panicBounds>
  566fef: e8 0c 65 f2 ff               	call	0x48d500 <runtime.panicBounds>
  566ff4: e8 07 65 f2 ff               	call	0x48d500 <runtime.panicBounds>
  566ff9: e8 02 65 f2 ff               	call	0x48d500 <runtime.panicBounds>
  566ffe: 66 90                        	nop
  567000: e8 fb 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  567005: e8 f6 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  56700a: e8 f1 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  56700f: e8 ec 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  567014: e8 e7 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  567019: e8 e2 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  56701e: 66 90                        	nop
  567020: e8 db 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  567025: e8 d6 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  56702a: 4c 8d 0c 03                  	lea	r9, [rbx + rax]
  56702e: c4 c1 f9 6e 11               	vmovq	xmm2, qword ptr [r9]
  567033: 4c 8d 0c 19                  	lea	r9, [rcx + rbx]
  567037: 4e 8b 0c 08                  	mov	r9, qword ptr [rax + r9]
  56703b: c4 c3 e9 22 d1 01            	vpinsrq	xmm2, xmm2, r9, 0x1
  567041: 4c 8d 0c 32                  	lea	r9, [rdx + rsi]
  567045: c4 c1 f9 6e 19               	vmovq	xmm3, qword ptr [r9]
  56704a: 4d 8d 0c 12                  	lea	r9, [r10 + rdx]
  56704e: 4e 8b 0c 0e                  	mov	r9, qword ptr [rsi + r9]
  567052: c4 c3 e1 22 d9 01            	vpinsrq	xmm3, xmm3, r9, 0x1
  567058: c5 e9 de e3                  	vpmaxub	xmm4, xmm2, xmm3
  56705c: c5 e9 da d3                  	vpminub	xmm2, xmm2, xmm3
  567060: c5 d9 f8 d2                  	vpsubb	xmm2, xmm4, xmm2
  567064: c4 e2 79 30 da               	vpmovzxbw	xmm3, xmm2      # xmm3 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero
  567069: c5 e1 f5 db                  	vpmaddwd	xmm3, xmm3, xmm3
  56706d: c5 f9 70 d2 4e               	vpshufd	xmm2, xmm2, 0x4e        # xmm2 = xmm2[2,3,0,1]
  567072: c4 e2 79 30 d2               	vpmovzxbw	xmm2, xmm2      # xmm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero
  567077: c5 e9 f5 d2                  	vpmaddwd	xmm2, xmm2, xmm2
  56707b: 90                           	nop
  56707c: 90                           	nop
  56707d: 90                           	nop
  56707e: c5 e1 fe c0                  	vpaddd	xmm0, xmm3, xmm0
  567082: c5 e9 fe c9                  	vpaddd	xmm1, xmm2, xmm1
  567086: 48 8d 1c 4b                  	lea	rbx, [rbx + 2*rcx]
  56708a: 4a 8d 14 52                  	lea	rdx, [rdx + 2*r10]
  56708e: 90                           	nop
  56708f: 4c 89 c7                     	mov	rdi, r8
  567092: 4c 8d 47 02                  	lea	r8, [rdi + 0x2]
  567096: 4d 39 c3                     	cmp	r11, r8
  567099: 7d 8f                        	jge	0x56702a <github.com/thesyncim/govpx/internal/pixel.SSE8+0x34a>
  56709b: 0f 1f 44 00 00               	nop	dword ptr [rax + rax]
  5670a0: 49 39 fb                     	cmp	r11, rdi
  5670a3: 7e 35                        	jle	0x5670da <github.com/thesyncim/govpx/internal/pixel.SSE8+0x3fa>
  5670a5: 48 8d 0c 03                  	lea	rcx, [rbx + rax]
  5670a9: c4 e1 f9 6e 11               	vmovq	xmm2, qword ptr [rcx]
  5670ae: 48 8d 0c 32                  	lea	rcx, [rdx + rsi]
  5670b2: c4 e1 f9 6e 19               	vmovq	xmm3, qword ptr [rcx]
  5670b7: c4 e2 79 59 d2               	vpbroadcastq	xmm2, xmm2
  5670bc: c4 e2 79 59 db               	vpbroadcastq	xmm3, xmm3
  5670c1: c5 e1 de e2                  	vpmaxub	xmm4, xmm3, xmm2
  5670c5: c5 e1 da d2                  	vpminub	xmm2, xmm3, xmm2
  5670c9: c5 d9 f8 d2                  	vpsubb	xmm2, xmm4, xmm2
  5670cd: c4 e2 79 30 d2               	vpmovzxbw	xmm2, xmm2      # xmm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero
  5670d2: c5 e9 f5 d2                  	vpmaddwd	xmm2, xmm2, xmm2
  5670d6: c5 e9 fe c0                  	vpaddd	xmm0, xmm2, xmm0
  5670da: c5 f9 fe c1                  	vpaddd	xmm0, xmm0, xmm1
  5670de: c5 f9 70 c8 4e               	vpshufd	xmm1, xmm0, 0x4e        # xmm1 = xmm0[2,3,0,1]
  5670e3: c5 f9 fe c1                  	vpaddd	xmm0, xmm0, xmm1
  5670e7: c5 f9 70 c8 b1               	vpshufd	xmm1, xmm0, 0xb1        # xmm1 = xmm0[1,0,3,2]
  5670ec: c5 f9 fe c1                  	vpaddd	xmm0, xmm0, xmm1
  5670f0: c4 e3 79 16 c0 00            	vpextrd	eax, xmm0, 0x0
  5670f6: 48 83 c4 10                  	add	rsp, 0x10
  5670fa: 5d                           	pop	rbp
  5670fb: c3                           	ret
  5670fc: 0f 1f 40 00                  	nop	dword ptr [rax]
  567100: e8 fb 63 f2 ff               	call	0x48d500 <runtime.panicBounds>
  567105: e8 f6 63 f2 ff               	call	0x48d500 <runtime.panicBounds>
  56710a: 90                           	nop
  56710b: cc                           	int3
  56710c: cc                           	int3
  56710d: cc                           	int3
  56710e: cc                           	int3
  56710f: cc                           	int3
  567110: cc                           	int3
  567111: cc                           	int3
  567112: cc                           	int3
  567113: cc                           	int3
  567114: cc                           	int3
  567115: cc                           	int3
  567116: cc                           	int3
  567117: cc                           	int3
  567118: cc                           	int3
  567119: cc                           	int3
  56711a: cc                           	int3
  56711b: cc                           	int3
  56711c: cc                           	int3
  56711d: cc                           	int3
  56711e: cc                           	int3
  56711f: cc                           	int3

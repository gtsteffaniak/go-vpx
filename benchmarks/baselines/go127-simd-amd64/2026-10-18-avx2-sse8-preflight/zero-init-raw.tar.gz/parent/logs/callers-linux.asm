
/private/tmp/govpx-sse8-zero-accumulators-research/parent-logs/dsp-linux.test:	file format elf64-x86-64

Disassembly of section .text:

00000000006412c0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8>:
  6412c0: 4c 8d a4 24 28 f8 ff ff      	lea	r12, [rsp - 0x7d8]
  6412c8: 4d 3b 66 10                  	cmp	r12, qword ptr [r14 + 0x10]
  6412cc: 0f 86 e0 00 00 00            	jbe	0x6413b2 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8+0xf2>
  6412d2: 55                           	push	rbp
  6412d3: 48 89 e5                     	mov	rbp, rsp
  6412d6: 48 81 ec 50 08 00 00         	sub	rsp, 0x850
  6412dd: 48 89 84 24 60 08 00 00      	mov	qword ptr [rsp + 0x860], rax
  6412e5: 48 8d 94 24 48 04 00 00      	lea	rdx, [rsp + 0x448]
  6412ed: 41 bc 10 00 00 00            	mov	r12d, 0x10
  6412f3: 44 0f 11 3a                  	movups	xmmword ptr [rdx], xmm15
  6412f7: 44 0f 11 7a 10               	movups	xmmword ptr [rdx + 0x10], xmm15
  6412fc: 44 0f 11 7a 20               	movups	xmmword ptr [rdx + 0x20], xmm15
  641301: 44 0f 11 7a 30               	movups	xmmword ptr [rdx + 0x30], xmm15
  641306: 48 83 c2 40                  	add	rdx, 0x40
  64130a: 41 ff cc                     	dec	r12d
  64130d: 75 e4                        	jne	0x6412f3 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8+0x33>
  64130f: 48 8d 74 24 48               	lea	rsi, [rsp + 0x48]
  641314: ba 10 00 00 00               	mov	edx, 0x10
  641319: 44 0f 11 3e                  	movups	xmmword ptr [rsi], xmm15
  64131d: 44 0f 11 7e 10               	movups	xmmword ptr [rsi + 0x10], xmm15
  641322: 44 0f 11 7e 20               	movups	xmmword ptr [rsi + 0x20], xmm15
  641327: 44 0f 11 7e 30               	movups	xmmword ptr [rsi + 0x30], xmm15
  64132c: 48 83 c6 40                  	add	rsi, 0x40
  641330: ff ca                        	dec	edx
  641332: 75 e5                        	jne	0x641319 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8+0x59>
  641334: 90                           	nop
  641335: c6 80 52 02 00 00 01         	mov	byte ptr [rax + 0x252], 0x1
  64133c: 48 c7 80 48 02 00 00 40 00 00 00     	mov	qword ptr [rax + 0x248], 0x40
  641347: 31 c9                        	xor	ecx, ecx
  641349: eb 55                        	jmp	0x6413a0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8+0xe0>
  64134b: 48 89 8c 24 48 08 00 00      	mov	qword ptr [rsp + 0x848], rcx
  641353: 90                           	nop
  641354: 48 8d 84 24 48 04 00 00      	lea	rax, [rsp + 0x448]
  64135c: bb 00 04 00 00               	mov	ebx, 0x400
  641361: 89 d9                        	mov	ecx, ebx
  641363: bf 20 00 00 00               	mov	edi, 0x20
  641368: 48 8d 74 24 48               	lea	rsi, [rsp + 0x48]
  64136d: 49 89 c8                     	mov	r8, rcx
  641370: 49 89 c9                     	mov	r9, rcx
  641373: 41 89 fa                     	mov	r10d, edi
  641376: 41 bb 08 00 00 00            	mov	r11d, 0x8
  64137c: 0f 1f 40 00                  	nop	dword ptr [rax]
  641380: e8 5b 3b fc ff               	call	0x604ee0 <github.com/thesyncim/govpx/internal/pixel.SSE8>
  641385: 48 8b 8c 24 48 08 00 00      	mov	rcx, qword ptr [rsp + 0x848]
  64138d: 48 ff c1                     	inc	rcx
  641390: 48 8b 84 24 60 08 00 00      	mov	rax, qword ptr [rsp + 0x860]
  641398: 0f 1f 84 00 00 00 00 00      	nop	dword ptr [rax + rax]
  6413a0: 48 39 88 10 02 00 00         	cmp	qword ptr [rax + 0x210], rcx
  6413a7: 7f a2                        	jg	0x64134b <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8+0x8b>
  6413a9: 48 81 c4 50 08 00 00         	add	rsp, 0x850
  6413b0: 5d                           	pop	rbp
  6413b1: c3                           	ret
  6413b2: 48 89 44 24 08               	mov	qword ptr [rsp + 0x8], rax
  6413b7: e8 04 d5 e4 ff               	call	0x48e8c0 <runtime.morestack_noctxt.abi0>
  6413bc: 48 8b 44 24 08               	mov	rax, qword ptr [rsp + 0x8]
  6413c1: e9 fa fe ff ff               	jmp	0x6412c0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8>
  6413c6: cc                           	int3
  6413c7: cc                           	int3
  6413c8: cc                           	int3
  6413c9: cc                           	int3
  6413ca: cc                           	int3
  6413cb: cc                           	int3
  6413cc: cc                           	int3
  6413cd: cc                           	int3
  6413ce: cc                           	int3
  6413cf: cc                           	int3
  6413d0: cc                           	int3
  6413d1: cc                           	int3
  6413d2: cc                           	int3
  6413d3: cc                           	int3
  6413d4: cc                           	int3
  6413d5: cc                           	int3
  6413d6: cc                           	int3
  6413d7: cc                           	int3
  6413d8: cc                           	int3
  6413d9: cc                           	int3
  6413da: cc                           	int3
  6413db: cc                           	int3
  6413dc: cc                           	int3
  6413dd: cc                           	int3
  6413de: cc                           	int3
  6413df: cc                           	int3

00000000006413e0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast>:
  6413e0: 4c 8d a4 24 50 f8 ff ff      	lea	r12, [rsp - 0x7b0]
  6413e8: 4d 3b 66 10                  	cmp	r12, qword ptr [r14 + 0x10]
  6413ec: 0f 86 c0 00 00 00            	jbe	0x6414b2 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast+0xd2>
  6413f2: 55                           	push	rbp
  6413f3: 48 89 e5                     	mov	rbp, rsp
  6413f6: 48 81 ec 28 08 00 00         	sub	rsp, 0x828
  6413fd: 48 89 84 24 38 08 00 00      	mov	qword ptr [rsp + 0x838], rax
  641405: 48 8d 94 24 20 04 00 00      	lea	rdx, [rsp + 0x420]
  64140d: be 10 00 00 00               	mov	esi, 0x10
  641412: 44 0f 11 3a                  	movups	xmmword ptr [rdx], xmm15
  641416: 44 0f 11 7a 10               	movups	xmmword ptr [rdx + 0x10], xmm15
  64141b: 44 0f 11 7a 20               	movups	xmmword ptr [rdx + 0x20], xmm15
  641420: 44 0f 11 7a 30               	movups	xmmword ptr [rdx + 0x30], xmm15
  641425: 48 83 c2 40                  	add	rdx, 0x40
  641429: ff ce                        	dec	esi
  64142b: 75 e5                        	jne	0x641412 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast+0x32>
  64142d: 48 8d 4c 24 20               	lea	rcx, [rsp + 0x20]
  641432: ba 10 00 00 00               	mov	edx, 0x10
  641437: 44 0f 11 39                  	movups	xmmword ptr [rcx], xmm15
  64143b: 44 0f 11 79 10               	movups	xmmword ptr [rcx + 0x10], xmm15
  641440: 44 0f 11 79 20               	movups	xmmword ptr [rcx + 0x20], xmm15
  641445: 44 0f 11 79 30               	movups	xmmword ptr [rcx + 0x30], xmm15
  64144a: 48 83 c1 40                  	add	rcx, 0x40
  64144e: ff ca                        	dec	edx
  641450: 75 e5                        	jne	0x641437 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast+0x57>
  641452: 90                           	nop
  641453: c6 80 52 02 00 00 01         	mov	byte ptr [rax + 0x252], 0x1
  64145a: 48 c7 80 48 02 00 00 40 00 00 00     	mov	qword ptr [rax + 0x248], 0x40
  641465: 31 c9                        	xor	ecx, ecx
  641467: eb 37                        	jmp	0x6414a0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast+0xc0>
  641469: 48 89 8c 24 20 08 00 00      	mov	qword ptr [rsp + 0x820], rcx
  641471: 48 8d 84 24 20 04 00 00      	lea	rax, [rsp + 0x420]
  641479: bb 20 00 00 00               	mov	ebx, 0x20
  64147e: 48 8d 4c 24 20               	lea	rcx, [rsp + 0x20]
  641483: 89 df                        	mov	edi, ebx
  641485: e8 b6 1a fd ff               	call	0x612f40 <github.com/thesyncim/govpx/internal/vp8/dsp.SSE8x8PtrFast>
  64148a: 48 8b 8c 24 20 08 00 00      	mov	rcx, qword ptr [rsp + 0x820]
  641492: 48 ff c1                     	inc	rcx
  641495: 48 8b 84 24 38 08 00 00      	mov	rax, qword ptr [rsp + 0x838]
  64149d: 0f 1f 00                     	nop	dword ptr [rax]
  6414a0: 48 39 88 10 02 00 00         	cmp	qword ptr [rax + 0x210], rcx
  6414a7: 7f c0                        	jg	0x641469 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast+0x89>
  6414a9: 48 81 c4 28 08 00 00         	add	rsp, 0x828
  6414b0: 5d                           	pop	rbp
  6414b1: c3                           	ret
  6414b2: 48 89 44 24 08               	mov	qword ptr [rsp + 0x8], rax
  6414b7: e8 04 d4 e4 ff               	call	0x48e8c0 <runtime.morestack_noctxt.abi0>
  6414bc: 48 8b 44 24 08               	mov	rax, qword ptr [rsp + 0x8]
  6414c1: e9 1a ff ff ff               	jmp	0x6413e0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast>
  6414c6: cc                           	int3
  6414c7: cc                           	int3
  6414c8: cc                           	int3
  6414c9: cc                           	int3
  6414ca: cc                           	int3
  6414cb: cc                           	int3
  6414cc: cc                           	int3
  6414cd: cc                           	int3
  6414ce: cc                           	int3
  6414cf: cc                           	int3
  6414d0: cc                           	int3
  6414d1: cc                           	int3
  6414d2: cc                           	int3
  6414d3: cc                           	int3
  6414d4: cc                           	int3
  6414d5: cc                           	int3
  6414d6: cc                           	int3
  6414d7: cc                           	int3
  6414d8: cc                           	int3
  6414d9: cc                           	int3
  6414da: cc                           	int3
  6414db: cc                           	int3
  6414dc: cc                           	int3
  6414dd: cc                           	int3
  6414de: cc                           	int3
  6414df: cc                           	int3

000000000064ab20 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1>:
  64ab20: 4c 8d a4 24 48 ff ff ff      	lea	r12, [rsp - 0xb8]
  64ab28: 4d 3b 66 10                  	cmp	r12, qword ptr [r14 + 0x10]
  64ab2c: 0f 86 6a 08 00 00            	jbe	0x64b39c <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x87c>
  64ab32: 55                           	push	rbp
  64ab33: 48 89 e5                     	mov	rbp, rsp
  64ab36: 48 81 ec 30 01 00 00         	sub	rsp, 0x130
  64ab3d: 48 89 84 24 40 01 00 00      	mov	qword ptr [rsp + 0x140], rax
  64ab45: 48 8b 72 10                  	mov	rsi, qword ptr [rdx + 0x10]
  64ab49: 48 89 b4 24 28 01 00 00      	mov	qword ptr [rsp + 0x128], rsi
  64ab51: 48 8b 7a 08                  	mov	rdi, qword ptr [rdx + 0x8]
  64ab55: 48 8b 0f                     	mov	rcx, qword ptr [rdi]
  64ab58: 48 89 4c 24 60               	mov	qword ptr [rsp + 0x60], rcx
  64ab5d: 48 8b 7f 08                  	mov	rdi, qword ptr [rdi + 0x8]
  64ab61: 48 89 7c 24 70               	mov	qword ptr [rsp + 0x70], rdi
  64ab66: 48 8b 5e 10                  	mov	rbx, qword ptr [rsi + 0x10]
  64ab6a: 48 ff cb                     	dec	rbx
  64ab6d: 48 89 de                     	mov	rsi, rbx
  64ab70: 48 0f af ce                  	imul	rcx, rsi
  64ab74: 48 89 8c 24 b8 00 00 00      	mov	qword ptr [rsp + 0xb8], rcx
  64ab7c: 48 0f af df                  	imul	rbx, rdi
  64ab80: 48 89 9c 24 b0 00 00 00      	mov	qword ptr [rsp + 0xb0], rbx
  64ab88: 48 8d 73 1e                  	lea	rsi, [rbx + 0x1e]
  64ab8c: 48 89 74 24 78               	mov	qword ptr [rsp + 0x78], rsi
  64ab91: 48 8b 52 18                  	mov	rdx, qword ptr [rdx + 0x18]
  64ab95: 48 89 94 24 90 00 00 00      	mov	qword ptr [rsp + 0x90], rdx
  64ab9d: 48 83 c1 18                  	add	rcx, 0x18
  64aba1: 48 89 4c 24 68               	mov	qword ptr [rsp + 0x68], rcx
  64aba6: 48 8d 05 3b b8 25 00         	lea	rax, [rip + 0x25b83b]   # 0x8a63e8 <type:*+0x36170>
  64abad: 48 89 cb                     	mov	rbx, rcx
  64abb0: e8 6b 0a e4 ff               	call	0x48b620 <runtime.makeslice>
  64abb5: 48 89 84 24 20 01 00 00      	mov	qword ptr [rsp + 0x120], rax
  64abbd: 48 8d 05 24 b8 25 00         	lea	rax, [rip + 0x25b824]   # 0x8a63e8 <type:*+0x36170>
  64abc4: 48 8b 5c 24 78               	mov	rbx, qword ptr [rsp + 0x78]
  64abc9: 48 89 d9                     	mov	rcx, rbx
  64abcc: e8 4f 0a e4 ff               	call	0x48b620 <runtime.makeslice>
  64abd1: 31 d2                        	xor	edx, edx
  64abd3: 48 8b 74 24 68               	mov	rsi, qword ptr [rsp + 0x68]
  64abd8: 48 8b bc 24 20 01 00 00      	mov	rdi, qword ptr [rsp + 0x120]
  64abe0: eb 32                        	jmp	0x64ac14 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0xf4>
  64abe2: 4c 8d 1c d2                  	lea	r11, [rdx + 8*rdx]
  64abe6: 4e 8d 1c 9a                  	lea	r11, [rdx + 4*r11]
  64abea: 48 89 c1                     	mov	rcx, rax
  64abed: 48 b8 8c 2e ba e8 a2 8b 2e ba	movabs	rax, -0x45d1745d1745d174
  64abf7: 48 89 d3                     	mov	rbx, rdx
  64abfa: 48 f7 e2                     	mul	rdx
  64abfd: 48 c1 ea 03                  	shr	rdx, 0x3
  64ac01: 4e 8d 1c 1a                  	lea	r11, [rdx + r11]
  64ac05: 4d 8d 5b 13                  	lea	r11, [r11 + 0x13]
  64ac09: 44 88 1c 1f                  	mov	byte ptr [rdi + rbx], r11b
  64ac0d: 48 8d 53 01                  	lea	rdx, [rbx + 0x1]
  64ac11: 48 89 c8                     	mov	rax, rcx
  64ac14: 48 39 d6                     	cmp	rsi, rdx
  64ac17: 7f c9                        	jg	0x64abe2 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0xc2>
  64ac19: 45 31 db                     	xor	r11d, r11d
  64ac1c: 48 89 f9                     	mov	rcx, rdi
  64ac1f: 48 8b 7c 24 78               	mov	rdi, qword ptr [rsp + 0x78]
  64ac24: eb 2e                        	jmp	0x64ac54 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x134>
  64ac26: 4d 6b e3 47                  	imul	r12, r11, 0x47
  64ac2a: 48 89 c2                     	mov	rdx, rax
  64ac2d: 48 b8 4a 92 24 49 92 24 49 92	movabs	rax, -0x6db6db6db6db6db6
  64ac37: 48 89 d3                     	mov	rbx, rdx
  64ac3a: 49 f7 e3                     	mul	r11
  64ac3d: 48 c1 ea 02                  	shr	rdx, 0x2
  64ac41: 4e 8d 24 22                  	lea	r12, [rdx + r12]
  64ac45: 4d 8d 64 24 1f               	lea	r12, [r12 + 0x1f]
  64ac4a: 46 88 24 1b                  	mov	byte ptr [rbx + r11], r12b
  64ac4e: 49 ff c3                     	inc	r11
  64ac51: 48 89 d8                     	mov	rax, rbx
  64ac54: 49 39 fb                     	cmp	r11, rdi
  64ac57: 7c cd                        	jl	0x64ac26 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x106>
  64ac59: 48 89 84 24 18 01 00 00      	mov	qword ptr [rsp + 0x118], rax
  64ac61: 4c 8b 9c 24 90 00 00 00      	mov	r11, qword ptr [rsp + 0x90]
  64ac69: 49 83 fb 01                  	cmp	r11, 0x1
  64ac6d: 75 51                        	jne	0x64acc0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1a0>
  64ac6f: 48 8b 9c 24 b8 00 00 00      	mov	rbx, qword ptr [rsp + 0xb8]
  64ac77: 49 89 db                     	mov	r11, rbx
  64ac7a: 66 0f 1f 44 00 00            	nop	word ptr [rax + rax]
  64ac80: 48 83 c3 18                  	add	rbx, 0x18
  64ac84: 74 2d                        	je	0x64acb3 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x193>
  64ac86: 48 89 c8                     	mov	rax, rcx
  64ac89: 48 89 f3                     	mov	rbx, rsi
  64ac8c: e8 0f 59 e4 ff               	call	0x4905a0 <runtime.memclrNoHeapPointers>
  64ac91: 48 8b 84 24 18 01 00 00      	mov	rax, qword ptr [rsp + 0x118]
  64ac99: 48 8b 8c 24 20 01 00 00      	mov	rcx, qword ptr [rsp + 0x120]
  64aca1: 48 8b 74 24 68               	mov	rsi, qword ptr [rsp + 0x68]
  64aca6: 48 8b 7c 24 78               	mov	rdi, qword ptr [rsp + 0x78]
  64acab: 4c 8b 9c 24 b8 00 00 00      	mov	r11, qword ptr [rsp + 0xb8]
  64acb3: 45 31 e4                     	xor	r12d, r12d
  64acb6: e9 d7 06 00 00               	jmp	0x64b392 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x872>
  64acbb: 0f 1f 44 00 00               	nop	dword ptr [rax + rax]
  64acc0: 49 83 fb 02                  	cmp	r11, 0x2
  64acc4: 75 1f                        	jne	0x64ace5 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1c5>
  64acc6: 4c 8b 9c 24 28 01 00 00      	mov	r11, qword ptr [rsp + 0x128]
  64acce: 4d 8b 63 10                  	mov	r12, qword ptr [r11 + 0x10]
  64acd2: 45 31 ed                     	xor	r13d, r13d
  64acd5: 4c 8b 54 24 70               	mov	r10, qword ptr [rsp + 0x70]
  64acda: 48 8b 5c 24 60               	mov	rbx, qword ptr [rsp + 0x60]
  64acdf: 90                           	nop
  64ace0: e9 31 06 00 00               	jmp	0x64b316 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7f6>
  64ace5: 48 8b 9c 24 b8 00 00 00      	mov	rbx, qword ptr [rsp + 0xb8]
  64aced: 4c 8d 5b 0b                  	lea	r11, [rbx + 0xb]
  64acf1: 4c 39 de                     	cmp	rsi, r11
  64acf4: 0f 82 0b 06 00 00            	jb	0x64b305 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7e5>
  64acfa: 66 0f 1f 44 00 00            	nop	word ptr [rax + rax]
  64ad00: 49 83 fb 03                  	cmp	r11, 0x3
  64ad04: 0f 82 f4 05 00 00            	jb	0x64b2fe <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7de>
  64ad0a: 4c 8d 5b 15                  	lea	r11, [rbx + 0x15]
  64ad0e: 4d 89 dc                     	mov	r12, r11
  64ad11: 49 f7 db                     	neg	r11
  64ad14: 49 c1 fb 3f                  	sar	r11, 0x3f
  64ad18: 41 83 e3 03                  	and	r11d, 0x3
  64ad1c: 4c 8b 8c 24 b0 00 00 00      	mov	r9, qword ptr [rsp + 0xb0]
  64ad24: 4d 8d 69 0d                  	lea	r13, [r9 + 0xd]
  64ad28: 49 01 cb                     	add	r11, rcx
  64ad2b: 49 39 fd                     	cmp	r13, rdi
  64ad2e: 0f 87 c5 05 00 00            	ja	0x64b2f9 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7d9>
  64ad34: 49 83 fd 05                  	cmp	r13, 0x5
  64ad38: 0f 82 b6 05 00 00            	jb	0x64b2f4 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7d4>
  64ad3e: 4c 89 a4 24 a8 00 00 00      	mov	qword ptr [rsp + 0xa8], r12
  64ad46: 4c 89 9c 24 e0 00 00 00      	mov	qword ptr [rsp + 0xe0], r11
  64ad4e: 4d 8d 69 19                  	lea	r13, [r9 + 0x19]
  64ad52: 4c 89 ac 24 88 00 00 00      	mov	qword ptr [rsp + 0x88], r13
  64ad5a: 4d 89 ef                     	mov	r15, r13
  64ad5d: 49 f7 dd                     	neg	r13
  64ad60: 49 c1 fd 3f                  	sar	r13, 0x3f
  64ad64: 41 83 e5 05                  	and	r13d, 0x5
  64ad68: 49 01 c5                     	add	r13, rax
  64ad6b: 4c 89 ac 24 d0 00 00 00      	mov	qword ptr [rsp + 0xd0], r13
  64ad73: 48 85 c9                     	test	rcx, rcx
  64ad76: 75 0d                        	jne	0x64ad85 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x265>
  64ad78: 31 d2                        	xor	edx, edx
  64ad7a: 45 31 c0                     	xor	r8d, r8d
  64ad7d: 0f 1f 00                     	nop	dword ptr [rax]
  64ad80: e9 8f 00 00 00               	jmp	0x64ae14 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x2f4>
  64ad85: 48 8d 44 24 40               	lea	rax, [rsp + 0x40]
  64ad8a: 48 89 f3                     	mov	rbx, rsi
  64ad8d: 31 c9                        	xor	ecx, ecx
  64ad8f: 48 89 df                     	mov	rdi, rbx
  64ad92: 48 8d 35 4f b6 25 00         	lea	rsi, [rip + 0x25b64f]   # 0x8a63e8 <type:*+0x36170>
  64ad99: e8 62 09 e4 ff               	call	0x48b700 <runtime.growslice>
  64ad9e: 48 89 84 24 c8 00 00 00      	mov	qword ptr [rsp + 0xc8], rax
  64ada6: 48 89 5c 24 48               	mov	qword ptr [rsp + 0x48], rbx
  64adab: 48 8b 9c 24 20 01 00 00      	mov	rbx, qword ptr [rsp + 0x120]
  64adb3: 48 8b 4c 24 68               	mov	rcx, qword ptr [rsp + 0x68]
  64adb8: e8 e3 5a e4 ff               	call	0x4908a0 <runtime.memmove>
  64adbd: 48 8b 84 24 18 01 00 00      	mov	rax, qword ptr [rsp + 0x118]
  64adc5: 48 8b 8c 24 20 01 00 00      	mov	rcx, qword ptr [rsp + 0x120]
  64adcd: 48 8b 9c 24 b8 00 00 00      	mov	rbx, qword ptr [rsp + 0xb8]
  64add5: 48 8b 74 24 68               	mov	rsi, qword ptr [rsp + 0x68]
  64adda: 48 8b 7c 24 78               	mov	rdi, qword ptr [rsp + 0x78]
  64addf: 4c 8b 8c 24 b0 00 00 00      	mov	r9, qword ptr [rsp + 0xb0]
  64ade7: 4c 8b 9c 24 e0 00 00 00      	mov	r11, qword ptr [rsp + 0xe0]
  64adef: 4c 8b a4 24 a8 00 00 00      	mov	r12, qword ptr [rsp + 0xa8]
  64adf7: 4c 8b ac 24 d0 00 00 00      	mov	r13, qword ptr [rsp + 0xd0]
  64adff: 4c 8b bc 24 88 00 00 00      	mov	r15, qword ptr [rsp + 0x88]
  64ae07: 48 8b 54 24 48               	mov	rdx, qword ptr [rsp + 0x48]
  64ae0c: 4c 8b 84 24 c8 00 00 00      	mov	r8, qword ptr [rsp + 0xc8]
  64ae14: 48 89 54 24 48               	mov	qword ptr [rsp + 0x48], rdx
  64ae19: 4c 89 84 24 c8 00 00 00      	mov	qword ptr [rsp + 0xc8], r8
  64ae21: 48 85 c0                     	test	rax, rax
  64ae24: 75 13                        	jne	0x64ae39 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x319>
  64ae26: 45 31 d2                     	xor	r10d, r10d
  64ae29: 45 31 d2                     	xor	r10d, r10d
  64ae2c: 4c 89 94 24 c0 00 00 00      	mov	qword ptr [rsp + 0xc0], r10
  64ae34: 45 31 d2                     	xor	r10d, r10d
  64ae37: eb 74                        	jmp	0x64aead <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x38d>
  64ae39: 48 8d 44 24 40               	lea	rax, [rsp + 0x40]
  64ae3e: 48 89 fb                     	mov	rbx, rdi
  64ae41: 31 c9                        	xor	ecx, ecx
  64ae43: 48 8d 35 9e b5 25 00         	lea	rsi, [rip + 0x25b59e]   # 0x8a63e8 <type:*+0x36170>
  64ae4a: e8 b1 08 e4 ff               	call	0x48b700 <runtime.growslice>
  64ae4f: 48 89 84 24 c0 00 00 00      	mov	qword ptr [rsp + 0xc0], rax
  64ae57: 48 89 5c 24 40               	mov	qword ptr [rsp + 0x40], rbx
  64ae5c: 48 8b 9c 24 18 01 00 00      	mov	rbx, qword ptr [rsp + 0x118]
  64ae64: 48 8b 4c 24 78               	mov	rcx, qword ptr [rsp + 0x78]
  64ae69: e8 32 5a e4 ff               	call	0x4908a0 <runtime.memmove>
  64ae6e: 48 8b 8c 24 20 01 00 00      	mov	rcx, qword ptr [rsp + 0x120]
  64ae76: 48 8b 54 24 48               	mov	rdx, qword ptr [rsp + 0x48]
  64ae7b: 48 8b 9c 24 b8 00 00 00      	mov	rbx, qword ptr [rsp + 0xb8]
  64ae83: 48 8b 74 24 68               	mov	rsi, qword ptr [rsp + 0x68]
  64ae88: 4c 8b 84 24 c8 00 00 00      	mov	r8, qword ptr [rsp + 0xc8]
  64ae90: 4c 8b 8c 24 b0 00 00 00      	mov	r9, qword ptr [rsp + 0xb0]
  64ae98: 4c 8b 9c 24 e0 00 00 00      	mov	r11, qword ptr [rsp + 0xe0]
  64aea0: 4c 8b ac 24 d0 00 00 00      	mov	r13, qword ptr [rsp + 0xd0]
  64aea8: 4c 8b 54 24 40               	mov	r10, qword ptr [rsp + 0x40]
  64aead: 4c 89 54 24 40               	mov	qword ptr [rsp + 0x40], r10
  64aeb2: 48 83 c3 08                  	add	rbx, 0x8
  64aeb6: 49 83 c1 08                  	add	r9, 0x8
  64aeba: 4c 8b a4 24 28 01 00 00      	mov	r12, qword ptr [rsp + 0x128]
  64aec2: 49 8b 44 24 10               	mov	rax, qword ptr [r12 + 0x10]
  64aec7: 45 31 ff                     	xor	r15d, r15d
  64aeca: 45 31 e4                     	xor	r12d, r12d
  64aecd: 48 8b 7c 24 60               	mov	rdi, qword ptr [rsp + 0x60]
  64aed2: 4c 8b 54 24 70               	mov	r10, qword ptr [rsp + 0x70]
  64aed7: eb 1d                        	jmp	0x64aef6 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x3d6>
  64aed9: 4c 8b 64 24 50               	mov	r12, qword ptr [rsp + 0x50]
  64aede: 49 ff c4                     	inc	r12
  64aee1: 48 8b 8c 24 20 01 00 00      	mov	rcx, qword ptr [rsp + 0x120]
  64aee9: 48 8b 74 24 68               	mov	rsi, qword ptr [rsp + 0x68]
  64aeee: 4c 8b ac 24 d0 00 00 00      	mov	r13, qword ptr [rsp + 0xd0]
  64aef6: 49 39 c4                     	cmp	r12, rax
  64aef9: 7d 63                        	jge	0x64af5e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x43e>
  64aefb: 4c 89 64 24 50               	mov	qword ptr [rsp + 0x50], r12
  64af00: 4c 0f af e7                  	imul	r12, rdi
  64af04: 4c 8b 6c 24 50               	mov	r13, qword ptr [rsp + 0x50]
  64af09: 4d 0f af ea                  	imul	r13, r10
  64af0d: 31 c9                        	xor	ecx, ecx
  64af0f: 48 8b b4 24 d0 00 00 00      	mov	rsi, qword ptr [rsp + 0xd0]
  64af17: eb 1e                        	jmp	0x64af37 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x417>
  64af19: 0f b6 14 16                  	movzx	edx, byte ptr [rsi + rdx]
  64af1d: 49 29 d0                     	sub	r8, rdx
  64af20: 4d 0f af c0                  	imul	r8, r8
  64af24: 4d 01 c7                     	add	r15, r8
  64af27: 48 ff c1                     	inc	rcx
  64af2a: 48 8b 54 24 48               	mov	rdx, qword ptr [rsp + 0x48]
  64af2f: 4c 8b 84 24 c8 00 00 00      	mov	r8, qword ptr [rsp + 0xc8]
  64af37: 48 83 f9 08                  	cmp	rcx, 0x8
  64af3b: 7d 9c                        	jge	0x64aed9 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x3b9>
  64af3d: 4d 8d 04 0c                  	lea	r8, [r12 + rcx]
  64af41: 4c 39 c3                     	cmp	rbx, r8
  64af44: 0f 86 a5 03 00 00            	jbe	0x64b2ef <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7cf>
  64af4a: 49 8d 54 0d 00               	lea	rdx, [r13 + rcx]
  64af4f: 47 0f b6 04 03               	movzx	r8d, byte ptr [r11 + r8]
  64af54: 49 39 d1                     	cmp	r9, rdx
  64af57: 77 c0                        	ja	0x64af19 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x3f9>
  64af59: e9 8c 03 00 00               	jmp	0x64b2ea <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7ca>
  64af5e: 48 89 9c 24 a0 00 00 00      	mov	qword ptr [rsp + 0xa0], rbx
  64af66: 4c 89 8c 24 80 00 00 00      	mov	qword ptr [rsp + 0x80], r9
  64af6e: 4c 89 7c 24 58               	mov	qword ptr [rsp + 0x58], r15
  64af73: 48 c7 84 24 98 00 00 00 00 00 00 00  	mov	qword ptr [rsp + 0x98], 0x0
  64af7f: 4c 8b a4 24 28 01 00 00      	mov	r12, qword ptr [rsp + 0x128]
  64af87: 41 80 7c 24 20 00            	cmp	byte ptr [r12 + 0x20], 0x0
  64af8d: 74 35                        	je	0x64afc4 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x4a4>
  64af8f: 48 85 db                     	test	rbx, rbx
  64af92: 0f 86 4d 03 00 00            	jbe	0x64b2e5 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7c5>
  64af98: 0f 1f 84 00 00 00 00 00      	nop	dword ptr [rax + rax]
  64afa0: 4d 85 c9                     	test	r9, r9
  64afa3: 0f 86 33 03 00 00            	jbe	0x64b2dc <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7bc>
  64afa9: 4c 89 d8                     	mov	rax, r11
  64afac: 48 89 fb                     	mov	rbx, rdi
  64afaf: 4c 89 e9                     	mov	rcx, r13
  64afb2: 4c 89 d7                     	mov	rdi, r10
  64afb5: e8 86 7f fc ff               	call	0x612f40 <github.com/thesyncim/govpx/internal/vp8/dsp.SSE8x8PtrFast>
  64afba: 48 89 84 24 98 00 00 00      	mov	qword ptr [rsp + 0x98], rax
  64afc2: eb 2c                        	jmp	0x64aff0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x4d0>
  64afc4: 49 8b 54 24 18               	mov	rdx, qword ptr [r12 + 0x18]
  64afc9: 4c 8b 22                     	mov	r12, qword ptr [rdx]
  64afcc: 4c 89 d8                     	mov	rax, r11
  64afcf: 48 8b 8c 24 a8 00 00 00      	mov	rcx, qword ptr [rsp + 0xa8]
  64afd7: 4c 89 ee                     	mov	rsi, r13
  64afda: 4d 89 c8                     	mov	r8, r9
  64afdd: 4c 8b 8c 24 88 00 00 00      	mov	r9, qword ptr [rsp + 0x88]
  64afe5: 41 ff d4                     	call	r12
  64afe8: 48 89 84 24 98 00 00 00      	mov	qword ptr [rsp + 0x98], rax
  64aff0: 48 8b 84 24 98 00 00 00      	mov	rax, qword ptr [rsp + 0x98]
  64aff8: 48 8b 4c 24 58               	mov	rcx, qword ptr [rsp + 0x58]
  64affd: 0f 1f 00                     	nop	dword ptr [rax]
  64b000: 48 39 c1                     	cmp	rcx, rax
  64b003: 74 79                        	je	0x64b07e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x55e>
  64b005: 48 8d 8c 24 f8 00 00 00      	lea	rcx, [rsp + 0xf8]
  64b00d: 44 0f 11 39                  	movups	xmmword ptr [rcx], xmm15
  64b011: 44 0f 11 79 10               	movups	xmmword ptr [rcx + 0x10], xmm15
  64b016: e8 45 c6 e3 ff               	call	0x487660 <runtime.convT64>
  64b01b: 48 8d 0d 86 b5 25 00         	lea	rcx, [rip + 0x25b586]   # 0x8a65a8 <type:*+0x36330>
  64b022: 48 89 8c 24 f8 00 00 00      	mov	qword ptr [rsp + 0xf8], rcx
  64b02a: 48 89 84 24 00 01 00 00      	mov	qword ptr [rsp + 0x100], rax
  64b032: 48 8b 44 24 58               	mov	rax, qword ptr [rsp + 0x58]
  64b037: e8 24 c6 e3 ff               	call	0x487660 <runtime.convT64>
  64b03c: 48 8d 0d 65 b5 25 00         	lea	rcx, [rip + 0x25b565]   # 0x8a65a8 <type:*+0x36330>
  64b043: 48 89 8c 24 08 01 00 00      	mov	qword ptr [rsp + 0x108], rcx
  64b04b: 48 89 84 24 10 01 00 00      	mov	qword ptr [rsp + 0x110], rax
  64b053: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b05b: 84 00                        	test	byte ptr [rax], al
  64b05d: 48 8d 1d b1 f4 01 00         	lea	rbx, [rip + 0x1f4b1]    # 0x66a515 <runtime.rodata+0x7515>
  64b064: b9 18 00 00 00               	mov	ecx, 0x18
  64b069: 48 8d bc 24 f8 00 00 00      	lea	rdi, [rsp + 0xf8]
  64b071: be 02 00 00 00               	mov	esi, 0x2
  64b076: 41 89 f0                     	mov	r8d, esi
  64b079: e8 c2 ad ec ff               	call	0x515e40 <testing.(*common).Fatalf>
  64b07e: 90                           	nop
  64b07f: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b087: c6 80 52 02 00 00 01         	mov	byte ptr [rax + 0x252], 0x1
  64b08e: e8 ad e5 eb ff               	call	0x509640 <testing.(*B).ResetTimer>
  64b093: 48 8b 8c 24 28 01 00 00      	mov	rcx, qword ptr [rsp + 0x128]
  64b09b: 80 79 20 00                  	cmp	byte ptr [rcx + 0x20], 0x0
  64b09f: 90                           	nop
  64b0a0: 74 2c                        	je	0x64b0ce <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x5ae>
  64b0a2: 48 8b b4 24 a0 00 00 00      	mov	rsi, qword ptr [rsp + 0xa0]
  64b0aa: 48 85 f6                     	test	rsi, rsi
  64b0ad: 0f 86 24 02 00 00            	jbe	0x64b2d7 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7b7>
  64b0b3: 48 8b b4 24 80 00 00 00      	mov	rsi, qword ptr [rsp + 0x80]
  64b0bb: 0f 1f 44 00 00               	nop	dword ptr [rax + rax]
  64b0c0: 48 85 f6                     	test	rsi, rsi
  64b0c3: 0f 87 c1 01 00 00            	ja	0x64b28a <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x76a>
  64b0c9: e9 04 02 00 00               	jmp	0x64b2d2 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7b2>
  64b0ce: 48 8b 51 18                  	mov	rdx, qword ptr [rcx + 0x18]
  64b0d2: 48 89 94 24 d8 00 00 00      	mov	qword ptr [rsp + 0xd8], rdx
  64b0da: eb 50                        	jmp	0x64b12c <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x60c>
  64b0dc: 4c 8b 1a                     	mov	r11, qword ptr [rdx]
  64b0df: 48 8b 84 24 e0 00 00 00      	mov	rax, qword ptr [rsp + 0xe0]
  64b0e7: 48 8b 9c 24 a0 00 00 00      	mov	rbx, qword ptr [rsp + 0xa0]
  64b0ef: 48 8b 8c 24 a8 00 00 00      	mov	rcx, qword ptr [rsp + 0xa8]
  64b0f7: 48 8b 7c 24 60               	mov	rdi, qword ptr [rsp + 0x60]
  64b0fc: 48 8b b4 24 d0 00 00 00      	mov	rsi, qword ptr [rsp + 0xd0]
  64b104: 4c 8b 84 24 80 00 00 00      	mov	r8, qword ptr [rsp + 0x80]
  64b10c: 4c 8b 8c 24 88 00 00 00      	mov	r9, qword ptr [rsp + 0x88]
  64b114: 4c 8b 54 24 70               	mov	r10, qword ptr [rsp + 0x70]
  64b119: 41 ff d3                     	call	r11
  64b11c: 48 89 84 24 98 00 00 00      	mov	qword ptr [rsp + 0x98], rax
  64b124: 48 8b 94 24 d8 00 00 00      	mov	rdx, qword ptr [rsp + 0xd8]
  64b12c: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b134: 4c 8b 98 c0 02 00 00         	mov	r11, qword ptr [rax + 0x2c0]
  64b13b: 0f 1f 44 00 00               	nop	dword ptr [rax + rax]
  64b140: 4c 39 98 b8 02 00 00         	cmp	qword ptr [rax + 0x2b8], r11
  64b147: 76 11                        	jbe	0x64b15a <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x63a>
  64b149: 49 ff c3                     	inc	r11
  64b14c: 4c 89 98 c0 02 00 00         	mov	qword ptr [rax + 0x2c0], r11
  64b153: b9 01 00 00 00               	mov	ecx, 0x1
  64b158: eb 17                        	jmp	0x64b171 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x651>
  64b15a: e8 61 f2 eb ff               	call	0x50a3c0 <testing.(*B).loopSlowPath>
  64b15f: 48 8b 94 24 d8 00 00 00      	mov	rdx, qword ptr [rsp + 0xd8]
  64b167: 89 c1                        	mov	ecx, eax
  64b169: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b171: 84 c9                        	test	cl, cl
  64b173: 0f 85 63 ff ff ff            	jne	0x64b0dc <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x5bc>
  64b179: 48 8b 54 24 58               	mov	rdx, qword ptr [rsp + 0x58]
  64b17e: 66 90                        	nop
  64b180: 48 39 94 24 98 00 00 00      	cmp	qword ptr [rsp + 0x98], rdx
  64b188: 74 07                        	je	0x64b191 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x671>
  64b18a: b9 01 00 00 00               	mov	ecx, 0x1
  64b18f: eb 77                        	jmp	0x64b208 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6e8>
  64b191: 48 8b 4c 24 68               	mov	rcx, qword ptr [rsp + 0x68]
  64b196: 48 8b 54 24 48               	mov	rdx, qword ptr [rsp + 0x48]
  64b19b: 0f 1f 44 00 00               	nop	dword ptr [rax + rax]
  64b1a0: 48 39 d1                     	cmp	rcx, rdx
  64b1a3: 74 04                        	je	0x64b1a9 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x689>
  64b1a5: 31 c9                        	xor	ecx, ecx
  64b1a7: eb 1f                        	jmp	0x64b1c8 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6a8>
  64b1a9: 48 8b 84 24 20 01 00 00      	mov	rax, qword ptr [rsp + 0x120]
  64b1b1: 48 8b 9c 24 c8 00 00 00      	mov	rbx, qword ptr [rsp + 0xc8]
  64b1b9: e8 a2 7a db ff               	call	0x402c60 <runtime.memequal>
  64b1be: 89 c1                        	mov	ecx, eax
  64b1c0: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b1c8: 84 c9                        	test	cl, cl
  64b1ca: 74 37                        	je	0x64b203 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6e3>
  64b1cc: 48 8b 54 24 40               	mov	rdx, qword ptr [rsp + 0x40]
  64b1d1: 48 8b 4c 24 78               	mov	rcx, qword ptr [rsp + 0x78]
  64b1d6: 48 39 ca                     	cmp	rdx, rcx
  64b1d9: 74 04                        	je	0x64b1df <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6bf>
  64b1db: 31 c9                        	xor	ecx, ecx
  64b1dd: eb 1f                        	jmp	0x64b1fe <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6de>
  64b1df: 48 8b 84 24 18 01 00 00      	mov	rax, qword ptr [rsp + 0x118]
  64b1e7: 48 8b 9c 24 c0 00 00 00      	mov	rbx, qword ptr [rsp + 0xc0]
  64b1ef: e8 6c 7a db ff               	call	0x402c60 <runtime.memequal>
  64b1f4: 89 c1                        	mov	ecx, eax
  64b1f6: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b1fe: 83 f1 01                     	xor	ecx, 0x1
  64b201: eb 05                        	jmp	0x64b208 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6e8>
  64b203: b9 01 00 00 00               	mov	ecx, 0x1
  64b208: 84 c9                        	test	cl, cl
  64b20a: 74 32                        	je	0x64b23e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x71e>
  64b20c: 48 8d 15 55 b1 25 00         	lea	rdx, [rip + 0x25b155]   # 0x8a6368 <type:*+0x360f0>
  64b213: 48 89 94 24 e8 00 00 00      	mov	qword ptr [rsp + 0xe8], rdx
  64b21b: 48 8d 15 2e 0a 03 00         	lea	rdx, [rip + 0x30a2e]    # 0x67bc50 <internal/sync..dict.indirect[interface {},interface {}]+0x120>
  64b222: 48 89 94 24 f0 00 00 00      	mov	qword ptr [rsp + 0xf0], rdx
  64b22a: 48 8d 9c 24 e8 00 00 00      	lea	rbx, [rsp + 0xe8]
  64b232: b9 01 00 00 00               	mov	ecx, 0x1
  64b237: 89 cf                        	mov	edi, ecx
  64b239: e8 02 ab ec ff               	call	0x515d40 <testing.(*common).Fatal>
  64b23e: 48 8b 84 24 98 00 00 00      	mov	rax, qword ptr [rsp + 0x98]
  64b246: 48 89 05 13 3a 2d 00         	mov	qword ptr [rip + 0x2d3a13], rax # 0x91ec60 <github.com/thesyncim/govpx/internal/vp8/dsp.sse8RowsNativeSink>
  64b24d: 48 81 c4 30 01 00 00         	add	rsp, 0x130
  64b254: 5d                           	pop	rbp
  64b255: c3                           	ret
  64b256: 48 8b 35 0b a4 28 00         	mov	rsi, qword ptr [rip + 0x28a40b] # 0x8d5668 <go:funcdesc+0x9e0>
  64b25d: 48 8b 84 24 e0 00 00 00      	mov	rax, qword ptr [rsp + 0xe0]
  64b265: 48 8b 5c 24 60               	mov	rbx, qword ptr [rsp + 0x60]
  64b26a: 48 8b 8c 24 d0 00 00 00      	mov	rcx, qword ptr [rsp + 0xd0]
  64b272: 48 8b 7c 24 70               	mov	rdi, qword ptr [rsp + 0x70]
  64b277: 48 8d 15 ea a3 28 00         	lea	rdx, [rip + 0x28a3ea]   # 0x8d5668 <go:funcdesc+0x9e0>
  64b27e: 66 90                        	nop
  64b280: ff d6                        	call	rsi
  64b282: 48 89 84 24 98 00 00 00      	mov	qword ptr [rsp + 0x98], rax
  64b28a: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b292: 48 8b b0 c0 02 00 00         	mov	rsi, qword ptr [rax + 0x2c0]
  64b299: 0f 1f 80 00 00 00 00         	nop	dword ptr [rax]
  64b2a0: 48 39 b0 b8 02 00 00         	cmp	qword ptr [rax + 0x2b8], rsi
  64b2a7: 76 11                        	jbe	0x64b2ba <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x79a>
  64b2a9: 48 ff c6                     	inc	rsi
  64b2ac: 48 89 b0 c0 02 00 00         	mov	qword ptr [rax + 0x2c0], rsi
  64b2b3: b9 01 00 00 00               	mov	ecx, 0x1
  64b2b8: eb 0f                        	jmp	0x64b2c9 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7a9>
  64b2ba: e8 01 f1 eb ff               	call	0x50a3c0 <testing.(*B).loopSlowPath>
  64b2bf: 89 c1                        	mov	ecx, eax
  64b2c1: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b2c9: 84 c9                        	test	cl, cl
  64b2cb: 75 89                        	jne	0x64b256 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x736>
  64b2cd: e9 a7 fe ff ff               	jmp	0x64b179 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x659>
  64b2d2: e8 29 52 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b2d7: e8 24 52 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b2dc: 0f 1f 40 00                  	nop	dword ptr [rax]
  64b2e0: e8 1b 52 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b2e5: e8 16 52 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b2ea: e8 11 52 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b2ef: e8 0c 52 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b2f4: e8 07 52 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b2f9: e8 02 52 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b2fe: 66 90                        	nop
  64b300: e8 fb 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b305: e8 f6 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b30a: 4c 8d 6a 01                  	lea	r13, [rdx + 0x1]
  64b30e: 4c 8b 9c 24 28 01 00 00      	mov	r11, qword ptr [rsp + 0x128]
  64b316: 4d 39 e5                     	cmp	r13, r12
  64b319: 0f 8d c6 f9 ff ff            	jge	0x64ace5 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1c5>
  64b31f: 4d 89 ef                     	mov	r15, r13
  64b322: 4d 0f af ea                  	imul	r13, r10
  64b326: 49 8d 55 0d                  	lea	rdx, [r13 + 0xd]
  64b32a: 48 39 fa                     	cmp	rdx, rdi
  64b32d: 77 56                        	ja	0x64b385 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x865>
  64b32f: 4d 8d 45 05                  	lea	r8, [r13 + 0x5]
  64b333: 4c 39 c2                     	cmp	rdx, r8
  64b336: 72 45                        	jb	0x64b37d <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x85d>
  64b338: 4c 89 fa                     	mov	rdx, r15
  64b33b: 4c 0f af fb                  	imul	r15, rbx
  64b33f: 4d 8d 47 0b                  	lea	r8, [r15 + 0xb]
  64b343: 4d 8d 4c 05 00               	lea	r9, [r13 + rax]
  64b348: 4d 8d 49 05                  	lea	r9, [r9 + 0x5]
  64b34c: 4c 39 c6                     	cmp	rsi, r8
  64b34f: 72 27                        	jb	0x64b378 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x858>
  64b351: 4d 8d 5f 03                  	lea	r11, [r15 + 0x3]
  64b355: 4d 39 d8                     	cmp	r8, r11
  64b358: 72 19                        	jb	0x64b373 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x853>
  64b35a: 4d 8d 1c 0f                  	lea	r11, [r15 + rcx]
  64b35e: 4d 8d 5b 03                  	lea	r11, [r11 + 0x3]
  64b362: 4d 39 d9                     	cmp	r9, r11
  64b365: 74 a3                        	je	0x64b30a <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7ea>
  64b367: 4d 8b 5c 0f 03               	mov	r11, qword ptr [r15 + rcx + 0x3]
  64b36c: 4d 89 5c 05 05               	mov	qword ptr [r13 + rax + 0x5], r11
  64b371: eb 97                        	jmp	0x64b30a <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7ea>
  64b373: e8 88 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b378: e8 83 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b37d: 0f 1f 00                     	nop	dword ptr [rax]
  64b380: e8 7b 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b385: e8 76 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b38a: 42 c6 04 20 ff               	mov	byte ptr [rax + r12], -0x1
  64b38f: 49 ff c4                     	inc	r12
  64b392: 49 39 fc                     	cmp	r12, rdi
  64b395: 7c f3                        	jl	0x64b38a <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x86a>
  64b397: e9 49 f9 ff ff               	jmp	0x64ace5 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1c5>
  64b39c: 48 89 44 24 08               	mov	qword ptr [rsp + 0x8], rax
  64b3a1: e8 7a 34 e4 ff               	call	0x48e820 <runtime.morestack.abi0>
  64b3a6: 48 8b 44 24 08               	mov	rax, qword ptr [rsp + 0x8]
  64b3ab: e9 70 f7 ff ff               	jmp	0x64ab20 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1>
  64b3b0: cc                           	int3
  64b3b1: cc                           	int3
  64b3b2: cc                           	int3
  64b3b3: cc                           	int3
  64b3b4: cc                           	int3
  64b3b5: cc                           	int3
  64b3b6: cc                           	int3
  64b3b7: cc                           	int3
  64b3b8: cc                           	int3
  64b3b9: cc                           	int3
  64b3ba: cc                           	int3
  64b3bb: cc                           	int3
  64b3bc: cc                           	int3
  64b3bd: cc                           	int3
  64b3be: cc                           	int3
  64b3bf: cc                           	int3

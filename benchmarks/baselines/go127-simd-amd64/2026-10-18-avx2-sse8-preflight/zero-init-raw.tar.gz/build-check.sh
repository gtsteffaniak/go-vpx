#!/bin/sh
set -eu
export ROSETTA_ADVERTISE_AVX=1 CODEX_AGENT_ID=govpx-ci-sse8-zero CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GOEXPERIMENT=simd GOFLAGS=-p=2 GOMAXPROCS=1 GOAMD64=v1
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go
root=/Users/thesyncim/GolandProjects/govpx
base=/private/tmp/govpx-sse8-zero-accumulators-research
"$root/scripts/go.sh" -C "$base/vexzero" fmt ./internal/pixel > "$base/fmt.txt"
for v in parent vexzero; do
 out=$base/$v-logs
 mkdir -p "$out"
 GOOS=linux GOARCH=amd64 "$root/scripts/go.sh" -C "$base/$v" test -pgo=off -c -o "$out/pixel-linux.test" ./internal/pixel > "$out/build-linux.txt" 2>&1
 GOOS=linux GOARCH=amd64 "$root/scripts/go.sh" -C "$base/$v" test -pgo=off -c -o "$out/dsp-linux.test" ./internal/vp8/dsp > "$out/build-dsp-linux.txt" 2>&1
 /usr/bin/objdump --disassemble-symbols=github.com/thesyncim/govpx/internal/pixel.SSE8 --x86-asm-syntax=intel -d "$out/pixel-linux.test" > "$out/sse8-linux.asm"
 /usr/bin/objdump --disassemble-symbols=github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8,github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast,github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1 --x86-asm-syntax=intel -d "$out/dsp-linux.test" > "$out/callers-linux.asm"
 GOOS=darwin GOARCH=arm64 "$root/scripts/go.sh" -C "$base/$v" test -pgo=off -c -o "$out/pixel-arm.test" ./internal/pixel > "$out/build-arm.txt" 2>&1
 /usr/bin/objdump --disassemble-symbols=_github.com/thesyncim/govpx/internal/pixel.SSE8 -d "$out/pixel-arm.test" > "$out/sse8-arm.asm"
done
out=$base/vexzero-logs
GOOS=darwin GOARCH=amd64 "$root/scripts/go.sh" -C "$base/vexzero" test -pgo=off -gcflags=all=-d=checkptr=1 -c -o "$out/pixel-checkptr.test" ./internal/pixel > "$out/build-checkptr.txt" 2>&1
GOVPX_REQUIRE_SIMD=1 arch -x86_64 "$out/pixel-checkptr.test" -test.run '^Test(SquaredError|SSE)' -test.v -test.count=1 > "$out/rosetta-checkptr.txt" 2>&1
GODEBUG=cpu.avx=off,cpu.avx2=off arch -x86_64 "$out/pixel-checkptr.test" -test.run '^Test(SquaredError|SSE)' -test.v -test.count=1 > "$out/cpuoff.txt" 2>&1
GOVPX_REQUIRE_SIMD=1 "$out/pixel-arm.test" -test.run '^Test(SquaredError|SSE)' -test.count=1 > "$out/arm-tests.txt" 2>&1
"$root/scripts/go.sh" -C "$base/vexzero" test -pgo=off -tags purego ./internal/pixel ./internal/vp8/dsp -run '^Test(SquaredError|SSE|Variance)' -count=1 > "$out/purego-tests.txt" 2>&1
GOEXPERIMENT= "$root/scripts/go.sh" -C "$base/vexzero" test -pgo=off ./internal/pixel ./internal/vp8/dsp -run '^Test(SquaredError|SSE|Variance)' -count=1 > "$out/off-tests.txt" 2>&1

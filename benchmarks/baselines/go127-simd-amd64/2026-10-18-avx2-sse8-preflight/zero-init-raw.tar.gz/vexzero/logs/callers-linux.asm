
/private/tmp/govpx-sse8-zero-accumulators-research/vexzero-logs/dsp-linux.test:	file format elf64-x86-64

Disassembly of section .text:

00000000006412e0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8>:
  6412e0: 4c 8d a4 24 28 f8 ff ff      	lea	r12, [rsp - 0x7d8]
  6412e8: 4d 3b 66 10                  	cmp	r12, qword ptr [r14 + 0x10]
  6412ec: 0f 86 e0 00 00 00            	jbe	0x6413d2 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8+0xf2>
  6412f2: 55                           	push	rbp
  6412f3: 48 89 e5                     	mov	rbp, rsp
  6412f6: 48 81 ec 50 08 00 00         	sub	rsp, 0x850
  6412fd: 48 89 84 24 60 08 00 00      	mov	qword ptr [rsp + 0x860], rax
  641305: 48 8d 94 24 48 04 00 00      	lea	rdx, [rsp + 0x448]
  64130d: 41 bc 10 00 00 00            	mov	r12d, 0x10
  641313: 44 0f 11 3a                  	movups	xmmword ptr [rdx], xmm15
  641317: 44 0f 11 7a 10               	movups	xmmword ptr [rdx + 0x10], xmm15
  64131c: 44 0f 11 7a 20               	movups	xmmword ptr [rdx + 0x20], xmm15
  641321: 44 0f 11 7a 30               	movups	xmmword ptr [rdx + 0x30], xmm15
  641326: 48 83 c2 40                  	add	rdx, 0x40
  64132a: 41 ff cc                     	dec	r12d
  64132d: 75 e4                        	jne	0x641313 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8+0x33>
  64132f: 48 8d 74 24 48               	lea	rsi, [rsp + 0x48]
  641334: ba 10 00 00 00               	mov	edx, 0x10
  641339: 44 0f 11 3e                  	movups	xmmword ptr [rsi], xmm15
  64133d: 44 0f 11 7e 10               	movups	xmmword ptr [rsi + 0x10], xmm15
  641342: 44 0f 11 7e 20               	movups	xmmword ptr [rsi + 0x20], xmm15
  641347: 44 0f 11 7e 30               	movups	xmmword ptr [rsi + 0x30], xmm15
  64134c: 48 83 c6 40                  	add	rsi, 0x40
  641350: ff ca                        	dec	edx
  641352: 75 e5                        	jne	0x641339 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8+0x59>
  641354: 90                           	nop
  641355: c6 80 52 02 00 00 01         	mov	byte ptr [rax + 0x252], 0x1
  64135c: 48 c7 80 48 02 00 00 40 00 00 00     	mov	qword ptr [rax + 0x248], 0x40
  641367: 31 c9                        	xor	ecx, ecx
  641369: eb 55                        	jmp	0x6413c0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8+0xe0>
  64136b: 48 89 8c 24 48 08 00 00      	mov	qword ptr [rsp + 0x848], rcx
  641373: 90                           	nop
  641374: 48 8d 84 24 48 04 00 00      	lea	rax, [rsp + 0x448]
  64137c: bb 00 04 00 00               	mov	ebx, 0x400
  641381: 89 d9                        	mov	ecx, ebx
  641383: bf 20 00 00 00               	mov	edi, 0x20
  641388: 48 8d 74 24 48               	lea	rsi, [rsp + 0x48]
  64138d: 49 89 c8                     	mov	r8, rcx
  641390: 49 89 c9                     	mov	r9, rcx
  641393: 41 89 fa                     	mov	r10d, edi
  641396: 41 bb 08 00 00 00            	mov	r11d, 0x8
  64139c: 0f 1f 40 00                  	nop	dword ptr [rax]
  6413a0: e8 3b 3b fc ff               	call	0x604ee0 <github.com/thesyncim/govpx/internal/pixel.SSE8>
  6413a5: 48 8b 8c 24 48 08 00 00      	mov	rcx, qword ptr [rsp + 0x848]
  6413ad: 48 ff c1                     	inc	rcx
  6413b0: 48 8b 84 24 60 08 00 00      	mov	rax, qword ptr [rsp + 0x860]
  6413b8: 0f 1f 84 00 00 00 00 00      	nop	dword ptr [rax + rax]
  6413c0: 48 39 88 10 02 00 00         	cmp	qword ptr [rax + 0x210], rcx
  6413c7: 7f a2                        	jg	0x64136b <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8+0x8b>
  6413c9: 48 81 c4 50 08 00 00         	add	rsp, 0x850
  6413d0: 5d                           	pop	rbp
  6413d1: c3                           	ret
  6413d2: 48 89 44 24 08               	mov	qword ptr [rsp + 0x8], rax
  6413d7: e8 e4 d4 e4 ff               	call	0x48e8c0 <runtime.morestack_noctxt.abi0>
  6413dc: 48 8b 44 24 08               	mov	rax, qword ptr [rsp + 0x8]
  6413e1: e9 fa fe ff ff               	jmp	0x6412e0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8>
  6413e6: cc                           	int3
  6413e7: cc                           	int3
  6413e8: cc                           	int3
  6413e9: cc                           	int3
  6413ea: cc                           	int3
  6413eb: cc                           	int3
  6413ec: cc                           	int3
  6413ed: cc                           	int3
  6413ee: cc                           	int3
  6413ef: cc                           	int3
  6413f0: cc                           	int3
  6413f1: cc                           	int3
  6413f2: cc                           	int3
  6413f3: cc                           	int3
  6413f4: cc                           	int3
  6413f5: cc                           	int3
  6413f6: cc                           	int3
  6413f7: cc                           	int3
  6413f8: cc                           	int3
  6413f9: cc                           	int3
  6413fa: cc                           	int3
  6413fb: cc                           	int3
  6413fc: cc                           	int3
  6413fd: cc                           	int3
  6413fe: cc                           	int3
  6413ff: cc                           	int3

0000000000641400 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast>:
  641400: 4c 8d a4 24 50 f8 ff ff      	lea	r12, [rsp - 0x7b0]
  641408: 4d 3b 66 10                  	cmp	r12, qword ptr [r14 + 0x10]
  64140c: 0f 86 c0 00 00 00            	jbe	0x6414d2 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast+0xd2>
  641412: 55                           	push	rbp
  641413: 48 89 e5                     	mov	rbp, rsp
  641416: 48 81 ec 28 08 00 00         	sub	rsp, 0x828
  64141d: 48 89 84 24 38 08 00 00      	mov	qword ptr [rsp + 0x838], rax
  641425: 48 8d 94 24 20 04 00 00      	lea	rdx, [rsp + 0x420]
  64142d: be 10 00 00 00               	mov	esi, 0x10
  641432: 44 0f 11 3a                  	movups	xmmword ptr [rdx], xmm15
  641436: 44 0f 11 7a 10               	movups	xmmword ptr [rdx + 0x10], xmm15
  64143b: 44 0f 11 7a 20               	movups	xmmword ptr [rdx + 0x20], xmm15
  641440: 44 0f 11 7a 30               	movups	xmmword ptr [rdx + 0x30], xmm15
  641445: 48 83 c2 40                  	add	rdx, 0x40
  641449: ff ce                        	dec	esi
  64144b: 75 e5                        	jne	0x641432 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast+0x32>
  64144d: 48 8d 4c 24 20               	lea	rcx, [rsp + 0x20]
  641452: ba 10 00 00 00               	mov	edx, 0x10
  641457: 44 0f 11 39                  	movups	xmmword ptr [rcx], xmm15
  64145b: 44 0f 11 79 10               	movups	xmmword ptr [rcx + 0x10], xmm15
  641460: 44 0f 11 79 20               	movups	xmmword ptr [rcx + 0x20], xmm15
  641465: 44 0f 11 79 30               	movups	xmmword ptr [rcx + 0x30], xmm15
  64146a: 48 83 c1 40                  	add	rcx, 0x40
  64146e: ff ca                        	dec	edx
  641470: 75 e5                        	jne	0x641457 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast+0x57>
  641472: 90                           	nop
  641473: c6 80 52 02 00 00 01         	mov	byte ptr [rax + 0x252], 0x1
  64147a: 48 c7 80 48 02 00 00 40 00 00 00     	mov	qword ptr [rax + 0x248], 0x40
  641485: 31 c9                        	xor	ecx, ecx
  641487: eb 37                        	jmp	0x6414c0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast+0xc0>
  641489: 48 89 8c 24 20 08 00 00      	mov	qword ptr [rsp + 0x820], rcx
  641491: 48 8d 84 24 20 04 00 00      	lea	rax, [rsp + 0x420]
  641499: bb 20 00 00 00               	mov	ebx, 0x20
  64149e: 48 8d 4c 24 20               	lea	rcx, [rsp + 0x20]
  6414a3: 89 df                        	mov	edi, ebx
  6414a5: e8 b6 1a fd ff               	call	0x612f60 <github.com/thesyncim/govpx/internal/vp8/dsp.SSE8x8PtrFast>
  6414aa: 48 8b 8c 24 20 08 00 00      	mov	rcx, qword ptr [rsp + 0x820]
  6414b2: 48 ff c1                     	inc	rcx
  6414b5: 48 8b 84 24 38 08 00 00      	mov	rax, qword ptr [rsp + 0x838]
  6414bd: 0f 1f 00                     	nop	dword ptr [rax]
  6414c0: 48 39 88 10 02 00 00         	cmp	qword ptr [rax + 0x210], rcx
  6414c7: 7f c0                        	jg	0x641489 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast+0x89>
  6414c9: 48 81 c4 28 08 00 00         	add	rsp, 0x828
  6414d0: 5d                           	pop	rbp
  6414d1: c3                           	ret
  6414d2: 48 89 44 24 08               	mov	qword ptr [rsp + 0x8], rax
  6414d7: e8 e4 d3 e4 ff               	call	0x48e8c0 <runtime.morestack_noctxt.abi0>
  6414dc: 48 8b 44 24 08               	mov	rax, qword ptr [rsp + 0x8]
  6414e1: e9 1a ff ff ff               	jmp	0x641400 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8x8PtrFast>
  6414e6: cc                           	int3
  6414e7: cc                           	int3
  6414e8: cc                           	int3
  6414e9: cc                           	int3
  6414ea: cc                           	int3
  6414eb: cc                           	int3
  6414ec: cc                           	int3
  6414ed: cc                           	int3
  6414ee: cc                           	int3
  6414ef: cc                           	int3
  6414f0: cc                           	int3
  6414f1: cc                           	int3
  6414f2: cc                           	int3
  6414f3: cc                           	int3
  6414f4: cc                           	int3
  6414f5: cc                           	int3
  6414f6: cc                           	int3
  6414f7: cc                           	int3
  6414f8: cc                           	int3
  6414f9: cc                           	int3
  6414fa: cc                           	int3
  6414fb: cc                           	int3
  6414fc: cc                           	int3
  6414fd: cc                           	int3
  6414fe: cc                           	int3
  6414ff: cc                           	int3

000000000064ab40 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1>:
  64ab40: 4c 8d a4 24 48 ff ff ff      	lea	r12, [rsp - 0xb8]
  64ab48: 4d 3b 66 10                  	cmp	r12, qword ptr [r14 + 0x10]
  64ab4c: 0f 86 6a 08 00 00            	jbe	0x64b3bc <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x87c>
  64ab52: 55                           	push	rbp
  64ab53: 48 89 e5                     	mov	rbp, rsp
  64ab56: 48 81 ec 30 01 00 00         	sub	rsp, 0x130
  64ab5d: 48 89 84 24 40 01 00 00      	mov	qword ptr [rsp + 0x140], rax
  64ab65: 48 8b 72 10                  	mov	rsi, qword ptr [rdx + 0x10]
  64ab69: 48 89 b4 24 28 01 00 00      	mov	qword ptr [rsp + 0x128], rsi
  64ab71: 48 8b 7a 08                  	mov	rdi, qword ptr [rdx + 0x8]
  64ab75: 48 8b 0f                     	mov	rcx, qword ptr [rdi]
  64ab78: 48 89 4c 24 60               	mov	qword ptr [rsp + 0x60], rcx
  64ab7d: 48 8b 7f 08                  	mov	rdi, qword ptr [rdi + 0x8]
  64ab81: 48 89 7c 24 70               	mov	qword ptr [rsp + 0x70], rdi
  64ab86: 48 8b 5e 10                  	mov	rbx, qword ptr [rsi + 0x10]
  64ab8a: 48 ff cb                     	dec	rbx
  64ab8d: 48 89 de                     	mov	rsi, rbx
  64ab90: 48 0f af ce                  	imul	rcx, rsi
  64ab94: 48 89 8c 24 b8 00 00 00      	mov	qword ptr [rsp + 0xb8], rcx
  64ab9c: 48 0f af df                  	imul	rbx, rdi
  64aba0: 48 89 9c 24 b0 00 00 00      	mov	qword ptr [rsp + 0xb0], rbx
  64aba8: 48 8d 73 1e                  	lea	rsi, [rbx + 0x1e]
  64abac: 48 89 74 24 78               	mov	qword ptr [rsp + 0x78], rsi
  64abb1: 48 8b 52 18                  	mov	rdx, qword ptr [rdx + 0x18]
  64abb5: 48 89 94 24 90 00 00 00      	mov	qword ptr [rsp + 0x90], rdx
  64abbd: 48 83 c1 18                  	add	rcx, 0x18
  64abc1: 48 89 4c 24 68               	mov	qword ptr [rsp + 0x68], rcx
  64abc6: 48 8d 05 8b b9 25 00         	lea	rax, [rip + 0x25b98b]   # 0x8a6558 <type:*+0x36170>
  64abcd: 48 89 cb                     	mov	rbx, rcx
  64abd0: e8 4b 0a e4 ff               	call	0x48b620 <runtime.makeslice>
  64abd5: 48 89 84 24 20 01 00 00      	mov	qword ptr [rsp + 0x120], rax
  64abdd: 48 8d 05 74 b9 25 00         	lea	rax, [rip + 0x25b974]   # 0x8a6558 <type:*+0x36170>
  64abe4: 48 8b 5c 24 78               	mov	rbx, qword ptr [rsp + 0x78]
  64abe9: 48 89 d9                     	mov	rcx, rbx
  64abec: e8 2f 0a e4 ff               	call	0x48b620 <runtime.makeslice>
  64abf1: 31 d2                        	xor	edx, edx
  64abf3: 48 8b 74 24 68               	mov	rsi, qword ptr [rsp + 0x68]
  64abf8: 48 8b bc 24 20 01 00 00      	mov	rdi, qword ptr [rsp + 0x120]
  64ac00: eb 32                        	jmp	0x64ac34 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0xf4>
  64ac02: 4c 8d 1c d2                  	lea	r11, [rdx + 8*rdx]
  64ac06: 4e 8d 1c 9a                  	lea	r11, [rdx + 4*r11]
  64ac0a: 48 89 c1                     	mov	rcx, rax
  64ac0d: 48 b8 8c 2e ba e8 a2 8b 2e ba	movabs	rax, -0x45d1745d1745d174
  64ac17: 48 89 d3                     	mov	rbx, rdx
  64ac1a: 48 f7 e2                     	mul	rdx
  64ac1d: 48 c1 ea 03                  	shr	rdx, 0x3
  64ac21: 4e 8d 1c 1a                  	lea	r11, [rdx + r11]
  64ac25: 4d 8d 5b 13                  	lea	r11, [r11 + 0x13]
  64ac29: 44 88 1c 1f                  	mov	byte ptr [rdi + rbx], r11b
  64ac2d: 48 8d 53 01                  	lea	rdx, [rbx + 0x1]
  64ac31: 48 89 c8                     	mov	rax, rcx
  64ac34: 48 39 d6                     	cmp	rsi, rdx
  64ac37: 7f c9                        	jg	0x64ac02 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0xc2>
  64ac39: 45 31 db                     	xor	r11d, r11d
  64ac3c: 48 89 f9                     	mov	rcx, rdi
  64ac3f: 48 8b 7c 24 78               	mov	rdi, qword ptr [rsp + 0x78]
  64ac44: eb 2e                        	jmp	0x64ac74 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x134>
  64ac46: 4d 6b e3 47                  	imul	r12, r11, 0x47
  64ac4a: 48 89 c2                     	mov	rdx, rax
  64ac4d: 48 b8 4a 92 24 49 92 24 49 92	movabs	rax, -0x6db6db6db6db6db6
  64ac57: 48 89 d3                     	mov	rbx, rdx
  64ac5a: 49 f7 e3                     	mul	r11
  64ac5d: 48 c1 ea 02                  	shr	rdx, 0x2
  64ac61: 4e 8d 24 22                  	lea	r12, [rdx + r12]
  64ac65: 4d 8d 64 24 1f               	lea	r12, [r12 + 0x1f]
  64ac6a: 46 88 24 1b                  	mov	byte ptr [rbx + r11], r12b
  64ac6e: 49 ff c3                     	inc	r11
  64ac71: 48 89 d8                     	mov	rax, rbx
  64ac74: 49 39 fb                     	cmp	r11, rdi
  64ac77: 7c cd                        	jl	0x64ac46 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x106>
  64ac79: 48 89 84 24 18 01 00 00      	mov	qword ptr [rsp + 0x118], rax
  64ac81: 4c 8b 9c 24 90 00 00 00      	mov	r11, qword ptr [rsp + 0x90]
  64ac89: 49 83 fb 01                  	cmp	r11, 0x1
  64ac8d: 75 51                        	jne	0x64ace0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1a0>
  64ac8f: 48 8b 9c 24 b8 00 00 00      	mov	rbx, qword ptr [rsp + 0xb8]
  64ac97: 49 89 db                     	mov	r11, rbx
  64ac9a: 66 0f 1f 44 00 00            	nop	word ptr [rax + rax]
  64aca0: 48 83 c3 18                  	add	rbx, 0x18
  64aca4: 74 2d                        	je	0x64acd3 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x193>
  64aca6: 48 89 c8                     	mov	rax, rcx
  64aca9: 48 89 f3                     	mov	rbx, rsi
  64acac: e8 ef 58 e4 ff               	call	0x4905a0 <runtime.memclrNoHeapPointers>
  64acb1: 48 8b 84 24 18 01 00 00      	mov	rax, qword ptr [rsp + 0x118]
  64acb9: 48 8b 8c 24 20 01 00 00      	mov	rcx, qword ptr [rsp + 0x120]
  64acc1: 48 8b 74 24 68               	mov	rsi, qword ptr [rsp + 0x68]
  64acc6: 48 8b 7c 24 78               	mov	rdi, qword ptr [rsp + 0x78]
  64accb: 4c 8b 9c 24 b8 00 00 00      	mov	r11, qword ptr [rsp + 0xb8]
  64acd3: 45 31 e4                     	xor	r12d, r12d
  64acd6: e9 d7 06 00 00               	jmp	0x64b3b2 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x872>
  64acdb: 0f 1f 44 00 00               	nop	dword ptr [rax + rax]
  64ace0: 49 83 fb 02                  	cmp	r11, 0x2
  64ace4: 75 1f                        	jne	0x64ad05 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1c5>
  64ace6: 4c 8b 9c 24 28 01 00 00      	mov	r11, qword ptr [rsp + 0x128]
  64acee: 4d 8b 63 10                  	mov	r12, qword ptr [r11 + 0x10]
  64acf2: 45 31 ed                     	xor	r13d, r13d
  64acf5: 4c 8b 54 24 70               	mov	r10, qword ptr [rsp + 0x70]
  64acfa: 48 8b 5c 24 60               	mov	rbx, qword ptr [rsp + 0x60]
  64acff: 90                           	nop
  64ad00: e9 31 06 00 00               	jmp	0x64b336 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7f6>
  64ad05: 48 8b 9c 24 b8 00 00 00      	mov	rbx, qword ptr [rsp + 0xb8]
  64ad0d: 4c 8d 5b 0b                  	lea	r11, [rbx + 0xb]
  64ad11: 4c 39 de                     	cmp	rsi, r11
  64ad14: 0f 82 0b 06 00 00            	jb	0x64b325 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7e5>
  64ad1a: 66 0f 1f 44 00 00            	nop	word ptr [rax + rax]
  64ad20: 49 83 fb 03                  	cmp	r11, 0x3
  64ad24: 0f 82 f4 05 00 00            	jb	0x64b31e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7de>
  64ad2a: 4c 8d 5b 15                  	lea	r11, [rbx + 0x15]
  64ad2e: 4d 89 dc                     	mov	r12, r11
  64ad31: 49 f7 db                     	neg	r11
  64ad34: 49 c1 fb 3f                  	sar	r11, 0x3f
  64ad38: 41 83 e3 03                  	and	r11d, 0x3
  64ad3c: 4c 8b 8c 24 b0 00 00 00      	mov	r9, qword ptr [rsp + 0xb0]
  64ad44: 4d 8d 69 0d                  	lea	r13, [r9 + 0xd]
  64ad48: 49 01 cb                     	add	r11, rcx
  64ad4b: 49 39 fd                     	cmp	r13, rdi
  64ad4e: 0f 87 c5 05 00 00            	ja	0x64b319 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7d9>
  64ad54: 49 83 fd 05                  	cmp	r13, 0x5
  64ad58: 0f 82 b6 05 00 00            	jb	0x64b314 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7d4>
  64ad5e: 4c 89 a4 24 a8 00 00 00      	mov	qword ptr [rsp + 0xa8], r12
  64ad66: 4c 89 9c 24 e0 00 00 00      	mov	qword ptr [rsp + 0xe0], r11
  64ad6e: 4d 8d 69 19                  	lea	r13, [r9 + 0x19]
  64ad72: 4c 89 ac 24 88 00 00 00      	mov	qword ptr [rsp + 0x88], r13
  64ad7a: 4d 89 ef                     	mov	r15, r13
  64ad7d: 49 f7 dd                     	neg	r13
  64ad80: 49 c1 fd 3f                  	sar	r13, 0x3f
  64ad84: 41 83 e5 05                  	and	r13d, 0x5
  64ad88: 49 01 c5                     	add	r13, rax
  64ad8b: 4c 89 ac 24 d0 00 00 00      	mov	qword ptr [rsp + 0xd0], r13
  64ad93: 48 85 c9                     	test	rcx, rcx
  64ad96: 75 0d                        	jne	0x64ada5 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x265>
  64ad98: 31 d2                        	xor	edx, edx
  64ad9a: 45 31 c0                     	xor	r8d, r8d
  64ad9d: 0f 1f 00                     	nop	dword ptr [rax]
  64ada0: e9 8f 00 00 00               	jmp	0x64ae34 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x2f4>
  64ada5: 48 8d 44 24 40               	lea	rax, [rsp + 0x40]
  64adaa: 48 89 f3                     	mov	rbx, rsi
  64adad: 31 c9                        	xor	ecx, ecx
  64adaf: 48 89 df                     	mov	rdi, rbx
  64adb2: 48 8d 35 9f b7 25 00         	lea	rsi, [rip + 0x25b79f]   # 0x8a6558 <type:*+0x36170>
  64adb9: e8 42 09 e4 ff               	call	0x48b700 <runtime.growslice>
  64adbe: 48 89 84 24 c8 00 00 00      	mov	qword ptr [rsp + 0xc8], rax
  64adc6: 48 89 5c 24 48               	mov	qword ptr [rsp + 0x48], rbx
  64adcb: 48 8b 9c 24 20 01 00 00      	mov	rbx, qword ptr [rsp + 0x120]
  64add3: 48 8b 4c 24 68               	mov	rcx, qword ptr [rsp + 0x68]
  64add8: e8 c3 5a e4 ff               	call	0x4908a0 <runtime.memmove>
  64addd: 48 8b 84 24 18 01 00 00      	mov	rax, qword ptr [rsp + 0x118]
  64ade5: 48 8b 8c 24 20 01 00 00      	mov	rcx, qword ptr [rsp + 0x120]
  64aded: 48 8b 9c 24 b8 00 00 00      	mov	rbx, qword ptr [rsp + 0xb8]
  64adf5: 48 8b 74 24 68               	mov	rsi, qword ptr [rsp + 0x68]
  64adfa: 48 8b 7c 24 78               	mov	rdi, qword ptr [rsp + 0x78]
  64adff: 4c 8b 8c 24 b0 00 00 00      	mov	r9, qword ptr [rsp + 0xb0]
  64ae07: 4c 8b 9c 24 e0 00 00 00      	mov	r11, qword ptr [rsp + 0xe0]
  64ae0f: 4c 8b a4 24 a8 00 00 00      	mov	r12, qword ptr [rsp + 0xa8]
  64ae17: 4c 8b ac 24 d0 00 00 00      	mov	r13, qword ptr [rsp + 0xd0]
  64ae1f: 4c 8b bc 24 88 00 00 00      	mov	r15, qword ptr [rsp + 0x88]
  64ae27: 48 8b 54 24 48               	mov	rdx, qword ptr [rsp + 0x48]
  64ae2c: 4c 8b 84 24 c8 00 00 00      	mov	r8, qword ptr [rsp + 0xc8]
  64ae34: 48 89 54 24 48               	mov	qword ptr [rsp + 0x48], rdx
  64ae39: 4c 89 84 24 c8 00 00 00      	mov	qword ptr [rsp + 0xc8], r8
  64ae41: 48 85 c0                     	test	rax, rax
  64ae44: 75 13                        	jne	0x64ae59 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x319>
  64ae46: 45 31 d2                     	xor	r10d, r10d
  64ae49: 45 31 d2                     	xor	r10d, r10d
  64ae4c: 4c 89 94 24 c0 00 00 00      	mov	qword ptr [rsp + 0xc0], r10
  64ae54: 45 31 d2                     	xor	r10d, r10d
  64ae57: eb 74                        	jmp	0x64aecd <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x38d>
  64ae59: 48 8d 44 24 40               	lea	rax, [rsp + 0x40]
  64ae5e: 48 89 fb                     	mov	rbx, rdi
  64ae61: 31 c9                        	xor	ecx, ecx
  64ae63: 48 8d 35 ee b6 25 00         	lea	rsi, [rip + 0x25b6ee]   # 0x8a6558 <type:*+0x36170>
  64ae6a: e8 91 08 e4 ff               	call	0x48b700 <runtime.growslice>
  64ae6f: 48 89 84 24 c0 00 00 00      	mov	qword ptr [rsp + 0xc0], rax
  64ae77: 48 89 5c 24 40               	mov	qword ptr [rsp + 0x40], rbx
  64ae7c: 48 8b 9c 24 18 01 00 00      	mov	rbx, qword ptr [rsp + 0x118]
  64ae84: 48 8b 4c 24 78               	mov	rcx, qword ptr [rsp + 0x78]
  64ae89: e8 12 5a e4 ff               	call	0x4908a0 <runtime.memmove>
  64ae8e: 48 8b 8c 24 20 01 00 00      	mov	rcx, qword ptr [rsp + 0x120]
  64ae96: 48 8b 54 24 48               	mov	rdx, qword ptr [rsp + 0x48]
  64ae9b: 48 8b 9c 24 b8 00 00 00      	mov	rbx, qword ptr [rsp + 0xb8]
  64aea3: 48 8b 74 24 68               	mov	rsi, qword ptr [rsp + 0x68]
  64aea8: 4c 8b 84 24 c8 00 00 00      	mov	r8, qword ptr [rsp + 0xc8]
  64aeb0: 4c 8b 8c 24 b0 00 00 00      	mov	r9, qword ptr [rsp + 0xb0]
  64aeb8: 4c 8b 9c 24 e0 00 00 00      	mov	r11, qword ptr [rsp + 0xe0]
  64aec0: 4c 8b ac 24 d0 00 00 00      	mov	r13, qword ptr [rsp + 0xd0]
  64aec8: 4c 8b 54 24 40               	mov	r10, qword ptr [rsp + 0x40]
  64aecd: 4c 89 54 24 40               	mov	qword ptr [rsp + 0x40], r10
  64aed2: 48 83 c3 08                  	add	rbx, 0x8
  64aed6: 49 83 c1 08                  	add	r9, 0x8
  64aeda: 4c 8b a4 24 28 01 00 00      	mov	r12, qword ptr [rsp + 0x128]
  64aee2: 49 8b 44 24 10               	mov	rax, qword ptr [r12 + 0x10]
  64aee7: 45 31 ff                     	xor	r15d, r15d
  64aeea: 45 31 e4                     	xor	r12d, r12d
  64aeed: 48 8b 7c 24 60               	mov	rdi, qword ptr [rsp + 0x60]
  64aef2: 4c 8b 54 24 70               	mov	r10, qword ptr [rsp + 0x70]
  64aef7: eb 1d                        	jmp	0x64af16 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x3d6>
  64aef9: 4c 8b 64 24 50               	mov	r12, qword ptr [rsp + 0x50]
  64aefe: 49 ff c4                     	inc	r12
  64af01: 48 8b 8c 24 20 01 00 00      	mov	rcx, qword ptr [rsp + 0x120]
  64af09: 48 8b 74 24 68               	mov	rsi, qword ptr [rsp + 0x68]
  64af0e: 4c 8b ac 24 d0 00 00 00      	mov	r13, qword ptr [rsp + 0xd0]
  64af16: 49 39 c4                     	cmp	r12, rax
  64af19: 7d 63                        	jge	0x64af7e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x43e>
  64af1b: 4c 89 64 24 50               	mov	qword ptr [rsp + 0x50], r12
  64af20: 4c 0f af e7                  	imul	r12, rdi
  64af24: 4c 8b 6c 24 50               	mov	r13, qword ptr [rsp + 0x50]
  64af29: 4d 0f af ea                  	imul	r13, r10
  64af2d: 31 c9                        	xor	ecx, ecx
  64af2f: 48 8b b4 24 d0 00 00 00      	mov	rsi, qword ptr [rsp + 0xd0]
  64af37: eb 1e                        	jmp	0x64af57 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x417>
  64af39: 0f b6 14 16                  	movzx	edx, byte ptr [rsi + rdx]
  64af3d: 49 29 d0                     	sub	r8, rdx
  64af40: 4d 0f af c0                  	imul	r8, r8
  64af44: 4d 01 c7                     	add	r15, r8
  64af47: 48 ff c1                     	inc	rcx
  64af4a: 48 8b 54 24 48               	mov	rdx, qword ptr [rsp + 0x48]
  64af4f: 4c 8b 84 24 c8 00 00 00      	mov	r8, qword ptr [rsp + 0xc8]
  64af57: 48 83 f9 08                  	cmp	rcx, 0x8
  64af5b: 7d 9c                        	jge	0x64aef9 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x3b9>
  64af5d: 4d 8d 04 0c                  	lea	r8, [r12 + rcx]
  64af61: 4c 39 c3                     	cmp	rbx, r8
  64af64: 0f 86 a5 03 00 00            	jbe	0x64b30f <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7cf>
  64af6a: 49 8d 54 0d 00               	lea	rdx, [r13 + rcx]
  64af6f: 47 0f b6 04 03               	movzx	r8d, byte ptr [r11 + r8]
  64af74: 49 39 d1                     	cmp	r9, rdx
  64af77: 77 c0                        	ja	0x64af39 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x3f9>
  64af79: e9 8c 03 00 00               	jmp	0x64b30a <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7ca>
  64af7e: 48 89 9c 24 a0 00 00 00      	mov	qword ptr [rsp + 0xa0], rbx
  64af86: 4c 89 8c 24 80 00 00 00      	mov	qword ptr [rsp + 0x80], r9
  64af8e: 4c 89 7c 24 58               	mov	qword ptr [rsp + 0x58], r15
  64af93: 48 c7 84 24 98 00 00 00 00 00 00 00  	mov	qword ptr [rsp + 0x98], 0x0
  64af9f: 4c 8b a4 24 28 01 00 00      	mov	r12, qword ptr [rsp + 0x128]
  64afa7: 41 80 7c 24 20 00            	cmp	byte ptr [r12 + 0x20], 0x0
  64afad: 74 35                        	je	0x64afe4 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x4a4>
  64afaf: 48 85 db                     	test	rbx, rbx
  64afb2: 0f 86 4d 03 00 00            	jbe	0x64b305 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7c5>
  64afb8: 0f 1f 84 00 00 00 00 00      	nop	dword ptr [rax + rax]
  64afc0: 4d 85 c9                     	test	r9, r9
  64afc3: 0f 86 33 03 00 00            	jbe	0x64b2fc <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7bc>
  64afc9: 4c 89 d8                     	mov	rax, r11
  64afcc: 48 89 fb                     	mov	rbx, rdi
  64afcf: 4c 89 e9                     	mov	rcx, r13
  64afd2: 4c 89 d7                     	mov	rdi, r10
  64afd5: e8 86 7f fc ff               	call	0x612f60 <github.com/thesyncim/govpx/internal/vp8/dsp.SSE8x8PtrFast>
  64afda: 48 89 84 24 98 00 00 00      	mov	qword ptr [rsp + 0x98], rax
  64afe2: eb 2c                        	jmp	0x64b010 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x4d0>
  64afe4: 49 8b 54 24 18               	mov	rdx, qword ptr [r12 + 0x18]
  64afe9: 4c 8b 22                     	mov	r12, qword ptr [rdx]
  64afec: 4c 89 d8                     	mov	rax, r11
  64afef: 48 8b 8c 24 a8 00 00 00      	mov	rcx, qword ptr [rsp + 0xa8]
  64aff7: 4c 89 ee                     	mov	rsi, r13
  64affa: 4d 89 c8                     	mov	r8, r9
  64affd: 4c 8b 8c 24 88 00 00 00      	mov	r9, qword ptr [rsp + 0x88]
  64b005: 41 ff d4                     	call	r12
  64b008: 48 89 84 24 98 00 00 00      	mov	qword ptr [rsp + 0x98], rax
  64b010: 48 8b 84 24 98 00 00 00      	mov	rax, qword ptr [rsp + 0x98]
  64b018: 48 8b 4c 24 58               	mov	rcx, qword ptr [rsp + 0x58]
  64b01d: 0f 1f 00                     	nop	dword ptr [rax]
  64b020: 48 39 c1                     	cmp	rcx, rax
  64b023: 74 79                        	je	0x64b09e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x55e>
  64b025: 48 8d 8c 24 f8 00 00 00      	lea	rcx, [rsp + 0xf8]
  64b02d: 44 0f 11 39                  	movups	xmmword ptr [rcx], xmm15
  64b031: 44 0f 11 79 10               	movups	xmmword ptr [rcx + 0x10], xmm15
  64b036: e8 25 c6 e3 ff               	call	0x487660 <runtime.convT64>
  64b03b: 48 8d 0d d6 b6 25 00         	lea	rcx, [rip + 0x25b6d6]   # 0x8a6718 <type:*+0x36330>
  64b042: 48 89 8c 24 f8 00 00 00      	mov	qword ptr [rsp + 0xf8], rcx
  64b04a: 48 89 84 24 00 01 00 00      	mov	qword ptr [rsp + 0x100], rax
  64b052: 48 8b 44 24 58               	mov	rax, qword ptr [rsp + 0x58]
  64b057: e8 04 c6 e3 ff               	call	0x487660 <runtime.convT64>
  64b05c: 48 8d 0d b5 b6 25 00         	lea	rcx, [rip + 0x25b6b5]   # 0x8a6718 <type:*+0x36330>
  64b063: 48 89 8c 24 08 01 00 00      	mov	qword ptr [rsp + 0x108], rcx
  64b06b: 48 89 84 24 10 01 00 00      	mov	qword ptr [rsp + 0x110], rax
  64b073: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b07b: 84 00                        	test	byte ptr [rax], al
  64b07d: 48 8d 1d 91 f4 01 00         	lea	rbx, [rip + 0x1f491]    # 0x66a515 <runtime.rodata+0x7515>
  64b084: b9 18 00 00 00               	mov	ecx, 0x18
  64b089: 48 8d bc 24 f8 00 00 00      	lea	rdi, [rsp + 0xf8]
  64b091: be 02 00 00 00               	mov	esi, 0x2
  64b096: 41 89 f0                     	mov	r8d, esi
  64b099: e8 a2 ad ec ff               	call	0x515e40 <testing.(*common).Fatalf>
  64b09e: 90                           	nop
  64b09f: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b0a7: c6 80 52 02 00 00 01         	mov	byte ptr [rax + 0x252], 0x1
  64b0ae: e8 8d e5 eb ff               	call	0x509640 <testing.(*B).ResetTimer>
  64b0b3: 48 8b 8c 24 28 01 00 00      	mov	rcx, qword ptr [rsp + 0x128]
  64b0bb: 80 79 20 00                  	cmp	byte ptr [rcx + 0x20], 0x0
  64b0bf: 90                           	nop
  64b0c0: 74 2c                        	je	0x64b0ee <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x5ae>
  64b0c2: 48 8b b4 24 a0 00 00 00      	mov	rsi, qword ptr [rsp + 0xa0]
  64b0ca: 48 85 f6                     	test	rsi, rsi
  64b0cd: 0f 86 24 02 00 00            	jbe	0x64b2f7 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7b7>
  64b0d3: 48 8b b4 24 80 00 00 00      	mov	rsi, qword ptr [rsp + 0x80]
  64b0db: 0f 1f 44 00 00               	nop	dword ptr [rax + rax]
  64b0e0: 48 85 f6                     	test	rsi, rsi
  64b0e3: 0f 87 c1 01 00 00            	ja	0x64b2aa <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x76a>
  64b0e9: e9 04 02 00 00               	jmp	0x64b2f2 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7b2>
  64b0ee: 48 8b 51 18                  	mov	rdx, qword ptr [rcx + 0x18]
  64b0f2: 48 89 94 24 d8 00 00 00      	mov	qword ptr [rsp + 0xd8], rdx
  64b0fa: eb 50                        	jmp	0x64b14c <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x60c>
  64b0fc: 4c 8b 1a                     	mov	r11, qword ptr [rdx]
  64b0ff: 48 8b 84 24 e0 00 00 00      	mov	rax, qword ptr [rsp + 0xe0]
  64b107: 48 8b 9c 24 a0 00 00 00      	mov	rbx, qword ptr [rsp + 0xa0]
  64b10f: 48 8b 8c 24 a8 00 00 00      	mov	rcx, qword ptr [rsp + 0xa8]
  64b117: 48 8b 7c 24 60               	mov	rdi, qword ptr [rsp + 0x60]
  64b11c: 48 8b b4 24 d0 00 00 00      	mov	rsi, qword ptr [rsp + 0xd0]
  64b124: 4c 8b 84 24 80 00 00 00      	mov	r8, qword ptr [rsp + 0x80]
  64b12c: 4c 8b 8c 24 88 00 00 00      	mov	r9, qword ptr [rsp + 0x88]
  64b134: 4c 8b 54 24 70               	mov	r10, qword ptr [rsp + 0x70]
  64b139: 41 ff d3                     	call	r11
  64b13c: 48 89 84 24 98 00 00 00      	mov	qword ptr [rsp + 0x98], rax
  64b144: 48 8b 94 24 d8 00 00 00      	mov	rdx, qword ptr [rsp + 0xd8]
  64b14c: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b154: 4c 8b 98 c0 02 00 00         	mov	r11, qword ptr [rax + 0x2c0]
  64b15b: 0f 1f 44 00 00               	nop	dword ptr [rax + rax]
  64b160: 4c 39 98 b8 02 00 00         	cmp	qword ptr [rax + 0x2b8], r11
  64b167: 76 11                        	jbe	0x64b17a <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x63a>
  64b169: 49 ff c3                     	inc	r11
  64b16c: 4c 89 98 c0 02 00 00         	mov	qword ptr [rax + 0x2c0], r11
  64b173: b9 01 00 00 00               	mov	ecx, 0x1
  64b178: eb 17                        	jmp	0x64b191 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x651>
  64b17a: e8 41 f2 eb ff               	call	0x50a3c0 <testing.(*B).loopSlowPath>
  64b17f: 48 8b 94 24 d8 00 00 00      	mov	rdx, qword ptr [rsp + 0xd8]
  64b187: 89 c1                        	mov	ecx, eax
  64b189: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b191: 84 c9                        	test	cl, cl
  64b193: 0f 85 63 ff ff ff            	jne	0x64b0fc <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x5bc>
  64b199: 48 8b 54 24 58               	mov	rdx, qword ptr [rsp + 0x58]
  64b19e: 66 90                        	nop
  64b1a0: 48 39 94 24 98 00 00 00      	cmp	qword ptr [rsp + 0x98], rdx
  64b1a8: 74 07                        	je	0x64b1b1 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x671>
  64b1aa: b9 01 00 00 00               	mov	ecx, 0x1
  64b1af: eb 77                        	jmp	0x64b228 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6e8>
  64b1b1: 48 8b 4c 24 68               	mov	rcx, qword ptr [rsp + 0x68]
  64b1b6: 48 8b 54 24 48               	mov	rdx, qword ptr [rsp + 0x48]
  64b1bb: 0f 1f 44 00 00               	nop	dword ptr [rax + rax]
  64b1c0: 48 39 d1                     	cmp	rcx, rdx
  64b1c3: 74 04                        	je	0x64b1c9 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x689>
  64b1c5: 31 c9                        	xor	ecx, ecx
  64b1c7: eb 1f                        	jmp	0x64b1e8 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6a8>
  64b1c9: 48 8b 84 24 20 01 00 00      	mov	rax, qword ptr [rsp + 0x120]
  64b1d1: 48 8b 9c 24 c8 00 00 00      	mov	rbx, qword ptr [rsp + 0xc8]
  64b1d9: e8 82 7a db ff               	call	0x402c60 <runtime.memequal>
  64b1de: 89 c1                        	mov	ecx, eax
  64b1e0: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b1e8: 84 c9                        	test	cl, cl
  64b1ea: 74 37                        	je	0x64b223 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6e3>
  64b1ec: 48 8b 54 24 40               	mov	rdx, qword ptr [rsp + 0x40]
  64b1f1: 48 8b 4c 24 78               	mov	rcx, qword ptr [rsp + 0x78]
  64b1f6: 48 39 ca                     	cmp	rdx, rcx
  64b1f9: 74 04                        	je	0x64b1ff <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6bf>
  64b1fb: 31 c9                        	xor	ecx, ecx
  64b1fd: eb 1f                        	jmp	0x64b21e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6de>
  64b1ff: 48 8b 84 24 18 01 00 00      	mov	rax, qword ptr [rsp + 0x118]
  64b207: 48 8b 9c 24 c0 00 00 00      	mov	rbx, qword ptr [rsp + 0xc0]
  64b20f: e8 4c 7a db ff               	call	0x402c60 <runtime.memequal>
  64b214: 89 c1                        	mov	ecx, eax
  64b216: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b21e: 83 f1 01                     	xor	ecx, 0x1
  64b221: eb 05                        	jmp	0x64b228 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6e8>
  64b223: b9 01 00 00 00               	mov	ecx, 0x1
  64b228: 84 c9                        	test	cl, cl
  64b22a: 74 32                        	je	0x64b25e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x71e>
  64b22c: 48 8d 15 a5 b2 25 00         	lea	rdx, [rip + 0x25b2a5]   # 0x8a64d8 <type:*+0x360f0>
  64b233: 48 89 94 24 e8 00 00 00      	mov	qword ptr [rsp + 0xe8], rdx
  64b23b: 48 8d 15 0e 0a 03 00         	lea	rdx, [rip + 0x30a0e]    # 0x67bc50 <internal/sync..dict.indirect[interface {},interface {}]+0x120>
  64b242: 48 89 94 24 f0 00 00 00      	mov	qword ptr [rsp + 0xf0], rdx
  64b24a: 48 8d 9c 24 e8 00 00 00      	lea	rbx, [rsp + 0xe8]
  64b252: b9 01 00 00 00               	mov	ecx, 0x1
  64b257: 89 cf                        	mov	edi, ecx
  64b259: e8 e2 aa ec ff               	call	0x515d40 <testing.(*common).Fatal>
  64b25e: 48 8b 84 24 98 00 00 00      	mov	rax, qword ptr [rsp + 0x98]
  64b266: 48 89 05 f3 39 2d 00         	mov	qword ptr [rip + 0x2d39f3], rax # 0x91ec60 <github.com/thesyncim/govpx/internal/vp8/dsp.sse8RowsNativeSink>
  64b26d: 48 81 c4 30 01 00 00         	add	rsp, 0x130
  64b274: 5d                           	pop	rbp
  64b275: c3                           	ret
  64b276: 48 8b 35 5b a5 28 00         	mov	rsi, qword ptr [rip + 0x28a55b] # 0x8d57d8 <go:funcdesc+0x9e0>
  64b27d: 48 8b 84 24 e0 00 00 00      	mov	rax, qword ptr [rsp + 0xe0]
  64b285: 48 8b 5c 24 60               	mov	rbx, qword ptr [rsp + 0x60]
  64b28a: 48 8b 8c 24 d0 00 00 00      	mov	rcx, qword ptr [rsp + 0xd0]
  64b292: 48 8b 7c 24 70               	mov	rdi, qword ptr [rsp + 0x70]
  64b297: 48 8d 15 3a a5 28 00         	lea	rdx, [rip + 0x28a53a]   # 0x8d57d8 <go:funcdesc+0x9e0>
  64b29e: 66 90                        	nop
  64b2a0: ff d6                        	call	rsi
  64b2a2: 48 89 84 24 98 00 00 00      	mov	qword ptr [rsp + 0x98], rax
  64b2aa: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b2b2: 48 8b b0 c0 02 00 00         	mov	rsi, qword ptr [rax + 0x2c0]
  64b2b9: 0f 1f 80 00 00 00 00         	nop	dword ptr [rax]
  64b2c0: 48 39 b0 b8 02 00 00         	cmp	qword ptr [rax + 0x2b8], rsi
  64b2c7: 76 11                        	jbe	0x64b2da <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x79a>
  64b2c9: 48 ff c6                     	inc	rsi
  64b2cc: 48 89 b0 c0 02 00 00         	mov	qword ptr [rax + 0x2c0], rsi
  64b2d3: b9 01 00 00 00               	mov	ecx, 0x1
  64b2d8: eb 0f                        	jmp	0x64b2e9 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7a9>
  64b2da: e8 e1 f0 eb ff               	call	0x50a3c0 <testing.(*B).loopSlowPath>
  64b2df: 89 c1                        	mov	ecx, eax
  64b2e1: 48 8b 84 24 40 01 00 00      	mov	rax, qword ptr [rsp + 0x140]
  64b2e9: 84 c9                        	test	cl, cl
  64b2eb: 75 89                        	jne	0x64b276 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x736>
  64b2ed: e9 a7 fe ff ff               	jmp	0x64b199 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x659>
  64b2f2: e8 09 52 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b2f7: e8 04 52 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b2fc: 0f 1f 40 00                  	nop	dword ptr [rax]
  64b300: e8 fb 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b305: e8 f6 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b30a: e8 f1 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b30f: e8 ec 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b314: e8 e7 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b319: e8 e2 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b31e: 66 90                        	nop
  64b320: e8 db 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b325: e8 d6 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b32a: 4c 8d 6a 01                  	lea	r13, [rdx + 0x1]
  64b32e: 4c 8b 9c 24 28 01 00 00      	mov	r11, qword ptr [rsp + 0x128]
  64b336: 4d 39 e5                     	cmp	r13, r12
  64b339: 0f 8d c6 f9 ff ff            	jge	0x64ad05 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1c5>
  64b33f: 4d 89 ef                     	mov	r15, r13
  64b342: 4d 0f af ea                  	imul	r13, r10
  64b346: 49 8d 55 0d                  	lea	rdx, [r13 + 0xd]
  64b34a: 48 39 fa                     	cmp	rdx, rdi
  64b34d: 77 56                        	ja	0x64b3a5 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x865>
  64b34f: 4d 8d 45 05                  	lea	r8, [r13 + 0x5]
  64b353: 4c 39 c2                     	cmp	rdx, r8
  64b356: 72 45                        	jb	0x64b39d <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x85d>
  64b358: 4c 89 fa                     	mov	rdx, r15
  64b35b: 4c 0f af fb                  	imul	r15, rbx
  64b35f: 4d 8d 47 0b                  	lea	r8, [r15 + 0xb]
  64b363: 4d 8d 4c 05 00               	lea	r9, [r13 + rax]
  64b368: 4d 8d 49 05                  	lea	r9, [r9 + 0x5]
  64b36c: 4c 39 c6                     	cmp	rsi, r8
  64b36f: 72 27                        	jb	0x64b398 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x858>
  64b371: 4d 8d 5f 03                  	lea	r11, [r15 + 0x3]
  64b375: 4d 39 d8                     	cmp	r8, r11
  64b378: 72 19                        	jb	0x64b393 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x853>
  64b37a: 4d 8d 1c 0f                  	lea	r11, [r15 + rcx]
  64b37e: 4d 8d 5b 03                  	lea	r11, [r11 + 0x3]
  64b382: 4d 39 d9                     	cmp	r9, r11
  64b385: 74 a3                        	je	0x64b32a <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7ea>
  64b387: 4d 8b 5c 0f 03               	mov	r11, qword ptr [r15 + rcx + 0x3]
  64b38c: 4d 89 5c 05 05               	mov	qword ptr [r13 + rax + 0x5], r11
  64b391: eb 97                        	jmp	0x64b32a <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7ea>
  64b393: e8 68 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b398: e8 63 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b39d: 0f 1f 00                     	nop	dword ptr [rax]
  64b3a0: e8 5b 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b3a5: e8 56 51 e4 ff               	call	0x490500 <runtime.panicBounds>
  64b3aa: 42 c6 04 20 ff               	mov	byte ptr [rax + r12], -0x1
  64b3af: 49 ff c4                     	inc	r12
  64b3b2: 49 39 fc                     	cmp	r12, rdi
  64b3b5: 7c f3                        	jl	0x64b3aa <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x86a>
  64b3b7: e9 49 f9 ff ff               	jmp	0x64ad05 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1c5>
  64b3bc: 48 89 44 24 08               	mov	qword ptr [rsp + 0x8], rax
  64b3c1: e8 5a 34 e4 ff               	call	0x48e820 <runtime.morestack.abi0>
  64b3c6: 48 8b 44 24 08               	mov	rax, qword ptr [rsp + 0x8]
  64b3cb: e9 70 f7 ff ff               	jmp	0x64ab40 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1>
  64b3d0: cc                           	int3
  64b3d1: cc                           	int3
  64b3d2: cc                           	int3
  64b3d3: cc                           	int3
  64b3d4: cc                           	int3
  64b3d5: cc                           	int3
  64b3d6: cc                           	int3
  64b3d7: cc                           	int3
  64b3d8: cc                           	int3
  64b3d9: cc                           	int3
  64b3da: cc                           	int3
  64b3db: cc                           	int3
  64b3dc: cc                           	int3
  64b3dd: cc                           	int3
  64b3de: cc                           	int3
  64b3df: cc                           	int3

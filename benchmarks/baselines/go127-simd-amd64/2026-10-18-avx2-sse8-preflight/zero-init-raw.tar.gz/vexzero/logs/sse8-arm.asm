
/private/tmp/govpx-sse8-zero-accumulators-research/vexzero-logs/pixel-arm.test:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100138fd0 <_github.com/thesyncim/govpx/internal/pixel.SSE8>:
100138fd0: f9400b90    	ldr	x16, [x28, #0x10]
100138fd4: eb3063ff    	cmp	sp, x16
100138fd8: 54001a89    	b.ls	0x100139328 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x358>
100138fdc: f81f0ffe    	str	x30, [sp, #-0x10]!
100138fe0: f81f83fd    	stur	x29, [sp, #-0x8]
100138fe4: d10023fd    	sub	x29, sp, #0x8
100138fe8: f9000fe0    	str	x0, [sp, #0x18]
100138fec: f9001fe4    	str	x4, [sp, #0x38]
100138ff0: d1000509    	sub	x9, x8, #0x1
100138ff4: 4f00e400    	movi.16b	v0, #0x0
100138ff8: 4f00e401    	movi.16b	v1, #0x0
100138ffc: f100fd3f    	cmp	x9, #0x3f
100139000: 54000228    	b.hi	0x100139044 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x74>
100139004: aa07006a    	orr	x10, x3, x7
100139008: d35efd4a    	lsr	x10, x10, #30
10013900c: b50001ca    	cbnz	x10, 0x100139044 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x74>
100139010: 9b097c62    	mul	x2, x3, x9
100139014: 91001c42    	add	x2, x2, #0x7
100139018: eb02003f    	cmp	x1, x2
10013901c: 54001829    	b.ls	0x100139320 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x350>
100139020: 9b097ce1    	mul	x1, x7, x9
100139024: 91001c21    	add	x1, x1, #0x7
100139028: eb0100bf    	cmp	x5, x1
10013902c: 54001789    	b.ls	0x10013931c <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x34c>
100139030: aa1f03e1    	mov	x1, xzr
100139034: aa1f03e2    	mov	x2, xzr
100139038: aa1f03e5    	mov	x5, xzr
10013903c: 4ea11c22    	mov.16b	v2, v1
100139040: 1400009c    	b	0x1001392b0 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x2e0>
100139044: aa1f03e9    	mov	x9, xzr
100139048: 4ea11c22    	mov.16b	v2, v1
10013904c: 14000017    	b	0x1001390a8 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0xd8>
100139050: f869688c    	ldr	x12, [x4, x9]
100139054: 4ea31c64    	mov.16b	v4, v3
100139058: 4e081d63    	mov.d	v3[0], x11
10013905c: 4e080463    	dup.2d	v3, v3[0]
100139060: 4e181d83    	mov.d	v3[1], x12
100139064: 2f08a405    	ushll.8h	v5, v0, #0x0
100139068: 2f08a466    	ushll.8h	v6, v3, #0x0
10013906c: 6e6684a5    	sub.8h	v5, v5, v6
100139070: 0e65c0a6    	smull.4s	v6, v5, v5
100139074: 4e65c0a5    	smull2.4s	v5, v5, v5
100139078: 4ea684a5    	add.4s	v5, v5, v6
10013907c: 4f00e406    	movi.16b	v6, #0x0
100139080: 4e067807    	zip2.16b	v7, v0, v6
100139084: 4e067863    	zip2.16b	v3, v3, v6
100139088: 6e6384e3    	sub.8h	v3, v7, v3
10013908c: 0e63c066    	smull.4s	v6, v3, v3
100139090: 4e63c063    	smull2.4s	v3, v3, v3
100139094: 4ea68463    	add.4s	v3, v3, v6
100139098: 4ea58442    	add.4s	v2, v2, v5
10013909c: 4ea38421    	add.4s	v1, v1, v3
1001390a0: 4ea41c80    	mov.16b	v0, v4
1001390a4: aa0a03e9    	mov	x9, x10
1001390a8: 9100092a    	add	x10, x9, #0x2
1001390ac: eb0a011f    	cmp	x8, x10
1001390b0: 5400052b    	b.lt	0x100139154 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x184>
1001390b4: 9b037d2b    	mul	x11, x9, x3
1001390b8: eb0b003f    	cmp	x1, x11
1001390bc: 54000bc3    	b.lo	0x100139234 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x264>
1001390c0: cb0b002c    	sub	x12, x1, x11
1001390c4: cb02016d    	sub	x13, x11, x2
1001390c8: 8a8dfd6d    	and	x13, x11, x13, asr #63
1001390cc: f1001d9f    	cmp	x12, #0x7
1001390d0: 54000b09    	b.ls	0x100139230 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x260>
1001390d4: 8b0b006b    	add	x11, x3, x11
1001390d8: f86d680c    	ldr	x12, [x0, x13]
1001390dc: eb0b003f    	cmp	x1, x11
1001390e0: 54000a63    	b.lo	0x10013922c <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x25c>
1001390e4: cb0b002d    	sub	x13, x1, x11
1001390e8: cb02016e    	sub	x14, x11, x2
1001390ec: 8a8efd6b    	and	x11, x11, x14, asr #63
1001390f0: f1001dbf    	cmp	x13, #0x7
1001390f4: 540009a9    	b.ls	0x100139228 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x258>
1001390f8: 9b077d29    	mul	x9, x9, x7
1001390fc: f86b680b    	ldr	x11, [x0, x11]
100139100: 4ea01c03    	mov.16b	v3, v0
100139104: 4e081d80    	mov.d	v0[0], x12
100139108: 4e080400    	dup.2d	v0, v0[0]
10013910c: 4e181d60    	mov.d	v0[1], x11
100139110: eb0900bf    	cmp	x5, x9
100139114: 54000883    	b.lo	0x100139224 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x254>
100139118: cb0900ab    	sub	x11, x5, x9
10013911c: cb06012c    	sub	x12, x9, x6
100139120: 8a8cfd2c    	and	x12, x9, x12, asr #63
100139124: f1001d7f    	cmp	x11, #0x7
100139128: 540007c9    	b.ls	0x100139220 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x250>
10013912c: 8b0900e9    	add	x9, x7, x9
100139130: f86c688b    	ldr	x11, [x4, x12]
100139134: eb0900bf    	cmp	x5, x9
100139138: 54000723    	b.lo	0x10013921c <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x24c>
10013913c: cb0900ac    	sub	x12, x5, x9
100139140: cb06012d    	sub	x13, x9, x6
100139144: 8a8dfd29    	and	x9, x9, x13, asr #63
100139148: f1001d9f    	cmp	x12, #0x7
10013914c: 54fff828    	b.hi	0x100139050 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x80>
100139150: 14000032    	b	0x100139218 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x248>
100139154: eb09011f    	cmp	x8, x9
100139158: 540004ad    	b.le	0x1001391ec <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x21c>
10013915c: 9b037d23    	mul	x3, x9, x3
100139160: eb03003f    	cmp	x1, x3
100139164: 54000583    	b.lo	0x100139214 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x244>
100139168: cb030021    	sub	x1, x1, x3
10013916c: cb020062    	sub	x2, x3, x2
100139170: 8a82fc62    	and	x2, x3, x2, asr #63
100139174: f1001c3f    	cmp	x1, #0x7
100139178: 540004c9    	b.ls	0x100139210 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x240>
10013917c: 9b077d21    	mul	x1, x9, x7
100139180: f8626802    	ldr	x2, [x0, x2]
100139184: 4ea01c03    	mov.16b	v3, v0
100139188: 4e081c40    	mov.d	v0[0], x2
10013918c: eb0100bf    	cmp	x5, x1
100139190: 540003e3    	b.lo	0x10013920c <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x23c>
100139194: cb0100a2    	sub	x2, x5, x1
100139198: cb060023    	sub	x3, x1, x6
10013919c: 8a83fc21    	and	x1, x1, x3, asr #63
1001391a0: f1001c5f    	cmp	x2, #0x7
1001391a4: 54000329    	b.ls	0x100139208 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x238>
1001391a8: f8616881    	ldr	x1, [x4, x1]
1001391ac: 4e081c23    	mov.d	v3[0], x1
1001391b0: 2f08a404    	ushll.8h	v4, v0, #0x0
1001391b4: 2f08a465    	ushll.8h	v5, v3, #0x0
1001391b8: 6e658484    	sub.8h	v4, v4, v5
1001391bc: 0e64c085    	smull.4s	v5, v4, v4
1001391c0: 4e64c084    	smull2.4s	v4, v4, v4
1001391c4: 4ea58484    	add.4s	v4, v4, v5
1001391c8: 4f00e405    	movi.16b	v5, #0x0
1001391cc: 4e057800    	zip2.16b	v0, v0, v5
1001391d0: 4e057863    	zip2.16b	v3, v3, v5
1001391d4: 6e638400    	sub.8h	v0, v0, v3
1001391d8: 0e60c003    	smull.4s	v3, v0, v0
1001391dc: 4e60c000    	smull2.4s	v0, v0, v0
1001391e0: 4ea38400    	add.4s	v0, v0, v3
1001391e4: 4ea48442    	add.4s	v2, v2, v4
1001391e8: 4ea08421    	add.4s	v1, v1, v0
1001391ec: 4ea18440    	add.4s	v0, v2, v1
1001391f0: 4eb1b800    	addv.4s	s0, v0
1001391f4: 0e043c00    	mov.s	w0, v0[0]
1001391f8: d503201f    	nop
1001391fc: f85f83fd    	ldur	x29, [sp, #-0x8]
100139200: f84107fe    	ldr	x30, [sp], #0x10
100139204: d65f03c0    	ret
100139208: 97fd29da    	bl	0x100083970 <_runtime.panicBounds>
10013920c: 97fd29d9    	bl	0x100083970 <_runtime.panicBounds>
100139210: 97fd29d8    	bl	0x100083970 <_runtime.panicBounds>
100139214: 97fd29d7    	bl	0x100083970 <_runtime.panicBounds>
100139218: 97fd29d6    	bl	0x100083970 <_runtime.panicBounds>
10013921c: 97fd29d5    	bl	0x100083970 <_runtime.panicBounds>
100139220: 97fd29d4    	bl	0x100083970 <_runtime.panicBounds>
100139224: 97fd29d3    	bl	0x100083970 <_runtime.panicBounds>
100139228: 97fd29d2    	bl	0x100083970 <_runtime.panicBounds>
10013922c: 97fd29d1    	bl	0x100083970 <_runtime.panicBounds>
100139230: 97fd29d0    	bl	0x100083970 <_runtime.panicBounds>
100139234: 97fd29cf    	bl	0x100083970 <_runtime.panicBounds>
100139238: f8656809    	ldr	x9, [x0, x5]
10013923c: 4ea01c03    	mov.16b	v3, v0
100139240: 4e081d23    	mov.d	v3[0], x9
100139244: 8b050069    	add	x9, x3, x5
100139248: f8696809    	ldr	x9, [x0, x9]
10013924c: 4e181d23    	mov.d	v3[1], x9
100139250: f8626889    	ldr	x9, [x4, x2]
100139254: 4ea01c04    	mov.16b	v4, v0
100139258: 4e081d24    	mov.d	v4[0], x9
10013925c: 8b0200e9    	add	x9, x7, x2
100139260: f8696889    	ldr	x9, [x4, x9]
100139264: 4e181d24    	mov.d	v4[1], x9
100139268: 6e246465    	umax.16b	v5, v3, v4
10013926c: 6e246c63    	umin.16b	v3, v3, v4
100139270: 6e2384a3    	sub.16b	v3, v5, v3
100139274: 2f08a464    	ushll.8h	v4, v3, #0x0
100139278: 6f08a463    	ushll2.8h	v3, v3, #0x0
10013927c: 0e64c085    	smull.4s	v5, v4, v4
100139280: 4e64c084    	smull2.4s	v4, v4, v4
100139284: 4ea58484    	add.4s	v4, v4, v5
100139288: 0e63c065    	smull.4s	v5, v3, v3
10013928c: 4e63c063    	smull2.4s	v3, v3, v3
100139290: 4ea58463    	add.4s	v3, v3, v5
100139294: d503201f    	nop
100139298: d503201f    	nop
10013929c: 4ea48421    	add.4s	v1, v1, v4
1001392a0: 4ea28462    	add.4s	v2, v3, v2
1001392a4: 8b0304a5    	add	x5, x5, x3, lsl #1
1001392a8: 8b070442    	add	x2, x2, x7, lsl #1
1001392ac: aa0603e1    	mov	x1, x6
1001392b0: 91000826    	add	x6, x1, #0x2
1001392b4: eb06011f    	cmp	x8, x6
1001392b8: 54fffc0a    	b.ge	0x100139238 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x268>
1001392bc: eb01011f    	cmp	x8, x1
1001392c0: 5400020d    	b.le	0x100139300 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x330>
1001392c4: f8656801    	ldr	x1, [x0, x5]
1001392c8: f8626882    	ldr	x2, [x4, x2]
1001392cc: 4ea01c03    	mov.16b	v3, v0
1001392d0: 4e081c20    	mov.d	v0[0], x1
1001392d4: 4e080400    	dup.2d	v0, v0[0]
1001392d8: 4e081c43    	mov.d	v3[0], x2
1001392dc: 4e080463    	dup.2d	v3, v3[0]
1001392e0: 6e236404    	umax.16b	v4, v0, v3
1001392e4: 6e236c00    	umin.16b	v0, v0, v3
1001392e8: 6e208480    	sub.16b	v0, v4, v0
1001392ec: 2f08a400    	ushll.8h	v0, v0, #0x0
1001392f0: 0e60c003    	smull.4s	v3, v0, v0
1001392f4: 4e60c000    	smull2.4s	v0, v0, v0
1001392f8: 4ea38400    	add.4s	v0, v0, v3
1001392fc: 4ea08421    	add.4s	v1, v1, v0
100139300: 4ea28420    	add.4s	v0, v1, v2
100139304: 4eb1b800    	addv.4s	s0, v0
100139308: 0e043c00    	mov.s	w0, v0[0]
10013930c: d503201f    	nop
100139310: f85f83fd    	ldur	x29, [sp, #-0x8]
100139314: f84107fe    	ldr	x30, [sp], #0x10
100139318: d65f03c0    	ret
10013931c: 97fd2995    	bl	0x100083970 <_runtime.panicBounds>
100139320: 97fd2994    	bl	0x100083970 <_runtime.panicBounds>
100139324: d503201f    	nop
100139328: a90087e0    	stp	x0, x1, [sp, #0x8]
10013932c: a9018fe2    	stp	x2, x3, [sp, #0x18]
100139330: a90297e4    	stp	x4, x5, [sp, #0x28]
100139334: a9039fe6    	stp	x6, x7, [sp, #0x38]
100139338: f90027e8    	str	x8, [sp, #0x48]
10013933c: aa1e03e3    	mov	x3, x30
100139340: 97fd2148    	bl	0x100081860 <_runtime.morestack_noctxt.abi0>
100139344: a94087e0    	ldp	x0, x1, [sp, #0x8]
100139348: a9418fe2    	ldp	x2, x3, [sp, #0x18]
10013934c: a94297e4    	ldp	x4, x5, [sp, #0x28]
100139350: a9439fe6    	ldp	x6, x7, [sp, #0x38]
100139354: f94027e8    	ldr	x8, [sp, #0x48]
100139358: 17ffff1e    	b	0x100138fd0 <_github.com/thesyncim/govpx/internal/pixel.SSE8>
10013935c: 00000000    	udf	#0x0

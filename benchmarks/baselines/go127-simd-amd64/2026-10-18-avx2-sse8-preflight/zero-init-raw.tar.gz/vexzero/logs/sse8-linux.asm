
/private/tmp/govpx-sse8-zero-accumulators-research/vexzero-logs/pixel-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000566ce0 <github.com/thesyncim/govpx/internal/pixel.SSE8>:
  566ce0: 55                           	push	rbp
  566ce1: 48 89 e5                     	mov	rbp, rsp
  566ce4: 48 83 ec 10                  	sub	rsp, 0x10
  566ce8: 48 89 44 24 20               	mov	qword ptr [rsp + 0x20], rax
  566ced: 48 89 74 24 40               	mov	qword ptr [rsp + 0x40], rsi
  566cf2: 80 3d 54 df 23 00 00         	cmp	byte ptr [rip + 0x23df54], 0x0 # 0x7a4c4d <github.com/thesyncim/govpx/internal/pixel.Enabled>
  566cf9: 0f 84 80 00 00 00            	je	0x566d7f <github.com/thesyncim/govpx/internal/pixel.SSE8+0x9f>
  566cff: 49 8d 53 ff                  	lea	rdx, [r11 - 0x1]
  566d03: 48 83 fa 3f                  	cmp	rdx, 0x3f
  566d07: 77 51                        	ja	0x566d5a <github.com/thesyncim/govpx/internal/pixel.SSE8+0x7a>
  566d09: 49 89 fc                     	mov	r12, rdi
  566d0c: 4c 09 d7                     	or	rdi, r10
  566d0f: 48 c1 ef 1e                  	shr	rdi, 0x1e
  566d13: 48 85 ff                     	test	rdi, rdi
  566d16: 75 45                        	jne	0x566d5d <github.com/thesyncim/govpx/internal/pixel.SSE8+0x7d>
  566d18: 4c 89 e1                     	mov	rcx, r12
  566d1b: 4c 0f af e2                  	imul	r12, rdx
  566d1f: 49 8d 7c 24 07               	lea	rdi, [r12 + 0x7]
  566d24: 48 39 fb                     	cmp	rbx, rdi
  566d27: 0f 86 f8 03 00 00            	jbe	0x567125 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x445>
  566d2d: 49 0f af d2                  	imul	rdx, r10
  566d31: 48 83 c2 07                  	add	rdx, 0x7
  566d35: 49 39 d0                     	cmp	r8, rdx
  566d38: 0f 86 de 03 00 00            	jbe	0x56711c <github.com/thesyncim/govpx/internal/pixel.SSE8+0x43c>
  566d3e: 90                           	nop
  566d3f: c5 fa 6f 05 89 e2 23 00      	vmovdqu	xmm0, xmmword ptr [rip + 0x23e289] # 0x7a4fd0 <github.com/thesyncim/govpx/internal/pixel.sse8ZeroAccumulatorLo>
  566d47: c5 fa 6f 0d 91 e2 23 00      	vmovdqu	xmm1, xmmword ptr [rip + 0x23e291] # 0x7a4fe0 <github.com/thesyncim/govpx/internal/pixel.sse8ZeroAccumulatorHi>
  566d4f: 31 d2                        	xor	edx, edx
  566d51: 31 db                        	xor	ebx, ebx
  566d53: 31 ff                        	xor	edi, edi
  566d55: e9 58 03 00 00               	jmp	0x5670b2 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x3d2>
  566d5a: 49 89 fc                     	mov	r12, rdi
  566d5d: 4c 89 5c 24 60               	mov	qword ptr [rsp + 0x60], r11
  566d62: 48 89 4c 24 30               	mov	qword ptr [rsp + 0x30], rcx
  566d67: 90                           	nop
  566d68: c5 fa 6f 05 60 e2 23 00      	vmovdqu	xmm0, xmmword ptr [rip + 0x23e260] # 0x7a4fd0 <github.com/thesyncim/govpx/internal/pixel.sse8ZeroAccumulatorLo>
  566d70: c5 fa 6f 0d 68 e2 23 00      	vmovdqu	xmm1, xmmword ptr [rip + 0x23e268] # 0x7a4fe0 <github.com/thesyncim/govpx/internal/pixel.sse8ZeroAccumulatorHi>
  566d78: 31 d2                        	xor	edx, edx
  566d7a: e9 d1 00 00 00               	jmp	0x566e50 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x170>
  566d7f: 4c 89 54 24 58               	mov	qword ptr [rsp + 0x58], r10
  566d84: 31 c9                        	xor	ecx, ecx
  566d86: 31 d2                        	xor	edx, edx
  566d88: eb 05                        	jmp	0x566d8f <github.com/thesyncim/govpx/internal/pixel.SSE8+0xaf>
  566d8a: 49 8d 54 24 01               	lea	rdx, [r12 + 0x1]
  566d8f: 49 39 d3                     	cmp	r11, rdx
  566d92: 7e 4e                        	jle	0x566de2 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x102>
  566d94: 49 89 d1                     	mov	r9, rdx
  566d97: 48 0f af d7                  	imul	rdx, rdi
  566d9b: 4d 89 cc                     	mov	r12, r9
  566d9e: 4d 0f af ca                  	imul	r9, r10
  566da2: 45 31 ed                     	xor	r13d, r13d
  566da5: eb 19                        	jmp	0x566dc0 <github.com/thesyncim/govpx/internal/pixel.SSE8+0xe0>
  566da7: 46 0f b6 14 16               	movzx	r10d, byte ptr [rsi + r10]
  566dac: 4d 29 d7                     	sub	r15, r10
  566daf: 4d 0f af ff                  	imul	r15, r15
  566db3: 44 01 f9                     	add	ecx, r15d
  566db6: 49 ff c5                     	inc	r13
  566db9: 4c 8b 54 24 58               	mov	r10, qword ptr [rsp + 0x58]
  566dbe: 66 90                        	nop
  566dc0: 49 83 fd 08                  	cmp	r13, 0x8
  566dc4: 7d c4                        	jge	0x566d8a <github.com/thesyncim/govpx/internal/pixel.SSE8+0xaa>
  566dc6: 4d 8d 7c 15 00               	lea	r15, [r13 + rdx]
  566dcb: 4c 39 fb                     	cmp	rbx, r15
  566dce: 76 1f                        	jbe	0x566def <github.com/thesyncim/govpx/internal/pixel.SSE8+0x10f>
  566dd0: 4f 8d 54 0d 00               	lea	r10, [r13 + r9]
  566dd5: 46 0f b6 3c 38               	movzx	r15d, byte ptr [rax + r15]
  566dda: 4d 39 d0                     	cmp	r8, r10
  566ddd: 77 c8                        	ja	0x566da7 <github.com/thesyncim/govpx/internal/pixel.SSE8+0xc7>
  566ddf: 90                           	nop
  566de0: eb 08                        	jmp	0x566dea <github.com/thesyncim/govpx/internal/pixel.SSE8+0x10a>
  566de2: 89 c8                        	mov	eax, ecx
  566de4: 48 83 c4 10                  	add	rsp, 0x10
  566de8: 5d                           	pop	rbp
  566de9: c3                           	ret
  566dea: e8 11 67 f2 ff               	call	0x48d500 <runtime.panicBounds>
  566def: e8 0c 67 f2 ff               	call	0x48d500 <runtime.panicBounds>
  566df4: c4 e1 f9 6e 1b               	vmovq	xmm3, qword ptr [rbx]
  566df9: 4e 8b 2c 2e                  	mov	r13, qword ptr [rsi + r13]
  566dfd: c4 e2 79 59 db               	vpbroadcastq	xmm3, xmm3
  566e02: c4 c3 e1 22 dd 01            	vpinsrq	xmm3, xmm3, r13, 0x1
  566e08: c4 e2 79 30 e2               	vpmovzxbw	xmm4, xmm2      # xmm4 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero
  566e0d: c4 e2 79 30 eb               	vpmovzxbw	xmm5, xmm3      # xmm5 = xmm3[0],zero,xmm3[1],zero,xmm3[2],zero,xmm3[3],zero,xmm3[4],zero,xmm3[5],zero,xmm3[6],zero,xmm3[7],zero
  566e12: c5 d9 f9 e5                  	vpsubw	xmm4, xmm4, xmm5
  566e16: c5 d9 f5 e4                  	vpmaddwd	xmm4, xmm4, xmm4
  566e1a: c5 f9 70 d2 4e               	vpshufd	xmm2, xmm2, 0x4e        # xmm2 = xmm2[2,3,0,1]
  566e1f: c4 e2 79 30 d2               	vpmovzxbw	xmm2, xmm2      # xmm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero
  566e24: c5 f9 70 db 4e               	vpshufd	xmm3, xmm3, 0x4e        # xmm3 = xmm3[2,3,0,1]
  566e29: c4 e2 79 30 db               	vpmovzxbw	xmm3, xmm3      # xmm3 = xmm3[0],zero,xmm3[1],zero,xmm3[2],zero,xmm3[3],zero,xmm3[4],zero,xmm3[5],zero,xmm3[6],zero,xmm3[7],zero
  566e2e: c5 e9 f9 d3                  	vpsubw	xmm2, xmm2, xmm3
  566e32: c5 e9 f5 d2                  	vpmaddwd	xmm2, xmm2, xmm2
  566e36: c5 f9 fe c4                  	vpaddd	xmm0, xmm0, xmm4
  566e3a: c5 f1 fe ca                  	vpaddd	xmm1, xmm1, xmm2
  566e3e: 90                           	nop
  566e3f: 90                           	nop
  566e40: 48 8b 4c 24 30               	mov	rcx, qword ptr [rsp + 0x30]
  566e45: 4c 89 db                     	mov	rbx, r11
  566e48: 4c 8b 5c 24 60               	mov	r11, qword ptr [rsp + 0x60]
  566e4d: 48 89 fa                     	mov	rdx, rdi
  566e50: 48 8d 7a 02                  	lea	rdi, [rdx + 0x2]
  566e54: 49 39 fb                     	cmp	r11, rdi
  566e57: 0f 8c e3 00 00 00            	jl	0x566f40 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x260>
  566e5d: 49 89 d5                     	mov	r13, rdx
  566e60: 49 0f af d4                  	imul	rdx, r12
  566e64: 48 39 d3                     	cmp	rbx, rdx
  566e67: 0f 82 d8 01 00 00            	jb	0x567045 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x365>
  566e6d: 48 89 14 24                  	mov	qword ptr [rsp], rdx
  566e71: 49 89 df                     	mov	r15, rbx
  566e74: 48 29 d3                     	sub	rbx, rdx
  566e77: 48 29 ca                     	sub	rdx, rcx
  566e7a: 48 c1 fa 3f                  	sar	rdx, 0x3f
  566e7e: 4c 8b 1c 24                  	mov	r11, qword ptr [rsp]
  566e82: 4c 21 da                     	and	rdx, r11
  566e85: 48 01 c2                     	add	rdx, rax
  566e88: 48 83 fb 07                  	cmp	rbx, 0x7
  566e8c: 0f 86 ac 01 00 00            	jbe	0x56703e <github.com/thesyncim/govpx/internal/pixel.SSE8+0x35e>
  566e92: 4b 8d 1c 1c                  	lea	rbx, [r12 + r11]
  566e96: 49 39 df                     	cmp	r15, rbx
  566e99: 0f 82 9a 01 00 00            	jb	0x567039 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x359>
  566e9f: 48 89 5c 24 08               	mov	qword ptr [rsp + 0x8], rbx
  566ea4: 4d 89 fb                     	mov	r11, r15
  566ea7: 49 29 df                     	sub	r15, rbx
  566eaa: 48 29 cb                     	sub	rbx, rcx
  566ead: 48 c1 fb 3f                  	sar	rbx, 0x3f
  566eb1: 48 8b 4c 24 08               	mov	rcx, qword ptr [rsp + 0x8]
  566eb6: 48 21 d9                     	and	rcx, rbx
  566eb9: 0f 1f 80 00 00 00 00         	nop	dword ptr [rax]
  566ec0: 49 83 ff 07                  	cmp	r15, 0x7
  566ec4: 0f 86 6a 01 00 00            	jbe	0x567034 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x354>
  566eca: 4d 0f af ea                  	imul	r13, r10
  566ece: c4 e1 f9 6e 12               	vmovq	xmm2, qword ptr [rdx]
  566ed3: 48 8b 0c 08                  	mov	rcx, qword ptr [rax + rcx]
  566ed7: c4 e2 79 59 d2               	vpbroadcastq	xmm2, xmm2
  566edc: c4 e3 e9 22 d1 01            	vpinsrq	xmm2, xmm2, rcx, 0x1
  566ee2: 4d 39 e8                     	cmp	r8, r13
  566ee5: 0f 82 44 01 00 00            	jb	0x56702f <github.com/thesyncim/govpx/internal/pixel.SSE8+0x34f>
  566eeb: 4c 89 c1                     	mov	rcx, r8
  566eee: 4d 29 e8                     	sub	r8, r13
  566ef1: 4c 89 ea                     	mov	rdx, r13
  566ef4: 4d 29 cd                     	sub	r13, r9
  566ef7: 49 c1 fd 3f                  	sar	r13, 0x3f
  566efb: 49 21 d5                     	and	r13, rdx
  566efe: 4a 8d 1c 2e                  	lea	rbx, [rsi + r13]
  566f02: 49 83 f8 07                  	cmp	r8, 0x7
  566f06: 0f 86 1e 01 00 00            	jbe	0x56702a <github.com/thesyncim/govpx/internal/pixel.SSE8+0x34a>
  566f0c: 4c 01 d2                     	add	rdx, r10
  566f0f: 48 39 d1                     	cmp	rcx, rdx
  566f12: 0f 82 0d 01 00 00            	jb	0x567025 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x345>
  566f18: 49 89 c8                     	mov	r8, rcx
  566f1b: 48 29 d1                     	sub	rcx, rdx
  566f1e: 49 89 d5                     	mov	r13, rdx
  566f21: 4c 29 ca                     	sub	rdx, r9
  566f24: 48 c1 fa 3f                  	sar	rdx, 0x3f
  566f28: 49 21 d5                     	and	r13, rdx
  566f2b: 48 83 f9 07                  	cmp	rcx, 0x7
  566f2f: 0f 87 bf fe ff ff            	ja	0x566df4 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x114>
  566f35: e9 e4 00 00 00               	jmp	0x56701e <github.com/thesyncim/govpx/internal/pixel.SSE8+0x33e>
  566f3a: 66 0f 1f 44 00 00            	nop	word ptr [rax + rax]
  566f40: 49 39 d3                     	cmp	r11, rdx
  566f43: 0f 8e 9f 00 00 00            	jle	0x566fe8 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x308>
  566f49: 4c 0f af e2                  	imul	r12, rdx
  566f4d: 4c 39 e3                     	cmp	rbx, r12
  566f50: 0f 82 c3 00 00 00            	jb	0x567019 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x339>
  566f56: 4c 29 e3                     	sub	rbx, r12
  566f59: 4c 89 e7                     	mov	rdi, r12
  566f5c: 49 29 cc                     	sub	r12, rcx
  566f5f: 49 c1 fc 3f                  	sar	r12, 0x3f
  566f63: 4c 21 e7                     	and	rdi, r12
  566f66: 48 8d 0c 38                  	lea	rcx, [rax + rdi]
  566f6a: 90                           	nop
  566f6b: 48 83 fb 07                  	cmp	rbx, 0x7
  566f6f: 0f 86 9f 00 00 00            	jbe	0x567014 <github.com/thesyncim/govpx/internal/pixel.SSE8+0x334>
  566f75: 49 0f af d2                  	imul	rdx, r10
  566f79: 0f 1f 80 00 00 00 00         	nop	dword ptr [rax]
  566f80: 49 39 d0                     	cmp	r8, rdx
  566f83: 0f 82 86 00 00 00            	jb	0x56700f <github.com/thesyncim/govpx/internal/pixel.SSE8+0x32f>
  566f89: 49 29 d0                     	sub	r8, rdx
  566f8c: 48 89 d3                     	mov	rbx, rdx
  566f8f: 4c 29 ca                     	sub	rdx, r9
  566f92: 48 c1 fa 3f                  	sar	rdx, 0x3f
  566f96: 48 21 d3                     	and	rbx, rdx
  566f99: 48 8d 14 1e                  	lea	rdx, [rsi + rbx]
  566f9d: 90                           	nop
  566f9e: 66 90                        	nop
  566fa0: 49 83 f8 07                  	cmp	r8, 0x7
  566fa4: 76 64                        	jbe	0x56700a <github.com/thesyncim/govpx/internal/pixel.SSE8+0x32a>
  566fa6: c4 e1 f9 6e 11               	vmovq	xmm2, qword ptr [rcx]
  566fab: c4 e1 f9 6e 1a               	vmovq	xmm3, qword ptr [rdx]
  566fb0: c4 e2 79 30 e2               	vpmovzxbw	xmm4, xmm2      # xmm4 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero
  566fb5: c4 e2 79 30 eb               	vpmovzxbw	xmm5, xmm3      # xmm5 = xmm3[0],zero,xmm3[1],zero,xmm3[2],zero,xmm3[3],zero,xmm3[4],zero,xmm3[5],zero,xmm3[6],zero,xmm3[7],zero
  566fba: c5 d9 f9 e5                  	vpsubw	xmm4, xmm4, xmm5
  566fbe: c5 d9 f5 e4                  	vpmaddwd	xmm4, xmm4, xmm4
  566fc2: c5 f9 70 d2 4e               	vpshufd	xmm2, xmm2, 0x4e        # xmm2 = xmm2[2,3,0,1]
  566fc7: c4 e2 79 30 d2               	vpmovzxbw	xmm2, xmm2      # xmm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero
  566fcc: c5 f9 70 db 4e               	vpshufd	xmm3, xmm3, 0x4e        # xmm3 = xmm3[2,3,0,1]
  566fd1: c4 e2 79 30 db               	vpmovzxbw	xmm3, xmm3      # xmm3 = xmm3[0],zero,xmm3[1],zero,xmm3[2],zero,xmm3[3],zero,xmm3[4],zero,xmm3[5],zero,xmm3[6],zero,xmm3[7],zero
  566fd6: c5 e9 f9 d3                  	vpsubw	xmm2, xmm2, xmm3
  566fda: c5 e9 f5 d2                  	vpmaddwd	xmm2, xmm2, xmm2
  566fde: c5 f9 fe c4                  	vpaddd	xmm0, xmm0, xmm4
  566fe2: c5 f1 fe ca                  	vpaddd	xmm1, xmm1, xmm2
  566fe6: 90                           	nop
  566fe7: 90                           	nop
  566fe8: c5 f9 fe c1                  	vpaddd	xmm0, xmm0, xmm1
  566fec: c5 f9 70 c8 4e               	vpshufd	xmm1, xmm0, 0x4e        # xmm1 = xmm0[2,3,0,1]
  566ff1: c5 f9 fe c1                  	vpaddd	xmm0, xmm0, xmm1
  566ff5: c5 f9 70 c8 b1               	vpshufd	xmm1, xmm0, 0xb1        # xmm1 = xmm0[1,0,3,2]
  566ffa: c5 f9 fe c1                  	vpaddd	xmm0, xmm0, xmm1
  566ffe: c4 e3 79 16 c0 00            	vpextrd	eax, xmm0, 0x0
  567004: 48 83 c4 10                  	add	rsp, 0x10
  567008: 5d                           	pop	rbp
  567009: c3                           	ret
  56700a: e8 f1 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  56700f: e8 ec 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  567014: e8 e7 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  567019: e8 e2 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  56701e: 66 90                        	nop
  567020: e8 db 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  567025: e8 d6 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  56702a: e8 d1 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  56702f: e8 cc 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  567034: e8 c7 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  567039: e8 c2 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  56703e: 66 90                        	nop
  567040: e8 bb 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  567045: e8 b6 64 f2 ff               	call	0x48d500 <runtime.panicBounds>
  56704a: 4c 8d 0c 03                  	lea	r9, [rbx + rax]
  56704e: c4 c1 f9 6e 11               	vmovq	xmm2, qword ptr [r9]
  567053: 4c 8d 0c 19                  	lea	r9, [rcx + rbx]
  567057: 4e 8b 0c 08                  	mov	r9, qword ptr [rax + r9]
  56705b: c4 c3 e9 22 d1 01            	vpinsrq	xmm2, xmm2, r9, 0x1
  567061: 4c 8d 0c 32                  	lea	r9, [rdx + rsi]
  567065: c4 c1 f9 6e 19               	vmovq	xmm3, qword ptr [r9]
  56706a: 4d 8d 0c 12                  	lea	r9, [r10 + rdx]
  56706e: 4e 8b 0c 0e                  	mov	r9, qword ptr [rsi + r9]
  567072: c4 c3 e1 22 d9 01            	vpinsrq	xmm3, xmm3, r9, 0x1
  567078: c5 e9 de e3                  	vpmaxub	xmm4, xmm2, xmm3
  56707c: c5 e9 da d3                  	vpminub	xmm2, xmm2, xmm3
  567080: c5 d9 f8 d2                  	vpsubb	xmm2, xmm4, xmm2
  567084: c4 e2 79 30 da               	vpmovzxbw	xmm3, xmm2      # xmm3 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero
  567089: c5 e1 f5 db                  	vpmaddwd	xmm3, xmm3, xmm3
  56708d: c5 f9 70 d2 4e               	vpshufd	xmm2, xmm2, 0x4e        # xmm2 = xmm2[2,3,0,1]
  567092: c4 e2 79 30 d2               	vpmovzxbw	xmm2, xmm2      # xmm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero
  567097: c5 e9 f5 d2                  	vpmaddwd	xmm2, xmm2, xmm2
  56709b: 90                           	nop
  56709c: 90                           	nop
  56709d: 90                           	nop
  56709e: c5 f9 fe c3                  	vpaddd	xmm0, xmm0, xmm3
  5670a2: c5 f1 fe ca                  	vpaddd	xmm1, xmm1, xmm2
  5670a6: 48 8d 1c 4b                  	lea	rbx, [rbx + 2*rcx]
  5670aa: 4a 8d 14 52                  	lea	rdx, [rdx + 2*r10]
  5670ae: 90                           	nop
  5670af: 4c 89 c7                     	mov	rdi, r8
  5670b2: 4c 8d 47 02                  	lea	r8, [rdi + 0x2]
  5670b6: 4d 39 c3                     	cmp	r11, r8
  5670b9: 7d 8f                        	jge	0x56704a <github.com/thesyncim/govpx/internal/pixel.SSE8+0x36a>
  5670bb: 0f 1f 44 00 00               	nop	dword ptr [rax + rax]
  5670c0: 49 39 fb                     	cmp	r11, rdi
  5670c3: 7e 35                        	jle	0x5670fa <github.com/thesyncim/govpx/internal/pixel.SSE8+0x41a>
  5670c5: 48 8d 0c 03                  	lea	rcx, [rbx + rax]
  5670c9: c4 e1 f9 6e 11               	vmovq	xmm2, qword ptr [rcx]
  5670ce: 48 8d 0c 32                  	lea	rcx, [rdx + rsi]
  5670d2: c4 e1 f9 6e 19               	vmovq	xmm3, qword ptr [rcx]
  5670d7: c4 e2 79 59 d2               	vpbroadcastq	xmm2, xmm2
  5670dc: c4 e2 79 59 db               	vpbroadcastq	xmm3, xmm3
  5670e1: c5 e1 de e2                  	vpmaxub	xmm4, xmm3, xmm2
  5670e5: c5 e1 da d2                  	vpminub	xmm2, xmm3, xmm2
  5670e9: c5 d9 f8 d2                  	vpsubb	xmm2, xmm4, xmm2
  5670ed: c4 e2 79 30 d2               	vpmovzxbw	xmm2, xmm2      # xmm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero
  5670f2: c5 e9 f5 d2                  	vpmaddwd	xmm2, xmm2, xmm2
  5670f6: c5 f9 fe c2                  	vpaddd	xmm0, xmm0, xmm2
  5670fa: c5 f9 fe c1                  	vpaddd	xmm0, xmm0, xmm1
  5670fe: c5 f9 70 c8 4e               	vpshufd	xmm1, xmm0, 0x4e        # xmm1 = xmm0[2,3,0,1]
  567103: c5 f9 fe c1                  	vpaddd	xmm0, xmm0, xmm1
  567107: c5 f9 70 c8 b1               	vpshufd	xmm1, xmm0, 0xb1        # xmm1 = xmm0[1,0,3,2]
  56710c: c5 f9 fe c1                  	vpaddd	xmm0, xmm0, xmm1
  567110: c4 e3 79 16 c0 00            	vpextrd	eax, xmm0, 0x0
  567116: 48 83 c4 10                  	add	rsp, 0x10
  56711a: 5d                           	pop	rbp
  56711b: c3                           	ret
  56711c: 0f 1f 40 00                  	nop	dword ptr [rax]
  567120: e8 db 63 f2 ff               	call	0x48d500 <runtime.panicBounds>
  567125: e8 d6 63 f2 ff               	call	0x48d500 <runtime.panicBounds>
  56712a: 90                           	nop
  56712b: cc                           	int3
  56712c: cc                           	int3
  56712d: cc                           	int3
  56712e: cc                           	int3
  56712f: cc                           	int3
  567130: cc                           	int3
  567131: cc                           	int3
  567132: cc                           	int3
  567133: cc                           	int3
  567134: cc                           	int3
  567135: cc                           	int3
  567136: cc                           	int3
  567137: cc                           	int3
  567138: cc                           	int3
  567139: cc                           	int3
  56713a: cc                           	int3
  56713b: cc                           	int3
  56713c: cc                           	int3
  56713d: cc                           	int3
  56713e: cc                           	int3
  56713f: cc                           	int3

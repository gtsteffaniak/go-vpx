#!/bin/sh
set -eu
export ROSETTA_ADVERTISE_AVX=1 CODEX_AGENT_ID=govpx-ci-sse8-reduced CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GOEXPERIMENT=simd GOFLAGS=-p=2 GOMAXPROCS=1 GOAMD64=v1
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go
root=/Users/thesyncim/GolandProjects/govpx
for variant in direct; do
 p=/private/tmp/govpx-sse8-pointer-avx2-$variant
 out=/private/tmp/govpx-sse8-pointer-avx2-$variant-results
 mkdir -p "$out"
 "$root/scripts/go.sh" -C "$p" fmt ./internal/pixel ./internal/vp8/dsp > "$out/fmt.txt"
 GOOS=linux GOARCH=amd64 "$root/scripts/go.sh" -C "$p" test -pgo=off -c -o "$out/pixel-linux.test" ./internal/pixel > "$out/build-linux.txt" 2>&1
 /usr/bin/objdump --disassemble-symbols=github.com/thesyncim/govpx/internal/pixel.SSE8Ptr --x86-asm-syntax=intel -d "$out/pixel-linux.test" > "$out/body-linux-llvm.txt"
 for pkg in internal/pixel internal/vp8/dsp; do
  name=${pkg##*/}
  GOOS=darwin GOARCH=amd64 "$root/scripts/go.sh" -C "$p" test -pgo=off -c -o "$out/$name-darwin.test" ./$pkg > "$out/build-$name.txt" 2>&1
  GOVPX_REQUIRE_SIMD=1 arch -x86_64 "$out/$name-darwin.test" -test.run '^Test(SquaredError|SSE|Variance)' -test.v -test.count=1 > "$out/$name-rosetta.txt" 2>&1
  GOOS=darwin GOARCH=amd64 "$root/scripts/go.sh" -C "$p" test -pgo=off -gcflags=all=-d=checkptr=1 -c -o "$out/$name-checkptr.test" ./$pkg > "$out/build-$name-checkptr.txt" 2>&1
  GOVPX_REQUIRE_SIMD=1 arch -x86_64 "$out/$name-checkptr.test" -test.run '^Test(SquaredError|SSE|Variance)' -test.v -test.count=1 > "$out/$name-checkptr.txt" 2>&1
  GODEBUG=cpu.avx=off,cpu.avx2=off arch -x86_64 "$out/$name-checkptr.test" -test.run '^Test(SquaredError|SSE|Variance)' -test.v -test.count=1 > "$out/$name-cpuoff.txt" 2>&1
 done
 /usr/bin/objdump --disassemble-symbols=_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr --x86-asm-syntax=intel -d "$out/pixel-darwin.test" > "$out/body-darwin-llvm.txt"
 GOVPX_REQUIRE_SIMD=1 arch -x86_64 "$out/dsp-darwin.test" -test.run '^$' -test.bench '^BenchmarkSSE8RowsNative$' -test.benchtime=1x -test.count=1 -test.cpu=1 -test.benchmem > "$out/public-fixtures-1x-correctness-only.txt" 2>&1
done


#!/bin/sh
set -eu
export ROSETTA_ADVERTISE_AVX=1
export CODEX_AGENT_ID=govpx-ci-sse8-avx2 CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GOEXPERIMENT=simd GOFLAGS=-p=2 GOMAXPROCS=1 GOAMD64=v1
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go
root=/Users/thesyncim/GolandProjects/govpx
p=/private/tmp/govpx-sse8-avx2-candidate
"$root/scripts/go.sh" -C "$p" fmt ./internal/pixel > /private/tmp/govpx-sse8-avx2-fmt.txt
GOOS=linux GOARCH=amd64 "$root/scripts/go.sh" -C "$p" test -pgo=off -c -o /private/tmp/govpx-sse8-avx2-linux.test ./internal/pixel > /private/tmp/govpx-sse8-avx2-build-linux-final.txt 2>&1
GOOS=darwin GOARCH=amd64 "$root/scripts/go.sh" -C "$p" test -pgo=off -c -o /private/tmp/govpx-sse8-avx2-darwin.test ./internal/pixel > /private/tmp/govpx-sse8-avx2-build-darwin.txt 2>&1
GOVPX_REQUIRE_SIMD=1 arch -x86_64 /private/tmp/govpx-sse8-avx2-darwin.test -test.run '^Test(SquaredError|SSE8)' -test.v -test.count=1 > /private/tmp/govpx-sse8-avx2-rosetta.txt 2>&1
GOOS=darwin GOARCH=amd64 "$root/scripts/go.sh" -C "$p" test -pgo=off -gcflags=all=-d=checkptr=1 -c -o /private/tmp/govpx-sse8-avx2-checkptr.test ./internal/pixel > /private/tmp/govpx-sse8-avx2-build-checkptr.txt 2>&1
GOVPX_REQUIRE_SIMD=1 arch -x86_64 /private/tmp/govpx-sse8-avx2-checkptr.test -test.run '^Test(SquaredError|SSE8)' -test.v -test.count=1 > /private/tmp/govpx-sse8-avx2-checkptr.txt 2>&1
GODEBUG=cpu.avx=off,cpu.avx2=off arch -x86_64 /private/tmp/govpx-sse8-avx2-checkptr.test -test.run '^Test(SquaredError|SSE8)' -test.v -test.count=1 > /private/tmp/govpx-sse8-avx2-cpuoff.txt 2>&1

#!/bin/sh
set -eu
export CODEX_AGENT_ID=govpx-ci-sse8-final CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GOEXPERIMENT=simd GOFLAGS=-p=2 GOMAXPROCS=1 GOOS=darwin GOARCH=arm64
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go
root=/Users/thesyncim/GolandProjects/govpx
"$root/scripts/go.sh" -C /private/tmp/govpx-sse8-avx2-slice-direct test -pgo=off -c -o /private/tmp/govpx-sse8-slice-direct-arm.test ./internal/pixel > /private/tmp/govpx-sse8-slice-direct-arm-build.txt 2>&1
GOVPX_REQUIRE_SIMD=1 /private/tmp/govpx-sse8-slice-direct-arm.test -test.run '^Test(SquaredError|SSE)' -test.count=1 > /private/tmp/govpx-sse8-slice-direct-arm-tests.txt 2>&1
"$root/scripts/go.sh" -C /private/tmp/govpx-sse8-pointer-avx2-direct test -pgo=off -tags purego ./internal/pixel ./internal/vp8/dsp -run '^Test(SquaredError|SSE|Variance)' -count=1 > /private/tmp/govpx-sse8-pointer-direct-purego.txt 2>&1
GOEXPERIMENT= "$root/scripts/go.sh" -C /private/tmp/govpx-sse8-pointer-avx2-direct test -pgo=off ./internal/pixel ./internal/vp8/dsp -run '^Test(SquaredError|SSE|Variance)' -count=1 > /private/tmp/govpx-sse8-pointer-direct-off.txt 2>&1

//go:build goexperiment.simd && arm64 && !purego

package pixel

import "unsafe"

func sse8RowsWide(sp unsafe.Pointer, ss int, rp unsafe.Pointer, rs, h int) (uint32, bool) {
	return 0, false
}

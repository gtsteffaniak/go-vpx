//go:build goexperiment.simd && amd64 && !purego

package pixel

import (
	"simd/archsimd"
	"testing"
	"unsafe"
)

func TestSSE8RowsWideDispatch(t *testing.T) {
	a, b := make([]byte, 64), make([]byte, 64)
	for i := range a {
		a[i] = 255
	}
	sp, rp := unsafe.Pointer(unsafe.SliceData(a)), unsafe.Pointer(unsafe.SliceData(b))
	if _, ok := sse8RowsWide(sp, 8, rp, 8, 4); ok {
		t.Fatal("four-row control entered wide helper")
	}
	got, ok := sse8RowsWide(sp, 8, rp, 8, 8)
	if archsimd.X86.AVX2() {
		if !ok || got != 64*255*255 {
			t.Fatalf("wide dispatch got%d accepted%v", got, ok)
		}
	} else if ok {
		t.Fatal("AVX2-disabled helper accepted")
	}
	t.Logf("AVX2=%v Enabled=%v", archsimd.X86.AVX2(), Enabled)
}

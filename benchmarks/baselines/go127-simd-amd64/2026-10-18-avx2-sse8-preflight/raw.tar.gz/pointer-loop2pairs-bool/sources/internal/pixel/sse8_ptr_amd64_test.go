//go:build goexperiment.simd && amd64 && !purego

package pixel

import (
	"bytes"
	"simd/archsimd"
	"testing"
)

func TestSSE8PtrPrivate(t *testing.T) {
	t.Logf("AVX2=%v Enabled=%v", archsimd.X86.AVX2(), Enabled)
	a, b := make([]byte, 64), make([]byte, 64)
	maxInt := int(^uint(0) >> 1)
	for _, stride := range []int{-maxInt - 1, -1, 1 << 30, maxInt} {
		if _, ok := SSE8Ptr(&a[0], stride, &b[0], 8); ok {
			t.Fatal("invalid source stride accepted")
		}
		if _, ok := SSE8Ptr(&a[0], 8, &b[0], stride); ok {
			t.Fatal("invalid ref stride accepted")
		}
	}
	if _, ok := SSE8Ptr(nil, 8, &b[0], 8); ok {
		t.Fatal("nil source accepted")
	}
	if _, ok := SSE8Ptr(&a[0], 8, nil, 8); ok {
		t.Fatal("nil ref accepted")
	}
	if !Enabled || !archsimd.X86.AVX2() {
		if _, ok := SSE8Ptr(&a[0], 8, &b[0], 8); ok {
			t.Fatal("CPU disabled path accepted")
		}
		return
	}
	for _, strides := range [][2]int{{0, 0}, {1, 3}, {8, 8}, {9, 17}, {31, 37}, {1312, 1320}} {
		ss, rs := strides[0], strides[1]
		n, m := 7*ss+8, 7*rs+8
		for align := range 8 {
			for mode := range 3 {
				a, b := make([]byte, n+align)[align:], make([]byte, m+align+1)[align+1:]
				for i := range a {
					a[i] = byte(i*37 + 11)
				}
				for i := range b {
					b[i] = byte(i*19 + 53)
				}
				if mode == 1 {
					for i := range a {
						a[i] = 255
					}
					clear(b)
				} else if mode == 2 {
					z := make([]byte, max(n, m)+5)
					for i := range z {
						z[i] = byte(i*17 + 29)
					}
					a, b = z[:n:n], z[5:5+m:5+m]
				}
				beforeA, beforeB := bytes.Clone(a), bytes.Clone(b)
				want := SSE8Scalar(a, ss, b, rs, 8)
				got, ok := SSE8Ptr(&a[0], ss, &b[0], rs)
				if !ok || got != want || !bytes.Equal(a, beforeA) || !bytes.Equal(b, beforeB) {
					t.Fatalf("strides%v align%d mode%d got%d want%d accepted%v", strides, align, mode, got, want, ok)
				}
			}
		}
	}
	for base := 0; base < 1<<16; base += 64 {
		for i := range a {
			v := base + i
			a[i], b[i] = byte(v>>8), byte(v)
		}
		got, ok := SSE8Ptr(&a[0], 8, &b[0], 8)
		if !ok || got != SSE8Scalar(a, 8, b, 8, 8) {
			t.Fatalf("byte pairs base%d got%d accepted%v", base, got, ok)
		}
	}
	old := Enabled
	Enabled = false
	defer func() { Enabled = old }()
	if _, ok := SSE8Ptr(&a[0], 8, &b[0], 8); ok {
		t.Fatal("backend disabled accepted")
	}
}

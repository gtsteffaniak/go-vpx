//go:build !goexperiment.simd || purego || (!arm64 && !amd64)

package pixel

func SSE8Ptr(src *byte, ss int, ref *byte, rs int) (uint32, bool) { return 0, false }

//go:build goexperiment.simd && amd64 && !purego

package pixel

import (
	"simd/archsimd"
	"unsafe"
)

// SSE8Ptr uses the caller-validated complete 8x8 windows. It declines
// unsupported CPU/geometry before reading either pointer, preserving fallback.
func SSE8Ptr(src *byte, ss int, ref *byte, rs int) (uint32, bool) {
	if !Enabled || !archsimd.X86.AVX2() || src == nil || ref == nil || (uint(ss)|uint(rs))>>30 != 0 {
		return 0, false
	}
	defer archsimd.ClearAVXUpperBits()
	sp, rp := unsafe.Pointer(src), unsafe.Pointer(ref)
	var acc archsimd.Int32x8
	{
		a := archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(sp, 0*ss))).InterleaveLoGrouped(archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(sp, 1*ss)))).GetLo().ReshapeToUint8s().ExtendToUint16().BitsToInt16()
		b := archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(rp, 0*rs))).InterleaveLoGrouped(archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(rp, 1*rs)))).GetLo().ReshapeToUint8s().ExtendToUint16().BitsToInt16()
		d := a.Sub(b)
		acc = acc.Add(d.DotProductPairs(d))
	}
	{
		a := archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(sp, 2*ss))).InterleaveLoGrouped(archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(sp, 3*ss)))).GetLo().ReshapeToUint8s().ExtendToUint16().BitsToInt16()
		b := archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(rp, 2*rs))).InterleaveLoGrouped(archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(rp, 3*rs)))).GetLo().ReshapeToUint8s().ExtendToUint16().BitsToInt16()
		d := a.Sub(b)
		acc = acc.Add(d.DotProductPairs(d))
	}
	{
		a := archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(sp, 4*ss))).InterleaveLoGrouped(archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(sp, 5*ss)))).GetLo().ReshapeToUint8s().ExtendToUint16().BitsToInt16()
		b := archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(rp, 4*rs))).InterleaveLoGrouped(archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(rp, 5*rs)))).GetLo().ReshapeToUint8s().ExtendToUint16().BitsToInt16()
		d := a.Sub(b)
		acc = acc.Add(d.DotProductPairs(d))
	}
	{
		a := archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(sp, 6*ss))).InterleaveLoGrouped(archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(sp, 7*ss)))).GetLo().ReshapeToUint8s().ExtendToUint16().BitsToInt16()
		b := archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(rp, 6*rs))).InterleaveLoGrouped(archsimd.BroadcastUint64x4(*(*uint64)(unsafe.Add(rp, 7*rs)))).GetLo().ReshapeToUint8s().ExtendToUint16().BitsToInt16()
		d := a.Sub(b)
		acc = acc.Add(d.DotProductPairs(d))
	}
	return uint32(sum32(acc.GetLo().Add(acc.GetHi()))), true
}

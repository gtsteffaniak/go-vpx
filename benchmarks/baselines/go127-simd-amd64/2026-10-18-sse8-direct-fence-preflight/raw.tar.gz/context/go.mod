module github.com/thesyncim/govpx

go 1.27.0

toolchain go1.27.2

import pathlib,hashlib,json,subprocess,shutil,re,difflib
root=pathlib.Path('/Users/thesyncim/GolandProjects/govpx')
snap=pathlib.Path('/private/tmp/govpx-sse8-direct-fence-candidate')
out=pathlib.Path('/private/tmp/govpx-sse8-direct-fence-ready')
out.mkdir(exist_ok=True)
base='c638b7c76eac857affa0780820e86c211cdd84d3'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
changed=['internal/pixel/sse8_ptr_amd64.go','internal/pixel/sse8_rows_wide_amd64.go']
related=['internal/pixel/sse_simd.go','internal/pixel/sse8_ptr_other.go','internal/pixel/sse8_zero_accumulators_amd64.go','internal/pixel/enabled_amd64.go','internal/pixel/sse8_ptr_amd64_test.go','internal/pixel/sse8_rows_simd_test.go','internal/pixel/sse8_rows_wide_amd64_test.go','internal/vp8/dsp/sse8_rows_native_test.go','internal/vp8/dsp/variance_block_sized_other.go','scripts/go.sh','go.mod']
patch=[]
for f in changed:
 old=subprocess.check_output(['git','show',base+':'+f],cwd=root)
 p=out/'parent'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(old)
 new=(snap/f).read_bytes();p=out/'candidate'/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(new)
 patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+f,tofile='b/'+f))
for f in related:
 p=out/'context'/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(snap/f,p)
(out/'candidate.patch').write_text(''.join(patch))
logs=['linux-build.log','darwin-build.log','rosetta-checkptr.log','cpuoff.log','dsp-build.log','darwin-ordinary-build.log','dsp-one-shot.log','dsp-cpuoff-one-shot.log','binary-buildinfo.txt','snapshot-proof.json']
for f in logs:
 p=out/'validation'/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2('/private/tmp/govpx-sse8-direct-fence-'+f,p)
for src,dst in [('govpx-sse8-direct-fence-linux-llvm.txt','candidate-linux.txt'),('govpx-sse8-direct-fence-darwin-ordinary-llvm.txt','candidate-darwin.txt'),('govpx-sse8-root-final-linux-llvm.txt','parent-linux.txt')]:
 p=out/'codegen'/dst;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2('/private/tmp/'+src,p)
sdk=pathlib.Path('/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/src/cmd/compile/internal/ssagen/intrinsics.go')
lines=sdk.read_text().splitlines(True)
(out/'sdk-intrinsics-snippet.txt').write_text('Source: '+str(sdk)+'\nFull-source SHA256: '+sha(sdk)+'\nLines 1674-1687:\n'+''.join(lines[1673:1687]))

def functions(path):
 parts=re.split(r'(?m)^([0-9a-f]+) <([^>]+)>:\n',path.read_text());d={}
 for i in range(1,len(parts),3):
  sym,body=parts[i+1:i+3]
  if not sym.endswith(('pixel.SSE8Ptr','pixel.sse8RowsWide')):continue
  ins=[]
  for line in body.splitlines():
   m=re.match(r'\s*([0-9a-f]+):\s+(?:[0-9a-f]{2}\s+)+\s*(\S+)(.*)',line)
   if m:ins.append((m[1],m[2],m[3].strip()))
  d[sym]={'total_decoded_instructions_including_cold_paths_and_alignment_padding':len(ins),'vzeroupper_count':sum(m=='vzeroupper' for _,m,a in ins),'calls':[a for _,m,a in ins if m.startswith('call')],'legacy_vector_instructions':[[m,a] for _,m,a in ins if ('%xmm' in a or '%ymm' in a) and not m.startswith('v')],'return_regions':[ins[max(0,j-5):j+5] for j,(_,m,_) in enumerate(ins) if m=='vzeroupper']}
 return d
checks={}
for f in ['dsp-one-shot.log','dsp-cpuoff-one-shot.log']:
 t=(out/'validation'/f).read_text();rows=[l for l in t.splitlines() if re.match(r'^BenchmarkSSE8RowsNative/.*\s+1\s+',l)]
 checks[f]={'fixture_count':len(rows),'ends_PASS':t.rstrip().endswith('PASS'),'all_one_shot_allocation_readings_zero':all(re.search(r'\b0 B/op\s+0 allocs/op$',l) for l in rows)}
 assert len(rows)==36 and checks[f]['ends_PASS'] and checks[f]['all_one_shot_allocation_readings_zero']
proof={'scope':'private correctness and generated-code assessment only; no performance acceptance claim','base':base,'snapshot':json.loads((out/'validation/snapshot-proof.json').read_text()),'codegen':{n:functions(out/'codegen'/n) for n in ['parent-linux.txt','candidate-linux.txt','candidate-darwin.txt']},'one_shot_checks':checks,'binary_hashes':{str(p):sha(p) for p in map(pathlib.Path,['/private/tmp/govpx-sse8-direct-fence-linux.test','/private/tmp/govpx-sse8-direct-fence-darwin.test','/private/tmp/govpx-sse8-direct-fence-darwin-ordinary.test','/private/tmp/govpx-sse8-direct-fence-dsp-darwin-checkptr.test'])},'sdk_full_source_sha256':sha(sdk)}
(out/'audit.json').write_text(json.dumps(proof,indent=2)+'\n')
(out/'REPORT.md').write_text('''# Private AMD SSE8 direct return-fence assessment

Base: `c638b7c76eac857affa0780820e86c211cdd84d3` (PR42 remains frozen). Go 1.27.2, GOEXPERIMENT=simd, GOAMD64=v1, PGO off. This package changes no root files. It contains no native or emulated performance result or acceptance claim. One-shot fixture timing columns are correctness-run output only.

Exactly two of 1,876 checked Go/module files differ from the base. Each change removes a deferred ClearAVXUpperBits and extracts the reduction into a scalar result, executes ClearAVXUpperBits directly, then returns. Arithmetic, row order, geometry, dispatch and fallbacks are unchanged.

## Contract and cleanup review

The slice entry checks Enabled and bounds `h` to 1..64 and nonnegative strides below 2^30. Both original last-byte checks execute before the exact-window helper. Monotone row offsets are below 2^36, and each load reads exactly eight bytes. Read-only overlapping/zero-stride rows and unaligned addresses remain supported. The pointer entry retains the existing trusted complete-8x8-window contract and declines unsupported CPU, nil pointers or unusual strides through the exact original unsafe.Slice/SSE8 expression before any YMM arithmetic. Integer terminal offsets are not dereferenced as pointers.

Eligible valid fast paths contain no Go bounds checks or other language-level panic sites after wide-vector work starts. Direct SDK lowering is a memory-effect VZEROUPPER. Both optimized targets extract the result into EAX before the fence; VZEROUPPER does not alter EAX or other general-purpose registers, and no vector value is live afterward. There is one fence on each normal SIMD return. Fallback exceptions occur before any YMM instruction in the pointer path.

Removing defer also removes its exceptional-unwind cleanup. A nonnil but undersized, dangling or otherwise invalid pointer violates the preexisting trusted pointer contract. A memory fault or checkptr failure after entering the unsafe SIMD path is not promised a fence during unwinding by this variant. The valid-window contract is not widened. Nil/invalid-stride fallback diagnostics remain tested and unchanged. The internal slice helper similarly requires its guarded caller; direct calls with invalid geometry are outside its contract.

## Correctness and code generation

The root-supplied selected Rosetta pixel log passes exact windows, exhaustive byte pairs, aliases, short bounds/fallback, invalid-geometry subprocess diagnostics and squared-error tests under checkptr=1 (confirmed in binary build metadata). Independent CPU AVX/AVX2-off execution passes pointer/fallback and public squared-error tests with AVX2=false and Enabled=false; SIMD-only tests skip as intended.

A fresh public DSP binary uses checkptr=2. All 36 identical scalar/canary fixtures pass both with AVX2 selected and with actual CPU AVX/AVX2 disabled, one operation per fixture, with zero B/op and allocs/op readings. This is correctness and dispatch evidence, not a throughput measurement.

Optimized Linux original/candidate total decoded instruction counts (including cold paths/alignment padding) are SSE8Ptr 180 -> 149 and sse8RowsWide 125 -> 90. Fresh optimized Darwin candidate matches 149/90. Each candidate body has one inline VZEROUPPER, no ClearAVXUpperBits call, no deferreturn call and no legacy vector instructions. The rows helper has no calls; pointer calls are confined to scalar fallback, panic and stack-growth paths before SIMD. Parent code has actual ClearAVXUpperBits and deferreturn calls plus XMM15 stack-zero bookkeeping. Counts diagnose code generation only; native speed remains unmeasured.

## Contents and reproduction

`parent/` and `candidate/` pin the two changed sources; `context/` pins the public call chain, test fixtures and wrapper. `candidate.patch` applies to the exact base. `audit.json`, SDK snippet, original and candidate LLVM logs, build metadata and complete raw correctness logs preserve the proof. Binary hashes are recorded; large binaries are not copied. `reproduce.sh` uses the root project wrapper and creates a private source snapshot from the pinned base. Run only in a coordinated correctness window. `SHA256SUMS` covers every package member except itself.
''')
(out/'reproduce.sh').write_text('''#!/bin/sh
set -eu
# Correctness only. Coordinate the Go build window before executing.
root=${GOVPX_ROOT:-/Users/thesyncim/GolandProjects/govpx}
package=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
work=$(mktemp -d /private/tmp/govpx-sse8-fence-repro.XXXXXX)
git -C "$root" archive c638b7c76eac857affa0780820e86c211cdd84d3 | tar -x -C "$work"
cp "$package/candidate/internal/pixel/sse8_ptr_amd64.go" "$work/internal/pixel/"
cp "$package/candidate/internal/pixel/sse8_rows_wide_amd64.go" "$work/internal/pixel/"
export CODEX_AGENT_ID=ci-sse8-fence-repro CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local GOMAXPROCS=2 GOFLAGS=-p=2
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go GOOS=darwin GOARCH=amd64 GOAMD64=v1
cd "$root"
./scripts/go.sh -C "$work" test -pgo=off -gcflags=all=-d=checkptr=2 -c -o "$work/pixel.test" ./internal/pixel
./scripts/go.sh -C "$work" test -pgo=off -gcflags=all=-d=checkptr=2 -c -o "$work/dsp.test" ./internal/vp8/dsp
ROSETTA_ADVERTISE_AVX=1 GOVPX_REQUIRE_SIMD=1 arch -x86_64 "$work/pixel.test" -test.run 'Test(SSE8|SquaredError)' -test.v
ROSETTA_ADVERTISE_AVX=1 GODEBUG=cpu.avx=off,cpu.avx2=off arch -x86_64 "$work/pixel.test" -test.run 'Test(SSE8|SquaredError)' -test.v
ROSETTA_ADVERTISE_AVX=1 GOVPX_REQUIRE_SIMD=1 arch -x86_64 "$work/dsp.test" -test.run 'Test(SquaredError|SSE8)' -test.bench '^BenchmarkSSE8RowsNative$' -test.benchtime=1x -test.count=1 -test.cpu=1
ROSETTA_ADVERTISE_AVX=1 GODEBUG=cpu.avx=off,cpu.avx2=off arch -x86_64 "$work/dsp.test" -test.run 'Test(SquaredError|SSE8)' -test.bench '^BenchmarkSSE8RowsNative$' -test.benchtime=1x -test.count=1 -test.cpu=1
''')
shutil.copy2('/private/tmp/govpx-package-sse8-direct-fence.py',out/'package-evidence.py')
manifest=[]
for p in sorted(out.rglob('*')):
 if p.is_file():manifest.append(sha(p)+'  '+str(p.relative_to(out)))
(out/'SHA256SUMS').write_text('\n'.join(manifest)+'\n')
print(json.dumps({'out':str(out),'members_excluding_manifest':len(manifest),'manifest_sha256':sha(out/'SHA256SUMS')},indent=2))

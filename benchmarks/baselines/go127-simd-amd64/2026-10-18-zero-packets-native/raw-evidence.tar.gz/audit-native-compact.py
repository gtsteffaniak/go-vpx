#!/usr/bin/env python3
from pathlib import Path
import collections,itertools,json,re,statistics,sys
root=Path(sys.argv[1]); output=Path(sys.argv[2])
binding=json.loads((root/'binding.json').read_text()); status=json.loads((root/'status.json').read_text())
assert status['complete'] and status['phase']=='complete'
assert binding['commits']=={'parent':'5c5cf3977052368746325c4033a1909e7eacd26a','current':'2366eb72882de11ea9758270fac9524b27b88123'}
assert binding['PGO']=='off' and binding['CGO_ENABLED']==1 and binding['GOMAXPROCS']==1
features=binding['actual_SDK_features']; assert features['AVX2'] and features['Enabled']
wide=features['AVX512']; marker=('--- PASS: ' if wide else '--- SKIP: ')+'TestFP32NativeSelectedOracles'
for v in ('parent','current'):
 for race in ('False','True'):
  text=(root/f'correctness/{v}-selected-race{race}.txt').read_text()
  assert all(s in text for s in ['numeric cases=7568','alias full-backing cases=450','pre-write panic cases=30','full-backing cases=60 plus literal',marker])
  assert not re.search(r'(^FAIL|--- FAIL:)',text,re.M)
 text=(root/f'correctness/{v}-post-timing-packets.txt').read_text()
 assert 'full-backing cases=60 plus literal' in text and 'numeric cases=7568' in text and text.rstrip().endswith('PASS')
 host=(root/f'correctness/{v}-host.txt').read_text()
 assert f'FP32PublicHost AVX512={str(wide).lower()} AVX2=true Enabled=true' in host
names={
 'pixel':{f'BenchmarkFP32PublicOptionalNative/n{n}/qnil{q}/classes{c}/{pattern}/{a}' for n,q,c,pattern,a in itertools.product((64,256),('false','true'),('false','true'),('zero','sparse','dense'),('aligned64','offset2-classes1'))},
 'encoder':{f'BenchmarkVP9FP16Native/n{n}/{c}/{pattern}/{a}' for n,c,pattern,a in itertools.product((16,64,256),('no-classes','classes'),('zero','sparse','dense'),('aligned32','offset2-classes1'))}
}
raw=collections.defaultdict(lambda:{'parent':[],'current':[]})
line_re=re.compile(r'(Benchmark\S+)\s+\d+\s+([\d.eE+\-]+) ns/op\s+0 B/op\s+0 allocs/op\s*')
rows=0
for number,v,kind in itertools.product(range(1,7),('parent','current'),('pixel','encoder')):
 seen=set()
 for line in (root/f'timed/r{number}-{v}-{kind}.txt').read_text().splitlines():
  if not line.startswith('Benchmark'):continue
  m=line_re.fullmatch(line); assert m,(number,v,kind,line)
  name=m[1]; assert name not in seen;seen.add(name);raw[name][v].append(float(m[2]));rows+=1
 assert seen==names[kind]
assert rows==1008 and len(raw)==84
components={}
for name,ns in raw.items():
 a,b=(statistics.median(ns[v]) for v in ('parent','current')); ratios=[a/b for a,b in zip(ns['parent'],ns['current'])]
 components[name]={'speedup':a/b,'paired_speedups':ratios,'slower_pairs':sum(x<1 for x in ratios),'all_pairs_faster':all(x>1 for x in ratios),'all_pairs_slower':all(x<1 for x in ratios),'minimum_pair':min(ratios),'raw_ns':ns}
groups={}
for pattern in ('zero','sparse','dense'):
 group=[x for name,x in components.items() if '/'+pattern+'/' in name]
 assert len(group)==28
 groups[pattern]={'cases':len(group),'median_range':[min(x['speedup'] for x in group),max(x['speedup'] for x in group)],'median_losses':sum(x['speedup']<1 for x in group),'all_pairs_slower_cases':sum(x['all_pairs_slower'] for x in group),'slower_pairs':sum(x['slower_pairs'] for x in group),'ge1_5_cases':sum(x['speedup']>=1.5 for x in group)}
ignored={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'}
whole={}
for case in ('vp9-320','vp9-720'):
 data={v:[json.loads((root/f'timed/r{i}-{v}-{case}.json').read_text()) for i in range(1,7)] for v in ('parent','current')}
 semantic=[{k:v for k,v in row.items() if k not in ignored} for xs in data.values() for row in xs]
 assert all(x==semantic[0] and len(x)==22 for x in semantic)
 ns={v:[r['ns_per_frame'] for r in xs] for v,xs in data.items()}
 pairs=[100*(a/b-1) for a,b in zip(ns['current'],ns['parent'])]
 whole[case]={'raw_ns_per_frame':ns,'median_time_change_pct':100*(statistics.median(ns['current'])/statistics.median(ns['parent'])-1),'paired_time_change_pct':pairs,'slower_pairs':sum(x>0 for x in pairs),'semantic_fields_equal':22,'allocations':{v:[r['allocs_per_frame'] for r in xs] for v,xs in data.items()}}
reported=json.loads((root/'summary.json').read_text())
assert all(abs(components[n]['speedup']-reported['components'][n]['speedup'])<1e-12 for n in components)
assert all(abs(whole[n]['median_time_change_pct']-reported['whole'][n]['median_time_change_pct'])<1e-10 for n in whole)
counts=json.loads((root/'counts/interpretation.json').read_text());assert counts['throughput_excluded']
for case in whole:
 assert json.loads((root/f'counts/parent-{case}.json').read_text())==json.loads((root/f'counts/current-{case}.json').read_text())
counts['workloads']={case:row|{'zero_packet_fraction':row['zero_packets']/row['packets']} for case,row in counts['workloads'].items()}
cpu=[line for line in (root/'lscpu.txt').read_text().splitlines() if re.match(r'(Model name|CPU\(s\)|Vendor ID):',line)]
result={'scope':'Compact independent raw audit. Uses driver-enforced source/binary bindings; no repeated broad inventories or artifact rehashing.','status':status,'commits':binding['commits'],'actual_SDK_features':features,'cpu':cpu,'oracles':'Both references ordinary/race/checkptr plus post-timing packet fixtures PASS; native512 required only when actual feature true.','component_rows':rows,'zero_component_allocations':True,'groups':groups,'components':components,'whole':whole,'diagnostic_counts':counts,'material_losses_lt_0_98':sorted([{'name':n,'speedup':x['speedup'],'slower_pairs':x['slower_pairs']} for n,x in components.items() if x['speedup']<.98],key=lambda x:x['speedup']),'qualifying_medians_ge_1_5':sorted([{'name':n,'speedup':x['speedup'],'minimum_pair':x['minimum_pair'],'slower_pairs':x['slower_pairs']} for n,x in components.items() if x['speedup']>=1.5],key=lambda x:-x['speedup'])}
output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('actual_SDK_features','cpu','groups','whole','diagnostic_counts','material_losses_lt_0_98','qualifying_medians_ge_1_5')},indent=2))

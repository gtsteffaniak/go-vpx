
/private/tmp/govpx-avx512-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000566a80 <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512>:
  566a80: 49 3b 66 10                  	cmpq	0x10(%r14), %rsp
  566a84: 0f 86 db 01 00 00            	jbe	0x566c65 <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512+0x1e5>
  566a8a: 55                           	pushq	%rbp
  566a8b: 48 89 e5                     	movq	%rsp, %rbp
  566a8e: 48 83 ec 28                  	subq	$0x28, %rsp
  566a92: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
  566a97: 66 44 0f d6 7c 24 20         	movq	%xmm15, 0x20(%rsp)
  566a9e: 48 89 74 24 60               	movq	%rsi, 0x60(%rsp)
  566aa3: c6 44 24 07 00               	movb	$0x0, 0x7(%rsp)
  566aa8: 48 c7 44 24 08 00 00 00 00   	movq	$0x0, 0x8(%rsp)
  566ab1: 48 8d 15 90 75 1f 00         	leaq	0x1f7590(%rip), %rdx    # 0x75e048 <go:funcdesc+0x310>
  566ab8: 48 89 54 24 20               	movq	%rdx, 0x20(%rsp)
  566abd: c6 44 24 07 01               	movb	$0x1, 0x7(%rsp)
  566ac2: 62 f1 fd 48 ef c0            	vpxorq	%zmm0, %zmm0, %zmm0
  566ac8: 31 d2                        	xorl	%edx, %edx
  566aca: 31 db                        	xorl	%ebx, %ebx
  566acc: 4c 8b 44 24 38               	movq	0x38(%rsp), %r8
  566ad1: eb 4d                        	jmp	0x566b20 <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512+0xa0>
  566ad3: 62 f3 fd 48 3b c2 00         	vextracti64x4	$0x0, %zmm0, %ymm2
  566ada: 62 f3 fd 48 3b c3 01         	vextracti64x4	$0x1, %zmm0, %ymm3
  566ae1: c5 ed fe d3                  	vpaddd	%ymm3, %ymm2, %ymm2
  566ae5: c4 e3 7d 39 d3 00            	vextracti128	$0x0, %ymm2, %xmm3
  566aeb: c4 e3 7d 39 d2 01            	vextracti128	$0x1, %ymm2, %xmm2
  566af1: c5 e9 fe d3                  	vpaddd	%xmm3, %xmm2, %xmm2
  566af5: c5 f9 70 da 4e               	vpshufd	$0x4e, %xmm2, %xmm3     # xmm3 = xmm2[2,3,0,1]
  566afa: c5 e1 fe d2                  	vpaddd	%xmm2, %xmm3, %xmm2
  566afe: c5 f9 70 da b1               	vpshufd	$0xb1, %xmm2, %xmm3     # xmm3 = xmm2[1,0,3,2]
  566b03: c5 e1 fe d2                  	vpaddd	%xmm2, %xmm3, %xmm2
  566b07: c4 c3 79 16 d4 00            	vpextrd	$0x0, %xmm2, %r12d
  566b0d: 45 89 e4                     	movl	%r12d, %r12d
  566b10: 4c 01 e2                     	addq	%r12, %rdx
  566b13: 62 f1 fe 48 7f c8            	vmovdqu64	%zmm1, %zmm0
  566b19: 0f 1f 80 00 00 00 00         	nopl	(%rax)
  566b20: 49 39 d8                     	cmpq	%rbx, %r8
  566b23: 0f 8e f0 00 00 00            	jle	0x566c19 <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512+0x199>
  566b29: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
  566b2e: 4c 8d 63 04                  	leaq	0x4(%rbx), %r12
  566b32: 4d 39 e0                     	cmpq	%r12, %r8
  566b35: 4d 0f 4c e0                  	cmovlq	%r8, %r12
  566b39: 62 f1 fe 48 7f c1            	vmovdqu64	%zmm0, %zmm1
  566b3f: 90                           	nop
  566b40: eb 10                        	jmp	0x566b52 <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512+0xd2>
  566b42: 48 8b 5c 24 10               	movq	0x10(%rsp), %rbx
  566b47: 48 ff c3                     	incq	%rbx
  566b4a: 4c 8b 44 24 38               	movq	0x38(%rsp), %r8
  566b4f: 4d 89 fb                     	movq	%r15, %r11
  566b52: 4c 39 e3                     	cmpq	%r12, %rbx
  566b55: 0f 8d 78 ff ff ff            	jge	0x566ad3 <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512+0x53>
  566b5b: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
  566b60: 49 89 dd                     	movq	%rbx, %r13
  566b63: 48 0f af df                  	imulq	%rdi, %rbx
  566b67: 4e 8d 3c 1b                  	leaq	(%rbx,%r11), %r15
  566b6b: 4d 0f af ea                  	imulq	%r10, %r13
  566b6f: 4c 39 f9                     	cmpq	%r15, %rcx
  566b72: 0f 82 d7 00 00 00            	jb	0x566c4f <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512+0x1cf>
  566b78: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)
  566b80: 4c 39 fb                     	cmpq	%r15, %rbx
  566b83: 0f 87 c1 00 00 00            	ja	0x566c4a <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512+0x1ca>
  566b89: 4d 89 df                     	movq	%r11, %r15
  566b8c: 49 f7 db                     	negq	%r11
  566b8f: 49 c1 fb 3f                  	sarq	$0x3f, %r11
  566b93: 4c 21 db                     	andq	%r11, %rbx
  566b96: 4f 8d 44 3d 00               	leaq	(%r13,%r15), %r8
  566b9b: 48 01 c3                     	addq	%rax, %rbx
  566b9e: 66 90                        	nop
  566ba0: 4d 39 c1                     	cmpq	%r8, %r9
  566ba3: 0f 82 9c 00 00 00            	jb	0x566c45 <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512+0x1c5>
  566ba9: 4d 39 c5                     	cmpq	%r8, %r13
  566bac: 0f 87 8b 00 00 00            	ja	0x566c3d <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512+0x1bd>
  566bb2: 4d 21 eb                     	andq	%r13, %r11
  566bb5: 4e 8d 04 1e                  	leaq	(%rsi,%r11), %r8
  566bb9: 4d 8d 5f e0                  	leaq	-0x20(%r15), %r11
  566bbd: 45 31 ed                     	xorl	%r13d, %r13d
  566bc0: eb 3e                        	jmp	0x566c00 <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512+0x180>
  566bc2: 49 8d 74 1d 00               	leaq	(%r13,%rbx), %rsi
  566bc7: 62 f2 7d 48 30 16            	vpmovzxbw	(%rsi), %zmm2
  566bcd: 4b 8d 74 05 00               	leaq	(%r13,%r8), %rsi
  566bd2: 62 f2 7d 48 30 1e            	vpmovzxbw	(%rsi), %zmm3
  566bd8: 62 f1 6d 48 f9 d3            	vpsubw	%zmm3, %zmm2, %zmm2
  566bde: 62 f1 6d 48 f5 d2            	vpmaddwd	%zmm2, %zmm2, %zmm2
  566be4: 62 f1 7d 48 fe c2            	vpaddd	%zmm2, %zmm0, %zmm0
  566bea: 48 8b 74 24 60               	movq	0x60(%rsp), %rsi
  566bef: 49 89 d5                     	movq	%rdx, %r13
  566bf2: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
  566bf7: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
  566c00: 4d 39 dd                     	cmpq	%r11, %r13
  566c03: 0f 8f 39 ff ff ff            	jg	0x566b42 <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512+0xc2>
  566c09: 49 8d 55 20                  	leaq	0x20(%r13), %rdx
  566c0d: 49 39 d7                     	cmpq	%rdx, %r15
  566c10: 72 26                        	jb	0x566c38 <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512+0x1b8>
  566c12: 49 39 d5                     	cmpq	%rdx, %r13
  566c15: 76 ab                        	jbe	0x566bc2 <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512+0x142>
  566c17: eb 1a                        	jmp	0x566c33 <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512+0x1b3>
  566c19: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
  566c1e: c6 44 24 07 00               	movb	$0x0, 0x7(%rsp)
  566c23: e8 f8 93 f2 ff               	callq	0x490020 <simd/archsimd.ClearAVXUpperBits>
  566c28: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
  566c2d: 48 83 c4 28                  	addq	$0x28, %rsp
  566c31: 5d                           	popq	%rbp
  566c32: c3                           	retq
  566c33: e8 c8 68 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  566c38: e8 c3 68 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  566c3d: 0f 1f 00                     	nopl	(%rax)
  566c40: e8 bb 68 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  566c45: e8 b6 68 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  566c4a: e8 b1 68 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  566c4f: e8 ac 68 f2 ff               	callq	0x48d500 <runtime.panicBounds>
  566c54: 90                           	nop
  566c55: e8 e6 3a ee ff               	callq	0x44a740 <runtime.deferreturn>
  566c5a: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
  566c5f: 48 83 c4 28                  	addq	$0x28, %rsp
  566c63: 5d                           	popq	%rbp
  566c64: c3                           	retq
  566c65: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
  566c6a: 48 89 5c 24 18               	movq	%rbx, 0x18(%rsp)
  566c6f: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
  566c74: 48 89 7c 24 28               	movq	%rdi, 0x28(%rsp)
  566c79: 48 89 74 24 30               	movq	%rsi, 0x30(%rsp)
  566c7e: 4c 89 44 24 38               	movq	%r8, 0x38(%rsp)
  566c83: 4c 89 4c 24 40               	movq	%r9, 0x40(%rsp)
  566c88: 4c 89 54 24 48               	movq	%r10, 0x48(%rsp)
  566c8d: 4c 89 5c 24 50               	movq	%r11, 0x50(%rsp)
  566c92: e8 29 4c f2 ff               	callq	0x48b8c0 <runtime.morestack_noctxt.abi0>
  566c97: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
  566c9c: 48 8b 5c 24 18               	movq	0x18(%rsp), %rbx
  566ca1: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
  566ca6: 48 8b 7c 24 28               	movq	0x28(%rsp), %rdi
  566cab: 48 8b 74 24 30               	movq	0x30(%rsp), %rsi
  566cb0: 4c 8b 44 24 38               	movq	0x38(%rsp), %r8
  566cb5: 4c 8b 4c 24 40               	movq	0x40(%rsp), %r9
  566cba: 4c 8b 54 24 48               	movq	0x48(%rsp), %r10
  566cbf: 4c 8b 5c 24 50               	movq	0x50(%rsp), %r11
  566cc4: e9 b7 fd ff ff               	jmp	0x566a80 <github.com/thesyncim/govpx/internal/pixel.ssePlane32AVX512>
  566cc9: cc                           	int3
  566cca: cc                           	int3
  566ccb: cc                           	int3
  566ccc: cc                           	int3
  566ccd: cc                           	int3
  566cce: cc                           	int3
  566ccf: cc                           	int3
  566cd0: cc                           	int3
  566cd1: cc                           	int3
  566cd2: cc                           	int3
  566cd3: cc                           	int3
  566cd4: cc                           	int3
  566cd5: cc                           	int3
  566cd6: cc                           	int3
  566cd7: cc                           	int3
  566cd8: cc                           	int3
  566cd9: cc                           	int3
  566cda: cc                           	int3
  566cdb: cc                           	int3
  566cdc: cc                           	int3
  566cdd: cc                           	int3
  566cde: cc                           	int3
  566cdf: cc                           	int3

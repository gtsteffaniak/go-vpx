import hashlib,json,pathlib,re,statistics,subprocess
B=pathlib.Path('/private/tmp');R=B/'govpx-sse8-focused-ac259fce-artifact';H='ac259fce071f3ac5fc45603c6bd7e7926bdfcf73';BASE='2ca5bab1110426401e4f9dbfd6fa0da8f568c717';ASM='691cd0512c4829d9ee40d483205dd223f9eb028d';ROOT='/Users/thesyncim/GolandProjects/govpx'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
raw={str(f.relative_to(R)):sha(f.read_bytes()) for f in sorted(R.rglob('*')) if f.is_file()}
manifest={line.split('  ',1)[1]:line.split('  ',1)[0] for line in (R/'SHA256SUMS').read_text().splitlines()};assert {k:v for k,v in raw.items() if k!='SHA256SUMS'}==manifest
commits=json.loads((R/'commits.json').read_text());assert commits=={'head':H,'base':BASE,'assembly':ASM};status=json.loads((R/'status.json').read_text());assert status=={'exit_status':0,'phase':'complete'}
env=(R/'environment.txt').read_text();cpu=next(x.split(':',1)[1].strip() for x in env.splitlines() if x.startswith('Model name:'));assert 'go version go1.27.2 linux/amd64' in env
source={}
for variant,commit in commits.items():
 tree=subprocess.check_output(['git','ls-tree','-r',commit,'--','go.mod','go.sum','internal/pixel','internal/vp8/dsp'],cwd=ROOT);assert tree==(R/f'{variant}-git-tree.txt').read_bytes()
 expected={line.split('  ',1)[1]:line.split('  ',1)[0] for line in (R/f'{variant}-source-sha256.txt').read_text().splitlines()};paths=list(expected);q=''.join(commit+':'+p+'\n' for p in paths).encode();blob=subprocess.check_output(['git','cat-file','--batch'],input=q,cwd=ROOT);offset=0;actual={}
 for path in paths:
  end=blob.index(b'\n',offset);header=blob[offset:end].decode().split();assert header[1]=='blob';n=int(header[2]);data=blob[end+1:end+1+n];assert len(data)==n;actual[path]=sha(data);offset=end+1+n+1
 assert offset==len(blob) and actual==expected
 source[variant]={'commit':commit,'file_count':len(actual),'all_exact_git_hashes_match':True,'source_sha256':actual}
fixture=(R/'sse8_rows_native_test.go').read_bytes();expectedfixture=subprocess.check_output(['git','show',H+':internal/vp8/dsp/sse8_rows_native_test.go'],cwd=ROOT);assert fixture==expectedfixture
orders=[line.split(': ',1)[1].split() for line in (R/'orders.txt').read_text().splitlines()];assert len(orders)==6 and len({tuple(x) for x in orders})==6
for i in range(3):assert sorted(x[i] for x in orders)==['assembly','assembly','base','base','head','head']
pattern=re.compile(r'^(Benchmark\S+)\s+(\d+)\s+(?:([0-9.eE+-]+) ns/op\s+)?(?:[0-9.eE+-]+ MB/s\s+)?(\d+) B/op\s+(\d+) allocs/op$',re.M)
public={f'BenchmarkSSE8RowsNative/{api}/pitch{a}-{b}/pattern{p}' for api in ['slice8x4','slice8x8','slice8x16','pointer8x8'] for a,b in [(8,8),(32,37),(1312,1320)] for p in range(3)};legacy={'BenchmarkSSE8x4','BenchmarkSSE8x8','BenchmarkSSE8x16','BenchmarkSSE8x8PtrFast'};allcases=public|legacy
def parse(f,measured=True):
 txt=f.read_text();assert re.search('^PASS$',txt,re.M);rows={}
 for case,it,ns,b,a in pattern.findall(txt):
  assert case not in rows;rows[case]={'iterations':int(it),'ns':float(ns) if ns else None,'bytes':int(b),'allocs':int(a)};assert int(it)>0
  if measured:assert ns and float(ns)>0 and int(b)==int(a)==0
  elif case in public:assert int(b)==int(a)==0
 assert set(rows)==allcases;return rows
one={v:parse(R/f'{v}-one-shot.txt',False) for v in ['head','base','assembly']};samples={v:[parse(R/f'{v}-round-{i}.txt') for i in range(1,7)] for v in ['head','base','assembly']};results={}
for case in sorted(allcases):
 vals={v:[row[case]['ns'] for row in samples[v]] for v in samples};med={v:statistics.median(a) for v,a in vals.items()};bp=[b/h for b,h in zip(vals['base'],vals['head'])];ap=[a/h for a,h in zip(vals['assembly'],vals['head'])]
 results[case]={'protocol':'B.Loop public' if case in public else 'B.N legacy diagnostic','samples':{v:[row[case] for row in samples[v]] for v in samples},'median_ns':med,'base_over_head':med['base']/med['head'],'old_ASM_over_head':med['assembly']/med['head'],'head_time_change_percent':100*(med['head']/med['base']-1),'base_head_paired_ratios':bp,'old_ASM_head_paired_ratios':ap,'pairs_head_faster':sum(x>1 for x in bp),'pairs_head_slower':sum(x<1 for x in bp),'all_pairs_ge_1_5':all(x>=1.5 for x in bp)}
reported=json.loads((R/'summary.json').read_text());assert len(reported['results'])==40
for row in reported['results']:
 own=results[row['case']]
 for k in ['median_ns','base_over_head','head_time_change_percent','base_head_paired_ratios']:assert own[k]==row[k]
 assert own['old_ASM_over_head']==row['assembly_over_head'];assert own['pairs_head_slower']==row['pairs_head_slower']
logs={}
for name in ['head-dispatch.txt','head-correctness.txt','head-race-checkptr2.txt']:
 t=(R/name).read_text();logs[name]={'pass':re.findall(r'^--- PASS: (\S+)',t,re.M),'allpass':re.findall(r'^\s*--- PASS: (\S+)',t,re.M),'fail':re.findall(r'^\s*--- FAIL: (\S+)',t,re.M),'skip':re.findall(r'^\s*--- SKIP: (\S+)',t,re.M),'feature_lines':[x for x in t.splitlines() if 'AVX2=' in x or 'native SIMD=' in x]};assert not logs[name]['fail'] and not logs[name]['skip']
assert 'native SIMD=true' in (R/'head-dispatch.txt').read_text()
text='\n'.join((R/x).read_text() for x in ['head-correctness.txt','head-race-checkptr2.txt']);feature=re.findall(r'AVX2=(true|false) Enabled=(true|false)',text);assert len(feature)>=4 and all(x==('true','true') for x in feature)
top=[t for row in logs.values() for t in row['pass']];names=['TestSSE8PtrExactWindows','TestSSE8PtrFallbackPanics','TestSSE8RowsWideDispatch','TestSSE8EntryDisabledScalar'];assert all(top.count(x)==2 for x in names)
fs={k:v for k,v in results.items() if k in public}
def group(fs):
 vs=list(fs.values());return {'cases':len(vs),'median_speedup_range':[min(v['base_over_head'] for v in vs),max(v['base_over_head'] for v in vs)],'min_pair_speedup':min(x for v in vs for x in v['base_head_paired_ratios']),'all6_faster_cases':sum(v['pairs_head_faster']==6 for v in vs),'median_slower_cases':sum(v['head_time_change_percent']>0 for v in vs),'all6_slower_cases':sum(v['pairs_head_slower']==6 for v in vs),'all6_ge1_5_cases':sum(v['all_pairs_ge_1_5'] for v in vs)}
out={'head_sha':H,'base_sha':BASE,'old_ASM_sha':ASM,'workflow_run_id':39098241911,'cpu':cpu,'environment':env,'source_proof':source,'fixture_exact_head':True,'orders':orders,'measured_samples':720,'all720_zero_bytes_allocs':True,'one_shot_samples_excluded':120,'one_shot_samples':one,'all40_results':results,'public36_summary':group(fs),'public_api_summaries':{api:group({k:v for k,v in fs.items() if '/'+api+'/' in k}) for api in ['slice8x4','slice8x8','slice8x16','pointer8x8']},'validation':logs,'all_required_dispatch_and_new_tests_pass':True,'all_raw_hashes_verified':True,'raw_sha256':raw,'native_scope':'PR45 FP/DC changes outside SSE8; all 36 SSE8 and 4 legacy AMD cases are unchanged-source controls; native timing changes remain acceptance-relevant and are not dismissed as noise. No wholecodec/crossCPU/newAMDgain claim. Focused job never grants merge approval.'}
control_paths=['internal/pixel/sse_simd.go','internal/pixel/sse8_rows_wide_amd64.go','internal/pixel/sse8_ptr_amd64.go','internal/vp8/dsp/sse8_rows_native_test.go','internal/vp8/dsp/variance_block_sized_other.go']
out['unchanged_SSE8_control_sources']={n:source['head']['source_sha256'][n]==source['base']['source_sha256'][n] for n in control_paths};assert all(out['unchanged_SSE8_control_sources'].values())
vs=list(fs.values());out['public36_old_reference_scope']={'median_ratio_range':[min(r['old_ASM_over_head'] for r in vs),max(r['old_ASM_over_head'] for r in vs)],'all36_medians_faster':all(r['old_ASM_over_head']>1 for r in vs),'minimum_paired_ratio':min(z for r in vs for z in r['old_ASM_head_paired_ratios']),'all6_faster_case_count':sum(all(z>1 for z in r['old_ASM_head_paired_ratios']) for r in vs)}
write(B/'govpx-ac259fce-focused-compact.json',out);write(B/'govpx-sse8-focused-ac259fce-files.json',raw)
print(json.dumps({'cpu':cpu,'public36':out['public36_summary'],'apis':out['public_api_summaries'],'audit':str(B/'govpx-ac259fce-focused-compact.json')},indent=2))

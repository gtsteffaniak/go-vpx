import pathlib,hashlib,json,re,subprocess,statistics
P=pathlib.Path('/private/tmp/govpx-amd64-ac259fce-artifact')
HEAD='ac259fce071f3ac5fc45603c6bd7e7926bdfcf73'; BASE='2ca5bab1110426401e4f9dbfd6fa0da8f568c717'; OLD='691cd0512c4829d9ee40d483205dd223f9eb028d'
V=('assembly','previous','simd')
manifest=json.loads(pathlib.Path('/private/tmp/govpx-amd64-ac259fce-files.json').read_text())
assert len(manifest)==91,len(manifest)
for f,h in manifest.items():assert hashlib.sha256((P/f).read_bytes()).hexdigest()==h,f
env=(P/'environment.txt').read_text(); assert env.splitlines()[:3]==['assembly commit: '+OLD,'previous SIMD commit: '+BASE,'SIMD commit: '+HEAD]
paths=json.loads(pathlib.Path('/private/tmp/govpx-next45-harness-scope.json').read_text())['source_SHAs']; assert len(paths)==len(set(paths))==63
shas={}
for path in paths:
 matches=[m[1] for line in env.splitlines() for m in [re.match(r'([0-9a-f]{64})  .*/govpx/govpx/(.+)$',line)] if m and m[2]==path]
 assert len(matches)==1,(path,matches)
 want=hashlib.sha256(subprocess.check_output(['git','show',HEAD+':'+path])).hexdigest();assert matches[0]==want,path;shas[path]=want
BENCH=re.compile(r'(Benchmark\S+)\s+(\d+)\s+(\S+)\s+ns/op.*?\s+(\S+)\s+B/op\s+(\S+)\s+allocs/op')
def samples(text):
 pkg='';out={}
 for line in text.splitlines():
  if line.startswith('pkg: '):pkg=line[5:]
  m=BENCH.match(line)
  if m:
   assert float(m[4])==float(m[5])==0,(line,'alloc')
   out.setdefault(pkg+'/'+m[1],[]).append({'n':int(m[2]),'ns':float(m[3])})
 return out
ks={v:samples((P/(v+'-kernels.txt')).read_text()) for v in V}
assert all(len(k)==463 and all(len(a)==6 for a in k.values()) for k in ks.values())
assert all(ks[v].keys()==ks['simd'].keys() for v in V)
orders=[line.split(': ',1)[1].split() for line in (P/'orders.txt').read_text().splitlines()]
assert len(orders)==6 and len(set(map(tuple,orders)))==6
for col in range(3):assert sorted(row[col] for row in orders)==['assembly','assembly','previous','previous','simd','simd']
allk={}
for key in ks['simd']:
 med={v:statistics.median(x['ns'] for x in ks[v][key]) for v in V}
 pairs={v:[a['ns']/b['ns'] for a,b in zip(ks[v][key],ks['simd'][key])] for v in ('previous','assembly')}
 allk[key]={'median_ns':med,'parent_speedup':med['previous']/med['simd'],'old_speedup':med['assembly']/med['simd'],'all6_paired_speedups':pairs}
fp={k:x for k,x in allk.items() if 'BenchmarkVP9FP16Native/' in k};assert len(fp)==36
eligible={k:x for k,x in fp.items() if '/n16/' not in k};assert len(eligible)==24
fp_old10={k:x for k,x in allk.items() if 'BenchmarkVP9FusedFPClassesNative/' in k or 'BenchmarkVP9FPNoClassesNative' in k};assert len(fp_old10)==10
controls={k:x for k,x in allk.items() if k not in fp and k not in fp_old10}
# These one-shot results are separate correctness preflights, never timed-kernel samples.
ones={}
for name in [v+'-fp16-fixture-validation.txt' for v in V]+['simd-fp16-cpuoff-fixture-validation.txt']:
 s=samples((P/name).read_text());assert len(s)==36 and all(len(a)==1 and a[0]['n']==1 for a in s.values());ones[name]=len(s)
log=(P/'quant-batch-validation.txt').read_text();dc=samples(log);assert len(dc)==27 and all(len(a)==3 and all(x['n']==1 for x in a) for a in dc.values());assert log.count('--- PASS: TestFusedDCSupplementState ')==2;assert log.count('# DC preflight: ')==3
flog=(P/'fp16-validation.txt').read_text();assert '--- FAIL' not in flog
assert flog.count('--- PASS: TestFP16Selected ')==4
assert flog.count('Enabled=true AVX2=true')==2 and flog.count('Enabled=false AVX2=false')==2
for name in ['TestFP16DisjointScalar','TestFP16AllSignedCoefficients','TestFP16UnalignedMinimum','TestFP16AliasedStoreOrder','TestFP16OriginalFallback','TestFP16Disabled']:assert flog.count('--- PASS: '+name+' ')==4,name
assert '--- FAIL' not in log
for name in ['TestCopy16RowsPublicState','TestCopy8RowsPublicState']:assert log.count('--- PASS: '+name+' ')==4,name
for name in ['TestSSE8PtrExactWindows','TestSSE8PtrFallbackPanics','TestSSE8RowsWideDispatch','TestSSE8EntryDisabledScalar','TestDenseTokenPrivateScalarComponent','TestDenseTokenPrivateStreamReference','TestDenseTokenPrepackAvailability']:assert log.count('--- PASS: '+name+' ')==2,name
assert log.count('--- SKIP: TestDenseTokenPrivatePrepack ')==2
active=log.count('AVX2=true AVX512=true;')==2
assert log.count(('--- PASS: ' if active else '--- SKIP: ')+'TestSSEPlane16AVX512 ')==2
for name in ['TestSADWideAVX2Rows','TestSADWideAVX2FallbackAndBounds','TestSADWideAVX2NilInputs','TestSADWideAVX2Disabled']:assert log.count('--- PASS: '+name+' ')==4,name
assert log.count('--- PASS: TestSADWideAVX2Selected ')==2 and log.count('--- SKIP: TestSADWideAVX2Selected ')==2
assert log.count('Enabled=false actual AVX2=false')==2
for name in ['dispatch.txt','previous-dispatch.txt']:assert '--- PASS: TestBackendSelected ' in (P/name).read_text()
ignore={'ns_per_frame','encode_fps','macroblocks_per_second','latency_ns','allocs_per_frame'};public={};profiles={}
for label,pat in [('VP9320','{v}-encoder-{i}.json'),('VP8720','{v}-vp8-720p-encoder-{i}.json'),('VP9720','{v}-vp9-720p-encoder-{i}.json')]:
 rows={v:[json.loads((P/pat.format(v=v,i=i)).read_text()) for i in range(1,7)] for v in V};rr=[r for a in rows.values() for r in a];fields=set(rr[0])-ignore
 assert len(fields)==22 and all({k:r[k] for k in fields}=={k:rr[0][k] for k in fields} for r in rr)
 med={v:statistics.median(r['ns_per_frame'] for r in a) for v,a in rows.items()}
 public[label]={'median_ns':med,'vs_parent_percent':100*(med['simd']/med['previous']-1),'vs_old_percent':100*(med['simd']/med['assembly']-1),'all6_paired_time_differences_percent':{v:[100*(a['ns_per_frame']/b['ns_per_frame']-1) for a,b in zip(rows['simd'],rows[v])] for v in ('previous','assembly')},'all_allocations':{v:[r['allocs_per_frame'] for r in a] for v,a in rows.items()},'all22_semantics_equal':True}
for codec in ('vp8','vp9'):
 rows={v:json.loads((P/(v+'-'+codec+'-720p-profile.json')).read_text()) for v in V};fields=set(rows['simd'])-ignore;assert len(fields)==22
 assert all({k:r[k] for k in fields}=={k:rows['simd'][k] for k in fields} for r in rows.values())
 profiles[codec]={'all22_semantics_equal':True,'all_allocations':{v:r['allocs_per_frame'] for v,r in rows.items()}}
for path in ['internal/pixel/sse_plane_amd64.go','internal/pixel/sse8_rows_wide_amd64.go','internal/pixel/sse8_ptr_amd64.go','internal/pixel/sad_amd64.go','internal/pixel/subtract_rows_amd64.go']:
 assert subprocess.check_output(['git','show',HEAD+':'+path])==subprocess.check_output(['git','show',BASE+':'+path]),path
out={'head':HEAD,'base':BASE,'native_files_verified':len(manifest),'git_source_shas_verified':shas,'kernel_cases':463,'kernel_samples':463*6*3,'all_kernel_allocations_zero':True,'all463_kernel_results':allk,'all36_FP_results':fp,'eligible24_FP_results':eligible,'old10_FP_results':fp_old10,'all_controls':controls,'controls_median_slower':sum(x['parent_speedup']<1 for x in controls.values()),'controls_all6_slower':sum(max(x['all6_paired_speedups']['previous'])<1 for x in controls.values()),'FP_medians_at_least_1_5':sum(x['parent_speedup']>=1.5 for x in eligible.values()),'FP_all6_pairs_at_least_1_5':sum(min(x['all6_paired_speedups']['previous'])>=1.5 for x in eligible.values()),'public':public,'profiles':profiles,'avx512_active':active,'expected_225_one_shots_excluded':{'FP':ones,'DC':81},'FP_4_actual_feature_probe_PASS':True,'all28_reference_fixture_scope':'harness independently reviewed; all3 one-shot outputs validated'}
pathlib.Path('/private/tmp/govpx-root-ac259fce-full-proof.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['git_source_shas_verified','all463_kernel_results','all36_FP_results','eligible24_FP_results','old10_FP_results','all_controls']},indent=2))

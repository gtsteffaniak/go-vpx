import pathlib,subprocess,shutil,os,json,re
w=pathlib.Path('/private/tmp/govpx-sse8-pointer-carry-review');root=pathlib.Path('/Users/thesyncim/GolandProjects/govpx');snap=w/'candidate';snap.mkdir(exist_ok=True);out=w/'validation';out.mkdir(exist_ok=True)
p=subprocess.Popen(['git','archive','46a08f8e6eb03f6ee4549d975384bd6c952a81fa'],cwd=root,stdout=subprocess.PIPE);subprocess.run(['tar','-x','-C',str(snap)],stdin=p.stdout,check=True);p.stdout.close();assert p.wait()==0
f=w/'sse8_ptr_amd64.go';subprocess.run(['/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/gofmt','-w',str(f)],check=True);shutil.copyfile(f,snap/'internal/pixel/sse8_ptr_amd64.go')
env=os.environ.copy();env.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-ssecarry',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',GOOS='darwin',GOARCH='amd64',GOAMD64='v1',CGO_ENABLED='1');records=[]
def run(name,args,extra={}):
 e=env.copy();e.update(extra);p=subprocess.run(args,cwd=root,env=e,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/(name+'.log')).write_text(p.stdout);records.append(dict(name=name,args=args,env=extra,exit=p.returncode));(out/'commands.json').write_text(json.dumps(records,indent=2));print(name,p.returncode,flush=True)
 if p.returncode:print(p.stdout[-4000:]);raise SystemExit(p.returncode)
 return p.stdout
run('cache',[str(root/'scripts/go.sh'),'env','GOCACHE'])
for pkg,path,sel in [('pixel','./internal/pixel','^Test(BackendSelected|SquaredError|SSE8)'),('dsp','./internal/vp8/dsp','^Test(SSE|Variance)')]:
 for mode in ['ordinary','checkptr2','linux']:
  binary=out/f'{pkg}-{mode}.test';args=[str(root/'scripts/go.sh'),'-C',str(snap),'test','-pgo=off','-c','-o',str(binary)]
  if mode=='checkptr2':args+=['-gcflags=all=-d=checkptr=2']
  else:args+=['-gcflags=github.com/thesyncim/govpx/internal/pixel=-m=2','-gcflags=github.com/thesyncim/govpx/internal/vp8/dsp=-m=2']
  args+=[path];run('build-'+pkg+'-'+mode,args,dict(GOOS='linux',CGO_ENABLED='0') if mode=='linux' else {})
  if mode=='linux':continue
  for off in [False,True]:
   cpu='off' if off else 'selected';extra=dict(ROSETTA_ADVERTISE_AVX='1',GOVPX_REQUIRE_SIMD='0' if off else '1',GOVPX_REQUIRE_SCALAR='1' if off else '0',GODEBUG='cpu.avx=off,cpu.avx2=off' if off else '')
   run('run-'+pkg+'-'+mode+'-'+cpu,['arch','-x86_64',str(binary),'-test.run='+sel,'-test.v','-test.count=1'],extra)
   if pkg=='dsp':
    s=run('fixture36-'+mode+'-'+cpu,['arch','-x86_64',str(binary),'-test.run=^$','-test.bench=^BenchmarkSSE8RowsNative$','-test.benchtime=1x','-test.benchmem','-test.cpu=1'],extra);lines=[l for l in s.splitlines() if l.startswith('BenchmarkSSE8RowsNative/')];assert len(lines)==36
    if mode=='ordinary':assert all(re.search(r'\b0 B/op\s+0 allocs/op',l) for l in lines)
base=pathlib.Path('/private/tmp/govpx-fp16-offset-guard/parent')
for name,src,arch in [('parent-linux',base,'amd64'),('candidate-arm',snap,'arm64'),('parent-arm',base,'arm64')]:
 run('build-'+name,[str(root/'scripts/go.sh'),'-C',str(src),'test','-pgo=off','-c','-o',str(out/(name+'.test')),'./internal/vp8/dsp'],dict(GOOS='linux' if arch=='amd64' else 'darwin',GOARCH=arch,CGO_ENABLED='0' if arch=='amd64' else '1'))
print('SSE CARRY PASS')

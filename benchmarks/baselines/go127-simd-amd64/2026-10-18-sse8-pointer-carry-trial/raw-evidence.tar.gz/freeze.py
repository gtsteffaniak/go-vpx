import pathlib,shutil,hashlib,json,subprocess,re
w=pathlib.Path('/private/tmp/govpx-sse8-pointer-carry-review');ready=pathlib.Path('/private/tmp/govpx-sse8-pointer-carry-ready');ready.mkdir(exist_ok=True)
# Save Darwin optimized helper as well; native throughput was never measured here.
for v,b in [('candidate',w/'validation/pixel-ordinary.test'),('parent',pathlib.Path('/private/tmp/govpx-fp16-offset-guard/evidence/validation/parent-pixel-ordinary.test'))]:
 s=subprocess.check_output(['xcrun','llvm-objdump','-d','--disassemble-symbols=_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr',str(b)],text=True);(w/'codegen'/f'{v}-darwin.asm').write_text(s)
for folder in ['validation','codegen']:
 for p in (w/folder).rglob('*'):
  if p.is_file() and p.suffix!='.test':q=ready/p.relative_to(w);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for f in ['validate.py','prove.py','freeze.py']:shutil.copy2(w/f,ready/f)
p=ready/'overlay/internal/pixel';p.mkdir(parents=True,exist_ok=True);shutil.copy2(w/'candidate/internal/pixel/sse8_ptr_amd64.go',p/'sse8_ptr_amd64.go')
# Preserve observed native regression, not merely sourceidentity arguments.
raw=pathlib.Path('/private/tmp/govpx-sse8-focused-46a08f8e-artifact');out=ready/'native46-readonly-evidence';out.mkdir(exist_ok=True)
for name in ['commits.json','orders.txt','environment.txt','fixture-sha256.txt','head-binary-sha256.txt','base-binary-sha256.txt','head-source-sha256.txt','base-source-sha256.txt']+[f'{v}-round-{r}.txt' for v in ['head','base','assembly'] for r in range(1,7)]:shutil.copy2(raw/name,out/name)
s=json.loads((raw/'summary.json').read_text());rows=[r for r in s['results'] if '/pointer8x8/' in r['case'] or r['case']=='BenchmarkSSE8x8PtrFast'];(out/'pointer-summary.json').write_text(json.dumps(rows,indent=2))
binaries=[]
for p in sorted((w/'validation').glob('*.test')):binaries.append(dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(ready/'binary-inventory.json').write_text(json.dumps(binaries,indent=2))
report='''# PRIVATE SSE8 pointer-carry nativeCI candidate

Base46a08f8e; oneproductionfile overlay only. UNMEASURED candidate, no native or Rosetta speed claim. Rootmaytrial47 after nativeacceptance. Priorfrozenpackages unchanged.

Observed EPYC7763 focused46 pointers have all9 medians3.47–6.53% moretime than45base78ce74d3,48/54pairedsamples slower; legacydiagnostic+6.07%,all6slower. Nativeinput raw logs/provenance preserved here. Sourceidentity is real(SHA760494...), but does not cancel these measured regressions. Focusednative binaries were deleted and onlyhashesretained, so their exactnativecode/caller layout cannotbe verified afterward. Futurecaptureproposal fixes that trace gap.

Current source packs2exact8B rows toVEX128 thenwidens256,sub/dot/add; it used two4rowchunks with independent source/referenceoffset integers. Exact-sourceoptimizedLinux baselinehotloop37instructions/addressops13. Candidatecarries source/referencepointers by4strides onlybetweenchunks andbreaksbefore anyfinaladvance. Newloop28instructions/addressops5; nohotcalls/stackspills/legacyvectorops. Wholemeaningfulhelper131→120. Scalaraddressbookkeeping removed; vectorpack/arithmetic, orderedreads, resultreduction and explicitVZEROUPPER unchanged. SavedDarwin codegen agrees with intendedVEX-onlybody. Staticinstruction reduction is not measuredperformance.

Safety: originalCPU/Enabled/nil/unsignedstrideguard and exactfallback sourceprefix are unchanged. Caller still mustvalidate complete8x8readonlywindows. With0<=stride<2^30, the sole4*stride pointeradvance remainsinside the completewindow; it occurs onlywhen another4rowsremain. No pointerbeyondlastvisiblewindow is formed. Exact8B loads, zero/overlaprows, arbitraryread-only src/refaliases, unalignedrows, and existing invalidgeometry/panic/fallback order stayintact. There are no stores. Inputsareconsumed in the samepairedroworder. Fullsum<=64*65025=4161600 fitsint32.

Ordinary/checkptr2 selectedAVX2+actualAVX/AVX2off pixelSSE/squared-error/minimumwindow/overlap/panic tests andDSP SSE/variance tests PASS. All144public36 one-shotfixturecalls across2modes×2CPUselections passfull-output/input-canaryoracles; ordinary72zeroalloc. These are correctnessruns; incidentalRosetta nsvalues are not performanceevidence. Linux/Darwinoptimizedbinaries crossbuilt; ARMlivepixel.SSE8normalizedbodyidentical.

OptimizedDSPexports SSE8x8PtrFast/sse8x8PtrFast are inlined/dead-stripped; actualBenchmarkSSE8RowsNative closure reaches pixel.SSE8Ptr directly. Fixture result checks+global sink+fullinputbacking checks keepB.Loopworklive. Slicevariants use afunctionpointer while pointervariant is staticallydevirtualized, so absoluteAPIcrosscomparisons include differentcallerprotocols; eachsamecase head/basecomparison is stillmatched. LegacyB.Ndiagnostics discardresult andusezero-filleddata, so remainseparateacceptancecontrols. Sixvariantpermutations balanceeachpositiontwice; no sink/orderdefectfound. CPUaffinity is unpinned andsample orderfixedwithinprocess; these are protocolfacts, not a reason todismissactualregressions.

No newSDKAPI/dependency/assembly. SelectedSSEsource SHA13d8759ea3b78f902e69cde25ee20ea16f906b5d6edbc43734700d0154c00f3e. Allsources/logs/LLVM/provenance included. Binaryblobs omittedonlyfromleanpackage; size/hash/privatepath inventoryretained. rootrepositorychanges remainparentowned.\n'''
(ready/'REPORT.md').write_text(report)
manifest=[]
for p in sorted(ready.rglob('*')):
 if p.is_file() and p.name!='MANIFEST.json':manifest.append(dict(path=str(p.relative_to(ready)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(ready/'MANIFEST.json').write_text(json.dumps(manifest,indent=2));print(ready,len(manifest),hashlib.sha256((ready/'MANIFEST.json').read_bytes()).hexdigest())

import pathlib,subprocess,re,json,hashlib
w=pathlib.Path('/private/tmp/govpx-sse8-pointer-carry-review');cg=w/'codegen';cg.mkdir(exist_ok=True)
def dis(binary,symbol,arm=False):
 s=subprocess.check_output(['xcrun','llvm-objdump','-d','--disassemble-symbols='+symbol,str(binary)],text=True);inst=[]
 for l in s.splitlines():
  pat=r'^\s*([0-9a-f]+):\s+[0-9a-f]{8}\s+(.+)$' if arm else r'^\s*([0-9a-f]+):\s+(?:[0-9a-f]{2}\s+)+(.+)$'
  m=re.match(pat,l)
  if m and m[2]!='int3':inst.append((int(m[1],16),m[2]))
 assert inst,symbol
 return s,inst
report={}
for v,binary in [('parent',w/'validation/parent-linux.test'),('candidate',w/'validation/dsp-linux.test')]:
 s,inst=dis(binary,'github.com/thesyncim/govpx/internal/pixel.SSE8Ptr');(cg/(v+'-ptr-linux.asm')).write_text(s)
 backs=[(pc,int(m[1],16)) for pc,i in inst if (m:=re.match(r'j(?!mp)\w+\s+0x([0-9a-f]+)',i)) and int(m[1],16)<pc]
 assert len(backs)==1,backs
 end,start=backs[0];hot=[(pc,i) for pc,i in inst if start<=pc<=end]
 report[v]={'meaningful_function_instructions':len(inst),'hotloop_instructions':len(hot),'hotloop_address_ops':len([i for p,i in hot if i.startswith(('leaq','addq'))]),'hotloop_calls':[i for p,i in hot if i.startswith('call')],'hotloop_legacy_vector':[i for p,i in hot if ('%xmm' in i or '%ymm' in i) and not i.startswith('v')],'hotloop_stack_refs':[i for p,i in hot if '%rsp' in i or '%rbp' in i],'hotloop':hot}
 for sym in ['BenchmarkSSE8RowsNative.func1']:
  text,ls=dis(binary,'github.com/thesyncim/govpx/internal/vp8/dsp.'+sym);(cg/f'{v}-{sym}-linux.asm').write_text(text)
 s,inst=dis(w/'validation/'+pathlib.Path('nothing'),'') if False else ('',[])
# Live ARM publicwrapper/compilerbody stays unchanged.
a=[]
for v in ['parent','candidate']:
 s,inst=dis(w/'validation'/f'{v}-arm.test','_github.com/thesyncim/govpx/internal/pixel.SSE8',True);(cg/f'{v}-arm.asm').write_text(s);a.append([re.sub(r'0x[0-9a-fA-F]+','ADDR',i) for p,i in inst])
assert a[0]==a[1]
old=pathlib.Path('/private/tmp/govpx-fp16-offset-guard/parent/internal/pixel/sse8_ptr_amd64.go').read_text();new=(w/'sse8_ptr_amd64.go').read_text();assert old[:old.index('\tsp, rp :=')]==new[:new.index('\tsp, rp :=')];assert old[old.index('\tresult :='):]==new[new.index('\tresult :='):]
report['source']=dict(only_production_delta='internal/pixel/sse8_ptr_amd64.go',fallback_exact=True,reduction_upper_cleanup_exact=True,ARM_actual_public_body_exact=True,parent_sha=hashlib.sha256(old.encode()).hexdigest(),candidate_sha=hashlib.sha256(new.encode()).hexdigest(),no_native_speed_claim=True)
(cg/'proof.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:({a:b for a,b in v.items() if a!='hotloop'} if isinstance(v,dict) else v) for k,v in report.items()},indent=2))

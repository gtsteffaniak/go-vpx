
/private/tmp/govpx-sse8-pointer-carry-review/validation/candidate-arm.test:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001001bee90 <_github.com/thesyncim/govpx/internal/pixel.SSE8>:
1001bee90: f9400b90    	ldr	x16, [x28, #0x10]
1001bee94: eb3063ff    	cmp	sp, x16
1001bee98: 54001a89    	b.ls	0x1001bf1e8 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x358>
1001bee9c: f81f0ffe    	str	x30, [sp, #-0x10]!
1001beea0: f81f83fd    	stur	x29, [sp, #-0x8]
1001beea4: d10023fd    	sub	x29, sp, #0x8
1001beea8: f9000fe0    	str	x0, [sp, #0x18]
1001beeac: f9001fe4    	str	x4, [sp, #0x38]
1001beeb0: d1000509    	sub	x9, x8, #0x1
1001beeb4: 4f00e400    	movi.16b	v0, #0x0
1001beeb8: 4f00e401    	movi.16b	v1, #0x0
1001beebc: f100fd3f    	cmp	x9, #0x3f
1001beec0: 54000228    	b.hi	0x1001bef04 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x74>
1001beec4: aa07006a    	orr	x10, x3, x7
1001beec8: d35efd4a    	lsr	x10, x10, #30
1001beecc: b50001ca    	cbnz	x10, 0x1001bef04 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x74>
1001beed0: 9b097c62    	mul	x2, x3, x9
1001beed4: 91001c42    	add	x2, x2, #0x7
1001beed8: eb02003f    	cmp	x1, x2
1001beedc: 54001829    	b.ls	0x1001bf1e0 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x350>
1001beee0: 9b097ce1    	mul	x1, x7, x9
1001beee4: 91001c21    	add	x1, x1, #0x7
1001beee8: eb0100bf    	cmp	x5, x1
1001beeec: 54001789    	b.ls	0x1001bf1dc <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x34c>
1001beef0: aa1f03e1    	mov	x1, xzr
1001beef4: aa1f03e2    	mov	x2, xzr
1001beef8: aa1f03e5    	mov	x5, xzr
1001beefc: 4ea11c22    	mov.16b	v2, v1
1001bef00: 1400009c    	b	0x1001bf170 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x2e0>
1001bef04: aa1f03e9    	mov	x9, xzr
1001bef08: 4ea11c22    	mov.16b	v2, v1
1001bef0c: 14000017    	b	0x1001bef68 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0xd8>
1001bef10: f869688c    	ldr	x12, [x4, x9]
1001bef14: 4ea31c64    	mov.16b	v4, v3
1001bef18: 4e081d63    	mov.d	v3[0], x11
1001bef1c: 4e080463    	dup.2d	v3, v3[0]
1001bef20: 4e181d83    	mov.d	v3[1], x12
1001bef24: 2f08a405    	ushll.8h	v5, v0, #0x0
1001bef28: 2f08a466    	ushll.8h	v6, v3, #0x0
1001bef2c: 6e6684a5    	sub.8h	v5, v5, v6
1001bef30: 0e65c0a6    	smull.4s	v6, v5, v5
1001bef34: 4e65c0a5    	smull2.4s	v5, v5, v5
1001bef38: 4ea684a5    	add.4s	v5, v5, v6
1001bef3c: 4f00e406    	movi.16b	v6, #0x0
1001bef40: 4e067807    	zip2.16b	v7, v0, v6
1001bef44: 4e067863    	zip2.16b	v3, v3, v6
1001bef48: 6e6384e3    	sub.8h	v3, v7, v3
1001bef4c: 0e63c066    	smull.4s	v6, v3, v3
1001bef50: 4e63c063    	smull2.4s	v3, v3, v3
1001bef54: 4ea68463    	add.4s	v3, v3, v6
1001bef58: 4ea58442    	add.4s	v2, v2, v5
1001bef5c: 4ea38421    	add.4s	v1, v1, v3
1001bef60: 4ea41c80    	mov.16b	v0, v4
1001bef64: aa0a03e9    	mov	x9, x10
1001bef68: 9100092a    	add	x10, x9, #0x2
1001bef6c: eb0a011f    	cmp	x8, x10
1001bef70: 5400052b    	b.lt	0x1001bf014 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x184>
1001bef74: 9b037d2b    	mul	x11, x9, x3
1001bef78: eb0b003f    	cmp	x1, x11
1001bef7c: 54000bc3    	b.lo	0x1001bf0f4 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x264>
1001bef80: cb0b002c    	sub	x12, x1, x11
1001bef84: cb02016d    	sub	x13, x11, x2
1001bef88: 8a8dfd6d    	and	x13, x11, x13, asr #63
1001bef8c: f1001d9f    	cmp	x12, #0x7
1001bef90: 54000b09    	b.ls	0x1001bf0f0 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x260>
1001bef94: 8b0b006b    	add	x11, x3, x11
1001bef98: f86d680c    	ldr	x12, [x0, x13]
1001bef9c: eb0b003f    	cmp	x1, x11
1001befa0: 54000a63    	b.lo	0x1001bf0ec <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x25c>
1001befa4: cb0b002d    	sub	x13, x1, x11
1001befa8: cb02016e    	sub	x14, x11, x2
1001befac: 8a8efd6b    	and	x11, x11, x14, asr #63
1001befb0: f1001dbf    	cmp	x13, #0x7
1001befb4: 540009a9    	b.ls	0x1001bf0e8 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x258>
1001befb8: 9b077d29    	mul	x9, x9, x7
1001befbc: f86b680b    	ldr	x11, [x0, x11]
1001befc0: 4ea01c03    	mov.16b	v3, v0
1001befc4: 4e081d80    	mov.d	v0[0], x12
1001befc8: 4e080400    	dup.2d	v0, v0[0]
1001befcc: 4e181d60    	mov.d	v0[1], x11
1001befd0: eb0900bf    	cmp	x5, x9
1001befd4: 54000883    	b.lo	0x1001bf0e4 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x254>
1001befd8: cb0900ab    	sub	x11, x5, x9
1001befdc: cb06012c    	sub	x12, x9, x6
1001befe0: 8a8cfd2c    	and	x12, x9, x12, asr #63
1001befe4: f1001d7f    	cmp	x11, #0x7
1001befe8: 540007c9    	b.ls	0x1001bf0e0 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x250>
1001befec: 8b0900e9    	add	x9, x7, x9
1001beff0: f86c688b    	ldr	x11, [x4, x12]
1001beff4: eb0900bf    	cmp	x5, x9
1001beff8: 54000723    	b.lo	0x1001bf0dc <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x24c>
1001beffc: cb0900ac    	sub	x12, x5, x9
1001bf000: cb06012d    	sub	x13, x9, x6
1001bf004: 8a8dfd29    	and	x9, x9, x13, asr #63
1001bf008: f1001d9f    	cmp	x12, #0x7
1001bf00c: 54fff828    	b.hi	0x1001bef10 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x80>
1001bf010: 14000032    	b	0x1001bf0d8 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x248>
1001bf014: eb09011f    	cmp	x8, x9
1001bf018: 540004ad    	b.le	0x1001bf0ac <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x21c>
1001bf01c: 9b037d23    	mul	x3, x9, x3
1001bf020: eb03003f    	cmp	x1, x3
1001bf024: 54000583    	b.lo	0x1001bf0d4 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x244>
1001bf028: cb030021    	sub	x1, x1, x3
1001bf02c: cb020062    	sub	x2, x3, x2
1001bf030: 8a82fc62    	and	x2, x3, x2, asr #63
1001bf034: f1001c3f    	cmp	x1, #0x7
1001bf038: 540004c9    	b.ls	0x1001bf0d0 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x240>
1001bf03c: 9b077d21    	mul	x1, x9, x7
1001bf040: f8626802    	ldr	x2, [x0, x2]
1001bf044: 4ea01c03    	mov.16b	v3, v0
1001bf048: 4e081c40    	mov.d	v0[0], x2
1001bf04c: eb0100bf    	cmp	x5, x1
1001bf050: 540003e3    	b.lo	0x1001bf0cc <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x23c>
1001bf054: cb0100a2    	sub	x2, x5, x1
1001bf058: cb060023    	sub	x3, x1, x6
1001bf05c: 8a83fc21    	and	x1, x1, x3, asr #63
1001bf060: f1001c5f    	cmp	x2, #0x7
1001bf064: 54000329    	b.ls	0x1001bf0c8 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x238>
1001bf068: f8616881    	ldr	x1, [x4, x1]
1001bf06c: 4e081c23    	mov.d	v3[0], x1
1001bf070: 2f08a404    	ushll.8h	v4, v0, #0x0
1001bf074: 2f08a465    	ushll.8h	v5, v3, #0x0
1001bf078: 6e658484    	sub.8h	v4, v4, v5
1001bf07c: 0e64c085    	smull.4s	v5, v4, v4
1001bf080: 4e64c084    	smull2.4s	v4, v4, v4
1001bf084: 4ea58484    	add.4s	v4, v4, v5
1001bf088: 4f00e405    	movi.16b	v5, #0x0
1001bf08c: 4e057800    	zip2.16b	v0, v0, v5
1001bf090: 4e057863    	zip2.16b	v3, v3, v5
1001bf094: 6e638400    	sub.8h	v0, v0, v3
1001bf098: 0e60c003    	smull.4s	v3, v0, v0
1001bf09c: 4e60c000    	smull2.4s	v0, v0, v0
1001bf0a0: 4ea38400    	add.4s	v0, v0, v3
1001bf0a4: 4ea48442    	add.4s	v2, v2, v4
1001bf0a8: 4ea08421    	add.4s	v1, v1, v0
1001bf0ac: 4ea18440    	add.4s	v0, v2, v1
1001bf0b0: 4eb1b800    	addv.4s	s0, v0
1001bf0b4: 0e043c00    	mov.s	w0, v0[0]
1001bf0b8: d503201f    	nop
1001bf0bc: f85f83fd    	ldur	x29, [sp, #-0x8]
1001bf0c0: f84107fe    	ldr	x30, [sp], #0x10
1001bf0c4: d65f03c0    	ret
1001bf0c8: 97fb1e22    	bl	0x100086950 <_runtime.panicBounds>
1001bf0cc: 97fb1e21    	bl	0x100086950 <_runtime.panicBounds>
1001bf0d0: 97fb1e20    	bl	0x100086950 <_runtime.panicBounds>
1001bf0d4: 97fb1e1f    	bl	0x100086950 <_runtime.panicBounds>
1001bf0d8: 97fb1e1e    	bl	0x100086950 <_runtime.panicBounds>
1001bf0dc: 97fb1e1d    	bl	0x100086950 <_runtime.panicBounds>
1001bf0e0: 97fb1e1c    	bl	0x100086950 <_runtime.panicBounds>
1001bf0e4: 97fb1e1b    	bl	0x100086950 <_runtime.panicBounds>
1001bf0e8: 97fb1e1a    	bl	0x100086950 <_runtime.panicBounds>
1001bf0ec: 97fb1e19    	bl	0x100086950 <_runtime.panicBounds>
1001bf0f0: 97fb1e18    	bl	0x100086950 <_runtime.panicBounds>
1001bf0f4: 97fb1e17    	bl	0x100086950 <_runtime.panicBounds>
1001bf0f8: f8656809    	ldr	x9, [x0, x5]
1001bf0fc: 4ea01c03    	mov.16b	v3, v0
1001bf100: 4e081d23    	mov.d	v3[0], x9
1001bf104: 8b050069    	add	x9, x3, x5
1001bf108: f8696809    	ldr	x9, [x0, x9]
1001bf10c: 4e181d23    	mov.d	v3[1], x9
1001bf110: f8626889    	ldr	x9, [x4, x2]
1001bf114: 4ea01c04    	mov.16b	v4, v0
1001bf118: 4e081d24    	mov.d	v4[0], x9
1001bf11c: 8b0200e9    	add	x9, x7, x2
1001bf120: f8696889    	ldr	x9, [x4, x9]
1001bf124: 4e181d24    	mov.d	v4[1], x9
1001bf128: 6e246465    	umax.16b	v5, v3, v4
1001bf12c: 6e246c63    	umin.16b	v3, v3, v4
1001bf130: 6e2384a3    	sub.16b	v3, v5, v3
1001bf134: 2f08a464    	ushll.8h	v4, v3, #0x0
1001bf138: 6f08a463    	ushll2.8h	v3, v3, #0x0
1001bf13c: 0e64c085    	smull.4s	v5, v4, v4
1001bf140: 4e64c084    	smull2.4s	v4, v4, v4
1001bf144: 4ea58484    	add.4s	v4, v4, v5
1001bf148: 0e63c065    	smull.4s	v5, v3, v3
1001bf14c: 4e63c063    	smull2.4s	v3, v3, v3
1001bf150: 4ea58463    	add.4s	v3, v3, v5
1001bf154: d503201f    	nop
1001bf158: d503201f    	nop
1001bf15c: 4ea48421    	add.4s	v1, v1, v4
1001bf160: 4ea28462    	add.4s	v2, v3, v2
1001bf164: 8b0304a5    	add	x5, x5, x3, lsl #1
1001bf168: 8b070442    	add	x2, x2, x7, lsl #1
1001bf16c: aa0603e1    	mov	x1, x6
1001bf170: 91000826    	add	x6, x1, #0x2
1001bf174: eb06011f    	cmp	x8, x6
1001bf178: 54fffc0a    	b.ge	0x1001bf0f8 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x268>
1001bf17c: eb01011f    	cmp	x8, x1
1001bf180: 5400020d    	b.le	0x1001bf1c0 <_github.com/thesyncim/govpx/internal/pixel.SSE8+0x330>
1001bf184: f8656801    	ldr	x1, [x0, x5]
1001bf188: f8626882    	ldr	x2, [x4, x2]
1001bf18c: 4ea01c03    	mov.16b	v3, v0
1001bf190: 4e081c20    	mov.d	v0[0], x1
1001bf194: 4e080400    	dup.2d	v0, v0[0]
1001bf198: 4e081c43    	mov.d	v3[0], x2
1001bf19c: 4e080463    	dup.2d	v3, v3[0]
1001bf1a0: 6e236404    	umax.16b	v4, v0, v3
1001bf1a4: 6e236c00    	umin.16b	v0, v0, v3
1001bf1a8: 6e208480    	sub.16b	v0, v4, v0
1001bf1ac: 2f08a400    	ushll.8h	v0, v0, #0x0
1001bf1b0: 0e60c003    	smull.4s	v3, v0, v0
1001bf1b4: 4e60c000    	smull2.4s	v0, v0, v0
1001bf1b8: 4ea38400    	add.4s	v0, v0, v3
1001bf1bc: 4ea08421    	add.4s	v1, v1, v0
1001bf1c0: 4ea28420    	add.4s	v0, v1, v2
1001bf1c4: 4eb1b800    	addv.4s	s0, v0
1001bf1c8: 0e043c00    	mov.s	w0, v0[0]
1001bf1cc: d503201f    	nop
1001bf1d0: f85f83fd    	ldur	x29, [sp, #-0x8]
1001bf1d4: f84107fe    	ldr	x30, [sp], #0x10
1001bf1d8: d65f03c0    	ret
1001bf1dc: 97fb1ddd    	bl	0x100086950 <_runtime.panicBounds>
1001bf1e0: 97fb1ddc    	bl	0x100086950 <_runtime.panicBounds>
1001bf1e4: d503201f    	nop
1001bf1e8: a90087e0    	stp	x0, x1, [sp, #0x8]
1001bf1ec: a9018fe2    	stp	x2, x3, [sp, #0x18]
1001bf1f0: a90297e4    	stp	x4, x5, [sp, #0x28]
1001bf1f4: a9039fe6    	stp	x6, x7, [sp, #0x38]
1001bf1f8: f90027e8    	str	x8, [sp, #0x48]
1001bf1fc: aa1e03e3    	mov	x3, x30
1001bf200: 97fb1590    	bl	0x100084840 <_runtime.morestack_noctxt.abi0>
1001bf204: a94087e0    	ldp	x0, x1, [sp, #0x8]
1001bf208: a9418fe2    	ldp	x2, x3, [sp, #0x18]
1001bf20c: a94297e4    	ldp	x4, x5, [sp, #0x28]
1001bf210: a9439fe6    	ldp	x6, x7, [sp, #0x38]
1001bf214: f94027e8    	ldr	x8, [sp, #0x48]
1001bf218: 17ffff1e    	b	0x1001bee90 <_github.com/thesyncim/govpx/internal/pixel.SSE8>
1001bf21c: 00000000    	udf	#0x0

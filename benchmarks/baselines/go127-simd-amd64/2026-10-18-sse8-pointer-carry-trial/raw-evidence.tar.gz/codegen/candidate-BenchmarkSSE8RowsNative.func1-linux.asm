
/private/tmp/govpx-sse8-pointer-carry-review/validation/dsp-linux.test:	file format elf64-x86-64

Disassembly of section .text:

00000000006566a0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1>:
  6566a0: 4c 8d a4 24 48 ff ff ff      	leaq	-0xb8(%rsp), %r12
  6566a8: 4d 3b 66 10                  	cmpq	0x10(%r14), %r12
  6566ac: 0f 86 5b 08 00 00            	jbe	0x656f0d <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x86d>
  6566b2: 55                           	pushq	%rbp
  6566b3: 48 89 e5                     	movq	%rsp, %rbp
  6566b6: 48 81 ec 30 01 00 00         	subq	$0x130, %rsp            # imm = 0x130
  6566bd: 48 89 84 24 40 01 00 00      	movq	%rax, 0x140(%rsp)
  6566c5: 48 8b 72 10                  	movq	0x10(%rdx), %rsi
  6566c9: 48 89 b4 24 28 01 00 00      	movq	%rsi, 0x128(%rsp)
  6566d1: 48 8b 7a 08                  	movq	0x8(%rdx), %rdi
  6566d5: 48 8b 0f                     	movq	(%rdi), %rcx
  6566d8: 48 89 4c 24 60               	movq	%rcx, 0x60(%rsp)
  6566dd: 48 8b 7f 08                  	movq	0x8(%rdi), %rdi
  6566e1: 48 89 7c 24 70               	movq	%rdi, 0x70(%rsp)
  6566e6: 48 8b 5e 10                  	movq	0x10(%rsi), %rbx
  6566ea: 48 ff cb                     	decq	%rbx
  6566ed: 48 89 de                     	movq	%rbx, %rsi
  6566f0: 48 0f af ce                  	imulq	%rsi, %rcx
  6566f4: 48 89 8c 24 b8 00 00 00      	movq	%rcx, 0xb8(%rsp)
  6566fc: 48 0f af df                  	imulq	%rdi, %rbx
  656700: 48 89 9c 24 b0 00 00 00      	movq	%rbx, 0xb0(%rsp)
  656708: 48 8d 73 1e                  	leaq	0x1e(%rbx), %rsi
  65670c: 48 89 74 24 78               	movq	%rsi, 0x78(%rsp)
  656711: 48 8b 52 18                  	movq	0x18(%rdx), %rdx
  656715: 48 89 94 24 90 00 00 00      	movq	%rdx, 0x90(%rsp)
  65671d: 48 83 c1 18                  	addq	$0x18, %rcx
  656721: 48 89 4c 24 68               	movq	%rcx, 0x68(%rsp)
  656726: 48 8d 05 9b 35 26 00         	leaq	0x26359b(%rip), %rax    # 0x8b9cc8 <type:*+0x36210>
  65672d: 48 89 cb                     	movq	%rcx, %rbx
  656730: e8 eb 4e e3 ff               	callq	0x48b620 <runtime.makeslice>
  656735: 48 89 84 24 20 01 00 00      	movq	%rax, 0x120(%rsp)
  65673d: 48 8d 05 84 35 26 00         	leaq	0x263584(%rip), %rax    # 0x8b9cc8 <type:*+0x36210>
  656744: 48 8b 5c 24 78               	movq	0x78(%rsp), %rbx
  656749: 48 89 d9                     	movq	%rbx, %rcx
  65674c: e8 cf 4e e3 ff               	callq	0x48b620 <runtime.makeslice>
  656751: 31 d2                        	xorl	%edx, %edx
  656753: 48 8b 74 24 68               	movq	0x68(%rsp), %rsi
  656758: 48 8b bc 24 20 01 00 00      	movq	0x120(%rsp), %rdi
  656760: eb 32                        	jmp	0x656794 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0xf4>
  656762: 4c 8d 1c d2                  	leaq	(%rdx,%rdx,8), %r11
  656766: 4e 8d 1c 9a                  	leaq	(%rdx,%r11,4), %r11
  65676a: 48 89 c1                     	movq	%rax, %rcx
  65676d: 48 b8 8c 2e ba e8 a2 8b 2e ba	movabsq	$-0x45d1745d1745d174, %rax # imm = 0xBA2E8BA2E8BA2E8C
  656777: 48 89 d3                     	movq	%rdx, %rbx
  65677a: 48 f7 e2                     	mulq	%rdx
  65677d: 48 c1 ea 03                  	shrq	$0x3, %rdx
  656781: 4e 8d 1c 1a                  	leaq	(%rdx,%r11), %r11
  656785: 4d 8d 5b 13                  	leaq	0x13(%r11), %r11
  656789: 44 88 1c 1f                  	movb	%r11b, (%rdi,%rbx)
  65678d: 48 8d 53 01                  	leaq	0x1(%rbx), %rdx
  656791: 48 89 c8                     	movq	%rcx, %rax
  656794: 48 39 d6                     	cmpq	%rdx, %rsi
  656797: 7f c9                        	jg	0x656762 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0xc2>
  656799: 45 31 db                     	xorl	%r11d, %r11d
  65679c: 48 89 f9                     	movq	%rdi, %rcx
  65679f: 48 8b 7c 24 78               	movq	0x78(%rsp), %rdi
  6567a4: eb 2e                        	jmp	0x6567d4 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x134>
  6567a6: 4d 6b e3 47                  	imulq	$0x47, %r11, %r12
  6567aa: 48 89 c2                     	movq	%rax, %rdx
  6567ad: 48 b8 4a 92 24 49 92 24 49 92	movabsq	$-0x6db6db6db6db6db6, %rax # imm = 0x924924924924924A
  6567b7: 48 89 d3                     	movq	%rdx, %rbx
  6567ba: 49 f7 e3                     	mulq	%r11
  6567bd: 48 c1 ea 02                  	shrq	$0x2, %rdx
  6567c1: 4e 8d 24 22                  	leaq	(%rdx,%r12), %r12
  6567c5: 4d 8d 64 24 1f               	leaq	0x1f(%r12), %r12
  6567ca: 46 88 24 1b                  	movb	%r12b, (%rbx,%r11)
  6567ce: 49 ff c3                     	incq	%r11
  6567d1: 48 89 d8                     	movq	%rbx, %rax
  6567d4: 49 39 fb                     	cmpq	%rdi, %r11
  6567d7: 7c cd                        	jl	0x6567a6 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x106>
  6567d9: 48 89 84 24 18 01 00 00      	movq	%rax, 0x118(%rsp)
  6567e1: 4c 8b 9c 24 90 00 00 00      	movq	0x90(%rsp), %r11
  6567e9: 49 83 fb 01                  	cmpq	$0x1, %r11
  6567ed: 75 51                        	jne	0x656840 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1a0>
  6567ef: 48 8b 9c 24 b8 00 00 00      	movq	0xb8(%rsp), %rbx
  6567f7: 49 89 db                     	movq	%rbx, %r11
  6567fa: 66 0f 1f 44 00 00            	nopw	(%rax,%rax)
  656800: 48 83 c3 18                  	addq	$0x18, %rbx
  656804: 74 2d                        	je	0x656833 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x193>
  656806: 48 89 c8                     	movq	%rcx, %rax
  656809: 48 89 f3                     	movq	%rsi, %rbx
  65680c: e8 8f 9d e3 ff               	callq	0x4905a0 <runtime.memclrNoHeapPointers>
  656811: 48 8b 84 24 18 01 00 00      	movq	0x118(%rsp), %rax
  656819: 48 8b 8c 24 20 01 00 00      	movq	0x120(%rsp), %rcx
  656821: 48 8b 74 24 68               	movq	0x68(%rsp), %rsi
  656826: 48 8b 7c 24 78               	movq	0x78(%rsp), %rdi
  65682b: 4c 8b 9c 24 b8 00 00 00      	movq	0xb8(%rsp), %r11
  656833: 45 31 e4                     	xorl	%r12d, %r12d
  656836: e9 c8 06 00 00               	jmp	0x656f03 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x863>
  65683b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  656840: 49 83 fb 02                  	cmpq	$0x2, %r11
  656844: 75 1f                        	jne	0x656865 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1c5>
  656846: 4c 8b 9c 24 28 01 00 00      	movq	0x128(%rsp), %r11
  65684e: 4d 8b 63 10                  	movq	0x10(%r11), %r12
  656852: 45 31 ed                     	xorl	%r13d, %r13d
  656855: 4c 8b 54 24 70               	movq	0x70(%rsp), %r10
  65685a: 48 8b 5c 24 60               	movq	0x60(%rsp), %rbx
  65685f: 90                           	nop
  656860: e9 20 06 00 00               	jmp	0x656e85 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7e5>
  656865: 48 8b 9c 24 b8 00 00 00      	movq	0xb8(%rsp), %rbx
  65686d: 4c 8d 5b 0b                  	leaq	0xb(%rbx), %r11
  656871: 4c 39 de                     	cmpq	%r11, %rsi
  656874: 0f 82 fa 05 00 00            	jb	0x656e74 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7d4>
  65687a: 66 0f 1f 44 00 00            	nopw	(%rax,%rax)
  656880: 49 83 fb 03                  	cmpq	$0x3, %r11
  656884: 0f 82 e5 05 00 00            	jb	0x656e6f <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7cf>
  65688a: 4c 8d 5b 15                  	leaq	0x15(%rbx), %r11
  65688e: 4d 89 dc                     	movq	%r11, %r12
  656891: 49 f7 db                     	negq	%r11
  656894: 49 c1 fb 3f                  	sarq	$0x3f, %r11
  656898: 41 83 e3 03                  	andl	$0x3, %r11d
  65689c: 4c 8b 8c 24 b0 00 00 00      	movq	0xb0(%rsp), %r9
  6568a4: 4d 8d 69 0d                  	leaq	0xd(%r9), %r13
  6568a8: 49 01 cb                     	addq	%rcx, %r11
  6568ab: 49 39 fd                     	cmpq	%rdi, %r13
  6568ae: 0f 87 b6 05 00 00            	ja	0x656e6a <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7ca>
  6568b4: 49 83 fd 05                  	cmpq	$0x5, %r13
  6568b8: 0f 82 a7 05 00 00            	jb	0x656e65 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7c5>
  6568be: 4c 89 a4 24 a8 00 00 00      	movq	%r12, 0xa8(%rsp)
  6568c6: 4c 89 9c 24 e0 00 00 00      	movq	%r11, 0xe0(%rsp)
  6568ce: 4d 8d 69 19                  	leaq	0x19(%r9), %r13
  6568d2: 4c 89 ac 24 88 00 00 00      	movq	%r13, 0x88(%rsp)
  6568da: 4d 89 ef                     	movq	%r13, %r15
  6568dd: 49 f7 dd                     	negq	%r13
  6568e0: 49 c1 fd 3f                  	sarq	$0x3f, %r13
  6568e4: 41 83 e5 05                  	andl	$0x5, %r13d
  6568e8: 49 01 c5                     	addq	%rax, %r13
  6568eb: 4c 89 ac 24 d0 00 00 00      	movq	%r13, 0xd0(%rsp)
  6568f3: 48 85 c9                     	testq	%rcx, %rcx
  6568f6: 75 0d                        	jne	0x656905 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x265>
  6568f8: 31 d2                        	xorl	%edx, %edx
  6568fa: 45 31 c0                     	xorl	%r8d, %r8d
  6568fd: 0f 1f 00                     	nopl	(%rax)
  656900: e9 8f 00 00 00               	jmp	0x656994 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x2f4>
  656905: 48 8d 44 24 40               	leaq	0x40(%rsp), %rax
  65690a: 48 89 f3                     	movq	%rsi, %rbx
  65690d: 31 c9                        	xorl	%ecx, %ecx
  65690f: 48 89 df                     	movq	%rbx, %rdi
  656912: 48 8d 35 af 33 26 00         	leaq	0x2633af(%rip), %rsi    # 0x8b9cc8 <type:*+0x36210>
  656919: e8 e2 4d e3 ff               	callq	0x48b700 <runtime.growslice>
  65691e: 48 89 84 24 c8 00 00 00      	movq	%rax, 0xc8(%rsp)
  656926: 48 89 5c 24 48               	movq	%rbx, 0x48(%rsp)
  65692b: 48 8b 9c 24 20 01 00 00      	movq	0x120(%rsp), %rbx
  656933: 48 8b 4c 24 68               	movq	0x68(%rsp), %rcx
  656938: e8 63 9f e3 ff               	callq	0x4908a0 <runtime.memmove>
  65693d: 48 8b 84 24 18 01 00 00      	movq	0x118(%rsp), %rax
  656945: 48 8b 8c 24 20 01 00 00      	movq	0x120(%rsp), %rcx
  65694d: 48 8b 9c 24 b8 00 00 00      	movq	0xb8(%rsp), %rbx
  656955: 48 8b 74 24 68               	movq	0x68(%rsp), %rsi
  65695a: 48 8b 7c 24 78               	movq	0x78(%rsp), %rdi
  65695f: 4c 8b 8c 24 b0 00 00 00      	movq	0xb0(%rsp), %r9
  656967: 4c 8b 9c 24 e0 00 00 00      	movq	0xe0(%rsp), %r11
  65696f: 4c 8b a4 24 a8 00 00 00      	movq	0xa8(%rsp), %r12
  656977: 4c 8b ac 24 d0 00 00 00      	movq	0xd0(%rsp), %r13
  65697f: 4c 8b bc 24 88 00 00 00      	movq	0x88(%rsp), %r15
  656987: 48 8b 54 24 48               	movq	0x48(%rsp), %rdx
  65698c: 4c 8b 84 24 c8 00 00 00      	movq	0xc8(%rsp), %r8
  656994: 48 89 54 24 48               	movq	%rdx, 0x48(%rsp)
  656999: 4c 89 84 24 c8 00 00 00      	movq	%r8, 0xc8(%rsp)
  6569a1: 48 85 c0                     	testq	%rax, %rax
  6569a4: 75 13                        	jne	0x6569b9 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x319>
  6569a6: 45 31 d2                     	xorl	%r10d, %r10d
  6569a9: 45 31 d2                     	xorl	%r10d, %r10d
  6569ac: 4c 89 94 24 c0 00 00 00      	movq	%r10, 0xc0(%rsp)
  6569b4: 45 31 d2                     	xorl	%r10d, %r10d
  6569b7: eb 74                        	jmp	0x656a2d <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x38d>
  6569b9: 48 8d 44 24 40               	leaq	0x40(%rsp), %rax
  6569be: 48 89 fb                     	movq	%rdi, %rbx
  6569c1: 31 c9                        	xorl	%ecx, %ecx
  6569c3: 48 8d 35 fe 32 26 00         	leaq	0x2632fe(%rip), %rsi    # 0x8b9cc8 <type:*+0x36210>
  6569ca: e8 31 4d e3 ff               	callq	0x48b700 <runtime.growslice>
  6569cf: 48 89 84 24 c0 00 00 00      	movq	%rax, 0xc0(%rsp)
  6569d7: 48 89 5c 24 40               	movq	%rbx, 0x40(%rsp)
  6569dc: 48 8b 9c 24 18 01 00 00      	movq	0x118(%rsp), %rbx
  6569e4: 48 8b 4c 24 78               	movq	0x78(%rsp), %rcx
  6569e9: e8 b2 9e e3 ff               	callq	0x4908a0 <runtime.memmove>
  6569ee: 48 8b 8c 24 20 01 00 00      	movq	0x120(%rsp), %rcx
  6569f6: 48 8b 54 24 48               	movq	0x48(%rsp), %rdx
  6569fb: 48 8b 9c 24 b8 00 00 00      	movq	0xb8(%rsp), %rbx
  656a03: 48 8b 74 24 68               	movq	0x68(%rsp), %rsi
  656a08: 4c 8b 84 24 c8 00 00 00      	movq	0xc8(%rsp), %r8
  656a10: 4c 8b 8c 24 b0 00 00 00      	movq	0xb0(%rsp), %r9
  656a18: 4c 8b 9c 24 e0 00 00 00      	movq	0xe0(%rsp), %r11
  656a20: 4c 8b ac 24 d0 00 00 00      	movq	0xd0(%rsp), %r13
  656a28: 4c 8b 54 24 40               	movq	0x40(%rsp), %r10
  656a2d: 4c 89 54 24 40               	movq	%r10, 0x40(%rsp)
  656a32: 48 83 c3 08                  	addq	$0x8, %rbx
  656a36: 49 83 c1 08                  	addq	$0x8, %r9
  656a3a: 4c 8b a4 24 28 01 00 00      	movq	0x128(%rsp), %r12
  656a42: 49 8b 44 24 10               	movq	0x10(%r12), %rax
  656a47: 45 31 ff                     	xorl	%r15d, %r15d
  656a4a: 45 31 e4                     	xorl	%r12d, %r12d
  656a4d: 48 8b 7c 24 60               	movq	0x60(%rsp), %rdi
  656a52: 4c 8b 54 24 70               	movq	0x70(%rsp), %r10
  656a57: eb 1d                        	jmp	0x656a76 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x3d6>
  656a59: 4c 8b 64 24 50               	movq	0x50(%rsp), %r12
  656a5e: 49 ff c4                     	incq	%r12
  656a61: 48 8b 8c 24 20 01 00 00      	movq	0x120(%rsp), %rcx
  656a69: 48 8b 74 24 68               	movq	0x68(%rsp), %rsi
  656a6e: 4c 8b ac 24 d0 00 00 00      	movq	0xd0(%rsp), %r13
  656a76: 49 39 c4                     	cmpq	%rax, %r12
  656a79: 7d 63                        	jge	0x656ade <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x43e>
  656a7b: 4c 89 64 24 50               	movq	%r12, 0x50(%rsp)
  656a80: 4c 0f af e7                  	imulq	%rdi, %r12
  656a84: 4c 8b 6c 24 50               	movq	0x50(%rsp), %r13
  656a89: 4d 0f af ea                  	imulq	%r10, %r13
  656a8d: 31 c9                        	xorl	%ecx, %ecx
  656a8f: 48 8b b4 24 d0 00 00 00      	movq	0xd0(%rsp), %rsi
  656a97: eb 1e                        	jmp	0x656ab7 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x417>
  656a99: 0f b6 14 16                  	movzbl	(%rsi,%rdx), %edx
  656a9d: 49 29 d0                     	subq	%rdx, %r8
  656aa0: 4d 0f af c0                  	imulq	%r8, %r8
  656aa4: 4d 01 c7                     	addq	%r8, %r15
  656aa7: 48 ff c1                     	incq	%rcx
  656aaa: 48 8b 54 24 48               	movq	0x48(%rsp), %rdx
  656aaf: 4c 8b 84 24 c8 00 00 00      	movq	0xc8(%rsp), %r8
  656ab7: 48 83 f9 08                  	cmpq	$0x8, %rcx
  656abb: 7d 9c                        	jge	0x656a59 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x3b9>
  656abd: 4d 8d 04 0c                  	leaq	(%r12,%rcx), %r8
  656ac1: 4c 39 c3                     	cmpq	%r8, %rbx
  656ac4: 0f 86 94 03 00 00            	jbe	0x656e5e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7be>
  656aca: 49 8d 54 0d 00               	leaq	(%r13,%rcx), %rdx
  656acf: 47 0f b6 04 03               	movzbl	(%r11,%r8), %r8d
  656ad4: 49 39 d1                     	cmpq	%rdx, %r9
  656ad7: 77 c0                        	ja	0x656a99 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x3f9>
  656ad9: e9 7b 03 00 00               	jmp	0x656e59 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7b9>
  656ade: 48 89 9c 24 a0 00 00 00      	movq	%rbx, 0xa0(%rsp)
  656ae6: 4c 89 8c 24 80 00 00 00      	movq	%r9, 0x80(%rsp)
  656aee: 4c 89 7c 24 58               	movq	%r15, 0x58(%rsp)
  656af3: 48 c7 84 24 98 00 00 00 00 00 00 00  	movq	$0x0, 0x98(%rsp)
  656aff: 4c 8b a4 24 28 01 00 00      	movq	0x128(%rsp), %r12
  656b07: 41 80 7c 24 20 00            	cmpb	$0x0, 0x20(%r12)
  656b0d: 74 38                        	je	0x656b47 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x4a7>
  656b0f: 48 85 db                     	testq	%rbx, %rbx
  656b12: 0f 86 3c 03 00 00            	jbe	0x656e54 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7b4>
  656b18: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)
  656b20: 4d 85 c9                     	testq	%r9, %r9
  656b23: 0f 86 26 03 00 00            	jbe	0x656e4f <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7af>
  656b29: 90                           	nop
  656b2a: 4c 89 d8                     	movq	%r11, %rax
  656b2d: 48 89 fb                     	movq	%rdi, %rbx
  656b30: 4c 89 e9                     	movq	%r13, %rcx
  656b33: 4c 89 d7                     	movq	%r10, %rdi
  656b36: e8 25 e7 fa ff               	callq	0x605260 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr>
  656b3b: 89 c2                        	movl	%eax, %edx
  656b3d: 48 89 94 24 98 00 00 00      	movq	%rdx, 0x98(%rsp)
  656b45: eb 2c                        	jmp	0x656b73 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x4d3>
  656b47: 49 8b 54 24 18               	movq	0x18(%r12), %rdx
  656b4c: 4c 8b 22                     	movq	(%rdx), %r12
  656b4f: 4c 89 d8                     	movq	%r11, %rax
  656b52: 48 8b 8c 24 a8 00 00 00      	movq	0xa8(%rsp), %rcx
  656b5a: 4c 89 ee                     	movq	%r13, %rsi
  656b5d: 4d 89 c8                     	movq	%r9, %r8
  656b60: 4c 8b 8c 24 88 00 00 00      	movq	0x88(%rsp), %r9
  656b68: 41 ff d4                     	callq	*%r12
  656b6b: 48 89 84 24 98 00 00 00      	movq	%rax, 0x98(%rsp)
  656b73: 48 8b 84 24 98 00 00 00      	movq	0x98(%rsp), %rax
  656b7b: 48 8b 4c 24 58               	movq	0x58(%rsp), %rcx
  656b80: 48 39 c1                     	cmpq	%rax, %rcx
  656b83: 74 79                        	je	0x656bfe <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x55e>
  656b85: 48 8d 8c 24 f8 00 00 00      	leaq	0xf8(%rsp), %rcx
  656b8d: 44 0f 11 39                  	movups	%xmm15, (%rcx)
  656b91: 44 0f 11 79 10               	movups	%xmm15, 0x10(%rcx)
  656b96: e8 c5 0a e3 ff               	callq	0x487660 <runtime.convT64>
  656b9b: 48 8d 0d e6 32 26 00         	leaq	0x2632e6(%rip), %rcx    # 0x8b9e88 <type:*+0x363d0>
  656ba2: 48 89 8c 24 f8 00 00 00      	movq	%rcx, 0xf8(%rsp)
  656baa: 48 89 84 24 00 01 00 00      	movq	%rax, 0x100(%rsp)
  656bb2: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
  656bb7: e8 a4 0a e3 ff               	callq	0x487660 <runtime.convT64>
  656bbc: 48 8d 0d c5 32 26 00         	leaq	0x2632c5(%rip), %rcx    # 0x8b9e88 <type:*+0x363d0>
  656bc3: 48 89 8c 24 08 01 00 00      	movq	%rcx, 0x108(%rsp)
  656bcb: 48 89 84 24 10 01 00 00      	movq	%rax, 0x110(%rsp)
  656bd3: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656bdb: 84 00                        	testb	%al, (%rax)
  656bdd: 48 8d 1d d5 09 02 00         	leaq	0x209d5(%rip), %rbx     # 0x6775b9 <runtime.rodata+0x75b9>
  656be4: b9 18 00 00 00               	movl	$0x18, %ecx
  656be9: 48 8d bc 24 f8 00 00 00      	leaq	0xf8(%rsp), %rdi
  656bf1: be 02 00 00 00               	movl	$0x2, %esi
  656bf6: 41 89 f0                     	movl	%esi, %r8d
  656bf9: e8 e2 f4 eb ff               	callq	0x5160e0 <testing.(*common).Fatalf>
  656bfe: 90                           	nop
  656bff: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656c07: c6 80 52 02 00 00 01         	movb	$0x1, 0x252(%rax)
  656c0e: e8 cd 2c eb ff               	callq	0x5098e0 <testing.(*B).ResetTimer>
  656c13: 48 8b 8c 24 28 01 00 00      	movq	0x128(%rsp), %rcx
  656c1b: 80 79 20 00                  	cmpb	$0x0, 0x20(%rcx)
  656c1f: 90                           	nop
  656c20: 74 2c                        	je	0x656c4e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x5ae>
  656c22: 48 8b 94 24 a0 00 00 00      	movq	0xa0(%rsp), %rdx
  656c2a: 48 85 d2                     	testq	%rdx, %rdx
  656c2d: 0f 86 17 02 00 00            	jbe	0x656e4a <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7aa>
  656c33: 48 8b 94 24 80 00 00 00      	movq	0x80(%rsp), %rdx
  656c3b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  656c40: 48 85 d2                     	testq	%rdx, %rdx
  656c43: 0f 87 b7 01 00 00            	ja	0x656e00 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x760>
  656c49: e9 f7 01 00 00               	jmp	0x656e45 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7a5>
  656c4e: 48 8b 51 18                  	movq	0x18(%rcx), %rdx
  656c52: 48 89 94 24 d8 00 00 00      	movq	%rdx, 0xd8(%rsp)
  656c5a: eb 50                        	jmp	0x656cac <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x60c>
  656c5c: 4c 8b 1a                     	movq	(%rdx), %r11
  656c5f: 48 8b 84 24 e0 00 00 00      	movq	0xe0(%rsp), %rax
  656c67: 48 8b 9c 24 a0 00 00 00      	movq	0xa0(%rsp), %rbx
  656c6f: 48 8b 8c 24 a8 00 00 00      	movq	0xa8(%rsp), %rcx
  656c77: 48 8b 7c 24 60               	movq	0x60(%rsp), %rdi
  656c7c: 48 8b b4 24 d0 00 00 00      	movq	0xd0(%rsp), %rsi
  656c84: 4c 8b 84 24 80 00 00 00      	movq	0x80(%rsp), %r8
  656c8c: 4c 8b 8c 24 88 00 00 00      	movq	0x88(%rsp), %r9
  656c94: 4c 8b 54 24 70               	movq	0x70(%rsp), %r10
  656c99: 41 ff d3                     	callq	*%r11
  656c9c: 48 89 84 24 98 00 00 00      	movq	%rax, 0x98(%rsp)
  656ca4: 48 8b 94 24 d8 00 00 00      	movq	0xd8(%rsp), %rdx
  656cac: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656cb4: 4c 8b 98 c0 02 00 00         	movq	0x2c0(%rax), %r11
  656cbb: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  656cc0: 4c 39 98 b8 02 00 00         	cmpq	%r11, 0x2b8(%rax)
  656cc7: 76 11                        	jbe	0x656cda <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x63a>
  656cc9: 49 ff c3                     	incq	%r11
  656ccc: 4c 89 98 c0 02 00 00         	movq	%r11, 0x2c0(%rax)
  656cd3: b9 01 00 00 00               	movl	$0x1, %ecx
  656cd8: eb 17                        	jmp	0x656cf1 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x651>
  656cda: e8 81 39 eb ff               	callq	0x50a660 <testing.(*B).loopSlowPath>
  656cdf: 48 8b 94 24 d8 00 00 00      	movq	0xd8(%rsp), %rdx
  656ce7: 89 c1                        	movl	%eax, %ecx
  656ce9: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656cf1: 84 c9                        	testb	%cl, %cl
  656cf3: 0f 85 63 ff ff ff            	jne	0x656c5c <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x5bc>
  656cf9: 48 8b 54 24 58               	movq	0x58(%rsp), %rdx
  656cfe: 66 90                        	nop
  656d00: 48 39 94 24 98 00 00 00      	cmpq	%rdx, 0x98(%rsp)
  656d08: 74 07                        	je	0x656d11 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x671>
  656d0a: b9 01 00 00 00               	movl	$0x1, %ecx
  656d0f: eb 77                        	jmp	0x656d88 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6e8>
  656d11: 48 8b 4c 24 68               	movq	0x68(%rsp), %rcx
  656d16: 48 8b 54 24 48               	movq	0x48(%rsp), %rdx
  656d1b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  656d20: 48 39 d1                     	cmpq	%rdx, %rcx
  656d23: 74 04                        	je	0x656d29 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x689>
  656d25: 31 c9                        	xorl	%ecx, %ecx
  656d27: eb 1f                        	jmp	0x656d48 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6a8>
  656d29: 48 8b 84 24 20 01 00 00      	movq	0x120(%rsp), %rax
  656d31: 48 8b 9c 24 c8 00 00 00      	movq	0xc8(%rsp), %rbx
  656d39: e8 22 bf da ff               	callq	0x402c60 <runtime.memequal>
  656d3e: 89 c1                        	movl	%eax, %ecx
  656d40: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656d48: 84 c9                        	testb	%cl, %cl
  656d4a: 74 37                        	je	0x656d83 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6e3>
  656d4c: 48 8b 54 24 40               	movq	0x40(%rsp), %rdx
  656d51: 48 8b 4c 24 78               	movq	0x78(%rsp), %rcx
  656d56: 48 39 ca                     	cmpq	%rcx, %rdx
  656d59: 74 04                        	je	0x656d5f <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6bf>
  656d5b: 31 c9                        	xorl	%ecx, %ecx
  656d5d: eb 1f                        	jmp	0x656d7e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6de>
  656d5f: 48 8b 84 24 18 01 00 00      	movq	0x118(%rsp), %rax
  656d67: 48 8b 9c 24 c0 00 00 00      	movq	0xc0(%rsp), %rbx
  656d6f: e8 ec be da ff               	callq	0x402c60 <runtime.memequal>
  656d74: 89 c1                        	movl	%eax, %ecx
  656d76: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656d7e: 83 f1 01                     	xorl	$0x1, %ecx
  656d81: eb 05                        	jmp	0x656d88 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6e8>
  656d83: b9 01 00 00 00               	movl	$0x1, %ecx
  656d88: 84 c9                        	testb	%cl, %cl
  656d8a: 74 32                        	je	0x656dbe <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x71e>
  656d8c: 48 8d 15 b5 2e 26 00         	leaq	0x262eb5(%rip), %rdx    # 0x8b9c48 <type:*+0x36190>
  656d93: 48 89 94 24 e8 00 00 00      	movq	%rdx, 0xe8(%rsp)
  656d9b: 48 8d 15 ce 22 03 00         	leaq	0x322ce(%rip), %rdx     # 0x689070 <internal/sync..dict.indirect[interface {},interface {}]+0x150>
  656da2: 48 89 94 24 f0 00 00 00      	movq	%rdx, 0xf0(%rsp)
  656daa: 48 8d 9c 24 e8 00 00 00      	leaq	0xe8(%rsp), %rbx
  656db2: b9 01 00 00 00               	movl	$0x1, %ecx
  656db7: 89 cf                        	movl	%ecx, %edi
  656db9: e8 22 f2 eb ff               	callq	0x515fe0 <testing.(*common).Fatal>
  656dbe: 48 8b 84 24 98 00 00 00      	movq	0x98(%rsp), %rax
  656dc6: 48 89 05 53 b0 2d 00         	movq	%rax, 0x2db053(%rip)    # 0x931e20 <github.com/thesyncim/govpx/internal/vp8/dsp.sse8RowsNativeSink>
  656dcd: 48 81 c4 30 01 00 00         	addq	$0x130, %rsp            # imm = 0x130
  656dd4: 5d                           	popq	%rbp
  656dd5: c3                           	retq
  656dd6: 90                           	nop
  656dd7: 48 8b 84 24 e0 00 00 00      	movq	0xe0(%rsp), %rax
  656ddf: 48 8b 5c 24 60               	movq	0x60(%rsp), %rbx
  656de4: 48 8b 8c 24 d0 00 00 00      	movq	0xd0(%rsp), %rcx
  656dec: 48 8b 7c 24 70               	movq	0x70(%rsp), %rdi
  656df1: e8 6a e4 fa ff               	callq	0x605260 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr>
  656df6: 89 c2                        	movl	%eax, %edx
  656df8: 48 89 94 24 98 00 00 00      	movq	%rdx, 0x98(%rsp)
  656e00: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656e08: 48 8b 90 c0 02 00 00         	movq	0x2c0(%rax), %rdx
  656e0f: 48 39 90 b8 02 00 00         	cmpq	%rdx, 0x2b8(%rax)
  656e16: 76 11                        	jbe	0x656e29 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x789>
  656e18: 48 ff c2                     	incq	%rdx
  656e1b: 48 89 90 c0 02 00 00         	movq	%rdx, 0x2c0(%rax)
  656e22: b9 01 00 00 00               	movl	$0x1, %ecx
  656e27: eb 0f                        	jmp	0x656e38 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x798>
  656e29: e8 32 38 eb ff               	callq	0x50a660 <testing.(*B).loopSlowPath>
  656e2e: 89 c1                        	movl	%eax, %ecx
  656e30: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656e38: 84 c9                        	testb	%cl, %cl
  656e3a: 75 9a                        	jne	0x656dd6 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x736>
  656e3c: 0f 1f 40 00                  	nopl	(%rax)
  656e40: e9 b4 fe ff ff               	jmp	0x656cf9 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x659>
  656e45: e8 b6 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e4a: e8 b1 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e4f: e8 ac 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e54: e8 a7 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e59: e8 a2 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e5e: 66 90                        	nop
  656e60: e8 9b 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e65: e8 96 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e6a: e8 91 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e6f: e8 8c 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e74: e8 87 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e79: 4c 8d 6a 01                  	leaq	0x1(%rdx), %r13
  656e7d: 4c 8b 9c 24 28 01 00 00      	movq	0x128(%rsp), %r11
  656e85: 4d 39 e5                     	cmpq	%r12, %r13
  656e88: 0f 8d d7 f9 ff ff            	jge	0x656865 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1c5>
  656e8e: 4d 89 ef                     	movq	%r13, %r15
  656e91: 4d 0f af ea                  	imulq	%r10, %r13
  656e95: 49 8d 55 0d                  	leaq	0xd(%r13), %rdx
  656e99: 48 39 fa                     	cmpq	%rdi, %rdx
  656e9c: 77 58                        	ja	0x656ef6 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x856>
  656e9e: 4d 8d 45 05                  	leaq	0x5(%r13), %r8
  656ea2: 4c 39 c2                     	cmpq	%r8, %rdx
  656ea5: 72 4a                        	jb	0x656ef1 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x851>
  656ea7: 4c 89 fa                     	movq	%r15, %rdx
  656eaa: 4c 0f af fb                  	imulq	%rbx, %r15
  656eae: 4d 8d 47 0b                  	leaq	0xb(%r15), %r8
  656eb2: 4d 8d 4c 05 00               	leaq	(%r13,%rax), %r9
  656eb7: 4d 8d 49 05                  	leaq	0x5(%r9), %r9
  656ebb: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  656ec0: 4c 39 c6                     	cmpq	%r8, %rsi
  656ec3: 72 27                        	jb	0x656eec <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x84c>
  656ec5: 4d 8d 5f 03                  	leaq	0x3(%r15), %r11
  656ec9: 4d 39 d8                     	cmpq	%r11, %r8
  656ecc: 72 19                        	jb	0x656ee7 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x847>
  656ece: 4d 8d 1c 0f                  	leaq	(%r15,%rcx), %r11
  656ed2: 4d 8d 5b 03                  	leaq	0x3(%r11), %r11
  656ed6: 4d 39 d9                     	cmpq	%r11, %r9
  656ed9: 74 9e                        	je	0x656e79 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7d9>
  656edb: 4d 8b 5c 0f 03               	movq	0x3(%r15,%rcx), %r11
  656ee0: 4d 89 5c 05 05               	movq	%r11, 0x5(%r13,%rax)
  656ee5: eb 92                        	jmp	0x656e79 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7d9>
  656ee7: e8 14 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656eec: e8 0f 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656ef1: e8 0a 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656ef6: e8 05 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656efb: 42 c6 04 20 ff               	movb	$-0x1, (%rax,%r12)
  656f00: 49 ff c4                     	incq	%r12
  656f03: 49 39 fc                     	cmpq	%rdi, %r12
  656f06: 7c f3                        	jl	0x656efb <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x85b>
  656f08: e9 58 f9 ff ff               	jmp	0x656865 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1c5>
  656f0d: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
  656f12: e8 09 79 e3 ff               	callq	0x48e820 <runtime.morestack.abi0>
  656f17: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
  656f1c: 0f 1f 40 00                  	nopl	(%rax)
  656f20: e9 7b f7 ff ff               	jmp	0x6566a0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1>
  656f25: cc                           	int3
  656f26: cc                           	int3
  656f27: cc                           	int3
  656f28: cc                           	int3
  656f29: cc                           	int3
  656f2a: cc                           	int3
  656f2b: cc                           	int3
  656f2c: cc                           	int3
  656f2d: cc                           	int3
  656f2e: cc                           	int3
  656f2f: cc                           	int3
  656f30: cc                           	int3
  656f31: cc                           	int3
  656f32: cc                           	int3
  656f33: cc                           	int3
  656f34: cc                           	int3
  656f35: cc                           	int3
  656f36: cc                           	int3
  656f37: cc                           	int3
  656f38: cc                           	int3
  656f39: cc                           	int3
  656f3a: cc                           	int3
  656f3b: cc                           	int3
  656f3c: cc                           	int3
  656f3d: cc                           	int3
  656f3e: cc                           	int3
  656f3f: cc                           	int3

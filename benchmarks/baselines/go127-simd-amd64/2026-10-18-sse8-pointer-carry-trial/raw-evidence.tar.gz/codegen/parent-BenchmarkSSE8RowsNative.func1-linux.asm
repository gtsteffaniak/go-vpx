
/private/tmp/govpx-sse8-pointer-carry-review/validation/parent-linux.test:	file format elf64-x86-64

Disassembly of section .text:

00000000006566c0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1>:
  6566c0: 4c 8d a4 24 48 ff ff ff      	leaq	-0xb8(%rsp), %r12
  6566c8: 4d 3b 66 10                  	cmpq	0x10(%r14), %r12
  6566cc: 0f 86 5b 08 00 00            	jbe	0x656f2d <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x86d>
  6566d2: 55                           	pushq	%rbp
  6566d3: 48 89 e5                     	movq	%rsp, %rbp
  6566d6: 48 81 ec 30 01 00 00         	subq	$0x130, %rsp            # imm = 0x130
  6566dd: 48 89 84 24 40 01 00 00      	movq	%rax, 0x140(%rsp)
  6566e5: 48 8b 72 10                  	movq	0x10(%rdx), %rsi
  6566e9: 48 89 b4 24 28 01 00 00      	movq	%rsi, 0x128(%rsp)
  6566f1: 48 8b 7a 08                  	movq	0x8(%rdx), %rdi
  6566f5: 48 8b 0f                     	movq	(%rdi), %rcx
  6566f8: 48 89 4c 24 60               	movq	%rcx, 0x60(%rsp)
  6566fd: 48 8b 7f 08                  	movq	0x8(%rdi), %rdi
  656701: 48 89 7c 24 70               	movq	%rdi, 0x70(%rsp)
  656706: 48 8b 5e 10                  	movq	0x10(%rsi), %rbx
  65670a: 48 ff cb                     	decq	%rbx
  65670d: 48 89 de                     	movq	%rbx, %rsi
  656710: 48 0f af ce                  	imulq	%rsi, %rcx
  656714: 48 89 8c 24 b8 00 00 00      	movq	%rcx, 0xb8(%rsp)
  65671c: 48 0f af df                  	imulq	%rdi, %rbx
  656720: 48 89 9c 24 b0 00 00 00      	movq	%rbx, 0xb0(%rsp)
  656728: 48 8d 73 1e                  	leaq	0x1e(%rbx), %rsi
  65672c: 48 89 74 24 78               	movq	%rsi, 0x78(%rsp)
  656731: 48 8b 52 18                  	movq	0x18(%rdx), %rdx
  656735: 48 89 94 24 90 00 00 00      	movq	%rdx, 0x90(%rsp)
  65673d: 48 83 c1 18                  	addq	$0x18, %rcx
  656741: 48 89 4c 24 68               	movq	%rcx, 0x68(%rsp)
  656746: 48 8d 05 2b 2f 26 00         	leaq	0x262f2b(%rip), %rax    # 0x8b9678 <type:*+0x36210>
  65674d: 48 89 cb                     	movq	%rcx, %rbx
  656750: e8 cb 4e e3 ff               	callq	0x48b620 <runtime.makeslice>
  656755: 48 89 84 24 20 01 00 00      	movq	%rax, 0x120(%rsp)
  65675d: 48 8d 05 14 2f 26 00         	leaq	0x262f14(%rip), %rax    # 0x8b9678 <type:*+0x36210>
  656764: 48 8b 5c 24 78               	movq	0x78(%rsp), %rbx
  656769: 48 89 d9                     	movq	%rbx, %rcx
  65676c: e8 af 4e e3 ff               	callq	0x48b620 <runtime.makeslice>
  656771: 31 d2                        	xorl	%edx, %edx
  656773: 48 8b 74 24 68               	movq	0x68(%rsp), %rsi
  656778: 48 8b bc 24 20 01 00 00      	movq	0x120(%rsp), %rdi
  656780: eb 32                        	jmp	0x6567b4 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0xf4>
  656782: 4c 8d 1c d2                  	leaq	(%rdx,%rdx,8), %r11
  656786: 4e 8d 1c 9a                  	leaq	(%rdx,%r11,4), %r11
  65678a: 48 89 c1                     	movq	%rax, %rcx
  65678d: 48 b8 8c 2e ba e8 a2 8b 2e ba	movabsq	$-0x45d1745d1745d174, %rax # imm = 0xBA2E8BA2E8BA2E8C
  656797: 48 89 d3                     	movq	%rdx, %rbx
  65679a: 48 f7 e2                     	mulq	%rdx
  65679d: 48 c1 ea 03                  	shrq	$0x3, %rdx
  6567a1: 4e 8d 1c 1a                  	leaq	(%rdx,%r11), %r11
  6567a5: 4d 8d 5b 13                  	leaq	0x13(%r11), %r11
  6567a9: 44 88 1c 1f                  	movb	%r11b, (%rdi,%rbx)
  6567ad: 48 8d 53 01                  	leaq	0x1(%rbx), %rdx
  6567b1: 48 89 c8                     	movq	%rcx, %rax
  6567b4: 48 39 d6                     	cmpq	%rdx, %rsi
  6567b7: 7f c9                        	jg	0x656782 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0xc2>
  6567b9: 45 31 db                     	xorl	%r11d, %r11d
  6567bc: 48 89 f9                     	movq	%rdi, %rcx
  6567bf: 48 8b 7c 24 78               	movq	0x78(%rsp), %rdi
  6567c4: eb 2e                        	jmp	0x6567f4 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x134>
  6567c6: 4d 6b e3 47                  	imulq	$0x47, %r11, %r12
  6567ca: 48 89 c2                     	movq	%rax, %rdx
  6567cd: 48 b8 4a 92 24 49 92 24 49 92	movabsq	$-0x6db6db6db6db6db6, %rax # imm = 0x924924924924924A
  6567d7: 48 89 d3                     	movq	%rdx, %rbx
  6567da: 49 f7 e3                     	mulq	%r11
  6567dd: 48 c1 ea 02                  	shrq	$0x2, %rdx
  6567e1: 4e 8d 24 22                  	leaq	(%rdx,%r12), %r12
  6567e5: 4d 8d 64 24 1f               	leaq	0x1f(%r12), %r12
  6567ea: 46 88 24 1b                  	movb	%r12b, (%rbx,%r11)
  6567ee: 49 ff c3                     	incq	%r11
  6567f1: 48 89 d8                     	movq	%rbx, %rax
  6567f4: 49 39 fb                     	cmpq	%rdi, %r11
  6567f7: 7c cd                        	jl	0x6567c6 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x106>
  6567f9: 48 89 84 24 18 01 00 00      	movq	%rax, 0x118(%rsp)
  656801: 4c 8b 9c 24 90 00 00 00      	movq	0x90(%rsp), %r11
  656809: 49 83 fb 01                  	cmpq	$0x1, %r11
  65680d: 75 51                        	jne	0x656860 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1a0>
  65680f: 48 8b 9c 24 b8 00 00 00      	movq	0xb8(%rsp), %rbx
  656817: 49 89 db                     	movq	%rbx, %r11
  65681a: 66 0f 1f 44 00 00            	nopw	(%rax,%rax)
  656820: 48 83 c3 18                  	addq	$0x18, %rbx
  656824: 74 2d                        	je	0x656853 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x193>
  656826: 48 89 c8                     	movq	%rcx, %rax
  656829: 48 89 f3                     	movq	%rsi, %rbx
  65682c: e8 6f 9d e3 ff               	callq	0x4905a0 <runtime.memclrNoHeapPointers>
  656831: 48 8b 84 24 18 01 00 00      	movq	0x118(%rsp), %rax
  656839: 48 8b 8c 24 20 01 00 00      	movq	0x120(%rsp), %rcx
  656841: 48 8b 74 24 68               	movq	0x68(%rsp), %rsi
  656846: 48 8b 7c 24 78               	movq	0x78(%rsp), %rdi
  65684b: 4c 8b 9c 24 b8 00 00 00      	movq	0xb8(%rsp), %r11
  656853: 45 31 e4                     	xorl	%r12d, %r12d
  656856: e9 c8 06 00 00               	jmp	0x656f23 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x863>
  65685b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  656860: 49 83 fb 02                  	cmpq	$0x2, %r11
  656864: 75 1f                        	jne	0x656885 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1c5>
  656866: 4c 8b 9c 24 28 01 00 00      	movq	0x128(%rsp), %r11
  65686e: 4d 8b 63 10                  	movq	0x10(%r11), %r12
  656872: 45 31 ed                     	xorl	%r13d, %r13d
  656875: 4c 8b 54 24 70               	movq	0x70(%rsp), %r10
  65687a: 48 8b 5c 24 60               	movq	0x60(%rsp), %rbx
  65687f: 90                           	nop
  656880: e9 20 06 00 00               	jmp	0x656ea5 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7e5>
  656885: 48 8b 9c 24 b8 00 00 00      	movq	0xb8(%rsp), %rbx
  65688d: 4c 8d 5b 0b                  	leaq	0xb(%rbx), %r11
  656891: 4c 39 de                     	cmpq	%r11, %rsi
  656894: 0f 82 fa 05 00 00            	jb	0x656e94 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7d4>
  65689a: 66 0f 1f 44 00 00            	nopw	(%rax,%rax)
  6568a0: 49 83 fb 03                  	cmpq	$0x3, %r11
  6568a4: 0f 82 e5 05 00 00            	jb	0x656e8f <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7cf>
  6568aa: 4c 8d 5b 15                  	leaq	0x15(%rbx), %r11
  6568ae: 4d 89 dc                     	movq	%r11, %r12
  6568b1: 49 f7 db                     	negq	%r11
  6568b4: 49 c1 fb 3f                  	sarq	$0x3f, %r11
  6568b8: 41 83 e3 03                  	andl	$0x3, %r11d
  6568bc: 4c 8b 8c 24 b0 00 00 00      	movq	0xb0(%rsp), %r9
  6568c4: 4d 8d 69 0d                  	leaq	0xd(%r9), %r13
  6568c8: 49 01 cb                     	addq	%rcx, %r11
  6568cb: 49 39 fd                     	cmpq	%rdi, %r13
  6568ce: 0f 87 b6 05 00 00            	ja	0x656e8a <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7ca>
  6568d4: 49 83 fd 05                  	cmpq	$0x5, %r13
  6568d8: 0f 82 a7 05 00 00            	jb	0x656e85 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7c5>
  6568de: 4c 89 a4 24 a8 00 00 00      	movq	%r12, 0xa8(%rsp)
  6568e6: 4c 89 9c 24 e0 00 00 00      	movq	%r11, 0xe0(%rsp)
  6568ee: 4d 8d 69 19                  	leaq	0x19(%r9), %r13
  6568f2: 4c 89 ac 24 88 00 00 00      	movq	%r13, 0x88(%rsp)
  6568fa: 4d 89 ef                     	movq	%r13, %r15
  6568fd: 49 f7 dd                     	negq	%r13
  656900: 49 c1 fd 3f                  	sarq	$0x3f, %r13
  656904: 41 83 e5 05                  	andl	$0x5, %r13d
  656908: 49 01 c5                     	addq	%rax, %r13
  65690b: 4c 89 ac 24 d0 00 00 00      	movq	%r13, 0xd0(%rsp)
  656913: 48 85 c9                     	testq	%rcx, %rcx
  656916: 75 0d                        	jne	0x656925 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x265>
  656918: 31 d2                        	xorl	%edx, %edx
  65691a: 45 31 c0                     	xorl	%r8d, %r8d
  65691d: 0f 1f 00                     	nopl	(%rax)
  656920: e9 8f 00 00 00               	jmp	0x6569b4 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x2f4>
  656925: 48 8d 44 24 40               	leaq	0x40(%rsp), %rax
  65692a: 48 89 f3                     	movq	%rsi, %rbx
  65692d: 31 c9                        	xorl	%ecx, %ecx
  65692f: 48 89 df                     	movq	%rbx, %rdi
  656932: 48 8d 35 3f 2d 26 00         	leaq	0x262d3f(%rip), %rsi    # 0x8b9678 <type:*+0x36210>
  656939: e8 c2 4d e3 ff               	callq	0x48b700 <runtime.growslice>
  65693e: 48 89 84 24 c8 00 00 00      	movq	%rax, 0xc8(%rsp)
  656946: 48 89 5c 24 48               	movq	%rbx, 0x48(%rsp)
  65694b: 48 8b 9c 24 20 01 00 00      	movq	0x120(%rsp), %rbx
  656953: 48 8b 4c 24 68               	movq	0x68(%rsp), %rcx
  656958: e8 43 9f e3 ff               	callq	0x4908a0 <runtime.memmove>
  65695d: 48 8b 84 24 18 01 00 00      	movq	0x118(%rsp), %rax
  656965: 48 8b 8c 24 20 01 00 00      	movq	0x120(%rsp), %rcx
  65696d: 48 8b 9c 24 b8 00 00 00      	movq	0xb8(%rsp), %rbx
  656975: 48 8b 74 24 68               	movq	0x68(%rsp), %rsi
  65697a: 48 8b 7c 24 78               	movq	0x78(%rsp), %rdi
  65697f: 4c 8b 8c 24 b0 00 00 00      	movq	0xb0(%rsp), %r9
  656987: 4c 8b 9c 24 e0 00 00 00      	movq	0xe0(%rsp), %r11
  65698f: 4c 8b a4 24 a8 00 00 00      	movq	0xa8(%rsp), %r12
  656997: 4c 8b ac 24 d0 00 00 00      	movq	0xd0(%rsp), %r13
  65699f: 4c 8b bc 24 88 00 00 00      	movq	0x88(%rsp), %r15
  6569a7: 48 8b 54 24 48               	movq	0x48(%rsp), %rdx
  6569ac: 4c 8b 84 24 c8 00 00 00      	movq	0xc8(%rsp), %r8
  6569b4: 48 89 54 24 48               	movq	%rdx, 0x48(%rsp)
  6569b9: 4c 89 84 24 c8 00 00 00      	movq	%r8, 0xc8(%rsp)
  6569c1: 48 85 c0                     	testq	%rax, %rax
  6569c4: 75 13                        	jne	0x6569d9 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x319>
  6569c6: 45 31 d2                     	xorl	%r10d, %r10d
  6569c9: 45 31 d2                     	xorl	%r10d, %r10d
  6569cc: 4c 89 94 24 c0 00 00 00      	movq	%r10, 0xc0(%rsp)
  6569d4: 45 31 d2                     	xorl	%r10d, %r10d
  6569d7: eb 74                        	jmp	0x656a4d <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x38d>
  6569d9: 48 8d 44 24 40               	leaq	0x40(%rsp), %rax
  6569de: 48 89 fb                     	movq	%rdi, %rbx
  6569e1: 31 c9                        	xorl	%ecx, %ecx
  6569e3: 48 8d 35 8e 2c 26 00         	leaq	0x262c8e(%rip), %rsi    # 0x8b9678 <type:*+0x36210>
  6569ea: e8 11 4d e3 ff               	callq	0x48b700 <runtime.growslice>
  6569ef: 48 89 84 24 c0 00 00 00      	movq	%rax, 0xc0(%rsp)
  6569f7: 48 89 5c 24 40               	movq	%rbx, 0x40(%rsp)
  6569fc: 48 8b 9c 24 18 01 00 00      	movq	0x118(%rsp), %rbx
  656a04: 48 8b 4c 24 78               	movq	0x78(%rsp), %rcx
  656a09: e8 92 9e e3 ff               	callq	0x4908a0 <runtime.memmove>
  656a0e: 48 8b 8c 24 20 01 00 00      	movq	0x120(%rsp), %rcx
  656a16: 48 8b 54 24 48               	movq	0x48(%rsp), %rdx
  656a1b: 48 8b 9c 24 b8 00 00 00      	movq	0xb8(%rsp), %rbx
  656a23: 48 8b 74 24 68               	movq	0x68(%rsp), %rsi
  656a28: 4c 8b 84 24 c8 00 00 00      	movq	0xc8(%rsp), %r8
  656a30: 4c 8b 8c 24 b0 00 00 00      	movq	0xb0(%rsp), %r9
  656a38: 4c 8b 9c 24 e0 00 00 00      	movq	0xe0(%rsp), %r11
  656a40: 4c 8b ac 24 d0 00 00 00      	movq	0xd0(%rsp), %r13
  656a48: 4c 8b 54 24 40               	movq	0x40(%rsp), %r10
  656a4d: 4c 89 54 24 40               	movq	%r10, 0x40(%rsp)
  656a52: 48 83 c3 08                  	addq	$0x8, %rbx
  656a56: 49 83 c1 08                  	addq	$0x8, %r9
  656a5a: 4c 8b a4 24 28 01 00 00      	movq	0x128(%rsp), %r12
  656a62: 49 8b 44 24 10               	movq	0x10(%r12), %rax
  656a67: 45 31 ff                     	xorl	%r15d, %r15d
  656a6a: 45 31 e4                     	xorl	%r12d, %r12d
  656a6d: 48 8b 7c 24 60               	movq	0x60(%rsp), %rdi
  656a72: 4c 8b 54 24 70               	movq	0x70(%rsp), %r10
  656a77: eb 1d                        	jmp	0x656a96 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x3d6>
  656a79: 4c 8b 64 24 50               	movq	0x50(%rsp), %r12
  656a7e: 49 ff c4                     	incq	%r12
  656a81: 48 8b 8c 24 20 01 00 00      	movq	0x120(%rsp), %rcx
  656a89: 48 8b 74 24 68               	movq	0x68(%rsp), %rsi
  656a8e: 4c 8b ac 24 d0 00 00 00      	movq	0xd0(%rsp), %r13
  656a96: 49 39 c4                     	cmpq	%rax, %r12
  656a99: 7d 63                        	jge	0x656afe <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x43e>
  656a9b: 4c 89 64 24 50               	movq	%r12, 0x50(%rsp)
  656aa0: 4c 0f af e7                  	imulq	%rdi, %r12
  656aa4: 4c 8b 6c 24 50               	movq	0x50(%rsp), %r13
  656aa9: 4d 0f af ea                  	imulq	%r10, %r13
  656aad: 31 c9                        	xorl	%ecx, %ecx
  656aaf: 48 8b b4 24 d0 00 00 00      	movq	0xd0(%rsp), %rsi
  656ab7: eb 1e                        	jmp	0x656ad7 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x417>
  656ab9: 0f b6 14 16                  	movzbl	(%rsi,%rdx), %edx
  656abd: 49 29 d0                     	subq	%rdx, %r8
  656ac0: 4d 0f af c0                  	imulq	%r8, %r8
  656ac4: 4d 01 c7                     	addq	%r8, %r15
  656ac7: 48 ff c1                     	incq	%rcx
  656aca: 48 8b 54 24 48               	movq	0x48(%rsp), %rdx
  656acf: 4c 8b 84 24 c8 00 00 00      	movq	0xc8(%rsp), %r8
  656ad7: 48 83 f9 08                  	cmpq	$0x8, %rcx
  656adb: 7d 9c                        	jge	0x656a79 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x3b9>
  656add: 4d 8d 04 0c                  	leaq	(%r12,%rcx), %r8
  656ae1: 4c 39 c3                     	cmpq	%r8, %rbx
  656ae4: 0f 86 94 03 00 00            	jbe	0x656e7e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7be>
  656aea: 49 8d 54 0d 00               	leaq	(%r13,%rcx), %rdx
  656aef: 47 0f b6 04 03               	movzbl	(%r11,%r8), %r8d
  656af4: 49 39 d1                     	cmpq	%rdx, %r9
  656af7: 77 c0                        	ja	0x656ab9 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x3f9>
  656af9: e9 7b 03 00 00               	jmp	0x656e79 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7b9>
  656afe: 48 89 9c 24 a0 00 00 00      	movq	%rbx, 0xa0(%rsp)
  656b06: 4c 89 8c 24 80 00 00 00      	movq	%r9, 0x80(%rsp)
  656b0e: 4c 89 7c 24 58               	movq	%r15, 0x58(%rsp)
  656b13: 48 c7 84 24 98 00 00 00 00 00 00 00  	movq	$0x0, 0x98(%rsp)
  656b1f: 4c 8b a4 24 28 01 00 00      	movq	0x128(%rsp), %r12
  656b27: 41 80 7c 24 20 00            	cmpb	$0x0, 0x20(%r12)
  656b2d: 74 38                        	je	0x656b67 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x4a7>
  656b2f: 48 85 db                     	testq	%rbx, %rbx
  656b32: 0f 86 3c 03 00 00            	jbe	0x656e74 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7b4>
  656b38: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)
  656b40: 4d 85 c9                     	testq	%r9, %r9
  656b43: 0f 86 26 03 00 00            	jbe	0x656e6f <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7af>
  656b49: 90                           	nop
  656b4a: 4c 89 d8                     	movq	%r11, %rax
  656b4d: 48 89 fb                     	movq	%rdi, %rbx
  656b50: 4c 89 e9                     	movq	%r13, %rcx
  656b53: 4c 89 d7                     	movq	%r10, %rdi
  656b56: e8 05 e7 fa ff               	callq	0x605260 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr>
  656b5b: 89 c2                        	movl	%eax, %edx
  656b5d: 48 89 94 24 98 00 00 00      	movq	%rdx, 0x98(%rsp)
  656b65: eb 2c                        	jmp	0x656b93 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x4d3>
  656b67: 49 8b 54 24 18               	movq	0x18(%r12), %rdx
  656b6c: 4c 8b 22                     	movq	(%rdx), %r12
  656b6f: 4c 89 d8                     	movq	%r11, %rax
  656b72: 48 8b 8c 24 a8 00 00 00      	movq	0xa8(%rsp), %rcx
  656b7a: 4c 89 ee                     	movq	%r13, %rsi
  656b7d: 4d 89 c8                     	movq	%r9, %r8
  656b80: 4c 8b 8c 24 88 00 00 00      	movq	0x88(%rsp), %r9
  656b88: 41 ff d4                     	callq	*%r12
  656b8b: 48 89 84 24 98 00 00 00      	movq	%rax, 0x98(%rsp)
  656b93: 48 8b 84 24 98 00 00 00      	movq	0x98(%rsp), %rax
  656b9b: 48 8b 4c 24 58               	movq	0x58(%rsp), %rcx
  656ba0: 48 39 c1                     	cmpq	%rax, %rcx
  656ba3: 74 79                        	je	0x656c1e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x55e>
  656ba5: 48 8d 8c 24 f8 00 00 00      	leaq	0xf8(%rsp), %rcx
  656bad: 44 0f 11 39                  	movups	%xmm15, (%rcx)
  656bb1: 44 0f 11 79 10               	movups	%xmm15, 0x10(%rcx)
  656bb6: e8 a5 0a e3 ff               	callq	0x487660 <runtime.convT64>
  656bbb: 48 8d 0d 76 2c 26 00         	leaq	0x262c76(%rip), %rcx    # 0x8b9838 <type:*+0x363d0>
  656bc2: 48 89 8c 24 f8 00 00 00      	movq	%rcx, 0xf8(%rsp)
  656bca: 48 89 84 24 00 01 00 00      	movq	%rax, 0x100(%rsp)
  656bd2: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
  656bd7: e8 84 0a e3 ff               	callq	0x487660 <runtime.convT64>
  656bdc: 48 8d 0d 55 2c 26 00         	leaq	0x262c55(%rip), %rcx    # 0x8b9838 <type:*+0x363d0>
  656be3: 48 89 8c 24 08 01 00 00      	movq	%rcx, 0x108(%rsp)
  656beb: 48 89 84 24 10 01 00 00      	movq	%rax, 0x110(%rsp)
  656bf3: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656bfb: 84 00                        	testb	%al, (%rax)
  656bfd: 48 8d 1d b5 09 02 00         	leaq	0x209b5(%rip), %rbx     # 0x6775b9 <runtime.rodata+0x75b9>
  656c04: b9 18 00 00 00               	movl	$0x18, %ecx
  656c09: 48 8d bc 24 f8 00 00 00      	leaq	0xf8(%rsp), %rdi
  656c11: be 02 00 00 00               	movl	$0x2, %esi
  656c16: 41 89 f0                     	movl	%esi, %r8d
  656c19: e8 c2 f4 eb ff               	callq	0x5160e0 <testing.(*common).Fatalf>
  656c1e: 90                           	nop
  656c1f: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656c27: c6 80 52 02 00 00 01         	movb	$0x1, 0x252(%rax)
  656c2e: e8 ad 2c eb ff               	callq	0x5098e0 <testing.(*B).ResetTimer>
  656c33: 48 8b 8c 24 28 01 00 00      	movq	0x128(%rsp), %rcx
  656c3b: 80 79 20 00                  	cmpb	$0x0, 0x20(%rcx)
  656c3f: 90                           	nop
  656c40: 74 2c                        	je	0x656c6e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x5ae>
  656c42: 48 8b 94 24 a0 00 00 00      	movq	0xa0(%rsp), %rdx
  656c4a: 48 85 d2                     	testq	%rdx, %rdx
  656c4d: 0f 86 17 02 00 00            	jbe	0x656e6a <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7aa>
  656c53: 48 8b 94 24 80 00 00 00      	movq	0x80(%rsp), %rdx
  656c5b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  656c60: 48 85 d2                     	testq	%rdx, %rdx
  656c63: 0f 87 b7 01 00 00            	ja	0x656e20 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x760>
  656c69: e9 f7 01 00 00               	jmp	0x656e65 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7a5>
  656c6e: 48 8b 51 18                  	movq	0x18(%rcx), %rdx
  656c72: 48 89 94 24 d8 00 00 00      	movq	%rdx, 0xd8(%rsp)
  656c7a: eb 50                        	jmp	0x656ccc <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x60c>
  656c7c: 4c 8b 1a                     	movq	(%rdx), %r11
  656c7f: 48 8b 84 24 e0 00 00 00      	movq	0xe0(%rsp), %rax
  656c87: 48 8b 9c 24 a0 00 00 00      	movq	0xa0(%rsp), %rbx
  656c8f: 48 8b 8c 24 a8 00 00 00      	movq	0xa8(%rsp), %rcx
  656c97: 48 8b 7c 24 60               	movq	0x60(%rsp), %rdi
  656c9c: 48 8b b4 24 d0 00 00 00      	movq	0xd0(%rsp), %rsi
  656ca4: 4c 8b 84 24 80 00 00 00      	movq	0x80(%rsp), %r8
  656cac: 4c 8b 8c 24 88 00 00 00      	movq	0x88(%rsp), %r9
  656cb4: 4c 8b 54 24 70               	movq	0x70(%rsp), %r10
  656cb9: 41 ff d3                     	callq	*%r11
  656cbc: 48 89 84 24 98 00 00 00      	movq	%rax, 0x98(%rsp)
  656cc4: 48 8b 94 24 d8 00 00 00      	movq	0xd8(%rsp), %rdx
  656ccc: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656cd4: 4c 8b 98 c0 02 00 00         	movq	0x2c0(%rax), %r11
  656cdb: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  656ce0: 4c 39 98 b8 02 00 00         	cmpq	%r11, 0x2b8(%rax)
  656ce7: 76 11                        	jbe	0x656cfa <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x63a>
  656ce9: 49 ff c3                     	incq	%r11
  656cec: 4c 89 98 c0 02 00 00         	movq	%r11, 0x2c0(%rax)
  656cf3: b9 01 00 00 00               	movl	$0x1, %ecx
  656cf8: eb 17                        	jmp	0x656d11 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x651>
  656cfa: e8 61 39 eb ff               	callq	0x50a660 <testing.(*B).loopSlowPath>
  656cff: 48 8b 94 24 d8 00 00 00      	movq	0xd8(%rsp), %rdx
  656d07: 89 c1                        	movl	%eax, %ecx
  656d09: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656d11: 84 c9                        	testb	%cl, %cl
  656d13: 0f 85 63 ff ff ff            	jne	0x656c7c <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x5bc>
  656d19: 48 8b 54 24 58               	movq	0x58(%rsp), %rdx
  656d1e: 66 90                        	nop
  656d20: 48 39 94 24 98 00 00 00      	cmpq	%rdx, 0x98(%rsp)
  656d28: 74 07                        	je	0x656d31 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x671>
  656d2a: b9 01 00 00 00               	movl	$0x1, %ecx
  656d2f: eb 77                        	jmp	0x656da8 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6e8>
  656d31: 48 8b 4c 24 68               	movq	0x68(%rsp), %rcx
  656d36: 48 8b 54 24 48               	movq	0x48(%rsp), %rdx
  656d3b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  656d40: 48 39 d1                     	cmpq	%rdx, %rcx
  656d43: 74 04                        	je	0x656d49 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x689>
  656d45: 31 c9                        	xorl	%ecx, %ecx
  656d47: eb 1f                        	jmp	0x656d68 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6a8>
  656d49: 48 8b 84 24 20 01 00 00      	movq	0x120(%rsp), %rax
  656d51: 48 8b 9c 24 c8 00 00 00      	movq	0xc8(%rsp), %rbx
  656d59: e8 02 bf da ff               	callq	0x402c60 <runtime.memequal>
  656d5e: 89 c1                        	movl	%eax, %ecx
  656d60: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656d68: 84 c9                        	testb	%cl, %cl
  656d6a: 74 37                        	je	0x656da3 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6e3>
  656d6c: 48 8b 54 24 40               	movq	0x40(%rsp), %rdx
  656d71: 48 8b 4c 24 78               	movq	0x78(%rsp), %rcx
  656d76: 48 39 ca                     	cmpq	%rcx, %rdx
  656d79: 74 04                        	je	0x656d7f <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6bf>
  656d7b: 31 c9                        	xorl	%ecx, %ecx
  656d7d: eb 1f                        	jmp	0x656d9e <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6de>
  656d7f: 48 8b 84 24 18 01 00 00      	movq	0x118(%rsp), %rax
  656d87: 48 8b 9c 24 c0 00 00 00      	movq	0xc0(%rsp), %rbx
  656d8f: e8 cc be da ff               	callq	0x402c60 <runtime.memequal>
  656d94: 89 c1                        	movl	%eax, %ecx
  656d96: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656d9e: 83 f1 01                     	xorl	$0x1, %ecx
  656da1: eb 05                        	jmp	0x656da8 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x6e8>
  656da3: b9 01 00 00 00               	movl	$0x1, %ecx
  656da8: 84 c9                        	testb	%cl, %cl
  656daa: 74 32                        	je	0x656dde <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x71e>
  656dac: 48 8d 15 45 28 26 00         	leaq	0x262845(%rip), %rdx    # 0x8b95f8 <type:*+0x36190>
  656db3: 48 89 94 24 e8 00 00 00      	movq	%rdx, 0xe8(%rsp)
  656dbb: 48 8d 15 ae 22 03 00         	leaq	0x322ae(%rip), %rdx     # 0x689070 <internal/sync..dict.indirect[interface {},interface {}]+0x150>
  656dc2: 48 89 94 24 f0 00 00 00      	movq	%rdx, 0xf0(%rsp)
  656dca: 48 8d 9c 24 e8 00 00 00      	leaq	0xe8(%rsp), %rbx
  656dd2: b9 01 00 00 00               	movl	$0x1, %ecx
  656dd7: 89 cf                        	movl	%ecx, %edi
  656dd9: e8 02 f2 eb ff               	callq	0x515fe0 <testing.(*common).Fatal>
  656dde: 48 8b 84 24 98 00 00 00      	movq	0x98(%rsp), %rax
  656de6: 48 89 05 f3 af 2d 00         	movq	%rax, 0x2daff3(%rip)    # 0x931de0 <github.com/thesyncim/govpx/internal/vp8/dsp.sse8RowsNativeSink>
  656ded: 48 81 c4 30 01 00 00         	addq	$0x130, %rsp            # imm = 0x130
  656df4: 5d                           	popq	%rbp
  656df5: c3                           	retq
  656df6: 90                           	nop
  656df7: 48 8b 84 24 e0 00 00 00      	movq	0xe0(%rsp), %rax
  656dff: 48 8b 5c 24 60               	movq	0x60(%rsp), %rbx
  656e04: 48 8b 8c 24 d0 00 00 00      	movq	0xd0(%rsp), %rcx
  656e0c: 48 8b 7c 24 70               	movq	0x70(%rsp), %rdi
  656e11: e8 4a e4 fa ff               	callq	0x605260 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr>
  656e16: 89 c2                        	movl	%eax, %edx
  656e18: 48 89 94 24 98 00 00 00      	movq	%rdx, 0x98(%rsp)
  656e20: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656e28: 48 8b 90 c0 02 00 00         	movq	0x2c0(%rax), %rdx
  656e2f: 48 39 90 b8 02 00 00         	cmpq	%rdx, 0x2b8(%rax)
  656e36: 76 11                        	jbe	0x656e49 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x789>
  656e38: 48 ff c2                     	incq	%rdx
  656e3b: 48 89 90 c0 02 00 00         	movq	%rdx, 0x2c0(%rax)
  656e42: b9 01 00 00 00               	movl	$0x1, %ecx
  656e47: eb 0f                        	jmp	0x656e58 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x798>
  656e49: e8 12 38 eb ff               	callq	0x50a660 <testing.(*B).loopSlowPath>
  656e4e: 89 c1                        	movl	%eax, %ecx
  656e50: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
  656e58: 84 c9                        	testb	%cl, %cl
  656e5a: 75 9a                        	jne	0x656df6 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x736>
  656e5c: 0f 1f 40 00                  	nopl	(%rax)
  656e60: e9 b4 fe ff ff               	jmp	0x656d19 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x659>
  656e65: e8 96 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e6a: e8 91 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e6f: e8 8c 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e74: e8 87 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e79: e8 82 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e7e: 66 90                        	nop
  656e80: e8 7b 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e85: e8 76 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e8a: e8 71 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e8f: e8 6c 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e94: e8 67 96 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656e99: 4c 8d 6a 01                  	leaq	0x1(%rdx), %r13
  656e9d: 4c 8b 9c 24 28 01 00 00      	movq	0x128(%rsp), %r11
  656ea5: 4d 39 e5                     	cmpq	%r12, %r13
  656ea8: 0f 8d d7 f9 ff ff            	jge	0x656885 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1c5>
  656eae: 4d 89 ef                     	movq	%r13, %r15
  656eb1: 4d 0f af ea                  	imulq	%r10, %r13
  656eb5: 49 8d 55 0d                  	leaq	0xd(%r13), %rdx
  656eb9: 48 39 fa                     	cmpq	%rdi, %rdx
  656ebc: 77 58                        	ja	0x656f16 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x856>
  656ebe: 4d 8d 45 05                  	leaq	0x5(%r13), %r8
  656ec2: 4c 39 c2                     	cmpq	%r8, %rdx
  656ec5: 72 4a                        	jb	0x656f11 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x851>
  656ec7: 4c 89 fa                     	movq	%r15, %rdx
  656eca: 4c 0f af fb                  	imulq	%rbx, %r15
  656ece: 4d 8d 47 0b                  	leaq	0xb(%r15), %r8
  656ed2: 4d 8d 4c 05 00               	leaq	(%r13,%rax), %r9
  656ed7: 4d 8d 49 05                  	leaq	0x5(%r9), %r9
  656edb: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  656ee0: 4c 39 c6                     	cmpq	%r8, %rsi
  656ee3: 72 27                        	jb	0x656f0c <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x84c>
  656ee5: 4d 8d 5f 03                  	leaq	0x3(%r15), %r11
  656ee9: 4d 39 d8                     	cmpq	%r11, %r8
  656eec: 72 19                        	jb	0x656f07 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x847>
  656eee: 4d 8d 1c 0f                  	leaq	(%r15,%rcx), %r11
  656ef2: 4d 8d 5b 03                  	leaq	0x3(%r11), %r11
  656ef6: 4d 39 d9                     	cmpq	%r11, %r9
  656ef9: 74 9e                        	je	0x656e99 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7d9>
  656efb: 4d 8b 5c 0f 03               	movq	0x3(%r15,%rcx), %r11
  656f00: 4d 89 5c 05 05               	movq	%r11, 0x5(%r13,%rax)
  656f05: eb 92                        	jmp	0x656e99 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x7d9>
  656f07: e8 f4 95 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656f0c: e8 ef 95 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656f11: e8 ea 95 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656f16: e8 e5 95 e3 ff               	callq	0x490500 <runtime.panicBounds>
  656f1b: 42 c6 04 20 ff               	movb	$-0x1, (%rax,%r12)
  656f20: 49 ff c4                     	incq	%r12
  656f23: 49 39 fc                     	cmpq	%rdi, %r12
  656f26: 7c f3                        	jl	0x656f1b <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x85b>
  656f28: e9 58 f9 ff ff               	jmp	0x656885 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1+0x1c5>
  656f2d: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
  656f32: e8 e9 78 e3 ff               	callq	0x48e820 <runtime.morestack.abi0>
  656f37: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
  656f3c: 0f 1f 40 00                  	nopl	(%rax)
  656f40: e9 7b f7 ff ff               	jmp	0x6566c0 <github.com/thesyncim/govpx/internal/vp8/dsp.BenchmarkSSE8RowsNative.func1>
  656f45: cc                           	int3
  656f46: cc                           	int3
  656f47: cc                           	int3
  656f48: cc                           	int3
  656f49: cc                           	int3
  656f4a: cc                           	int3
  656f4b: cc                           	int3
  656f4c: cc                           	int3
  656f4d: cc                           	int3
  656f4e: cc                           	int3
  656f4f: cc                           	int3
  656f50: cc                           	int3
  656f51: cc                           	int3
  656f52: cc                           	int3
  656f53: cc                           	int3
  656f54: cc                           	int3
  656f55: cc                           	int3
  656f56: cc                           	int3
  656f57: cc                           	int3
  656f58: cc                           	int3
  656f59: cc                           	int3
  656f5a: cc                           	int3
  656f5b: cc                           	int3
  656f5c: cc                           	int3
  656f5d: cc                           	int3
  656f5e: cc                           	int3
  656f5f: cc                           	int3

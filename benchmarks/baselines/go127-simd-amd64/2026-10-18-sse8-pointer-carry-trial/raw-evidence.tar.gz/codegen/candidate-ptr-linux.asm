
/private/tmp/govpx-sse8-pointer-carry-review/validation/dsp-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000605260 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr>:
  605260: 49 3b 66 10                  	cmpq	0x10(%r14), %rsp
  605264: 0f 86 94 01 00 00            	jbe	0x6053fe <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x19e>
  60526a: 55                           	pushq	%rbp
  60526b: 48 89 e5                     	movq	%rsp, %rbp
  60526e: 48 83 ec 48                  	subq	$0x48, %rsp
  605272: 80 3d be ca 32 00 00         	cmpb	$0x0, 0x32cabe(%rip)    # 0x931d37 <github.com/thesyncim/govpx/internal/pixel.Enabled>
  605279: 74 47                        	je	0x6052c2 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x62>
  60527b: 80 3d e2 d6 32 00 00         	cmpb	$0x0, 0x32d6e2(%rip)    # 0x932964 <internal/cpu.X86+0x44>
  605282: 74 39                        	je	0x6052bd <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x5d>
  605284: 48 85 c0                     	testq	%rax, %rax
  605287: 74 2f                        	je	0x6052b8 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x58>
  605289: 48 85 c9                     	testq	%rcx, %rcx
  60528c: 74 25                        	je	0x6052b3 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x53>
  60528e: 49 89 fa                     	movq	%rdi, %r10
  605291: 48 09 df                     	orq	%rbx, %rdi
  605294: 48 c1 ef 1e                  	shrq	$0x1e, %rdi
  605298: 48 85 ff                     	testq	%rdi, %rdi
  60529b: 75 28                        	jne	0x6052c5 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x65>
  60529d: c5 fd ef c0                  	vpxor	%ymm0, %ymm0, %ymm0
  6052a1: 48 8d 14 5b                  	leaq	(%rbx,%rbx,2), %rdx
  6052a5: 4b 8d 34 52                  	leaq	(%r10,%r10,2), %rsi
  6052a9: bf 08 00 00 00               	movl	$0x8, %edi
  6052ae: e9 a4 00 00 00               	jmp	0x605357 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xf7>
  6052b3: 49 89 fa                     	movq	%rdi, %r10
  6052b6: eb 0d                        	jmp	0x6052c5 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x65>
  6052b8: 49 89 fa                     	movq	%rdi, %r10
  6052bb: eb 08                        	jmp	0x6052c5 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x65>
  6052bd: 49 89 fa                     	movq	%rdi, %r10
  6052c0: eb 03                        	jmp	0x6052c5 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x65>
  6052c2: 49 89 fa                     	movq	%rdi, %r10
  6052c5: 48 8d 14 5b                  	leaq	(%rbx,%rbx,2), %rdx
  6052c9: 48 8d 14 53                  	leaq	(%rbx,%rdx,2), %rdx
  6052cd: 48 8d 52 08                  	leaq	0x8(%rdx), %rdx
  6052d1: 48 85 d2                     	testq	%rdx, %rdx
  6052d4: 7c 74                        	jl	0x60534a <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xea>
  6052d6: 49 89 c4                     	movq	%rax, %r12
  6052d9: 49 f7 dc                     	negq	%r12
  6052dc: 0f 1f 40 00                  	nopl	(%rax)
  6052e0: 4c 39 e2                     	cmpq	%r12, %rdx
  6052e3: 77 51                        	ja	0x605336 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xd6>
  6052e5: 4f 8d 24 52                  	leaq	(%r10,%r10,2), %r12
  6052e9: 4f 8d 0c 62                  	leaq	(%r10,%r12,2), %r9
  6052ed: 4d 8d 49 08                  	leaq	0x8(%r9), %r9
  6052f1: 4d 85 c9                     	testq	%r9, %r9
  6052f4: 7c 3b                        	jl	0x605331 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xd1>
  6052f6: 48 89 ce                     	movq	%rcx, %rsi
  6052f9: 48 f7 d9                     	negq	%rcx
  6052fc: 0f 1f 40 00                  	nopl	(%rax)
  605300: 49 39 c9                     	cmpq	%rcx, %r9
  605303: 77 1d                        	ja	0x605322 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xc2>
  605305: 48 89 d1                     	movq	%rdx, %rcx
  605308: 48 89 df                     	movq	%rbx, %rdi
  60530b: 4d 89 c8                     	movq	%r9, %r8
  60530e: 41 bb 08 00 00 00            	movl	$0x8, %r11d
  605314: 48 89 cb                     	movq	%rcx, %rbx
  605317: e8 24 01 00 00               	callq	0x605440 <github.com/thesyncim/govpx/internal/pixel.SSE8>
  60531c: 48 83 c4 48                  	addq	$0x48, %rsp
  605320: 5d                           	popq	%rbp
  605321: c3                           	retq
  605322: 48 85 f6                     	testq	%rsi, %rsi
  605325: 74 05                        	je	0x60532c <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xcc>
  605327: e8 14 8e e7 ff               	callq	0x47e140 <runtime.panicunsafeslicelen>
  60532c: e8 af 8e e7 ff               	callq	0x47e1e0 <runtime.panicunsafeslicenilptr>
  605331: e8 0a 8e e7 ff               	callq	0x47e140 <runtime.panicunsafeslicelen>
  605336: 48 85 c0                     	testq	%rax, %rax
  605339: 74 0a                        	je	0x605345 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xe5>
  60533b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  605340: e8 fb 8d e7 ff               	callq	0x47e140 <runtime.panicunsafeslicelen>
  605345: e8 96 8e e7 ff               	callq	0x47e1e0 <runtime.panicunsafeslicenilptr>
  60534a: e8 f1 8d e7 ff               	callq	0x47e140 <runtime.panicunsafeslicelen>
  60534f: 48 8d 04 98                  	leaq	(%rax,%rbx,4), %rax
  605353: 4a 8d 0c 91                  	leaq	(%rcx,%r10,4), %rcx
  605357: c4 e1 f9 6e 08               	vmovq	(%rax), %xmm1
  60535c: 4c 8b 04 18                  	movq	(%rax,%rbx), %r8
  605360: c4 c3 f1 22 c8 01            	vpinsrq	$0x1, %r8, %xmm1, %xmm1
  605366: c4 e2 7d 30 c9               	vpmovzxbw	%xmm1, %ymm1    # ymm1 = xmm1[0],zero,xmm1[1],zero,xmm1[2],zero,xmm1[3],zero,xmm1[4],zero,xmm1[5],zero,xmm1[6],zero,xmm1[7],zero,xmm1[8],zero,xmm1[9],zero,xmm1[10],zero,xmm1[11],zero,xmm1[12],zero,xmm1[13],zero,xmm1[14],zero,xmm1[15],zero
  60536b: c4 e1 f9 6e 11               	vmovq	(%rcx), %xmm2
  605370: 4e 8b 04 11                  	movq	(%rcx,%r10), %r8
  605374: c4 c3 e9 22 d0 01            	vpinsrq	$0x1, %r8, %xmm2, %xmm2
  60537a: c4 e2 7d 30 d2               	vpmovzxbw	%xmm2, %ymm2    # ymm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero,xmm2[8],zero,xmm2[9],zero,xmm2[10],zero,xmm2[11],zero,xmm2[12],zero,xmm2[13],zero,xmm2[14],zero,xmm2[15],zero
  60537f: c5 f5 f9 ca                  	vpsubw	%ymm2, %ymm1, %ymm1
  605383: c5 f5 f5 c9                  	vpmaddwd	%ymm1, %ymm1, %ymm1
  605387: c5 fd fe c1                  	vpaddd	%ymm1, %ymm0, %ymm0
  60538b: 4c 8d 04 58                  	leaq	(%rax,%rbx,2), %r8
  60538f: c4 c1 f9 6e 08               	vmovq	(%r8), %xmm1
  605394: 4c 8b 04 10                  	movq	(%rax,%rdx), %r8
  605398: c4 c3 f1 22 c8 01            	vpinsrq	$0x1, %r8, %xmm1, %xmm1
  60539e: c4 e2 7d 30 c9               	vpmovzxbw	%xmm1, %ymm1    # ymm1 = xmm1[0],zero,xmm1[1],zero,xmm1[2],zero,xmm1[3],zero,xmm1[4],zero,xmm1[5],zero,xmm1[6],zero,xmm1[7],zero,xmm1[8],zero,xmm1[9],zero,xmm1[10],zero,xmm1[11],zero,xmm1[12],zero,xmm1[13],zero,xmm1[14],zero,xmm1[15],zero
  6053a3: 4e 8d 04 51                  	leaq	(%rcx,%r10,2), %r8
  6053a7: c4 c1 f9 6e 10               	vmovq	(%r8), %xmm2
  6053ac: 4c 8b 04 31                  	movq	(%rcx,%rsi), %r8
  6053b0: c4 c3 e9 22 d0 01            	vpinsrq	$0x1, %r8, %xmm2, %xmm2
  6053b6: c4 e2 7d 30 d2               	vpmovzxbw	%xmm2, %ymm2    # ymm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero,xmm2[8],zero,xmm2[9],zero,xmm2[10],zero,xmm2[11],zero,xmm2[12],zero,xmm2[13],zero,xmm2[14],zero,xmm2[15],zero
  6053bb: c5 f5 f9 ca                  	vpsubw	%ymm2, %ymm1, %ymm1
  6053bf: c5 f5 f5 c9                  	vpmaddwd	%ymm1, %ymm1, %ymm1
  6053c3: c5 fd fe c1                  	vpaddd	%ymm1, %ymm0, %ymm0
  6053c7: 48 83 c7 fc                  	addq	$-0x4, %rdi
  6053cb: 75 82                        	jne	0x60534f <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xef>
  6053cd: c4 e3 7d 39 c1 00            	vextracti128	$0x0, %ymm0, %xmm1
  6053d3: c4 e3 7d 39 c0 01            	vextracti128	$0x1, %ymm0, %xmm0
  6053d9: c5 f9 fe c1                  	vpaddd	%xmm1, %xmm0, %xmm0
  6053dd: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     # xmm1 = xmm0[2,3,0,1]
  6053e2: c5 f1 fe c0                  	vpaddd	%xmm0, %xmm1, %xmm0
  6053e6: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     # xmm1 = xmm0[1,0,3,2]
  6053eb: c5 f1 fe c0                  	vpaddd	%xmm0, %xmm1, %xmm0
  6053ef: c4 e3 79 16 c0 00            	vpextrd	$0x0, %xmm0, %eax
  6053f5: c5 f8 77                     	vzeroupper
  6053f8: 48 83 c4 48                  	addq	$0x48, %rsp
  6053fc: 5d                           	popq	%rbp
  6053fd: c3                           	retq
  6053fe: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
  605403: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
  605408: 48 89 4c 24 18               	movq	%rcx, 0x18(%rsp)
  60540d: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
  605412: e8 a9 94 e8 ff               	callq	0x48e8c0 <runtime.morestack_noctxt.abi0>
  605417: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
  60541c: 48 8b 5c 24 10               	movq	0x10(%rsp), %rbx
  605421: 48 8b 4c 24 18               	movq	0x18(%rsp), %rcx
  605426: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
  60542b: e9 30 fe ff ff               	jmp	0x605260 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr>
  605430: cc                           	int3
  605431: cc                           	int3
  605432: cc                           	int3
  605433: cc                           	int3
  605434: cc                           	int3
  605435: cc                           	int3
  605436: cc                           	int3
  605437: cc                           	int3
  605438: cc                           	int3
  605439: cc                           	int3
  60543a: cc                           	int3
  60543b: cc                           	int3
  60543c: cc                           	int3
  60543d: cc                           	int3
  60543e: cc                           	int3
  60543f: cc                           	int3

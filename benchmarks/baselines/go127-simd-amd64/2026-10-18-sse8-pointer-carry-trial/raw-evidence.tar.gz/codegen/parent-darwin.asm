
/private/tmp/govpx-fp16-offset-guard/evidence/validation/parent-pixel-ordinary.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

000000000115a520 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr>:
 115a520: 49 3b 66 10                  	cmpq	0x10(%r14), %rsp
 115a524: 0f 86 ba 01 00 00            	jbe	0x115a6e4 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x1c4>
 115a52a: 55                           	pushq	%rbp
 115a52b: 48 89 e5                     	movq	%rsp, %rbp
 115a52e: 48 83 ec 48                  	subq	$0x48, %rsp
 115a532: 80 3d 34 01 25 00 00         	cmpb	$0x0, 0x250134(%rip)    ## 0x13aa66d <_github.com/thesyncim/govpx/internal/pixel.Enabled>
 115a539: 74 4c                        	je	0x115a587 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x67>
 115a53b: 80 3d a2 0c 25 00 00         	cmpb	$0x0, 0x250ca2(%rip)    ## 0x13ab1e4 <_internal/cpu.X86+0x44>
 115a542: 74 3e                        	je	0x115a582 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x62>
 115a544: 48 85 c0                     	testq	%rax, %rax
 115a547: 74 32                        	je	0x115a57b <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x5b>
 115a549: 48 85 c9                     	testq	%rcx, %rcx
 115a54c: 74 28                        	je	0x115a576 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x56>
 115a54e: 49 89 fa                     	movq	%rdi, %r10
 115a551: 48 09 df                     	orq	%rbx, %rdi
 115a554: 48 c1 ef 1e                  	shrq	$0x1e, %rdi
 115a558: 48 85 ff                     	testq	%rdi, %rdi
 115a55b: 75 2d                        	jne	0x115a58a <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x6a>
 115a55d: c5 fd ef c0                  	vpxor	%ymm0, %ymm0, %ymm0
 115a561: 48 8d 14 5b                  	leaq	(%rbx,%rbx,2), %rdx
 115a565: 4b 8d 34 52                  	leaq	(%r10,%r10,2), %rsi
 115a569: 31 ff                        	xorl	%edi, %edi
 115a56b: 45 31 c0                     	xorl	%r8d, %r8d
 115a56e: 45 31 c9                     	xorl	%r9d, %r9d
 115a571: e9 33 01 00 00               	jmp	0x115a6a9 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x189>
 115a576: 49 89 fa                     	movq	%rdi, %r10
 115a579: eb 0f                        	jmp	0x115a58a <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x6a>
 115a57b: 49 89 fa                     	movq	%rdi, %r10
 115a57e: 66 90                        	nop
 115a580: eb 08                        	jmp	0x115a58a <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x6a>
 115a582: 49 89 fa                     	movq	%rdi, %r10
 115a585: eb 03                        	jmp	0x115a58a <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x6a>
 115a587: 49 89 fa                     	movq	%rdi, %r10
 115a58a: 48 8d 14 5b                  	leaq	(%rbx,%rbx,2), %rdx
 115a58e: 48 8d 14 53                  	leaq	(%rbx,%rdx,2), %rdx
 115a592: 48 8d 52 08                  	leaq	0x8(%rdx), %rdx
 115a596: 48 85 d2                     	testq	%rdx, %rdx
 115a599: 7c 6f                        	jl	0x115a60a <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xea>
 115a59b: 49 89 c4                     	movq	%rax, %r12
 115a59e: 49 f7 dc                     	negq	%r12
 115a5a1: 4c 39 e2                     	cmpq	%r12, %rdx
 115a5a4: 77 50                        	ja	0x115a5f6 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xd6>
 115a5a6: 4f 8d 24 52                  	leaq	(%r10,%r10,2), %r12
 115a5aa: 4f 8d 0c 62                  	leaq	(%r10,%r12,2), %r9
 115a5ae: 4d 8d 49 08                  	leaq	0x8(%r9), %r9
 115a5b2: 4d 85 c9                     	testq	%r9, %r9
 115a5b5: 7c 3a                        	jl	0x115a5f1 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xd1>
 115a5b7: 48 89 ce                     	movq	%rcx, %rsi
 115a5ba: 48 f7 d9                     	negq	%rcx
 115a5bd: 0f 1f 00                     	nopl	(%rax)
 115a5c0: 49 39 c9                     	cmpq	%rcx, %r9
 115a5c3: 77 1d                        	ja	0x115a5e2 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xc2>
 115a5c5: 48 89 d1                     	movq	%rdx, %rcx
 115a5c8: 48 89 df                     	movq	%rbx, %rdi
 115a5cb: 4d 89 c8                     	movq	%r9, %r8
 115a5ce: 41 bb 08 00 00 00            	movl	$0x8, %r11d
 115a5d4: 48 89 cb                     	movq	%rcx, %rbx
 115a5d7: e8 44 01 00 00               	callq	0x115a720 <_github.com/thesyncim/govpx/internal/pixel.SSE8>
 115a5dc: 48 83 c4 48                  	addq	$0x48, %rsp
 115a5e0: 5d                           	popq	%rbp
 115a5e1: c3                           	retq
 115a5e2: 48 85 f6                     	testq	%rsi, %rsi
 115a5e5: 74 05                        	je	0x115a5ec <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xcc>
 115a5e7: e8 b4 df f1 ff               	callq	0x10785a0 <_runtime.panicunsafeslicelen>
 115a5ec: e8 4f e0 f1 ff               	callq	0x1078640 <_runtime.panicunsafeslicenilptr>
 115a5f1: e8 aa df f1 ff               	callq	0x10785a0 <_runtime.panicunsafeslicelen>
 115a5f6: 48 85 c0                     	testq	%rax, %rax
 115a5f9: 74 0a                        	je	0x115a605 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xe5>
 115a5fb: 0f 1f 44 00 00               	nopl	(%rax,%rax)
 115a600: e8 9b df f1 ff               	callq	0x10785a0 <_runtime.panicunsafeslicelen>
 115a605: e8 36 e0 f1 ff               	callq	0x1078640 <_runtime.panicunsafeslicenilptr>
 115a60a: e8 91 df f1 ff               	callq	0x10785a0 <_runtime.panicunsafeslicelen>
 115a60f: 4e 8d 1c 00                  	leaq	(%rax,%r8), %r11
 115a613: c4 c1 f9 6e 0b               	vmovq	(%r11), %xmm1
 115a618: 4e 8d 1c 03                  	leaq	(%rbx,%r8), %r11
 115a61c: 4d 8b 1c 03                  	movq	(%r11,%rax), %r11
 115a620: c4 c3 f1 22 cb 01            	vpinsrq	$0x1, %r11, %xmm1, %xmm1
 115a626: c4 e2 7d 30 c9               	vpmovzxbw	%xmm1, %ymm1    ## ymm1 = xmm1[0],zero,xmm1[1],zero,xmm1[2],zero,xmm1[3],zero,xmm1[4],zero,xmm1[5],zero,xmm1[6],zero,xmm1[7],zero,xmm1[8],zero,xmm1[9],zero,xmm1[10],zero,xmm1[11],zero,xmm1[12],zero,xmm1[13],zero,xmm1[14],zero,xmm1[15],zero
 115a62b: 4e 8d 1c 09                  	leaq	(%rcx,%r9), %r11
 115a62f: c4 c1 f9 6e 13               	vmovq	(%r11), %xmm2
 115a634: 4f 8d 1c 0a                  	leaq	(%r10,%r9), %r11
 115a638: 4d 8b 1c 0b                  	movq	(%r11,%rcx), %r11
 115a63c: c4 c3 e9 22 d3 01            	vpinsrq	$0x1, %r11, %xmm2, %xmm2
 115a642: c4 e2 7d 30 d2               	vpmovzxbw	%xmm2, %ymm2    ## ymm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero,xmm2[8],zero,xmm2[9],zero,xmm2[10],zero,xmm2[11],zero,xmm2[12],zero,xmm2[13],zero,xmm2[14],zero,xmm2[15],zero
 115a647: c5 f5 f9 ca                  	vpsubw	%ymm2, %ymm1, %ymm1
 115a64b: c5 f5 f5 c9                  	vpmaddwd	%ymm1, %ymm1, %ymm1
 115a64f: c5 fd fe c9                  	vpaddd	%ymm1, %ymm0, %ymm1
 115a653: 4d 8d 1c 58                  	leaq	(%r8,%rbx,2), %r11
 115a657: 49 01 c3                     	addq	%rax, %r11
 115a65a: c4 c1 f9 6e 13               	vmovq	(%r11), %xmm2
 115a65f: 4d 8d 1c 10                  	leaq	(%r8,%rdx), %r11
 115a663: 4e 8b 1c 18                  	movq	(%rax,%r11), %r11
 115a667: c4 c3 e9 22 d3 01            	vpinsrq	$0x1, %r11, %xmm2, %xmm2
 115a66d: c4 e2 7d 30 d2               	vpmovzxbw	%xmm2, %ymm2    ## ymm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero,xmm2[8],zero,xmm2[9],zero,xmm2[10],zero,xmm2[11],zero,xmm2[12],zero,xmm2[13],zero,xmm2[14],zero,xmm2[15],zero
 115a672: 4f 8d 1c 51                  	leaq	(%r9,%r10,2), %r11
 115a676: 49 01 cb                     	addq	%rcx, %r11
 115a679: c4 c1 f9 6e 1b               	vmovq	(%r11), %xmm3
 115a67e: 4d 8d 1c 31                  	leaq	(%r9,%rsi), %r11
 115a682: 4e 8b 1c 19                  	movq	(%rcx,%r11), %r11
 115a686: c4 c3 e1 22 db 01            	vpinsrq	$0x1, %r11, %xmm3, %xmm3
 115a68c: c4 e2 7d 30 db               	vpmovzxbw	%xmm3, %ymm3    ## ymm3 = xmm3[0],zero,xmm3[1],zero,xmm3[2],zero,xmm3[3],zero,xmm3[4],zero,xmm3[5],zero,xmm3[6],zero,xmm3[7],zero,xmm3[8],zero,xmm3[9],zero,xmm3[10],zero,xmm3[11],zero,xmm3[12],zero,xmm3[13],zero,xmm3[14],zero,xmm3[15],zero
 115a691: c5 ed f9 d3                  	vpsubw	%ymm3, %ymm2, %ymm2
 115a695: c5 ed f5 d2                  	vpmaddwd	%ymm2, %ymm2, %ymm2
 115a699: c5 f5 fe c2                  	vpaddd	%ymm2, %ymm1, %ymm0
 115a69d: 4d 8d 04 98                  	leaq	(%r8,%rbx,4), %r8
 115a6a1: 4f 8d 0c 91                  	leaq	(%r9,%r10,4), %r9
 115a6a5: 48 83 c7 04                  	addq	$0x4, %rdi
 115a6a9: 48 83 ff 08                  	cmpq	$0x8, %rdi
 115a6ad: 0f 8c 5c ff ff ff            	jl	0x115a60f <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xef>
 115a6b3: c4 e3 7d 39 c1 00            	vextracti128	$0x0, %ymm0, %xmm1
 115a6b9: c4 e3 7d 39 c0 01            	vextracti128	$0x1, %ymm0, %xmm0
 115a6bf: c5 f9 fe c1                  	vpaddd	%xmm1, %xmm0, %xmm0
 115a6c3: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     ## xmm1 = xmm0[2,3,0,1]
 115a6c8: c5 f1 fe c0                  	vpaddd	%xmm0, %xmm1, %xmm0
 115a6cc: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     ## xmm1 = xmm0[1,0,3,2]
 115a6d1: c5 f1 fe c0                  	vpaddd	%xmm0, %xmm1, %xmm0
 115a6d5: c4 e3 79 16 c0 00            	vpextrd	$0x0, %xmm0, %eax
 115a6db: c5 f8 77                     	vzeroupper
 115a6de: 48 83 c4 48                  	addq	$0x48, %rsp
 115a6e2: 5d                           	popq	%rbp
 115a6e3: c3                           	retq
 115a6e4: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
 115a6e9: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
 115a6ee: 48 89 4c 24 18               	movq	%rcx, 0x18(%rsp)
 115a6f3: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
 115a6f8: e8 c3 d3 f2 ff               	callq	0x1087ac0 <_runtime.morestack_noctxt.abi0>
 115a6fd: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
 115a702: 48 8b 5c 24 10               	movq	0x10(%rsp), %rbx
 115a707: 48 8b 4c 24 18               	movq	0x18(%rsp), %rcx
 115a70c: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
 115a711: e9 0a fe ff ff               	jmp	0x115a520 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr>
 115a716: cc                           	int3
 115a717: cc                           	int3
 115a718: cc                           	int3
 115a719: cc                           	int3
 115a71a: cc                           	int3
 115a71b: cc                           	int3
 115a71c: cc                           	int3
 115a71d: cc                           	int3
 115a71e: cc                           	int3
 115a71f: cc                           	int3

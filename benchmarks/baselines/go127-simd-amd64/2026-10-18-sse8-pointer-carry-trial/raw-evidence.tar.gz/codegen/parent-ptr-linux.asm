
/private/tmp/govpx-sse8-pointer-carry-review/validation/parent-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000605260 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr>:
  605260: 49 3b 66 10                  	cmpq	0x10(%r14), %rsp
  605264: 0f 86 ba 01 00 00            	jbe	0x605424 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x1c4>
  60526a: 55                           	pushq	%rbp
  60526b: 48 89 e5                     	movq	%rsp, %rbp
  60526e: 48 83 ec 48                  	subq	$0x48, %rsp
  605272: 80 3d 7e ca 32 00 00         	cmpb	$0x0, 0x32ca7e(%rip)    # 0x931cf7 <github.com/thesyncim/govpx/internal/pixel.Enabled>
  605279: 74 4c                        	je	0x6052c7 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x67>
  60527b: 80 3d a2 d6 32 00 00         	cmpb	$0x0, 0x32d6a2(%rip)    # 0x932924 <internal/cpu.X86+0x44>
  605282: 74 3e                        	je	0x6052c2 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x62>
  605284: 48 85 c0                     	testq	%rax, %rax
  605287: 74 32                        	je	0x6052bb <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x5b>
  605289: 48 85 c9                     	testq	%rcx, %rcx
  60528c: 74 28                        	je	0x6052b6 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x56>
  60528e: 49 89 fa                     	movq	%rdi, %r10
  605291: 48 09 df                     	orq	%rbx, %rdi
  605294: 48 c1 ef 1e                  	shrq	$0x1e, %rdi
  605298: 48 85 ff                     	testq	%rdi, %rdi
  60529b: 75 2d                        	jne	0x6052ca <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x6a>
  60529d: c5 fd ef c0                  	vpxor	%ymm0, %ymm0, %ymm0
  6052a1: 48 8d 14 5b                  	leaq	(%rbx,%rbx,2), %rdx
  6052a5: 4b 8d 34 52                  	leaq	(%r10,%r10,2), %rsi
  6052a9: 31 ff                        	xorl	%edi, %edi
  6052ab: 45 31 c0                     	xorl	%r8d, %r8d
  6052ae: 45 31 c9                     	xorl	%r9d, %r9d
  6052b1: e9 33 01 00 00               	jmp	0x6053e9 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x189>
  6052b6: 49 89 fa                     	movq	%rdi, %r10
  6052b9: eb 0f                        	jmp	0x6052ca <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x6a>
  6052bb: 49 89 fa                     	movq	%rdi, %r10
  6052be: 66 90                        	nop
  6052c0: eb 08                        	jmp	0x6052ca <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x6a>
  6052c2: 49 89 fa                     	movq	%rdi, %r10
  6052c5: eb 03                        	jmp	0x6052ca <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x6a>
  6052c7: 49 89 fa                     	movq	%rdi, %r10
  6052ca: 48 8d 14 5b                  	leaq	(%rbx,%rbx,2), %rdx
  6052ce: 48 8d 14 53                  	leaq	(%rbx,%rdx,2), %rdx
  6052d2: 48 8d 52 08                  	leaq	0x8(%rdx), %rdx
  6052d6: 48 85 d2                     	testq	%rdx, %rdx
  6052d9: 7c 6f                        	jl	0x60534a <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xea>
  6052db: 49 89 c4                     	movq	%rax, %r12
  6052de: 49 f7 dc                     	negq	%r12
  6052e1: 4c 39 e2                     	cmpq	%r12, %rdx
  6052e4: 77 50                        	ja	0x605336 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xd6>
  6052e6: 4f 8d 24 52                  	leaq	(%r10,%r10,2), %r12
  6052ea: 4f 8d 0c 62                  	leaq	(%r10,%r12,2), %r9
  6052ee: 4d 8d 49 08                  	leaq	0x8(%r9), %r9
  6052f2: 4d 85 c9                     	testq	%r9, %r9
  6052f5: 7c 3a                        	jl	0x605331 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xd1>
  6052f7: 48 89 ce                     	movq	%rcx, %rsi
  6052fa: 48 f7 d9                     	negq	%rcx
  6052fd: 0f 1f 00                     	nopl	(%rax)
  605300: 49 39 c9                     	cmpq	%rcx, %r9
  605303: 77 1d                        	ja	0x605322 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xc2>
  605305: 48 89 d1                     	movq	%rdx, %rcx
  605308: 48 89 df                     	movq	%rbx, %rdi
  60530b: 4d 89 c8                     	movq	%r9, %r8
  60530e: 41 bb 08 00 00 00            	movl	$0x8, %r11d
  605314: 48 89 cb                     	movq	%rcx, %rbx
  605317: e8 44 01 00 00               	callq	0x605460 <github.com/thesyncim/govpx/internal/pixel.SSE8>
  60531c: 48 83 c4 48                  	addq	$0x48, %rsp
  605320: 5d                           	popq	%rbp
  605321: c3                           	retq
  605322: 48 85 f6                     	testq	%rsi, %rsi
  605325: 74 05                        	je	0x60532c <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xcc>
  605327: e8 14 8e e7 ff               	callq	0x47e140 <runtime.panicunsafeslicelen>
  60532c: e8 af 8e e7 ff               	callq	0x47e1e0 <runtime.panicunsafeslicenilptr>
  605331: e8 0a 8e e7 ff               	callq	0x47e140 <runtime.panicunsafeslicelen>
  605336: 48 85 c0                     	testq	%rax, %rax
  605339: 74 0a                        	je	0x605345 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xe5>
  60533b: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  605340: e8 fb 8d e7 ff               	callq	0x47e140 <runtime.panicunsafeslicelen>
  605345: e8 96 8e e7 ff               	callq	0x47e1e0 <runtime.panicunsafeslicenilptr>
  60534a: e8 f1 8d e7 ff               	callq	0x47e140 <runtime.panicunsafeslicelen>
  60534f: 4e 8d 1c 00                  	leaq	(%rax,%r8), %r11
  605353: c4 c1 f9 6e 0b               	vmovq	(%r11), %xmm1
  605358: 4e 8d 1c 03                  	leaq	(%rbx,%r8), %r11
  60535c: 4d 8b 1c 03                  	movq	(%r11,%rax), %r11
  605360: c4 c3 f1 22 cb 01            	vpinsrq	$0x1, %r11, %xmm1, %xmm1
  605366: c4 e2 7d 30 c9               	vpmovzxbw	%xmm1, %ymm1    # ymm1 = xmm1[0],zero,xmm1[1],zero,xmm1[2],zero,xmm1[3],zero,xmm1[4],zero,xmm1[5],zero,xmm1[6],zero,xmm1[7],zero,xmm1[8],zero,xmm1[9],zero,xmm1[10],zero,xmm1[11],zero,xmm1[12],zero,xmm1[13],zero,xmm1[14],zero,xmm1[15],zero
  60536b: 4e 8d 1c 09                  	leaq	(%rcx,%r9), %r11
  60536f: c4 c1 f9 6e 13               	vmovq	(%r11), %xmm2
  605374: 4f 8d 1c 0a                  	leaq	(%r10,%r9), %r11
  605378: 4d 8b 1c 0b                  	movq	(%r11,%rcx), %r11
  60537c: c4 c3 e9 22 d3 01            	vpinsrq	$0x1, %r11, %xmm2, %xmm2
  605382: c4 e2 7d 30 d2               	vpmovzxbw	%xmm2, %ymm2    # ymm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero,xmm2[8],zero,xmm2[9],zero,xmm2[10],zero,xmm2[11],zero,xmm2[12],zero,xmm2[13],zero,xmm2[14],zero,xmm2[15],zero
  605387: c5 f5 f9 ca                  	vpsubw	%ymm2, %ymm1, %ymm1
  60538b: c5 f5 f5 c9                  	vpmaddwd	%ymm1, %ymm1, %ymm1
  60538f: c5 fd fe c9                  	vpaddd	%ymm1, %ymm0, %ymm1
  605393: 4d 8d 1c 58                  	leaq	(%r8,%rbx,2), %r11
  605397: 49 01 c3                     	addq	%rax, %r11
  60539a: c4 c1 f9 6e 13               	vmovq	(%r11), %xmm2
  60539f: 4d 8d 1c 10                  	leaq	(%r8,%rdx), %r11
  6053a3: 4e 8b 1c 18                  	movq	(%rax,%r11), %r11
  6053a7: c4 c3 e9 22 d3 01            	vpinsrq	$0x1, %r11, %xmm2, %xmm2
  6053ad: c4 e2 7d 30 d2               	vpmovzxbw	%xmm2, %ymm2    # ymm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero,xmm2[8],zero,xmm2[9],zero,xmm2[10],zero,xmm2[11],zero,xmm2[12],zero,xmm2[13],zero,xmm2[14],zero,xmm2[15],zero
  6053b2: 4f 8d 1c 51                  	leaq	(%r9,%r10,2), %r11
  6053b6: 49 01 cb                     	addq	%rcx, %r11
  6053b9: c4 c1 f9 6e 1b               	vmovq	(%r11), %xmm3
  6053be: 4d 8d 1c 31                  	leaq	(%r9,%rsi), %r11
  6053c2: 4e 8b 1c 19                  	movq	(%rcx,%r11), %r11
  6053c6: c4 c3 e1 22 db 01            	vpinsrq	$0x1, %r11, %xmm3, %xmm3
  6053cc: c4 e2 7d 30 db               	vpmovzxbw	%xmm3, %ymm3    # ymm3 = xmm3[0],zero,xmm3[1],zero,xmm3[2],zero,xmm3[3],zero,xmm3[4],zero,xmm3[5],zero,xmm3[6],zero,xmm3[7],zero,xmm3[8],zero,xmm3[9],zero,xmm3[10],zero,xmm3[11],zero,xmm3[12],zero,xmm3[13],zero,xmm3[14],zero,xmm3[15],zero
  6053d1: c5 ed f9 d3                  	vpsubw	%ymm3, %ymm2, %ymm2
  6053d5: c5 ed f5 d2                  	vpmaddwd	%ymm2, %ymm2, %ymm2
  6053d9: c5 f5 fe c2                  	vpaddd	%ymm2, %ymm1, %ymm0
  6053dd: 4d 8d 04 98                  	leaq	(%r8,%rbx,4), %r8
  6053e1: 4f 8d 0c 91                  	leaq	(%r9,%r10,4), %r9
  6053e5: 48 83 c7 04                  	addq	$0x4, %rdi
  6053e9: 48 83 ff 08                  	cmpq	$0x8, %rdi
  6053ed: 0f 8c 5c ff ff ff            	jl	0x60534f <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xef>
  6053f3: c4 e3 7d 39 c1 00            	vextracti128	$0x0, %ymm0, %xmm1
  6053f9: c4 e3 7d 39 c0 01            	vextracti128	$0x1, %ymm0, %xmm0
  6053ff: c5 f9 fe c1                  	vpaddd	%xmm1, %xmm0, %xmm0
  605403: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     # xmm1 = xmm0[2,3,0,1]
  605408: c5 f1 fe c0                  	vpaddd	%xmm0, %xmm1, %xmm0
  60540c: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     # xmm1 = xmm0[1,0,3,2]
  605411: c5 f1 fe c0                  	vpaddd	%xmm0, %xmm1, %xmm0
  605415: c4 e3 79 16 c0 00            	vpextrd	$0x0, %xmm0, %eax
  60541b: c5 f8 77                     	vzeroupper
  60541e: 48 83 c4 48                  	addq	$0x48, %rsp
  605422: 5d                           	popq	%rbp
  605423: c3                           	retq
  605424: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
  605429: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
  60542e: 48 89 4c 24 18               	movq	%rcx, 0x18(%rsp)
  605433: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
  605438: e8 83 94 e8 ff               	callq	0x48e8c0 <runtime.morestack_noctxt.abi0>
  60543d: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
  605442: 48 8b 5c 24 10               	movq	0x10(%rsp), %rbx
  605447: 48 8b 4c 24 18               	movq	0x18(%rsp), %rcx
  60544c: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
  605451: e9 0a fe ff ff               	jmp	0x605260 <github.com/thesyncim/govpx/internal/pixel.SSE8Ptr>
  605456: cc                           	int3
  605457: cc                           	int3
  605458: cc                           	int3
  605459: cc                           	int3
  60545a: cc                           	int3
  60545b: cc                           	int3
  60545c: cc                           	int3
  60545d: cc                           	int3
  60545e: cc                           	int3
  60545f: cc                           	int3

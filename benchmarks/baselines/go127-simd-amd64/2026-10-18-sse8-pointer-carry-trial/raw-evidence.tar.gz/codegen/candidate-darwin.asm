
/private/tmp/govpx-sse8-pointer-carry-review/validation/pixel-ordinary.test:	file format mach-o 64-bit x86-64

Disassembly of section __TEXT,__text:

000000000115a520 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr>:
 115a520: 49 3b 66 10                  	cmpq	0x10(%r14), %rsp
 115a524: 0f 86 94 01 00 00            	jbe	0x115a6be <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x19e>
 115a52a: 55                           	pushq	%rbp
 115a52b: 48 89 e5                     	movq	%rsp, %rbp
 115a52e: 48 83 ec 48                  	subq	$0x48, %rsp
 115a532: 80 3d 14 d1 24 00 00         	cmpb	$0x0, 0x24d114(%rip)    ## 0x13a764d <_github.com/thesyncim/govpx/internal/pixel.Enabled>
 115a539: 74 47                        	je	0x115a582 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x62>
 115a53b: 80 3d 82 dc 24 00 00         	cmpb	$0x0, 0x24dc82(%rip)    ## 0x13a81c4 <_internal/cpu.X86+0x44>
 115a542: 74 39                        	je	0x115a57d <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x5d>
 115a544: 48 85 c0                     	testq	%rax, %rax
 115a547: 74 2f                        	je	0x115a578 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x58>
 115a549: 48 85 c9                     	testq	%rcx, %rcx
 115a54c: 74 25                        	je	0x115a573 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x53>
 115a54e: 49 89 fa                     	movq	%rdi, %r10
 115a551: 48 09 df                     	orq	%rbx, %rdi
 115a554: 48 c1 ef 1e                  	shrq	$0x1e, %rdi
 115a558: 48 85 ff                     	testq	%rdi, %rdi
 115a55b: 75 28                        	jne	0x115a585 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x65>
 115a55d: c5 fd ef c0                  	vpxor	%ymm0, %ymm0, %ymm0
 115a561: 48 8d 14 5b                  	leaq	(%rbx,%rbx,2), %rdx
 115a565: 4b 8d 34 52                  	leaq	(%r10,%r10,2), %rsi
 115a569: bf 08 00 00 00               	movl	$0x8, %edi
 115a56e: e9 a4 00 00 00               	jmp	0x115a617 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xf7>
 115a573: 49 89 fa                     	movq	%rdi, %r10
 115a576: eb 0d                        	jmp	0x115a585 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x65>
 115a578: 49 89 fa                     	movq	%rdi, %r10
 115a57b: eb 08                        	jmp	0x115a585 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x65>
 115a57d: 49 89 fa                     	movq	%rdi, %r10
 115a580: eb 03                        	jmp	0x115a585 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0x65>
 115a582: 49 89 fa                     	movq	%rdi, %r10
 115a585: 48 8d 14 5b                  	leaq	(%rbx,%rbx,2), %rdx
 115a589: 48 8d 14 53                  	leaq	(%rbx,%rdx,2), %rdx
 115a58d: 48 8d 52 08                  	leaq	0x8(%rdx), %rdx
 115a591: 48 85 d2                     	testq	%rdx, %rdx
 115a594: 7c 74                        	jl	0x115a60a <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xea>
 115a596: 49 89 c4                     	movq	%rax, %r12
 115a599: 49 f7 dc                     	negq	%r12
 115a59c: 0f 1f 40 00                  	nopl	(%rax)
 115a5a0: 4c 39 e2                     	cmpq	%r12, %rdx
 115a5a3: 77 51                        	ja	0x115a5f6 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xd6>
 115a5a5: 4f 8d 24 52                  	leaq	(%r10,%r10,2), %r12
 115a5a9: 4f 8d 0c 62                  	leaq	(%r10,%r12,2), %r9
 115a5ad: 4d 8d 49 08                  	leaq	0x8(%r9), %r9
 115a5b1: 4d 85 c9                     	testq	%r9, %r9
 115a5b4: 7c 3b                        	jl	0x115a5f1 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xd1>
 115a5b6: 48 89 ce                     	movq	%rcx, %rsi
 115a5b9: 48 f7 d9                     	negq	%rcx
 115a5bc: 0f 1f 40 00                  	nopl	(%rax)
 115a5c0: 49 39 c9                     	cmpq	%rcx, %r9
 115a5c3: 77 1d                        	ja	0x115a5e2 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xc2>
 115a5c5: 48 89 d1                     	movq	%rdx, %rcx
 115a5c8: 48 89 df                     	movq	%rbx, %rdi
 115a5cb: 4d 89 c8                     	movq	%r9, %r8
 115a5ce: 41 bb 08 00 00 00            	movl	$0x8, %r11d
 115a5d4: 48 89 cb                     	movq	%rcx, %rbx
 115a5d7: e8 24 01 00 00               	callq	0x115a700 <_github.com/thesyncim/govpx/internal/pixel.SSE8>
 115a5dc: 48 83 c4 48                  	addq	$0x48, %rsp
 115a5e0: 5d                           	popq	%rbp
 115a5e1: c3                           	retq
 115a5e2: 48 85 f6                     	testq	%rsi, %rsi
 115a5e5: 74 05                        	je	0x115a5ec <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xcc>
 115a5e7: e8 b4 df f1 ff               	callq	0x10785a0 <_runtime.panicunsafeslicelen>
 115a5ec: e8 4f e0 f1 ff               	callq	0x1078640 <_runtime.panicunsafeslicenilptr>
 115a5f1: e8 aa df f1 ff               	callq	0x10785a0 <_runtime.panicunsafeslicelen>
 115a5f6: 48 85 c0                     	testq	%rax, %rax
 115a5f9: 74 0a                        	je	0x115a605 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xe5>
 115a5fb: 0f 1f 44 00 00               	nopl	(%rax,%rax)
 115a600: e8 9b df f1 ff               	callq	0x10785a0 <_runtime.panicunsafeslicelen>
 115a605: e8 36 e0 f1 ff               	callq	0x1078640 <_runtime.panicunsafeslicenilptr>
 115a60a: e8 91 df f1 ff               	callq	0x10785a0 <_runtime.panicunsafeslicelen>
 115a60f: 48 8d 04 98                  	leaq	(%rax,%rbx,4), %rax
 115a613: 4a 8d 0c 91                  	leaq	(%rcx,%r10,4), %rcx
 115a617: c4 e1 f9 6e 08               	vmovq	(%rax), %xmm1
 115a61c: 4c 8b 04 18                  	movq	(%rax,%rbx), %r8
 115a620: c4 c3 f1 22 c8 01            	vpinsrq	$0x1, %r8, %xmm1, %xmm1
 115a626: c4 e2 7d 30 c9               	vpmovzxbw	%xmm1, %ymm1    ## ymm1 = xmm1[0],zero,xmm1[1],zero,xmm1[2],zero,xmm1[3],zero,xmm1[4],zero,xmm1[5],zero,xmm1[6],zero,xmm1[7],zero,xmm1[8],zero,xmm1[9],zero,xmm1[10],zero,xmm1[11],zero,xmm1[12],zero,xmm1[13],zero,xmm1[14],zero,xmm1[15],zero
 115a62b: c4 e1 f9 6e 11               	vmovq	(%rcx), %xmm2
 115a630: 4e 8b 04 11                  	movq	(%rcx,%r10), %r8
 115a634: c4 c3 e9 22 d0 01            	vpinsrq	$0x1, %r8, %xmm2, %xmm2
 115a63a: c4 e2 7d 30 d2               	vpmovzxbw	%xmm2, %ymm2    ## ymm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero,xmm2[8],zero,xmm2[9],zero,xmm2[10],zero,xmm2[11],zero,xmm2[12],zero,xmm2[13],zero,xmm2[14],zero,xmm2[15],zero
 115a63f: c5 f5 f9 ca                  	vpsubw	%ymm2, %ymm1, %ymm1
 115a643: c5 f5 f5 c9                  	vpmaddwd	%ymm1, %ymm1, %ymm1
 115a647: c5 fd fe c1                  	vpaddd	%ymm1, %ymm0, %ymm0
 115a64b: 4c 8d 04 58                  	leaq	(%rax,%rbx,2), %r8
 115a64f: c4 c1 f9 6e 08               	vmovq	(%r8), %xmm1
 115a654: 4c 8b 04 10                  	movq	(%rax,%rdx), %r8
 115a658: c4 c3 f1 22 c8 01            	vpinsrq	$0x1, %r8, %xmm1, %xmm1
 115a65e: c4 e2 7d 30 c9               	vpmovzxbw	%xmm1, %ymm1    ## ymm1 = xmm1[0],zero,xmm1[1],zero,xmm1[2],zero,xmm1[3],zero,xmm1[4],zero,xmm1[5],zero,xmm1[6],zero,xmm1[7],zero,xmm1[8],zero,xmm1[9],zero,xmm1[10],zero,xmm1[11],zero,xmm1[12],zero,xmm1[13],zero,xmm1[14],zero,xmm1[15],zero
 115a663: 4e 8d 04 51                  	leaq	(%rcx,%r10,2), %r8
 115a667: c4 c1 f9 6e 10               	vmovq	(%r8), %xmm2
 115a66c: 4c 8b 04 31                  	movq	(%rcx,%rsi), %r8
 115a670: c4 c3 e9 22 d0 01            	vpinsrq	$0x1, %r8, %xmm2, %xmm2
 115a676: c4 e2 7d 30 d2               	vpmovzxbw	%xmm2, %ymm2    ## ymm2 = xmm2[0],zero,xmm2[1],zero,xmm2[2],zero,xmm2[3],zero,xmm2[4],zero,xmm2[5],zero,xmm2[6],zero,xmm2[7],zero,xmm2[8],zero,xmm2[9],zero,xmm2[10],zero,xmm2[11],zero,xmm2[12],zero,xmm2[13],zero,xmm2[14],zero,xmm2[15],zero
 115a67b: c5 f5 f9 ca                  	vpsubw	%ymm2, %ymm1, %ymm1
 115a67f: c5 f5 f5 c9                  	vpmaddwd	%ymm1, %ymm1, %ymm1
 115a683: c5 fd fe c1                  	vpaddd	%ymm1, %ymm0, %ymm0
 115a687: 48 83 c7 fc                  	addq	$-0x4, %rdi
 115a68b: 75 82                        	jne	0x115a60f <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr+0xef>
 115a68d: c4 e3 7d 39 c1 00            	vextracti128	$0x0, %ymm0, %xmm1
 115a693: c4 e3 7d 39 c0 01            	vextracti128	$0x1, %ymm0, %xmm0
 115a699: c5 f9 fe c1                  	vpaddd	%xmm1, %xmm0, %xmm0
 115a69d: c5 f9 70 c8 4e               	vpshufd	$0x4e, %xmm0, %xmm1     ## xmm1 = xmm0[2,3,0,1]
 115a6a2: c5 f1 fe c0                  	vpaddd	%xmm0, %xmm1, %xmm0
 115a6a6: c5 f9 70 c8 b1               	vpshufd	$0xb1, %xmm0, %xmm1     ## xmm1 = xmm0[1,0,3,2]
 115a6ab: c5 f1 fe c0                  	vpaddd	%xmm0, %xmm1, %xmm0
 115a6af: c4 e3 79 16 c0 00            	vpextrd	$0x0, %xmm0, %eax
 115a6b5: c5 f8 77                     	vzeroupper
 115a6b8: 48 83 c4 48                  	addq	$0x48, %rsp
 115a6bc: 5d                           	popq	%rbp
 115a6bd: c3                           	retq
 115a6be: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
 115a6c3: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
 115a6c8: 48 89 4c 24 18               	movq	%rcx, 0x18(%rsp)
 115a6cd: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
 115a6d2: e8 e9 d3 f2 ff               	callq	0x1087ac0 <_runtime.morestack_noctxt.abi0>
 115a6d7: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
 115a6dc: 48 8b 5c 24 10               	movq	0x10(%rsp), %rbx
 115a6e1: 48 8b 4c 24 18               	movq	0x18(%rsp), %rcx
 115a6e6: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
 115a6eb: e9 30 fe ff ff               	jmp	0x115a520 <_github.com/thesyncim/govpx/internal/pixel.SSE8Ptr>
 115a6f0: cc                           	int3
 115a6f1: cc                           	int3
 115a6f2: cc                           	int3
 115a6f3: cc                           	int3
 115a6f4: cc                           	int3
 115a6f5: cc                           	int3
 115a6f6: cc                           	int3
 115a6f7: cc                           	int3
 115a6f8: cc                           	int3
 115a6f9: cc                           	int3
 115a6fa: cc                           	int3
 115a6fb: cc                           	int3
 115a6fc: cc                           	int3
 115a6fd: cc                           	int3
 115a6fe: cc                           	int3
 115a6ff: cc                           	int3

from pathlib import Path
import json,re,hashlib,statistics,subprocess
B=Path('/private/tmp');R=B/'govpx-pr51-manual39127005272-artifact';ROOT='/Users/thesyncim/GolandProjects/govpx';HEAD='bc4a12a2ea74f6219d26acb5646677016eb6423f';BASE='d08c4f72697dc256ea86fb5959339d2d6819e890'
sha=lambda b:hashlib.sha256(b).hexdigest()
commits=json.loads((R/'pixel-optional-commits.json').read_text());assert commits=={'head':HEAD,'base':BASE,'assembly_excluded':True}
fixtures={line.split('  ',1)[1]:line.split('  ',1)[0] for line in (R/'pixel-optional-fixture-sha256.txt').read_text().splitlines()};assert set(fixtures)=={'internal/pixel/fp32_optional_native_test.go','internal/pixel/stats_reduction_native_test.go'}
for n,h in fixtures.items():assert sha((R/'pixel-optional-fixtures'/Path(n).name).read_bytes())==sha(subprocess.check_output(['git','show',HEAD+':'+n],cwd=ROOT))==h
text=(R/'pixel-optional.txt').read_text();validation=(R/'pixel-optional-validation.txt').read_text();assert '# head '+HEAD in text and '# base '+BASE in text and '# driver checkout '+'bc4a12a2ea74f6219d26acb5646677016eb6423f' in text
features=re.findall(r'FP32PublicHost AVX512=(true|false) AVX2=(true|false) Enabled=(true|false)',text);assert len(features)>=1 and features[0][1:]==('true','true');active=features[0][0]=='true'
actual=re.findall(r'Enabled=(true|false) AVX2=(true|false) AVX512=(true|false)',validation);assert len(actual)==6,actual
assert actual==[('true','true',str(active).lower())]*2+[('true','true','false')]*2+[('false','false','false')]*2,actual
passnames=re.findall(r'^--- PASS: (\S+)',validation,re.M);skipnames=re.findall(r'^--- SKIP: (\S+)',validation,re.M);assert not re.search(r'^\s*--- FAIL:|^FAIL',validation,re.M)
mandatory=['TestFP32ActualFeature','TestFP32DispatchBoundaries','TestFP32WordClasses','TestFP32EligibleExactWindows','TestFP32EligibleAliasedDeclines','TestFP32EligiblePanicWindows','TestFP16AllSignedCoefficients']
for n in mandatory:assert passnames.count(n)==6,(n,passnames.count(n))
assert passnames.count('TestFP32NativeSelectedOracles')==(2 if active else 0) and skipnames.count('TestFP32NativeSelectedOracles')==(4 if active else 6)
if active:assert '# SELECTED_AVX512_AVAILABLE=1' in text and re.search(r'^--- PASS: TestFP32NativeSelectedOracles ',text,re.M)
else:assert '# SELECTED_AVX512_UNAVAILABLE' in text and 'FP32 fallback timings omitted; cannot accept AVX512 correctness/performance' in text
fp={f'BenchmarkFP32PublicOptionalNative/n{n}/qnil{q}/classes{cl}/{p}/{align}' for n in [64,256] for q in ['false','true'] for cl in ['false','true'] for p in ['zero','sparse','dense'] for align in ['aligned64','offset2-classes1']};stats={f'BenchmarkStatsReductionNative/w{w}/h{h}' for w in [8,32,64] for h in [1,7,8,64,4096,4097]};assert len(fp)==48 and len(stats)==18
phase=None;variant=None;roundno=None;one={v:{} for v in ['parent','current']};timed={v:{} for v in ['parent','current']};orders=[];rows_total=0
pattern=re.compile(r'^(Benchmark(?:FP32PublicOptionalNative|StatsReductionNative)/\S+)\s+(\d+)\s+(?:([\d.eE+\-]+) ns/op\s+)?(\d+) B/op\s+(\d+) allocs/op$')
for line in text.splitlines():
 m=re.fullmatch(r'# excluded preflight (parent|current): 48 FP32 API and 18 Stats cases',line)
 if m:phase='one';variant=m[1];continue
 m=re.fullmatch(r'# round (\d+) order (parent current|current parent)',line)
 if m:orders.append((int(m[1]),m[2].split()));continue
 m=re.fullmatch(r'# round (\d+) pixel (parent|current)',line)
 if m:phase='timed';roundno=int(m[1]);variant=m[2];continue
 m=pattern.fullmatch(line)
 if m:
  n,it,ns,b,a=m.groups();assert int(b)==int(a)==0 and phase and variant;rows_total+=1;row={'iterations':int(it),'ns':float(ns) if ns else None,'bytes':int(b),'allocs':int(a)}
  if phase=='one':assert int(it)==1 and n not in one[variant];one[variant][n]=row
  else:assert ns and float(ns)>0 and int(it)>1;row['round']=roundno;timed[variant].setdefault(n,[]).append(row)
assert orders==[(i,['parent','current'] if i%2 else ['current','parent']) for i in range(1,7)]
expected=fp|stats if active else stats
for v in ['parent','current']:
 assert set(one[v])==fp|stats and set(timed[v])==expected
 for n in expected:assert [x['round'] for x in timed[v][n]]==list(range(1,7))
count=792 if active else 216;assert rows_total==132+count;assert f'optional pixel inventory PASS:132 excluded one-shots; timed samples={count}; actual selected512={int(active)}; all0B/0alloc' in text
results={}
for n in sorted(expected):
 p=[r['ns'] for r in timed['parent'][n]];c=[r['ns'] for r in timed['current'][n]];mp=statistics.median(p);mc=statistics.median(c);rat=[a/b for a,b in zip(p,c)]
 results[n]={'samples':{v:timed[v][n] for v in timed},'parent_median_ns':mp,'current_median_ns':mc,'parent_over_current_median':mp/mc,'current_time_delta_percent':100*(mc/mp-1),'all6_paired_parent_over_current':rat,'faster_pairs':sum(x>1 for x in rat),'slower_pairs':sum(x<1 for x in rat),'all6_ge1_5':min(rat)>=1.5,'scope':('actual512 eligible public entry/guard-order component; qnil is not an encoder caller' if '/n256/' in n else 'n64 fallback entry/guard-order candidate') if n in fp else 'Stats odd8-tail candidate or unchanged geometry control'}
def group(vals):
 vals=list(vals);return {'cases':len(vals),'median_ratio_range':[min(v['parent_over_current_median'] for v in vals),max(v['parent_over_current_median'] for v in vals)] if vals else [],'minimum_pair_ratio':min((r for v in vals for r in v['all6_paired_parent_over_current']),default=None),'median_slower':sum(v['current_time_delta_percent']>0 for v in vals),'all6_slower':sum(v['slower_pairs']==6 for v in vals),'all6_faster':sum(v['faster_pairs']==6 for v in vals),'all6_ge1_5':sum(v['all6_ge1_5'] for v in vals)}
out={'head':HEAD,'base':BASE,'actual512':active,'feature_states_ordinary_race_512off_AVXoff':actual,'all_required_tests_PASS_counts':{n:passnames.count(n) for n in mandatory},'all_PASS':passnames,'all_SKIP':skipnames,'selected512_PASS':passnames.count('TestFP32NativeSelectedOracles'),'selected512_SKIP':skipnames.count('TestFP32NativeSelectedOracles'),'all65536_signed_coefficients_ordinary_race_and_off':True,'exact_windows_alias_panic_checks_all6PASS':True,'identical_overlay_fixtures_sha256':fixtures,'all132_excluded_one_shots':one,'timed_samples':count,'all_allocations_zero':True,'balanced_orders':orders,'all_results':results,'stats18':group(v for n,v in results.items() if n in stats),'FP48':group(v for n,v in results.items() if n in fp),'FP_n256_actual_selected24':group(v for n,v in results.items() if '/n256/' in n),'FP_n64_fallback24':group(v for n,v in results.items() if '/n64/' in n),'scope':'No old691 pixel baseline; no wholecodec attribution. Actual512 gains can be accepted only if active and required oracles pass. This phase is distinct from original720 SSE8 timing controls.'}
(B/'govpx-pr51-manual39127005272-focused-optional-compact.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k in ['head','actual512','timed_samples','stats18','FP48','FP_n256_actual_selected24','FP_n64_fallback24']},indent=2))

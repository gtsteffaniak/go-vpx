from pathlib import Path
import json,hashlib,re,subprocess
B=Path('/private/tmp');R=B/'govpx-pr51-manual39127005272-artifact';ROOT='/Users/thesyncim/GolandProjects/govpx';H='bc4a12a2ea74f6219d26acb5646677016eb6423f';BASE='d08c4f72697dc256ea86fb5959339d2d6819e890';sha=lambda b:hashlib.sha256(b).hexdigest();PREFIX='github.com/thesyncim/govpx/internal/pixel.'
helper=subprocess.check_output(['git','show',H+':scripts/capture-stats-codegen.py'],cwd=ROOT);log=(R/'pixel-optional.txt').read_bytes();out={}
for variant,commit in [('parent',BASE),('current',H)]:
 D=R/'pixel-optional-stats-codegen'/variant;m=json.loads((D/'metadata.json').read_text());assert m['variant']==variant and m['source_commit']==commit and m['head_commit']==H and m['base_commit']==BASE and m['protocol_SHA256']==sha(log) and m['capture_helper_SHA256']==sha(helper)
 assert (m['binary_sha256']+'  '+m['binary']) in log.decode();assert m['ISA_and_orders']['orders']==[[str(i),'parent current' if i%2 else 'current parent'] for i in range(1,7)]
 commands=json.loads((D/'commands.json').read_text());assert all(c['exit_code']==0 and (D/c['output']).is_file() for c in commands);assert (D/'objdump-version.txt').read_text().startswith('GNU objdump');info=(D/'binary-buildinfo.txt').read_text();assert 'go1.27.2' in info and 'GOARCH=amd64' in info and 'GOOS=linux' in info
 # Compare exact captured source hashes with explicit Git commits plus common fixture overlay.
 refs={p:(H if p in m['identical_common_fixture_SHA256'] else commit) for p in m['actual_source_SHA256']};query=''.join(refs[p]+':'+p+'\n' for p in refs).encode();blob=subprocess.check_output(['git','cat-file','--batch'],input=query,cwd=ROOT);off=0
 for p in refs:
  end=blob.index(b'\n',off);header=blob[off:end].decode().split();assert header[1]=='blob';n=int(header[2]);data=blob[end+1:end+1+n];assert sha(data)==m['actual_source_SHA256'][p],p;off=end+1+n+1
 assert off==len(blob)
 for p,h in m['identical_common_fixture_SHA256'].items():assert sha((R/'pixel-optional-fixtures'/Path(p).name).read_bytes())==h
 nm={}
 for line in (D/'symbols-all.txt').read_text().splitlines():
  k=re.fullmatch(r'\s*([0-9a-fA-F]+)\s+(\d+)\s+([Tt])\s+(\S+)\s*',line)
  if k:nm[k[4]]=(int(k[1],16),int(k[2]),k[3])
 symbols={}
 for name,s in m['live_symbols'].items():
  addr,size,kind=nm[name];assert hex(addr)==s['address_hex'] and size==s['size_bytes'] and kind==s['kind'] and addr%16==s['address_mod16'] and addr%32==s['address_mod32'] and addr%64==s['address_mod64']
  asm=(D/(name.removeprefix(PREFIX)+'.asm.txt')).read_text();assert re.search(r'^0*'+format(addr,'x')+r' <'+re.escape(name)+r'>:',asm,re.M)
  symbols[name]={'address':s['address_hex'],'address_mod64':s['address_mod64'],'size_bytes':size,'raw_GNU_disassembly_sha256':sha(asm.encode())}
 assert PREFIX+'BenchmarkStatsReductionNative.func1' in symbols and PREFIX+'pixelStatsPairs8' in symbols
 out[variant]={'actual_measured_binary_sha256_record':m['binary_sha256'],'binary_size':m['binary_size'],'exact_source_commit':commit,'source_files_verified':len(refs),'all_captured_source_hashes_verified':m['actual_source_SHA256'],'identical_fixture_SHA':m['identical_common_fixture_SHA256'],'symbols':symbols,'absent_may_be_inlined':m['absent_may_be_inlined'],'capture_commands_all_exit0':True,'ISA_and_orders':m['ISA_and_orders']}
proof={'PR':51,'run':39127005272,'driver_head':H,'base':BASE,'scope':'Actual post-timing native pixel-binary/source/layout capture, no binary rerun. All disassembly and exact addresses retained; does not prove performance cause.','all128raw_files_preserved':len([p for p in R.rglob('*') if p.is_file()])==128,'protocol_SHA':sha(log),'capture_helper_exact_Git_SHA':sha(helper),'variants':out,'actual_Pairs8_sizes':{v:x['symbols'][PREFIX+'pixelStatsPairs8']['size_bytes'] for v,x in out.items()},'no_source_build_encode_timing_or_binary_execution_performed_for_audit':True}
(B/'govpx-pr51-manual39127005272-stats-capture-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'run':proof['run'],'variants_source_files':{v:d['source_files_verified'] for v,d in out.items()},'Pairs8_sizes':proof['actual_Pairs8_sizes'],'all_capture_proofs_verified':True},indent=2))

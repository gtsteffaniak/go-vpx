from pathlib import Path
import json,re,hashlib,statistics,subprocess
B=Path('/private/tmp');R=B/'govpx-pr51-manual39127005272-artifact';ROOT='/Users/thesyncim/GolandProjects/govpx';H='bc4a12a2ea74f6219d26acb5646677016eb6423f';BASE='d08c4f72697dc256ea86fb5959339d2d6819e890';DRIVER='bc4a12a2ea74f6219d26acb5646677016eb6423f'
sha=lambda b:hashlib.sha256(b).hexdigest()
def blob(c,n):return subprocess.check_output(['git','show',c+':'+n],cwd=ROOT)
for n in ['dc_pair_native_bench_test.go','dc_pair_inplace_native_bench_test.go']:assert (R/n).read_bytes()==blob(H,'internal/vp8/dsp/'+n)
assert (R/'dc-pair-reference-shim.go.txt').read_bytes()==blob(DRIVER,'scripts/benchmark-fixtures/dc_pair_inplace_reference_shim.go.txt')
assert (R/'dc-pair-fixtures.txt').read_text().startswith('head shim=absent-original-API-retained\nbase shim=absent-original-API-retained\nassembly shim=reference-only\n')
fixture_hashes=[]
for line in (R/'dc-pair-fixtures.txt').read_text().splitlines()[3:]:
 digest,n=line.split('  ',1)
 rel='scripts/benchmark-fixtures/dc_pair_inplace_reference_shim.go.txt' if n.endswith('dc_pair_inplace_reference_shim.go.txt') else 'scripts/benchmark-dc-pair-focused.sh' if n.endswith('benchmark-dc-pair-focused.sh') else 'internal/vp8/dsp/'+Path(n).name
 ref=DRIVER if rel.startswith('scripts/') else H;assert sha(blob(ref,rel))==digest;fixture_hashes.append({'path':rel,'source_commit':ref,'sha256':digest})
expected={f'Benchmark{api}/pitch{p}/inplace{i}/pair{k}' for api in ['DCPairRowsNative','DCPairInPlaceRowsNative'] for p in [8,32,1312] for i in ['false','true'] for k in range(3)};assert len(expected)==36
pat=re.compile(r'^(Benchmark\S+)\s+(\d+)\s+(?:([\d.eE+\-]+) ns/op\s+)?(\d+) B/op\s+(\d+) allocs/op$',re.M)
def parse(path,one=False):
 text=path.read_text();assert re.search(r'^PASS$',text,re.M);rows={}
 for n,it,ns,b,a in pat.findall(text):
  assert n not in rows and int(b)==int(a)==0 and (int(it)==1 if one else int(it)>1);rows[n]={'iterations':int(it),'ns':float(ns) if ns else None,'bytes':int(b),'allocs':int(a)}
  if not one:assert ns and float(ns)>0
 assert set(rows)==expected;return rows
pre={v:parse(R/f'dc-pair/{v}-preflight.txt',True) for v in ['head','base','assembly']};timed={v:[parse(R/f'dc-pair/{v}-round-{i}.txt') for i in range(1,7)] for v in pre};summary=json.loads((R/'dc-pair/summary.json').read_text());assert summary['public_cases']==36 and summary['timed_samples']==648 and summary['excluded_one_shots']==108
orders=[line.split(': ',1)[1].split() for line in (R/'dc-pair/orders.txt').read_text().splitlines()];assert orders==summary['round_orders'] and len({tuple(x) for x in orders})==6
for col in range(3):assert sorted(x[col] for x in orders)==['assembly','assembly','base','base','head','head']
results={}
for n in sorted(expected):
 vals={v:[r[n]['ns'] for r in timed[v]] for v in timed};med={v:statistics.median(x) for v,x in vals.items()};br=[a/b for a,b in zip(vals['base'],vals['head'])];ar=[a/b for a,b in zip(vals['assembly'],vals['head'])];rec=next(v for v in summary['results'] if v['case']==n);assert med==rec['median_ns'] and vals==rec['samples_ns'] and br==rec['paired_reference_over_head']['base'] and ar==rec['paired_reference_over_head']['assembly']
 results[n]={'samples_ns':vals,'median_ns':med,'base_over_head':med['base']/med['head'],'old_over_head':med['assembly']/med['head'],'base_all6_ratios':br,'old_all6_ratios':ar,'head_time_percent':100*(med['head']/med['base']-1),'slower_pairs':sum(x<1 for x in br)}
val=(R/'dc-pair-validation.txt').read_text();assert not re.search(r'^FAIL|--- FAIL:',val,re.M);passes=re.findall(r'^--- PASS: (\S+)',val,re.M)

out={'PR':51,'run':39127005272,'driver_Git':DRIVER,'measured_head':H,'measured_base':BASE,'requested_runner':'ubuntu-24.04','DC_scope':'Unchanged paired-DC API control; head/base retain original API, old691 reference-only shim. Not portable producer performance.','DC_fixtures_and_driver_hashes':fixture_hashes,'DC648_timed_zeroalloc':True,'DC108_excluded_zeroalloc':True,'DC_preflights':pre,'DC_all36_results':results,'DC_median_base_over_head_range':[min(v['base_over_head'] for v in results.values()),max(v['base_over_head'] for v in results.values())],'DC_median_slower':sum(v['head_time_percent']>0 for v in results.values()),'DC_all6_slower':sum(v['slower_pairs']==6 for v in results.values()),'DC_validation_all_PASS':passes,'all_raw_untouched':True}
(B/'govpx-pr51-manual39127005272-DC-proof.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['run','measured_head','DC_median_base_over_head_range','DC_median_slower','DC_all6_slower']},indent=2))

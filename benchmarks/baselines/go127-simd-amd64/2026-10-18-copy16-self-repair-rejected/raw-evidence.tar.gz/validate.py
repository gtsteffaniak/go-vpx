import pathlib,subprocess,json,os,re
root=pathlib.Path('/Users/thesyncim/GolandProjects/govpx');w=pathlib.Path('/private/tmp/govpx-copy16-self-repair');out=w/'validation';out.mkdir(exist_ok=True);snap=w/'candidate';env=os.environ.copy();env.update(CODEX_PROJECT_CACHE_ROOT='/private/tmp/codex-projects',CODEX_AGENT_ID='govpx-ci-copyself',GOTOOLCHAIN='local',GOEXPERIMENT='simd',GOFLAGS='-p=2',GOMAXPROCS='2',GO='/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go',GOOS='darwin',GOARCH='amd64',GOAMD64='v1',CGO_ENABLED='1');records=[]
def run(name,args,extra={}):
 e=env.copy();e.update(extra);p=subprocess.run(args,cwd=root,env=e,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/(name+'.log')).write_text(p.stdout);records.append(dict(name=name,args=args,env=extra,exit=p.returncode));(out/'commands.json').write_text(json.dumps(records,indent=2));print(name,p.returncode,flush=True)
 if p.returncode:print(p.stdout[-4000:]);raise SystemExit(p.returncode)
 return p.stdout
run('cache',[str(root/'scripts/go.sh'),'env','GOCACHE'])
for pkg,path in [('pixel','./internal/pixel'),('dsp','./internal/vp8/dsp'),('root','.')]:
 for mode in ['ordinary','checkptr2','linux']:
  binary=out/f'{pkg}-{mode}.test';args=[str(root/'scripts/go.sh'),'-C',str(snap),'test','-pgo=off','-c','-o',str(binary)]
  if mode=='checkptr2':args+=['-gcflags=all=-d=checkptr=2']
  else:args+=['-gcflags=github.com/thesyncim/govpx/internal/pixel=-m=2','-gcflags=github.com/thesyncim/govpx/internal/vp8/dsp=-m=2','-gcflags=github.com/thesyncim/govpx=-m=2']
  args+=[path];run('build-'+pkg+'-'+mode,args,dict(GOOS='linux',CGO_ENABLED='0') if mode=='linux' else {})
  if mode=='linux':continue
  for off in [False,True]:
   cpu='off' if off else 'selected';extra=dict(ROSETTA_ADVERTISE_AVX='1',GOVPX_REQUIRE_SIMD='0' if off else '1',GOVPX_REQUIRE_SCALAR='1' if off else '0',GODEBUG='cpu.avx=off,cpu.avx2=off' if off else '')
   run('run-'+pkg+'-'+mode+'-'+cpu,['arch','-x86_64',str(binary),'-test.run=^TestCopy16(AMD|Frozen)','-test.v','-test.count=1'],extra)
   if pkg!='pixel':
    s=run('fixture8-'+pkg+'-'+mode+'-'+cpu,['arch','-x86_64',str(binary),'-test.run=^$','-test.bench=^BenchmarkCopy16RowsNative$','-test.benchtime=1x','-test.benchmem','-test.cpu=1'],extra);lines=[l for l in s.splitlines() if l.startswith('BenchmarkCopy16RowsNative/')];assert len(lines)==8
    if mode=='ordinary':assert all(re.search(r'\b0 B/op\s+0 allocs/op',l) for l in lines)
print('COPY SELF PASS')

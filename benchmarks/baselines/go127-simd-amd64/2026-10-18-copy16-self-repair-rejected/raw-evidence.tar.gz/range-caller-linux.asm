
/private/tmp/govpx-copy16-self-repair/range-validation/dsp-linux.test:	file format elf64-x86-64

Disassembly of section .text:

000000000060e5a0 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16>:
  60e5a0: 55                           	pushq	%rbp
  60e5a1: 48 89 e5                     	movq	%rsp, %rbp
  60e5a4: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
  60e5a9: 48 89 74 24 30               	movq	%rsi, 0x30(%rsp)
  60e5ae: 80 3d 82 37 32 00 00         	cmpb	$0x0, 0x323782(%rip)    # 0x931d37 <github.com/thesyncim/govpx/internal/pixel.Enabled>
  60e5b5: 74 4c                        	je	0x60e603 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x63>
  60e5b7: 48 89 fa                     	movq	%rdi, %rdx
  60e5ba: 4c 09 d7                     	orq	%r10, %rdi
  60e5bd: 48 c1 ef 1e                  	shrq	$0x1e, %rdi
  60e5c1: 48 85 ff                     	testq	%rdi, %rdi
  60e5c4: 75 40                        	jne	0x60e606 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x66>
  60e5c6: 48 8d 3c 52                  	leaq	(%rdx,%rdx,2), %rdi
  60e5ca: 48 8d 3c bf                  	leaq	(%rdi,%rdi,4), %rdi
  60e5ce: 48 8d 7f 10                  	leaq	0x10(%rdi), %rdi
  60e5d2: 48 39 fb                     	cmpq	%rdi, %rbx
  60e5d5: 7c 2f                        	jl	0x60e606 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x66>
  60e5d7: 4b 8d 1c 52                  	leaq	(%r10,%r10,2), %rbx
  60e5db: 48 8d 1c 9b                  	leaq	(%rbx,%rbx,4), %rbx
  60e5df: 48 8d 5b 10                  	leaq	0x10(%rbx), %rbx
  60e5e3: 49 39 d8                     	cmpq	%rbx, %r8
  60e5e6: 7c 1e                        	jl	0x60e606 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x66>
  60e5e8: 49 39 d2                     	cmpq	%rdx, %r10
  60e5eb: 75 0c                        	jne	0x60e5f9 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x59>
  60e5ed: 48 39 c6                     	cmpq	%rax, %rsi
  60e5f0: 75 07                        	jne	0x60e5f9 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x59>
  60e5f2: bb 01 00 00 00               	movl	$0x1, %ebx
  60e5f7: eb 0f                        	jmp	0x60e608 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x68>
  60e5f9: 31 db                        	xorl	%ebx, %ebx
  60e5fb: 48 89 f7                     	movq	%rsi, %rdi
  60e5fe: 49 89 c0                     	movq	%rax, %r8
  60e601: eb 74                        	jmp	0x60e677 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xd7>
  60e603: 48 89 fa                     	movq	%rdi, %rdx
  60e606: 31 db                        	xorl	%ebx, %ebx
  60e608: 84 db                        	testb	%bl, %bl
  60e60a: 75 05                        	jne	0x60e611 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x71>
  60e60c: 90                           	nop
  60e60d: 31 db                        	xorl	%ebx, %ebx
  60e60f: eb 06                        	jmp	0x60e617 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x77>
  60e611: 5d                           	popq	%rbp
  60e612: c3                           	retq
  60e613: 49 8d 58 01                  	leaq	0x1(%r8), %rbx
  60e617: 48 83 fb 10                  	cmpq	$0x10, %rbx
  60e61b: 7d 3d                        	jge	0x60e65a <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xba>
  60e61d: 48 89 df                     	movq	%rbx, %rdi
  60e620: 49 0f af da                  	imulq	%r10, %rbx
  60e624: 4c 8d 43 10                  	leaq	0x10(%rbx), %r8
  60e628: 4d 39 c1                     	cmpq	%r8, %r9
  60e62b: 72 42                        	jb	0x60e66f <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xcf>
  60e62d: 4c 39 c3                     	cmpq	%r8, %rbx
  60e630: 77 38                        	ja	0x60e66a <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xca>
  60e632: 49 89 f8                     	movq	%rdi, %r8
  60e635: 48 0f af fa                  	imulq	%rdx, %rdi
  60e639: 4c 8d 5f 10                  	leaq	0x10(%rdi), %r11
  60e63d: 48 01 f3                     	addq	%rsi, %rbx
  60e640: 4c 39 d9                     	cmpq	%r11, %rcx
  60e643: 72 20                        	jb	0x60e665 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xc5>
  60e645: 4c 39 df                     	cmpq	%r11, %rdi
  60e648: 77 12                        	ja	0x60e65c <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xbc>
  60e64a: 48 01 c7                     	addq	%rax, %rdi
  60e64d: 48 39 fb                     	cmpq	%rdi, %rbx
  60e650: 74 c1                        	je	0x60e613 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x73>
  60e652: 0f 10 07                     	movups	(%rdi), %xmm0
  60e655: 0f 11 03                     	movups	%xmm0, (%rbx)
  60e658: eb b9                        	jmp	0x60e613 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x73>
  60e65a: 5d                           	popq	%rbp
  60e65b: c3                           	retq
  60e65c: 0f 1f 40 00                  	nopl	(%rax)
  60e660: e8 9b 1e e8 ff               	callq	0x490500 <runtime.panicBounds>
  60e665: e8 96 1e e8 ff               	callq	0x490500 <runtime.panicBounds>
  60e66a: e8 91 1e e8 ff               	callq	0x490500 <runtime.panicBounds>
  60e66f: e8 8c 1e e8 ff               	callq	0x490500 <runtime.panicBounds>
  60e674: 48 ff c3                     	incq	%rbx
  60e677: 48 83 fb 10                  	cmpq	$0x10, %rbx
  60e67b: 7d 16                        	jge	0x60e693 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xf3>
  60e67d: c5 fa 6f 00                  	vmovdqu	(%rax), %xmm0
  60e681: c5 fa 7f 06                  	vmovdqu	%xmm0, (%rsi)
  60e685: 48 83 fb 0f                  	cmpq	$0xf, %rbx
  60e689: 74 e9                        	je	0x60e674 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xd4>
  60e68b: 48 01 d0                     	addq	%rdx, %rax
  60e68e: 4c 01 d6                     	addq	%r10, %rsi
  60e691: eb e1                        	jmp	0x60e674 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xd4>
  60e693: 4c 89 c0                     	movq	%r8, %rax
  60e696: 48 89 fe                     	movq	%rdi, %rsi
  60e699: bb 01 00 00 00               	movl	$0x1, %ebx
  60e69e: 66 90                        	nop
  60e6a0: e9 63 ff ff ff               	jmp	0x60e608 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x68>
  60e6a5: cc                           	int3
  60e6a6: cc                           	int3
  60e6a7: cc                           	int3
  60e6a8: cc                           	int3
  60e6a9: cc                           	int3
  60e6aa: cc                           	int3
  60e6ab: cc                           	int3
  60e6ac: cc                           	int3
  60e6ad: cc                           	int3
  60e6ae: cc                           	int3
  60e6af: cc                           	int3
  60e6b0: cc                           	int3
  60e6b1: cc                           	int3
  60e6b2: cc                           	int3
  60e6b3: cc                           	int3
  60e6b4: cc                           	int3
  60e6b5: cc                           	int3
  60e6b6: cc                           	int3
  60e6b7: cc                           	int3
  60e6b8: cc                           	int3
  60e6b9: cc                           	int3
  60e6ba: cc                           	int3
  60e6bb: cc                           	int3
  60e6bc: cc                           	int3
  60e6bd: cc                           	int3
  60e6be: cc                           	int3
  60e6bf: cc                           	int3

import pathlib,shutil,json,hashlib,subprocess
w=pathlib.Path('/private/tmp/govpx-copy16-self-repair');ready=pathlib.Path('/private/tmp/govpx-copy16-self-repair-rejected-ready');ready.mkdir(exist_ok=True)
for folder in ['validation','range-validation','loop-variants']:
 for p in (w/folder).glob('*'):
  if p.is_file() and p.suffix!='.test':q=ready/folder/p.name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for variant in ['candidate','range-candidate']:
 for file in ['copy16_rows_amd64.go','copy16_self_repair_amd64_test.go']:
  q=ready/variant/file;q.parent.mkdir(exist_ok=True);shutil.copy2(w/variant/'internal/pixel'/file,q)
for p in w.glob('*.py'):shutil.copy2(p,ready/p.name)
shutil.copy2(w/'range-caller-linux.asm',ready/'range-caller-linux.asm')
for name,sym,pkg in [('naive-helper','github.com/thesyncim/govpx/internal/pixel.Copy16Rows','pixel'),('naive-dsp','github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16','dsp'),('range-root','github.com/thesyncim/govpx.copyMacroblockY','root')]:
 b=w/('range-validation' if name.startswith('range') else 'validation')/(pkg+'-linux.test');s=subprocess.check_output(['xcrun','llvm-objdump','-d','--disassemble-symbols='+sym,str(b)],text=True);(ready/(name+'.asm')).write_text(s)
binaries=[]
for folder in ['validation','range-validation','loop-variants']:
 for p in sorted((w/folder).glob('*.test')):binaries.append(dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(ready/'binary-inventory.json').write_text(json.dumps(binaries,indent=2))
report='''# Rejected PRIVATE AMD Copy16 self-noop repairs

Base46a08f8e. Root47 keeps Copy16productionUNCHANGED to protect its actualdisjointnativewins. These variants have no nativeperformanceevidence/acceptance claim.46native trueexact-self/zero-stridecontrols regressed(root.5096×,DSP.4416×parent); that evidence remainsvalid andretainedbyparent. We didnot trade knownordinarywins for an unmeasurednoopshortcut.

Allproposals place `if ss==ds &&sp==dp{returntrue}` AFTER originalEnabled/unsignedstride/fullvisibleLENguards. It is correctonlyatthatexactpoint: everyrowselfcopy is a semanticnoop; equalbase withunequalstride, shiftedaliasandinvalidshort-visible/capacitywindows mustkeeporiginalorderedmemmove/fallback/partialpanic. Newunitproof tests exactself strides0/1/7/16/31/1312, independentlyshortlen/spare/clippedcaps,nil/extremestrides/disabled. Existingfullbacking/allalias/root/DSPfrozenpanicoracles retained.

| Private variant | Inlinecost | Outcome |
| --- | ---: | --- |
| Naiveoriginalcarry+no-op |90 |reject: losesoriginal80inline,addsABIcall |
| Rangeconditionalcarry/chainedstore |79 |inlinebuthotloop10instructionsvs46carry6;rejectrisk |
| First15+separatefinalrow |87 |noninline |
| Indexedrange |74 |inlinebutadds2IMULperrow;rejectaddresswork |
| Originalcarry/chainedstore |84 |noninline |
| Sharedwhileconditioncarry |86 |noninline |
| Finalparent-proposedremaining15/returnfromloop |83 |noninline |

Naive and79rangevariants eachcompleted9Darwin/Linuxbuilds plusordinary/checkptr2 pixel/root/DSP selected/actualCPUoff fullstate/panic/alias tests, allPASS. Eachhas64public8fixtureone-shots(2packages×2modes×2CPU×8),allordinary0alloc. No emulatedspeedclaim.79range keepsDSPhelper inlined(cost121publicwrapper) androotcost113, but extra per-rowcmp/conditional/jump materiallychangeshotwork. Lastreturn83alsofails80budget. Otherboundedvariants are compile/codegenprobesonly, notclaimedtestedproductioncandidates.

Allrawlogs,sourcevariants,Go-mdiagnostics,actualcallerdisassemblyandbinaryhash/privatepathsretained. Originalnaive/rangecandidate snapshots stayprivate. Package is intentionallyNOT an integrationoverlay. No root/Git/dependency changes. Futurecarefulworkmustrepairself-noop withoutdestroying ordinaryinline/hotloopproperties,thenremeasureallnativecontrols.\n'''
(ready/'REPORT.md').write_text(report)
manifest=[]
for p in sorted(ready.rglob('*')):
 if p.is_file() and p.name!='MANIFEST.json':manifest.append(dict(path=str(p.relative_to(ready)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(ready/'MANIFEST.json').write_text(json.dumps(manifest,indent=2));print(ready,len(manifest),hashlib.sha256((ready/'MANIFEST.json').read_bytes()).hexdigest())

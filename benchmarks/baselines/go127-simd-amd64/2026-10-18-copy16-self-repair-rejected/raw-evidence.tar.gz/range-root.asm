
/private/tmp/govpx-copy16-self-repair/range-validation/root-linux.test:	file format elf64-x86-64

Disassembly of section .text:

0000000000780d80 <github.com/thesyncim/govpx.copyMacroblockY>:
  780d80: 55                           	pushq	%rbp
  780d81: 48 89 e5                     	movq	%rsp, %rbp
  780d84: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
  780d89: 48 89 74 24 30               	movq	%rsi, 0x30(%rsp)
  780d8e: 80 3d 6b b7 d6 00 00         	cmpb	$0x0, 0xd6b76b(%rip)    # 0x14ec500 <github.com/thesyncim/govpx/internal/pixel.Enabled>
  780d95: 74 4c                        	je	0x780de3 <github.com/thesyncim/govpx.copyMacroblockY+0x63>
  780d97: 4c 89 d2                     	movq	%r10, %rdx
  780d9a: 49 09 fa                     	orq	%rdi, %r10
  780d9d: 49 c1 ea 1e                  	shrq	$0x1e, %r10
  780da1: 4d 85 d2                     	testq	%r10, %r10
  780da4: 75 40                        	jne	0x780de6 <github.com/thesyncim/govpx.copyMacroblockY+0x66>
  780da6: 4c 8d 14 52                  	leaq	(%rdx,%rdx,2), %r10
  780daa: 4f 8d 14 92                  	leaq	(%r10,%r10,4), %r10
  780dae: 4d 8d 52 10                  	leaq	0x10(%r10), %r10
  780db2: 4d 39 d0                     	cmpq	%r10, %r8
  780db5: 7c 2f                        	jl	0x780de6 <github.com/thesyncim/govpx.copyMacroblockY+0x66>
  780db7: 4c 8d 04 7f                  	leaq	(%rdi,%rdi,2), %r8
  780dbb: 4f 8d 04 80                  	leaq	(%r8,%r8,4), %r8
  780dbf: 4d 8d 40 10                  	leaq	0x10(%r8), %r8
  780dc3: 4c 39 c3                     	cmpq	%r8, %rbx
  780dc6: 7c 1e                        	jl	0x780de6 <github.com/thesyncim/govpx.copyMacroblockY+0x66>
  780dc8: 48 39 fa                     	cmpq	%rdi, %rdx
  780dcb: 75 0c                        	jne	0x780dd9 <github.com/thesyncim/govpx.copyMacroblockY+0x59>
  780dcd: 48 39 c6                     	cmpq	%rax, %rsi
  780dd0: 75 07                        	jne	0x780dd9 <github.com/thesyncim/govpx.copyMacroblockY+0x59>
  780dd2: bb 01 00 00 00               	movl	$0x1, %ebx
  780dd7: eb 0f                        	jmp	0x780de8 <github.com/thesyncim/govpx.copyMacroblockY+0x68>
  780dd9: 31 db                        	xorl	%ebx, %ebx
  780ddb: 49 89 c0                     	movq	%rax, %r8
  780dde: 49 89 f2                     	movq	%rsi, %r10
  780de1: eb 74                        	jmp	0x780e57 <github.com/thesyncim/govpx.copyMacroblockY+0xd7>
  780de3: 4c 89 d2                     	movq	%r10, %rdx
  780de6: 31 db                        	xorl	%ebx, %ebx
  780de8: 84 db                        	testb	%bl, %bl
  780dea: 75 04                        	jne	0x780df0 <github.com/thesyncim/govpx.copyMacroblockY+0x70>
  780dec: 31 db                        	xorl	%ebx, %ebx
  780dee: eb 06                        	jmp	0x780df6 <github.com/thesyncim/govpx.copyMacroblockY+0x76>
  780df0: 5d                           	popq	%rbp
  780df1: c3                           	retq
  780df2: 49 8d 5a 01                  	leaq	0x1(%r10), %rbx
  780df6: 48 83 fb 10                  	cmpq	$0x10, %rbx
  780dfa: 7d 3f                        	jge	0x780e3b <github.com/thesyncim/govpx.copyMacroblockY+0xbb>
  780dfc: 49 89 d8                     	movq	%rbx, %r8
  780dff: 48 0f af df                  	imulq	%rdi, %rbx
  780e03: 4c 8d 53 10                  	leaq	0x10(%rbx), %r10
  780e07: 4c 39 d1                     	cmpq	%r10, %rcx
  780e0a: 72 43                        	jb	0x780e4f <github.com/thesyncim/govpx.copyMacroblockY+0xcf>
  780e0c: 4c 39 d3                     	cmpq	%r10, %rbx
  780e0f: 77 39                        	ja	0x780e4a <github.com/thesyncim/govpx.copyMacroblockY+0xca>
  780e11: 4d 89 c2                     	movq	%r8, %r10
  780e14: 4c 0f af c2                  	imulq	%rdx, %r8
  780e18: 4d 8d 58 10                  	leaq	0x10(%r8), %r11
  780e1c: 48 01 c3                     	addq	%rax, %rbx
  780e1f: 90                           	nop
  780e20: 4d 39 d9                     	cmpq	%r11, %r9
  780e23: 72 20                        	jb	0x780e45 <github.com/thesyncim/govpx.copyMacroblockY+0xc5>
  780e25: 4d 39 d8                     	cmpq	%r11, %r8
  780e28: 77 13                        	ja	0x780e3d <github.com/thesyncim/govpx.copyMacroblockY+0xbd>
  780e2a: 49 01 f0                     	addq	%rsi, %r8
  780e2d: 4c 39 c3                     	cmpq	%r8, %rbx
  780e30: 74 c0                        	je	0x780df2 <github.com/thesyncim/govpx.copyMacroblockY+0x72>
  780e32: 41 0f 10 00                  	movups	(%r8), %xmm0
  780e36: 0f 11 03                     	movups	%xmm0, (%rbx)
  780e39: eb b7                        	jmp	0x780df2 <github.com/thesyncim/govpx.copyMacroblockY+0x72>
  780e3b: 5d                           	popq	%rbp
  780e3c: c3                           	retq
  780e3d: 0f 1f 00                     	nopl	(%rax)
  780e40: e8 3b 5a d1 ff               	callq	0x496880 <runtime.panicBounds>
  780e45: e8 36 5a d1 ff               	callq	0x496880 <runtime.panicBounds>
  780e4a: e8 31 5a d1 ff               	callq	0x496880 <runtime.panicBounds>
  780e4f: e8 2c 5a d1 ff               	callq	0x496880 <runtime.panicBounds>
  780e54: 48 ff c3                     	incq	%rbx
  780e57: 48 83 fb 10                  	cmpq	$0x10, %rbx
  780e5b: 7d 16                        	jge	0x780e73 <github.com/thesyncim/govpx.copyMacroblockY+0xf3>
  780e5d: c5 fa 6f 06                  	vmovdqu	(%rsi), %xmm0
  780e61: c5 fa 7f 00                  	vmovdqu	%xmm0, (%rax)
  780e65: 48 83 fb 0f                  	cmpq	$0xf, %rbx
  780e69: 74 e9                        	je	0x780e54 <github.com/thesyncim/govpx.copyMacroblockY+0xd4>
  780e6b: 48 01 d6                     	addq	%rdx, %rsi
  780e6e: 48 01 f8                     	addq	%rdi, %rax
  780e71: eb e1                        	jmp	0x780e54 <github.com/thesyncim/govpx.copyMacroblockY+0xd4>
  780e73: 4c 89 c0                     	movq	%r8, %rax
  780e76: 4c 89 d6                     	movq	%r10, %rsi
  780e79: bb 01 00 00 00               	movl	$0x1, %ebx
  780e7e: 66 90                        	nop
  780e80: e9 63 ff ff ff               	jmp	0x780de8 <github.com/thesyncim/govpx.copyMacroblockY+0x68>
  780e85: cc                           	int3
  780e86: cc                           	int3
  780e87: cc                           	int3
  780e88: cc                           	int3
  780e89: cc                           	int3
  780e8a: cc                           	int3
  780e8b: cc                           	int3
  780e8c: cc                           	int3
  780e8d: cc                           	int3
  780e8e: cc                           	int3
  780e8f: cc                           	int3
  780e90: cc                           	int3
  780e91: cc                           	int3
  780e92: cc                           	int3
  780e93: cc                           	int3
  780e94: cc                           	int3
  780e95: cc                           	int3
  780e96: cc                           	int3
  780e97: cc                           	int3
  780e98: cc                           	int3
  780e99: cc                           	int3
  780e9a: cc                           	int3
  780e9b: cc                           	int3
  780e9c: cc                           	int3
  780e9d: cc                           	int3
  780e9e: cc                           	int3
  780e9f: cc                           	int3

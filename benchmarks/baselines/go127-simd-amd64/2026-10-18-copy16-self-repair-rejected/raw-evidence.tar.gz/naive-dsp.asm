
/private/tmp/govpx-copy16-self-repair/validation/dsp-linux.test:	file format elf64-x86-64

Disassembly of section .text:

000000000060e620 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16>:
  60e620: 49 3b 66 10                  	cmpq	0x10(%r14), %rsp
  60e624: 0f 86 cc 00 00 00            	jbe	0x60e6f6 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xd6>
  60e62a: 55                           	pushq	%rbp
  60e62b: 48 89 e5                     	movq	%rsp, %rbp
  60e62e: 48 83 ec 40                  	subq	$0x40, %rsp
  60e632: 48 89 7c 24 68               	movq	%rdi, 0x68(%rsp)
  60e637: 4c 89 94 24 88 00 00 00      	movq	%r10, 0x88(%rsp)
  60e63f: 48 89 44 24 50               	movq	%rax, 0x50(%rsp)
  60e644: 48 89 4c 24 60               	movq	%rcx, 0x60(%rsp)
  60e649: 48 89 74 24 70               	movq	%rsi, 0x70(%rsp)
  60e64e: 4c 89 8c 24 80 00 00 00      	movq	%r9, 0x80(%rsp)
  60e656: e8 85 4b fe ff               	callq	0x5f31e0 <github.com/thesyncim/govpx/internal/pixel.Copy16Rows>
  60e65b: 84 c0                        	testb	%al, %al
  60e65d: 75 29                        	jne	0x60e688 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x68>
  60e65f: 90                           	nop
  60e660: 31 c0                        	xorl	%eax, %eax
  60e662: 48 8b 8c 24 88 00 00 00      	movq	0x88(%rsp), %rcx
  60e66a: 48 8b 94 24 80 00 00 00      	movq	0x80(%rsp), %rdx
  60e672: 48 8b 5c 24 68               	movq	0x68(%rsp), %rbx
  60e677: 48 8b 74 24 70               	movq	0x70(%rsp), %rsi
  60e67c: 48 8b 7c 24 60               	movq	0x60(%rsp), %rdi
  60e681: 4c 8b 44 24 50               	movq	0x50(%rsp), %r8
  60e686: eb 0a                        	jmp	0x60e692 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x72>
  60e688: 48 83 c4 40                  	addq	$0x40, %rsp
  60e68c: 5d                           	popq	%rbp
  60e68d: c3                           	retq
  60e68e: 49 8d 42 01                  	leaq	0x1(%r10), %rax
  60e692: 48 83 f8 10                  	cmpq	$0x10, %rax
  60e696: 7d 43                        	jge	0x60e6db <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xbb>
  60e698: 49 89 c1                     	movq	%rax, %r9
  60e69b: 48 0f af c1                  	imulq	%rcx, %rax
  60e69f: 4c 8d 50 10                  	leaq	0x10(%rax), %r10
  60e6a3: 4c 39 d2                     	cmpq	%r10, %rdx
  60e6a6: 72 48                        	jb	0x60e6f0 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xd0>
  60e6a8: 4c 39 d0                     	cmpq	%r10, %rax
  60e6ab: 77 3e                        	ja	0x60e6eb <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xcb>
  60e6ad: 4d 89 ca                     	movq	%r9, %r10
  60e6b0: 4c 0f af cb                  	imulq	%rbx, %r9
  60e6b4: 4d 8d 59 10                  	leaq	0x10(%r9), %r11
  60e6b8: 48 01 f0                     	addq	%rsi, %rax
  60e6bb: 0f 1f 44 00 00               	nopl	(%rax,%rax)
  60e6c0: 4c 39 df                     	cmpq	%r11, %rdi
  60e6c3: 72 21                        	jb	0x60e6e6 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xc6>
  60e6c5: 4d 39 d9                     	cmpq	%r11, %r9
  60e6c8: 77 17                        	ja	0x60e6e1 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0xc1>
  60e6ca: 4d 01 c1                     	addq	%r8, %r9
  60e6cd: 4c 39 c8                     	cmpq	%r9, %rax
  60e6d0: 74 bc                        	je	0x60e68e <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x6e>
  60e6d2: 41 0f 10 01                  	movups	(%r9), %xmm0
  60e6d6: 0f 11 00                     	movups	%xmm0, (%rax)
  60e6d9: eb b3                        	jmp	0x60e68e <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16+0x6e>
  60e6db: 48 83 c4 40                  	addq	$0x40, %rsp
  60e6df: 5d                           	popq	%rbp
  60e6e0: c3                           	retq
  60e6e1: e8 1a 1e e8 ff               	callq	0x490500 <runtime.panicBounds>
  60e6e6: e8 15 1e e8 ff               	callq	0x490500 <runtime.panicBounds>
  60e6eb: e8 10 1e e8 ff               	callq	0x490500 <runtime.panicBounds>
  60e6f0: e8 0b 1e e8 ff               	callq	0x490500 <runtime.panicBounds>
  60e6f5: 90                           	nop
  60e6f6: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
  60e6fb: 48 89 5c 24 10               	movq	%rbx, 0x10(%rsp)
  60e700: 48 89 4c 24 18               	movq	%rcx, 0x18(%rsp)
  60e705: 48 89 7c 24 20               	movq	%rdi, 0x20(%rsp)
  60e70a: 48 89 74 24 28               	movq	%rsi, 0x28(%rsp)
  60e70f: 4c 89 44 24 30               	movq	%r8, 0x30(%rsp)
  60e714: 4c 89 4c 24 38               	movq	%r9, 0x38(%rsp)
  60e719: 4c 89 54 24 40               	movq	%r10, 0x40(%rsp)
  60e71e: 66 90                        	nop
  60e720: e8 9b 01 e8 ff               	callq	0x48e8c0 <runtime.morestack_noctxt.abi0>
  60e725: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
  60e72a: 48 8b 5c 24 10               	movq	0x10(%rsp), %rbx
  60e72f: 48 8b 4c 24 18               	movq	0x18(%rsp), %rcx
  60e734: 48 8b 7c 24 20               	movq	0x20(%rsp), %rdi
  60e739: 48 8b 74 24 28               	movq	0x28(%rsp), %rsi
  60e73e: 4c 8b 44 24 30               	movq	0x30(%rsp), %r8
  60e743: 4c 8b 4c 24 38               	movq	0x38(%rsp), %r9
  60e748: 4c 8b 54 24 40               	movq	0x40(%rsp), %r10
  60e74d: e9 ce fe ff ff               	jmp	0x60e620 <github.com/thesyncim/govpx/internal/vp8/dsp.Copy16x16>
  60e752: cc                           	int3
  60e753: cc                           	int3
  60e754: cc                           	int3
  60e755: cc                           	int3
  60e756: cc                           	int3
  60e757: cc                           	int3
  60e758: cc                           	int3
  60e759: cc                           	int3
  60e75a: cc                           	int3
  60e75b: cc                           	int3
  60e75c: cc                           	int3
  60e75d: cc                           	int3
  60e75e: cc                           	int3
  60e75f: cc                           	int3

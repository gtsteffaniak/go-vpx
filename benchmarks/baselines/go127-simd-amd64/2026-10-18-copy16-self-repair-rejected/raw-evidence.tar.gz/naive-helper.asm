
/private/tmp/govpx-copy16-self-repair/validation/pixel-linux.test:	file format elf64-x86-64

Disassembly of section .text:

00000000005537e0 <github.com/thesyncim/govpx/internal/pixel.Copy16Rows>:
  5537e0: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
  5537e5: 48 89 74 24 28               	movq	%rsi, 0x28(%rsp)
  5537ea: 80 3d dc f7 26 00 00         	cmpb	$0x0, 0x26f7dc(%rip)    # 0x7c2fcd <github.com/thesyncim/govpx/internal/pixel.Enabled>
  5537f1: 74 4b                        	je	0x55383e <github.com/thesyncim/govpx/internal/pixel.Copy16Rows+0x5e>
  5537f3: 48 89 f9                     	movq	%rdi, %rcx
  5537f6: 4c 09 d7                     	orq	%r10, %rdi
  5537f9: 48 c1 ef 1e                  	shrq	$0x1e, %rdi
  5537fd: 0f 1f 00                     	nopl	(%rax)
  553800: 48 85 ff                     	testq	%rdi, %rdi
  553803: 75 39                        	jne	0x55383e <github.com/thesyncim/govpx/internal/pixel.Copy16Rows+0x5e>
  553805: 48 8d 14 49                  	leaq	(%rcx,%rcx,2), %rdx
  553809: 48 8d 14 92                  	leaq	(%rdx,%rdx,4), %rdx
  55380d: 48 8d 52 10                  	leaq	0x10(%rdx), %rdx
  553811: 48 39 d3                     	cmpq	%rdx, %rbx
  553814: 7c 28                        	jl	0x55383e <github.com/thesyncim/govpx/internal/pixel.Copy16Rows+0x5e>
  553816: 4b 8d 14 52                  	leaq	(%r10,%r10,2), %rdx
  55381a: 48 8d 14 92                  	leaq	(%rdx,%rdx,4), %rdx
  55381e: 48 8d 52 10                  	leaq	0x10(%rdx), %rdx
  553822: 49 39 d0                     	cmpq	%rdx, %r8
  553825: 7c 17                        	jl	0x55383e <github.com/thesyncim/govpx/internal/pixel.Copy16Rows+0x5e>
  553827: 49 39 ca                     	cmpq	%rcx, %r10
  55382a: 75 0b                        	jne	0x553837 <github.com/thesyncim/govpx/internal/pixel.Copy16Rows+0x57>
  55382c: 48 39 c6                     	cmpq	%rax, %rsi
  55382f: 75 06                        	jne	0x553837 <github.com/thesyncim/govpx/internal/pixel.Copy16Rows+0x57>
  553831: b8 01 00 00 00               	movl	$0x1, %eax
  553836: c3                           	retq
  553837: ba 10 00 00 00               	movl	$0x10, %edx
  55383c: eb 09                        	jmp	0x553847 <github.com/thesyncim/govpx/internal/pixel.Copy16Rows+0x67>
  55383e: 31 c0                        	xorl	%eax, %eax
  553840: c3                           	retq
  553841: 48 01 c8                     	addq	%rcx, %rax
  553844: 4c 01 d6                     	addq	%r10, %rsi
  553847: c5 fa 6f 00                  	vmovdqu	(%rax), %xmm0
  55384b: c5 fa 7f 06                  	vmovdqu	%xmm0, (%rsi)
  55384f: 48 ff ca                     	decq	%rdx
  553852: 75 ed                        	jne	0x553841 <github.com/thesyncim/govpx/internal/pixel.Copy16Rows+0x61>
  553854: b8 01 00 00 00               	movl	$0x1, %eax
  553859: c3                           	retq
  55385a: cc                           	int3
  55385b: cc                           	int3
  55385c: cc                           	int3
  55385d: cc                           	int3
  55385e: cc                           	int3
  55385f: cc                           	int3

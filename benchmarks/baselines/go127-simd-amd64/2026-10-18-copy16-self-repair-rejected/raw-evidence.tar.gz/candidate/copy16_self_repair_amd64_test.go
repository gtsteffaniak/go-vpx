//go:build goexperiment.simd && amd64 && !purego

package pixel

import (
	"bytes"
	"testing"
)

func TestCopy16AMDSelfRepairGuard(t *testing.T) {
	selected := copy16ProbeEnabled(t)
	for _, stride := range []int{0, 1, 7, 16, 31, 1312} {
		span := 15*stride + 16
		for _, sl := range []int{0, span - 1, span} {
			for _, dl := range []int{0, span - 1, span} {
				for _, clipped := range []bool{false, true} {
					backing := make([]byte, 32+span+32)
					for i := range backing {
						backing[i] = byte(i*37 + i/7 + 11)
					}
					original := bytes.Clone(backing)
					src, dst := backing[32:32+sl], backing[32:32+dl]
					if clipped {
						src = src[:len(src):len(src)]
						dst = dst[:len(dst):len(dst)]
					}
					got := Copy16Rows(src, stride, dst, stride)
					want := selected && sl == span && dl == span
					if got != want || !bytes.Equal(backing, original) {
						t.Fatalf("stride%d sl%d dl%d clipped%v handled%v/%v orchanged", stride, sl, dl, clipped, got, want)
					}
				}
			}
		}
	}
	maxInt := int(^uint(0) >> 1)
	for _, stride := range []int{-1, 1 << 30, maxInt, -maxInt - 1} {
		b := make([]byte, 64)
		for i := range b {
			b[i] = byte(i)
		}
		before := bytes.Clone(b)
		if Copy16Rows(b, stride, b, stride) || !bytes.Equal(b, before) {
			t.Fatal("invalid stride bypassedguard", stride)
		}
	}
	if Copy16Rows(nil, 0, nil, 0) {
		t.Fatal("nil identical windows bypassedguard")
	}
	was := Enabled
	Enabled = false
	defer func() { Enabled = was }()
	b := make([]byte, 256)
	if Copy16Rows(b, 16, b, 16) {
		t.Fatal("disabled identicalwindows handled")
	}
}

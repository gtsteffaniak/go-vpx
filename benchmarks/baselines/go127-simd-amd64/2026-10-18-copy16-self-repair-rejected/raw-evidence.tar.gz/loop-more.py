exec(open('/private/tmp/govpx-copy16-self-repair/loop-probes.py').read().split('variants={')[0])
variants={
'carry-chain':prefix+'\tfor remaining := 16; ; {\n'+chain+'\t\tremaining--\n\t\tif remaining == 0 { break }\n\t\tsp, dp = unsafe.Add(sp, ss), unsafe.Add(dp, ds)\n\t}\n\treturn true\n}\n',
'carry-shared-condition':prefix+'\tfor remaining := 16; remaining > 0; {\n'+chain+'\t\tremaining--\n\t\tif remaining > 0 { sp, dp = unsafe.Add(sp, ss), unsafe.Add(dp, ds) }\n\t}\n\treturn true\n}\n'}
exec(open('/private/tmp/govpx-copy16-self-repair/loop-probes.py').read().split("root=pathlib.Path")[1].join(["root=pathlib.Path",""]).replace("(folder/'commands.json')", "(folder/'more-commands.json')"))

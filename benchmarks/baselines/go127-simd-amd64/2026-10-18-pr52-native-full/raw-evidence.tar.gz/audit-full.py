from pathlib import Path
import collections,hashlib,json,re,statistics,subprocess,sys
D=Path(__file__).parent;R=Path(sys.argv[1]);ROOT='/Users/thesyncim/GolandProjects/govpx';H='5c5cf3977052368746325c4033a1909e7eacd26a';BASE='6bda90f7eeee6f407d6ed53e299eab505afa440e';OLD='691cd0512c4829d9ee40d483205dd223f9eb028d';V=('assembly','previous','simd');MODULE='github.com/thesyncim/govpx/'
def write(name,x):(D/name).write_text(json.dumps(x,indent=2)+'\n')
def git(*args,input=None):return subprocess.check_output(['git','--no-optional-locks',*args],cwd=ROOT,input=input)
def sha(b):return hashlib.sha256(b).hexdigest()
raw={str(p.relative_to(R)):sha(p.read_bytes())for p in sorted(R.rglob('*'))if p.is_file()};assert sorted(n for n in raw if '/'not in n)==json.loads((D/'expected-top99.json').read_text());assert all('/'not in n or n.startswith('pixel-optional-stats-codegen/')for n in raw);write('raw-files-SHA256.json',raw)
env=(R/'environment.txt').read_text();assert env.splitlines()[:3]==['assembly commit: '+OLD,'previous SIMD commit: '+BASE,'SIMD commit: '+H];assert 'go version go1.27.2 linux/amd64'in env and'GOMAXPROCS=1 PGO=off rounds=6 kernel-benchtime=150ms'in env;cpu=re.search(r'^Model name:\s+(.+)$',env,re.M)[1]
script=git('show',H+':scripts/benchmark-amd64.sh').decode();paths=re.findall(r'sha256sum "\$root/([^"\n]+)"',script);assert len(paths)==len(set(paths))==132 and paths==json.loads((D/'expected-source-paths.json').read_text())
blob=git('cat-file','--batch',input=''.join(H+':'+p+'\n'for p in paths).encode());off=0;sources={}
for path in paths:
 end=blob.index(b'\n',off);hdr=blob[off:end].decode().split();assert hdr[1]=='blob';n=int(hdr[2]);sources[path]=sha(blob[end+1:end+1+n]);off=end+1+n+1
assert off==len(blob);recorded={}
for l in env.splitlines():
 m=re.match(r'([0-9a-f]{64})  (.+)$',l)
 if m:
  ps=[p for p in paths if m[2].endswith('/'+p)]
  if ps:recorded[max(ps,key=len)]=m[1]
assert sources==recorded
copies=re.findall(r'cp "\$root/([^"\n]+)" "\$source_dir/([^"\n]+)"',script);common=[a for a,b in copies if a==b];adapters=[(a,b)for a,b in copies if a!=b];assert len(common)==35 and adapters==[('scripts/benchmark-fixtures/dc_pair_inplace_reference_shim.go.txt','internal/vp8/dsp/dc_pair_inplace_reference_shim_test.go')]
adapter_records=re.findall(r'reference DC inplace API commit: ([0-9a-f]{40})\nreference DC inplace API: (.+)',env)
assert adapter_records==[(OLD,'test-only forwarding adapter'),(BASE,'original production function')],adapter_records
for suffix,helper in [('summary','analyze-three.py'),('parity','whole-parity.py')]:
 data=subprocess.check_output(['/usr/bin/python3',str(D/helper),str(R)]);(D/('native-'+suffix+'.json')).write_bytes(data)
s=json.loads((D/'native-summary.json').read_text());parity=json.loads((D/'native-parity.json').read_text());kernels=s['kernels'];assert len(kernels)==561
assert set(kernels)=={MODULE+x for x in json.loads((D/'expected-main-inventory.json').read_text())['all561']}
assert all(all(len(v[a+'_samples'])==6 and v[a+'_allocation_samples']==[[0.,0.]]for a in V)for v in kernels.values())
orders=[line.split(': ',1)[1].split()for line in(R/'orders.txt').read_text().splitlines()];assert len(orders)==len(set(map(tuple,orders)))==6
for i in range(3):assert collections.Counter(row[i]for row in orders)=={v:2 for v in V}
for p in parity.values():assert p['all_semantic_fields_equal']and len(p['semantic_fields'])==22
validation={};passes=collections.Counter();skips=collections.Counter()
for f in sorted(R.glob('*validation*.txt')):
 t=f.read_text();ps=re.findall(r'^--- PASS: (\S+)',t,re.M);sk=re.findall(r'^--- SKIP: (\S+)',t,re.M);fail=re.findall(r'^\s*--- FAIL: (\S+)',t,re.M);assert not fail,(f.name,fail);assert not re.search(r'^FAIL(?:\s|$)',t,re.M),f.name
 validation[f.name]={'PASS':ps,'SKIP':sk,'failures':fail};passes.update(ps);skips.update(sk)
quant=(R/'quant-batch-validation.txt').read_text();flog=(R/'fp16-validation.txt').read_text()
for name in ('TestDCPairNativePublicState','TestDCPairNativeDisabledState','TestDCOnlyPairLayouts','TestMacroAxisCallerFrozenState','TestTMPredict4TileFullBackingAliases','TestTMPredict4TileArithmetic','TestTMPredict4TileFallbackPanicState','TestTMPredict4TileCheckedPanicState','TestDCPairInPlacePublicState','TestDCPairInPlaceDisabledState'):
 assert quant.count('--- PASS: '+name+' ')==4,(name,quant.count('--- PASS: '+name+' '))
for name in ('TestDCPairNative','TestDCPairAllBytesAndDeltas'):assert quant.count('--- PASS: '+name+' ')==2 and quant.count('--- SKIP: '+name+' ')==2,name
for name in ('TestDCPairByteNativeSelected','TestDCPairCoeffByteBoundaries'):assert quant.count('--- PASS: '+name+' ')==2 and quant.count('--- SKIP: '+name+' ')==2,name
# Retain every previous ordinary/race validation PASS count. Extra current FP32
# tests are additive; unsupported native guards may legitimately skip as below.
previous=Path('/private/tmp/govpx-amd64-next48-artifact');prior=collections.Counter(n for f in previous.glob('*validation*.txt')for n in re.findall(r'^--- PASS: (\S+)',f.read_text(),re.M))
for name,count in prior.items():
 if name=='TestSSEPlane16AVX512':continue
 assert passes[name]>=count,(name,passes[name],count)
pat=re.compile(r'^(Benchmark\S+)\s+(\d+)\s+(?:(\S+) ns/op\s+)?(?:\S+ MB/s\s+)?(\S+) B/op\s+(\S+) allocs/op$',re.M)
def ones(text):
 rows=[]
 for name,it,ns,b,a in pat.findall(text):assert int(it)==1 and float(b)==float(a)==0;rows.append(name)
 return rows
quantrows=ones(quant);assert len(quantrows)==302
qcounts={x:sum(n.startswith('Benchmark'+x)for n in quantrows)for x in ('Copy16RowsNative/','TMPredictRowsNative/','IntraDCFill','DCPairRowsNative/','DCPairInPlaceRowsNative/')};assert qcounts=={'Copy16RowsNative/':32,'TMPredictRowsNative/':81,'IntraDCFill':81,'DCPairRowsNative/':54,'DCPairInPlaceRowsNative/':54}
fpfiles=[v+'-fp16-fixture-validation.txt'for v in V]+['simd-fp16-cpuoff-fixture-validation.txt'];assert all(len(ones((R/f).read_text()))==36 for f in fpfiles)
# New token fixture remains independent on all pinned production references.
token_expected={"BenchmarkPreparedTokenEOBNative/"+p+"/p"+str(q)for p in ("allEOB","sparse","gappy","denseSmall","denseMixed")for q in (0,128,230)}
token_preflights={}
for v in V:
 f=R/(v+'-token-eob-fixture-validation.txt');txt=f.read_text();rows=ones(txt)
 assert len(rows)==len(set(rows))==15 and set(rows)==token_expected,(v,rows)
 assert txt.count('--- PASS: TestPreparedEOBNoShiftState ')==2,v
 token_preflights[v]={'excluded15':rows,'independent_state_ordinary_race_PASS':2}
assert len(quantrows)+144+sum(len(x['excluded15'])for x in token_preflights.values())==491
macro_expected={"BenchmarkTokenCountMacroNative/is4"+a+"/"+p+"/records"+b for a in ("false","true")for p in ("zero","sparse","dense")for b in ("false","true")}
macro_preflights={}
for v in V:
 txt=(R/(v+'-token-count-macro-validation.txt')).read_text();rows=ones(txt)
 assert len(rows)==len(set(rows))==12 and set(rows)==macro_expected,(v,rows)
 assert txt.count('--- PASS: TestTokenCountMacroFrozenState ')==2 and txt.count('full-state/error/panic/backing cases=12288')==2,v
 macro_preflights[v]={'excluded12':rows,'independent_state_ordinary_race_PASS':2,'fullstate_cases_each':12288}
assert 491+sum(len(x['excluded12'])for x in macro_preflights.values())==527
for name in ('TestStatsOddRowAllBytePairs','TestStatsOddRowRowsAndTall','TestStatsOddRowMalformedWindows'):assert quant.count('--- PASS: '+name+' ')==4,name
features=re.findall(r'Enabled=(true|false) AVX2=(true|false) AVX512=(true|false)',flog);assert len(features)==6,features
available=features[0][2]=='true';assert features==[('true','true',str(available).lower())]*2+[('true','true','false')]*2+[('false','false','false')]*2,features
for name in ('TestFP32ActualFeature','TestFP32DispatchBoundaries','TestFP32WordClasses','TestFP32EligibleExactWindows','TestFP32EligibleAliasedDeclines','TestFP32EligiblePanicWindows'):assert flog.count('--- PASS: '+name+' ')==6,name
assert flog.count('--- PASS: TestFP32NativeSelectedOracles ')==(2 if available else 0)
assert flog.count('--- SKIP: TestFP32NativeSelectedOracles ')==(4 if available else 6)
# Actual public two-way component log: retain controls and every slower pair.
t=(R/'pixel-optional.txt').read_text();assert '--- FAIL:'not in t;hosts=re.findall(r'FP32PublicHost AVX512=(true|false) AVX2=(true|false) Enabled=(true|false)',t);assert hosts==[(str(available).lower(),'true','true')]*3,hosts
assert ('# SELECTED_AVX512_AVAILABLE=1'in t)==available;assert ('# SELECTED_AVX512_UNAVAILABLE'in t)==(not available)
assert 'go version go1.27.2 linux/amd64'in t
if available:
 for name in ('TestFP32ActualFeature','TestFP32NativeSelectedOracles','TestFP32EligibleExactWindows','TestFP32EligibleAliasedDeclines','TestFP32EligiblePanicWindows'):assert t.count('--- PASS: '+name+' ')==1,name
 assert '--- SKIP: TestFP32NativeSelectedOracles 'not in t
phase='preflight';variant=None;roundno=0;optional=collections.defaultdict(list);pre=collections.Counter();optorders=[]
for line in t.splitlines():
 if line.startswith('# excluded preflight '):variant=line.split()[3].rstrip(':')
 m=re.match(r'# round (\d+) order (.+)$',line)
 if m:phase='timed';roundno=int(m[1]);optorders.append(m[2].split());continue
 m=re.match(r'# round (\d+) pixel (parent|current)$',line)
 if m:assert int(m[1])==roundno;variant=m[2];continue
 if not line.startswith(('BenchmarkFP32PublicOptionalNative/','BenchmarkStatsReductionNative/')):continue
 if phase=='preflight'and re.fullmatch(r'(?:BenchmarkFP32PublicOptionalNative|BenchmarkStatsReductionNative)/\S+\s*',line):continue
 m=pat.match(line);assert m,line
 name,it,ns,b,a=m.groups();assert float(b)==float(a)==0 and int(it)>0
 if phase=='preflight':assert int(it)==1;pre[(variant,name)]+=1
 else:assert ns and float(ns)>0;optional[(variant,name)].append({'round':roundno,'ns':float(ns),'iterations':int(it),'bytes':float(b),'allocs':float(a)})
expected=json.loads((D/'expected-optional-inventory.json').read_text());all66=set(expected['all66']);timed=set(expected['all66']if available else expected['Stats18']);assert len(pre)==132 and all(c==1 for c in pre.values())
for v in ('parent','current'):
 assert {n for a,n in pre if a==v}==all66
 assert {n for a,n in optional if a==v}==timed
 for n in timed:assert [x['round']for x in optional[(v,n)]]==list(range(1,7))
assert optorders==[['parent','current']if n%2 else['current','parent']for n in range(1,7)]
optional_results={}
for name in sorted(timed):
 rows={v:optional[(v,name)]for v in ('parent','current')};med={v:statistics.median(x['ns']for x in rows[v])for v in rows};optional_results[name]={'samples':rows,'median_ns':med,'parent_speedup':med['parent']/med['current'],'all6_parent_speedups':[a['ns']/b['ns']for a,b in zip(rows['parent'],rows['current'])],'scope':'pixel API optionalq only, no encoder qnil caller claim'if name.startswith('BenchmarkFP32')else'public pixel Stats API'}
component=json.loads(subprocess.check_output(['/usr/bin/python3',str(D/'audit-component.py'),str(R)]));component['bindings']['unrolled']='ACTUAL52production; same88instruction guard body, feature-first outerdispatch';write('guard-component-proof.json',component)
assert '6402500232ee21792b751cad72aa24417e695f4bc0b49749308b839d93b1efdf'in(R/'fp16-guard-component.txt').read_text()
alloc=[]
for name,v in parity.items():
 rows=[(a,i+1,x)for a,ss in v['allocation_samples'].items()for i,x in enumerate(ss if isinstance(ss,list)else[ss])];mode=statistics.mode(x for a,i,x in rows);alloc.append({'dataset':name,'all_samples_equal':all(x==mode for a,i,x in rows),'mode':mode,'all_samples':rows,'exceptions':[(a,i,x)for a,i,x in rows if x!=mode]})
fp_targets={k:v for k,v in kernels.items()if '/BenchmarkVP9FP16Native/n256/'in k or '/BenchmarkVP9FusedFPClassesNative/16x16/'in k};assert len(fp_targets)==15
controls={k:v for k,v in kernels.items()if k not in fp_targets};assert len(controls)==546
stats_capture=json.loads(subprocess.check_output(['/usr/bin/python3',str(D/'audit-stats-capture.py'),str(R),H,BASE]));write('stats-native-capture-proof.json',stats_capture)
assert len(raw)==99+stats_capture['nested_files_total']
out={'head':H,'base':BASE,'old':OLD,'workflow_run_id':39131584002,'cpu':cpu,'actual512_available':available,'selected512_ordinary_race_and_optional_execution_proven':available,'FP32_acceptance_possible_from_hardware':available,'raw_all_sha256':raw,'exact132_source_sha256':sources,'common35':common,'reference_only_adapter':{'conditional_copy':adapters,'actual_records':adapter_records},'main561_results':kernels,'main10098_allzeroalloc':True,'main527_excluded':{'original446':qcounts,'EOB45':token_preflights,'macro36':macro_preflights},'all15_main_FP32_eligible_results':fp_targets,'main_FP32_target_execution_scope':'actual512 selected'if available else'AVX2 fallback controls ONLY; no512 acceptance','all546_other_results':controls,'all561_median_regressions':{k:v for k,v in kernels.items()if v['parent_time_delta_percent']>0},'all561_all6_slower':{k:v for k,v in kernels.items()if all(x>0 for x in v['parent_paired_percent'])},'optional132_excluded_zeroalloc':True,'optional_timed_count':len(optional_results)*12,'optional_results':optional_results,'all22_semantic_allocation_data':parity,'allocation_samples_and_exceptions':alloc,'public':s['encoders'],'actual_native_stats_capture':stats_capture,'validation':validation,'FP32_feature_records':features,'scope':['No performance threshold; keep every slower control/decline/allocation sample.','561main threeway and66optional pixel-only API phase are distinct; optionalq has no actualencodercaller claim.','Actual selected512 hardware is required for512 correctness/performance acceptance.','Kernel/component and wholecodec results are separate; no crossCPU pooling or causality fromsourceidentity.']};write('full-proof.json',out)
print(json.dumps({'head':H,'cpu':cpu,'actual512_available':available,'selected512_correctness':available,'raw_files':len(raw),'source_hashes':len(sources),'main_cases':len(kernels),'main_samples':10098,'main_excluded':527,'guard_timings':396,'guard_excluded':66,'optional_timings':len(optional_results)*12,'optional_excluded':132,'all561_median_slower':len(out['all561_median_regressions']),'all561_all6_slower':len(out['all561_all6_slower']),'allocation_exceptions':[{'dataset':x['dataset'],'exceptions':x['exceptions']}for x in alloc],'proof':str(D/'full-proof.json')},indent=2))

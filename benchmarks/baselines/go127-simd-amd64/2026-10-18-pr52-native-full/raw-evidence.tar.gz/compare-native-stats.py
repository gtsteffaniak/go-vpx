from pathlib import Path
import re,json,difflib
D=Path('/private/tmp/govpx-ci52-full-audit-5c5cf397');R=D/'raw/pixel-optional-stats-codegen';O=D/'followup';O.mkdir(exist_ok=True)
def norm(p,symbol):
 text=p.read_text();rows=[]
 for line in text.splitlines():
  m=re.match(r'^\s*([0-9a-f]+):\s+((?:[0-9a-f]{2}\s+)+)\s*(.*)$',line)
  if m and m[3].strip():rows.append((int(m[1],16),m[3].strip()))
 def padding(x):return x.startswith(('nop','nopl','nopw','int3'))or('nop'in x and x.startswith(('data16','cs ')))or re.fullmatch(r'xchg\s+%ax,%ax',x)is not None
 live=[(a,x)for a,x in rows if not padding(x)];indices={a:i for i,(a,x)in enumerate(live)}
 def target(m):
  addr=int(m[1],16);name=m[2]
  if name==symbol or name.startswith(symbol+'+'):
   idx=next((i for a,i in sorted(indices.items())if a>=addr),None);assert idx is not None,(p,addr);return '<LOCAL:'+str(idx)+'>'
  return '<'+name+'>'
 out=[]
 for a,x in live:
  x=re.sub(r'\b([0-9a-f]+) <([^>]+)>',target,x);x=re.sub(r'[-]?0x[0-9a-f]+\(%rip\)','RELOC(%rip)',x);x=x.split('#',1)[0].rstrip();out.append(x)
 return rows,out
result={};pmeta=json.loads((R/'parent/metadata.json').read_text());cmeta=json.loads((R/'current/metadata.json').read_text())
for name in pmeta['live_symbols'].keys()&cmeta['live_symbols'].keys():
 short=name.split('.')[-1];filename=name.removeprefix('github.com/thesyncim/govpx/internal/pixel.')+'.asm.txt';a,an=norm(R/'parent'/filename,name);b,bn=norm(R/'current'/filename,name);result[filename]={'nonpadding_normalized_equal':an==bn,'parent_instructions_including_padding':len(a),'current_instructions_including_padding':len(b),'parent_nonpadding':len(an),'current_nonpadding':len(bn),'parent_symbol':pmeta['live_symbols'][name],'current_symbol':cmeta['live_symbols'][name]};(O/(filename+'.normalized.diff')).write_text(''.join(difflib.unified_diff(an,bn,fromfile='parent',tofile='current',lineterm='\n')))
(O/'native-stats-body-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:{x:y for x,y in v.items()if x not in ('parent_symbol','current_symbol')}for k,v in result.items()},indent=2))

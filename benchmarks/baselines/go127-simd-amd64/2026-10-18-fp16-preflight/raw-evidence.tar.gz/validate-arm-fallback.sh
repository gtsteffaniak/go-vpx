#!/bin/sh
set -eu
export CODEX_AGENT_ID=ci-fp16-arm CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go
export GOMAXPROCS=2 GOFLAGS=-p=2 CGO_ENABLED=0
p=/private/tmp/govpx-next-fp16
root=/Users/thesyncim/GolandProjects/govpx
run() { printf '%s\n' "$*" >> "$p/final-commands.txt"; "$@"; }
for target in candidate parent; do
 run "$root/scripts/go.sh" -C "$p/$target" test -pgo=off -c -o "$p/final-arm-$target.test" ./internal/pixel > "$p/final-arm-$target-build.log" 2>&1
 run "$p/final-arm-$target.test" '-test.run=QuantizeFP' -test.count=1 -test.v > "$p/final-arm-$target-pixel.log" 2>&1
done
run "$root/scripts/go.sh" -C "$p/candidate" test -pgo=off '-run=TestQuantizeFP' -count=1 -v ./internal/vp9/encoder > "$p/final-arm-encoder.log" 2>&1
run "$root/scripts/go.sh" -C "$p/candidate" test -pgo=off -tags=purego '-run=TestQuantizeFP' -count=1 -v ./internal/pixel ./internal/vp9/encoder > "$p/final-purego.log" 2>&1
GOEXPERIMENT=nosimd run "$root/scripts/go.sh" -C "$p/candidate" test -pgo=off '-run=TestQuantizeFP' -count=1 -v ./internal/pixel ./internal/vp9/encoder > "$p/final-nosimd.log" 2>&1

#!/bin/sh
set -eu
export CODEX_AGENT_ID=ci-fp16-fixture CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go
export GOMAXPROCS=2 GOFLAGS=-p=2 GOAMD64=v1 CGO_ENABLED=0
p=/private/tmp/govpx-next-fp16
root=/Users/thesyncim/GolandProjects/govpx
for target in candidate parent oldbuild; do
 for mode in ordinary checkptr; do
  extra=
  if [ "$mode" = checkptr ]; then extra=-gcflags=all=-d=checkptr=2; fi
  env GOOS=darwin GOARCH=amd64 "$root/scripts/go.sh" -C "$p/$target" test -pgo=off $extra -c -o "$p/fixture-$target-$mode.test" ./internal/vp9/encoder > "$p/fixture-$target-$mode-build.log" 2>&1
  env ROSETTA_ADVERTISE_AVX=1 GOVPX_REQUIRE_SIMD=1 arch -x86_64 "$p/fixture-$target-$mode.test" -test.run '^$' -test.bench '^BenchmarkVP9FP16Native$' -test.benchtime=1x -test.count=1 -test.cpu=1 -test.benchmem > "$p/fixture-$target-$mode-oneshot.log" 2>&1
 done
done
for mode in ordinary checkptr; do
 env ROSETTA_ADVERTISE_AVX=1 GODEBUG=cpu.avx=off,cpu.avx2=off GOVPX_REQUIRE_SIMD=0 arch -x86_64 "$p/fixture-candidate-$mode.test" -test.run '^$' -test.bench '^BenchmarkVP9FP16Native$' -test.benchtime=1x -test.count=1 -test.cpu=1 -test.benchmem > "$p/fixture-candidate-$mode-cpuoff.log" 2>&1
done
for mode in purego nosimd; do
 if [ "$mode" = purego ]; then
  "$root/scripts/go.sh" -C "$p/candidate" test -pgo=off -tags=purego -run '^$' -bench '^BenchmarkVP9FP16Native$' -benchtime=1x -count=1 -cpu=1 -benchmem ./internal/vp9/encoder > "$p/fixture-$mode-oneshot.log" 2>&1
 else
  env GOEXPERIMENT=nosimd "$root/scripts/go.sh" -C "$p/candidate" test -pgo=off -run '^$' -bench '^BenchmarkVP9FP16Native$' -benchtime=1x -count=1 -cpu=1 -benchmem ./internal/vp9/encoder > "$p/fixture-$mode-oneshot.log" 2>&1
 fi
done

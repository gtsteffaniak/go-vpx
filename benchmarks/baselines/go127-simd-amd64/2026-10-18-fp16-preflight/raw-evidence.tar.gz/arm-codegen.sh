#!/bin/sh
set -eu
export CODEX_AGENT_ID=ci-fp16-arm-proof CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go
export GOMAXPROCS=2 GOFLAGS=-p=2 CGO_ENABLED=0
p=/private/tmp/govpx-next-fp16
root=/Users/thesyncim/GolandProjects/govpx
for target in parent candidate; do
 "$root/scripts/go.sh" -C "$p/$target" test -pgo=off -c -o "$p/final-arm-encoder-$target.test" ./internal/vp9/encoder > "$p/final-arm-encoder-$target-build.log" 2>&1
 /Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/llvm-objdump --disassemble --no-show-raw-insn '--disassemble-symbols=_github.com/thesyncim/govpx/internal/pixel.quantizeFPBlockSIMD' "$p/final-arm-encoder-$target.test" > "$p/final-arm-encoder-$target-llvm.txt"
done

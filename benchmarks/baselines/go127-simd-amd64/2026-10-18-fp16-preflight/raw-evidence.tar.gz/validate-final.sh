#!/bin/sh
set -eu
export CODEX_AGENT_ID=ci-fp16-final CODEX_PROJECT_CACHE_ROOT=/private/tmp/codex-projects GOTOOLCHAIN=local
export GO=/Users/thesyncim/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.darwin-arm64/bin/go
export GOMAXPROCS=2 GOFLAGS=-p=2 GOAMD64=v1 CGO_ENABLED=0
p=/private/tmp/govpx-next-fp16
root=/Users/thesyncim/GolandProjects/govpx
run() { printf '%s\n' "$*" >> "$p/final-commands.txt"; "$@"; }
run "$root/scripts/go.sh" -C "$p/candidate" env GOCACHE > "$p/final-cache.log" 2>&1
for mode in ordinary checkptr; do
 extra=
 if [ "$mode" = checkptr ]; then extra=-gcflags=all=-d=checkptr=2; fi
 for package in pixel encoder; do
  pkg=./internal/pixel
  if [ "$package" = encoder ]; then pkg=./internal/vp9/encoder; fi
  GOOS=darwin GOARCH=amd64 run "$root/scripts/go.sh" -C "$p/candidate" test -pgo=off $extra -c -o "$p/final-$package-$mode.test" "$pkg" > "$p/final-$package-$mode-build.log" 2>&1
  run env GODEBUG= GOVPX_REQUIRE_FP16_AVX_OFF=0 ROSETTA_ADVERTISE_AVX=1 GOVPX_REQUIRE_SIMD=1 arch -x86_64 "$p/final-$package-$mode.test" '-test.run=TestFP16|TestQuantizeFP' -test.count=1 -test.v > "$p/final-$package-$mode-selected.log" 2>&1
 done
 run env GODEBUG=cpu.avx=off,cpu.avx2=off ROSETTA_ADVERTISE_AVX=1 GOVPX_REQUIRE_SIMD=0 GOVPX_REQUIRE_FP16_AVX_OFF=1 arch -x86_64 "$p/final-pixel-$mode.test" '-test.run=^TestFP16' -test.count=1 -test.v > "$p/final-pixel-$mode-cpuoff.log" 2>&1
 run env GODEBUG=cpu.avx=off,cpu.avx2=off ROSETTA_ADVERTISE_AVX=1 GOVPX_REQUIRE_SIMD=0 arch -x86_64 "$p/final-encoder-$mode.test" '-test.run=TestQuantizeFP' -test.count=1 -test.v > "$p/final-encoder-$mode-cpuoff.log" 2>&1
done
GOOS=linux GOARCH=amd64 run "$root/scripts/go.sh" -C "$p/candidate" test -pgo=off -c -o "$p/final-pixel-linux.test" ./internal/pixel > "$p/final-pixel-linux-build.log" 2>&1

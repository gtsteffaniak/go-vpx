from pathlib import Path
import re,json
p=Path('/private/tmp/govpx-next-fp16');out={};parsed={}
for f in sorted(p.glob('fixture-*.log')):
 if f.name.endswith('-build.log'):continue
 rows=[]
 for x in f.read_text().splitlines():
  if x.startswith('BenchmarkVP9FP16Native/') and 'ns/op' in x:
   m=re.match(r'(BenchmarkVP9FP16Native/\S+)\s+1\s+\S+ ns/op\s+(\d+) B/op\s+(\d+) allocs/op',x);assert m,x
   rows.append((m[1],int(m[2]),int(m[3])))
 t=f.read_text();result={'cases':len(rows),'pass':bool(re.search(r'^PASS$',t,re.M)),'zero_alloc_cases':sum(b==0 and a==0 for _,b,a in rows),'allocation_pairs':sorted(set((b,a) for _,b,a in rows)),'samples_are_timing_evidence':False}
 assert len(rows)==36 and result['pass'],(f,result)
 if 'checkptr' not in f.name:assert result['zero_alloc_cases']==36,(f,result)
 out[f.name]=result;parsed[f.name]={n:(b,a) for n,b,a in rows}
assert parsed['fixture-candidate-checkptr-oneshot.log']==parsed['fixture-parent-checkptr-oneshot.log']
assert parsed['fixture-candidate-checkptr-cpuoff.log']==parsed['fixture-oldbuild-checkptr-oneshot.log']
out['instrumentation_scope']='checkptr2 classes: candidate=parent16B/1alloc; CPUoff caller walk=oldASM caller walk (400/33 atn16,1552/129atn64,6160/513atn256). Ordinary/purego/nosimd all36=0B/0alloc. Instrumented values are not production-allocation claims.'
(p/'fixture-audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

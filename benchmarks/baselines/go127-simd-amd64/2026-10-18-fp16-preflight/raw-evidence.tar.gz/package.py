from pathlib import Path
import shutil,json,hashlib,difflib,re
p=Path('/private/tmp/govpx-next-fp16'); ready=Path('/private/tmp/govpx-fp16-avx2-ready');ready.mkdir(exist_ok=True)
files=['internal/pixel/quantize_fp_simd.go','internal/pixel/quantize_fp_amd64.go','internal/pixel/quantize_fp16_amd64_test.go','internal/vp9/encoder/quant_fp16_native_test.go']
for f in files:
 d=ready/'overlay'/f;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p/'candidate'/f,d)
for f in p.iterdir():
 if f.is_file() and (f.suffix in ['.log','.txt','.json','.sh','.patch','.py'] or f.name=='scope.json'):
  shutil.copy2(f,ready/f.name)
shutil.copytree(p/'initial-class-bounds',ready/'initial-class-bounds',dirs_exist_ok=True)
ref=ready/'reference';ref.mkdir(exist_ok=True)
for f in ['internal/pixel/quantize_fp.go','internal/pixel/helpers_amd64.go','internal/vp9/encoder/quant_fp_classes_native_bench_test.go']:
 d=ref/f;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p/'candidate'/f,d)
# Preserve the original shared body, not an entire source checkout.
shutil.copy2(p/'parent-quantize_fp_simd.go.txt',ref/'parent-quantize_fp_simd.go.txt')
diff=[]
for f in files:
 a=(p/'parent'/f).read_text().splitlines(True) if (p/'parent'/f).exists() and f!='internal/vp9/encoder/quant_fp16_native_test.go' else []
 b=(p/'candidate'/f).read_text().splitlines(True)
 diff.extend(difflib.unified_diff(a,b,fromfile='a/'+f if a else '/dev/null',tofile='b/'+f))
(ready/'overlay.patch').write_text(''.join(diff))
# Codegen hot segments are split around the mutually exclusive original fallback.
code=(p/'final-linux-llvm.txt').read_text()
pat=re.compile(r'^\s*([0-9a-f]+):\s*(.*)$',re.M)
ins=[(int(a,16),s) for a,s in pat.findall(code)]
hot=[s for a,s in ins if 0x5653da<=a<0x565545 or 0x565934<=a<=0x565a64]
loop=[s for a,s in ins if 0x565934<=a<0x565a18]
proof=json.loads((p/'final-identity-proof.json').read_text())
proof.update({'wide_hot_instructions':len(hot),'wide_loop_instructions':len(loop),'wide_hot_calls':[s for s in hot if s.startswith('call')],'wide_hot_legacy_vector':[s for s in hot if re.match(r'(movups|movaps|pxor|pand|por|padd|psub|pshuf|pcmpeq|pcmpgt)',s)],'wide_hot_vector_stack':[s for s in hot if re.search(r'%[xy]mm',s) and '(%rsp)' in s],'wide_hot_vzeroupper':sum(s.startswith('vzeroupper') for s in hot),'frame_bytes_parent':168,'frame_bytes_candidate':168,'performance_measured':False})
assert not proof['wide_hot_calls'] and not proof['wide_hot_legacy_vector'] and not proof['wide_hot_vector_stack'] and proof['wide_hot_vzeroupper']==1
(ready/'codegen-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
source_hashes={f:hashlib.sha256((p/'candidate'/f).read_bytes()).hexdigest() for f in files}
(ready/'source-sha256.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
# Binary files stay in working directory; exact hashes connect logs to builds.
bins={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in list(p.glob('final-*.test'))+list(p.glob('fixture-*.test'))}
(ready/'binary-sha256.json').write_text(json.dumps(bins,indent=2)+'\n')
shutil.copytree(p/'proposed-ci-overlay',ready/'proposed-ci-overlay',dirs_exist_ok=True)
print(ready)
print(json.dumps(proof,indent=2))

from pathlib import Path
import json,subprocess,itertools,re
p=Path('/private/tmp/govpx-ci49-full-audit-39115190163');base=Path('/private/tmp/govpx-pr48-native-harness-inventory/expected-timed-inventory.json');s=json.loads(base.read_text());old=set(s['all_names']);assert len(old)==516
new={'internal/vp8/dsp/BenchmarkDCPairInPlaceRowsNative/pitch%d/inplace%s/pair%d'%(pitch,str(alias).lower(),pair)for pitch,alias,pair in itertools.product((8,32,1312),(False,True),range(3))};assert len(new)==18 and not old&new
(p/'expected-main-inventory.json').write_text(json.dumps({'old516':sorted(old),'added18':sorted(new),'all534':sorted(old|new)},indent=2)+'\n')
H='41596b4e0ad1087e4afe4020825d03cb38e2c4ce';root='/Users/thesyncim/GolandProjects/govpx';script=subprocess.check_output(['git','show',H+':scripts/benchmark-amd64.sh'],cwd=root,text=True);paths=re.findall(r'sha256sum "\$root/([^"\n]+)"',script);assert len(paths)==len(set(paths))==116
(p/'expected-source-paths.json').write_text(json.dumps(paths,indent=2)+'\n');(p/'head-benchmark-amd64.sh').write_text(script)
fixtures=[]
for path in ('fp32_optional_native_test.go','stats_reduction_native_test.go'):
 fixtures.append(subprocess.check_output(['git','show',H+':internal/pixel/'+path],cwd=root,text=True))
fp={'BenchmarkFP32PublicOptionalNative/n%d/qnil%s/classes%s/%s/%s'%(n,str(qnil).lower(),str(classes).lower(),pattern,align)for n,qnil,classes,pattern,align in itertools.product((64,256),(False,True),(False,True),('zero','sparse','dense'),('aligned64','offset2-classes1'))};stats={'BenchmarkStatsReductionNative/w%d/h%d'%(w,h)for w,h in itertools.product((8,32,64),(1,7,8,64,4096,4097))};assert len(fp)==48 and len(stats)==18
(p/'expected-optional-inventory.json').write_text(json.dumps({'FP48':sorted(fp),'Stats18':sorted(stats),'all66':sorted(fp|stats)},indent=2)+'\n')
print('prepared534main,66optional,116SHA inventory; source-only, no Go/native execution')

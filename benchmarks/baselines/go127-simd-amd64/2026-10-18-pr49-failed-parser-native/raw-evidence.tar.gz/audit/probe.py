from pathlib import Path
import re,json,sys
r=Path(sys.argv[1]);out={}
for name in ('fp16-validation.txt','pixel-optional.txt','quant-batch-validation.txt'):
 p=r/name
 if not p.exists():out[name]={'present':False};continue
 t=p.read_text();features=re.findall(r'Enabled=(true|false) AVX2=(true|false) AVX512=(true|false)',t);hosts=re.findall(r'FP32PublicHost AVX512=(true|false) AVX2=(true|false) Enabled=(true|false)',t)
 out[name]={'present':True,'FP32_feature_records':features,'public_host_records':hosts,'FP32_native_selected_PASS':t.count('--- PASS: TestFP32NativeSelectedOracles '),'FP32_native_selected_SKIP':t.count('--- SKIP: TestFP32NativeSelectedOracles '),'test_failures':re.findall(r'^\s*--- FAIL: (\S+)',t,re.M),'explicit_native512_available':'# SELECTED_AVX512_AVAILABLE=1'in t,'explicit_unavailable':'# SELECTED_AVX512_UNAVAILABLE'in t}
print(json.dumps(out,indent=2))

from pathlib import Path
import json,shutil,hashlib,tarfile,subprocess,statistics
p=Path('/private/tmp/govpx-ci49-full-audit-39115190163');r=Path('/Users/thesyncim/GolandProjects/govpx');ready=Path('/private/tmp/govpx-pr49-native-full-failed41596-ready');assert not ready.exists();ready.mkdir()
def copy(a,b):b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((p/'full-proof.json').read_text());manifest=json.loads((p/'raw-files-SHA256.json').read_text());assert len(manifest)==93
for name,want in manifest.items():assert sha(p/'raw'/name)==want;copy(p/'raw'/name,ready/'raw'/name)
for f in p.iterdir():
 if f.is_file():copy(f,ready/'audit'/f.name)
fix=Path('/private/tmp/govpx-ci49-pixel-parser-fix')
for f in fix.iterdir():
 if f.is_file():copy(f,ready/'parser-fix-proof'/f.name)
# Exact failed-head source bodies: never read repaired current root as41596.
H=s['head'];paths=list(s['exact116_source_sha256']);blob=subprocess.check_output(['git','cat-file','--batch'],cwd=r,input=''.join(H+':'+x+'\n'for x in paths).encode());off=0
for rel in paths:
 end=blob.index(b'\n',off);hdr=blob[off:end].decode().split();assert hdr[1]=='blob';n=int(hdr[2]);data=blob[end+1:end+1+n];assert hashlib.sha256(data).hexdigest()==s['exact116_source_sha256'][rel];dest=ready/'failed-head-sources'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);off=end+n+2
assert off==len(blob)
lines=['# Failed PR49 native job: completed measurements, parser failure','','Exact head `'+H+'`, base `'+s['base']+'`, old Go/assembly reference `'+s['old']+'`.','Workflow run39115190163/job117639458187 FAILED at10:06:42UTC after42m26. The final optional Python parser rejected a verbose name-only preflight header. This package does not label the GitHub job green. All raw files remain unchanged.','','Hardware: **'+s['cpu']+'**. Real SDK AVX2=true, AVX512=false. Selected512 oracle skipped6 times. The optional log explicitly declares512 unavailable and omits all FP32 timings. No selected512 correctness/performance acceptance is possible from this runner.','','The independent data audit verifies93raw hashes,116exact failed-head source hashes,33common fixtures and one reference-only adapter,534cases×18=9612main samples,446excluded ordinary one-shots,396guard samples/66excluded, and216Stats samples/132optional excluded preflights. Every timed micro sample is0B/0alloc. All22codec semantic fields and all allocation samples agree, including profile rows. All303median regressions and112all-six-slower cases are preserved in full-proof.json.','','## Actual public Stats18, paired parent/current','','One deterministic pattern per width/height, not multiple patterns: bytes(i*37+11) versus bytes(i*19+53), strides width+13/width+17 and starts3/5. Thus w32h1 is one case with source/reference strides45/49.','','| Case | Parent ns | Current ns | Parent/current | Paired min–max | All6 slower |','|---|---:|---:|---:|---:|---:|']
for name,v in sorted(s['optional_results'].items()):
 med=v['median_ns'];pairs=v['all6_parent_speedups'];lines.append('| '+name.removeprefix('BenchmarkStatsReductionNative/')+' | %.5g | %.5g | %.6f | %.6f–%.6f | %s |'%(med['parent'],med['current'],v['parent_speedup'],min(pairs),max(pairs),all(x<1 for x in pairs)))
lines+=['','w32h1 is a reproducible20.063% time regression (15.925→19.12ns, all6pairs slower). Long width32/64 cases gain roughly3–5%; width8short cases gain up to6.66%. No1.5× result is claimed for this Stats trial.','','## Whole codecs on this same native runner','','| Workload | Old Go+ASM ms | Parent ms | Current ms | Current time vs parent | Current time vs old | All6 faster than old |','|---|---:|---:|---:|---:|---:|---:|']
for name,v in s['public'].items():lines.append('| '+name+' | %.6f | %.6f | %.6f | %+.6f%% | %+.6f%% | %s |'%(v['assembly_ns']/1e6,v['previous_ns']/1e6,v['simd_ns']/1e6,v['parent_time_delta_percent'],v['time_delta_percent'],all(x<0 for x in v['paired_percent'])))
lines+=['','Old means actual pinned691cd051 Go/handwritten assembly built with the same official Go1.27.2/PGOoff/GOMAX1. It is not the external libvpx C oracle. Do not pool these x64 results with separate local ARM whole-codec windows. All per-round output, quantizer, drop/count fields and allocation samples remain in raw/full proof.','','The two-line parser proposal accepts only verbose name-only preflight headers; inventory, positive timed values and allocation checks remain unchanged. Replay on the complete real immutable optional log passes132excluded+216timed without running a new benchmark. The original42minute job remains failed; a repaired exact-head CI run is still required.','','No executables or full repository snapshot are included. Raw.pgo files are profiling data and remain intact. Repaired root production source is deliberately excluded: included116sources are the exact failed41596 commit.']
(ready/'REPORT.md').write_text('\n'.join(lines)+'\n')
# Preserve previous PASS requirements without relying on the other raw folder.
import re,collections
prior=collections.Counter(n for f in Path('/private/tmp/govpx-amd64-next48-artifact').glob('*validation*.txt')for n in re.findall(r'^--- PASS: (\S+)',f.read_text(),re.M));(ready/'audit/prior48-PASS-requirements.json').write_text(json.dumps(prior,indent=2)+'\n')
m={str(f.relative_to(ready)):sha(f)for f in sorted(ready.rglob('*'))if f.is_file()};(ready/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n');archive=Path(str(ready)+'.tar.gz')
with tarfile.open(archive,'w:gz')as t:t.add(ready,arcname=ready.name)
print(json.dumps({'ready':str(ready),'members_excluding_manifest':len(m),'raw_files':93,'source_files':116,'original_job':'FAILURE parser, completed data auditPASS','actual_AVX512':False,'manifest_sha256':sha(ready/'MANIFEST.json'),'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'all_jobs_stopped':True},indent=2))
